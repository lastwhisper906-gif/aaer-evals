# ADTN MD&A — 0001193125-12-334164


## mdna

[0001193125-12-334164:mdna:1]
[same as prior period, unchanged from 0001193125-12-220696:mdna:1]

[0001193125-12-334164:mdna:2]
[same as prior period, unchanged from 0001193125-12-220696:mdna:2]

[0001193125-12-334164:mdna:3]
[same as prior period, unchanged from 0001193125-12-220696:mdna:3]

[0001193125-12-334164:mdna:4]
[same as prior period, unchanged from 0001193125-12-220696:mdna:4]

[0001193125-12-334164:mdna:5]
[same as prior period, unchanged from 0001193125-12-220696:mdna:5]

[0001193125-12-334164:mdna:6]
[same as prior period, unchanged from 0001193125-12-220696:mdna:6]

[0001193125-12-334164:mdna:7]
[same as prior period, unchanged from 0001193125-12-220696:mdna:7]

[0001193125-12-334164:mdna:8]
See Note 11 of
Notes to Consolidated Financial Statements in this report for further information regarding these product categories.

[0001193125-12-334164:mdna:9]
Sales were $184.0
million and $318.7 million for the three and six months ended June 30, 2012 compared to $184.2 million and $349.7 million for the three and six months ended June 30, 2011. Product revenues for our three primary growth areas, Broadband
Access, Optical Access and Internetworking, were $155.0 million and $259.7 million for the three and six months ended June 30, 2012 compared to $132.1 million and $237.7 million for the three and six months ended June 30, 2011. Our gross
margin decreased to 51.7% and 53.1% for the three and six months ended June 30, 2012 from 58.0% and 58.8% for the three and six months ended June 30, 2011. Our operating income margin decreased to 14.6% and 13.5% for the three and six
months ended June 30, 2012 from 27.9% and 27.7% for the three and six months ended June 30, 2011. Net income was $21.1 million and $34.0 million for the three and six months ended June 30, 2012 compared to $36.9 million and $71.2
million for the three and six months ended June 30, 2011. Our effective tax rate increased to 35.7% for the three months ended June 30, 2012 from 34.0% for the three months ended June 30, 2011 and increased to 35.6% for the six months
ended June 30, 2012 from 32.5% for the six months ended June 30, 2011. Earnings per share, assuming dilution, were $0.33 and $0.53 for the three and six months ended June 30, 2012 compared to $0.56 and $1.08 for the three and six
months ended June 30, 2011.

[0001193125-12-334164:mdna:10]
[same as prior period, unchanged from 0001193125-12-220696:mdna:10]

[0001193125-12-334164:mdna:11]
[same as prior period, unchanged from 0001193125-12-220696:mdna:11]

[0001193125-12-334164:mdna:12]
[same as prior period, unchanged from 0001193125-12-220696:mdna:12]

[0001193125-12-334164:mdna:13]
[same as prior period, unchanged from 0001193125-12-220696:mdna:13]

[0001193125-12-334164:mdna:14]
[same as prior period, unchanged from 0001193125-12-220696:mdna:14]

[0001193125-12-334164:mdna:15]
[same as prior period, unchanged from 0001193125-12-220696:mdna:15]

[0001193125-12-334164:mdna:16]
[same as prior period, unchanged from 0001193125-12-220696:mdna:16]

[0001193125-12-334164:mdna:17]
[same as prior period, unchanged from 0001193125-12-220696:mdna:17]

[0001193125-12-334164:mdna:18]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks (NSN) Broadband Access business (NSN BBA
business). Acquisition related expenses, amortizations and adjustments for the three and six months ended June 30, 2012 for both transactions are as follows:

[0001193125-12-334164:mdna:19]
| (In Thousands) |  | ThreeMonths EndedJune 30, 2012 |  |  | SixMonths EndedJune 30, 2012 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 267 |  |  | $ | 485 |  |
| Amortization of other purchase accounting adjustments |  |  | 111 |  |  |  | 377 |  |
| Subtotal |  |  | 378 |  |  |  | 862 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 172 |  |  |  | 172 |  |
| Amortization of other purchase accounting adjustments |  |  | 1,052 |  |  |  | 1,052 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 2,705 |  |  |  | 4,285 |  |
| Subtotal |  |  | 3,929 |  |  |  | 5,509 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 4,307 |  |  |  | 6,371 |  |
| Tax effect |  |  | (1,361 | ) |  |  | (2,039 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 2,946 |  |  | $ | 4,332 |  |

[0001193125-12-334164:mdna:20]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated
Statements of Income categories for the three and six months ended June 30, 2012:

[0001193125-12-334164:mdna:21]
| (In Thousands) |  | ThreeMonths EndedJune 30, 2012 |  |  | SixMonths EndedJune 30, 2012 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 508 |  |  | $ | 654 |  |
| Cost of goods sold |  |  | 669 |  |  |  | 806 |  |
| Subtotal |  |  | 1,177 |  |  |  | 1,460 |  |
| Selling, general and administrative expenses |  |  | 2,361 |  |  |  | 3,922 |  |
| Research and development expenses |  |  | 769 |  |  |  | 989 |  |
| Subtotal |  |  | 3,130 |  |  |  | 4,911 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 4,307 |  |  |  | 6,371 |  |
| Tax effect |  |  | (1,361 | ) |  |  | (2,039 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 2,946 |  |  | $ | 4,332 |  |

[0001193125-12-334164:mdna:22]
25

[0001193125-12-334164:mdna:23]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2012 COMPARED TO THREE AND SIX MONTHS
ENDED JUNE 30, 2011

[0001193125-12-334164:mdna:24]
[same as prior period, unchanged from 0001193125-12-220696:mdna:23]

[0001193125-12-334164:mdna:25]
ADTRAN’s sales decreased 0.1% from $184.2 million in the three months ended June 30, 2011 to $184.0 million in the three months ended June 30, 2012, and decreased 8.9% from $349.7 million
in the six months ended June 30, 2011 to $318.7 million in the six months ended June 30, 2012. The decrease in sales for the three months ended June 30, 2012 is primarily attributable to a $23.1 million decrease in sales of our HDSL
and other legacy products and an $8.0 million decrease in sales of our Optical products, substantially offset by a $29.0 million increase in sales of our Broadband Access products and a $1.9 million increase in sales of our Internetworking products.
The decrease in sales for the six months ended June 30, 2012 is primarily attributable to a $53.0 million decrease in sales of our HDSL and other legacy products, a $14.7 million decrease in sales of our Optical products, partially offset by a
$26.7 million increase in sales of our Broadband Access products and a $10.0 million increase in sales of our Internetworking products.

[0001193125-12-334164:mdna:26]
Carrier Networks sales increased 1.5% from $150.5 million in the three months ended June 30, 2011 to $152.7 million in the three months ended
June 30, 2012, and decreased 11.8% from $282.9 million in the six months ended June 30, 2011 to $249.4 in the six months ended June 30, 2012. The increase in sales for the three months ended June 30, 2012 is primarily
attributable to increases in sales of our Broadband Access products and Internetworking NTE products, partially offset by decreases in sales of our Optical products and HDSL and other legacy products. The decrease in sales for the six months ended
June 30, 2012 is primarily attributable to decreases in sales of our Optical products and HDSL and other legacy products. This decline was partially offset by the added sales of the NSN BBA business and an increase in sales of our
Internetworking NTE products and organic Broadband Access products. Our organic Broadband Access sales for the six months ended June 30, 2012 were impacted by a delay in both the start and ramp-up of orders during the first quarter of this year
from one of our larger carrier customers due to a new systems implementation. The declining trend in HDSL and other legacy products has been expected as we evolve our products towards packet-based technologies.

[0001193125-12-334164:mdna:27]
Enterprise Networks sales decreased 7.2% from $33.7 million in the three months ended June 30, 2011 to $31.3 million in the three months ended
June 30, 2012, and increased 3.7% from $66.9 million in the six months ended June 30, 2011 to $69.4 million in the six months ended June 30, 2012. The decrease for the three months ended June 30, 2012 is primarily attributable to
a decrease in sales of Internetworking products and legacy products. The increase for the six months ended June 30, 2012 is primarily attributable to an increase in Internetworking product sales, partially offset by a decrease in sales of
legacy products. Internetworking product sales attributable to Enterprise Networks were 91.1% of the division’s sales in the three and six months ended June 30, 2012, compared to 85.4% and 85.2% in the three and six months ended
June 30, 2011. Legacy products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 18.3% for the three months ended June 30, 2011 to 17.0% for the three
months ended June 30, 2012 and increased from 19.1% for the six months ended June 30, 2011 to 21.8% for the six months ended June 30, 2012.

[0001193125-12-334164:mdna:28]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, increased 128.9% from $23.4 million in the three months ended June 30, 2011 to $53.6
million in the three months ended June 30, 2012, and increased 100.7% from $35.8 million in the six months ended June 30, 2011 to $71.9 million in the six months ended June 30, 2012. International sales, as a percentage of total
sales, increased from 12.7% for the three months ended June 30, 2011 to 29.1% for the three months ended June 30, 2012, and increased from 10.2% for the six months ended June 30, 2011 to 22.6% for the six months ended June 30,
2012. International sales increased in the three and six months ended June 30, 2012 compared to the three and six months ended June 30, 2011 primarily due to sales attributable to the acquired NSN BBA business and an increase in organic
sales in Latin America.

[0001193125-12-334164:mdna:29]
Carrier System product sales increased $14.5 million in the three months ended June 30, 2012 and decreased $1.0
million in the six months ended June 30, 2012 compared to the three and six months ended June 30, 2011. The increase for the three months ended June 30, 2012 is primarily due to a $29.0 million increase in Broadband Access product
sales, partially offset by an $8.0 million decrease in Optical product sales and a $6.5 million decrease in legacy product sales. The decrease for the six months ended June 30, 2012 is primarily due to a $14.7 million decrease in Optical
product sales and a $13.0 million decrease in legacy product sales. This decline was partially offset by the added sales of the NSN BBA business and an increase in sales of our Internetworking NTE products and organic Broadband Access products.

[0001193125-12-334164:mdna:30]
Our organic Broadband Access sales for the six months ended June 30, 2012 were impacted by a delay in
both the start and ramp-up of orders during the first quarter of this year from one of our larger carrier customers due to a new systems implementation. The declining trend in HDSL and other legacy products has been expected as we evolve our
products towards packet-based technologies.

[0001193125-12-334164:mdna:31]
Business Networking product sales increased $0.9 million and $7.7 million in the three and six
months ended June 30, 2012 compared to the three and six months ended June 30, 2011. The increase for the three months ended June 30, 2012 is primarily due to a $1.9 million increase in Interworking product sales across both
divisions, partially offset by a $1.0 million decrease in legacy product sales. The increase for the six months ended June 30, 2012 is primarily due to a $10.0 million increase in Interworking product sales across both divisions, partially
offset by a $2.3 million decrease in legacy product sales. The decrease in sales of traditional products is a result of customers shifting to newer technologies. Many of these newer technologies are integral to our Internetworking product area.

[0001193125-12-334164:mdna:32]
Loop Access product sales decreased $15.6 million and $37.7 million in the three and six months ended June 30, 2012 compared to the
three and six months ended June 30, 2011. The decrease for the three months ended June 30, 2012 is primarily due to a $14.6 million decrease in HDSL product sales. The decrease for the six months ended June 30, 2012 is primarily due
to a $36.6 million decrease in HDSL product sales.

[0001193125-12-334164:mdna:33]
[same as prior period, unchanged from 0001193125-12-220696:mdna:31]

[0001193125-12-334164:mdna:34]
As a percentage of sales, cost of sales increased from 42.0% in the three months ended June 30, 2011 to 48.3% in the three months ended June 30, 2012 and increased from 41.2% in the six months
ended June 30, 2011 to 46.9% in the six months ended June 30, 2012. This increase is primarily attributable to lower gross margins related to the recently acquired NSN BBA business, customer price movements to achieve market share
position and higher warranty costs.

[0001193125-12-334164:mdna:35]
Carrier Networks cost of sales, as a percent of division sales, increased from 41.9% in the three months
ended June 30, 2011 to 48.4% in the three months ended June 30, 2012 and increased from 41.0% in the six months ended June 30, 2011 to 47.2% in the six months ended June 30, 2012. The increase in Carrier Networks cost of
sales as a percentage of sales is primarily attributable to lower gross margins related to the recently acquired NSN BBA business, customer price movements to achieve market share position and higher warranty costs.

[0001193125-12-334164:mdna:36]
Enterprise Networks cost of sales, as a percent of division sales, increased from 42.6% in the three months ended June 30, 2011 to 47.4% in the
three months ended June 30, 2012 and increased from 42.2% in the six months ended June 30, 2011 to 45.7% in the six months ended June 30, 2012. The increase is primarily attributable to lower cost absorption due to the lower
production volumes, customer price movements to achieve market share position, and the impact of cost allocations between divisions.

[0001193125-12-334164:mdna:37]
An
important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing
differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-12-334164:mdna:38]
SELLING, GENERAL AND ADMINISTRATIVE
EXPENSES

[0001193125-12-334164:mdna:39]
Selling, general and administrative expenses increased 16.2% from $30.9 million in the three months ended June 30, 2011
to $35.9 million in the three months ended June 30, 2012 and increased 14.2% from $60.5 million in the six months ended June 30, 2011 to $69.0 million in the six months ended June 30, 2012. The increase in selling, general and
administrative expenses for the three and six month periods ended June 30, 2012 is primarily related to increases in staffing and fringe benefit costs due to increased headcount, including expenses and increased headcount related to the NSN BBA
business acquired on May 4, 2012 and Bluesocket, Inc., which was acquired on August 4, 2011, professional services, legal services and travel expenses. The increases in professional services, legal services and travel expenses were
primarily attributable to the acquired NSN BBA business.

[0001193125-12-334164:mdna:40]
Selling, general and administrative expenses as a percentage of sales increased from
16.8% in the three months ended June 30, 2011 to 19.5% in the three months ended June 30, 2012 and increased from 17.3% in the six months ended June 30, 2011 to 21.7% in the six months ended June 30, 2012. Selling, general and
administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-12-334164:mdna:41]
[same as prior period, unchanged from 0001193125-12-220696:mdna:39]

[0001193125-12-334164:mdna:42]
Research and development expenses increased 31.8% from $24.6 million in the three months ended June 30, 2011 to $32.5 million in the three months ended June 30, 2012 and increased 18.6% from
$48.3 million in the six months ended June 30, 2011 to $57.3 million in the six months ended June 30, 2012. The increase in research and development expenses for the three and six months ended June 30, 2012 is primarily related to
increases in staffing and fringe benefit costs due to increased headcount, including expenses and increased headcount related to the NSN BBA business acquired on May 4, 2012 and Bluesocket, Inc., which was acquired on August 4, 2011, and
amortization of acquired intangible assets related to both acquisitions.

[0001193125-12-334164:mdna:43]
As a percentage of sales, research and development expenses
increased from 13.4% in the three months ended June 30, 2011 to 17.6% in the three months ended June 30, 2012 and increased from 13.8% in the six months ended June 30, 2011 to 18.0% in the six months ended June 30, 2012. Research
and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-12-334164:mdna:44]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international
markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products and product cost reductions. We may incur
significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-12-334164:mdna:45]
INTEREST AND DIVIDEND
INCOME

[0001193125-12-334164:mdna:46]
Interest and dividend income decreased 3.8% from $2.0 million in the three months ended June 30, 2011 to $1.9 million in
the three months ended June 30, 2012 and was flat at $3.8 million for the six months ended June 30, 2011 and June 30, 2012. The decrease for the three months ended June 30, 2012 is primarily driven by a 6.6% reduction in the
average rate of return on our investments as a result of lower interest rates, partially offset by a 13.2% increase in our average investment balances.

[0001193125-12-334164:mdna:47]
[same as prior period, unchanged from 0001193125-12-220696:mdna:45]

[0001193125-12-334164:mdna:48]
Interest expense, which is primarily related to our taxable
revenue bond, remained constant at $0.6 million in each of the three months ended June 30, 2012 and 2011 and $1.2 million in each of the six months ended June 30, 2012 and 2011, respectively. See “Liquidity and Capital Resources”
below for additional information on our revenue bond.

[0001193125-12-334164:mdna:49]
[same as prior period, unchanged from 0001193125-12-220696:mdna:47]

[0001193125-12-334164:mdna:50]
Net realized investment gain decreased 30.1% from $3.4 million in the three months ended June 30, 2011 to $2.4 million in the three months ended
June 30, 2012 and decreased 21.4% from $6.1 million in the six months ended June 30, 2011 to $4.8 million in the six months ended June 30, 2012. The higher amount of realized gains in the period ended June 30, 2011 is primarily
driven by the sales of previously impaired assets in the deferred compensation plans and sales of other equity securities. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-12-334164:mdna:51]
[same as prior period, unchanged from 0001193125-12-220696:mdna:49]

[0001193125-12-334164:mdna:52]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, scrap raw material sales, and gains and
losses on the disposal of property, plant and equipment occurring in the normal course of business, changed from $0.1 million of expense in the three months ended June 30, 2011 to $0.5 million of income in the three months ended June 30,
2012 and changed from $0.2 million of expense in the six months ended June 30, 2011 to $0.6 million of income in the six months ended June 30, 2012.

[0001193125-12-334164:mdna:53]
[same as prior period, unchanged from 0001193125-12-220696:mdna:51]

[0001193125-12-334164:mdna:54]
Our effective tax rate increased from 32.5% in the six months ended
June 30, 2011 to 35.6% in the six months ended June 30, 2012. The tax provision rate in the six months ended June 30, 2012 did not include the benefit of the research tax credit, which expired on December 31, 2011. The
exclusion of this benefit during the six months ended June 30, 2012 resulted in a 2.2 percentage point increase in our effective tax rate. Also, decreased benefits from a lower volume of stock option exercises in the six months ended
June 30, 2012 resulted in a 1.4 percentage point increase in our effective tax rate. Finally, the closure of an audit resulted in a 0.4 percentage point decrease in our effective tax rate for the six months ended June 30, 2012.

[0001193125-12-334164:mdna:55]
During the three months ended June 30, 2012, we acquired the NSN BBA business, which resulted in a
bargain purchase gain reported on the income statement. The bargain purchase gain is presented net of tax in the income statement and a deferred tax liability was established in the opening balance sheet for the acquired entity.

[0001193125-12-334164:mdna:56]
[same as prior period, unchanged from 0001193125-12-220696:mdna:53]

[0001193125-12-334164:mdna:57]
As a result of the
above factors, net income decreased $15.9 million from $36.9 million in the three months ended June 30, 2011 to $21.1 million in the three months ended June 30, 2012 and decreased $37.2 million from $71.2 million in the six months ended
June 30, 2011 to $34.0 million in the six months ended June 30, 2012.

[0001193125-12-334164:mdna:58]
As a percentage of sales, net income decreased from 20.1% in
the three months ended June 30, 2011 to 11.5% in the three months ended June 30, 2012 and decreased from 20.4% in the six months ended June 30, 2011 to 10.7% in the six months ended June 30, 2012.

[0001193125-12-334164:mdna:59]
[same as prior period, unchanged from 0001193125-12-220696:mdna:56]

[0001193125-12-334164:mdna:60]
[same as prior period, unchanged from 0001193125-12-220696:mdna:57]

[0001193125-12-334164:mdna:61]
We intend to finance our
operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, dividend payments, and other general corporate purposes, including
(i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to
be adequate to meet our operating and capital needs for the foreseeable future.

[0001193125-12-334164:mdna:62]
At June 30, 2012, cash on hand was $37.0 million and
short-term investments were $169.4 million, which resulted in available short-term liquidity of $206.4 million. At December 31, 2011, our cash on hand of $43.0 million and short-term investments of $159.3 million resulted in available
short-term liquidity of $202.3 million. The increase in short-term liquidity from December 31, 2011 to June 30, 2012 primarily reflects funds provided by our operating activities, proceeds from stock option exercises and cash received from
NSN as a result of our acquisition of the NSN BBA business, offset by an increase in the purchase of long-term investments, equipment acquisitions and dividends.

[0001193125-12-334164:mdna:63]
[same as prior period, unchanged from 0001193125-12-220696:mdna:60]

[0001193125-12-334164:mdna:64]
Our working capital, which consists of current assets less current
liabilities, increased 3.6% from $329.3 million as of December 31, 2011 to $341.1 million as of June 30, 2012. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current
liabilities, decreased from 4.50 as of December 31, 2011 to 2.87 as of June 30, 2012. The current ratio, defined as current assets divided by current liabilities, decreased from 6.32 as of December 31, 2011 to 4.01 as of June 30,
2012. The increase in our working capital and decreases in the quick ratio and the current ratio are primarily attributable to changes in the underlying assets and liabilities, including deferred revenue balances, relating to the acquired NSN BBA
business.

[0001193125-12-334164:mdna:65]
Net accounts receivable increased 55.7% from $76.1 million at December 31, 2011 to $118.5 million at June 30, 2012. Our
allowance for doubtful accounts was $8 thousand at December 31, 2011 and $5 thousand at June 30, 2012. Quarterly accounts receivable days sales outstanding (DSO) increased from 40 days as of December 31, 2011 to 59 days as of
June 30, 2012. Net accounts receivable and DSO increased for the quarter ended June 30, 2012 due to trade receivables incurred during the months of May and June in the acquired NSN BBA business and the timing of shipments in the organic
business during the quarter. Other receivables decreased from $9.7 million at December 31, 2011 to $8.1 million at June 30, 2012. Generally, the change in other receivables is due to the timing of shipments and payments received for raw
materials supplied to our contract manufacturers.

[0001193125-12-334164:mdna:66]
Quarterly inventory turnover increased from 3.5 turns as of December 31, 2011 to 3.6
turns as of June 30, 2012. Inventory increased 18.2% from December 31, 2011 to June 30, 2012. The increase in inventory is primarily attributable to inventories acquired during the acquisition of the NSN BBA business. We expect
inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business; ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing
technology and customer demand.

[0001193125-12-334164:mdna:67]
Accounts payable increased 59.8% from $29.4 million at December 31, 2011 to $47.0 million at
June 30, 2012. The increase in accounts payable is primarily attributable to accounts payable incurred during the months of May and June in the acquired NSN BBA business. Additionally, accounts payable will fluctuate due to variations in the
timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-12-334164:mdna:68]
[same as prior period, unchanged from 0001193125-12-220696:mdna:65]

[0001193125-12-334164:mdna:69]
Capital expenditures totaled approximately $7.8 million and $6.3 million for the six months ended June 30, 2012 and 2011,
respectively. These expenditures were primarily used to purchase manufacturing and test equipment and computer software and hardware.

[0001193125-12-334164:mdna:70]
On
May 4, 2012, we acquired the NSN BBA business. This acquisition provides us with an established customer base in key markets and complementary, market-focused products and was accounted for as a business combination. We received a cash payment
of $7.5 million from NSN and recorded a bargain purchase gain of $1.8 million, net of income taxes, subject to customary working capital adjustments between the parties.

[0001193125-12-334164:mdna:71]
Our combined short-term and long-term investments increased $26.5 million from $491.4 million at December 31, 2011 to $517.9 million at June 30, 2012. This increase reflects the impact of
additional funds available for investment provided by our operating activities and stock option exercises by our employees, reduced by our cash needs for equipment acquisitions and dividends, as well as net realized and unrealized losses and
amortization of net premiums on our combined investments.

[0001193125-12-334164:mdna:72]
We invest all available cash not required for immediate use in operations primarily
in securities that we believe bear minimal risk of loss. At June 30, 2012 these investments included municipal variable rate demand notes of $46.8 million, municipal fixed-rate bonds of $189.5 million and corporate bonds of $183.7 million. At
December 31, 2011, these investments included municipal variable rate demand notes of $69.7 million, municipal fixed-rate bonds of $174.8 million and corporate bonds of $156.8 million. As of June 30, 2012, our corporate bonds, municipal
fixed-rate bonds, and municipal variable rate demand notes were classified as available-for-sale and had a combined duration of 0.97 years with an average credit rating of AA-. Because our bond portfolio has a high quality rating and contractual
maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-12-334164:mdna:73]
Our long-term investments increased 4.9% from $332.0 million at December 31, 2011 to $348.4 million at June 30, 2012. The primary reason for the increase in our long-term investments during 2012
was cash generated from operations. Long-term investments at June 30, 2012 and December 31, 2011 included an investment in a certificate of deposit of $48.3 million, which serves as collateral for our revenue bonds, as discussed below. We
have various equity investments included in long-term investments at a cost of $18.1 million and $12.8 million, and with a fair value of $35.9 million and $31.3 million, at June 30, 2012 and December 31, 2011, respectively.

[0001193125-12-334164:mdna:74]
Long-term investments at June 30, 2012 also include $10.8 million related to our deferred compensation plans; $2.1 million of other investments
carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer; and $0.8 million of a fixed income bond fund.

[0001193125-12-334164:mdna:75]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements
made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive
months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $33 thousand during
the six months ended June 30, 2012 related to eight marketable equity securities. For the six months ended June 30, 2011, we recorded an other-than-temporary impairment charge of $12 thousand related to three marketable equity securities.

[0001193125-12-334164:mdna:76]
[same as prior period, unchanged from 0001193125-12-220696:mdna:72]

[0001193125-12-334164:mdna:77]
[same as prior period, unchanged from 0001193125-12-220696:mdna:73]

[0001193125-12-334164:mdna:78]
In July 2003, our Board of Directors elected to begin declaring quarterly
dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the six months ended June 30, 2012, we paid dividends totaling $11.5 million.

[0001193125-12-334164:mdna:79]
[same as prior period, unchanged from 0001193125-12-220696:mdna:75]

[0001193125-12-334164:mdna:80]
We have amounts outstanding
under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $47.0 million at June 30, 2012 and December 31, 2011. At June 30, 2012, the estimated fair value of
the Bond was approximately $48.4 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of A+. Included in long-term investments are restricted funds in the amount
of $48.3 million at June 30, 2012 and December 31, 2011, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the
balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 5% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that
reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program.

[0001193125-12-334164:mdna:81]
We are required to make payments in the amounts necessary to pay the principal and interest on the amounts currently outstanding. Based on positive
cash flow from operating activities, we have decided to continue early partial redemptions of the Bond. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $0.5
million of the Bond debt has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at June 30, 2012.

[0001193125-12-334164:mdna:82]
[same as prior period, unchanged from 0001193125-12-220696:mdna:78]

[0001193125-12-334164:mdna:83]
Since 1997,
our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 35 million shares of our common stock. During the six months ended June 30, 2012, we repurchased
0.5 million shares of our common stock at an average price of $29.51 per share. We have the authority to purchase an additional 5.4 million shares of our common stock under plans approved by the Board of Directors on April 14, 2008
and October 11, 2011.

[0001193125-12-334164:mdna:84]
[same as prior period, unchanged from 0001193125-12-220696:mdna:80]

[0001193125-12-334164:mdna:85]
To accommodate employee stock option exercises, we issued 0.2 million shares of treasury stock for $4.3 million during the six months ended June 30, 2012. During the six months ended
June 30, 2011, we issued 1.7 million shares of treasury stock for $33.0 million.

[0001193125-12-334164:mdna:86]
Off-Balance Sheet Arrangements and Contractual
Obligations

[0001193125-12-334164:mdna:87]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements
with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the six months ended June 30, 2012, there have been no material changes
in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2011 filed on February 29, 2012 with the SEC.

[0001193125-12-334164:mdna:88]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30,
2012, of which $7.7 million has been applied to these commitments.

[0001193125-12-334164:mdna:89]
[same as prior period, unchanged from 0001193125-12-220696:mdna:85]

[0001193125-12-334164:mdna:90]
The following are some of the risks that could affect our financial performance or could cause actual results to differ materially from those expressed
or implied in our forward-looking statements:

[0001193125-12-334164:mdna:91]
[same as prior period, unchanged from 0001193125-12-220696:mdna:87]

[0001193125-12-334164:mdna:92]
[same as prior period, unchanged from 0001193125-12-220696:mdna:88]

[0001193125-12-334164:mdna:93]
|  | • |  | The failure to complete the integration of the NSN BBA business as soon as we expect or the failure to realize benefits from this acquisition as significant as we expect may affect our future results of operations and financial condition, and could affect our stock price. |

[0001193125-12-334164:mdna:94]
[same as prior period, unchanged from 0001193125-12-220696:mdna:90]

[0001193125-12-334164:mdna:95]
[same as prior period, unchanged from 0001193125-12-220696:mdna:91]

[0001193125-12-334164:mdna:96]
[same as prior period, unchanged from 0001193125-12-220696:mdna:92]

[0001193125-12-334164:mdna:97]
[same as prior period, unchanged from 0001193125-12-220696:mdna:93]

[0001193125-12-334164:mdna:98]
[same as prior period, unchanged from 0001193125-12-220696:mdna:94]

[0001193125-12-334164:mdna:99]
[same as prior period, unchanged from 0001193125-12-220696:mdna:95]

[0001193125-12-334164:mdna:100]
[same as prior period, unchanged from 0001193125-12-220696:mdna:96]

[0001193125-12-334164:mdna:101]
[same as prior period, unchanged from 0001193125-12-220696:mdna:97]

[0001193125-12-334164:mdna:102]
[same as prior period, unchanged from 0001193125-12-220696:mdna:98]

[0001193125-12-334164:mdna:103]
[same as prior period, unchanged from 0001193125-12-220696:mdna:99]

[0001193125-12-334164:mdna:104]
[same as prior period, unchanged from 0001193125-12-220696:mdna:100]

[0001193125-12-334164:mdna:105]
[same as prior period, unchanged from 0001193125-12-220696:mdna:101]

[0001193125-12-334164:mdna:106]
[same as prior period, unchanged from 0001193125-12-220696:mdna:102]

[0001193125-12-334164:mdna:107]
[same as prior period, unchanged from 0001193125-12-220696:mdna:103]

[0001193125-12-334164:mdna:108]
[same as prior period, unchanged from 0001193125-12-220696:mdna:104]

[0001193125-12-334164:mdna:109]
[same as prior period, unchanged from 0001193125-12-220696:mdna:105]

[0001193125-12-334164:mdna:110]
[same as prior period, unchanged from 0001193125-12-220696:mdna:106]

[0001193125-12-334164:mdna:111]
[same as prior period, unchanged from 0001193125-12-220696:mdna:107]

[0001193125-12-334164:mdna:112]
[same as prior period, unchanged from 0001193125-12-220696:mdna:108]

[0001193125-12-334164:mdna:113]
[same as prior period, unchanged from 0001193125-12-220696:mdna:109]

[0001193125-12-334164:mdna:114]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-12-334164:mdna:115]
[same as prior period, unchanged from 0001193125-12-220696:mdna:111]

[0001193125-12-334164:mdna:116]
[same as prior period, unchanged from 0001193125-12-220696:mdna:112]

[0001193125-12-334164:mdna:117]
32

[0001193125-12-334164:mdna:118]
| • |  | If we are unable to successfully develop relationships with system integrators, service providers, and enterprise value added resellers, our sales may be negatively affected. |

[0001193125-12-334164:mdna:119]
| • |  | If we fail to manage our exposure to worldwide financial and securities markets successfully, our operating results and financial statements could be materially impacted. |

[0001193125-12-334164:mdna:120]
| • |  | Changes in our effective tax rate or assessments arising from tax audits may have an adverse impact on our results. |

[0001193125-12-334164:mdna:121]
| • |  | We are required to periodically evaluate the value of our long-lived assets, including the value of intangibles acquired and goodwill resulting from business combinations. Any future impairment charges required may adversely affect our operating results. |

[0001193125-12-334164:mdna:122]
| • |  | Our success depends on attracting and retaining key personnel. |

[0001193125-12-334164:mdna:123]
| • |  | Regulatory and potential physical impacts of climate change and other natural events may affect our customers and our production operations, resulting in adverse effects on our operating results. |

[0001193125-12-334164:mdna:124]
| • |  | While we believe our internal control over financial reporting is adequate, a failure to maintain effective internal control over financial reporting as our business expands could result in a loss of investor confidence in our financial reports and have an adverse effect on our stock price. |

[0001193125-12-334164:mdna:125]
| • |  | The price of our common stock has been volatile and may continue to fluctuate significantly. |

[0001193125-12-334164:mdna:126]
[same as prior period, unchanged from 0001193125-12-220696:mdna:122]
