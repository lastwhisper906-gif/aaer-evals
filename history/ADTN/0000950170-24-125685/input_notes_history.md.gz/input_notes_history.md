# ADTN note change history — 0000950170-24-094602 → 0000950170-24-125685


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-12):
[0000950170-24-125685:note_history:1]
18. COMMITMENTS AND CONTINGENCIES
  (was, 2024-08-09, similarity 0.8158):
[0000950170-24-094602:note_history:1]
18. COMMITMENTS AND CONTINGENCIES 
Legal Matters

- added (2024-11-12):
[0000950170-24-125685:note_history:2]
Legal Matters

- changed (2024-11-12):
[0000950170-24-125685:note_history:3]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.37% as of September 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.9 million or approximately $364.1 million, based on an exchange rate as of September 30, 2024, and reflecting interest accrued through September 30, 2024, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).
  (was, 2024-08-09, similarity 0.9885):
[0000950170-24-094602:note_history:3]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of June 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €345.6 million or approximately $371.3 million, based on an exchange rate as of June 30, 2024, and reflecting interest accrued through June 30, 2024, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- added (2024-11-12):
[0000950170-24-125685:note_history:4]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million (or $10.0 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three months ended September 30, 2024 and 2023, we accrued $2.4 million and $2.6 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2024 and 2023, we accrued $7.4 million and $7.6 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

- added (2024-11-12):
[0000950170-24-125685:note_history:5]
For the three and nine months ended September 30, 2024, approximately 830 thousand shares and 831 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on an exchange rate as of September 30, 2024, being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, being paid to Adtran Networks shareholders.

- changed (2024-11-12):
[0000950170-24-125685:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2024, and December 31, 2023, we had commitments related to these bonds totaling $14.6 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2024-08-09, similarity 0.9874):
[0000950170-24-094602:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2024, and December 31, 2023, we had commitments related to these bonds totaling $13.9 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2024-11-12):
[0000950170-24-125685:note_history:7]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2024, purchase obligations totaled $261.8 million.
  (was, 2024-08-09, similarity 0.9784):
[0000950170-24-094602:note_history:7]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for short-term product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of June 30, 2024, purchase obligations totaled $280.9 million.

- removed (2024-11-12):
[0000950170-24-094602:note_history:8]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.4 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three and six months ended June 30, 2024, and 2023, we accrued $2.9 million and $5.7 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

- removed (2024-11-12):
[0000950170-24-094602:note_history:9]
For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or approximately $20 thousand and $25 thousand, respectively, based on an exchange rate as of June 30, 2024, were paid to Adtran Networks shareholders. For the three and six months ended June 30, 2023, approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €0.8 thousand and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-11-12):
[0000950170-24-125685:note_history:10]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.
  (was, 2024-08-09, similarity 0.9647):
[0000950170-24-094602:note_history:10]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

- changed (2024-11-12):
[0000950170-24-125685:note_history:11]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks SE (“Adtran Networks”). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer, especially upon the convergence of solutions at the network edge.
  (was, 2024-08-09, similarity 0.9281):
[0000950170-24-094602:note_history:11]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks SE (formerly ADVA Optical Networking SE). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer and in particular upon the convergence of solutions at the network edge.

- changed (2024-11-12):
[0000950170-24-125685:note_history:12]
The DPLTA between the Company, as the controlling company, and Adtran Networks, as the controlled company, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).
  (was, 2024-08-09, similarity 0.9563):
[0000950170-24-094602:note_history:12]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE ("Adtran Networks"), as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

- changed (2024-11-12):
[0000950170-24-125685:note_history:13]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated by Adtran Networks in 2023.
  (was, 2024-08-09, similarity 0.7984):
[0000950170-24-094602:note_history:13]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally

- changed (2024-11-12):
[0000950170-24-125685:note_history:14]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.37% as of September 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.9 million or approximately $364.1 million, based on an exchange rate as of September 30, 2024, and reflecting interest accrued through September 30, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).
  (was, 2024-08-09, similarity 0.9885):
[0000950170-24-094602:note_history:14]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of June 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €345.6 million or approximately $371.3 million, based on an exchange rate as of June 30, 2024, and reflecting interest accrued through June 30, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- added (2024-11-12):
[0000950170-24-125685:note_history:15]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million (or $10.0 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders as of September 30, 2024 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three months ended September 30, 2024 and 2023, we accrued $2.4 million and $2.6 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2024 and 2023, we accrued $7.4 million and $7.6 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.

- added (2024-11-12):
[0000950170-24-125685:note_history:16]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and nine months ended September 30, 2024, approximately 830 thousand shares and 831 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on an exchange rate as of September 30, 2024, being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, being paid to Adtran Networks shareholders.

- added (2024-11-12):
[0000950170-24-125685:note_history:17]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. The Company had access to $205.6 million on its Credit Facility for future borrowings; however, as of September 30, 2024, the Company was limited to additional borrowings of $24.1 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x.  See Note 11, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

- added (2024-11-12):
[0000950170-24-125685:note_history:18]
As of September 30, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. While the Company did experience $17.4 million of redemptions in Q3 2024, we believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the diverse base of shareholders that must make this election on an individual shareholder basis, (ii) the fact that the Company expects to receive a procedural decision on a matter of law related to the current ongoing appraisal proceedings involving a dispute over the value of the Exit Compensation in 2024 or early 2025, after which the appeal process should take an additional 24-32 months to resolve, (iii) the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and (iv) the current trading value of Adtran Networks shares.

- added (2024-11-12):
[0000950170-24-125685:note_history:19]
The Company experienced revenue declines in the year ended December 31, 2023, and during the three and nine months ended September 30, 2024. To the extent the Company does not experience anticipated revenue growth, the Company will implement plans to preserve cash liquidity and maintain compliance with the Company’s net leverage covenants. The Company has suspended dividend payments and has implemented a business efficiency program, which includes, but is not limited to ongoing reductions in operating expenses and a site consolidation plan. In connection with the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditure and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our net leverage debt covenants.

- added (2024-11-12):
[0000950170-24-125685:note_history:20]
Revision of Previously Issued Condensed Consolidated Financial Statements

- added (2024-11-12):
[0000950170-24-125685:note_history:21]
Following the third quarter of 2024, the Company identified errors primarily impacting the carrying values of the redeemable non-controlling interest, retained deficit, the net income attributable to the non-controlling interest and the net loss attributable to the Company and, as a consequence, of the loss per common share attributable to the Company. The Company has evaluated the errors and determined that the related impacts were not material to the previously issued consolidated financial statements for any prior period. A summary of the corrections to the Company's Condensed Consolidated Financial Statements for the periods ended March 31, 2023, June 30, 2023, September 30, 2023, December 31, 2023, March 31, 2024 and June 30, 2024, are as follows:

- added (2024-11-12):
[0000950170-24-125685:note_history:22]
(a)
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) is entitled to receive from us an Annual Recurring Compensation payment of €0.52 per share. The Company erroneously accrued this liability every quarter at €0.59 per share, overstating the associated accrual, the net income attributable to non-controlling interest and the net loss attributable to ADTRAN Holdings, Inc. for fiscal periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024.

- added (2024-11-12):
[0000950170-24-125685:note_history:23]
(b)
For the periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024 the Company remeasured the redeemable non-controlling interest each quarter-end at the current exchange rate of Euros to U.S. Dollar. The Company treated the redeemable non-controlling interest as a monetary mezzanine equity instrument but should have treated it as a non-monetary mezzanine equity instrument not subject to remeasurement.

- added (2024-11-12):
[0000950170-24-125685:note_history:24]
We have revised our previously issued Condensed Consolidated Financial Statements for the periods ended March 31, 2023, June 30, 2023, September 30, 2023, December 31, 2023, March 31, 2024 and June 30, 2024. Additionally, the Company will revise its previously issued 2023 interim financial statements and 2023 annual financial statements in connection with the future filings of the Form 10-K for the year ended December 31, 2024, and interim reporting on Form 10-Q for the periods ended March 31, 2025 and June 30, 2025.

- added (2024-11-12):
[0000950170-24-125685:note_history:25]
The following tables reflect the impact of the revision to the specific line items presented in the Company's previously reported Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Loss, and Condensed Consolidated Statements of Comprehensive Loss for the for fiscal periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024.

- added (2024-11-12):
[0000950170-24-125685:note_history:26]
|  |  |  | March 31, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Other non-current liabilities |  |  | $ | 15,986 |  |  | $ | (346 | ) | (a) | $ | 15,640 |  |
| Total Liabilities |  |  | $ | 675,765 |  |  | $ | (346 | ) |  | $ | 675,419 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 442,668 |  |  | $ | (430 | ) | (b) | $ | 442,238 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 34,526 |  |  | $ | 1 |  | (a) | $ | 34,527 |  |
| Retained Earnings |  |  | $ | 8,006 |  |  | $ | 775 |  | (a)(b) | $ | 8,781 |  |
| Total Equity |  |  | $ | 820,162 |  |  | $ | 776 |  |  | $ | 820,938 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,938,595 |  |  | $ | — |  |  | $ | 1,938,595 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:27]
|  |  |  | For the Three Months Ended March 31, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Loss attributable to non-controlling interest |  |  | $ | (370 | ) |  | $ | (345 | ) | (a) | $ | (715 | ) |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (40,083 | ) |  | $ | 345 |  | (a) | $ | (39,738 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (0.51 | ) |  | $ | — |  |  | $ | (0.51 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (0.51 | ) |  | $ | — |  |  | $ | (0.51 | ) |
| Foreign currency translation gain |  |  | $ | 8,678 |  |  | $ | 1 |  | (a) | $ | 8,679 |  |
| Other Comprehensive Income, net of tax |  |  | $ | 8,782 |  |  | $ | 1 |  |  | $ | 8,783 |  |
| Comprehensive Loss, net of tax |  |  | $ | (31,671 | ) |  | $ | 1 |  |  | $ | (31,670 | ) |
| Less: Comprehensive Income (Loss) attributable to non-controlling interest, net of tax |  |  | $ | 12 |  |  | $ | (345 | ) | (a) | $ | (333 | ) |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (31,683 | ) |  | $ | 346 |  | (a) | $ | (31,337 | ) |

- added (2024-11-12):
[0000950170-24-125685:note_history:28]
|  |  |  | June 30, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Other non-current liabilities |  |  | $ | 16,401 |  |  | $ | (695 | ) | (a) | $ | 15,706 |  |
| Total Liabilities |  |  | $ | 665,006 |  |  | $ | (695 | ) |  | $ | 664,311 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 445,462 |  |  | $ | (3,244 | ) | (b) | $ | 442,218 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 41,483 |  |  | $ | 2 |  | (a) | $ | 41,485 |  |
| Retained Deficit |  |  | $ | (41,010 | ) |  | $ | 3,937 |  | (a)(b) | $ | (37,073 | ) |
| Total Equity |  |  | $ | 782,470 |  |  | $ | 3,939 |  |  | $ | 786,409 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,882,938 |  |  | $ | — |  |  | $ | 1,882,938 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:29]
|  |  |  | For the Three Months Ended June 30, 2023 |  |  | For the Six Months Ended June 30, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 2,882 |  |  | $ | (348 | ) | (a) | $ | 2,534 |  |  | $ | 2,512 |  |  | $ | (693 | ) | (a) | $ | 1,819 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (39,097 | ) |  | $ | 348 |  | (a) | $ | (38,749 | ) |  | $ | (79,180 | ) |  | $ | 693 |  | (a) | $ | (78,487 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (0.50 | ) |  | $ | — |  |  | $ | (0.50 | ) |  | $ | (1.01 | ) |  | $ | 0.01 |  | (a) | $ | (1.00 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (0.50 | ) |  | $ | — |  |  | $ | (0.50 | ) |  | $ | (1.01 | ) |  | $ | 0.01 |  | (a) | $ | (1.00 | ) |
| Foreign currency translation gain |  |  | $ | 6,940 |  |  | $ | 1 |  | (a) | $ | 6,941 |  |  | $ | 15,618 |  |  | $ | 2 |  | (a) | $ | 15,620 |  |
| Other Comprehensive Income, net of tax |  |  | $ | 6,957 |  |  | $ | 1 |  |  | $ | 6,958 |  |  | $ | 15,739 |  |  | $ | 2 |  |  | $ | 15,741 |  |
| Comprehensive Loss, net of tax |  |  | $ | (29,258 | ) |  | $ | 1 |  |  | $ | (29,257 | ) |  | $ | (60,929 | ) |  | $ | 2 |  |  | $ | (60,927 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 2,882 |  |  | $ | (348 | ) | (a) | $ | 2,534 |  |  | $ | 2,894 |  |  | $ | (693 | ) | (a) | $ | 2,201 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (32,140 | ) |  | $ | 349 |  | (a) | $ | (31,791 | ) |  | $ | (63,823 | ) |  | $ | 695 |  | (a) | $ | (63,128 | ) |

- added (2024-11-12):
[0000950170-24-125685:note_history:30]
|  |  |  | September 30, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Other non-current liabilities |  |  | $ | 17,408 |  |  | $ | (1,049 | ) | (a) | $ | 16,359 |  |
| Total Liabilities |  |  | $ | 625,355 |  |  | $ | (1,049 | ) |  | $ | 624,306 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 431,921 |  |  | $ | 10,291 |  | (b) | $ | 442,212 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 12,075 |  |  | $ | 3 |  | (a) | $ | 12,078 |  |
| Retained Deficit |  |  | $ | (113,289 | ) |  | $ | (9,245 | ) | (a)(b) | $ | (122,534 | ) |
| Total Equity |  |  | $ | 684,893 |  |  | $ | (9,242 | ) |  | $ | 675,651 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,742,169 |  |  | $ | — |  |  | $ | 1,742,169 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:31]
|  |  |  | For the Three Months Ended September 30, 2023 |  |  | For the Nine Months Ended September 30, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 2,914 |  |  | $ | (353 | ) | (a) | $ | 2,561 |  |  | $ | 5,426 |  |  | $ | (1,046 | ) | (a) | $ | 4,380 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (78,563 | ) |  | $ | 353 |  | (a) | $ | (78,210 | ) |  | $ | (157,743 | ) |  | $ | 1,046 |  | (a) | $ | (156,697 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (1.00 | ) |  | $ | — |  |  | $ | (1.00 | ) |  | $ | (2.01 | ) |  | $ | 0.01 |  | (a) | $ | (2.00 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (1.00 | ) |  | $ | — |  |  | $ | (1.00 | ) |  | $ | (2.01 | ) |  | $ | 0.01 |  | (a) | $ | (2.00 | ) |
| Foreign currency translation loss |  |  | $ | (29,716 | ) |  | $ | 1 |  | (a) | $ | (29,715 | ) |  | $ | (14,098 | ) |  | $ | 3 |  | (a) | $ | (14,095 | ) |
| Other Comprehensive Loss, net of tax |  |  | $ | (29,408 | ) |  | $ | 1 |  |  | $ | (29,407 | ) |  | $ | (13,669 | ) |  | $ | 3 |  |  | $ | (13,666 | ) |
| Comprehensive Loss, net of tax |  |  | $ | (105,057 | ) |  | $ | 1 |  |  | $ | (105,056 | ) |  | $ | (165,986 | ) |  | $ | 3 |  |  | $ | (165,983 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 2,914 |  |  | $ | (353 | ) | (a) | $ | 2,561 |  |  | $ | 5,808 |  |  | $ | (1,046 | ) | (a) | $ | 4,762 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (107,971 | ) |  | $ | 354 |  | (a) | $ | (107,617 | ) |  | $ | (171,794 | ) |  | $ | 1,049 |  | (a) | $ | (170,745 | ) |

- added (2024-11-12):
[0000950170-24-125685:note_history:32]
|  |  |  | March 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Accrued Expenses and Other Liabilities |  |  | $ | 36,404 |  |  | $ | (1,403 | ) | (a) | $ | 35,001 |  |
| Total Current Liabilities |  |  | $ | 282,746 |  |  | $ | (1,403 | ) |  | $ | 281,343 |  |
| Other non-current liabilities |  |  | $ | 35,375 |  |  | $ | (350 | ) | (a) | $ | 35,025 |  |
| Total Liabilities |  |  | $ | 620,488 |  |  | $ | (1,753 | ) |  | $ | 618,735 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 441,635 |  |  | $ | 511 |  | (b) | $ | 442,146 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 29,656 |  |  | $ | 5 |  | (a) | $ | 29,661 |  |
| Retained Deficit |  |  | $ | (558,363 | ) |  | $ | 1,237 |  | (a)(b) | $ | (557,126 | ) |
| Total Equity |  |  | $ | 265,783 |  |  | $ | 1,242 |  |  | $ | 267,025 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,327,906 |  |  | $ | — |  |  | $ | 1,327,906 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:33]
|  |  |  | For the Three Months Ended March 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 2,880 |  |  | $ | (349 | ) | (a) | $ | 2,531 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (324,550 | ) |  | $ | 349 |  | (a) | $ | (324,201 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (4.12 | ) |  | $ | — |  |  | $ | (4.12 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (4.12 | ) |  | $ | — |  |  | $ | (4.12 | ) |
| Foreign currency translation loss |  |  | $ | (17,745 | ) |  | $ | 1 |  | (a) | $ | (17,744 | ) |
| Other Comprehensive Loss, net of tax |  |  | $ | (17,805 | ) |  | $ | 1 |  |  | $ | (17,804 | ) |
| Comprehensive Loss, net of tax |  |  | $ | (339,475 | ) |  | $ | 1 |  |  | $ | (339,474 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 2,880 |  |  | $ | (349 | ) | (a) | $ | 2,531 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (342,355 | ) |  | $ | 350 |  | (a) | $ | (342,005 | ) |

- added (2024-11-12):
[0000950170-24-125685:note_history:34]
|  |  |  | June 30, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Accrued Expenses and Other Liabilities |  |  | $ | 36,307 |  |  | $ | (1,403 | ) | (a) | $ | 34,904 |  |
| Total Current Liabilities |  |  | $ | 289,712 |  |  | $ | (1,403 | ) |  | $ | 288,309 |  |
| Other non-current liabilities |  |  | $ | 34,445 |  |  | $ | (701 | ) | (a) | $ | 33,744 |  |
| Total Liabilities |  |  | $ | 630,810 |  |  | $ | (2,104 | ) |  | $ | 628,706 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 439,743 |  |  | $ | 2,379 |  | (b) | $ | 442,122 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 28,274 |  |  | $ | 6 |  | (a) | $ | 28,280 |  |
| Retained Deficit |  |  | $ | (606,375 | ) |  | $ | (281 | ) | (a)(b) | $ | (606,656 | ) |
| Total Equity |  |  | $ | 220,229 |  |  | $ | (275 | ) |  | $ | 219,954 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,290,782 |  |  | $ | — |  |  | $ | 1,290,782 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:35]
|  |  |  | For the Three Months Ended June 30, 2024 |  |  | For the Six Months Ended June 30, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 2,854 |  |  | $ | (350 | ) | (a) | $ | 2,504 |  |  | $ | 5,734 |  |  | $ | (699 | ) | (a) | $ | 5,035 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (49,865 | ) |  | $ | 350 |  | (a) | $ | (49,515 | ) |  | $ | (374,415 | ) |  | $ | 699 |  | (a) | $ | (373,716 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (0.63 | ) |  | $ | — |  |  | $ | (0.63 | ) |  | $ | (4.75 | ) |  | $ | 0.01 |  | (a) | $ | (4.74 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (0.63 | ) |  | $ | — |  |  | $ | (0.63 | ) |  | $ | (4.75 | ) |  | $ | 0.01 |  | (a) | $ | (4.74 | ) |
| Foreign currency translation loss |  |  | $ | (1,375 | ) |  | $ | 1 |  | (a) | $ | (1,374 | ) |  | $ | (19,120 | ) |  | $ | 2 |  | (a) | $ | (19,118 | ) |
| Other Comprehensive Loss, net of tax |  |  | $ | (1,382 | ) |  | $ | 1 |  |  | $ | (1,381 | ) |  | $ | (19,187 | ) |  | $ | 2 |  |  | $ | (19,185 | ) |
| Comprehensive Loss, net of tax |  |  | $ | (48,393 | ) |  | $ | 1 |  |  | $ | (48,392 | ) |  | $ | (387,868 | ) |  | $ | 2 |  |  | $ | (387,866 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 2,854 |  |  | $ | (350 | ) | (a) | $ | 2,504 |  |  | $ | 5,734 |  |  | $ | (699 | ) | (a) | $ | 5,035 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (51,247 | ) |  | $ | 351 |  | (a) | $ | (50,896 | ) |  | $ | (393,602 | ) |  | $ | 701 |  | (a) | $ | (392,901 | ) |

- added (2024-11-12):
[0000950170-24-125685:note_history:36]
The following tables reflect the impact of the revisions to the specific line items presented in the Company’s previously reported Consolidated Balance Sheet as of December 31, 2023, the Consolidated Statement of Loss and the Consolidated Statement of Comprehensive Loss for the year ended December 31, 2023.

- added (2024-11-12):
[0000950170-24-125685:note_history:37]
|  |  |  | December 31, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Accrued Expenses and Other Liabilities |  |  | $ | 37,607 |  |  | $ | (1,403 | ) | (a) | $ | 36,204 |  |
| Total Current Liabilities |  |  | $ | 279,511 |  |  | $ | (1,403 | ) |  | $ | 278,108 |  |
| Total Liabilities |  |  | $ | 636,934 |  |  | $ | (1,403 | ) |  | $ | 635,531 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 451,756 |  |  | $ | (9,604 | ) | (b) | $ | 442,152 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 47,461 |  |  | $ | 4 |  | (a) | $ | 47,465 |  |
| Retained Deficit |  |  | $ | (243,908 | ) |  | $ | 11,003 |  | (a)(b) | $ | (232,905 | ) |
| Total Equity |  |  | $ | 593,822 |  |  | $ | 11,007 |  |  | $ | 604,829 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,682,512 |  |  | $ | — |  |  | $ | 1,682,512 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:38]
|  |  |  | For the Year Ended December 31, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 8,345 |  |  | $ | (1,399 | ) | (a) | $ | 6,946 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (267,688 | ) |  | $ | 1,399 |  | (a) | $ | (266,289 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (3.41 | ) |  | $ | 0.02 |  | (a) | $ | (3.39 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (3.41 | ) |  | $ | 0.02 |  | (a) | $ | (3.39 | ) |
| Foreign currency translation gain |  |  | $ | 22,753 |  |  | $ | 4 |  | (a) | $ | 22,757 |  |
| Other Comprehensive Income, net of tax |  |  | $ | 21,717 |  |  | $ | 4 |  |  | $ | 21,721 |  |
| Comprehensive Loss, net of tax |  |  | $ | (237,626 | ) |  | $ | 4 |  |  | $ | (237,622 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 8,727 |  |  | $ | (1,399 | ) | (a) | $ | 7,328 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (246,353 | ) |  | $ | 1,403 |  | (a) | $ | (244,950 | ) |

- added (2024-11-12):
[0000950170-24-125685:note_history:39]
The following tables reflect the impact of the revision to the specific line items presented in the Company's previously reported Condensed Consolidated Statements of Changes in Stockholders Equity as of September 30, 2023 and 2024:

- added (2024-11-12):
[0000950170-24-125685:note_history:40]
|  |  |  | Retained Earnings (Deficit) |  |  | Accumulated Other Comprehensive Income |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Annual recurring compensation earned |  |  | $ | (2,809 | ) |  | $ | 345 |  | (a) | $ | (2,464 | ) |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Other comprehensive income, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 8,400 |  |  | $ | 1 |  | (a) | $ | 8,401 |  |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | (430 | ) |  | $ | 430 |  | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of March 31, 2023 |  |  | $ | 8,006 |  |  | $ | 775 |  |  | $ | 8,781 |  |  | $ | 34,526 |  |  | $ | 1 |  |  | $ | 34,527 |  |
| Annual recurring compensation earned |  |  | $ | (2,882 | ) |  | $ | 348 |  | (a) | $ | (2,534 | ) |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Other comprehensive income, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 6,957 |  |  | $ | 1 |  | (a) | $ | 6,958 |  |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | (2,814 | ) |  | $ | 2,814 |  | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of June 30, 2023 |  |  | $ | (41,010 | ) |  | $ | 3,937 |  |  | $ | (37,073 | ) |  | $ | 41,483 |  |  | $ | 2 |  |  | $ | 41,485 |  |
| Annual recurring compensation earned |  |  | $ | (2,914 | ) |  | $ | 353 |  | (a) | $ | (2,561 | ) |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Other comprehensive loss, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | (29,408 | ) |  | $ | 1 |  | (a) | $ | (29,407 | ) |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | 13,535 |  |  | $ | (13,535 | ) | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of September 30, 2023 |  |  | $ | (113,289 | ) |  | $ | (9,245 | ) |  | $ | (122,534 | ) |  | $ | 12,075 |  |  | $ | 3 |  |  | $ | 12,078 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:41]
|  |  |  | Retained Deficit |  |  | Accumulated Other Comprehensive Income |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Balance as of December 31, 2023 |  |  | $ | (243,908 | ) |  | $ | 11,003 |  | (a) | $ | (232,905 | ) |  | $ | 47,461 |  |  | $ | 4 |  | (a) | $ | 47,465 |  |
| Annual recurring compensation earned |  |  | $ | (2,880 | ) |  | $ | 349 |  | (a) | $ | (2,531 | ) |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Other comprehensive loss, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | (17,805 | ) |  | $ | 1 |  | (a) | $ | (17,804 | ) |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | 10,115 |  |  | $ | (10,115 | ) | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of March 31, 2024 |  |  | $ | (558,363 | ) |  | $ | 1,237 |  |  | $ | (557,126 | ) |  | $ | 29,656 |  |  | $ | 5 |  |  | $ | 29,661 |  |
| Annual recurring compensation earned |  |  | $ | (2,854 | ) |  | $ | 350 |  | (a) | $ | (2,504 | ) |  | $ | - |  |  |  |  |  | $ | - |  |
| Other comprehensive loss, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | (1,382 | ) |  | $ | 1 |  | (a) | $ | (1,381 | ) |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | 1,868 |  |  | $ | (1,868 | ) | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of June 30, 2024 |  |  | $ | (606,375 | ) |  | $ | (281 | ) |  | $ | (606,656 | ) |  | $ | 28,274 |  |  | $ | 6 |  |  | $ | 28,280 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:42]
The following tables reflect the impact of the revision to the specific line items presented in the Company's previously reported Consolidated Statement of Changes in Stockholders as of December 31, 2023:

- added (2024-11-12):
[0000950170-24-125685:note_history:43]
|  |  |  | Retained Earnings (Deficit) |  |  | Accumulated Other Comprehensive Income |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Annual recurring compensation earned |  |  | $ | (11,524 | ) |  | $ | 1,399 |  | (a) | $ | (10,125 | ) |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Other comprehensive income, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 21,335 |  |  | $ | 4 |  | (a) | $ | 21,339 |  |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | (9,604 | ) |  | $ | 9,604 |  | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of December 31, 2023 |  |  | $ | (243,908 | ) |  | $ | 11,003 |  |  | $ | (232,905 | ) |  | $ | 47,461 |  |  | $ | 4 |  |  | $ | 47,465 |  |

- changed (2024-11-12):
[0000950170-24-125685:note_history:44]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenue and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.
  (was, 2024-08-09, similarity 0.9996):
[0000950170-24-094602:note_history:44]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

- changed (2024-11-12):
[0000950170-24-125685:note_history:45]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions as of September 30, 2024, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.
  (was, 2024-08-09, similarity 0.9923):
[0000950170-24-094602:note_history:45]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions as of June 30, 2024, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.

- changed (2024-11-12):
[0000950170-24-125685:note_history:46]
Receivables Purchase Agreement
  (was, 2024-08-09, similarity 0.6027):
[0000950170-24-094602:note_history:46]
New Accounts Receivable Factoring Agreement

- added (2024-11-12):
[0000950170-24-125685:note_history:47]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. These transactions are accounted for in accordance with ASC Topic 860 and result in a reduction in accounts receivable because the Factoring Agreement transfers effective control over, and risk related to the receivables to the buyers. Trade accounts receivables balances sold are removed from the Condensed Consolidated Balance Sheets and cash received is reflected as cash flows provided by (used in) operating activities in the Condensed Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest expense on the Condensed Consolidated Statements of Loss. On each sale date, the Factor retains from the sale price a default reserve, up to a required balance, which is held by the Factor in a reserve account and pledged to the Company. The Factor is entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets.

- changed (2024-11-12):
[0000950170-24-125685:note_history:48]
Previous Receivables Purchase Agreement
  (was, 2024-08-09, similarity 0.7126):
[0000950170-24-094602:note_history:48]
Previous Accounts Receivable Factoring Agreement

- changed (2024-11-12):
[0000950170-24-125685:note_history:49]
On December 19, 2023, the Company entered into a receivables purchase agreement (the “Prior Factoring Agreement”) with a third-party financial institution and was terminated on July 1, 2024. The Prior Factoring Agreement qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company was considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retained a residual claim on reserves related to the factored receivables. Within the Condensed Consolidated Balance Sheets, the receivables factored were carried in accounts receivable, less allowance for credit losses, and the secured borrowings were carried as a current liability within accounts payable. The proceeds and repayments of secured borrowings were reflected as cash flows (used in) provided by financing activities within the Condensed Consolidated Statements of Cash Flows, and program fees were recorded as interest expense in the Consolidated Statements of Loss. The short-term liability classification of the secured borrowings was based on the estimated timing of the collection of the accounts receivable which were expected to be received within 12 months. See Note 2 for additional information.
  (was, 2024-08-09, similarity 0.8631):
[0000950170-24-094602:note_history:49]
On December 19, 2023, the Company entered into a new factoring agreement with a third-party financial institution to replace the Company’s prior accounts receivable purchase agreement, to sell on a revolving basis, undivided interests in the Company’s accounts receivable. The new factoring agreement qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company is considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retains a residual claim on reserves related to the factored receivables. Within the Condensed Consolidated Balance Sheets, the receivables factored continue to be carried in accounts receivable, less allowance for credit losses, and the secured borrowings are carried as a current liability within accounts payable. The proceeds and repayments of secured borrowings are reflected as cash flows (used in) provided by financing activities within the Condensed Consolidated Statements of Cash Flows, and program fees are recorded as interest expense in the Consolidated Statements of Loss. The short-term liability classification of the secured borrowings is based on the estimated timing of the collection of the accounts receivable which are expected to be received within 12 months. See Note 2 for additional information.

- changed (2024-11-12):
[0000950170-24-125685:note_history:50]
As of September 30, 2024 and December 31, 2023, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 33.0% and 34.6%, respectively.
  (was, 2024-08-09, similarity 0.8947):
[0000950170-24-094602:note_history:50]
As of June 30, 2024 and December 31, 2023, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.6% for each period.

- changed (2024-11-12):
[0000950170-24-125685:note_history:51]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Condensed Consolidated Balance Sheets. See Note 14 for additional information on RNCI.
  (was, 2024-08-09, similarity 0.7361):
[0000950170-24-094602:note_history:51]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. However, the RNCI will be remeasured using the current exchange rate at each reporting date as long as the RNCI is currently redeemable. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Condensed Consolidated Balance Sheets. See Note 14 for additional information on RNCI.

- added (2024-11-12):
[0000950170-24-125685:note_history:52]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2024-03, "Disaggregation of Income Statement Expenses (DISE) (Topic 220): Improvements to Income Statement Disclosures", which applies to all public business entities (PBEs) and is intended to enhance disclosures about specific types of expenses included in the expense captions presented on the face of the income statement as well as disclosures about selling expenses. The amendments are effective prospectively for annual periods beginning after December 15, 2026, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2024-03 will have on our disclosures.

- removed (2024-11-12):
[0000950170-24-094602:note_history:53]
absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated in 2023.

- removed (2024-11-12):
[0000950170-24-094602:note_history:54]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.4 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three and six months ended June 30, 2024, and 2023, we accrued $2.9 million and $5.7 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

- removed (2024-11-12):
[0000950170-24-094602:note_history:55]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or approximately $20 thousand and $25 thousand, respectively, based on an exchange rate as of June 30, 2024, were paid to Adtran Networks shareholders. For the three and six months ended June 30, 2023, approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €0.8 thousand and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

- removed (2024-11-12):
[0000950170-24-094602:note_history:56]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. Pursuant to the terms of the Credit Agreement, as amended, the Company, ADTRAN, Inc., and the subsidiary guarantors (together, the “Credit Parties”) are subject to a liquidity covenant, which provides that, during the fourth quarter of 2023 through and including the third quarter of 2024 (“Covenant Relief Period”) or a Springing Covenant Period (i.e., the period beginning upon the purchase by the Company of at least 60% of the outstanding shares of Adtran Networks not owned by the Company as of August 9, 2023 and the three consecutive quarterly test periods after such date), as of the last day of any fiscal quarter, the cash and cash equivalents of the Credit Parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million, limiting our ability to pay the obligations under the DPLTA. The Company had access to $206.0 million on its Credit Facility for future borrowings; however, as of June 30, 2024, the Company was limited to additional borrowings of $16.4 million based on debt covenant compliance metrics. See Note 11, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

- removed (2024-11-12):
[0000950170-24-094602:note_history:57]
As of June 30, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-32 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks shares.

- removed (2024-11-12):
[0000950170-24-094602:note_history:58]
The Company experienced revenue declines in the year ended December 31, 2023, and during the three and six months ended June 30, 2024. To the extent that the Company is further impacted by customers' inventory reduction initiatives, the Company is implementing plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a business efficiency program, which includes, but is not limited to ongoing reductions in

- removed (2024-11-12):
[0000950170-24-094602:note_history:59]
operating expenses and a site consolidation plan. In connection with the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditure and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

- removed (2024-11-12):
[0000950170-24-094602:note_history:60]
The Company had previously entered into a factoring agreement to sell certain receivables to an unrelated third-party financial institution on a non-recourse basis. These transactions were accounted for in accordance with ASC Topic 860 and resulted in a reduction in accounts receivable because the agreement transferred effective control over, and risk related to the receivables to the buyers. Trade accounts receivables balances sold were removed from the Condensed Consolidated Balance Sheets and cash received was reflected as cash flows provided by (used in) operating activities in the Condensed Consolidated Statements of Cash Flow. Factoring related interest expense was recorded to interest expense on the Condensed Consolidated Statements of Loss. On each sale date, the financial institution retained from the sale price a default reserve, up to a required balance, which was held by the financial institution in a reserve account and pledged to the Company. The financial institution was entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account was included in other assets on the Condensed Consolidated Balance Sheets.

- removed (2024-11-12):
[0000950170-24-094602:note_history:61]
Recent Final Rules Not Yet Adopted

- removed (2024-11-12):
[0000950170-24-094602:note_history:62]
In March 2024, the SEC adopted final rules under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, which requires registrants to provide certain climate-related information in their registration statements and annual reports. The rules require information about a registrant's climate-related risks that are reasonably likely to have a material impact on its business, results of operations, or financial condition. The required information about climate-related risks will also include disclosure of a registrant's greenhouse gas emissions. In addition, the rules will require registrants to present certain climate-related financial metrics in their audited financial statements. These requirements are effective for the Company in various fiscal years, starting with its fiscal year beginning January 1, 2025. Disclosures will be required prospectively, with information for prior periods required only to the extent it was previously disclosed in an SEC filing. The Company is currently evaluating the impact of these final rules on its consolidated financial statements and disclosures. On April 12, 2024, the final rules were indefinitely delayed pending the completion of judicial review in consolidated proceedings in the U.S. Court of Appeals, Eighth Circuit.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-11-12):
[0000950170-24-125685:note_history:63]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2024 |  |  | December 31, 2023 |  |
| Wells Fargo credit agreement |  | $ | 189,849 |  |  | $ | 195,000 |  |
| Total non-current revolving credit facility |  | $ | 189,849 |  |  | $ | 195,000 |  |

- changed (2024-11-12):
[0000950170-24-125685:note_history:64]
As of September 30, 2024, the weighted average interest rate on our revolving credit agreements was 8.45%.
  (was, 2024-08-09, similarity 0.9418):
[0000950170-24-094602:note_history:64]
As of June 30, 2024, the weighted average interest rate on our revolving credit agreements was 8.51%.

- changed (2024-11-12):
[0000950170-24-125685:note_history:65]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (as amended from time to time, the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount ($100.0 million of which is available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below).
  (was, 2024-08-09, similarity 0.8889):
[0000950170-24-094602:note_history:65]
On July 18, 2022, ADTRAN, Inc., as the borrower ("US Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (as amended from time to time, the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount ($100.0 million of which is available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below), as well as the $50.0 million delayed draw term loan facility described below. The term of the delayed draw term loan facility expires on August 9, 2024.

- added (2024-11-12):
[0000950170-24-125685:note_history:66]
The First Amendment, among other things, increased the available funding from $100.0 million to $400.0 million. In addition, a new $50.0 million delayed draw term loan facility (“DDTL”) was introduced, which (subject to certain conditions) was available for borrowing in the event that at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date was tendered (such event, a “Springing Covenant Event”). Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During the Springing Covenant Period, the Company’s leverage ratios are increased. Although the ability to borrow under the DDTL expired on August 9, 2024, the Springing Covenant Event and Springing Covenant Period remain in effect.

- added (2024-11-12):
[0000950170-24-125685:note_history:67]
On January 16, 2024 ("Second Amendment Effective Date"), the Company and ADTRAN, Inc. entered into a Second Amendment to Credit Agreement and First Amendment to Collateral Agreement ("Second Amendment"). The Second Amendment, among other things, introduced the Covenant Relief Period, which provided the Company with additional covenant headroom while imposing a minimum liquidity financial covenant from the end of the fourth quarter of 2023 to the end of the third quarter of 2024. The Covenant Relief Period ended on November 7, 2024.

- added (2024-11-12):
[0000950170-24-125685:note_history:68]
As of September 30, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $189.8 million, of which approximately $115.0 million were borrowed by ADTRAN, Inc. and $75.0 million were borrowed under the Subline by Adtran Networks. The credit facilities provided under the Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $400.0 million total revolving facility for the issuance of letters of credit. As of September 30, 2024, we had a total of $4.4 million in letters of credit under ADTRAN, Inc. outstanding under the Credit Agreement, leaving a net amount (after giving effect to the $189.8 million of outstanding borrowings described above) of $205.6 million available for future borrowings; however, as of September 30, 2024, the Company was limited to additional borrowings of $24.1 million based on debt covenant compliance metrics. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of September 30, 2024, the Company was in compliance with all covenants.

- changed (2024-11-12):
[0000950170-24-125685:note_history:69]
All U.S. dollar borrowings under the revolving line of credit other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin), bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period (as defined below), an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.15% per annum).
  (was, 2024-08-09, similarity 0.9892):
[0000950170-24-094602:note_history:69]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin), at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period (as defined below), an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.15% per annum).

- changed (2024-11-12):
[0000950170-24-125685:note_history:70]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), or (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.
  (was, 2024-08-09, similarity 0.9967):
[0000950170-24-094602:note_history:70]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.

- changed (2024-11-12):
[0000950170-24-125685:note_history:71]
In addition, if on or prior to December 31, 2024, we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.
  (was, 2024-08-09, similarity 0.9949):
[0000950170-24-094602:note_history:71]
In addition, (x) if on or prior to December 31, 2024, we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

- changed (2024-11-12):
[0000950170-24-125685:note_history:72]
•
If a Springing Covenant Period is not in effect, the Consolidated Senior Secured Net Leverage Ratio may not exceed 3.25x.
  (was, 2024-08-09, similarity 0.9789):
[0000950170-24-094602:note_history:72]
•
If a Springing Covenant Period is not in effect, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

- changed (2024-11-12):
[0000950170-24-125685:note_history:73]
•
During a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million.
  (was, 2024-08-09, similarity 0.9451):
[0000950170-24-094602:note_history:73]
•
During the Covenant Relief Period or a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million.

- changed (2024-11-12):
[0000950170-24-125685:note_history:74]
All obligations under the Credit Agreement (including under the Subline) are guaranteed by ADTRAN, Inc., and certain subsidiaries of ADTRAN, Inc. (“Full Facility Guarantors”). To secure such guarantees, ADTRAN, Inc. and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and ADTRAN, Inc. has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries ("Subline Guarantors") have provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Adtran Networks has also granted security interests in favor of the Administrative Agent over substantially all of its tangible and intangible assets, to secure solely its obligations under the Subline. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.
  (was, 2024-08-09, similarity 0.9953):
[0000950170-24-094602:note_history:74]
All obligations under the Credit Agreement (including under the Subline) are guaranteed by ADTRAN, Inc., the Company and certain subsidiaries of ADTRAN, Inc. (“Full Facility Guarantors”). To secure such guarantees, ADTRAN, Inc. and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and ADTRAN, Inc. has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries ("Subline Guarantors") have provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Adtran Networks has also granted security interests in favor of the Administrative Agent over substantially all of its tangible and intangible assets, to secure solely its obligations under the Subline. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

- changed (2024-11-12):
[0000950170-24-125685:note_history:75]
The Credit Agreement, as amended, contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.
  (was, 2024-08-09, similarity 0.9007):
[0000950170-24-094602:note_history:75]
Furthermore, the Credit Agreement, as amended, contain customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts; however, certain of the exceptions and carveouts are not permitted to be used during the Covenant Relief Period. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.

- removed (2024-11-12):
[0000950170-24-094602:note_history:76]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Wells Fargo credit agreement |  | $ | 190,273 |  |  | $ | 195,000 |  |
| Total non-current revolving credit facility |  | $ | 190,273 |  |  | $ | 195,000 |  |

- removed (2024-11-12):
[0000950170-24-094602:note_history:77]
The First Amendment among other things, provided for a new $50.0 million delayed draw term loan facility (“DDTL”), which (subject to certain conditions) is available for borrowing in the event that at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date have been tendered (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase shares of Adtran Networks. The DDTL is available for borrowing from the occurrence of a Springing Covenant Event through August 9, 2024.

- removed (2024-11-12):
[0000950170-24-094602:note_history:78]
On January 16, 2024 ("Second Amendment Effective Date"), the Company and ADTRAN, Inc. entered into a Second Amendment to Credit Agreement and First Amendment to Collateral Agreement ("Second Amendment"). The Second Amendment, among other things, provided the Company and its subsidiaries with additional covenant headroom for the fourth quarter of 2023 through and including the third quarter of 2024 ("Covenant Relief Period") and revised and/or added certain other financial covenants which (as later modified by the Fourth Amendment) are described below.

- removed (2024-11-12):
[0000950170-24-094602:note_history:79]
As of June 30, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $190.3 million, of which $115.0 million were borrowed by ADTRAN, Inc. and $75.3 million were borrowed under the Subline by Adtran Networks. As of June 30, 2024, there were no borrowings under the DDTL. The credit facilities provided under the Credit Agreement mature in July 2027, but the US Borrower has an option to request extensions subject to customary conditions. In addition, the US Borrower may utilize up to $50.0 million of the $400.0 million total revolving facility for the issuance of letters of credit. As of June 30, 2024, we had a total of $3.7 million in letters of credit under ADTRAN, Inc. outstanding under the Credit Agreement, leaving a net amount (after giving effect to the $190.3 million of outstanding borrowings described above) of $206.0 million available for future borrowings; however, as of June 30, 2024, the Company was limited to additional borrowings of $16.4 million based on debt covenant compliance metrics. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of June 30, 2024, the Company was in compliance with all covenants.

- removed (2024-11-12):
[0000950170-24-094602:note_history:80]
DDTL Interest Rate

- removed (2024-11-12):
[0000950170-24-094602:note_history:81]
All U.S. dollar borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to either (a) the Base Rate plus an applicable margin ranging from 0.90% to 1.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 2.40% per annum), or (b) Adjusted Term SOFR plus an applicable margin ranging from 1.90% to 2.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.40% per annum).

- removed (2024-11-12):
[0000950170-24-094602:note_history:82]
In addition, (x) if on or prior to December 31, 2024, we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025, we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

- removed (2024-11-12):
[0000950170-24-094602:note_history:83]
In addition to paying interest on outstanding principal under the DDTL loan, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment.

- removed (2024-11-12):
[0000950170-24-094602:note_history:84]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

- removed (2024-11-12):
[0000950170-24-094602:note_history:85]
•
From December 31, 2023, through and including March 31, 2024: 3.25x.

- removed (2024-11-12):
[0000950170-24-094602:note_history:86]
•
From April 1, 2024, through and including June 30, 2024: 3.50x.

- removed (2024-11-12):
[0000950170-24-094602:note_history:87]
•
From July 1, 2024, and thereafter: 3.25x.

- removed (2024-11-12):
[0000950170-24-094602:note_history:88]
During the Covenant Relief Period, the Company is not permitted to make certain dividend payments to the Company's Stockholders or certain other Restricted Payments. However, the Company is permitted to make the Recurring Compensation Payment to each Adtran Networks shareholder (other than the Company), pursuant to the terms of the DPLTA.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-12):
[0000950170-24-125685:note_history:89]
The Company did not have any debt securities and other investments as of September 30, 2024.
  (was, 2024-08-09, similarity 0.9341):
[0000950170-24-094602:note_history:89]
The Company did not have any debt securities and other investments as of June 30, 2024.

- added (2024-11-12):
[0000950170-24-125685:note_history:90]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 9 |  |
| Gross realized loss on debt securities |  |  | — |  |  |  | (317 | ) |  |  | — |  |  |  | (355 | ) |
| Total loss recognized, net |  | $ | — |  |  | $ | (312 | ) |  | $ | — |  |  | $ | (346 | ) |

- changed (2024-11-12):
[0000950170-24-125685:note_history:91]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Unrealized gain (loss) on equity securities held |  | $ | 1,372 |  |  | $ | (1,130 | ) |  | $ | 4,371 |  |  | $ | 1,404 |  |
| Realized (loss) gain on equity securities sold |  |  | 10 |  |  |  | (1 | ) |  |  | 136 |  |  |  | 13 |  |
| Total gain (loss) recognized, net |  | $ | 1,382 |  |  | $ | (1,131 | ) |  | $ | 4,507 |  |  | $ | 1,417 |  |
  (was, 2024-08-09, similarity 0.8156):
[0000950170-24-094602:note_history:91]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Unrealized gain on equity securities held |  | $ | 4 |  |  | $ | 1,288 |  |  | $ | 127 |  |  | $ | 2,535 |  |
| Realized gain on equity securities sold |  |  | 868 |  |  |  | 1 |  |  |  | 2,998 |  |  |  | 14 |  |
| Total gain recognized, net |  | $ | 872 |  |  | $ | 1,289 |  |  | $ | 3,125 |  |  | $ | 2,549 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:92]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,500 |  |  | $ | 5,500 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 1,035 |  |  |  | 1,035 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 30,471 |  |  |  | 30,471 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 37,006 |  |  | $ | 37,006 |  |  | $ | — |  |  | $ | — |  |

- removed (2024-11-12):
[0000950170-24-094602:note_history:93]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4 |  |
| Gross realized loss on debt securities |  |  | — |  |  |  | (27 | ) |  |  | — |  |  |  | (39 | ) |
| Total loss recognized, net |  | $ | — |  |  | $ | (27 | ) |  | $ | — |  |  | $ | (35 | ) |

- removed (2024-11-12):
[0000950170-24-094602:note_history:94]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,433 |  |  | $ | 5,433 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 955 |  |  |  | 955 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 29,204 |  |  |  | 29,204 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,592 |  |  | $ | 35,592 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-11-12):
[0000950170-24-125685:note_history:95]
|  |  | Three Months Ended |  |
|  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 81,060 |  |  | $ | 9,036 |  |  | $ | 90,096 |  |  | $ | 52,921 |  |  | $ | 8,564 |  |  | $ | 61,485 |  |
| Optical Networking Solutions |  |  | 47,474 |  |  |  | 23,061 |  |  |  | 70,535 |  |  |  | 94,592 |  |  |  | 21,608 |  |  |  | 116,200 |  |
| Access & Aggregation Solutions |  |  | 52,954 |  |  |  | 14,119 |  |  |  | 67,073 |  |  |  | 81,051 |  |  |  | 13,595 |  |  |  | 94,646 |  |
| Total |  | $ | 181,488 |  |  | $ | 46,216 |  |  | $ | 227,704 |  |  | $ | 228,564 |  |  | $ | 43,767 |  |  | $ | 272,331 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:96]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 215,044 |  |  | $ | 27,218 |  |  | $ | 242,262 |  |  | $ | 196,726 |  |  | $ | 25,760 |  |  | $ | 222,486 |  |
| Optical Networking Solutions |  |  | 152,068 |  |  |  | 67,246 |  |  |  | 219,314 |  |  |  | 342,390 |  |  |  | 64,562 |  |  |  | 406,952 |  |
| Access & Aggregation Solutions |  |  | 174,843 |  |  |  | 43,449 |  |  |  | 218,292 |  |  |  | 254,868 |  |  |  | 39,315 |  |  |  | 294,183 |  |
| Total |  | $ | 541,955 |  |  | $ | 137,913 |  |  | $ | 679,868 |  |  | $ | 793,984 |  |  | $ | 129,637 |  |  | $ | 923,621 |  |

- removed (2024-11-12):
[0000950170-24-094602:note_history:97]
|  |  | Three Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 51,467 |  |  | $ | 22,220 |  |  | $ | 73,687 |  |  | $ | 120,221 |  |  | $ | 22,775 |  |  | $ | 142,996 |  |
| Access & Aggregation Solutions |  |  | 54,112 |  |  |  | 15,795 |  |  |  | 69,907 |  |  |  | 89,263 |  |  |  | 13,454 |  |  |  | 102,717 |  |
| Subscriber Solutions |  |  | 73,615 |  |  |  | 8,782 |  |  |  | 82,397 |  |  |  | 73,518 |  |  |  | 8,147 |  |  |  | 81,665 |  |
| Total |  | $ | 179,194 |  |  | $ | 46,797 |  |  | $ | 225,991 |  |  | $ | 283,002 |  |  | $ | 44,376 |  |  | $ | 327,378 |  |

- removed (2024-11-12):
[0000950170-24-094602:note_history:98]
|  |  | Six Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 104,594 |  |  | $ | 44,186 |  |  | $ | 148,780 |  |  | $ | 247,798 |  |  | $ | 42,954 |  |  | $ | 290,752 |  |
| Access & Aggregation Solutions |  |  | 121,889 |  |  |  | 29,330 |  |  |  | 151,219 |  |  |  | 173,817 |  |  |  | 25,720 |  |  |  | 199,537 |  |
| Subscriber Solutions |  |  | 133,984 |  |  |  | 18,181 |  |  |  | 152,165 |  |  |  | 143,805 |  |  |  | 17,196 |  |  |  | 161,001 |  |
| Total |  | $ | 360,467 |  |  | $ | 91,697 |  |  | $ | 452,164 |  |  | $ | 565,420 |  |  | $ | 85,870 |  |  | $ | 651,290 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-11-12):
[0000950170-24-125685:note_history:99]
|  |  | Three Months Ended |  |
|  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 81,060 |  |  | $ | 9,036 |  |  | $ | 90,096 |  |  | $ | 52,921 |  |  | $ | 8,564 |  |  | $ | 61,485 |  |
| Optical Networking Solutions |  |  | 47,474 |  |  |  | 23,061 |  |  |  | 70,535 |  |  |  | 94,592 |  |  |  | 21,608 |  |  |  | 116,200 |  |
| Access & Aggregation Solutions |  |  | 52,954 |  |  |  | 14,119 |  |  |  | 67,073 |  |  |  | 81,051 |  |  |  | 13,595 |  |  |  | 94,646 |  |
| Total |  | $ | 181,488 |  |  | $ | 46,216 |  |  | $ | 227,704 |  |  | $ | 228,564 |  |  | $ | 43,767 |  |  | $ | 272,331 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:100]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 215,044 |  |  | $ | 27,218 |  |  | $ | 242,262 |  |  | $ | 196,726 |  |  | $ | 25,760 |  |  | $ | 222,486 |  |
| Optical Networking Solutions |  |  | 152,068 |  |  |  | 67,246 |  |  |  | 219,314 |  |  |  | 342,390 |  |  |  | 64,562 |  |  |  | 406,952 |  |
| Access & Aggregation Solutions |  |  | 174,843 |  |  |  | 43,449 |  |  |  | 218,292 |  |  |  | 254,868 |  |  |  | 39,315 |  |  |  | 294,183 |  |
| Total |  | $ | 541,955 |  |  | $ | 137,913 |  |  | $ | 679,868 |  |  | $ | 793,984 |  |  | $ | 129,637 |  |  | $ | 923,621 |  |

- added (2024-11-12):
[0000950170-24-125685:note_history:101]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of September 30, 2024, related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $280.8 million. As of September 30, 2024, approximately 66.0% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of September 30, 2024, are related to contracts or orders that have an original expected duration of one year or less and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2024-11-12):
[0000950170-24-125685:note_history:102]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2024 |  |  | December 31, 2023 |  |
| Accounts receivable, net |  | $ | 172,025 |  |  | $ | 216,445 |  |
| Contract assets(1) |  | $ | 668 |  |  | $ | 691 |  |
| Unearned revenue |  | $ | 54,615 |  |  | $ | 46,731 |  |
| Non-current unearned revenue |  | $ | 24,901 |  |  | $ | 25,109 |  |
  (was, 2024-08-09, similarity 0.9279):
[0000950170-24-094602:note_history:102]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Accounts receivable, net |  | $ | 186,176 |  |  | $ | 216,445 |  |
| Contract assets(1) |  | $ | 719 |  |  | $ | 691 |  |
| Unearned revenue |  | $ | 55,107 |  |  | $ | 46,731 |  |
| Non-current unearned revenue |  | $ | 26,584 |  |  | $ | 25,109 |  |

- changed (2024-11-12):
[0000950170-24-125685:note_history:103]
The allowance for credit losses was $0.4 million as of September 30, 2024, and December 31, 2023, respectively, related to accounts receivable.
  (was, 2024-08-09, similarity 0.903):
[0000950170-24-094602:note_history:103]
The allowance for credit losses was $0.2 million and $0.4 million as of June 30, 2024, and December 31, 2023, respectively, related to accounts receivable.

- added (2024-11-12):
[0000950170-24-125685:note_history:104]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of September 30, 2024, totaled $16.7 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months and nine months ended September 30, 2024. Costs of a previous receivables purchase agreement which are included in interest expense in the Condensed Consolidated Statements of Loss totaled $0.3 million and $0.9 million for the three and nine months ended September 30, 2023.

- added (2024-11-12):
[0000950170-24-125685:note_history:105]
Previous Receivable Purchase Agreement

- added (2024-11-12):
[0000950170-24-125685:note_history:106]
On December 19, 2023, the Company entered into a receivables purchase agreement (the “Prior Factoring Agreement”) with a third-party financial institution (the "Factor")  to replace a prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The prior factoring agreement provided for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The prior factoring agreement qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. The receivables purchase agreement was terminated on July 1, 2024 and there were no secured borrowings under this agreement as of September 30, 2024. Total secured borrowings under the agreement were $14.3 million as of December 31, 2023, which left $25.4 million available for future borrowings as of December 31, 2023. Accounts receivable pledged as collateral related to the secured borrowings were $16.8 million as of December 31, 2023. For the nine months ended September 30, 2024, the Company incurred program fee expenses of $0.6 million.

- changed (2024-11-12):
[0000950170-24-125685:note_history:107]
No allowance for credit losses was recorded for the three and nine months ended September 30, 2024 and 2023, respectively, related to contract assets.
  (was, 2024-08-09, similarity 0.8855):
[0000950170-24-094602:note_history:107]
No allowance for credit losses was recorded for the three and six months ended June 30, 2024 and 2023 related to contract assets.

- added (2024-11-12):
[0000950170-24-125685:note_history:108]
Unearned Revenue

- changed (2024-11-12):
[0000950170-24-125685:note_history:109]
Of the outstanding unearned revenue balances as of December 31, 2023, $10.03 million and $43.1 million were recognized as revenue during the three and nine months ended September 30, 2024, respectively. Of the $60.4 million of outstanding unearned revenue balances as of December 31, 2022, $6.1 million and $31.3 million were recognized as revenue during the three and nine months ended September 30, 2023, respectively.
  (was, 2024-08-09, similarity 0.872):
[0000950170-24-094602:note_history:109]
Of the outstanding unearned revenue balances as of December 31, 2023, $13.7 million and $33.1 million were recognized as revenue during the three and six months ended June 30, 2024, respectively. Of the $60.4 million of outstanding unearned revenue balances as of December 31, 2022, $24.8 million and $50.5 million were recognized as revenue during the three and six months ended June 30, 2023, respectively.

- removed (2024-11-12):
[0000950170-24-094602:note_history:110]
|  |  | Three Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 51,467 |  |  | $ | 22,220 |  |  | $ | 73,687 |  |  | $ | 120,221 |  |  | $ | 22,775 |  |  | $ | 142,996 |  |
| Access & Aggregation Solutions |  |  | 54,112 |  |  |  | 15,795 |  |  |  | 69,907 |  |  |  | 89,263 |  |  |  | 13,454 |  |  |  | 102,717 |  |
| Subscriber Solutions |  |  | 73,615 |  |  |  | 8,782 |  |  |  | 82,397 |  |  |  | 73,518 |  |  |  | 8,147 |  |  |  | 81,665 |  |
| Total |  | $ | 179,194 |  |  | $ | 46,797 |  |  | $ | 225,991 |  |  | $ | 283,002 |  |  | $ | 44,376 |  |  | $ | 327,378 |  |

- removed (2024-11-12):
[0000950170-24-094602:note_history:111]
|  |  | Six Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 104,594 |  |  | $ | 44,186 |  |  | $ | 148,780 |  |  | $ | 247,798 |  |  | $ | 42,954 |  |  | $ | 290,752 |  |
| Access & Aggregation Solutions |  |  | 121,889 |  |  |  | 29,330 |  |  |  | 151,219 |  |  |  | 173,817 |  |  |  | 25,720 |  |  |  | 199,537 |  |
| Subscriber Solutions |  |  | 133,984 |  |  |  | 18,181 |  |  |  | 152,165 |  |  |  | 143,805 |  |  |  | 17,196 |  |  |  | 161,001 |  |
| Total |  | $ | 360,467 |  |  | $ | 91,697 |  |  | $ | 452,164 |  |  | $ | 565,420 |  |  | $ | 85,870 |  |  | $ | 651,290 |  |

- removed (2024-11-12):
[0000950170-24-094602:note_history:112]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2024, and December 31, 2023, related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $276.9 million and $314.8 million, respectively. As of June 30, 2024, approximately 57% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of June 30, 2024, are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- removed (2024-11-12):
[0000950170-24-094602:note_history:113]
The Company was party to a receivable purchase agreement with a third-party financial institution (“Factor”), which accelerates receivable collection and helps to better manage cash flow. As of December 31, 2023, no accounts receivable were factored under the agreement or held in the reserve account. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million and $0.6 million for the three and six months ended June 30, 2023.

- removed (2024-11-12):
[0000950170-24-094602:note_history:114]
On December 19, 2023, the agreement with the Factor was terminated and the Company, entered into a receivables purchase agreement with a third-party financial institution (“New Factor”) to replace the Company’s prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The New Factor provides for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The New Factor qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. Total secured borrowings under the agreement were $17.3 million and $14.3 million as of June 30, 2024 and December 31, 2023, respectively, leaving $22.4 million and $25.4 million available for future borrowings as of June 30, 2024 and December 31, 2023, respectively. Accounts receivable pledged as collateral related to the secured borrowings were $21.2 million and $16.8 million as of June 30, 2024 and December 31, 2023, respectively. For the three and six months ended June 30, 2024, the Company incurred program fee expenses of $0.3 million and $0.6 million, respectively. As of June 30, 2024, the program fee rate was 6.88% percent.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2024-11-12):
[0000950170-24-094602:note_history:115]
20. SUBSEQUENT EVENTS

- removed (2024-11-12):
[0000950170-24-094602:note_history:116]
Receivables Purchase Agreement

- removed (2024-11-12):
[0000950170-24-094602:note_history:117]
On July 1, 2024, the Company renegotiated our receivables purchase agreement which is currently treated as a secured borrowing. The renegotiated receivables purchase agreement will result in a derecognition of the accounts receivable sold and the removal of the secured borrowing liability given the agreement transfers effective control over, and risk related to the receivables to the buyers. See Note 1 and Note 2 above for additional information on the accounting treatment of our receivable purchase agreements.

- removed (2024-11-12):
[0000950170-24-094602:note_history:118]
Annual Recurring Compensation Payment

- removed (2024-11-12):
[0000950170-24-094602:note_history:119]
On July 3, 2024, the Annual Recurring Compensation was paid with respect to the 2023 fiscal year. See Note 1 and Note 18 for additional information on the Annual Recurring Compensation payment.
