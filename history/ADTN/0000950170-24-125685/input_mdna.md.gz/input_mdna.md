# ADTN MD&A — 0000950170-24-125685


## mdna

[0000950170-24-125685:mdna:1]
[same as prior period, unchanged from 0000950170-24-094602:mdna:1]

[0000950170-24-125685:mdna:2]
[same as prior period, unchanged from 0000950170-24-094602:mdna:2]

[0000950170-24-125685:mdna:3]
[same as prior period, unchanged from 0000950170-24-094602:mdna:3]

[0000950170-24-125685:mdna:4]
Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to "ADTRAN", the “Company,” “we”, “us” and “our” refer to ADTRAN Holdings, Inc. and its consolidated subsidiaries. Furthermore, unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to “Adtran Networks” refer to Adtran Networks SE (formerly ADVA Optical Networking SE).

[0000950170-24-125685:mdna:5]
[same as prior period, unchanged from 0000950170-24-094602:mdna:5]

[0000950170-24-125685:mdna:6]
The Company is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies.

[0000950170-24-125685:mdna:7]
Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands while enabling them to transition to the fully converged, scalable, highly automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-24-125685:mdna:8]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end customer, especially upon the convergence of solutions at the network edge.

[0000950170-24-125685:mdna:9]
[same as prior period, unchanged from 0000950170-24-094602:mdna:9]

[0000950170-24-125685:mdna:10]
[same as prior period, unchanged from 0000950170-24-094602:mdna:10]

[0000950170-24-125685:mdna:11]
[same as prior period, unchanged from 0000950170-24-094602:mdna:11]

[0000950170-24-125685:mdna:12]
[same as prior period, unchanged from 0000950170-24-094602:mdna:12]

[0000950170-24-125685:mdna:13]
[same as prior period, unchanged from 0000950170-24-094602:mdna:13]

[0000950170-24-125685:mdna:14]
[same as prior period, unchanged from 0000950170-24-094602:mdna:14]

[0000950170-24-125685:mdna:15]
[same as prior period, unchanged from 0000950170-24-094602:mdna:15]

[0000950170-24-125685:mdna:16]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest ("Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.52 per share for each full fiscal year of Adtran Networks (“Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component that was 3.37% as of September 30, 2024. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024, and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. The adequacy of both forms of compensation has been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

[0000950170-24-125685:mdna:17]
The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). For the three and nine months ended September 30, 2024, approximately 830 thousand shares and 831 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on an exchange rate as of September 30, 2024, being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, being paid to Adtran Networks shareholders.

[0000950170-24-125685:mdna:18]
In addition to our cash and cash equivalents and the credit facility, we may fund a portion or all of the Exit Compensation through the sale of securities or additional alternative funding sources, if available. There can be no assurances that we would be successful in effecting these actions on commercially reasonable terms or at all. If we cannot raise additional funds as needed, it could have a material adverse impact on our financial results and financial condition.

[0000950170-24-125685:mdna:19]
We currently hold 34,855,921 no-par value bearer shares of Adtran Networks, representing 67.0% of Adtran Networks outstanding shares as of September 30, 2024.

[0000950170-24-125685:mdna:20]
[same as prior period, unchanged from 0000950170-24-094602:mdna:20]

[0000950170-24-125685:mdna:21]
[same as prior period, unchanged from 0000950170-24-094602:mdna:23]

[0000950170-24-125685:mdna:22]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (“Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expands upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital

[0000950170-24-125685:mdna:23]
Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment. Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). On October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze. Additionally, on April 11, 2024, management determined to close a facility in Greifswald, Germany. The closure of the facility is expected to be completed by December 31, 2024.

[0000950170-24-125685:mdna:24]
During the three and nine months ended September 30, 2024, we recognized $5.9 million and $40.6 million of costs related to the Business Efficiency Program, respectively. The costs recognized during the nine months ended September 30, 2024, included charges of $8.6 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.1 million relates to inventory write-downs and $4.5 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss. Since the inception of the Business Efficiency Program, we recognized $65.6 million of costs. We expect costs in the fourth quarter 2024 relating to the Business Efficiency Program to range between $9.6 million and $13.8 million. Management expects these planned costs to include severance costs to be approximately $6.2 million in connection with reductions in workforce and site consolidation transaction expenses (primarily brokers fees and Greifswald exit costs) ranging from $3.4 million to $7.6 million. The broker fees related to our site consolidation expenses will be netted against proceeds upon the sale of the building(s). Future cash payments include: severance costs and outplacement fees that are anticipated to be  approximately $23.1 million, and payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $3.4 million to $7.6 million, We do not anticipate any remaining payments related to the inventory strategy shift. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures.  However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing. If required, we will amend this disclosure at such time as management is able in good faith to estimate the amount, or range of amounts, of these charges.

[0000950170-24-125685:mdna:25]
[same as prior period, unchanged from 0000950170-24-094602:mdna:26]

[0000950170-24-125685:mdna:26]
During the three and nine months ended September 30, 2024, we recognized $0.4 million and $1.4 million of integration costs related to the Business Combination were incurred. During the three and nine months ended September 30, 2023, $1.7 million and $3.1 million of integration costs related to the Business Combination were incurred, respectively. These transaction costs are included in selling, general and administrative expenses, research & development expenses and cost of revenue in the Condensed Consolidated Statement of Loss. We expect to incur additional integration costs and expenses associated with the implementation of the DPLTA throughout 2024 and such costs are expected to be material. See Note 19 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-125685:mdna:27]
[same as prior period, unchanged from 0000950170-24-094602:mdna:28]

[0000950170-24-125685:mdna:28]
We ended the third quarter of 2024 with a year-over-year revenue decrease of 16.4% as compared to the three months ended September 30, 2023, driven by decreased volume of sales activity due to customers' focus on reducing inventory levels and continuing uncertain macroeconomic conditions related to inflationary pressures, elevated interest rates and currency fluctuation which impacted the spending behavior of our customers. During the third quarter of 2024, we had one customer with revenues greater than 10.0% which was an international Service Provider customer and our five largest customers comprised 30.1% of our revenue. Our year-over-year domestic revenue decreased by 8.0% and continued to be impacted by elevated customer inventory levels, continuing effects of uncertain macroeconomic conditions and decreased shipments to distributor customers. Internationally, our year-over-year revenue decreased by 22.2%, primarily driven by the unfavorable impact of foreign exchange on revenue as a result of the strengthened U.S. dollar and decreased shipments to network operators in Europe.

[0000950170-24-125685:mdna:29]
Access & Aggregation and Optical Networking revenue categories experienced a general slowdown in revenue as a result of reduced spending by our Service Provider customers as they continue to reduce excess inventory levels and monitor the uncertain macroeconomic conditions. Despite these challenges, we have maintained our emphasis on product development to enable us to respond to rapidly changing technology and evolving industry standards. For example, we expect public funding through projects such as IPCEI ME/CT to further our research and development for new communication technologies. Additionally, public funding through the Broadband Equity, Access and Deployment Program is expected to commence in 2025, which provides a positive outlook for the future. In Europe, we continue to see increased activity from high-risk vendor replacement and broadband subsidy programs.

[0000950170-24-125685:mdna:30]
Our operating results have fluctuated and may continue to fluctuate on a quarterly basis due to several factors, including customer order activity, prior supply chain constraints, component availability, and the Company's consolidation and integration with Adtran Networks. Further, a significant percentage of orders require delivery within a few days, requiring us to maintain higher inventory levels. These factors may result in limited order flow visibility. We have taken decisive steps to transform our business into a leaner, more efficient and more profitable company, including through the implementation of a Business Efficiency Program, which includes a significant cost efficiency program targeting a reduction of ongoing operating expenses and a capital efficiency program inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension

[0000950170-24-125685:mdna:31]
of the quarterly dividend. Nevertheless, our operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues has and may again in the future significantly impact on our financial results in any given quarter.

[0000950170-24-125685:mdna:32]
Our operating results have significantly fluctuated and may do so in the future as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, inflation, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. In recent years, inflationary pressures on input costs, such as raw materials and labor, and distribution costs had a negative impact on our operating results. However, inflationary pressures on our supply chain have eased somewhat, which has led to reductions in cost premiums on raw material costs and freight. We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors and customers to address and to limit the disruption to our operations and order fulfillment. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an additional adverse effect on our business and operating results beyond the effects of the most recent inventory write-downs. Also, not maintaining sufficient inventory levels to ensure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results.

[0000950170-24-125685:mdna:33]
We are exposed to changes in foreign currencies relative to the U.S. dollar, which are references to the differences between the foreign-exchanges rates we use to convert the financial results of our international operations from local currencies into U.S. dollars for financial reporting purposes. This impact of foreign-exchange rate changes is calculated based on the difference between the current period’s currency exchange rates and that of the comparable prior period. Our primary exposures to foreign currency exchange rate movements are with the euro and the British pound. As a result of our global operations, our revenue, gross margin, operating expense and operating loss in some international markets has been and may continue to be affected by foreign currency fluctuations.

[0000950170-24-125685:mdna:34]
[same as prior period, unchanged from 0000950170-24-094602:mdna:34]

[0000950170-24-125685:mdna:35]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of the Network Solutions reporting unit using a combination of an income approach and a market-based peer group analysis. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit during the three months ended March 31, 2024. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the three months ended March 31, 2024. There have been no triggering events identified affecting the valuation of goodwill in our Services & Support reporting unit during the second and third quarters of 2024.

[0000950170-24-125685:mdna:36]
[same as prior period, unchanged from 0000950170-24-094602:mdna:37]

[0000950170-24-125685:mdna:37]
[same as prior period, unchanged from 0000950170-24-094602:mdna:38]

[0000950170-24-125685:mdna:38]
[same as prior period, unchanged from 0000950170-24-094602:mdna:39]

[0000950170-24-125685:mdna:39]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2024, COMPARED TO THE THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2023

[0000950170-24-125685:mdna:40]
[same as prior period, unchanged from 0000950170-24-094602:mdna:42]

[0000950170-24-125685:mdna:41]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 79.7 |  | % |  | 83.9 |  | % |  | 79.7 |  | % |  | 86.0 |  | % |
| Services & Support |  |  | 20.3 |  |  |  | 16.1 |  |  |  | 20.3 |  |  |  | 14.0 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 55.4 |  |  |  | 58.8 |  |  |  | 55.4 |  |  |  | 64.6 |  |  |
| Network Solutions - other (credits), charges and inventory write-down |  |  | (0.1 | ) |  |  | 7.7 |  |  |  | 1.3 |  |  |  | 2.3 |  |  |
| Services & Support |  |  | 7.3 |  |  |  | 6.2 |  |  |  | 8.1 |  |  |  | 5.6 |  |  |
| Total Cost of Revenue |  |  | 62.6 |  |  |  | 72.7 |  |  |  | 64.8 |  |  |  | 72.4 |  |  |
| Gross Profit |  |  | 37.4 |  |  |  | 27.3 |  |  |  | 35.2 |  |  |  | 27.6 |  |  |
| Selling, general and administrative expenses |  |  | 25.3 |  |  |  | 23.1 |  |  |  | 25.9 |  |  |  | 21.3 |  |  |
| Research and development expenses |  |  | 22.7 |  |  |  | 23.0 |  |  |  | 25.3 |  |  |  | 22.0 |  |  |
| Goodwill impairment |  |  | — |  |  |  | 13.9 |  |  |  | 43.0 |  |  |  | 4.1 |  |  |
| Operating Loss |  |  | (10.5 | ) |  |  | (32.8 | ) |  |  | (59.1 | ) |  |  | (19.9 | ) |  |
| Interest and dividend income |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.1 |  |  |
| Interest expense |  |  | (2.5 | ) |  |  | (1.7 | ) |  |  | (2.5 | ) |  |  | (1.3 | ) |  |
| Net investment gain (loss) |  |  | 0.6 |  |  |  | (0.5 | ) |  |  | 0.7 |  |  |  | 0.1 |  |  |
| Other (expense) income, net |  |  | (0.4 | ) |  |  | 0.9 |  |  |  | (0.1 | ) |  |  | 0.5 |  |  |
| Loss Before Income Taxes |  |  | (12.5 | ) |  |  | (33.9 | ) |  |  | (60.8 | ) |  |  | (20.4 | ) |  |
| Income tax (expense) benefit |  |  | (0.2 | ) |  |  | 6.1 |  |  |  | 2.4 |  |  |  | 3.9 |  |  |
| Net Loss |  |  | (12.7 | ) | % |  | (27.8 | ) | % |  | (58.5 | ) | % |  | (16.5 | ) | % |
| Less: Net Income attributable to non-controlling interest |  |  | 1.0 |  |  |  | 0.9 |  |  |  | 1.1 |  |  |  | 0.5 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | (13.7 | ) | % |  | (28.7 | ) | % |  | (59.6 | ) | % |  | (17.0 | ) | % |

[0000950170-24-125685:mdna:42]
[same as prior period, unchanged from 0000950170-24-094602:mdna:44]

[0000950170-24-125685:mdna:43]
Our revenue decreased 16.4% from $272.3 million for the three months ended September 30, 2023, to $227.7 million for the three months ended September 30, 2024, and decreased 26.4% from $923.6 million for the nine months ended September 30, 2023, to $679.9 million for the nine months ended September 30, 2024. The decrease in revenue for the three and nine months ended September 30, 2024, is primarily driven by a decrease in volume of sales activity due to customers’ focus on reducing inventory levels and the completion of significant customer projects. The decrease in revenue by category for the three months ended September 30, 2024, was primarily attributable to a $45.7 million decrease in Optical Networking Solutions products, and a $27.6 million decrease in Access & Aggregation revenue partially offset by a $28.6 million increase in Subscriber Solutions products. The decrease in revenue by category for the nine months ended September 30, 2024, was primarily attributable to a $187.6 million decrease in Optical Networking Solutions products, and a $75.9 million decrease in Access & Aggregation revenue partially offset by a $19.8 million increase in Subscriber Solutions products. Continued customer concerns over inventory stocking levels have affected our revenue year-to-date in our Optical Networking Solutions category, Access & Aggregation category and our Subscriber Solutions category. This includes our two largest Optical Networking Solutions customers, which we believe are focused on reducing existing inventory.

[0000950170-24-125685:mdna:44]
Network Solutions segment revenue decreased 20.6% from $228.6 million for the three months ended September 30, 2023, to $181.5 million for the three months ended September 30, 2024, and decreased 31.7% from $794.0 million for the nine months ended September 30, 2023, to $542.0 million for the nine months ended September 30, 2024. The decrease in Network Solutions revenue for the three months ended September 30, 2024, was due to a decrease of $47.1 million in volume of sales activity in Optical Networking products, and a decrease of $28.1 million in volume of sales activity in Access & Aggregation products partially offset by an increase of $28.1 million in volume of sales activity in Subscriber Solutions products. The decrease in Network Solutions revenue for the nine months ended September 30, 2024, was due to a decrease of $190.3 million in volume of sales activity in Optical Networking products, and a decrease of $80.0 million in volume of sales activity in Access & Aggregation products partially offset by an increase of $18.3 million in volume of sales activity in Subscriber Solutions products.

[0000950170-24-125685:mdna:45]
Services & Support segment revenue increased 5.6% from $43.8 million for the three months ended September 30, 2023, to $46.2 million for the three months ended September 30, 2024, and increased 6.4% from $129.6 million for the nine months ended

[0000950170-24-125685:mdna:46]
49

[0000950170-24-125685:mdna:47]
September 30, 2023, to $137.9 million for the nine months ended September 30, 2024. The increase in revenue for the three months ended September 30, 2024, was primarily attributable a $1.5 million increase in Optical Networking services, a $0.5 million increase for Subscriber Solutions and a $0.5 million increase in Access & Aggregation. The increase in revenue for the nine months ended September 30, 2024, was primarily attributable a $4.1 million increase in Access & Aggregation a $2.7 million increase in Optical Networking services, and a $1.5 million increase in Subscriber Solutions services. More specifically, the increase in revenue for the three and nine months ended September 30, 2024, of our ADTRAN, Inc. operations was primarily due to higher volume of sales of our software services and business solutions services.

[0000950170-24-125685:mdna:48]
Domestic revenue decreased by 8.0% from $111.5 million for the three months ended September 30, 2023, to $102.5 million for the three months ended September 30, 2024, and decreased by 21.8% from $375.3 million for the nine months ended September 30, 2023, to $293.4 million for the nine months ended September 30, 2024. The decrease in domestic revenue for the three and nine months ended September 30, 2024, was primarily due to lower volume of sales of our residential solutions products as a result of customers focus on reducing inventory levels across all revenue categories.

[0000950170-24-125685:mdna:49]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., decreased by 22.1% from $160.8 million for the three months ended September 30, 2023 to $125.2 million for the three months ended September 30, 2024 and decreased by 29.5% from $548.4 million for the nine months ended September 30, 2023 to $386.4 million for the nine months ended September 30, 2024. International revenue, as a percentage of total revenue, decreased from 59.1% for the three months ended September 30, 2023, to 55.0% for the three months ended September 30, 2024, and decreased from 59.4% for the nine months ended September 30, 2023, to 56.8% for the nine months ended September 30, 2024. The decrease in international revenue for the three and nine months ended September 30, 2024, was primarily due to the conclusion of specific customer projects and customer concerns over inventory stocking levels. While international revenue has decreased to approximately 55.0% and 56.8% of total revenues for the three and nine months ended September 30, 2024, respectively, the mix of our Network Solutions and Services & Support segments as a percentage of total international revenue remains relatively linear. For the three and nine months ended September 30, 2024, as compared to the three and nine months ended September 30, 2023, changes in foreign currencies relative to the U.S. dollar increased our net revenue by approximately $2.8 million and increased our net revenue by approximately $4.7 million, respectively.

[0000950170-24-125685:mdna:50]
[same as prior period, unchanged from 0000950170-24-094602:mdna:51]

[0000950170-24-125685:mdna:51]
[same as prior period, unchanged from 0000950170-24-094602:mdna:52]

[0000950170-24-125685:mdna:52]
As a percentage of revenue, cost of revenue decreased from 72.7% for the three months ended September 30, 2023, to 62.6% for the three months ended September 30, 2024, and decreased from 72.4% for the nine months ended September 30, 2023, to 64.8% for the nine months ended September 30, 2024. The decrease for the three months ended September 30, 2024 was attributable to a 0.7% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, a 0.8% decrease in expense as a percentage of revenue related to decreased acquisition costs, a 9.5% decrease in expense as a percentage of revenue in connection with our Business Efficiency Program (primarily a decrease in inventory write-offs related to our strategy shift which included discontinuance of certain product lines), partially offset by a 0.8% increase in expense as a percentage of revenue attributable to changes in customer and product mix. The decrease for the nine months ended September 30, 2024 was attributable to a 3.5% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, a 3.7% decrease in expense as a percentage of revenue related to decreased acquisition costs, a 1.1% decrease in expense as a percentage of revenue in connection with our Business Efficiency Program (primarily a decrease in inventory write-offs related to our strategy shift which included discontinuance of certain product lines, partially offset by increases in severance and employee related costs), partially offset by a 0.7% increase in expense as a percentage of revenue attributable to changes in customer and product mix. For the three and nine months ended September 30, 2024, as compared to the three and nine months ended September 30, 2023, changes in foreign currencies relative to the U.S. dollar increased our cost of revenue by approximately $0.6 million and increased our cost of revenue by approximately $1.0 million, respectively.

[0000950170-24-125685:mdna:53]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, decreased from 79.3% for the three months ended September 30, 2023, to 69.3% for the three months ended September 30, 2024, and decreased from 77.8% for the nine months ended

[0000950170-24-125685:mdna:54]
September 30, 2023 to 71.1% for the nine months ended September 30, 2024. The decrease in cost of revenue as a percentage of revenue for the three months ended September 30, 2024 was attributable to a 0.8% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, a 1.0% decrease in expense as a percentage of revenue related to decreased acquisition costs, and  a 11.9% decrease in expense as a percentage of revenue in connection with our Business Efficiency Program (primarily a decrease in inventory write-offs related to our strategy shift which included discontinuance of certain product lines), partially offset by a 3.7% increase in expense as a percentage of revenue attributable to changes in customer and product mix. The decrease in cost of revenue as a percentage of revenue for the nine months ended September 30, 2024 was attributable to a 4.4% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, a 4.6% decrease in expense as a percentage of revenue related to decreased acquisition costs, a 1.8% decrease in expense as a percentage of revenue in connection with our Business Efficiency Program (primarily a decrease in inventory write-offs related to our strategy shift which included discontinuance of certain product lines, partially offset by increases in severance and employee related costs), which resulted in an inventory write down and other charges of $8.6 million incurred as a result of a strategy shift which included discontinuance of certain product lines, partially offset by a 4.1% increase in expense as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-24-125685:mdna:55]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 38.4% for the three months ended September 30, 2023, to 36.1% for the three months ended September 30, 2024, and increased from 39.8% for the nine months ended September 30, 2023 to 40.1% for the nine months ended September 30, 2024. The increase in cost of revenue as a percentage of revenue for the three and nine months ended September 30, 2024, was primarily attributable to changes in customer and product mix.

[0000950170-24-125685:mdna:56]
[same as prior period, unchanged from 0000950170-24-094602:mdna:57]

[0000950170-24-125685:mdna:57]
[same as prior period, unchanged from 0000950170-24-094602:mdna:58]

[0000950170-24-125685:mdna:58]
As a percentage of revenue, gross profit increased from 27.3% for the three months ended September 30, 2023, to 37.4% for the three months ended September 30, 2024, and increased from 27.6% for the nine months ended September 30, 2023 to 35.2% for the nine months ended September 30, 2024. The increase for the three months ended September 30, 2024 was attributable to a 0.7% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, a 0.8% increase in gross profit as a percentage of revenue related to decreased acquisition costs, a 9.5% increase in gross profit as a percentage of revenue in connection with decreased expenses with our Business Efficiency Program (primarily a decrease in inventory write-offs related to our strategy shift which included discontinuance of certain product lines), partially offset by a 0.8% decrease in gross profit as a percentage of revenue attributable to changes in customer and product mix. The increase for the nine months ended September 30, 2024 was attributable to a 3.5% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, a 3.7% increase in gross profit as a percentage of revenue related to decreased acquisition costs, a 1.1% increase in gross profit as a percentage of revenue in connection with decreased expenses with our Business Efficiency Program (primarily a decrease in inventory write-offs related to our strategy shift which included discontinuance of certain product lines, partially offset by increases in severance and employee related costs), which resulted in an inventory write down and other charges of $8.6 million incurred as a result of a strategy shift which included discontinuance of certain product lines, partially offset by a 0.7% decrease in gross profit as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-24-125685:mdna:59]
As a percentage of that segment's revenue, Network Solutions gross profit increased from 20.7% for the three months ended September 30, 2023, to 30.7% for the three months ended September 30, 2024, and increased from 22.2% for the nine months ended September 30, 2023 to 28.9% for the nine months ended September 30, 2024. The increase for the three months ended September 30, 2024 was attributable to a 0.8% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks a 1.0% increase in gross profit as a percentage of revenue related to decreased acquisition costs, a 11.9% increase in gross profit as a percentage of revenue in connection with decreased expenses with our Business Efficiency Program (primarily a decrease in inventory write-offs related to our strategy shift which included discontinuance of certain product lines), partially offset by a 3.7% decrease in gross profit as a percentage of revenue attributable to changes in customer and product mix. The increase for the nine months ended September 30, 2024 was attributable to a 4.4% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, a 4.6% increase in gross profit as a percentage

[0000950170-24-125685:mdna:60]
51

[0000950170-24-125685:mdna:61]
of revenue related to decreased acquisition costs, a 1.8% increase in gross profit as a percentage of revenue in connection with decreased expenses with our Business Efficiency Program (primarily a decrease in inventory write-offs related to our strategy shift which included discontinuance of certain product lines, partially offset by increases in severance and employee related costs), which resulted in an inventory write down and other charges of $8.6 million incurred as a result of a strategy shift which included discontinuance of certain product lines, partially offset by a 4.1% decrease in gross profit as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-24-125685:mdna:62]
As a percentage of that segment's revenue, Services & Support gross profit increased from 61.6% for the three months ended September 30, 2023, to 63.9% for the three months ended September 30, 2024, and decreased from 60.2% for the nine months ended September 30, 2023, to 59.9% for the nine months ended September 30, 2024. The decrease was primarily attributable to changes in customer and services mix.

[0000950170-24-125685:mdna:63]
[same as prior period, unchanged from 0000950170-24-094602:mdna:62]

[0000950170-24-125685:mdna:64]
As a percentage of revenue, selling, general and administrative expenses increased from 23.1% for the three months ended September 30, 2023, to 25.3% for the three months ended September 30, 2024, and increased from 21.3% for the nine months ended September 30, 2023, to 25.9% for the nine months ended September 30, 2024. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared. We are still in the process of implementing our Business Efficiency Program, which we expect will lower selling, general and administrative expenses as a percentage of revenue over time.

[0000950170-24-125685:mdna:65]
Selling, general and administrative expenses decreased 8.4% from $62.9 million for the three months ended September 30, 2023, to $57.6 million for the three months ended September 30, 2024, and decreased 10.5% from $196.9 million for the nine months ended September 30, 2023, to $176.2 million for the nine months ended September 30, 2024. Selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The decrease in selling, general and administrative expenses for the three months ended September 30, 2024, compared to the three months ended September 30, 2023, was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $3.4 million. The decrease for the nine months ended September 30, 2024, compared to the nine months ended September 30, 2023, was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $17.0 million, and travel expenses by $2.0 million. For the three and nine months ended September 30, 2024, as compared to the three and nine months ended September 30, 2023, changes in foreign currencies relative to the U.S dollar decreased our selling, general and administrative expenses by approximately $0.3 million and increased our selling, general and administrative expenses by approximately $0.6 million, respectively.

[0000950170-24-125685:mdna:66]
[same as prior period, unchanged from 0000950170-24-094602:mdna:65]

[0000950170-24-125685:mdna:67]
As a percentage of revenue, research and development expenses decreased from 23.0% for the three months ended September 30, 2023, to 22.7% for the three months ended September 30, 2024, and increased from 22.0% for the nine months ended September 30, 2023, to 25.3% for the nine months ended September 30, 2024. Research and development expenses as a percentage of revenue will generally fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared. We are still in the process of implementing our Business Efficiency Program, which we expect will lower research and development expense as a percentage of revenue over time.

[0000950170-24-125685:mdna:68]
Research and development expenses decreased 17.8% from $62.8 million for the three months ended September 30, 2023, to $51.6 million for the three months ended September 30, 2024, and decreased 15.3% from $203.5 million for the nine months ended September 30, 2023, to $172.3 million for the nine months ended September 30, 2024. The decrease in research and development expenses for the three months ended September 30, 2024, was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $5.6 million and contract services by $2.5 million. The decrease for the nine months ended September 30, 2024, was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $11.5 million and contract services by $6.7 million. For the three and nine months ended September 30, 2024, as compared to the three and nine months ended September 30, 2023, changes in foreign currencies relative to the U.S. dollar increased our research and development expenses by approximately $0.5 million and increased our research and development expenses by approximately $1.4 million, respectively.

[0000950170-24-125685:mdna:69]
Adtran Networks has arrangements with governmental entities for the purpose of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expenses incurred. For the three months ended September 30, 2024 and 2023, the Company recognized $2.5 million and $0.8 million as a reduction of research and development expense, respectively, and for the nine months ended September 30, 2024 and 2023, the Company recognized $6.6 million and $2.3 million as a reduction of research and development expense, respectively.

[0000950170-24-125685:mdna:70]
[same as prior period, unchanged from 0000950170-24-094602:mdna:69]

[0000950170-24-125685:mdna:71]
[same as prior period, unchanged from 0000950170-24-094602:mdna:70]

[0000950170-24-125685:mdna:72]
No goodwill impairment was recognized during the three months ended September 30, 2024. During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer focus on inventory adjustments, triggered a quantitative impairment assessment for our reporting units. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit during the nine months ended September 30, 2024.

[0000950170-24-125685:mdna:73]
During the third quarter of 2023, qualitative factors, such as a decrease in the Company's market capitalization and long-term projections, triggered a quantitative impairment assessment for our reporting units. The Company determined upon its quantitative impairment assessment to recognize a $37.9 million non-cash goodwill impairment charge for the Services & Support reporting unit. The Company did not recognize any impairment charges for the Network Solutions reporting unit during the nine months ended September 30, 2023. For additional information, see Note 8 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-24-125685:mdna:74]
[same as prior period, unchanged from 0000950170-24-094602:mdna:72]

[0000950170-24-125685:mdna:75]
Interest and dividend income increased from $0.5 million for the three months ended September 30, 2023, to $0.7 million for the three months ended September 30, 2024 and increased from $1.2 million for the nine months ended September 30, 2023, to $1.4 million for the nine months ended September 30, 2024. The increase in interest and dividend income is primarily attributable to fluctuations in investment balances and an increase in the rate of return on those investments due to interest rate movements.

[0000950170-24-125685:mdna:76]
[same as prior period, unchanged from 0000950170-24-094602:mdna:74]

[0000950170-24-125685:mdna:77]
Interest expense increased from $4.5 million for the three months ended September 30, 2023, to $5.7 million for the three months ended September 30, 2024, and increased from $11.9 million for the nine months ended September 30, 2023, to $17.2 million for the nine months ended September 30, 2024. The increase in interest expense during the three and nine months ended September 30, 2024, was primarily driven by higher amortization of debt issuance costs, as well as higher interest rates associated with the amendments of the Credit Agreement and higher average borrowings outstanding versus the three and nine months ending September 30, 2023. See Note 11 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-24-125685:mdna:78]
NET INVESTMENT GAIN (LOSS)

[0000950170-24-125685:mdna:79]
We recognized a net investment loss of $1.4 million for the three months ended September 30, 2023 and a net investment gain $1.4 million for the three months ended September 30, 2024 and recognized a net investment gain of $1.1 million and $4.5 million for the nine months ended September 30, 2023, and 2024, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See Note 5 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-24-125685:mdna:80]
[same as prior period, unchanged from 0000950170-24-094602:mdna:78]

[0000950170-24-125685:mdna:81]
Other (expense) income, net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, decreased from income of $2.5 million for the three months ended September 30, 2023 to expense of $0.9 million for the three months ended September 30, 2024 and decreased from income of $4.7 million for the nine months ended September 30, 2023 to expense of $0.4 million for the nine months ended September 30, 2024.

[0000950170-24-125685:mdna:82]
INCOME TAX (EXPENSE) BENEFIT

[0000950170-24-125685:mdna:83]
The Company's effective tax rate changed from a benefit of 18.0% of pre-tax loss for the three months ended September 30, 2023, to a expense of 1.4% of pre-tax loss for the three months ended September 30, 2024 and changed from a benefit of 19.2% of pre-tax loss for the nine months ended September 30, 2023, to a benefit of 3.9% of pre-tax loss for the nine months ended September 30, 2024. The changes in the effective tax rate for the three and nine months ended September 30, 2024, were driven primarily by non-deductible impairment charges and a loss jurisdiction for which no tax benefits were recognized on its pre-tax losses incurred during the nine months ended September 30, 2024.

[0000950170-24-125685:mdna:84]
[same as prior period, unchanged from 0000950170-24-094602:mdna:82]

[0000950170-24-125685:mdna:85]
As a result of the above factors, net loss attributable to ADTRAN Holdings, Inc. decreased from net loss of $78.2 million for the three months ended September 30, 2023, to a net loss of $31.2 million for the three months ended September 30, 2024, and increased from net loss of $156.7 million for the nine months ended September 30, 2023, to a net loss of $405.0 million for the nine months ended September 30, 2024.

[0000950170-24-125685:mdna:86]
[same as prior period, unchanged from 0000950170-24-094602:mdna:84]

[0000950170-24-125685:mdna:87]
We have historically financed our ongoing business with existing cash, investments and cash flow from operations; however, we have increasingly relied upon our credit arrangements to manage our working capital needs. We had a positive cash flow from operating activities of $88.4 million in the nine months ended September 30, 2024. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures.

[0000950170-24-125685:mdna:88]
As of September 30, 2024, our cash on hand was $88.5 million of which $62.6 million was held by our foreign subsidiaries. The Company had access to $205.6 million on its Credit Facility for future borrowings; however, as of September 30, 2024, the Company was limited to additional borrowings of $24.1 million based on debt covenant compliance metrics. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax. As of December 31, 2023, our cash on hand was $87.2 million, of which $73.0 million was held by our foreign subsidiaries.

[0000950170-24-125685:mdna:89]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.37% as of September 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.9 million or approximately $364.1 million, based on an exchange rate as of September 30, 2024, and reflecting interest accrued through September 30, 2024, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-125685:mdna:90]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million or $10.0 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024; therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three months ended September 30, 2024 and 2023, we accrued $2.4 million and $2.6 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2024 and 2023, we accrued $7.4 million and $7.6 million, respectively, in Annual Recurring Compensation which is reflected as an increase to retained deficit.

[0000950170-24-125685:mdna:91]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. The Company had access to $205.6 million on its Credit Facility for future borrowings; however, as of September 30, 2024, the Company was limited to additional borrowings of $24.1 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (or 4.0x to 3.5x during a Springing Covenant Period), and a Consolidated Fixed Charge Coverage Ratio of 1.25x. See Note 11, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

[0000950170-24-125685:mdna:92]
As of September 30, 2024, and as of the date of issuance of the condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. For the three and nine months ended September 30, 2024, approximately 830 thousand shares and 831 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on an exchange rate as of September 30, 2024, being paid to Adtran

[0000950170-24-125685:mdna:93]
Networks shareholders. For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, being paid to Adtran Networks shareholders.

[0000950170-24-125685:mdna:94]
As of September 30, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPTLA pertaining to Exit Compensation. While the Company did experience $17.4 million of redemptions in Q3 2024, we believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the diverse base of shareholders that must make this election on an individual shareholder basis, (ii) the fact that the Company expects to receive a procedural decision as a matter of law related to the current ongoing appraisal proceedings involving a dispute over the value of the Exit Compensation in 2024 or early 2025, after which the appeal process should take an additional 24-32 months to resolve, (iii) the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and (iv) the current trading value of Adtran Networks shares.

[0000950170-24-125685:mdna:95]
The Company experienced revenue declines in the year ended December 31, 2023, and during the three and nine months ended September 30, 2024. To the extent that the Company is further impacted by customers' inventory reduction initiatives and uncertain macroeconomic conditions, the Company is implementing plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a Business Efficiency Program, which includes, but is not limited to ongoing reductions in operating expenses and a site consolidation plan. In connection with the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditure and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

[0000950170-24-125685:mdna:96]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo Credit Facility (described below), will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and ability to continue to comply with our debt covenants under the Credit Facility for at least the next twelve months, from the issuance of these condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q. See Note 11, Revolving Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo Credit agreement and Notes to Condensed Consolidated Financial Statements included in Part I, Item, 1 for additional information regarding the terms of the Wells Fargo Credit Agreement, as amended.

[0000950170-24-125685:mdna:97]
Wells Fargo Credit Facility

[0000950170-24-125685:mdna:98]
On July 18, 2022, ADTRAN, Inc., as the borrower ("US Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (as amended from time to time, the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount ($100.0 million of which is available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below), as well as the $50.0 million delayed draw term loan facility described below. The term of the delayed draw term loan facility expired on August 9, 2024.

[0000950170-24-125685:mdna:99]
[same as prior period, unchanged from 0000950170-24-094602:mdna:97]

[0000950170-24-125685:mdna:100]
The First Amendment, among other things, increased the available funding from $100.0 million to $400.0 million. In addition, a new $50.0 million delayed draw term loan facility (“DDTL”) was introduced, which (subject to certain conditions) was available for borrowing in the event that at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date was tendered (such event, a “Springing Covenant Event”). Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During the Springing Covenant Period, the Company’s leverage ratios are increased. Although the ability to borrow under the DDTL expired on August 9, 2024, the Springing Covenant Event and Springing Covenant Period remain in effect.

[0000950170-24-125685:mdna:101]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-24-125685:mdna:102]
[same as prior period, unchanged from 0000950170-24-094602:mdna:160]

[0000950170-24-125685:mdna:103]
On January 16, 2024 ("Second Amendment Effective Date"), the Company and ADTRAN, Inc. entered into a Second Amendment to Credit Agreement and First Amendment to Collateral Agreement ("Second Amendment"). The Second Amendment, among other things, introduced the Covenant Relief Period, which provided the Company with additional covenant headroom while imposing a minimum liquidity financial covenant from the end of the fourth quarter of 2023 to the end of the third quarter of 2024. The Covenant Relief Period ended on November 7, 2024.

[0000950170-24-125685:mdna:104]
On March 12, 2024, the Company and ADTRAN, Inc. entered into a Third Amendment to Credit Agreement ("Third Amendment"). The Third Amendment, among other things, amended the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024, and June 30, 2024.

[0000950170-24-125685:mdna:105]
On June 4, 2024, the Company, ADTRAN, Inc., and Adtran Networks entered into a Fourth Amendment to Credit Agreement ("Fourth Amendment"). The Fourth Amendment, among other things, created a new sublimit under the existing $400.0 million revolving commitments, in an aggregate amount of $100.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold is initially $75.0 million and may be lowered from time to time pursuant to the terms of the Fourth Amendment. The existing swing line sublimit and letter of credit sublimit under the Credit Agreement remained available to the US Borrower (and not to Adtran Networks) after giving effect to the Fourth Amendment. Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

[0000950170-24-125685:mdna:106]
As of September 30, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $189.8 million, of which approximately $115.0 million were borrowed by ADTRAN, Inc. and $75.0 million were borrowed under the Subline by Adtran Networks. The credit facilities provided under the Credit Agreement mature in July 2027, but the US Borrower may request extensions subject to customary conditions. In addition, the US Borrower may utilize up to $50.0 million of the $400.0 million total revolving facility for the issuance of letters of credit. As of September 30, 2024, we had a total of $4.4 million in letters of credit under ADTRAN, Inc. outstanding under the Credit Agreement, leaving a net amount (after giving effect to the $189.8 million of outstanding borrowings described above) of $205.6 million available for future borrowings; however, as of September 30, 2024, the Company was limited to additional borrowings of $24.1 million based on debt covenant compliance metrics. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of September 30, 2024, the Company was in compliance with all covenants.

[0000950170-24-125685:mdna:107]
[same as prior period, unchanged from 0000950170-24-094602:mdna:104]

[0000950170-24-125685:mdna:108]
All U.S. dollar borrowings under the revolving line of credit other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin), at the Company’s option, at a rate per annum equal to either (a) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period (as defined below), an applicable margin of 2.15% per annum), or (b) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.15% per annum).

[0000950170-24-125685:mdna:109]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), or (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.

[0000950170-24-125685:mdna:110]
[same as prior period, unchanged from 0000950170-24-094602:mdna:107]

[0000950170-24-125685:mdna:111]
[same as prior period, unchanged from 0000950170-24-094602:mdna:108]

[0000950170-24-125685:mdna:112]
In addition, if on or prior to December 31, 2024, we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and if on or prior to June 30, 2025, we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-125685:mdna:113]
[same as prior period, unchanged from 0000950170-24-094602:mdna:110]

[0000950170-24-125685:mdna:114]
The “Applicable Margin Interest Period” means the period commencing on the Second Amendment Effective Date and ending on the first date when each of the following conditions have been met: (a) the Covenant Relief Period has ended (b) since the Second Amendment Effective Date, the borrowers have repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million (c) the borrowers have reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million, and (d) the borrowers are in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-24-125685:mdna:115]
[same as prior period, unchanged from 0000950170-24-094602:mdna:112]

[0000950170-24-125685:mdna:116]
Covenants Under the Credit Agreement

[0000950170-24-125685:mdna:117]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable):

[0000950170-24-125685:mdna:118]
[same as prior period, unchanged from 0000950170-24-094602:mdna:120]

[0000950170-24-125685:mdna:119]
[same as prior period, unchanged from 0000950170-24-094602:mdna:121]

[0000950170-24-125685:mdna:120]
•
In the fiscal quarter in which a Springing Covenant Event occurs and the three consecutive quarterly test periods thereafter, (“Springing Covenant Period”), the following covenant levels:

[0000950170-24-125685:mdna:121]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

[0000950170-24-125685:mdna:122]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

[0000950170-24-125685:mdna:123]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

[0000950170-24-125685:mdna:124]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

[0000950170-24-125685:mdna:125]
•
If a Springing Covenant Period is not in effect, the Consolidated Senior Secured Net Leverage Ratio may not exceed 3.25x.

[0000950170-24-125685:mdna:126]
[same as prior period, unchanged from 0000950170-24-094602:mdna:131]

[0000950170-24-125685:mdna:127]
•
During a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million.

[0000950170-24-125685:mdna:128]
All obligations under the Credit Agreement (including under the Subline) are guaranteed by ADTRAN, Inc., and certain subsidiaries of ADTRAN, Inc. (“Full Facility Guarantors”). To secure such guarantees, ADTRAN, Inc. and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and ADTRAN, Inc. has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries ("Subline Guarantors") have provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Adtran Networks has also granted security interests in favor of the Administrative Agent over substantially all of its tangible and intangible assets, to secure solely its obligations under the Subline. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

[0000950170-24-125685:mdna:129]
The Credit Agreement, as amended, contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.

[0000950170-24-125685:mdna:130]
[same as prior period, unchanged from 0000950170-24-094602:mdna:136]

[0000950170-24-125685:mdna:131]
Net cash provided by operating activities of $98.5 million during the nine months ended September 30, 2024, improved by $127.8 million compared to net cash used in operating activities of $29.3 million during the nine months ended September 30, 2023. The increase was primarily due to the declining net loss for the nine months ended September 30, 2024 and 2023, excluding the goodwill impairment charge of $292.6 million, as adjusted primarily for decreased depreciation and amortization, decreased deferred taxes and increased net cash inflows from working capital. Additional details related to our working capital and its drivers are discussed below.

[0000950170-24-125685:mdna:132]
Net accounts receivable decreased 20.5% from $216.4 million as of December 31, 2023, to $172.0 million as of September 30, 2024. There was an allowance for credit losses of $0.4 million as of September 30, 2024, and December 31, 2023. The decrease in net accounts receivable was due primarily to a reduction in DSO. Quarterly accounts receivable DSO decreased from 88 days as of December 31, 2023, to 70 days as of September 30, 2024 and was primarily driven by customer and geographical mix of commercial terms.

[0000950170-24-125685:mdna:133]
Other receivables decreased 26.3% from $17.5 million as of December 31, 2023, to $12.9 million as of September 30, 2024. The decrease in other receivables was primarily attributable to a decrease in sales of raw materials.

[0000950170-24-125685:mdna:134]
Quarterly inventory turnover was 2.07 turns as of December 31, 2023, and 2.0 turns as of September 30, 2024. Inventory decreased 21.9% from $362.3 million as of December 31, 2023, to $282.9 million as of September 30, 2024. The decrease in inventory was primarily due to steps taken in with our Business Efficiency Program to improve working capital, a reduction in component purchases due to improved lead time, utilization of buffer stock and a $4.1 million write down of inventory due to a restructuring discontinuation of certain product lines within our Network Solutions segment. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory for customer demand and improve working capital.

[0000950170-24-125685:mdna:135]
Accounts payable increase 6.4% from $162.9 million as of December 31, 2023, to $173.4 million as of September 30, 2024. The increase in accounts payable was primarily due to the timing of the receipt of inventory, supplies and services. Despite the increase in accounts payable, the average number of days payable to our trade suppliers remained flat at 67 days as of September 30, 2024 compared to December 31, 2023. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-24-125685:mdna:136]
[same as prior period, unchanged from 0000950170-24-094602:mdna:142]

[0000950170-24-125685:mdna:137]
Capital expenditures totaled approximately $48.2 million and $33.7 million for the nine months ended September 30, 2024 and 2023, respectively. These expenditures were primarily used to purchase software, computer hardware, manufacturing and test equipment, and building improvements. The increase in capital expenditures for the three and nine months ended September 30, 2024, is primarily attributable to increases in expenditures related to software and building renovation projects.

[0000950170-24-125685:mdna:138]
Our long-term investments increased 13.7% from $27.7 million as of December 31, 2023, to $31.5 million as of September 30, 2024. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $0.9 million as of September 30, 2024, and December 31, 2023. Long-term investments as of September 30, 2024, and December 31, 2023, also included $30.5 million and $26.8 million, respectively, related to our deferred compensation plans. See Note 5 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0000950170-24-125685:mdna:139]
[same as prior period, unchanged from 0000950170-24-094602:mdna:145]

[0000950170-24-125685:mdna:140]
During the nine months ended September 30, 2023, we paid dividends totaling $21.2 million. On November 6, 2023, the Board of Directors suspended the Company’s quarterly cash dividend in order to reduce debt and interest expense and support the Company's capital efficiency program. We consequently did not pay any dividends during the nine months ended September 30, 2024. The payment of any future dividends will be at the discretion of the Board of Directors and will depend on the Company’s financial condition, results of operations, capital requirements, and any other factors deemed relevant by the Board of Directors; however, the Wells Fargo Credit Agreement currently does not allow for the payment of dividends to shareholders. For additional information, see Note 11 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report and Liquidity & Capital Resources above.

[0000950170-24-125685:mdna:141]
[same as prior period, unchanged from 0000950170-24-094602:mdna:147]

[0000950170-24-125685:mdna:142]
There were no stock repurchases during the periods ended September 30, 2024, and 2023, and there currently is no authorized stock repurchase program.

[0000950170-24-125685:mdna:143]
[same as prior period, unchanged from 0000950170-24-094602:mdna:149]

[0000950170-24-125685:mdna:144]
To accommodate employee stock option exercises, the Company issued 36 thousand and 8 thousand shares of common stock which resulted in proceeds of $0.2 million and $0.1 million during the nine months ended September 30, 2024 and 2023, respectively. Additionally, to accommodate Adtran Networks stock option exercises, Adtran Networks issued 13 thousand shares of Adtran Networks common stock which resulted in proceeds of $0.1 million, for the nine months ended September 30, 2023. No Adtran Networks stock options were exercised during the nine months ended September 30, 2024. During the third quarter of 2024, all remaining Adtran Networks stock options were modified which resulted in the acceleration of vesting and conversion to liability based awards that were settled for cash totaling $0.2 million.

[0000950170-24-125685:mdna:145]
[same as prior period, unchanged from 0000950170-24-094602:mdna:151]

[0000950170-24-125685:mdna:146]
We maintain defined benefit pension plans covering employees in certain foreign countries. The Company's net non-current pension liability for all defined benefit pension plans totaled $12.1 million and $12.5 million as of September 30, 2024, and December 31, 2023, respectively and the net current pension liability for all defined benefit pension plans totaled $0.1 million as of September 30, 2024, and December 31, 2023, which is included in accounts payable on the Condensed Consolidated Balance Sheets. For additional information, see Note 12 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-24-125685:mdna:147]
[same as prior period, unchanged from 0000950170-24-094602:mdna:153]

[0000950170-24-125685:mdna:148]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors. The fair value of the assets held by the deferred compensation programs totaled $30.5 million and $26.8 million as of September 30, 2024, and December 31, 2023, respectively, and is included in long-term investments on the Condensed Consolidated Balance Sheets. The amounts payable to the deferred compensation program participants totaled $32.0 million and $29.0 million as of September 30, 2024, and December 31, 2023, respectively. For additional information, see Note 5 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-24-125685:mdna:149]
[same as prior period, unchanged from 0000950170-24-094602:mdna:155]

[0000950170-24-125685:mdna:150]
We have exposure to credit losses from off-balance sheet exposures, to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of September 30, 2024. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 18 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-125685:mdna:151]
[same as prior period, unchanged from 0000950170-24-094602:mdna:157]

[0000950170-24-125685:mdna:152]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of September 30, 2024, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA and currency hedging arrangements, which are discussed below). Other than operating lease obligations, the cash requirements table excludes interest payments.

[0000950170-24-125685:mdna:153]
| (In thousands) |  | Total |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | 2028 |  |  | Thereafter |  |
| Wells Fargo credit agreement(1) |  | $ | 189,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 189,849 |  |  | $ | — |  |  | $ | — |  |
| Purchase obligations(2) |  |  | 261,839 |  |  |  | 206,150 |  |  |  | 48,942 |  |  |  | 6,400 |  |  |  | 55 |  |  |  | 292 |  |  |  | — |  |
| Operating lease obligations(3) |  |  | 39,583 |  |  |  | 2,401 |  |  |  | 8,574 |  |  |  | 6,577 |  |  |  | 5,071 |  |  |  | 4,606 |  |  |  | 12,354 |  |
| Totals |  | $ | 491,271 |  |  | $ | 208,551 |  |  | $ | 57,516 |  |  | $ | 12,977 |  |  | $ | 194,975 |  |  | $ | 4,898 |  |  | $ | 12,354 |  |

[0000950170-24-125685:mdna:154]
[same as prior period, unchanged from 0000950170-24-094602:mdna:161]

[0000950170-24-125685:mdna:155]
(2) We have purchase obligations related to open purchase orders to our contract manufacturers, ODMs, component suppliers, service

[0000950170-24-125685:mdna:156]
[same as prior period, unchanged from 0000950170-24-094602:mdna:164]

[0000950170-24-125685:mdna:157]
[same as prior period, unchanged from 0000950170-24-094602:mdna:165]

[0000950170-24-125685:mdna:158]
[same as prior period, unchanged from 0000950170-24-094602:mdna:166]

[0000950170-24-125685:mdna:159]
(3) We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international

[0000950170-24-125685:mdna:160]
locations. Our operating leases had remaining lease terms ranging from 3 months to 170 months as of September 30, 2024.

[0000950170-24-125685:mdna:161]
[same as prior period, unchanged from 0000950170-24-094602:mdna:169]

[0000950170-24-125685:mdna:162]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into the Credit Agreement with the Administrative Agent and the other lenders named therein. The Credit Agreement was subsequently amended on August 9, 2023, January 16, 2024, March 12, 2024, and June 4, 2024. As of September 30, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $189.8 million. The Credit Facility matures in July 2027; however, the Company may request extensions subject to customary conditions. See Note 11 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report and “Liquidity and Capital Resources” in Part I, Item 2 of this report for additional information.

[0000950170-24-125685:mdna:163]
[same as prior period, unchanged from 0000950170-24-094602:mdna:171]

[0000950170-24-125685:mdna:164]
On November 3, 2022, the Company entered into a euro/U.S. dollar forward contract arrangement ("Initial Forward") with Wells Fargo Bank, N.A. (“Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enabled the Company to convert a portion of its euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million converted to U.S. dollars at a daily fixed forward rate ranging from approximately EUR/USD 0.98286 to 1.03290. The aggregate amount of €160.0 million was divided into eight quarterly tranches of €20.0 million, which commenced in the fourth quarter of 2022. During the nine months ended September 30, 2024, the Company settled three €20.0 million forward contract tranches, leaving the remaining tranche of €20.0 million to be settled in the fourth quarter of 2024. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-24-125685:mdna:165]
On March 21, 2023, the Company entered into a euro/U.S. dollar forward contract arrangements (“Forward”) with the Hedge Counterparty. Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company exchanged an aggregate notional amount of €160.0 million converted to U.S. dollars at an average rate of EUR/USD 1.085. During the nine months ended September 30, 2024, the Company settled three €20.0 million forward contract tranches, leaving the remaining tranche of €20.0 million to be settled in the fourth quarter of 2024. These forward contracts were executed to sell EUR and to buy USD and were entered into for the purpose of unwinding the Initial Forward to buy EUR and to sell USD. The drawdown dates of the Initial Forward are set to the same date as the maturity of the offsetting Forward.

[0000950170-24-125685:mdna:166]
[same as prior period, unchanged from 0000950170-24-094602:mdna:174]

[0000950170-24-125685:mdna:167]
On July 1, 2024, the Company entered into a Factoring Agreement with the Factor, which accelerates receivable collection and helps to better manage cash flow. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. Total accounts receivables factored as of the end of September 30, 2024, totaled $16.7 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. See Note 1 and Note 2 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-125685:mdna:168]
On December 19, 2023, the Company entered into the Prior Factoring Agreement with a third-party financial institution which qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidation. The Prior Factoring Agreement was terminated on July 1, 2024. See Note 1 and Note 2 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-125685:mdna:169]
[same as prior period, unchanged from 0000950170-24-094602:mdna:177]

[0000950170-24-125685:mdna:170]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE ("Adtran Networks"), as the controlled company, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-24-125685:mdna:171]
[same as prior period, unchanged from 0000950170-24-094602:mdna:179]

[0000950170-24-125685:mdna:172]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.37% as of September 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.9 million or approximately $364.1 million, based on an exchange rate as of September 30, 2024, and reflecting interest accrued through September 30, 2024, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-125685:mdna:173]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million or $10.0 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three months ended September 30, 2024 and 2023, we accrued $2.4 million and $2.6 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2024 and 2023, we accrued $7.4 million and $7.6 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.

[0000950170-24-125685:mdna:174]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and nine months ended September 30, 2024, approximately 830 thousand shares and 831 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on an exchange rate as of September 30, 2024, being paid to Adtran Networks shareholders. For the three months and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, being paid to Adtran Networks shareholders.

[0000950170-24-125685:mdna:175]
We currently hold 34,855,921 no-par value bearer shares of Adtran Networks, representing 67.0% of Adtran Networks outstanding shares as of September 30, 2024.

[0000950170-24-125685:mdna:176]
[same as prior period, unchanged from 0000950170-24-094602:mdna:184]

[0000950170-24-125685:mdna:177]
[same as prior period, unchanged from 0000950170-24-094602:mdna:185]

[0000950170-24-125685:mdna:178]
[same as prior period, unchanged from 0000950170-24-094602:mdna:24]

[0000950170-24-125685:mdna:179]
During the three and nine months ended September 30, 2024, we recognized $5.9 million and $40.6 million of costs related to the Business Efficiency Program, respectively. The costs recognized during the nine months ended September 30, 2024, included charges of $8.6 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.1 million relates to inventory write-downs and $4.6 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss. Since the inception of the Business Efficiency Program, we recognized $65.6 million of costs. We expect costs in the fourth quarter 2024 relating to the Business Efficiency Program to range between $9.6 million and $13.8 million. Management expects these planned costs to include severance costs to be approximately $6.2 million in connection with reductions in workforce and site consolidation transaction expenses (primarily brokers fees and Greifswald exit costs) ranging from $3.4 million to $7.6 million. The broker fees related to our site consolidation expenses will be netted against proceeds upon the sale of the building(s). Future cash payments include: severance costs and outplacement fees that are anticipated to be in the range of $23.1 million to $23.1 million and payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $3.4 million to $7.6 million. We do not anticipate any remaining payments related to the inventory strategy shift. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures.  However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing. If required, we will amend this disclosure at such time as management is able in good faith to estimate the amount, or range of amounts, of these charges.

[0000950170-24-125685:mdna:180]
[same as prior period, unchanged from 0000950170-24-094602:mdna:189]

[0000950170-24-125685:mdna:181]
During the three and nine months ended September 30, 2024 and 2023, we recognized $0.4 million and $1.4 million, and $1.7 million and $3.1 million of integration costs related to the Business Combination, respectively, that are included in selling, general and administrative expenses, research & development expenses and cost of revenue in the Condensed Consolidated Statement of Loss. We expect to incur additional integration costs and expenses associated with the implementation of the DPLTA throughout 2024 and such costs are expected to be material. See Note 19 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-125685:mdna:182]
[same as prior period, unchanged from 0000950170-24-094602:mdna:194]

[0000950170-24-125685:mdna:183]
During the nine months ended September 30, 2024, other than the Exit Compensation payments, Annual Recurring Compensation under the DPLTA, restructuring costs and increased debt service costs, there have been no other material changes in cash requirements from those discussed in the 2023 Form 10-K and our cash requirements table shown in Liquidity and Capital Resources above.

[0000950170-24-125685:mdna:184]
[same as prior period, unchanged from 0000950170-24-094602:mdna:196]

[0000950170-24-125685:mdna:185]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2024, and December 31, 2023, we had commitments related to these bonds totaling $14.6 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-24-125685:mdna:186]
[same as prior period, unchanged from 0000950170-24-094602:mdna:198]

[0000950170-24-125685:mdna:187]
[same as prior period, unchanged from 0000950170-24-094602:mdna:199]

[0000950170-24-125685:mdna:188]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part I, Item 1 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the critical accounting policies affect our more significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements. During the nine months ended September 30, 2024, there were no significant changes to our critical accounting policies and estimates as described in the financial statements contained in the 2023 Form 10-K, except for goodwill as discussed below.

[0000950170-24-125685:mdna:189]
[same as prior period, unchanged from 0000950170-24-094602:mdna:201]

[0000950170-24-125685:mdna:190]
[same as prior period, unchanged from 0000950170-24-094602:mdna:202]

[0000950170-24-125685:mdna:191]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of the Network Solutions reporting unit using a combination of an income approach and a market-based peer group analysis. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit during the first quarter of 2024. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the first quarter of 2024.

[0000950170-24-125685:mdna:192]
During the third quarter of 2024, the Company qualitatively assessed the carrying value of our Services & Support reporting unit for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Based on our assessment of certain qualitative factors such as macroeconomic conditions, industry and market considerations, cost factors and overall financial performance, management concluded that the fair value of the Services & Support reporting unit was more likely than not greater than its carrying amount as of September 30, 2024. Therefore, no impairment of goodwill was recorded during the three months ended September 30, 2024. Our Network Solutions reporting unit had no remaining goodwill and our Services & Support reporting unit had $56.9 million of goodwill as of September 30, 2024, respectively.
