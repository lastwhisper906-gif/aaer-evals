# ADTN 8-K — 0000950170-24-122762 filed 2024-11-07

## item codes, every 8-K on or before 2024-11-12

- 2024-11-07 0000950170-24-122762 — 2.02, 7.01, 9.01
- 2024-08-30 0000950170-24-102309 — 5.02, 9.01
- 2024-08-06 0000950170-24-091207 — 2.02, 7.01, 9.01
- 2024-08-02 0000950170-24-089974 — 5.02
- 2024-06-10 0001193125-24-158388 — 1.01, 2.03, 9.01
- 2024-05-09 0000950170-24-056830 — 5.02, 5.07, 9.01
- 2024-05-07 0000950170-24-053920 — 2.02, 7.01, 9.01
- 2024-05-03 0001193125-24-130896 — 2.02, 7.01, 9.01
- 2024-04-17 0000950170-24-045151 — 2.05, 9.01
- 2024-03-15 0000950170-24-031864 — 2.02, 9.01
- 2024-02-27 0000950170-24-020613 — 2.02, 7.01, 9.01
- 2024-02-20 0001193125-24-040068 — 4.02
- 2024-01-22 0001193125-24-011697 — 1.01, 2.03, 9.01
- 2023-12-06 0001193125-23-289895 — 5.02, 9.01
- 2023-12-05 0001193125-23-289150 — 5.02, 9.01
- 2023-11-07 0001193125-23-271842 — 2.02, 7.01, 9.01
- 2023-10-24 0001193125-23-261665 — 5.02, 5.03, 9.01
- 2023-10-17 0001193125-23-257289 — 2.02, 7.01, 9.01
- 2023-09-29 0001193125-23-246498 — 5.02
- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2024-11-12

- 2024-02-29 0000950170-24-023141 — NT 10-K, for the period ended 2023-12-31
- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-24-122762:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0000950170-24-122762:8k_2_02:2]
EX-99.1

[0000950170-24-122762:8k_2_02:3]
EXHIBIT 99.1

[0000950170-24-122762:8k_2_02:4]
ADTRAN Holdings, Inc. reports preliminary third quarter 2024 financial results

[0000950170-24-122762:8k_2_02:5]
Huntsville, Alabama, USA. — November 06, 2024 — ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” or the “Company”) today announced its preliminary unaudited financial results for the third quarter of 2024.

[0000950170-24-122762:8k_2_02:6]
•
Revenue: $227.7 million, up sequentially and above the mid-point of guidance.

[0000950170-24-122762:8k_2_02:7]
•
Gross margin: GAAP gross margin: 37.4%; Non-GAAP gross margin: 42.1%, a sequential increase of 134 and 17 basis points, respectively.

[0000950170-24-122762:8k_2_02:8]
•
Operating margin: GAAP operating margin negative 10.5% up sequentially; Non-GAAP operating margin positive 1.1%, up sequentially and above the mid-point of guidance.

[0000950170-24-122762:8k_2_02:9]
•
GAAP diluted loss per share of $0.36; Non-GAAP diluted loss per share $0.05.

[0000950170-24-122762:8k_2_02:10]
ADTRAN Holdings’ Chairman and Chief Executive Officer Tom Stanton stated, “We delivered higher sequential revenue and expanded gross and operating margins in the third quarter. Importantly, we are seeing improvements in our key end markets as we continue to grow our customer base. With the gradual recovery in service provider spending, the success we are having in customer acquisition, and encouraging booking trends, we expect sequential revenue growth to continue in the fourth quarter. This outlook, coupled with improving visibility, gives us confidence our end-markets should continue to improve.”

[0000950170-24-122762:8k_2_02:11]
“ADTRAN remains well-positioned for sustainable and profitable growth as customer inventory levels normalize,” added Mr. Stanton. “The continued trend to increase fiber access and optical transport, combined with the ongoing transition from higher risk vendors to providers like ADTRAN, serve as durable secular catalysts. As we grow, we are confident we can unlock meaningful operational leverage, driving accelerated profitability and increased cash generation.”

[0000950170-24-122762:8k_2_02:12]
Business Outlook1

[0000950170-24-122762:8k_2_02:13]
For the fourth quarter of 2024, the Company expects revenue to be within a range of $230 million to $245 million. Non-GAAP operating margin is expected to be within a range of 0% to 4%.

[0000950170-24-122762:8k_2_02:14]
1GAAP earnings guidance is not provided. Please see the Explanation of Use of Non-GAAP Financial Measures at the end of this press release for an explanation regarding the Company’s omission of both GAAP earnings guidance and the applicable reconciliation table. In addition, please see the Explanation of Use of Non-GAAP Financial Measures and the Supplemental Information Reconciliations of non-GAAP financial measures to the most directly comparable GAAP measures at the end of this press release for detailed information on calculating the non-GAAP measures referenced herein.

[0000950170-24-122762:8k_2_02:15]
The Company will hold a conference call to discuss its preliminary third quarter results on Thursday, November 07, 2024, at 9:30 a.m. Central Time, or 4:30 p.m. Central European Time. The Company will webcast this conference call. To listen, simply visit our Investor Relations site at investors.adtran.com approximately 10 minutes prior to the start of the call, click on the event “ADTRAN Holdings Releases 3rd Quarter 2024 Financial Results and Earnings Call”, and click on the webcast link.

[0000950170-24-122762:8k_2_02:16]
An online replay of the Company’s conference call, as well as the transcript of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit investors.adtran.com or email investor.relations@adtran.com.

[0000950170-24-122762:8k_2_02:17]
About Adtran

[0000950170-24-122762:8k_2_02:18]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network

[0000950170-24-122762:8k_2_02:19]
infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises, government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the largest shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE. Find more at Adtran, LinkedIn and Twitter.

[0000950170-24-122762:8k_2_02:20]
Cautionary Note Regarding Forward-Looking Statements

[0000950170-24-122762:8k_2_02:21]
Additionally, the financial measures presented herein are preliminary estimates, remain subject to our internal controls and procedures, and are subject to risks and uncertainties, including, among others, changes in connection with quarter-end adjustments. Any variation between the Company’s actual results and the preliminary financial information set forth herein may be material.

[0000950170-24-122762:8k_2_02:22]
Explanation of Use of Non-GAAP Financial Measures

[0000950170-24-122762:8k_2_02:23]
Set forth in the tables below are reconciliations of gross profit, gross margin, operating expenses, operating loss, other (expense) income, net loss inclusive of the non-controlling interest, net loss attributable to the Company, net income attributable to the non-controlling interest, and loss per share - basic and diluted, attributable to the Company, and net cash provided by (used in) operating activities, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income (loss), non-GAAP other expense, non-GAAP net loss inclusive of the non-controlling interest, non-GAAP net loss attributable to the Company, non-GAAP net income attributable to the non-controlling interest, non-GAAP loss per share - basic and diluted, attributable to the Company, respectively, and non-GAAP free cash flow. Such non-GAAP measures exclude acquisition-related expenses, amortization and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments as well as legal and advisory fees related to a potential significant transaction), stock-based compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, integration expenses, restructuring expenses,  goodwill impairments, the tax effect of these adjustments to net loss and purchases of property, plant and equipment. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of these non-GAAP measures, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company.  1Non-GAAP operating margin (which is calculated as non-GAAP operating loss divided by revenue) is a non-GAAP financial measure. The Company has provided fourth quarter guidance with regard to non-GAAP operating margin. This measure excludes from the corresponding GAAP financial measure the effect of adjustments as described below. The Company has not provided a reconciliation of such non-GAAP guidance to guidance presented on a GAAP basis because it cannot predict and quantify without unreasonable effort all of the adjustments that may occur during the period due to the difficulty of predicting the timing and amounts of various items within a reasonable range. In particular, non-GAAP operating margin excludes certain items, including continued restructuring expenses, that will continue to evolve as our business efficiency program is implemented that the Company is unable to quantitatively predict. Depending on the materiality of these items, they could have a significant impact on the Company's GAAP financial results.

[0000950170-24-122762:8k_2_02:24]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0000950170-24-122762:8k_2_02:25]
Published by

[0000950170-24-122762:8k_2_02:26]
ADTRAN Holdings, Inc.

[0000950170-24-122762:8k_2_02:27]
www.adtran.com

[0000950170-24-122762:8k_2_02:28]
For media

[0000950170-24-122762:8k_2_02:29]
Gareth Spence

[0000950170-24-122762:8k_2_02:30]
+44 1904 699 358

[0000950170-24-122762:8k_2_02:31]
public.relations@adtran.com

[0000950170-24-122762:8k_2_02:32]
For investors

[0000950170-24-122762:8k_2_02:33]
Peter Schuman

[0000950170-24-122762:8k_2_02:34]
+1 650 743 7948

[0000950170-24-122762:8k_2_02:35]
investor.relations@adtran.com

[0000950170-24-122762:8k_2_02:36]
Condensed Consolidated Balance Sheets

[0000950170-24-122762:8k_2_02:37]
(Preliminary, Unaudited)

[0000950170-24-122762:8k_2_02:38]
(In thousands)

[0000950170-24-122762:8k_2_02:39]
|  | September 30, |  |  | December 31, |  |
|  | 2024 |  |  | 2023 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 88,456 |  |  | $ | 87,167 |  |
| Accounts receivable, net |  | 172,025 |  |  |  | 216,445 |  |
| Other receivables |  | 12,871 |  |  |  | 17,450 |  |
| Income tax receivable |  | 13,466 |  |  |  | 7,933 |  |
| Inventory, net |  | 282,926 |  |  |  | 362,295 |  |
| Prepaid expenses and other current assets |  | 69,112 |  |  |  | 45,566 |  |
| Total Current Assets |  | 638,856 |  |  |  | 736,856 |  |
| Property, plant and equipment, net |  | 147,428 |  |  |  | 123,020 |  |
| Deferred tax assets |  | 25,697 |  |  |  | 25,787 |  |
| Goodwill |  | 56,884 |  |  |  | 353,415 |  |
| Intangibles, net |  | 286,098 |  |  |  | 327,985 |  |
| Other non-current assets |  | 86,677 |  |  |  | 87,706 |  |
| Long-term investments |  | 31,506 |  |  |  | 27,743 |  |
| Total Assets | $ | 1,273,146 |  |  | $ | 1,682,512 |  |
| Liabilities, Redeemable Non-Controlling Interest and Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 173,354 |  |  | $ | 162,922 |  |
| Unearned revenue |  | 54,615 |  |  |  | 46,731 |  |
| Accrued expenses and other liabilities |  | 34,482 |  |  |  | 36,204 |  |
| Accrued wages and benefits |  | 40,366 |  |  |  | 27,030 |  |
| Income tax payable, net |  | 2,007 |  |  |  | 5,221 |  |
| Total Current Liabilities |  | 304,824 |  |  |  | 278,108 |  |
| Non-current revolving credit agreement outstanding |  | 189,849 |  |  |  | 195,000 |  |
| Deferred tax liabilities |  | 21,483 |  |  |  | 35,655 |  |
| Non-current unearned revenue |  | 24,901 |  |  |  | 25,109 |  |
| Non-current pension liability |  | 12,149 |  |  |  | 12,543 |  |
| Deferred compensation liability |  | 32,046 |  |  |  | 29,039 |  |
| Non-current lease obligations |  | 25,635 |  |  |  | 31,420 |  |
| Other non-current liabilities |  | 26,489 |  |  |  | 28,657 |  |
| Total Liabilities |  | 637,376 |  |  |  | 635,531 |  |
| Redeemable Non-Controlling Interest |  | 421,776 |  |  |  | 442,152 |  |
| Equity |  |  |  |  |  |
| Common stock |  | 792 |  |  |  | 790 |  |
| Additional paid-in capital |  | 806,187 |  |  |  | 795,304 |  |
| Accumulated other comprehensive income |  | 47,377 |  |  |  | 47,465 |  |
| Retained deficit |  | (635,164 | ) |  |  | (232,905 | ) |
| Treasury stock |  | (5,198 | ) |  |  | (5,825 | ) |
| Total Equity |  | 213,994 |  |  |  | 604,829 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity | $ | 1,273,146 |  |  | $ | 1,682,512 |  |

[0000950170-24-122762:8k_2_02:40]
Condensed Consolidated Statements of Loss

[0000950170-24-122762:8k_2_02:41]
(Preliminary, Unaudited)

[0000950170-24-122762:8k_2_02:42]
(In thousands, except per share amounts)

[0000950170-24-122762:8k_2_02:43]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 181,488 |  |  | $ | 228,564 |  |  | $ | 541,955 |  |  | $ | 793,984 |  |  |
| Services & Support |  |  | 46,216 |  |  |  | 43,767 |  |  |  | 137,913 |  |  |  | 129,637 |  |  |
| Total Revenue |  |  | 227,704 |  |  |  | 272,331 |  |  |  | 679,868 |  |  |  | 923,621 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 126,103 |  |  |  | 160,244 |  |  |  | 376,886 |  |  |  | 596,334 |  |  |
| Network Solutions - other (credits), charges and inventory write-down |  |  | (328 | ) |  |  | 21,043 |  |  |  | 8,597 |  |  |  | 21,043 |  |  |
| Services & Support |  |  | 16,678 |  |  |  | 16,807 |  |  |  | 55,304 |  |  |  | 51,646 |  |  |
| Total Cost of Revenue |  |  | 142,453 |  |  |  | 198,094 |  |  |  | 440,787 |  |  |  | 669,023 |  |  |
| Gross Profit |  |  | 85,251 |  |  |  | 74,237 |  |  |  | 239,081 |  |  |  | 254,598 |  |  |
| Selling, general and administrative expenses |  |  | 57,620 |  |  |  | 62,907 |  |  |  | 176,214 |  |  |  | 196,887 |  |  |
| Research and development expenses |  |  | 51,615 |  |  |  | 62,752 |  |  |  | 172,253 |  |  |  | 203,493 |  |  |
| Goodwill impairment |  |  | — |  |  |  | 37,874 |  |  |  | 292,583 |  |  |  | 37,874 |  |  |
| Operating Loss |  |  | (23,984 | ) |  |  | (89,296 | ) |  |  | (401,969 | ) |  |  | (183,656 | ) |  |
| Interest and dividend income |  |  | 664 |  |  |  | 521 |  |  |  | 1,427 |  |  |  | 1,183 |  |  |
| Interest expense |  |  | (5,679 | ) |  |  | (4,507 | ) |  |  | (17,183 | ) |  |  | (11,858 | ) |  |
| Net investment gain (loss) |  |  | 1,382 |  |  |  | (1,443 | ) |  |  | 4,507 |  |  |  | 1,071 |  |  |
| Other (expense) income, net |  |  | (850 | ) |  |  | 2,523 |  |  |  | (441 | ) |  |  | 4,714 |  |  |
| Loss Before Income Taxes |  |  | (28,467 | ) |  |  | (92,202 | ) |  |  | (413,659 | ) |  |  | (188,546 | ) |  |
| Income tax (expense) benefit |  |  | (390 | ) |  |  | 16,553 |  |  |  | 16,121 |  |  |  | 36,229 |  |  |
| Net Loss |  | $ | (28,857 | ) |  | $ | (75,649 | ) |  | $ | (397,538 | ) |  | $ | (152,317 | ) |  |
| Less: Net (Loss) Income attributable to non-controlling interest |  |  | 2,382 |  |  |  | 2,561 |  |  |  | 7,417 |  |  |  | 4,380 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (31,239 | ) |  | $ | (78,210 | ) |  | $ | (404,955 | ) |  | $ | (156,697 | ) |  |
| Weighted average shares outstanding – basic |  |  | 78,952 |  |  |  | 78,389 |  |  |  | 78,873 |  |  |  | 78,378 |  |  |
| Weighted average shares outstanding – diluted |  |  | 78,952 |  |  |  | 78,389 |  |  |  | 78,873 |  |  |  | 78,378 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.36 | ) | (1) | $ | (1.00 | ) |  | $ | (5.10 | ) | (1) | $ | (2.00 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.36 | ) | (1) | $ | (1.00 | ) |  | $ | (5.10 | ) | (1) | $ | (2.00 | ) |  |

[0000950170-24-122762:8k_2_02:44]
(1) Loss per common share attributable to ADTRAN Holdings, Inc. reflects $3.0 million gain on redemption of redeemable non-controlling interest for the three and nine months ended September 30, 2024.

[0000950170-24-122762:8k_2_02:45]
Condensed Consolidated Statements of Cash Flows

[0000950170-24-122762:8k_2_02:46]
(Preliminary, Unaudited)

[0000950170-24-122762:8k_2_02:47]
(In thousands)

[0000950170-24-122762:8k_2_02:48]
|  |  | Nine Months Ended |  |
|  |  | September 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net loss |  | $ | (397,538 | ) |  | $ | (152,317 | ) |
| Adjustments to reconcile net loss to net cash provided by (used in) operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 68,421 |  |  |  | 91,422 |  |
| Goodwill impairment |  |  | 292,583 |  |  |  | 37,874 |  |
| Amortization of debt issuance cost |  |  | 1,013 |  |  |  | 607 |  |
| Gain on investments, net |  |  | (4,238 | ) |  |  | (3,316 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 203 |  |  |  | — |  |
| Stock-based compensation expense |  |  | 11,417 |  |  |  | 12,229 |  |
| Deferred income taxes |  |  | (13,399 | ) |  |  | (45,941 | ) |
| Other, net |  |  | (267 | ) |  |  | 204 |  |
| Inventory write down - business efficiency program |  |  | 4,135 |  |  |  | 21,043 |  |
| Inventory reserves |  |  | 6,667 |  |  |  | 29,836 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 59,446 |  |  |  | 47,347 |  |
| Other receivables |  |  | 4,875 |  |  |  | 8,340 |  |
| Income taxes receivable, net |  |  | (5,682 | ) |  |  | — |  |
| Inventory |  |  | 69,412 |  |  |  | 536 |  |
| Prepaid expenses, other current assets and other assets |  |  | (20,083 | ) |  |  | 1,816 |  |
| Accounts payable |  |  | 9,697 |  |  |  | (87,903 | ) |
| Accrued expenses and other liabilities |  |  | 15,039 |  |  |  | 6,476 |  |
| Income taxes payable, net |  |  | (3,175 | ) |  |  | 2,433 |  |
| Net cash provided by (used in) operating activities |  |  | 98,526 |  |  |  | (29,314 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (48,183 | ) |  |  | (33,674 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 1,195 |  |  |  | 10,545 |  |
| Purchases of available-for-sale investments |  |  | (195 | ) |  |  | (807 | ) |
| Proceeds from beneficial interests in securitized accounts receivable |  |  | 282 |  |  |  | 1,178 |  |
| Net cash used in investing activities |  |  | (46,901 | ) |  |  | (22,758 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (189 | ) |  |  | (6,331 | ) |
| Proceeds from stock option exercises |  |  | 219 |  |  |  | 187 |  |
| Dividend payments |  |  | — |  |  |  | (21,237 | ) |
| Proceeds from receivables purchase agreement |  |  | 68,556 |  |  |  | — |  |
| Repayments on receivables purchase agreement |  |  | (83,772 | ) |  |  | — |  |
| Proceeds from draw on revolving credit agreements |  |  | — |  |  |  | 163,760 |  |
| Repayment of revolving credit agreements |  |  | (5,000 | ) |  |  | (49,233 | ) |
| Payment for redemption of redeemable non-controlling interest |  |  | (17,395 | ) |  |  | (1,196 | ) |
| Payment for annual recurring compensation to non-controlling interest |  |  | (10,084 | ) |  |  | — |  |
| Payment of debt issuance cost |  |  | (1,994 | ) |  |  | (708 | ) |
| Repayment of notes payable |  |  | — |  |  |  | (24,931 | ) |
| Net cash (used in) provided by financing activities |  |  | (49,659 | ) |  |  | 60,311 |  |
| Net increase in cash and cash equivalents |  |  | 1,966 |  |  |  | 8,239 |  |
| Effect of exchange rate changes |  |  | (677 | ) |  |  | (791 | ) |
| Cash and cash equivalents, beginning of period |  |  | 87,167 |  |  |  | 108,644 |  |
| Cash and cash equivalents, end of period |  | $ | 88,456 |  |  | $ | 116,092 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 18,225 |  |  | $ | 8,540 |  |
| Cash paid for income taxes |  | $ | 9,122 |  |  | $ | — |  |
| Cash used in operating activities related to operating leases |  | $ | 7,380 |  |  | $ | 7,378 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 2,122 |  |  | $ | 8,490 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 952 |  |  | $ | 2,508 |  |

[0000950170-24-122762:8k_2_02:49]
Revision of Previously Issued Condensed Consolidated Financial Statements

[0000950170-24-122762:8k_2_02:50]
Following the third quarter of 2024, the Company identified errors primarily impacting the carrying values of the redeemable non-controlling interest, retained deficit, the net income attributable to the non-controlling interest and the net loss attributable to the Company and, as a consequence, of the loss per common share attributable to the Company. The Company has evaluated the errors and determined that the related impacts were not material to the previously issued consolidated financial statements for any prior period. A summary of the corrections to the Company's Condensed Consolidated Financial Statements for the periods ended March 31, 2023, June 30, 2023, September 30, 2023, December 31, 2023, March 31, 2024 and June 30, 2024, is as follows:

[0000950170-24-122762:8k_2_02:51]
(a)
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) is entitled to receive from us an Annual Recurring Compensation payment of €0.52 per share. The Company erroneously accrued this liability every quarter at €0.59 per share, overstating the associated accrual, the net income attributable to non-controlling interest and the net loss attributable to ADTRAN Holdings, Inc. for fiscal periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024.

[0000950170-24-122762:8k_2_02:52]
(b)
For the periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024 the Company remeasured the redeemable non-controlling interest each quarter-end at the current exchange rate of Euros to U.S. Dollar. The Company treated the redeemable non-controlling interest as a monetary mezzanine equity instrument but should have treated it as a non-monetary mezzanine equity instrument not subject to remeasurement.

[0000950170-24-122762:8k_2_02:53]
For additional information, please see our Note 1 to the Condensed Consolidated Financial Statements set forth in the Form 10-Q for the quarterly period ended September 30, 2024 to be filed with the SEC.

[0000950170-24-122762:8k_2_02:54]
Supplemental Information

[0000950170-24-122762:8k_2_02:55]
Reconciliation of Preliminary Gross Profit and Preliminary Gross Margin to

[0000950170-24-122762:8k_2_02:56]
Preliminary Non-GAAP Gross Profit and Preliminary Non-GAAP Gross Margin

[0000950170-24-122762:8k_2_02:57]
(Unaudited)

[0000950170-24-122762:8k_2_02:58]
(In thousands)

[0000950170-24-122762:8k_2_02:59]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |
|  |  | September 30, 2024 |  |  | June 30, 2024 |  |  | September 30, 2023 |  |  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| Total Revenue |  | $ | 227,704 |  |  | $ | 225,991 |  |  | $ | 272,331 |  |  |  | $ | 679,868 |  |  | $ | 923,621 |  |
| Cost of Revenue |  | $ | 142,453 |  |  | $ | 144,416 |  |  | $ | 198,094 |  |  |  | $ | 440,787 |  |  | $ | 669,023 |  |
| Acquisition-related expenses, amortizations and adjustments(1) |  |  | (10,276 | ) |  |  | (10,064 | ) |  |  | (13,537 | ) |  |  |  | (30,517 | ) |  |  | (79,554 | ) |
| Stock-based compensation expense |  |  | (270 | ) |  |  | (280 | ) |  |  | (279 | ) |  |  |  | (825 | ) |  |  | (854 | ) |
| Restructuring expenses(2) |  |  | (7 | ) |  |  | (2,788 | ) |  |  | (21,630 | ) |  |  |  | (14,042 | ) |  |  | (21,706 | ) |
| Integration expenses(3) |  |  | (34 | ) |  |  | (35 | ) |  |  | (154 | ) |  |  |  | (104 | ) |  |  | (154 | ) |
| Non-GAAP Cost of Revenue |  | $ | 131,866 |  |  | $ | 131,249 |  |  | $ | 162,494 |  |  |  | $ | 395,299 |  |  | $ | 566,755 |  |
| Gross Profit |  | $ | 85,251 |  |  | $ | 81,575 |  |  | $ | 74,237 |  |  |  | $ | 239,081 |  |  | $ | 254,598 |  |
| Non-GAAP Gross Profit |  | $ | 95,838 |  |  | $ | 94,742 |  |  | $ | 109,837 |  |  |  | $ | 284,569 |  |  | $ | 356,866 |  |
| Gross Margin |  |  | 37.4 | % |  |  | 36.1 | % |  |  | 27.3 | % |  |  |  | 35.2 | % |  |  | 27.6 | % |
| Non-GAAP Gross Margin |  |  | 42.1 | % |  |  | 41.9 | % |  |  | 40.3 | % |  |  |  | 41.9 | % |  |  | 38.6 | % |

[0000950170-24-122762:8k_2_02:60]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations.

[0000950170-24-122762:8k_2_02:61]
(2) Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks. These expenses include inventory write down and other charges of $8.6 million for the nine months ended September 30, 2024, incurred as a result of a strategy shift which included discontinuance of certain product lines in connection with the Business Efficiency Program. The restructuring program commenced upon the closing of the business combination with Adtran Networks and is expected to be substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany. These expenses include restructuring wage charges of $4.9 million for the nine months ended September 30, 2024. The closure of the facility is expected to be completed by December 31, 2024.

[0000950170-24-122762:8k_2_02:62]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks.

[0000950170-24-122762:8k_2_02:63]
Supplemental Information

[0000950170-24-122762:8k_2_02:64]
Reconciliation of Preliminary Operating Expenses to Preliminary Non-GAAP Operating Expenses

[0000950170-24-122762:8k_2_02:65]
(Unaudited)

[0000950170-24-122762:8k_2_02:66]
(In thousands)

[0000950170-24-122762:8k_2_02:67]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | June 30, |  |  | September 30, |  |  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2024 |  |  | 2024 |  |  | 2023 |  |  |  | 2024 |  |  | 2023 |  |  |
| Operating Expenses |  | $ | 109,235 |  |  | $ | 119,881 |  |  | $ | 163,533 |  |  |  | $ | 641,050 |  |  | $ | 438,254 |  |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | (5,054 | ) | (1) |  | (7,233 | ) | (6) |  | (4,534 | ) | (10) |  |  | (17,168 | ) | (14) |  | (13,516 | ) | (19) |
| Stock-based compensation expense |  |  | (3,126 | ) | (2) |  | (3,321 | ) | (7) |  | (3,251 | ) | (11) |  |  | (9,894 | ) | (15) |  | (10,683 | ) | (20) |
| Restructuring expenses |  |  | (5,930 | ) | (3) |  | (14,742 | ) | (8) |  | (3,242 | ) | (12) |  |  | (26,534 | ) | (16) |  | (11,471 | ) | (21) |
| Integration expenses |  |  | (333 | ) | (4) |  | (531 | ) | (9) |  | (1,485 | ) | (13) |  |  | (1,344 | ) | (17) |  | (2,897 | ) | (22) |
| Deferred compensation adjustments(5) |  |  | (1,471 | ) |  |  | (848 | ) |  |  | 1,801 |  |  |  |  | (4,259 | ) |  |  | 1,714 |  |  |
| Goodwill impairment(18) |  |  | — |  |  |  | — |  |  |  | (37,874 | ) |  |  |  | (292,583 | ) |  |  | (37,874 | ) |  |
| Non-GAAP Operating Expenses |  | $ | 93,321 |  |  | $ | 93,206 |  |  | $ | 114,948 |  |  |  | $ | 289,268 |  |  | $ | 363,527 |  |  |

[0000950170-24-122762:8k_2_02:68]
(1) Includes $4.0M of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations and $0.6 million of legal and advisory fees related to a potential strategic transaction which are both included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:69]
(2) $2.2 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:70]
(3) $2.7 million is included in selling, general and administrative expenses and $3.2 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses of $3.2 million of wage related and other charges due to the Greifswald facility closure of which $0.8 million is included in selling, general and administrative and $2.4 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:71]
(4) $0.3 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks.

[0000950170-24-122762:8k_2_02:72]
(5) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-24-122762:8k_2_02:73]
(6) Includes $3.9M of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations and $2.8 million of legal and advisory fees related to a contemplated strategic transaction which are both included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:74]
(7) $2.4 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:75]
(8) $3.5 million is included in selling, general and administrative expenses and $11.3 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses of $13.5 million of wage related and other charges due to the Greifswald facility closure of which $2.6 million is included in selling, general and administrative and $10.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:76]
(9) $0.5 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks.

[0000950170-24-122762:8k_2_02:77]
(10) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $4.0 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:78]
(11) $2.4 million is included in selling, general and administrative expenses and $0.8 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:79]
(12) $3.4 million is included in selling, general and administrative expenses and $(0.2) million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:80]
(13) $1.4 million is included in selling, general and administrative expenses and $0.1 million is included in research and development expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. Additionally, includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks of which $0.5 million is stock compensation expense for the program.

[0000950170-24-122762:8k_2_02:81]
(14) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $15.8 million is included in selling, general and administrative expenses and $1.4 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:82]
(15) $7.1 million is included in selling, general and administrative expenses and $2.8 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:83]
(16) $8.0 million is included in selling, general and administrative expenses and $18.6 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses of $16.5 million of wage related and other charges due to the Greifswald facility closure of which $3.2 million is included in selling, general and administrative and $13.3 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:84]
(17) $1.3 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. Additionally, includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks of which $0.7 million is stock compensation expense for the program.

[0000950170-24-122762:8k_2_02:85]
(18) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company's market capitalization, cautious service provider spending due to economic uncertainty and continued elevated customer inventory adjustments.

[0000950170-24-122762:8k_2_02:86]
(19) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $12.0 million is included in selling, general and administrative expenses and $1.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:87]
(20) $7.6 million is included in selling, general and administrative expenses and $3.1 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:88]
(21) $7.0 million is included in selling, general and administrative expenses and $4.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-122762:8k_2_02:89]
(22) $2.8 million is included in selling, general and administrative expenses and $0.1 million is included in research and development expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. Additionally, includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks of which $0.5 million is stock compensation expense for the program.

[0000950170-24-122762:8k_2_02:90]
Supplemental Information

[0000950170-24-122762:8k_2_02:91]
Reconciliation of Preliminary Operating Loss to Preliminary Non-GAAP Operating Income (Loss)

[0000950170-24-122762:8k_2_02:92]
(Unaudited)

[0000950170-24-122762:8k_2_02:93]
(In thousands)

[0000950170-24-122762:8k_2_02:94]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | June 30, |  |  | September 30, |  |  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2024 |  |  | 2024 |  |  | 2023 |  |  |  | 2024 |  |  | 2023 |  |  |
| Operating Loss |  | $ | (23,984 | ) |  | $ | (38,306 | ) |  | $ | (89,296 | ) |  |  | $ | (401,969 | ) |  | $ | (183,656 | ) |  |
| Acquisition related expenses, amortizations and adjustments(1) |  |  | 15,330 |  |  |  | 17,297 |  |  |  | 18,070 |  |  |  |  | 47,685 |  |  |  | 93,069 |  |  |
| Stock-based compensation expense |  |  | 3,396 |  |  |  | 3,601 |  |  |  | 3,530 |  |  |  |  | 10,719 |  |  |  | 11,537 |  |  |
| Restructuring expenses(2) |  |  | 5,936 |  |  |  | 17,530 |  |  |  | 24,873 |  |  |  |  | 40,576 |  |  |  | 33,178 |  |  |
| Integration expenses(3) |  |  | 367 |  |  |  | 566 |  |  |  | 1,639 |  |  |  |  | 1,447 |  |  |  | 3,051 |  |  |
| Deferred compensation adjustments(4) |  |  | 1,471 |  |  |  | 848 |  |  |  | (1,801 | ) |  |  |  | 4,259 |  |  |  | (1,714 | ) |  |
| Goodwill impairment(5) |  |  | — |  |  |  | — |  |  |  | 37,874 |  |  |  |  | 292,583 |  |  |  | 37,874 |  |  |
| Non-GAAP Operating Income (Loss) |  | $ | 2,516 |  |  | $ | 1,536 |  |  | $ | (5,111 | ) |  |  | $ | (4,700 | ) |  | $ | (6,661 | ) |  |

[0000950170-24-122762:8k_2_02:95]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations.

[0000950170-24-122762:8k_2_02:96]
(2) Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks. These expenses include inventory write down and other charges incurred as a result of a strategic shift in certain product lines in connection with the restructuring program. Additionally, includes expenses related to the closure of the Greifswald facility.

[0000950170-24-122762:8k_2_02:97]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks. Includes fees incurred for the expansion of internal controls at Adtran Networks and the implementation of the DPTLA.

[0000950170-24-122762:8k_2_02:98]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-24-122762:8k_2_02:99]
(5) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer inventory adjustments.

[0000950170-24-122762:8k_2_02:100]
Supplemental Information

[0000950170-24-122762:8k_2_02:101]
Reconciliation of Preliminary Other (Expense) Income to Preliminary Non-GAAP Other Expense

[0000950170-24-122762:8k_2_02:102]
(Unaudited)

[0000950170-24-122762:8k_2_02:103]
(In thousands)

[0000950170-24-122762:8k_2_02:104]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |
|  |  | September 30, 2024 |  |  | June 30, 2024 |  |  | September 30, 2023 |  |  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| Interest and dividend income |  | $ | 664 |  |  | $ | 366 |  |  | $ | 521 |  |  |  | $ | 1,427 |  |  | $ | 1,183 |  |
| Interest expense |  |  | (5,679 | ) |  |  | (6,906 | ) |  |  | (4,507 | ) |  |  |  | (17,183 | ) |  |  | (11,858 | ) |
| Net investment gain (loss) |  |  | 1,382 |  |  |  | 872 |  |  |  | (1,443 | ) |  |  |  | 4,507 |  |  |  | 1,071 |  |
| Other (expense) income, net |  |  | (850 | ) |  |  | (901 | ) |  |  | 2,523 |  |  |  |  | (441 | ) |  |  | 4,714 |  |
| Total Other Expense |  | $ | (4,483 | ) |  | $ | (6,569 | ) |  | $ | (2,906 | ) |  |  | $ | (11,690 | ) |  | $ | (4,890 | ) |
| Deferred compensation adjustments (1) |  |  | (1,294 | ) |  |  | (896 | ) |  |  | 1,117 |  |  |  |  | (4,629 | ) |  |  | (1,387 | ) |
| Pension expense (2) |  |  | 7 |  |  |  | 7 |  |  |  | 7 |  |  |  |  | 21 |  |  |  | 20 |  |
| Non-GAAP Other Expense |  | $ | (5,770 | ) |  | $ | (7,458 | ) |  | $ | (1,782 | ) |  |  | $ | (16,298 | ) |  | $ | (6,257 | ) |

[0000950170-24-122762:8k_2_02:105]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0000950170-24-122762:8k_2_02:106]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-24-122762:8k_2_02:107]
Supplemental Information

[0000950170-24-122762:8k_2_02:108]
Reconciliation of Preliminary Net Loss inclusive of Non-Controlling Interest to

[0000950170-24-122762:8k_2_02:109]
Preliminary Non-GAAP Net Loss inclusive of Non-Controlling Interest

[0000950170-24-122762:8k_2_02:110]
(Unaudited)

[0000950170-24-122762:8k_2_02:111]
and

[0000950170-24-122762:8k_2_02:112]
Reconciliation of Preliminary Net Income attributable to Non-Controlling Interest to

[0000950170-24-122762:8k_2_02:113]
Preliminary Non-GAAP Net Income attributable to Non-Controlling Interest

[0000950170-24-122762:8k_2_02:114]
(Unaudited)

[0000950170-24-122762:8k_2_02:115]
and

[0000950170-24-122762:8k_2_02:116]
Reconciliation of Preliminary Net Loss attributable to ADTRAN Holdings, Inc. and

[0000950170-24-122762:8k_2_02:117]
Preliminary Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0000950170-24-122762:8k_2_02:118]
Preliminary Non-GAAP Net Loss attributable to ADTRAN Holdings, Inc. and

[0000950170-24-122762:8k_2_02:119]
Preliminary Non-GAAP Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0000950170-24-122762:8k_2_02:120]
(Unaudited)

[0000950170-24-122762:8k_2_02:121]
(In thousands, except per share amounts)

[0000950170-24-122762:8k_2_02:122]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |
|  |  | September 30,2024 |  |  | June 30,2024 |  |  | September 30,2023 |  |  |  | September 30,2024 |  |  | September 30,2023 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | (31,239 | ) |  | $ | (49,515 | ) |  | $ | (78,210 | ) |  |  | $ | (404,955 | ) |  | $ | (156,697 | ) |
| Plus: Net (Loss) Income attributable to non-controlling interest (1) |  |  | 2,382 |  |  |  | 2,504 |  |  |  | 2,561 |  |  |  |  | 7,417 |  |  |  | 4,380 |  |
| Net Loss inclusive of non-controlling interest |  | $ | (28,857 | ) |  | $ | (47,011 | ) |  | $ | (75,649 | ) |  |  | $ | (397,538 | ) |  | $ | (152,317 | ) |
| Acquisition related expenses, amortizations and adjustments |  |  | 15,330 |  |  |  | 17,297 |  |  |  | 18,070 |  |  |  |  | 47,685 |  |  |  | 93,069 |  |
| Stock-based compensation expense |  |  | 3,396 |  |  |  | 3,601 |  |  |  | 3,530 |  |  |  |  | 10,719 |  |  |  | 11,537 |  |
| Deferred compensation adjustments (2) |  |  | 177 |  |  |  | (48 | ) |  |  | (684 | ) |  |  |  | (370 | ) |  |  | (3,101 | ) |
| Pension adjustments (3) |  |  | 7 |  |  |  | 7 |  |  |  | 7 |  |  |  |  | 21 |  |  |  | 20 |  |
| Restructuring expenses |  |  | 5,936 |  |  |  | 17,530 |  |  |  | 24,873 |  |  |  |  | 40,576 |  |  |  | 33,178 |  |
| Integration expenses |  |  | 367 |  |  |  | 566 |  |  |  | 1,639 |  |  |  |  | 1,447 |  |  |  | 3,051 |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | 37,874 |  |  |  |  | 292,583 |  |  |  | 37,874 |  |
| Tax effect of adjustments to net loss (4) |  |  | (712 | ) |  |  | 755 |  |  |  | (21,024 | ) |  |  |  | (19,022 | ) |  |  | (50,146 | ) |
| Non-GAAP Net Loss inclusive of non-controlling interest |  | $ | (4,356 | ) |  | $ | (7,303 | ) |  | $ | (11,364 | ) |  |  | $ | (23,899 | ) |  | $ | (26,835 | ) |
| Less: Non-GAAP Net (Loss) Income attributable to non-controlling interest (1) |  |  | 2,382 |  |  |  | 2,504 |  |  |  | 2,561 |  |  |  |  | 7,417 |  |  |  | 5,909 |  |
| Non-GAAP Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (6,738 | ) |  | $ | (9,807 | ) |  | $ | (13,925 | ) |  |  | $ | (31,316 | ) |  | $ | (32,744 | ) |
| GAAP Net Income attributable to non-controlling interest (1) |  | $ | 2,382 |  |  | $ | 2,504 |  |  | $ | 2,561 |  |  |  | $ | 7,417 |  |  | $ | 4,380 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 1,457 |  |
| Restructuring expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 29 |  |
| Integration expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 6 |  |
| Stock-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 37 |  |
| Non-GAAP Net Income attributable to non-controlling interest (1) |  | $ | 2,382 |  |  | $ | 2,504 |  |  | $ | 2,561 |  |  |  | $ | 7,417 |  |  | $ | 5,909 |  |
| Weighted average shares outstanding – basic |  |  | 78,952 |  |  |  | 78,852 |  |  |  | 78,389 |  |  |  |  | 78,873 |  |  |  | 78,378 |  |
| Weighted average shares outstanding – diluted |  |  | 78,952 |  |  |  | 78,852 |  |  |  | 78,389 |  |  |  |  | 78,873 |  |  |  | 78,378 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.36 | ) | (5) | $ | (0.63 | ) |  | $ | (1.00 | ) |  |  | $ | (5.10 | ) | (5) | $ | (2.00 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.36 | ) | (5) | $ | (0.63 | ) |  | $ | (1.00 | ) |  |  | $ | (5.10 | ) | (5) | $ | (2.00 | ) |
| Non-GAAP Loss per common share attributable to ADTRAN – basic |  | $ | (0.05 | ) | (5) | $ | (0.12 | ) |  | $ | (0.18 | ) |  |  | $ | (0.36 | ) | (5) | $ | (0.42 | ) |
| Non-GAAP Loss per common share attributable to ADTRAN – diluted |  | $ | (0.05 | ) | (5) | $ | (0.12 | ) |  | $ | (0.18 | ) |  |  | $ | (0.36 | ) | (5) | $ | (0.42 | ) |

[0000950170-24-122762:8k_2_02:123]
(1) Represents the non-controlling interest portion of the Company's ownership of Adtran Networks pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0000950170-24-122762:8k_2_02:124]
(2) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-24-122762:8k_2_02:125]
(3) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-24-122762:8k_2_02:126]
(4) Represents the tax effect of non-GAAP adjustments. Beginning in period ending September 30, 2024, the Company changed its method of calculating non-GAAP income taxes by applying blended statutory tax rates to non-GAAP losses before income taxes in order to include current and deferred income tax expenses that are commensurate with the non-GAAP measure of profitability. The blended statutory tax rate is calculated using 0%, resulting in no tax benefits net of impact of valuation allowance, for the loss jurisdiction’s non-GAAP losses before income taxes and 30% for all remaining jurisdictions’ non-GAAP income before income taxes. Prior periods have been adjusted to reflect the application of blended statutory tax rates, net of impact of valuation allowance, to non-GAAP losses before income taxes as opposed to the previous application of blended statutory and effective tax rates to separate non-GAAP adjustments. We previously reported the tax effect of the adjustment to non-GAAP net loss under the prior method of $7.9 million, $49.1 million and $21.0 million for the three and nine months ended September 30, 2023 and for the three months ended June 30, 2024, respectively.

[0000950170-24-122762:8k_2_02:127]
(5) Loss per common share attributable to ADTRAN Holdings, Inc. and Non-GAAP Loss per common share attributable to ADTRAN Holdings, Inc. reflects $3.0 million of gain on redemption of redeemable non-controlling interest for the three and nine months ended September 30, 2024.

[0000950170-24-122762:8k_2_02:128]
Supplemental Information

[0000950170-24-122762:8k_2_02:129]
Reconciliation of Preliminary Net Cash Provided By (Used In) Operating Activities to Preliminary Free Cash Flow

[0000950170-24-122762:8k_2_02:130]
(Unaudited)

[0000950170-24-122762:8k_2_02:131]
(In thousands)

[0000950170-24-122762:8k_2_02:132]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | June 30, |  |  | September 30, |  |  |  | September 30, |  |  | September 30, |  |
|  |  | 2024 |  |  | 2024 |  |  | 2023 |  |  |  | 2024 |  |  | 2023 |  |
| Net Cash provided by (used in) operating activities |  | $ | 42,030 |  |  | $ | 19,898 |  |  | $ | 6,846 |  |  |  | $ | 98,526 |  |  | $ | (29,314 | ) |
| Purchases of property, plant and equipment(1) |  |  | (18,814 | ) |  |  | (15,995 | ) |  |  | (13,556 | ) |  |  |  | (48,183 | ) |  |  | (33,674 | ) |
| Free cash flow |  | $ | 23,216 |  |  | $ | 3,903 |  |  | $ | (6,710 | ) |  |  | $ | 50,343 |  |  | $ | (62,988 | ) |

[0000950170-24-122762:8k_2_02:133]
(1) Purchases related to capital expenditures.
