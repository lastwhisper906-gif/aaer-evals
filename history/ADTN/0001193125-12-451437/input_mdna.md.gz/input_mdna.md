# ADTN MD&A — 0001193125-12-451437


## mdna

[0001193125-12-451437:mdna:1]
[same as prior period, unchanged from 0001193125-12-334164:mdna:1]

[0001193125-12-451437:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and
the related notes that appear elsewhere in this document.

[0001193125-12-451437:mdna:3]
[same as prior period, unchanged from 0001193125-12-334164:mdna:3]

[0001193125-12-451437:mdna:4]
[same as prior period, unchanged from 0001193125-12-334164:mdna:4]

[0001193125-12-451437:mdna:5]
[same as prior period, unchanged from 0001193125-12-334164:mdna:5]

[0001193125-12-451437:mdna:6]
[same as prior period, unchanged from 0001193125-12-334164:mdna:6]

[0001193125-12-451437:mdna:7]
[same as prior period, unchanged from 0001193125-12-334164:mdna:7]

[0001193125-12-451437:mdna:8]
[same as prior period, unchanged from 0001193125-12-334164:mdna:8]

[0001193125-12-451437:mdna:9]
Sales were $162.1
million and $480.9 million for the three and nine months ended September 30, 2012 compared to $192.2 million and $541.9 million for the three and nine months ended September 30, 2011. Product revenues for our three primary growth areas,
Broadband Access, Optical Access and Internetworking, were $141.0 million and $400.7 million for the three and nine months ended September 30, 2012 compared to $151.8 million and $389.4 million for the three and nine months ended
September 30, 2011. Our gross margin decreased to 49.3% and 51.8% for the three and nine months ended September 30, 2012 from 57.0% and 58.1% for the three and nine months ended September 30, 2011. Our operating income margin
decreased to 6.3% and 11.1% for the three and nine months ended September 30, 2012 from 26.6% and 27.3% for the three and nine months ended September 30, 2011. Net income was $9.3 million and $43.3 million for the three and nine months
ended September 30, 2012 compared to $36.2 million and $107.4 million for the three and nine months ended September 30, 2011. Our effective tax rate decreased to 32.4% for the three months ended September 30, 2012 from 34.6% for the
three months ended September 30, 2011 and increased to 34.9% for the nine months ended September 30, 2012 from 33.2% for the nine months ended September 30, 2011. Earnings per share, assuming dilution, were $0.15 and $0.68 for the
three and nine months ended September 30, 2012 compared to $0.56 and $1.63 for the three and nine months ended September 30, 2011.

[0001193125-12-451437:mdna:10]
[same as prior period, unchanged from 0001193125-12-334164:mdna:10]

[0001193125-12-451437:mdna:11]
[same as prior period, unchanged from 0001193125-12-334164:mdna:11]

[0001193125-12-451437:mdna:12]
[same as prior period, unchanged from 0001193125-12-334164:mdna:12]

[0001193125-12-451437:mdna:13]
[same as prior period, unchanged from 0001193125-12-334164:mdna:13]

[0001193125-12-451437:mdna:14]
[same as prior period, unchanged from 0001193125-12-334164:mdna:14]

[0001193125-12-451437:mdna:15]
[same as prior period, unchanged from 0001193125-12-334164:mdna:15]

[0001193125-12-451437:mdna:16]
[same as prior period, unchanged from 0001193125-12-334164:mdna:16]

[0001193125-12-451437:mdna:17]
[same as prior period, unchanged from 0001193125-12-334164:mdna:17]

[0001193125-12-451437:mdna:18]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks (NSN) Broadband Access business (NSN BBA
business). Acquisition related expenses, amortizations and adjustments for the three and nine months ended September 30, 2012 and 2011 for both transactions are as follows:

[0001193125-12-451437:mdna:19]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 268 |  |  | $ | 198 |  |  | $ | 753 |  |  | $ | 198 |  |
| Amortization of other purchase accounting adjustments |  |  | 37 |  |  |  | 217 |  |  |  | 414 |  |  |  | 217 |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | 630 |  |  |  | — |  |  |  | 630 |  |
| Subtotal |  |  | 305 |  |  |  | 1,045 |  |  |  | 1,167 |  |  |  | 1,045 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 300 |  |  |  | — |  |  |  | 472 |  |  |  | — |  |
| Amortization of other purchase accounting adjustments |  |  | 666 |  |  |  | — |  |  |  | 1,718 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | 252 |  |  |  | 931 |  |  |  | 4,537 |  |  |  | 992 |  |
| Subtotal |  |  | 1,218 |  |  |  | 931 |  |  |  | 6,727 |  |  |  | 992 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 1,523 |  |  |  | 1,976 |  |  |  | 7,894 |  |  |  | 2,037 |  |
| Tax effect |  |  | (496 | ) |  |  | (751 | ) |  |  | (2,660 | ) |  |  | (776 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,027 |  |  | $ | 1,225 |  |  | $ | 5,234 |  |  | $ | 1,261 |  |

[0001193125-12-451437:mdna:20]
[same as prior period, unchanged from 0001193125-12-334164:mdna:22]

[0001193125-12-451437:mdna:21]
The acquisition related expenses, amortizations and adjustments above were recorded in the following
Consolidated Statements of Income categories for the three and nine months ended September 30, 2012 and 2011:

[0001193125-12-451437:mdna:22]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 497 |  |  | $ | 155 |  |  | $ | 1,151 |  |  | $ | 155 |  |
| Cost of goods sold |  |  | 126 |  |  |  | 66 |  |  |  | 932 |  |  |  | 66 |  |
| Subtotal |  |  | 623 |  |  |  | 221 |  |  |  | 2,083 |  |  |  | 221 |  |
| Selling, general and administrative expenses |  |  | 258 |  |  |  | 1,374 |  |  |  | 4,180 |  |  |  | 1,424 |  |
| Research and development expenses |  |  | 642 |  |  |  | 381 |  |  |  | 1,631 |  |  |  | 392 |  |
| Subtotal |  |  | 900 |  |  |  | 1,755 |  |  |  | 5,811 |  |  |  | 1,816 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 1,523 |  |  |  | 1,976 |  |  |  | 7,894 |  |  |  | 2,037 |  |
| Tax effect |  |  | (496 | ) |  |  | (751 | ) |  |  | (2,660 | ) |  |  | (776 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,027 |  |  | $ | 1,225 |  |  | $ | 5,234 |  |  | $ | 1,261 |  |

[0001193125-12-451437:mdna:23]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2012 COMPARED TO THREE AND NINE MONTHS ENDED
SEPTEMBER 30, 2011

[0001193125-12-451437:mdna:24]
[same as prior period, unchanged from 0001193125-12-334164:mdna:24]

[0001193125-12-451437:mdna:25]
ADTRAN’s sales decreased 15.6% from $192.2 million in the three months ended September 30, 2011 to $162.1 million in the three months ended September 30, 2012, and decreased 11.3% from
$541.9 million in the nine months ended September 30, 2011 to $480.9 million in the nine months ended September 30, 2012. The decrease in sales for the three months ended September 30, 2012 is primarily attributable to a $19.3 million
decrease in sales of our HDSL and other legacy products, an $11.1 million decrease in sales of our Optical products, and a $7.1 million decrease in sales of our Internetworking products, partially offset by a $7.5 million increase in sales of our
Broadband Access products. The decrease in sales for the nine months ended September 30, 2012 is primarily attributable to a $72.4 million decrease in sales of our HDSL and other legacy products, a $25.8 million decrease in sales of our Optical
products, partially offset by a $34.2 million increase in sales of our Broadband Access products and a $2.9 million increase in sales of our Internetworking products.

[0001193125-12-451437:mdna:26]
Carrier Networks sales decreased 13.5% from $152.5 million in the three months ended September 30, 2011 to $131.9 million in the three months ended September 30, 2012, and decreased 12.4% from
$435.3 million in the nine months ended September 30, 2011 to $381.3 in the nine months ended September 30, 2012. The decrease in sales for the three and nine months ended September 30, 2012 is primarily attributable to decreases in
sales of Optical products, HDSL and other legacy products. These declines were partially offset by the added sales of the NSN BBA business and an increase in sales of our Internetworking NTE products. Our organic Broadband Access sales for the nine
months ended September 30, 2012 were impacted by a delay in both the start and ramp-up of orders during the first quarter of this year from one of our larger carrier customers due to a new systems implementation and significant project delays
at another customer. The decrease in Optical products for the three and nine months ended September 30, 2012 is primarily attributable to the market transitioning to Ethernet and our transition to new products to address this market. The
declining trend in HDSL and other legacy products has been expected as we evolve our products towards packet-based technologies, but was larger than anticipated due to a large carrier customer that initiated a significant acceleration of their
installed inventory reuse program.

[0001193125-12-451437:mdna:27]
Enterprise Networks sales decreased 24.0% from $39.7 million in the three months ended September 30,
2011 to $30.2 million in the three months ended September 30, 2012, and decreased 6.6% from $106.6 million in the nine months ended September 30, 2011 to $99.6 million in the nine months ended September 30, 2012. The decrease for the
three and nine months ended September 30, 2012 is primarily attributable to decreases in sales of Internetworking products and legacy products. The decrease in Internetworking product sales for the three and nine months ended September, 30,
2012, is primarily due to uncertainties caused by the macro-economic environment, which resulted in delays in end-customer purchases. The impact of this environment was partially offset by market share gains in the competitive service provider
markets, value-added reseller recruitment, and by the addition of our vWLAN solutions. Internetworking product sales attributable to Enterprise Networks were 92.3% and 91.5% of the division’s sales in the three and nine months ended
September 30, 2012, compared to 88.6% and 86.6% in the three and nine months ended September 30, 2011. Legacy products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales
decreased from 20.7% for the three months ended September 30, 2011 to 18.6% for the three months ended September 30, 2012 and increased from 19.7% for the nine months ended September 30, 2011 to 20.7% for the nine months ended
September 30, 2012.

[0001193125-12-451437:mdna:28]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above,
increased 124.9% from $21.9 million in the three months ended September 30, 2011 to $49.2 million in the three months ended September 30, 2012, and increased 109.9% from $57.7 million in the nine months ended September 30, 2011 to
$121.1 million in the nine months ended September 30, 2012. International sales, as a percentage of total sales, increased from 11.4% for the three months ended September 30, 2011 to 30.3% for the three months ended September 30,
2012, and increased from 10.6% for the nine months ended September 30, 2011 to 25.2% for the nine months ended September 30, 2012. International sales increased in the three and nine months ended September 30, 2012 compared to the
three and nine months ended September 30, 2011 primarily due to sales attributable to the acquired NSN BBA business and an increase in organic sales in Latin America.

[0001193125-12-451437:mdna:29]
Carrier System product sales decreased $8.4 million and $9.4 million in the three and nine months ended September 30, 2012 compared to the three and nine months ended September 30, 2011. The
decrease for the three months ended September 30, 2012 is primarily due to an $11.1 million decrease in Optical product sales and a $4.8 million decrease in legacy product sales, partially offset by an increase of $7.5 million in Broadband
Access product sales. The decrease for the nine months ended September 30, 2012 is primarily due to a $25.8 million decrease in Optical product sales and a $17.8 million decrease in legacy product sales, partially offset by an increase of $34.2
million in Broadband Access product sales. The decrease in Optical products for the three and nine months ended September 30, 2012 is primarily attributable to the market transitioning to Ethernet and our transition to new products to address
this market. The increase in Broadband Access was due to the added sales of the NSN BBA business, partially offset by a decline in organic Broadband Access sales. Our organic Broadband Access sales for the nine months ended September 30, 2012
were impacted by a delay in both the start and ramp-up of orders during the first quarter of this year from one of our larger carrier customers due to a new systems implementation and significant project delays at another customer.

[0001193125-12-451437:mdna:30]
Business Networking product sales decreased $8.3 million and $0.6 million in the three and nine months ended September 30, 2012 compared to the
three and nine months ended September 30, 2011. The decrease for the three months ended September 30, 2012 is primarily due to a $7.1 million decrease in Interworking product sales across both divisions and a $1.2 million decrease in
legacy product sales. The decrease for the nine months ended September 30, 2012 is primarily due to a $3.4 million decrease in legacy product sales, partially offset by a $2.9 million increase in Interworking product sales across both
divisions. The decrease in sales of traditional products is a result of customers shifting to newer technologies. Many of these newer technologies are integral to our Internetworking product area.

[0001193125-12-451437:mdna:31]
Loop Access product sales decreased $13.3 million and $51.0 million in the three and nine months ended September 30, 2012 compared to the three and
nine months ended September 30, 2011. The decrease for the three months ended September 30, 2012 is primarily due to a $12.4 million decrease in HDSL product sales. The decrease for the nine months ended September 30, 2012 is
primarily due to a $48.9 million decrease in HDSL product sales. The declining trend in HDSL and other legacy products has been expected as we evolve our products towards packet-based technologies, but was larger than anticipated due to a large
carrier customer that initiated a significant acceleration of their installed inventory reuse program.

[0001193125-12-451437:mdna:32]
27

[0001193125-12-451437:mdna:33]
[same as prior period, unchanged from 0001193125-12-334164:mdna:33]

[0001193125-12-451437:mdna:34]
As a percentage of sales, cost of sales increased from 43.0% in the three months ended September 30, 2011 to 50.7% in the three months ended September 30, 2012 and increased from 41.9% in the
nine months ended September 30, 2011 to 48.2% in the nine months ended September 30, 2012. This increase is primarily attributable to lower gross margins related to the recently acquired NSN BBA business, lower cost absorption due to
the lower production volumes and customer price movements to achieve market share position.

[0001193125-12-451437:mdna:35]
Carrier Networks cost of sales, as a percent of
division sales, increased from 43.6% in the three months ended September 30, 2011 to 51.6% in the three months ended September 30, 2012 and increased from 41.9% in the nine months ended September 30, 2011 to 48.7% in the nine months
ended September 30, 2012. The increase in Carrier Networks cost of sales as a percentage of sales is primarily attributable to lower gross margins related to the recently acquired NSN BBA business, lower cost absorption due to the lower
production volumes and customer price movements to achieve market share position.

[0001193125-12-451437:mdna:36]
Enterprise Networks cost of sales, as a percent of division
sales, increased from 40.7% in the three months ended September 30, 2011 to 46.5% in the three months ended September 30, 2012 and increased from 41.7% in the nine months ended September 30, 2011 to 45.9% in the nine months ended
September 30, 2012. The increase is primarily attributable to lower cost absorption due to the lower production volumes and customer price movements to achieve market share position.

[0001193125-12-451437:mdna:37]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on
the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-12-451437:mdna:38]
SELLING, GENERAL AND ADMINISTRATIVE EXPENSES

[0001193125-12-451437:mdna:39]
Selling, general and administrative expenses increased 8.4% from $31.5 million in the three months ended September 30, 2011 to $34.1 million in the three months ended September 30, 2012 and
increased 12.2% from $91.9 million in the nine months ended September 30, 2011 to $103.1 million in the nine months ended September 30, 2012. The increase in selling, general and administrative expenses for the three month period ended
September 30, 2012 is primarily related to increases in staffing and fringe benefit costs due to increased headcount, including expenses and increased headcount related to the NSN BBA business acquired on May 4, 2012 and Bluesocket, Inc.,
which was acquired on August 4, 2011, travel expenses, and amortization of intangible assets related to the acquired NSN BBA business, partially offset by a decrease in professional services and legal services. The increase in selling, general
and administrative expenses for the nine month periods ended September 30, 2012 is primarily related to increases in staffing and fringe benefit costs due to increased headcount, including expenses and increased headcount related to the NSN BBA
business acquired on May 4, 2012 and Bluesocket, Inc., which was acquired on August 4, 2011, professional services, legal services, travel expenses and amortization of intangible assets related to the acquired NSN BBA business. The
increases in professional services, legal services and travel expenses were primarily attributable to the acquired NSN BBA business.

[0001193125-12-451437:mdna:40]
Selling,
general and administrative expenses as a percentage of sales increased from 16.4% in the three months ended September 30, 2011 to 21.0% in the three months ended September 30, 2012 and increased from 17.0% in the nine months ended
September 30, 2011 to 21.4% in the nine months ended September 30, 2012. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being
compared.

[0001193125-12-451437:mdna:41]
[same as prior period, unchanged from 0001193125-12-334164:mdna:41]

[0001193125-12-451437:mdna:42]
Research and development expenses increased 32.3% from $26.9 million in the three months ended September 30, 2011 to $35.6 million in the three months ended September 30, 2012 and increased
23.5% from $75.2 million in the nine months ended September 30, 2011 to $92.8 million in the nine months ended September 30, 2012. The increase in research and development expenses for the three and nine months ended September 30,
2012 is primarily related to increases in staffing and fringe benefit costs due to increased headcount, including expenses and increased headcount related to the NSN BBA business acquired on May 4, 2012 and Bluesocket, Inc., which was acquired
on August 4, 2011, amortization of acquired intangible assets related to both acquisitions, increases in independent contractor expense and office lease expense.

[0001193125-12-451437:mdna:43]
As a percentage of sales, research and development expenses increased from 14.0% in the three months ended
September 30, 2011 to 21.9% in the three months ended September 30, 2012 and increased from 13.9% in the nine months ended September 30, 2011 to 19.3% in the nine months ended September 30, 2012. Research and development expenses
as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-12-451437:mdna:44]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product
opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior
to the receipt of revenues from a major new product group.

[0001193125-12-451437:mdna:45]
INTEREST AND DIVIDEND INCOME

[0001193125-12-451437:mdna:46]
Interest and dividend income decreased 8.5% from $2.0 million in the three months ended September 30, 2011 to $1.9 million in the three months ended
September 30, 2012 and decreased 3.1% from $5.8 million in the nine months ended September 30, 2011 to $5.7 million in the nine months ended September 30, 2012. The decrease for the three months ended September 30, 2012 is
primarily driven by a 5.1% reduction in the average rate of return on our investments as a result of lower interest rates, partially offset by a 19.9% increase in our average investment balances. The decrease for the nine months ended
September 30, 2012 is primarily driven by a 7.7% reduction in the average rate of return on our investments as a result of lower interest rates, partially offset by an 18.3% increase on our average investment balances.

[0001193125-12-451437:mdna:47]
[same as prior period, unchanged from 0001193125-12-334164:mdna:47]

[0001193125-12-451437:mdna:48]
Interest
expense, which is primarily related to our taxable revenue bond, remained constant at $0.6 million in each of the three months ended September 30, 2012 and 2011 and $1.8 million in each of the nine months ended September 30, 2012 and 2011,
respectively. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001193125-12-451437:mdna:49]
NET REALIZED
INVESTMENT GAIN

[0001193125-12-451437:mdna:50]
Net realized investment gain decreased 15.2% from $3.0 million in the three months ended September 30, 2011 to
$2.5 million in the three months ended September 30, 2012 and decreased 19.4% from $9.1 million in the nine months ended September 30, 2011 to $7.4 million in the nine months ended September 30, 2012. The higher amount of realized
gains in the period ended September 30, 2011 is primarily driven by the sales of previously impaired assets in the deferred compensation plans and sales of other equity securities. In addition, for the period ended September 30, 2012, we
recorded an impairment of deferred compensation plan assets of $0.6 million. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-12-451437:mdna:51]
[same as prior period, unchanged from 0001193125-12-334164:mdna:51]

[0001193125-12-451437:mdna:52]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management
fees, scrap raw material sales, and gains and losses on the disposal of property, plant and equipment occurring in the normal course of business, changed from $0.2 million of expense in the three months ended September 30, 2011 to $0.4 million
of expense in the three months ended September 30, 2012 and changed from $0.4 million of expense in the nine months ended September 30, 2011 to $0.3 million of income in the nine months ended September 30, 2012.

[0001193125-12-451437:mdna:53]
[same as prior period, unchanged from 0001193125-12-334164:mdna:53]

[0001193125-12-451437:mdna:54]
Our effective tax
rate increased from 33.2% in the nine months ended September 30, 2011 to 34.9% in the nine months ended September 30, 2012. The tax provision rate in the nine months ended September 30, 2012 did not include the benefit of the
research tax credit, which expired on December 31, 2011. The exclusion of this benefit during the nine months ended September 30, 2012 resulted in a 2.2 percentage point increase in our effective tax rate. Reduced stock option
exercises, increase in a valuation allowance related to foreign subsidiary losses, and an increase in reserves related to state apportionment resulted in an additional 6.1 percentage point increase in our effective tax rate for the nine months ended
September 30, 2012. These increases were partially offset by provision to return reconciliation adjustments related to 2011, adjustments related to closed tax years and associated audits, and employment related state income tax incentives,
which resulted in a 6.6 percentage point decrease in our effective tax rate for the nine months ended September 30, 2012.

[0001193125-12-451437:mdna:55]
During the nine months ended September 30, 2012, we acquired the NSN BBA business, which resulted in a
bargain purchase gain reported on the income statement. The bargain purchase gain is presented net of tax in the income statement and a deferred tax liability was established in the opening balance sheet for the acquired entity.

[0001193125-12-451437:mdna:56]
[same as prior period, unchanged from 0001193125-12-334164:mdna:56]

[0001193125-12-451437:mdna:57]
As a result of the
above factors, net income decreased $26.9 million from $36.2 million in the three months ended September 30, 2011 to $9.3 million in the three months ended September 30, 2012 and decreased $64.1 million from $107.4 million in the nine
months ended September 30, 2011 to $43.3 million in the nine months ended September 30, 2012.

[0001193125-12-451437:mdna:58]
As a percentage of sales, net income
decreased from 18.8% in the three months ended September 30, 2011 to 5.7% in the three months ended September 30, 2012 and decreased from 19.8% in the nine months ended September 30, 2011 to 9.0% in the nine months ended
September 30, 2012.

[0001193125-12-451437:mdna:59]
[same as prior period, unchanged from 0001193125-12-334164:mdna:59]

[0001193125-12-451437:mdna:60]
[same as prior period, unchanged from 0001193125-12-334164:mdna:60]

[0001193125-12-451437:mdna:61]
We intend to finance our operations with cash flow from operations. We have
used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, dividend payments, and other general corporate purposes, including (i) product development activities to enhance our
existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for
the foreseeable future.

[0001193125-12-451437:mdna:62]
At September 30, 2012, cash on hand was $43.5 million and short-term investments were $190.3 million, which
resulted in available short-term liquidity of $233.9 million. At December 31, 2011, our cash on hand of $43.0 million and short-term investments of $159.3 million resulted in available short-term liquidity of $202.3 million. The increase in
short-term liquidity from December 31, 2011 to September 30, 2012 primarily reflects funds provided by our operating activities, proceeds from stock option exercises, cash received from NSN as a result of our acquisition of the NSN BBA
business and long-term corporate bonds moving to short-term status, partially offset by equipment acquisitions, share repurchases and dividends.

[0001193125-12-451437:mdna:63]
[same as prior period, unchanged from 0001193125-12-334164:mdna:63]

[0001193125-12-451437:mdna:64]
Our working capital, which consists of current assets less current
liabilities, increased 7.4% from $329.3 million as of December 31, 2011 to $353.7 million as of September 30, 2012. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current
liabilities, decreased from 4.50 as of December 31, 2011 to 2.92 as of September 30, 2012. The current ratio, defined as current assets divided by current liabilities, decreased from 6.32 as of December 31, 2011 to 4.07 as of
September 30, 2012. The increase in our working capital and decreases in the quick ratio and the current ratio are primarily attributable to changes in the underlying assets and liabilities, including deferred revenue balances, relating to the
acquired NSN BBA business.

[0001193125-12-451437:mdna:65]
Net accounts receivable increased 34.9% from $76.1 million at December 31, 2011 to $102.7 million at
September 30, 2012. Our allowance for doubtful accounts was $8 thousand at December 31, 2011 and $5 thousand at September 30, 2012. Quarterly accounts receivable days sales outstanding (DSO) increased from 40 days as of
December 31, 2011 to 58 days as of September 30, 2012. Net accounts receivable and DSO increased for the quarter ended September 30, 2012 due to trade receivables related to the acquired NSN BBA business and the timing of shipments in
the organic business during the quarter. Other receivables decreased from $9.7 million at December 31, 2011 to $8.3 million at September 30, 2012. Generally, the change in other receivables is due to the timing of shipments and payments
received for raw materials supplied to our contract manufacturers.

[0001193125-12-451437:mdna:66]
Quarterly inventory turnover decreased from 3.5 turns as of
December 31, 2011 to 3.1 turns as of September 30, 2012. Inventory increased 22.1% from December 31, 2011 to September 30, 2012. The increase in inventory is primarily attributable to inventories acquired during the acquisition
of the NSN BBA business and the timing of acceptances of broadband stimulus projects. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead
times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-12-451437:mdna:67]
Accounts payable increased 77.8% from $29.4 million at December 31, 2011 to $52.3 million at
September 30, 2012. The increase in accounts payable is primarily attributable to accounts payable related to the acquired NSN BBA business. Additionally, accounts payable will fluctuate due to variations in the timing of the receipt of
supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-12-451437:mdna:68]
[same as prior period, unchanged from 0001193125-12-334164:mdna:68]

[0001193125-12-451437:mdna:69]
Capital expenditures totaled approximately $10.8 million and $9.5 million for the nine months ended September 30, 2012 and 2011, respectively. These
expenditures were primarily used to purchase manufacturing and test equipment and computer software and hardware.

[0001193125-12-451437:mdna:70]
On May 4, 2012, we
acquired the NSN BBA business. This acquisition provides us with an established customer base in key markets and complementary, market-focused products and was accounted for as a business combination. We received a cash payment of $7.5 million from
NSN and recorded a bargain purchase gain of $1.8 million, net of income taxes, subject to customary working capital adjustments between the parties. We are currently negotiating the final working capital adjustments in accordance with the provisions
of the underlying purchase agreement.

[0001193125-12-451437:mdna:71]
Our combined short-term and long-term investments increased $26.1 million from $491.4 million at
December 31, 2011 to $517.4 million at September 30, 2012. This increase reflects the impact of additional funds available for investment provided by our operating activities and stock option exercises by our employees, reduced by our cash
needs for equipment acquisitions, share repurchases and dividends, as well as net realized and unrealized losses and amortization of net premiums on our combined investments.

[0001193125-12-451437:mdna:72]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At September 30, 2012 these investments included corporate
bonds of $166.9 million, municipal fixed-rate bonds of $191.8 million and municipal variable rate demand notes of $58.8 million. At December 31, 2011, these investments included corporate bonds of $156.8 million, municipal fixed-rate bonds of
$174.8 million and municipal variable rate demand notes of $69.7 million. As of September 30, 2012, our corporate bonds, municipal fixed-rate bonds, and municipal variable rate demand notes were classified as available-for-sale and had a
combined duration of 0.95 years with an average credit rating of AA-. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market
inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-12-451437:mdna:73]
Our long-term investments decreased 1.5% from $332.0 million
at December 31, 2011 to $327.1 million at September 30, 2012. The primary reason for the decrease in our long-term investments during 2012 was the movement of long-term corporate bonds to short-term status. Long-term investments at
September 30, 2012 and December 31, 2011 included an investment in a certificate of deposit of $48.3 million, which serves as collateral for our revenue bonds, as discussed below. We have various equity investments included in long-term
investments at a cost of $20.6 million and $12.8 million, and with a fair value of $37.8 million and $31.3 million, at September 30, 2012 and December 31, 2011, respectively.

[0001193125-12-451437:mdna:74]
Long-term investments at September 30, 2012 also include $11.0 million related to our deferred compensation plans; $2.0 million of other investments carried at cost, consisting of interests in two
private equity funds and an investment in a privately held telecommunications equipment manufacturer; and $0.9 million of a fixed income bond fund.

[0001193125-12-451437:mdna:75]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which
may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative
information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our
identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual
security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $0.1 million during the nine months ended September 30,
2012 related to 21 marketable equity securities. In addition to the impairment charge we recorded on our marketable equity securities, we recorded an impairment of $0.6 million during the nine months ended September 30, 2012 related to our
deferred compensation plan as a result of similar reviews. For the nine months ended September 30, 2011, we recorded an other-than-temporary impairment charge of $32 thousand related to seven marketable equity securities.

[0001193125-12-451437:mdna:76]
[same as prior period, unchanged from 0001193125-12-334164:mdna:76]

[0001193125-12-451437:mdna:77]
[same as prior period, unchanged from 0001193125-12-334164:mdna:77]

[0001193125-12-451437:mdna:78]
In July 2003, our Board of Directors elected to begin declaring quarterly
dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the nine months ended September 30, 2012, we paid dividends totaling $17.2 million.

[0001193125-12-451437:mdna:79]
[same as prior period, unchanged from 0001193125-12-334164:mdna:79]

[0001193125-12-451437:mdna:80]
We have amounts outstanding
under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $47.0 million at September 30, 2012 and December 31, 2011. At September 30, 2012, the estimated fair
value of the Bond was approximately $49.2 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of A. Included in long-term investments are restricted funds in
the amount of $48.3 million at September 30, 2012 and December 31, 2011, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in
order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 5% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the
state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program.

[0001193125-12-451437:mdna:81]
We are required to make payments in the amounts necessary to pay the principal and interest on the amounts currently outstanding. Based on positive cash flow from operating activities, we have
decided to continue early partial redemptions of the Bond. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $0.5 million of the Bond debt has been classified
as a current liability in accounts payable in the Consolidated Balance Sheet at September 30, 2012.

[0001193125-12-451437:mdna:82]
[same as prior period, unchanged from 0001193125-12-334164:mdna:82]

[0001193125-12-451437:mdna:83]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase
transactions of up to 35 million shares of our common stock. During the nine months ended September 30, 2012, we repurchased 1.2 million shares of our common stock at an average price of $24.24 per share. We currently have the
authority to purchase an additional 4.7 million shares of our common stock under the current plan approved by the Board of Directors.

[0001193125-12-451437:mdna:84]
[same as prior period, unchanged from 0001193125-12-334164:mdna:84]

[0001193125-12-451437:mdna:85]
To accommodate
employee stock option exercises, we issued 0.3 million shares of treasury stock for $4.9 million during the nine months ended September 30, 2012. During the nine months ended September 30, 2011, we issued 1.8 million shares of
treasury stock for $33.6 million.

[0001193125-12-451437:mdna:86]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001193125-12-451437:mdna:87]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated
entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the nine months ended September 30, 2012, there have been no material changes in
contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2011 filed on February 29, 2012 with the SEC.

[0001193125-12-451437:mdna:88]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30,
2012, of which $7.7 million has been applied to these commitments.

[0001193125-12-451437:mdna:89]
[same as prior period, unchanged from 0001193125-12-334164:mdna:89]

[0001193125-12-451437:mdna:90]
The following are some of the risks that could affect our financial performance or could cause actual results to differ materially from those expressed or implied in our forward-looking statements:

[0001193125-12-451437:mdna:91]
[same as prior period, unchanged from 0001193125-12-334164:mdna:91]

[0001193125-12-451437:mdna:92]
[same as prior period, unchanged from 0001193125-12-334164:mdna:92]

[0001193125-12-451437:mdna:93]
[same as prior period, unchanged from 0001193125-12-334164:mdna:93]

[0001193125-12-451437:mdna:94]
[same as prior period, unchanged from 0001193125-12-334164:mdna:94]

[0001193125-12-451437:mdna:95]
[same as prior period, unchanged from 0001193125-12-334164:mdna:95]

[0001193125-12-451437:mdna:96]
[same as prior period, unchanged from 0001193125-12-334164:mdna:96]

[0001193125-12-451437:mdna:97]
[same as prior period, unchanged from 0001193125-12-334164:mdna:97]

[0001193125-12-451437:mdna:98]
[same as prior period, unchanged from 0001193125-12-334164:mdna:98]

[0001193125-12-451437:mdna:99]
[same as prior period, unchanged from 0001193125-12-334164:mdna:99]

[0001193125-12-451437:mdna:100]
[same as prior period, unchanged from 0001193125-12-334164:mdna:100]

[0001193125-12-451437:mdna:101]
[same as prior period, unchanged from 0001193125-12-334164:mdna:101]

[0001193125-12-451437:mdna:102]
[same as prior period, unchanged from 0001193125-12-334164:mdna:102]

[0001193125-12-451437:mdna:103]
[same as prior period, unchanged from 0001193125-12-334164:mdna:103]

[0001193125-12-451437:mdna:104]
[same as prior period, unchanged from 0001193125-12-334164:mdna:104]

[0001193125-12-451437:mdna:105]
[same as prior period, unchanged from 0001193125-12-334164:mdna:105]

[0001193125-12-451437:mdna:106]
[same as prior period, unchanged from 0001193125-12-334164:mdna:106]

[0001193125-12-451437:mdna:107]
[same as prior period, unchanged from 0001193125-12-334164:mdna:107]

[0001193125-12-451437:mdna:108]
[same as prior period, unchanged from 0001193125-12-334164:mdna:108]

[0001193125-12-451437:mdna:109]
[same as prior period, unchanged from 0001193125-12-334164:mdna:109]

[0001193125-12-451437:mdna:110]
[same as prior period, unchanged from 0001193125-12-334164:mdna:110]

[0001193125-12-451437:mdna:111]
[same as prior period, unchanged from 0001193125-12-334164:mdna:111]

[0001193125-12-451437:mdna:112]
[same as prior period, unchanged from 0001193125-12-334164:mdna:112]

[0001193125-12-451437:mdna:113]
[same as prior period, unchanged from 0001193125-12-334164:mdna:113]

[0001193125-12-451437:mdna:114]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-12-451437:mdna:115]
[same as prior period, unchanged from 0001193125-12-334164:mdna:115]

[0001193125-12-451437:mdna:116]
[same as prior period, unchanged from 0001193125-12-334164:mdna:116]

[0001193125-12-451437:mdna:117]
33

[0001193125-12-451437:mdna:118]
|  | • |  | If we are unable to successfully develop relationships with system integrators, service providers, and enterprise value added resellers, our sales may be negatively affected. |

[0001193125-12-451437:mdna:119]
|  | • |  | If we fail to manage our exposure to worldwide financial and securities markets successfully, our operating results and financial statements could be materially impacted. |

[0001193125-12-451437:mdna:120]
|  | • |  | Changes in our effective tax rate or assessments arising from tax audits may have an adverse impact on our results. |

[0001193125-12-451437:mdna:121]
|  | • |  | We are required to periodically evaluate the value of our long-lived assets, including the value of intangibles acquired and goodwill resulting from business combinations. Any future impairment charges required may adversely affect our operating results. |

[0001193125-12-451437:mdna:122]
|  | • |  | Our success depends on attracting and retaining key personnel. |

[0001193125-12-451437:mdna:123]
|  | • |  | Regulatory and potential physical impacts of climate change and other natural events may affect our customers and our production operations, resulting in adverse effects on our operating results. |

[0001193125-12-451437:mdna:124]
|  | • |  | While we believe our internal control over financial reporting is adequate, a failure to maintain effective internal control over financial reporting as our business expands could result in a loss of investor confidence in our financial reports and have an adverse effect on our stock price. |

[0001193125-12-451437:mdna:125]
|  | • |  | The price of our common stock has been volatile and may continue to fluctuate significantly. |

[0001193125-12-451437:mdna:126]
[same as prior period, unchanged from 0001193125-12-334164:mdna:126]
