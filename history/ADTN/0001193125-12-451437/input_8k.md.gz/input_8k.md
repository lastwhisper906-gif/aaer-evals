# ADTN 8-K — 0001157523-12-005081 filed 2012-10-10

## item codes, every 8-K on or before 2012-11-05

- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2012-11-05

- none on or before 2012-11-05

## item 2.02 — earnings release, exhibit 99.1

[0001157523-12-005081:8k_2_02:1]
EX-99.1
2
a50436079ex99_1.htm
EXHIBIT 99.1

[0001157523-12-005081:8k_2_02:2]
Exhibit 99.1

[0001157523-12-005081:8k_2_02:3]
ADTRAN,
      Inc. Reports Results for the Third Quarter 2012 and Declares Quarterly
      Cash Dividend

[0001157523-12-005081:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--October 9, 2012--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the third quarter 2012. For the
      quarter, sales were $162,125,000 compared to $192,194,000 for the third
      quarter of 2011. Net income was $9,272,000 for the quarter compared to
      $36,213,000 for the third quarter of 2011. Earnings per share, assuming
      dilution, were $0.15 for the quarter compared to $0.56 for the third
      quarter of 2011. Non-GAAP earnings per share for the quarter were $0.20
      compared to $0.61 for the third quarter of 2011. The reconciliation
      between GAAP earnings per share, diluted, and non-GAAP earnings per
      share, diluted, is in the table provided.

[0001157523-12-005081:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “This quarter’s
      performance came in line with our revised expectations. Although current
      market conditions limit near term visibility, we are confident that our
      market share position and globalization efforts will lead to
      significantly better performance in the future.”

[0001157523-12-005081:8k_2_02:6]
The Company also announced that its Board of Directors declared a cash
      dividend for the third quarter of 2012. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on October 25, 2012. The ex-dividend date is October 23, 2012
      and the payment date is November 8, 2012.

[0001157523-12-005081:8k_2_02:7]
Non-GAAP earnings per share exclude the effect of acquisition related
      expenses, amortizations and adjustments, and stock compensation expense.

[0001157523-12-005081:8k_2_02:8]
The Company confirmed that its third quarter conference call will be
      held Wednesday, October 10, 2012 at 9:30 a.m. Central Time. This
      conference call will be web cast live through StreetEvents.com. To
      listen, simply visit the Investor Relations site at www.adtran.com
      or www.streetevents.com approximately 10 minutes prior to the
      start of the call and click on the conference call link provided.

[0001157523-12-005081:8k_2_02:9]
An online replay of the conference call will be available for seven days
      at www.streetevents.com. In addition, an online replay of the
      conference call, as well as the text of the Company's earnings release,
      will be available on the Investor Relations site at www.adtran.com
      for at least 12 months following the call.

[0001157523-12-005081:8k_2_02:10]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment. ADTRAN’s products enable voice, data, video
      and Internet communications across a variety of network infrastructures.
      ADTRAN solutions are currently in use by service providers, private
      enterprises, government organizations, and millions of individual users
      worldwide. For more information, please visit www.adtran.com.

[0001157523-12-005081:8k_2_02:11]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-12-005081:8k_2_02:12]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2011 and our quarterly report on Form 10-Q for the quarter ended
      June 30, 2012. These risks and uncertainties could cause actual results
      to differ materially from those in the forward-looking statements
      included in this press release.

[0001157523-12-005081:8k_2_02:13]
| Condensed Consolidated Balance Sheet |
| (Unaudited) |
| (In thousands) |
|  |  |  |  | September 30,2012 |  |  |  | December 31,2011 |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  |  | $ | 43,535 |  |  |  | $ | 42,979 |
| Short-term investments |  |  |  |  | 190,333 |  |  |  |  | 159,347 |
| Accounts receivable, net |  |  |  |  | 102,693 |  |  |  |  | 76,130 |
| Other receivables |  |  |  |  | 8,260 |  |  |  |  | 9,743 |
| Inventory |  |  |  |  | 107,183 |  |  |  |  | 87,800 |
| Prepaid expenses |  |  |  |  | 4,354 |  |  |  |  | 3,119 |
| Deferred tax assets, net |  |  |  |  | 12,729 |  |  |  |  | 12,125 |
| Total Current Assets |  |  |  |  | 469,087 |  |  |  |  | 391,243 |
| Property, plant and equipment, net |  |  |  |  | 81,905 |  |  |  |  | 75,295 |
| Deferred tax assets, net |  |  |  |  | 6,843 |  |  |  |  | 8,345 |
| Goodwill |  |  |  |  | 3,492 |  |  |  |  | 3,492 |
| Other assets |  |  |  |  | 13,825 |  |  |  |  | 7,131 |
| Long-term investments |  |  |  |  | 327,106 |  |  |  |  | 332,008 |
| Total Assets |  |  |  | $ | 902,258 |  |  |  | $ | 817,514 |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  |  |  | $ | 52,285 |  |  |  | $ | 29,404 |
| Unearned revenue |  |  |  |  | 31,672 |  |  |  |  | 9,965 |
| Accrued expenses |  |  |  |  | 10,310 |  |  |  |  | 5,876 |
| Accrued wages and benefits |  |  |  |  | 16,894 |  |  |  |  | 13,518 |
| Income tax payable, net |  |  |  |  | 4,186 |  |  |  |  | 3,169 |
| Total Current Liabilities |  |  |  |  | 115,347 |  |  |  |  | 61,932 |
| Non-current unearned revenue |  |  |  |  | 19,085 |  |  |  |  | 4,874 |
| Other non-current liabilities |  |  |  |  | 15,882 |  |  |  |  | 12,077 |
| Bonds payable |  |  |  |  | 46,500 |  |  |  |  | 46,500 |
| Total Liabilities |  |  |  |  | 196,814 |  |  |  |  | 125,383 |
| Stockholders' Equity |  |  |  |  | 705,444 |  |  |  |  | 692,131 |
| Total Liabilities and Stockholders' Equity |  |  |  | $ | 902,258 |  |  |  | $ | 817,514 |

[0001157523-12-005081:8k_2_02:14]
| Consolidated Statements of Income |
| (Unaudited) |
| (In thousands, except per share data) |
|  |  |  |  | Three Months Ended |  |  | Nine Months Ended |
|  |  |  |  | September 30, |  |  | September 30, |
|  |  |  |  | 2012 |  |  |  | 2011 |  |  | 2012 |  |  |  | 2011 |
| Sales |  |  |  | $ | 162,125 |  |  |  |  | $ | 192,194 |  |  |  | $ | 480,858 |  |  |  |  | $ | 541,943 |  |
| Cost of sales |  |  |  |  | 82,153 |  |  |  |  |  | 82,718 |  |  |  |  | 231,598 |  |  |  |  |  | 226,845 |  |
| Gross Profit |  |  |  |  | 79,972 |  |  |  |  |  | 109,476 |  |  |  |  | 249,260 |  |  |  |  |  | 315,098 |  |
| Selling, general and administrative expenses |  |  |  |  | 34,114 |  |  |  |  |  | 31,475 |  |  |  |  | 103,130 |  |  |  |  |  | 91,925 |  |
| Research and development expenses |  |  |  |  | 35,582 |  |  |  |  |  | 26,894 |  |  |  |  | 92,835 |  |  |  |  |  | 75,150 |  |
| Operating Income |  |  |  |  | 10,276 |  |  |  |  |  | 51,107 |  |  |  |  | 53,295 |  |  |  |  |  | 148,023 |  |
| Interest and dividend income |  |  |  |  | 1,864 |  |  |  |  |  | 2,037 |  |  |  |  | 5,651 |  |  |  |  |  | 5,829 |  |
| Interest expense |  |  |  |  | (587 | ) |  |  |  |  | (599 | ) |  |  |  | (1,756 | ) |  |  |  |  | (1,795 | ) |
| Net realized investment gain |  |  |  |  | 2,530 |  |  |  |  |  | 2,982 |  |  |  |  | 7,353 |  |  |  |  |  | 9,121 |  |
| Other income (expense), net |  |  |  |  | (368 | ) |  |  |  |  | (155 | ) |  |  |  | 265 |  |  |  |  |  | (397 | ) |
| Gain on bargain purchase of a business |  |  |  |  | - |  |  |  |  |  | - |  |  |  |  | 1,753 |  |  |  |  |  | - |  |
| Income before provision for income taxes |  |  |  |  | 13,715 |  |  |  |  |  | 55,372 |  |  |  |  | 66,561 |  |  |  |  |  | 160,781 |  |
| Provision for income taxes |  |  |  |  | (4,443 | ) |  |  |  |  | (19,159 | ) |  |  |  | (23,259 | ) |  |  |  |  | (53,367 | ) |
| Net Income |  |  |  | $ | 9,272 |  |  |  |  | $ | 36,213 |  |  |  | $ | 43,302 |  |  |  |  | $ | 107,414 |  |
| Weighted average shares outstanding - basic |  |  |  |  | 63,066 |  |  |  |  |  | 64,023 |  |  |  |  | 63,495 |  |  |  |  |  | 64,300 |  |
| Weighted average shares outstanding - diluted (1) |  |  |  |  | 63,304 |  |  |  |  |  | 64,961 |  |  |  |  | 64,139 |  |  |  |  |  | 65,697 |  |
| Earnings per common share - basic |  |  |  | $ | 0.15 |  |  |  |  | $ | 0.57 |  |  |  | $ | 0.68 |  |  |  |  | $ | 1.67 |  |
| Earnings per common share - diluted (1) |  |  |  | $ | 0.15 |  |  |  |  | $ | 0.56 |  |  |  | $ | 0.68 |  |  |  |  | $ | 1.63 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001157523-12-005081:8k_2_02:15]
| Consolidated Statements of Comprehensive Income |
| (Unaudited) |
| (In thousands) |
|  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |
|  |  |  |  | September 30, |  |  |  | September 30, |
|  |  |  |  | 2012 |  |  |  | 2011 |  |  |  | 2012 |  |  |  | 2011 |
| Net Income |  |  |  | $ | 9,272 |  |  |  | $ | 36,213 |  |  |  |  | $ | 43,302 |  |  |  | $ | 107,414 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net change in unrealized gains (losses) on marketable securities |  |  |  |  | 154 |  |  |  |  | (5,468 | ) |  |  |  |  | 1,855 |  |  |  |  | (11,259 | ) |
| Reclassification adjustments for amounts included in net income |  |  |  |  | 343 |  |  |  |  | (287 | ) |  |  |  |  | 164 |  |  |  |  | (682 | ) |
| Foreign currency translation |  |  |  |  | 134 |  |  |  |  | (1,487 | ) |  |  |  |  | 191 |  |  |  |  | (1,031 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  |  |  | 631 |  |  |  |  | (7,242 | ) |  |  |  |  | 2,210 |  |  |  |  | (12,972 | ) |
| Comprehensive Income, net of tax |  |  |  | $ | 9,903 |  |  |  | $ | 28,971 |  |  |  |  | $ | 45,512 |  |  |  | $ | 94,442 |  |

[0001157523-12-005081:8k_2_02:16]
| Consolidated Statements of Cash Flows |
| (Unaudited) |
| (In thousands) |
|  |  |  |  | Nine Months Ended |
|  |  |  |  | September 30, |
|  |  |  |  |  | 2012 |  |  |  |  |  | 2011 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  |  |  | $ | 43,302 |  |  |  |  | $ | 107,414 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 10,366 |  |  |  |  |  | 8,435 |  |
| Amortization of net premium on available-for-sale investments |  |  |  |  | 6,343 |  |  |  |  |  | 4,697 |  |
| Net realized gain on long-term investments |  |  |  |  | (7,352 | ) |  |  |  |  | (9,121 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  |  |  | (213 | ) |  |  |  |  | 14 |  |
| Gain on bargain purchase of a business |  |  |  |  | (1,753 | ) |  |  |  |  | - |  |
| Stock-based compensation expense |  |  |  |  | 6,783 |  |  |  |  |  | 6,455 |  |
| Deferred income taxes |  |  |  |  | (1,156 | ) |  |  |  |  | 128 |  |
| Tax benefit from stock option exercises |  |  |  |  | 1,813 |  |  |  |  |  | 10,457 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  |  |  | (1,412 | ) |  |  |  |  | (9,311 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (26,178 | ) |  |  |  |  | (18,440 | ) |
| Other receivables |  |  |  |  | 1,866 |  |  |  |  |  | (8,525 | ) |
| Income tax receivable, net |  |  |  |  | - |  |  |  |  |  | 2,741 |  |
| Inventory |  |  |  |  | 2,142 |  |  |  |  |  | (12,247 | ) |
| Prepaid expenses and other assets |  |  |  |  | (1,193 | ) |  |  |  |  | 207 |  |
| Accounts payable |  |  |  |  | 17,607 |  |  |  |  |  | 8,924 |  |
| Accrued expenses and other liabilities |  |  |  |  | 12,769 |  |  |  |  |  | 15,047 |  |
| Income tax payable, net |  |  |  |  | 1,022 |  |  |  |  |  | 1,916 |  |
| Net cash provided by operating activities |  |  |  |  | 64,756 |  |  |  |  |  | 108,791 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  |  |  | (10,759 | ) |  |  |  |  | (9,531 | ) |
| Proceeds from disposals of property, plant and equipment |  |  |  |  | 266 |  |  |  |  |  | - |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  |  |  | 198,566 |  |  |  |  |  | 378,288 |  |
| Purchases of available-for-sale investments |  |  |  |  | (220,355 | ) |  |  |  |  | (443,275 | ) |
| Acquisition of business |  |  |  |  | 7,496 |  |  |  |  |  | (22,762 | ) |
| Net cash used in investing activities |  |  |  |  | (24,786 | ) |  |  |  |  | (97,280 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  |  |  | 4,932 |  |  |  |  |  | 33,631 |  |
| Purchases of treasury stock |  |  |  |  | (28,578 | ) |  |  |  |  | (35,178 | ) |
| Dividend payments |  |  |  |  | (17,173 | ) |  |  |  |  | (17,395 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  |  |  | 1,412 |  |  |  |  |  | 9,311 |  |
| Net cash used in financing activities |  |  |  |  | (39,407 | ) |  |  |  |  | (9,631 | ) |
| Net increase in cash and cash equivalents |  |  |  |  | 563 |  |  |  |  |  | 1,880 |  |
| Effect of exchange rate changes |  |  |  |  | (7 | ) |  |  |  |  | (1,031 | ) |
| Cash and cash equivalents, beginning of period |  |  |  |  | 42,979 |  |  |  |  |  | 31,677 |  |
| Cash and cash equivalents, end of period |  |  |  | $ | 43,535 |  |  |  |  | $ | 32,526 |  |

[0001157523-12-005081:8k_2_02:17]
| Supplemental Information |
| Acquisition Related Expenses, Amortizations and Adjustments |
| (Unaudited) |
| (In thousands) |
| On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and nine months ended September 30, 2012 and 2011 for both transactions are as follows: |
|  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |
|  |  |  |  | September 30, |  |  |  | September 30, |
|  |  |  |  |  | 2012 |  |  |  |  |  | 2011 |  |  |  |  |  | 2012 |  |  |  |  |  | 2011 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  |  | $ | 268 |  |  |  |  | $ | 198 |  |  |  |  | $ | 753 |  |  |  |  | $ | 198 |  |
| Amortization of other purchase accounting adjustments |  |  |  |  | 37 |  |  |  |  |  | 217 |  |  |  |  |  | 414 |  |  |  |  |  | 217 |  |
| Acquisition related professional fees, travel and other expenses |  |  |  |  | - |  |  |  |  |  | 630 |  |  |  |  |  | - |  |  |  |  |  | 630 |  |
| Subtotal |  |  |  |  | 305 |  |  |  |  |  | 1,045 |  |  |  |  |  | 1,167 |  |  |  |  |  | 1,045 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  |  |  | 300 |  |  |  |  |  | - |  |  |  |  |  | 472 |  |  |  |  |  | - |  |
| Amortization of other purchase accounting adjustments |  |  |  |  | 666 |  |  |  |  |  | - |  |  |  |  |  | 1,718 |  |  |  |  |  | - |  |
| Acquisition related professional fees, travel and other expenses |  |  |  |  | 252 |  |  |  |  |  | 931 |  |  |  |  |  | 4,537 |  |  |  |  |  | 992 |  |
| Subtotal |  |  |  |  | 1,218 |  |  |  |  |  | 931 |  |  |  |  |  | 6,727 |  |  |  |  |  | 992 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  |  |  | 1,523 |  |  |  |  |  | 1,976 |  |  |  |  |  | 7,894 |  |  |  |  |  | 2,037 |  |
| Tax effect |  |  |  |  | (496 | ) |  |  |  |  | (751 | ) |  |  |  |  | (2,660 | ) |  |  |  |  | (776 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  |  |  | $ | 1,027 |  |  |  |  | $ | 1,225 |  |  |  |  | $ | 5,234 |  |  |  |  | $ | 1,261 |  |

[0001157523-12-005081:8k_2_02:18]
| The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and nine months ended September 30, 2012 and 2011: |
|  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |
|  |  |  |  | September 30, |  |  |  | September 30, |
|  |  |  |  |  | 2012 |  |  |  |  |  | 2011 |  |  |  |  |  | 2012 |  |  |  |  |  | 2011 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  |  |  | $ | 497 |  |  |  |  | $ | 155 |  |  |  |  | $ | 1,151 |  |  |  |  | $ | 155 |  |
| Cost of goods sold |  |  |  |  | 126 |  |  |  |  |  | 66 |  |  |  |  |  | 932 |  |  |  |  |  | 66 |  |
| Subtotal |  |  |  |  | 623 |  |  |  |  |  | 221 |  |  |  |  |  | 2,083 |  |  |  |  |  | 221 |  |
| Selling, general and administrative expenses |  |  |  |  | 258 |  |  |  |  |  | 1,374 |  |  |  |  |  | 4,180 |  |  |  |  |  | 1,424 |  |
| Research and development expenses |  |  |  |  | 642 |  |  |  |  |  | 381 |  |  |  |  |  | 1,631 |  |  |  |  |  | 392 |  |
| Subtotal |  |  |  |  | 900 |  |  |  |  |  | 1,755 |  |  |  |  |  | 5,811 |  |  |  |  |  | 1,816 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  |  |  | 1,523 |  |  |  |  |  | 1,976 |  |  |  |  |  | 7,894 |  |  |  |  |  | 2,037 |  |
| Tax effect |  |  |  |  | (496 | ) |  |  |  |  | (751 | ) |  |  |  |  | (2,660 | ) |  |  |  |  | (776 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  |  |  | $ | 1,027 |  |  |  |  | $ | 1,225 |  |  |  |  | $ | 5,234 |  |  |  |  | $ | 1,261 |  |

[0001157523-12-005081:8k_2_02:19]
| Supplemental Information |
| Stock-based Compensation Expense |
| (Unaudited) |
| (In thousands) |
|  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |
|  |  |  |  | September 30, |  |  |  | September 30, |
|  |  |  |  |  | 2012 |  |  |  |  |  | 2011 |  |  |  |  |  | 2012 |  |  |  |  |  | 2011 |  |
| Stock-based compensation expense included in cost of sales |  |  |  | $ | 106 |  |  |  |  | $ | 100 |  |  |  |  | $ | 304 |  |  |  |  | $ | 280 |  |
| Selling, general and administrative expense |  |  |  |  | 1,107 |  |  |  |  |  | 1,090 |  |  |  |  |  | 3,205 |  |  |  |  |  | 3,096 |  |
| Research and development expense |  |  |  |  | 1,138 |  |  |  |  |  | 1,100 |  |  |  |  |  | 3,274 |  |  |  |  |  | 3,079 |  |
| Stock-based compensation expense included in operating expenses |  |  |  |  | 2,245 |  |  |  |  |  | 2,190 |  |  |  |  |  | 6,479 |  |  |  |  |  | 6,175 |  |
| Total stock-based compensation expense |  |  |  |  | 2,351 |  |  |  |  |  | 2,290 |  |  |  |  |  | 6,783 |  |  |  |  |  | 6,455 |  |
| Tax benefit for expense associated with non-qualified options |  |  |  |  | (313 | ) |  |  |  |  | (302 | ) |  |  |  |  | (916 | ) |  |  |  |  | (1,018 | ) |
| Total stock-based compensation expense, net of tax |  |  |  | $ | 2,038 |  |  |  |  | $ | 1,988 |  |  |  |  | $ | 5,867 |  |  |  |  | $ | 5,437 |  |

[0001157523-12-005081:8k_2_02:20]
| Reconciliation of GAAP net income per share, diluted, to |
| Non-GAAP net income per share, diluted |
| (Unaudited) |
|  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |
|  |  |  |  | September 30, |  |  |  | September 30, |
|  |  |  |  |  | 2012 |  |  |  |  | 2011 |  |  |  |  | 2012 |  |  |  |  |  | 2011 |
| GAAP earnings per common share – diluted |  |  |  | $ | 0.15 |  |  |  | $ | 0.56 |  |  |  | $ | 0.68 |  |  |  |  | $ | 1.63 |
| Acquisition related expenses, amortizations and adjustments |  |  |  |  | 0.02 |  |  |  |  | 0.02 |  |  |  |  | 0.08 |  |  |  |  |  | 0.02 |
| Stock-based compensation expense |  |  |  |  | 0.03 |  |  |  |  | 0.03 |  |  |  |  | 0.09 |  |  |  |  |  | 0.08 |
| Bargain purchase gain – NSN BBA acquisition |  |  |  | - |  |  |  | - |  |  |  |  | (0.03 | ) |  |  |  | - |
| Non-GAAP earnings per common share – diluted |  |  |  | $ | 0.20 |  |  |  | $ | 0.61 |  |  |  | $ | 0.82 |  |  |  |  | $ | 1.73 |

[0001157523-12-005081:8k_2_02:21]
CONTACT:
ADTRAN, Inc.
Jim Matthews, 256-963-8775
Senior Vice
      President/CFO
or
Investor Services/Assistance:
Gayle
      Ellis, 256-963-8220
