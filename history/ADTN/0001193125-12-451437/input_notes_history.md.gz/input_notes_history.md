# ADTN note change history — 0001193125-12-334164 → 0001193125-12-451437


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-11-05):
[0001193125-12-451437:note_history:1]
We have committed to invest
up to an aggregate of $7.9 million in two private equity funds, and
we have contributed $8.4 million as of September 30, 2012, of
which $7.7 million has been applied to these
commitments.
  (was, 2012-08-03, similarity 0.9726):
[0001193125-12-334164:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30,
   2012, of which $7.7 million has been applied to these commitments.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-11-05):
[0001193125-12-451437:note_history:2]
During the nine months
ended September 30, 2012, we adopted the following accounting
standards, which had no material effect on our consolidated results
of operations or financial condition:
  (was, 2012-08-03, similarity 0.9558):
[0001193125-12-334164:note_history:2]
During the six months ended June 30, 2012, we adopted the following accounting standards, which had no material effect on our consolidated results of operations or financial condition:

- changed (2012-11-05):
[0001193125-12-451437:note_history:3]
In June 2011, the Financial
Accounting Standards Board (FASB) issued Accounting Standards
Update No. 2011-05, Presentation of Comprehensive Income (ASU
2011-05). ASU 2011-05 requires companies to present the components
of net income and other comprehensive income either as one
continuous statement or as two consecutive statements. ASU 2011-05
eliminates the option to present the components of other
comprehensive income as part of the statement of changes in
stockholders’ equity. While ASU 2011-05 changes the
presentation of comprehensive income, it does not change the
components that are recognized in net income or comprehensive
income under current accounting guidance. This update is effective
for fiscal years, and interim periods within those years, ending
after December 15, 2011, with early adoption permitted. We
adopted this amendment during the first quarter of 2012, and we
have provided the disclosures required for the three and nine
months ended September 30, 2012 and 2011.
  (was, 2012-08-03, similarity 0.9641):
[0001193125-12-334164:note_history:3]
In June 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update
   No. 2011-05, Presentation of Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to present the components of net income and other comprehensive income either as one continuous statement or as two consecutive statements. ASU
   2011-05 eliminates the option to present the components of other comprehensive income as part of the statement of changes in stockholders’ equity. While ASU 2011-05 changes the presentation of comprehensive income, it does not change the
   components that are recognized in net income or comprehensive income under current accounting guidance. This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption
   permitted. We adopted this amendment during the first quarter of 2012, and we have provided the disclosures required for the three and six months ended June 30, 2012 and 2011.

- changed (2012-11-05):
[0001193125-12-451437:note_history:4]
In December 2011, the FASB
issued Accounting Standards Update No. 2011-12, Deferral of
the Effective Date for Amendments to the Presentation of
Reclassifications of Items Out of Accumulated Other Comprehensive
Income in Accounting Standards Update No. 2011-05 (ASU
2011-12). ASU 2011-12 defers the effective date for certain
presentation requirements that relate to reclassification
adjustments and the effect of those reclassification adjustments on
the financial statements. This update is effective for fiscal
years, and interim periods within those years, ending after
December 15, 2011, with early adoption permitted. We adopted
this amendment during the first quarter of 2012. The adoption of
this amendment had no effect on our consolidated results of
operations and financial condition for the three and nine months
ended September 30, 2012.
  (was, 2012-08-03, similarity 0.9654):
[0001193125-12-334164:note_history:4]
In December 2011, the FASB issued Accounting Standards Update No. 2011-12, Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other
   Comprehensive Income in Accounting Standards Update No. 2011-05 (ASU 2011-12). ASU 2011-12 defers the effective date for certain presentation requirements that relate to reclassification adjustments and the effect of those reclassification
   adjustments on the financial statements. This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption permitted. We adopted this amendment during the first quarter of
   2012. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the three and six months ended June 30, 2012.

- changed (2012-11-05):
[0001193125-12-451437:note_history:5]
In May 2011, the FASB
issued Accounting Standards Update No. 2011-04, Amendments to
Achieve Common Fair Value Measurement and Disclosure Requirements
in U.S. GAAP and IFRSs (ASU 2011-04). ASU 2011-04 is intended to
improve the comparability of fair value measurements presented and
disclosed in financial statements prepared in accordance with U.S.
GAAP and IFRS. The amendments are of two types: (i) those that
clarify the Board’s intent about the application of existing
fair value measurement and disclosure requirements and
(ii) those that change a particular principle or requirement
for measuring fair value or for disclosing information about fair
value measurements. This update is effective for annual periods
beginning after December 15, 2011. We adopted this amendment
during the first quarter of 2012. The adoption of this amendment
had no effect on our consolidated results of operations and
financial condition for the three and nine months ended
September 30, 2012.
  (was, 2012-08-03, similarity 0.9703):
[0001193125-12-334164:note_history:5]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to
   Achieve Common Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IFRSs (ASU 2011-04). ASU 2011-04 is intended to improve the comparability of fair value measurements presented and disclosed in financial statements prepared in
   accordance with U.S. GAAP and IFRS. The amendments are of two types: (i) those that clarify the Board’s intent about the application of existing fair value measurement and disclosure requirements and (ii) those that change a
   particular principle or requirement for measuring fair value or for disclosing information about fair value measurements. This update is effective for annual periods beginning after December 15, 2011. We adopted this amendment during the first
   quarter of 2012. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the three and six months ended June 30, 2012.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-11-05):
[0001193125-12-451437:note_history:6]
At September 30, 2012,
we held the following securities and investments, recorded at
either fair value or cost.
  (was, 2012-08-03, similarity 0.9463):
[0001193125-12-334164:note_history:6]
At June 30, 2012, we held the following securities and investments, recorded at either fair value or cost.

- changed (2012-11-05):
[0001193125-12-451437:note_history:7]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,199 |  |  | $ | 795 |  |  | $ | (6 | ) |  | $ | 10,988 |  |
| Corporate bonds |  |  | 165,912 |  |  |  | 1,080 |  |  |  | (65 | ) |  |  | 166,927 |  |
| Municipal fixed-rate bonds |  |  | 190,893 |  |  |  | 947 |  |  |  | (9 | ) |  |  | 191,831 |  |
| Municipal variable rate demand notes |  |  | 58,780 |  |  |  | — |  |  |  | — |  |  |  | 58,780 |  |
| Fixed income bond fund |  |  | 862 |  |  |  | 18 |  |  |  | — |  |  |  | 880 |  |
| Marketable equity securities |  |  | 20,618 |  |  |  | 17,550 |  |  |  | (348 | ) |  |  | 37,820 |  |
| Available-for-sale securities held at fair value |  | $ | 447,264 |  |  | $ | 20,390 |  |  | $ | (428 | ) |  | $ | 467,226 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,963 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 517,439 |  |
  (was, 2012-08-03, similarity 0.9989):
[0001193125-12-334164:note_history:7]
| (In thousands) |  | AmortizedCost |  |  | Gross Unrealized |  |  | CarryingValue |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 7,994 |  |  | $ | 119 |  |  | $ | (401 | ) |  | $ | 7,712 |  |
| Corporate bonds |  |  | 159,077 |  |  |  | 181 |  |  |  | (2,505 | ) |  |  | 156,753 |  |
| Municipal fixed-rate bonds |  |  | 174,300 |  |  |  | 579 |  |  |  | (53 | ) |  |  | 174,826 |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | — |  |  |  | 69,660 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 194 |  |  |  | — |  |  |  | 721 |  |
| Marketable equity securities |  |  | 12,771 |  |  |  | 19,098 |  |  |  | (559 | ) |  |  | 31,310 |  |
| Available-for-sale securities held at fair value |  | $ | 424,329 |  |  | $ | 20,171 |  |  | $ | (3,518 | ) |  | $ | 440,982 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,123 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 491,355 |  |

- changed (2012-11-05):
[0001193125-12-451437:note_history:8]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 7,994 |  |  | $ | 119 |  |  | $ | (401 | ) |  | $ | 7,712 |  |
| Corporate bonds |  |  | 159,077 |  |  |  | 181 |  |  |  | (2,505 | ) |  |  | 156,753 |  |
| Municipal fixed-rate bonds |  |  | 174,300 |  |  |  | 579 |  |  |  | (53 | ) |  |  | 174,826 |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | — |  |  |  | 69,660 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 194 |  |  |  | — |  |  |  | 721 |  |
| Marketable equity securities |  |  | 12,771 |  |  |  | 19,098 |  |  |  | (559 | ) |  |  | 31,310 |  |
| Available-for-sale securities held at fair value |  | $ | 424,329 |  |  | $ | 20,171 |  |  | $ | (3,518 | ) |  | $ | 440,982 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,123 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 491,355 |  |
  (was, 2012-08-03, similarity 0.9978):
[0001193125-12-334164:note_history:8]
| (In thousands) |  | AmortizedCost |  |  | Gross Unrealized |  |  | CarryingValue |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,598 |  |  | $ | 392 |  |  | $ | (190 | ) |  | $ | 10,800 |  |
| Corporate bonds |  |  | 183,282 |  |  |  | 786 |  |  |  | (333 | ) |  |  | 183,735 |  |
| Municipal fixed-rate bonds |  |  | 188,845 |  |  |  | 696 |  |  |  | (23 | ) |  |  | 189,518 |  |
| Municipal variable rate demand notes |  |  | 46,790 |  |  |  | — |  |  |  | — |  |  |  | 46,790 |  |
| Fixed income bond fund |  |  | 846 |  |  |  | — |  |  |  | — |  |  |  | 846 |  |
| Marketable equity securities |  |  | 18,052 |  |  |  | 18,423 |  |  |  | (603 | ) |  |  | 35,872 |  |
| Available-for-sale securities held at fair value |  | $ | 448,413 |  |  | $ | 20,297 |  |  | $ | (1,149 | ) |  | $ | 467,561 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,062 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 517,873 |  |

- changed (2012-11-05):
[0001193125-12-451437:note_history:9]
As of September 30,
2012, our corporate bonds and municipal fixed-rate bonds had the
following contractual maturities:
  (was, 2012-08-03, similarity 0.9498):
[0001193125-12-334164:note_history:9]
As of June 30, 2012, our corporate bonds and municipal fixed-rate bonds had the following contractual maturities:

- changed (2012-11-05):
[0001193125-12-451437:note_history:10]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 55,739 |  |  | $ | 73,594 |  |
| One to two years |  |  | 99,858 |  |  |  | 53,694 |  |
| Two to three years |  |  | 11,330 |  |  |  | 12,286 |  |
| Three to five years |  |  | — |  |  |  | 52,257 |  |
| Total |  | $ | 166,927 |  |  | $ | 191,831 |  |
  (was, 2012-08-03, similarity 0.9947):
[0001193125-12-334164:note_history:10]
| (In thousands) |  | Corporatebonds |  |  | Municipalfixed-ratebonds |  |
| Less than one year |  | $ | 39,614 |  |  | $ | 83,045 |  |
| One to two years |  |  | 114,900 |  |  |  | 56,268 |  |
| Two to three years |  |  | 29,221 |  |  |  | 7,210 |  |
| Three to five years |  |  | — |  |  |  | 42,995 |  |
| Total |  | $ | 183,735 |  |  | $ | 189,518 |  |

- changed (2012-11-05):
[0001193125-12-451437:note_history:11]
We review our investment
portfolio for potential “other-than-temporary” declines
in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be
considered other-than-temporary and, if necessary, recognize and
record the appropriate charge to write-down the carrying value of
such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including
but not limited to the following: the magnitude and duration of
historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by
the issuer. We generally begin our identification of potential
other-than-temporary impairments by reviewing any security with a
fair value that has declined from its original or adjusted cost
basis by 25% or more for six or more consecutive months. We then
evaluate the individual security based on the previously identified
factors to determine the amount of the write-down, if any. As a
result of our review, we recorded an other-than-temporary
impairment charge of $0.1 million during the nine months ended
September 30, 2012 related to 21 marketable equity securities.
In addition to the impairment charge we recorded on our marketable
equity securities, we recorded an impairment of $0.6 million during
the nine months ended September 30, 2012 related to our
deferred compensation plan as a result of similar reviews. For the
nine months ended September 30, 2011, we recorded an
other-than-temporary impairment charge of $32 thousand related to
seven marketable equity securities.
  (was, 2012-08-03, similarity 0.7636):
[0001193125-12-334164:note_history:11]
We review our investment portfolio for
   potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the
   appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of
   historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security
   with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the
   write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $33 thousand during the six months ended June 30, 2012 related to eight marketable equity securities. For the six months ended June 30,
   2011, we recorded an other-than-temporary impairment charge of $12 thousand related to three marketable equity securities.

- changed (2012-11-05):
[0001193125-12-451437:note_history:12]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Gross realized gains |  | $ | 3,388 |  |  | $ | 3,401 |  |  | $ | 8,688 |  |  | $ | 9,770 |  |
| Gross realized losses |  | $ | (858 | ) |  | $ | (419 | ) |  | $ | (1,335 | ) |  | $ | (649 | ) |
  (was, 2012-08-03, similarity 0.86):
[0001193125-12-334164:note_history:12]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Gross realized gains |  | $ | 2,631 |  |  | $ | 3,505 |  |  | $ | 5,300 |  |  | $ | 6,369 |  |
| Gross realized losses |  | $ | (275 | ) |  | $ | (133 | ) |  | $ | (477 | ) |  | $ | (230 | ) |

- changed (2012-11-05):
[0001193125-12-451437:note_history:13]
As of September 30,
2012 and 2011, gross unrealized losses related to individual
securities that had been in a continuous loss position for 12
months or longer were not significant.
  (was, 2012-08-03, similarity 0.9674):
[0001193125-12-334164:note_history:13]
As of June 30, 2012 and 2011, gross unrealized losses related to individual securities that had been in a continuous loss position
   for 12 months or longer were not significant.

- changed (2012-11-05):
[0001193125-12-451437:note_history:14]
|  |  | Fair Value Measurements at September 30, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 16,861 |  |  | $ | 16,861 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 10,988 |  |  |  | 10,988 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 166,927 |  |  |  | — |  |  |  | 166,927 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 191,831 |  |  |  | — |  |  |  | 191,831 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 58,780 |  |  |  | — |  |  |  | 58,780 |  |  |  | — |  |
| Fixed income bond fund |  |  | 880 |  |  |  | 880 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 17,360 |  |  |  | 17,360 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 20,460 |  |  |  | 20,460 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 467,226 |  |  |  | 49,688 |  |  |  | 417,538 |  |  |  | — |  |
| Total |  | $ | 484,087 |  |  | $ | 66,549 |  |  | $ | 417,538 |  |  | $ | — |  |
  (was, 2012-08-03, similarity 0.844):
[0001193125-12-334164:note_history:14]
|  |  | Fair Value Measurements at June 30, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket forIdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 9,250 |  |  | $ | 9,250 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 10,800 |  |  |  | 10,800 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 183,735 |  |  |  | — |  |  |  | 183,735 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 189,518 |  |  |  | — |  |  |  | 189,518 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 46,790 |  |  |  | — |  |  |  | 46,790 |  |  |  | — |  |
| Fixed income bond fund |  |  | 846 |  |  |  | 846 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 18,053 |  |  |  | 18,053 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 17,819 |  |  |  | 17,819 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 467,561 |  |  |  | 47,518 |  |  |  | 420,043 |  |  |  | — |  |
| Total |  | $ | 476,811 |  |  | $ | 56,768 |  |  | $ | 420,043 |  |  | $ | — |  |

- changed (2012-11-05):
[0001193125-12-451437:note_history:15]
|  |  | Fair Value Measurements at December 31, 2011 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 13,696 |  |  | $ | 13,696 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 7,712 |  |  |  | 7,712 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 156,753 |  |  |  | — |  |  |  | 156,753 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 174,826 |  |  |  | — |  |  |  | 174,826 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | 69,660 |  |  |  | — |  |
| Fixed income bond fund |  |  | 721 |  |  |  | 721 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 18,743 |  |  |  | 18,743 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 12,567 |  |  |  | 12,567 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 440,982 |  |  |  | 39,743 |  |  |  | 401,239 |  |  |  | — |  |
| Total |  | $ | 454,678 |  |  | $ | 53,439 |  |  | $ | 401,239 |  |  | $ | — |  |
  (was, 2012-08-03, similarity 0.9638):
[0001193125-12-334164:note_history:15]
|  |  | Fair Value Measurements at December 31, 2011 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket forIdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 13,696 |  |  | $ | 13,696 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 7,712 |  |  |  | 7,712 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 156,753 |  |  |  | — |  |  |  | 156,753 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 174,826 |  |  |  | — |  |  |  | 174,826 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | 69,660 |  |  |  | — |  |
| Fixed income bond fund |  |  | 721 |  |  |  | 721 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 18,743 |  |  |  | 18,743 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 12,567 |  |  |  | 12,567 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 440,982 |  |  |  | 39,743 |  |  |  | 401,239 |  |  |  | — |  |
| Total |  | $ | 454,678 |  |  | $ | 53,439 |  |  | $ | 401,239 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2012-11-05):
[0001193125-12-451437:note_history:16]
We employ the law firm of
our director emeritus for legal services. All bills for services
rendered by this firm are reviewed and approved by our Chief
Financial Officer. We believe that the fees for such services are
comparable to those charged by other firms for services rendered to
us. For the three and nine month periods ended September 30,
2012 and 2011, we incurred fees of $10 thousand per month for these
legal services.
  (was, 2012-08-03, similarity 0.9257):
[0001193125-12-334164:note_history:16]
We employ the law firm of our director emeritus for legal services. All bills for services rendered by this firm are reviewed and
   approved by our Chief Financial Officer. We believe that the fees for such services are comparable to those charged by other firms for services rendered to us. For the three and six month periods ended June 30, 2012 and 2011, we incurred fees
   of $10 thousand per month for these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2012-11-05):
[0001193125-12-451437:note_history:17]
On October 9, 2012, we
announced that our Board of Directors declared a quarterly cash
dividend of $0.09 per common share to be paid to stockholders of
record at the close of business on October 25, 2012. The
payment date will be November 8, 2012. The quarterly dividend
payment will be approximately $5.6 million. In July 2003, our Board
of Directors elected to begin declaring quarterly dividends on our
common stock considering the tax treatment of dividends and
adequate levels of Company liquidity.

- added (2012-11-05):
[0001193125-12-451437:note_history:18]
During the fourth quarter
of 2012 and as of November 5, 2012, we repurchased
0.3 million shares of our common stock through open market
purchases at an average cost of $16.01 per share. We currently have
the authority to purchase an additional 4.4 million shares of
our common stock under the current plan approved by the Board of
Directors.

- removed (2012-11-05):
[0001193125-12-334164:note_history:19]
On July 10, 2012, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid
   to stockholders of record at the close of business on July 26, 2012. The payment date will be August 9, 2012. The quarterly dividend payment will be approximately $5.7 million. In July 2003, our Board of Directors elected to begin
   declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

- removed (2012-11-05):
[0001193125-12-334164:note_history:20]
During
   the third quarter of 2012 and as of August 3, 2012, we repurchased 0.5 million shares of our common stock through open market purchases at an average cost of $21.08 per share. We have the authority to purchase an additional
   4.9 million shares of our common stock under plans approved by the Board of Directors on April 14, 2008 and October 11, 2011.
