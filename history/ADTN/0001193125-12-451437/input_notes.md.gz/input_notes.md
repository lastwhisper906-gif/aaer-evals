# ADTN notes — 0001193125-12-451437


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-12-451437:notes:1]
4. PENSION BENEFIT
PLAN

[0001193125-12-451437:notes:2]
As a result of our
acquisition of the NSN BBA business, we assumed a defined benefit
obligation of $17.0 million as of May 4, 2012. We established
a Contribution Trust Arrangement (CTA) to hold the pension assets,
and NSN has transferred assets to us equal to the defined benefit
obligation.

[0001193125-12-451437:notes:3]
The following table
summarizes the components of net periodic pension cost for the
three months ended September 30, 2012 and the period
May 4, 2012 to September 30, 2012:

[0001193125-12-451437:notes:4]
|  |  | Three Months Ended |  |  | May 4, 2012 to |  |
| (In thousands) |  | September 30, 2012 |  |  | September 30, 2012 |  |
| Service cost |  | $ | 288 |  |  | $ | 478 |  |
| Interest cost |  |  | 187 |  |  |  | 314 |  |
| Expected return on plan assets |  |  | (250 | ) |  |  | (415 | ) |
| Net periodic pension cost |  | $ | 225 |  |  | $ | 377 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-451437:notes:5]
10. EARNINGS PER
SHARE

[0001193125-12-451437:notes:6]
A summary of the
calculation of basic and diluted earnings per share for the three
and nine months ended September 30, 2012 and 2011 is as
follows:

[0001193125-12-451437:notes:7]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 9,272 |  |  | $ | 36,213 |  |  | $ | 43,302 |  |  | $ | 107,414 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 63,066 |  |  |  | 64,023 |  |  |  | 63,495 |  |  |  | 64,300 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 225 |  |  |  | 882 |  |  |  | 637 |  |  |  | 1,346 |  |
| Restricted stock and restricted stock units |  |  | 13 |  |  |  | 56 |  |  |  | 7 |  |  |  | 51 |  |
| Weighted average number of shares – diluted |  |  | 63,304 |  |  |  | 64,961 |  |  |  | 64,139 |  |  |  | 65,697 |  |
| Net income per share – basic |  | $ | 0.15 |  |  | $ | 0.57 |  |  | $ | 0.68 |  |  | $ | 1.67 |  |
| Net income per share – diluted |  | $ | 0.15 |  |  | $ | 0.56 |  |  | $ | 0.68 |  |  | $ | 1.63 |  |

[0001193125-12-451437:notes:8]
Anti-dilutive options to
purchase common stock outstanding were excluded from the above
calculations. Anti-dilutive options totaled 4.4 million
and 1.5 million for the three months ended September 30,
2012 and 2011, respectively, and 2.6 million and
1.0 million for the nine months ended September 30, 2012
and 2011, respectively.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001193125-12-451437:notes:9]
The following supplemental
pro forma information presents the financial results as if the
acquisition of the NSN BBA business had occurred on January 1,
2011. This supplemental pro forma information does not purport to
be indicative of what would have occurred had the acquisition of
the NSN BBA business been completed on January 1, 2011, nor
are they indicative of any future results.

[0001193125-12-451437:notes:10]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Pro forma revenue |  | $ | 44,978 |  |  | $ | 100,413 |  |  | $ | 153,263 |  |
| Pro forma pre-tax loss |  | $ | (10,947 | ) |  | $ | (18,006 | ) |  | $ | (31,987 | ) |
| Weighted average exchange rate during the period (EURO/USD) |  |  | €1.00/$1.42 |  |  | € | 1.00/$1.29 |  |  | € | 1.00/$1.40 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-12-451437:notes:11]
13. RELATED PARTY
TRANSACTIONS

[0001193125-12-451437:notes:12]
We employ the law firm of
our director emeritus for legal services. All bills for services
rendered by this firm are reviewed and approved by our Chief
Financial Officer. We believe that the fees for such services are
comparable to those charged by other firms for services rendered to
us. For the three and nine month periods ended September 30,
2012 and 2011, we incurred fees of $10 thousand per month for these
legal services.


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-12-451437:notes:13]
At September 30, 2012,
we held the following securities and investments, recorded at
either fair value or cost.

[0001193125-12-451437:notes:14]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,199 |  |  | $ | 795 |  |  | $ | (6 | ) |  | $ | 10,988 |  |
| Corporate bonds |  |  | 165,912 |  |  |  | 1,080 |  |  |  | (65 | ) |  |  | 166,927 |  |
| Municipal fixed-rate bonds |  |  | 190,893 |  |  |  | 947 |  |  |  | (9 | ) |  |  | 191,831 |  |
| Municipal variable rate demand notes |  |  | 58,780 |  |  |  | — |  |  |  | — |  |  |  | 58,780 |  |
| Fixed income bond fund |  |  | 862 |  |  |  | 18 |  |  |  | — |  |  |  | 880 |  |
| Marketable equity securities |  |  | 20,618 |  |  |  | 17,550 |  |  |  | (348 | ) |  |  | 37,820 |  |
| Available-for-sale securities held at fair value |  | $ | 447,264 |  |  | $ | 20,390 |  |  | $ | (428 | ) |  | $ | 467,226 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,963 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 517,439 |  |

[0001193125-12-451437:notes:15]
At December 31, 2011,
we held the following securities and investments, recorded at
either fair value or cost.

[0001193125-12-451437:notes:16]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 7,994 |  |  | $ | 119 |  |  | $ | (401 | ) |  | $ | 7,712 |  |
| Corporate bonds |  |  | 159,077 |  |  |  | 181 |  |  |  | (2,505 | ) |  |  | 156,753 |  |
| Municipal fixed-rate bonds |  |  | 174,300 |  |  |  | 579 |  |  |  | (53 | ) |  |  | 174,826 |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | — |  |  |  | 69,660 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 194 |  |  |  | — |  |  |  | 721 |  |
| Marketable equity securities |  |  | 12,771 |  |  |  | 19,098 |  |  |  | (559 | ) |  |  | 31,310 |  |
| Available-for-sale securities held at fair value |  | $ | 424,329 |  |  | $ | 20,171 |  |  | $ | (3,518 | ) |  | $ | 440,982 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,123 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 491,355 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-12-451437:notes:17]
15. SUBSEQUENT
EVENTS

[0001193125-12-451437:notes:18]
On October 9, 2012, we
announced that our Board of Directors declared a quarterly cash
dividend of $0.09 per common share to be paid to stockholders of
record at the close of business on October 25, 2012. The
payment date will be November 8, 2012. The quarterly dividend
payment will be approximately $5.6 million. In July 2003, our Board
of Directors elected to begin declaring quarterly dividends on our
common stock considering the tax treatment of dividends and
adequate levels of Company liquidity.

[0001193125-12-451437:notes:19]
During the fourth quarter
of 2012 and as of November 5, 2012, we repurchased
0.3 million shares of our common stock through open market
purchases at an average cost of $16.01 per share. We currently have
the authority to purchase an additional 4.4 million shares of
our common stock under the current plan approved by the Board of
Directors.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-451437:notes:20]
3. INCOME
TAXES

[0001193125-12-451437:notes:21]
Our effective tax rate
increased from 33.2% in the nine months ended September 30,
2011 to 34.9% in the nine months ended September 30,
2012. The tax provision rate in the nine months ended
September 30, 2012 did not include the benefit of the research
tax credit, which expired on December 31, 2011. The
exclusion of this benefit during the nine months ended
September 30, 2012 resulted in a 2.2 percentage point increase
in our effective tax rate. Reduced stock option exercises,
increase in a valuation allowance related to foreign subsidiary
losses, and an increase in reserves related to state apportionment
resulted in an additional 6.1 percentage point increase in our
effective tax rate for the nine months ended September 30,
2012. These increases were partially offset by provision to return
reconciliation adjustments related to 2011, adjustments related to
closed tax years and associated audits, and employment related
state income tax incentives, which resulted in a 6.6 percentage
point decrease in our effective tax rate for the nine months ended
September 30, 2012.

[0001193125-12-451437:notes:22]
During the nine months
ended September 30, 2012, we acquired the NSN BBA business,
which resulted in a bargain purchase gain reported on the income
statement. The bargain purchase gain is presented net of tax in the
income statement and a deferred tax liability was established in
the opening balance sheet for the acquired entity.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001193125-12-451437:notes:23]
The following table
presents information about the reported sales and gross profit of
our reportable segments for the three and nine months ended
September 30, 2012 and 2011. Asset information by reportable
segment is not reported, since we do not produce such information
internally.

[0001193125-12-451437:notes:24]
|  |  | Three Months Ended |  |
|  |  | September 30, 2012 |  |  | September 30, 2011 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 131,942 |  |  | $ | 63,827 |  |  | $ | 152,492 |  |  | $ | 85,944 |  |
| Enterprise Networks |  |  | 30,183 |  |  |  | 16,145 |  |  |  | 39,702 |  |  |  | 23,532 |  |
| Total |  | $ | 162,125 |  |  | $ | 79,972 |  |  | $ | 192,194 |  |  | $ | 109,476 |  |

[0001193125-12-451437:notes:25]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2012 |  |  | September 30, 2011 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 381,303 |  |  | $ | 195,448 |  |  | $ | 435,344 |  |  | $ | 252,908 |  |
| Enterprise Networks |  |  | 99,555 |  |  |  | 53,812 |  |  |  | 106,599 |  |  |  | 62,190 |  |
| Total |  | $ | 480,858 |  |  | $ | 249,260 |  |  | $ | 541,943 |  |  | $ | 315,098 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-12-451437:notes:26]
In accordance with the Fair
Value Measurements and Disclosures Topic of the FASB ASC, we have
categorized our cash equivalents held in money market funds and our
investments held at fair value into a three-level fair value
hierarchy based on the priority of the inputs to the valuation
technique for the cash equivalents and investments as follows:
Level 1 – Values based on unadjusted quoted prices for
identical assets or liabilities in an active market; Level 2
– Values based on quoted prices in markets that are not
active or model inputs that are observable either directly or
indirectly; Level 3 – Values based on prices or valuation
techniques that require inputs that are both unobservable and
significant to the overall fair value measurement. These inputs
include information supplied by investees.

[0001193125-12-451437:notes:27]
|  |  | Fair Value Measurements at September 30, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 16,861 |  |  | $ | 16,861 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 10,988 |  |  |  | 10,988 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 166,927 |  |  |  | — |  |  |  | 166,927 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 191,831 |  |  |  | — |  |  |  | 191,831 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 58,780 |  |  |  | — |  |  |  | 58,780 |  |  |  | — |  |
| Fixed income bond fund |  |  | 880 |  |  |  | 880 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 17,360 |  |  |  | 17,360 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 20,460 |  |  |  | 20,460 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 467,226 |  |  |  | 49,688 |  |  |  | 417,538 |  |  |  | — |  |
| Total |  | $ | 484,087 |  |  | $ | 66,549 |  |  | $ | 417,538 |  |  | $ | — |  |

[0001193125-12-451437:notes:28]
|  |  | Fair Value Measurements at December 31, 2011 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 13,696 |  |  | $ | 13,696 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 7,712 |  |  |  | 7,712 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 156,753 |  |  |  | — |  |  |  | 156,753 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 174,826 |  |  |  | — |  |  |  | 174,826 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | 69,660 |  |  |  | — |  |
| Fixed income bond fund |  |  | 721 |  |  |  | 721 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 18,743 |  |  |  | 18,743 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 12,567 |  |  |  | 12,567 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 440,982 |  |  |  | 39,743 |  |  |  | 401,239 |  |  |  | — |  |
| Total |  | $ | 454,678 |  |  | $ | 53,439 |  |  | $ | 401,239 |  |  | $ | — |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-12-451437:notes:29]
A summary of the changes in
stockholders’ equity for the nine months ended
September 30, 2012 is as follows:

[0001193125-12-451437:notes:30]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2011 |  | $ | 692,131 |  |
| Net income |  |  | 43,302 |  |
| Dividend payments |  |  | (17,173 | ) |
| Dividends accrued for unvested restricted stock units |  |  | 24 |  |
| Net change in unrealized gains and losses on marketable securities (net of deferred taxes) |  |  | 1,855 |  |
| Reclassification adjustment for amounts included in net income (net of deferred taxes) |  |  | 164 |  |
| Foreign currency translation adjustment |  |  | 191 |  |
| Proceeds from stock option exercises |  |  | 4,932 |  |
| Purchase of treasury stock |  |  | (28,578 | ) |
| Tax benefits from stock option exercises |  |  | 1,813 |  |
| Stock-based compensation expense |  |  | 6,783 |  |
| Balance, September 30, 2012 |  | $ | 705,444 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-12-451437:notes:31]
Basis of
Presentation

[0001193125-12-451437:notes:32]
The accompanying
unaudited consolidated financial statements of ADTRAN®,
Inc. and its subsidiaries (ADTRAN) have been prepared pursuant to
the rules and regulations for reporting on Quarterly Reports on
Form 10-Q. Accordingly, certain information and notes required by
generally accepted accounting principles for complete financial
statements are not included herein. The December 31, 2011
Consolidated Balance Sheet is derived from audited financial
statements, but does not include all disclosures required by
accounting principles generally accepted in the United
States.

[0001193125-12-451437:notes:33]
In the opinion of
management, all adjustments necessary for a fair presentation of
these interim statements have been included and are of a normal and
recurring nature. The results of operations for an interim period
are not necessarily indicative of the results for the full year.
The interim statements should be read in conjunction with the
financial statements and notes thereto included in ADTRAN’s
Annual Report on Form 10-K for the year ended December 31,
2011, filed on February 29, 2012 with the SEC.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-451437:notes:34]
7.
INVENTORY

[0001193125-12-451437:notes:35]
At September 30, 2012
and December 31, 2011, inventory consisted of the
following:

[0001193125-12-451437:notes:36]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |
| Raw materials |  | $ | 48,868 |  |  | $ | 44,588 |  |
| Work in process |  |  | 5,495 |  |  |  | 3,954 |  |
| Finished goods |  |  | 52,820 |  |  |  | 39,258 |  |
| Total |  | $ | 107,183 |  |  | $ | 87,800 |  |

[0001193125-12-451437:notes:37]
We establish reserves for
estimated excess, obsolete, or unmarketable inventory equal to the
difference between the cost of the inventory and the estimated fair
value of the inventory based upon assumptions about future demand
and market conditions. At September 30, 2012 and
December 31, 2011, raw materials reserves totaled $9.3 million
and $7.9 million, respectively, and finished goods inventory
reserves totaled $2.0 million and $1.5 million,
respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-12-451437:notes:38]
9. STOCKHOLDERS’
EQUITY

[0001193125-12-451437:notes:39]
Stock Repurchase
Program

[0001193125-12-451437:notes:40]
Since 1997, our Board of
Directors has approved multiple share repurchase programs that have
authorized open market repurchase transactions of up to
35 million shares of our common stock. During the nine months
ended September 30, 2012, we repurchased 1.2 million
shares of our common stock at an average price of $24.24 per share.
We currently have the authority to purchase an additional
4.7 million shares of our common stock under the current plan
approved by the Board of Directors.

[0001193125-12-451437:notes:41]
Stock Option
Exercises

[0001193125-12-451437:notes:42]
We issued 0.3 million
shares of treasury stock during the nine months ended
September 30, 2012 to accommodate employee stock option
exercises. The stock options had exercise prices ranging from $8.70
to $33.70. We received proceeds totaling $4.9 million from the
exercise of these stock options during the nine months ended
September 30, 2012.

[0001193125-12-451437:notes:43]
Dividend
Payments

[0001193125-12-451437:notes:44]
During the nine months
ended September 30, 2012, we paid cash dividends as follows
(in thousands except per share amount):

[0001193125-12-451437:notes:45]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 2, 2012 |  | February 16, 2012 |  | $ | 0.09 |  |  | $ | 5,739 |  |
| April 26, 2012 |  | May 10, 2012 |  | $ | 0.09 |  |  | $ | 5,737 |  |
| July 26, 2012 |  | August 9, 2012 |  | $ | 0.09 |  |  | $ | 5,697 |  |

[0001193125-12-451437:notes:46]
Other Comprehensive
Income

[0001193125-12-451437:notes:47]
Other comprehensive income
consists of the net change in unrealized gains and losses on
marketable securities, reclassification adjustments for amounts
included in net income related to realized gains on previously
impaired marketable securities and foreign currency translation
adjustments.

[0001193125-12-451437:notes:48]
The components of other
comprehensive income for the three months ended September 30,
2012 and 2011 are as follows:

[0001193125-12-451437:notes:49]
|  |  | Three Months Ended September 30, 2012 |  |  | Three Months Ended September 30, 2011 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Net change in unrealized gains (losses) related to marketable securities |  | $ | 253 |  |  | $ | (99 | ) |  | $ | 154 |  |  | $ | (9,001 | ) |  | $ | 3,533 |  |  | $ | (5,468 | ) |
| Reclassification adjustment for amounts included in net income |  |  | 562 |  |  |  | (219 | ) |  |  | 343 |  |  |  | (482 | ) |  |  | 195 |  |  |  | (287 | ) |
| Foreign currency translation adjustment |  |  | 134 |  |  |  | — |  |  |  | 134 |  |  |  | (1,487 | ) |  |  | — |  |  |  | (1,487 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 949 |  |  | $ | (318 | ) |  | $ | 631 |  |  | $ | (10,970 | ) |  | $ | 3,728 |  |  | $ | (7,242 | ) |

[0001193125-12-451437:notes:50]
The components of other
comprehensive income for the nine months ended September 30,
2012 and 2011 are as follows:

[0001193125-12-451437:notes:51]
|  |  | Nine Months Ended September 30, 2012 |  |  | Nine Months Ended September 30, 2011 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Net change in unrealized gains (losses) related to marketable securities |  | $ | 3,041 |  |  | $ | (1,186 | ) |  | $ | 1,855 |  |  | $ | (17,494 | ) |  | $ | 6,235 |  |  | $ | (11,259 | ) |
| Reclassification adjustment for amounts included in net income |  |  | 269 |  |  |  | (105 | ) |  |  | 164 |  |  |  | (1,063 | ) |  |  | 381 |  |  |  | (682 | ) |
| Foreign currency translation adjustment |  |  | 191 |  |  |  | — |  |  |  | 191 |  |  |  | (1,031 | ) |  |  | — |  |  |  | (1,031 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 3,501 |  |  | $ | (1,291 | ) |  | $ | 2,210 |  |  | $ | (19,588 | ) |  | $ | 6,616 |  |  | $ | (12,972 | ) |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-12-451437:notes:52]
As of September 30,
2012, our corporate bonds and municipal fixed-rate bonds had the
following contractual maturities:

[0001193125-12-451437:notes:53]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 55,739 |  |  | $ | 73,594 |  |
| One to two years |  |  | 99,858 |  |  |  | 53,694 |  |
| Two to three years |  |  | 11,330 |  |  |  | 12,286 |  |
| Three to five years |  |  | — |  |  |  | 52,257 |  |
| Total |  | $ | 166,927 |  |  | $ | 191,831 |  |


## us-gaap:ScheduleOfRealizedGainLossTableTextBlock

[0001193125-12-451437:notes:54]
Realized gains and losses
on sales of securities are computed under the specific
identification method. The following table presents gross realized
gains and losses related to our investments.

[0001193125-12-451437:notes:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Gross realized gains |  | $ | 3,388 |  |  | $ | 3,401 |  |  | $ | 8,688 |  |  | $ | 9,770 |  |
| Gross realized losses |  | $ | (858 | ) |  | $ | (419 | ) |  | $ | (1,335 | ) |  | $ | (649 | ) |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-12-451437:notes:56]
As of September 30,
2012, the estimated future amortization expense of our intangible
assets is as follows:

[0001193125-12-451437:notes:57]
| (In thousands) |  | Amount |  |
| Remainder of 2012 |  | $ | 606 |  |
| 2013 |  |  | 2,408 |  |
| 2014 |  |  | 2,254 |  |
| 2015 |  |  | 2,119 |  |
| 2016 |  |  | 1,848 |  |
| Thereafter |  |  | 3,906 |  |
| Total |  | $ | 13,141 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-12-451437:notes:58]
The table below presents
sales information by geographic area for the three and nine months
ended September 30, 2012 and 2011. International sales
correlate to shipments with a non-U.S. destination.

[0001193125-12-451437:notes:59]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (In thousands) |  | September 30, |  |  | September 30, |  |
|  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| United States |  | $ | 112,972 |  |  | $ | 170,343 |  |  | $ | 359,804 |  |  | $ | 484,260 |  |
| International |  |  | 49,153 |  |  |  | 21,851 |  |  |  | 121,054 |  |  |  | 57,683 |  |
| Total |  | $ | 162,125 |  |  | $ | 192,194 |  |  | $ | 480,858 |  |  | $ | 541,943 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-12-451437:notes:60]
The following table is a
summary of our stock options outstanding as of December 31,
2011 and September 30, 2012 and the changes that occurred
during the nine months ended September 30, 2012:

[0001193125-12-451437:notes:61]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2011 |  |  | 5,400 |  |  | $ | 25.66 |  |  |  | 6.78 |  |  | $ | 27,270 |  |
| Options granted |  |  | 98 |  |  | $ | 27.75 |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (42 | ) |  | $ | 26.63 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (284 | ) |  | $ | 17.39 |  |  |  |  |  |  |  |  |  |
| Options outstanding, September 30, 2012 |  |  | 5,172 |  |  | $ | 26.15 |  |  |  | 6.24 |  |  | $ | 1,632 |  |
| Options exercisable, September 30, 2012 |  |  | 3,013 |  |  | $ | 24.62 |  |  |  | 4.93 |  |  | $ | 1,205 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001193125-12-451437:notes:62]
The table below presents
sales information by product category for the three and nine months
ended September 30, 2012 and 2011.

[0001193125-12-451437:notes:63]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Carrier Systems |  | $ | 111,577 |  |  | $ | 119,979 |  |  | $ | 309,590 |  |  | $ | 319,018 |  |
| Business Networking |  |  | 36,600 |  |  |  | 44,919 |  |  |  | 116,332 |  |  |  | 116,981 |  |
| Loop Access |  |  | 13,948 |  |  |  | 27,296 |  |  |  | 54,936 |  |  |  | 105,944 |  |
| Total |  | $ | 162,125 |  |  | $ | 192,194 |  |  | $ | 480,858 |  |  | $ | 541,943 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-12-451437:notes:64]
8. GOODWILL AND
INTANGIBLE ASSETS

[0001193125-12-451437:notes:65]
The changes in the carrying
value of goodwill, all of which is included in our Enterprise
Networks division, for the nine months ended September 30,
2012 are as follows:

[0001193125-12-451437:notes:66]
| (In thousands) |  |  |  |
| Balance, December 31, 2011 |  | $ | 3,492 |  |
| Acquisitions |  |  | — |  |
| Impairment losses |  |  | — |  |
| Balance, September 30, 2012 |  | $ | 3,492 |  |
| Balance as of September 30, 2012 |  |  |  |  |
| Goodwill |  | $ | 3,492 |  |
| Accumulated impairment losses |  |  | — |  |
| Total goodwill |  | $ | 3,492 |  |

[0001193125-12-451437:notes:67]
We evaluate the carrying
value of goodwill during the fourth quarter of each year and
between annual evaluations if events occur or circumstances change
that would more likely than not reduce the fair value of the
reporting unit below its carrying amount. When evaluating whether
goodwill is impaired, we first assess qualitative factors to
determine whether it is necessary to perform the two-step
quantitative goodwill impairment test. If we determine that the
two-step quantitative test is necessary, then we compare the fair
value of the reporting unit to which the goodwill is assigned to
the reporting unit’s carrying amount, including goodwill. If
the carrying amount of the reporting unit exceeds its fair value,
then the amount of the impairment loss is measured. There were no
impairment losses recorded during the nine months ended
September 30, 2012.

[0001193125-12-451437:notes:68]
The following table
presents our intangible assets as of September 30, 2012 and
December 31, 2011. Intangible assets are included in other
assets in the accompanying Consolidated Balance Sheets and include
intangibles acquired in conjunction with our acquisition of
Objectworld Communications Corporation on September 15, 2009,
Bluesocket, Inc. on August 4, 2011, and the NSN BBA business
on May 4, 2012.

[0001193125-12-451437:notes:69]
|  |  | September 30, 2012 |  |  | December 31, 2011 |  |
| (In thousands) |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,636 |  |  | $ | (569 | ) |  | $ | 6,067 |  |  | $ | 1,623 |  |  | $ | (194 | ) |  | $ | 1,429 |  |
| Developed technology |  |  | 6,315 |  |  |  | (1,024 | ) |  |  | 5,291 |  |  |  | 3,230 |  |  |  | (303 | ) |  |  | 2,927 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (768 | ) |  |  | 1,572 |  |  |  | 2,340 |  |  |  | (525 | ) |  |  | 1,815 |  |
| Trade names |  |  | 270 |  |  |  | (70 | ) |  |  | 200 |  |  |  | 270 |  |  |  | (28 | ) |  |  | 242 |  |
| Other |  |  | 13 |  |  |  | (2 | ) |  |  | 11 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 15,574 |  |  | $ | (2,433 | ) |  | $ | 13,141 |  |  | $ | 7,463 |  |  | $ | (1,050 | ) |  | $ | 6,413 |  |

[0001193125-12-451437:notes:70]
Amortization expense was
$0.6 million and $0.3 million for the three months ended
September 30, 2012 and 2011, respectively, and $1.4 million
and $0.4 million for the nine months ended September 30, 2012
and 2011, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-451437:notes:71]
5. STOCK-BASED
COMPENSATION

[0001193125-12-451437:notes:72]
The following table
summarizes the stock-based compensation expense related to stock
options, restricted stock units (RSUs) and restricted stock for the
three and nine months ended September 30, 2012 and 2011, which
was recognized as follows:

[0001193125-12-451437:notes:73]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 106 |  |  | $ | 100 |  |  | $ | 304 |  |  | $ | 280 |  |
| Selling, general and administrative expense |  |  | 1,107 |  |  |  | 1,090 |  |  |  | 3,205 |  |  |  | 3,096 |  |
| Research and development expense |  |  | 1,138 |  |  |  | 1,100 |  |  |  | 3,274 |  |  |  | 3,079 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,245 |  |  |  | 2,190 |  |  |  | 6,479 |  |  |  | 6,175 |  |
| Total stock-based compensation expense |  |  | 2,351 |  |  |  | 2,290 |  |  |  | 6,783 |  |  |  | 6,455 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (313 | ) |  |  | (302 | ) |  |  | (916 | ) |  |  | (1,018 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 2,038 |  |  | $ | 1,988 |  |  | $ | 5,867 |  |  | $ | 5,437 |  |

[0001193125-12-451437:notes:74]
The fair value of our stock
options was estimated using the Black-Scholes model. The
determination of the fair value of stock options on the date of
grant using the Black-Scholes model is affected by our stock price
as well as assumptions regarding a number of complex and subjective
variables that may have a significant impact on the fair value
estimate.

[0001193125-12-451437:notes:75]
The weighted-average
assumptions and value of options granted for the three and nine
months ended September 30, 2012 and 2011 are summarized as
follows:

[0001193125-12-451437:notes:76]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Expected volatility |  |  | 40.20 | % |  |  | 38.31 | % |  |  | 40.20 | % |  |  | 38.31 | % |
| Risk-free interest rate |  |  | 0.63 | % |  |  | 1.00 | % |  |  | 0.63 | % |  |  | 1.00 | % |
| Expected dividend yield |  |  | 1.30 | % |  |  | 1.19 | % |  |  | 1.30 | % |  |  | 1.19 | % |
| Expected life (in years) |  |  | 4.95 |  |  |  | 5.14 |  |  |  | 4.95 |  |  |  | 5.14 |  |
| Weighted-average estimated value |  | $ | 8.69 |  |  | $ | 9.52 |  |  | $ | 8.69 |  |  | $ | 9.54 |  |

[0001193125-12-451437:notes:77]
The fair value of our RSUs
is calculated using a Monte Carlo Simulation valuation method.
There were no RSU grants during the nine months ended
September 30, 2012 or 2011.

[0001193125-12-451437:notes:78]
The fair value of
restricted stock is equal to the closing price of our stock on the
date of grant. There were no restricted stock grants during the
nine months ended September 30, 2012 or 2011.

[0001193125-12-451437:notes:79]
Stock-based compensation
expense recognized in our Consolidated Statements of Income for the
three and nine months ended September 30, 2012 and 2011 is
based on options, RSUs and restricted stock ultimately expected to
vest, and has been reduced for estimated forfeitures. Estimated
forfeitures for stock options were based upon historical experience
and approximate 1.6% annually. We estimated a 0% forfeiture rate
for our RSUs and restricted stock due to the limited number of
recipients and historical experience for these awards.

[0001193125-12-451437:notes:80]
As of September 30,
2012, total compensation expense related to non-vested stock
options, RSUs and restricted stock not yet recognized was
approximately $15.8 million, which is expected to be recognized
over an average remaining recognition period of 2.4
years.

[0001193125-12-451437:notes:81]
The aggregate intrinsic
values in the table above represent the total pre-tax intrinsic
value (the difference between ADTRAN’s closing stock price on
the last trading day of the quarter and the exercise price,
multiplied by the number of in-the-money options) that would have
been received by the option holders had all option holders
exercised their options on September 30, 2012. The aggregate
intrinsic value will change based on the fair market value of
ADTRAN’s stock.

[0001193125-12-451437:notes:82]
The total pre-tax intrinsic
value of options exercised during the three and nine month periods
ended September 30, 2012 was $0.5 million and $4.1 million,
respectively.

[0001193125-12-451437:notes:83]
The following table is a
summary of our RSUs and restricted stock outstanding as of
December 31, 2011 and September 30, 2012 and the changes
that occurred during the nine months ended September 30,
2012:

[0001193125-12-451437:notes:84]
| (In thousands, except per share amounts) |  | Number of Shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2011 |  |  | 90 |  |  | $ | 34.21 |  |
| RSUs and restricted stock granted |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock vested |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  | $ | — |  |
| Unvested RSUs and restricted stock, September 30, 2012 |  |  | 90 |  |  | $ | 34.21 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-12-451437:notes:85]
12. LIABILITY FOR
WARRANTY RETURNS

[0001193125-12-451437:notes:86]
Our products generally
include warranties of 90 days to ten years for product defects. We
accrue for warranty returns at the time revenue is recognized based
on our estimate of the cost to repair or replace the defective
products. We engage in extensive product quality programs and
processes, including actively monitoring and evaluating the quality
of our component suppliers. Our products continue to become more
complex in both size and functionality as many of our product
offerings migrate from line card applications to systems products.
The increasing complexity of our products will cause warranty
incidences, when they arise, to be more costly. Our estimates
regarding future warranty obligations may change due to product
failure rates, material usage, and other rework costs incurred in
correcting a product failure. In addition, from time to time,
specific warranty accruals may be recorded if unforeseen problems
arise. Should our actual experience relative to these factors be
worse than our estimates, we will be required to record additional
warranty expense. Alternatively, if we provide for more reserves
than we require, we will reverse a portion of such provisions in
future periods. The liability for warranty obligations totaled $7.3
million at September 30, 2012 and $4.1 million at
December 31, 2011. These liabilities are included in accrued
expenses in the accompanying Consolidated Balance
Sheets.

[0001193125-12-451437:notes:87]
A summary of warranty
expense and write-off activity for the nine months ended
September 30, 2012 and 2011 is as follows:

[0001193125-12-451437:notes:88]
| Nine Months Ended September 30, |  | 2012 |  |  | 2011 |  |
| (In thousands) |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 4,118 |  |  | $ | 3,304 |  |
| Plus: Amounts charged to cost and expenses |  |  | 3,910 |  |  |  | 2,306 |  |
| Amounts assumed on acquisition |  |  | 1,932 |  |  |  | — |  |
| Less: Deductions |  |  | (2,709 | ) |  |  | (1,743 | ) |
| Balance at end of period |  | $ | 7,251 |  |  | $ | 3,867 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-451437:notes:89]
14. COMMITMENTS AND
CONTINGENCIES

[0001193125-12-451437:notes:90]
In the ordinary course of
business, we may be subject to various legal proceedings and
claims, including employment disputes, patent claims, disputes over
contract agreements and other commercial disputes. In some cases,
claimants seek damages or other relief, such as royalty payments
related to patents, which, if granted, could require significant
expenditures. Although the outcome of any claim or litigation can
never be certain, it is our opinion that the outcome of all
contingencies of which we are currently aware will not materially
affect our business, operations, financial condition or cash
flows.

[0001193125-12-451437:notes:91]
We have committed to invest
up to an aggregate of $7.9 million in two private equity funds, and
we have contributed $8.4 million as of September 30, 2012, of
which $7.7 million has been applied to these
commitments.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-451437:notes:92]
11. SEGMENT
INFORMATION

[0001193125-12-451437:notes:93]
We operate in two
reportable segments: (1) the Carrier Networks Division and
(2) the Enterprise Networks Division. We evaluate the
performance of our segments based on gross profit; therefore,
selling, general and administrative expense, research and
development expenses, interest income and dividend income, interest
expense, net realized investment gain/loss, other income/expense
and provision for taxes are reported on an entity-wide basis only.
There are no inter-segment revenues.

[0001193125-12-451437:notes:94]
Sales by
Product

[0001193125-12-451437:notes:95]
Our three major product
categories are Carrier Systems, Business Networking and Loop
Access.

[0001193125-12-451437:notes:96]
Carrier
Systems products are used by communications service providers
to provide data, voice and video services to consumers and
enterprises. The Carrier Systems category includes our broadband
access products comprised of Total Access®
5000 multi-service access and aggregation platform products, Total
Access 1100/1200 Series Fiber-To-The-Node (FTTN) products, hiX 5600
Series Multi-Service Access Node (MSAN), Ultra Broadband Ethernet
(UBE) and Digital Subscriber Line Access Multiplexer (DSLAM)
products. Our broadband access products are used by service
providers around the world to deliver high-speed Internet access,
Plain Old Telephone Service (POTS), Voice over Internet Protocol
(VoIP), IP Television (IPTV), and/or Ethernet services from the
central office or remote terminal locations to customer premises.
The Carrier Systems category also includes our optical products.
These products consist of optical multiplexers and transceivers
including those used in our Optical Networking Edge (ONE) products,
NetVanta 8000 series products, and our family of OPTI products.
Optical products are used to deliver higher bandwidth services,
aggregate large numbers of low bandwidth services, or transport
wavelength services across a fiber optic infrastructure. Total
Access 1500 products, 303 concentrator products, M13 multiplexer
products, and a number of mobile backhaul products are also
included in the Carrier Systems product category.

[0001193125-12-451437:notes:97]
Business Networking
products provide access to telecommunication services, facilitating
the delivery of converged services and Unified Communications to
the small and mid-sized enterprises (SME) market. The Business
Networking category includes Internetworking products and
Integrated Access Devices (IADs). Internetworking products consist
of our Total Access IP Business Gateways, Optical Network Terminals
(ONTs), Virtual Wireless LAN products and NetVanta product lines.
NetVanta products include multi-service routers, managed Ethernet
switches, IP Private Branch Exchange (PBX) products, IP phone
products, Unified Communications solutions, Unified Threat
Management (UTM) solutions, and Carrier Ethernet Network
Terminating Equipment (NTE). IAD products consist of our Total
Access 600 Series and the Total Access 850.

[0001193125-12-451437:notes:98]
Loop Access products
are used by carrier and enterprise customers for access to
copper-based telecommunications networks. The Loop Access category
includes products such as: Digital Data Service (DDS) and
Integrated Services Digital Network (Total Reach) products, High
bit-rate Digital Subscriber Line (HDSL) products including Total
Access 3000 HDSL and Time Division Multiplexed-Symmetrical HDSL
(TDM-SHDSL) products, T1/E1/T3, Channel Service Units/Data Service
Units, and TRACER fixed wireless products.

[0001193125-12-451437:notes:99]
In addition, we identify
subcategories of product revenues, which we divide into our core
products and legacy products. Our core products consist of
Broadband Access and Optical products (included in Carrier Systems)
and Internetworking products (included in Business Networking) and
our legacy products include HDSL products (included in Loop Access)
and other products not included in the aforementioned core
products.

[0001193125-12-451437:notes:100]
Subcategory revenues
included in the above are as follows:

[0001193125-12-451437:notes:101]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 94,464 |  |  | $ | 86,954 |  |  | $ | 249,988 |  |  | $ | 215,798 |  |
| Optical (included in Carrier Systems) |  |  | 11,160 |  |  |  | 22,298 |  |  |  | 39,418 |  |  |  | 65,222 |  |
| Internetworking (NetVanta & Multi-service Access Gateways) (included in Business Networking) |  |  | 35,411 |  |  |  | 42,506 |  |  |  | 111,320 |  |  |  | 108,418 |  |
| Subtotal |  |  | 141,035 |  |  |  | 151,758 |  |  |  | 400,726 |  |  |  | 389,438 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 12,926 |  |  |  | 25,297 |  |  |  | 51,350 |  |  |  | 100,291 |  |
| Other products (excluding HDSL) |  |  | 8,164 |  |  |  | 15,139 |  |  |  | 28,782 |  |  |  | 52,214 |  |
| Subtotal |  |  | 21,090 |  |  |  | 40,436 |  |  |  | 80,132 |  |  |  | 152,505 |  |
| Total |  | $ | 162,125 |  |  | $ | 192,194 |  |  | $ | 480,858 |  |  | $ | 541,943 |  |

[0001193125-12-451437:notes:102]
Sales by Geographic
Region


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-12-451437:notes:103]
1. SUMMARY OF
SIGNIFICANT ACCOUNTING POLICIES

[0001193125-12-451437:notes:104]
The
accompanying unaudited consolidated financial statements of
ADTRAN®,
Inc. and its subsidiaries (ADTRAN) have been prepared pursuant to
the rules and regulations for reporting on Quarterly Reports on
Form 10-Q. Accordingly, certain information and notes required by
generally accepted accounting principles for complete financial
statements are not included herein. The December 31, 2011
Consolidated Balance Sheet is derived from audited financial
statements, but does not include all disclosures required by
accounting principles generally accepted in the United
States.

[0001193125-12-451437:notes:105]
Use of
Estimates

[0001193125-12-451437:notes:106]
The preparation of
financial statements in conformity with accounting principles
generally accepted in the United States of America requires
management to make estimates and assumptions that affect the
reported amounts of assets and liabilities, the disclosure of
contingent assets and liabilities at the date of the financial
statements, and the reported amounts of revenue and expense during
the reporting period. Our more significant estimates include the
allowance for doubtful accounts, obsolete and excess inventory
reserves, warranty reserves, customer rebates, allowance for sales
returns, determination of the deferred revenue components of
multiple element sales agreements, estimated costs to complete
obligations associated with deferred revenues, estimated income tax
contingencies, the fair value of stock-based compensation,
impairment of goodwill, value and estimated lives of intangible
assets, and the evaluation of other-than-temporary declines in the
value of investments. Actual amounts could differ significantly
from these estimates.

[0001193125-12-451437:notes:107]
Recent Accounting
Pronouncements

[0001193125-12-451437:notes:108]
During the nine months
ended September 30, 2012, we adopted the following accounting
standards, which had no material effect on our consolidated results
of operations or financial condition:

[0001193125-12-451437:notes:109]
In June 2011, the Financial
Accounting Standards Board (FASB) issued Accounting Standards
Update No. 2011-05, Presentation of Comprehensive Income (ASU
2011-05). ASU 2011-05 requires companies to present the components
of net income and other comprehensive income either as one
continuous statement or as two consecutive statements. ASU 2011-05
eliminates the option to present the components of other
comprehensive income as part of the statement of changes in
stockholders’ equity. While ASU 2011-05 changes the
presentation of comprehensive income, it does not change the
components that are recognized in net income or comprehensive
income under current accounting guidance. This update is effective
for fiscal years, and interim periods within those years, ending
after December 15, 2011, with early adoption permitted. We
adopted this amendment during the first quarter of 2012, and we
have provided the disclosures required for the three and nine
months ended September 30, 2012 and 2011.

[0001193125-12-451437:notes:110]
In December 2011, the FASB
issued Accounting Standards Update No. 2011-12, Deferral of
the Effective Date for Amendments to the Presentation of
Reclassifications of Items Out of Accumulated Other Comprehensive
Income in Accounting Standards Update No. 2011-05 (ASU
2011-12). ASU 2011-12 defers the effective date for certain
presentation requirements that relate to reclassification
adjustments and the effect of those reclassification adjustments on
the financial statements. This update is effective for fiscal
years, and interim periods within those years, ending after
December 15, 2011, with early adoption permitted. We adopted
this amendment during the first quarter of 2012. The adoption of
this amendment had no effect on our consolidated results of
operations and financial condition for the three and nine months
ended September 30, 2012.

[0001193125-12-451437:notes:111]
In May 2011, the FASB
issued Accounting Standards Update No. 2011-04, Amendments to
Achieve Common Fair Value Measurement and Disclosure Requirements
in U.S. GAAP and IFRSs (ASU 2011-04). ASU 2011-04 is intended to
improve the comparability of fair value measurements presented and
disclosed in financial statements prepared in accordance with U.S.
GAAP and IFRS. The amendments are of two types: (i) those that
clarify the Board’s intent about the application of existing
fair value measurement and disclosure requirements and
(ii) those that change a particular principle or requirement
for measuring fair value or for disclosing information about fair
value measurements. This update is effective for annual periods
beginning after December 15, 2011. We adopted this amendment
during the first quarter of 2012. The adoption of this amendment
had no effect on our consolidated results of operations and
financial condition for the three and nine months ended
September 30, 2012.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-12-451437:notes:112]
6.
INVESTMENTS

[0001193125-12-451437:notes:113]
Our investment policy
provides limitations for issuer concentration, which limits, at the
time of purchase, the concentration in any one issuer to 5% of the
market value of our total investment portfolio.

[0001193125-12-451437:notes:114]
We review our investment
portfolio for potential “other-than-temporary” declines
in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be
considered other-than-temporary and, if necessary, recognize and
record the appropriate charge to write-down the carrying value of
such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including
but not limited to the following: the magnitude and duration of
historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by
the issuer. We generally begin our identification of potential
other-than-temporary impairments by reviewing any security with a
fair value that has declined from its original or adjusted cost
basis by 25% or more for six or more consecutive months. We then
evaluate the individual security based on the previously identified
factors to determine the amount of the write-down, if any. As a
result of our review, we recorded an other-than-temporary
impairment charge of $0.1 million during the nine months ended
September 30, 2012 related to 21 marketable equity securities.
In addition to the impairment charge we recorded on our marketable
equity securities, we recorded an impairment of $0.6 million during
the nine months ended September 30, 2012 related to our
deferred compensation plan as a result of similar reviews. For the
nine months ended September 30, 2011, we recorded an
other-than-temporary impairment charge of $32 thousand related to
seven marketable equity securities.

[0001193125-12-451437:notes:115]
As of September 30,
2012 and 2011, gross unrealized losses related to individual
securities that had been in a continuous loss position for 12
months or longer were not significant.

[0001193125-12-451437:notes:116]
The fair value of our Level
2 securities is calculated using a weighted average market price
for each security. Market prices are obtained from a variety of
industry standard data providers, security master files from large
financial institutions, and other third-party sources. These
multiple market prices are used as inputs into a
distribution-curve-based algorithm to determine the daily market
value of each security.

[0001193125-12-451437:notes:117]
Our municipal variable rate
demand notes have a structure that implies a standard expected
market price. The frequent interest rate resets make it reasonable
to expect the price to stay at par. These securities are priced at
the expected market price.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-12-451437:notes:118]
2. BUSINESS
COMBINATIONS

[0001193125-12-451437:notes:119]
On May 4, 2012, we
acquired the Nokia Siemens Networks (NSN) Broadband Access business
(NSN BBA business). This acquisition provides us with an
established customer base in key markets and complementary,
market-focused products and was accounted for as a business
combination. We have included the financial results of the NSN BBA
business in our consolidated financial statements since the date of
acquisition. These revenues are included in the Carrier Networks
division in the Broadband Access subcategory.

[0001193125-12-451437:notes:120]
We received a cash payment
of $7.5 million from NSN and recorded a bargain purchase gain of
$1.8 million, net of income taxes, subject to customary working
capital adjustments between the parties as defined in the purchase
agreement. As of September 30, 2012, the parties were in the
process of resolving the working capital adjustments. The bargain
purchase gain of $1.8 million represents the excess of the
consideration exchanged over the fair value of the assets acquired
and liabilities assumed. We have assessed the recognition and
measurements of the assets acquired and liabilities assumed based
on historical and pro forma data for future periods and have
concluded that our valuation procedures and resulting measures were
appropriate. The gain is included in the line item “Gain on
bargain purchase of a business” in the 2012 Consolidated
Statements of Income.

[0001193125-12-451437:notes:121]
The preliminary allocation
of the purchase price to the estimated fair value of the assets
acquired and liabilities assumed at the acquisition date is as
follows:

[0001193125-12-451437:notes:122]
[same as prior period, unchanged from 0001193125-12-334164:notes:16]

[0001193125-12-451437:notes:123]
The fair value of the
customer relationships acquired was calculated using a discounted
cash flow method (excess earnings) and is being amortized using a
declining balance method derived from projected customer revenue
over an average estimated useful life of 13 years. The fair value
of the developed technology acquired was calculated using a
discounted cash flow method (relief from royalty) and is being
amortized using the straight-line method over an estimated useful
life of five years.

[0001193125-12-451437:notes:124]
The actual revenue and
pre-tax loss included in our Consolidated Statements of Income for
the three months ended September 30, 2012 and from the
acquisition date to September 30, 2012 are as
follows:

[0001193125-12-451437:notes:125]
|  |  | Three Months Ended |  |  | May 4, 2012 to |  |
| (In thousands) |  | September 30, 2012 |  |  | September 30, 2012 |  |
| Revenue |  | $ | 26,343 |  |  | $ | 48,983 |  |
| Pre-tax loss |  | $ | (2,547 | ) |  | $ | (2,947 | ) |

[0001193125-12-451437:notes:126]
For the three and nine
months ended September 30, 2012, we incurred acquisition and
integration related expenses and amortization of acquired
intangibles of $1.2 million and $6.7 million, respectively, related
to this acquisition.

[0001193125-12-451437:notes:127]
On August 4, 2011, we
acquired all of the outstanding stock of Bluesocket, Inc., a
provider of wireless network solutions with virtual control
capabilities, for $23.7 million in cash. The acquisition provides
us with IEEE802.11N enterprise class wireless LAN expertise,
technology, and products to address the growing transition within
small-medium enterprises and large enterprises to wireless networks
and mobile devices. We have included the financial results of
Bluesocket in our consolidated financial statements since the date
of acquisition. Pro forma results of operations prior to the
closing date for the acquisition have not been presented because
the effect of the acquisition was not material to our financial
results.

[0001193125-12-451437:notes:128]
The allocation of the
purchase price to the estimated fair value of the assets acquired
and liabilities assumed at the acquisition date is as
follows:

[0001193125-12-451437:notes:129]
[same as prior period, unchanged from 0001193125-12-334164:notes:24]

[0001193125-12-451437:notes:130]
During the fourth quarter
of 2011, the purchase price and purchase price allocation were
adjusted for our final valuations. The adjustments resulted in a
decrease to the goodwill recognized in the transaction.

[0001193125-12-451437:notes:131]
The net deferred tax assets
acquired are primarily related to net operating losses and
previously capitalized and unamortized research and development
expense for tax deduction purposes.

[0001193125-12-451437:notes:132]
The fair value of the
customer relationships, developed technology and intellectual
property acquired was calculated using an income approach (excess
earnings method) and is being amortized using the straight-line
method. The customer relationships and intellectual property are
being amortized over an estimated useful life of 7 years and the
developed technology is being amortized over an average estimated
useful life of 4.5 years.

[0001193125-12-451437:notes:133]
The fair value of the trade
names acquired was calculated using an income approach (relief from
royalty method) and is being amortized using the straight-line
method over the estimated useful life of 4.5 years.

[0001193125-12-451437:notes:134]
The goodwill of $3.5
million generated from this acquisition is primarily related to
expected synergies and was assigned to our Enterprise Networks
division. The goodwill will not be deductible for U.S. federal
income tax purposes.

[0001193125-12-451437:notes:135]
For the three and nine
months ended September 30, 2012, we incurred integration
related expenses and amortization of acquired intangibles of $0.3
million and $1.2 million, respectively, related to this
acquisition.
