# ADTN MD&A — 0000950170-22-023803


## mdna

[0000950170-22-023803:mdna:1]
[same as prior period, unchanged from 0000950170-22-015058:mdna:1]

[0000950170-22-023803:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and the related notes that appear in Part I, Item 1 of this document. In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2021, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1, Business, and Item 1A, Risk Factors, included in 2021 Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022.

[0000950170-22-023803:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our Condensed Consolidated Financial Statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our Condensed Consolidated Financial Statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 3 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part 1, Item 1A, Risk Factors, of the 2021 Form 10‑K and Part II, Item 1A, Risk Factors of this Form 10-Q.

[0000950170-22-023803:mdna:4]
Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to "ADTRAN", the “Company,” “we,” “us” and “our” refer to ADTRAN Holdings, Inc. and its consolidated subsidiaries for periods subsequent to the Merger and to ADTRAN, Inc. and its consolidated subsidiaries for periods prior to the Merger. The prior period results do not include the results of ADVA prior to the Merger.

[0000950170-22-023803:mdna:5]
[same as prior period, unchanged from 0000950170-22-015058:mdna:5]

[0000950170-22-023803:mdna:6]
The Company is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, alternative service providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have sales and research and development facilities in strategic global locations.

[0000950170-22-023803:mdna:7]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of ADVA Optical Networking SE ("ADVA"). ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. ADVA is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge. Additional information on each of the companies is provided below:

[0000950170-22-023803:mdna:8]
•
ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video, and internet communications across any network infrastructure. Its award-winning end-to-end fiber broadband solutions portfolio spans from OLTs to in-home services and intelligent SaaS solutions. These solutions empower communications service providers to manage and scale services to meet the needs of their customers. ADTRAN, Inc. serves customers in over 60 countries.

[0000950170-22-023803:mdna:9]
•
ADVA is a global provider of open networking solutions with over 25 years of experience in optical networking, carrier Ethernet access and network synchronization. ADVA has led the industry for over two decades with open and secure networking solutions that carefully balance space, power and cost. Founded in 1994 in Germany, ADVA has continually pushed the boundaries of innovation, working side-by-side with leading enterprises and service providers to develop technology that meets real-world demands. From open optical line systems, open terminals and pluggable multiplexers to programmable cloud access, encryption and precise timing, ADVA is committed to developing solutions that help its customers succeed.

[0000950170-22-023803:mdna:10]
[same as prior period, unchanged from 0000950170-22-015058:mdna:10]

[0000950170-22-023803:mdna:11]
On August 30, 2021, ADTRAN, Inc. and ADVA, entered into a Business Combination Agreement, pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, ADTRAN Holdings, Inc. (formerly known as Acorn HoldCo, Inc.) which was formed as a wholly-owned subsidiary of ADTRAN in order to consummate the

[0000950170-22-023803:mdna:12]
transactions under the Business Combination Agreement. Under the terms of the Business Combination Agreement on July 8, 2022, Acorn MergeCo, Inc., a Delaware corporation and wholly-owned direct subsidiary of the Company, merged with and into ADTRAN, with ADTRAN surviving the merger as a wholly-owned direct subsidiary of the Company.

[0000950170-22-023803:mdna:13]
Additionally, pursuant to the Business Combination Agreement, the Company made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of common stock, par value $0.01 per share, of the Company ("Company Common Stock"). The Exchange Offer was settled on July 15, 2022, on which date the Company acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of Company Common Stock. Additionally, pursuant to the Business Combination Agreement, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings, Inc. The fair value of the ADVA stock options assumed by ADTRAN Holdings, Inc. was $12.8 million, estimated using the binomial lattice model.

[0000950170-22-023803:mdna:14]
ADTRAN, Inc. and ADVA became subsidiaries of ADTRAN Holdings, Inc. as a result of the Business Combination. ADTRAN was determined to be the accounting acquirer of ADVA based on ADTRAN shareholders’ majority equity stake in the combined company, and the composition of the Board of Directors and senior management of the combined company, among other factors. The Company accounted for the acquisition of ADVA as a business combination under ASC 805.

[0000950170-22-023803:mdna:15]
On October 18, 2022, the Board of Directors of ADTRAN Holdings, Inc. and the management board of ADVA, agreed on a final draft of a domination and profit and loss transfer agreement (the “DPLTA”) between the Company, as the controlling company, and ADVA, as the controlled company. The parties’ execution of the DPLTA remains subject to the approval of the DPLTA by shareholders of ADVA with 75% of the votes cast in an extraordinary general meeting, which is scheduled to be held on November 30, 2022. The Company currently holds 33,957,538 shares of ADVA, representing 65.35% of ADVA’s outstanding shares as of September 30, 2022.

[0000950170-22-023803:mdna:16]
Subject to the approval of the DPLTA by ADVA shareholders and the subsequent registration of the DPLTA with the commercial register of the local court at ADVA’s registered offices, ADTRAN Holdings, Inc. will offer, at the election of each shareholder of ADVA (other than the Company), (i) to acquire the shares of such shareholder for a compensation (Abfindung) of EUR 17.21 per share pursuant to Sec. 305 of the German Stock Corporation Akt (Aktiengesetz, “AktG”), or (ii) to pay such shareholder an annual recurring compensation payment (Ausgleichszahlung) pursuant to Sec. 304 of the AktG in an amount of EUR 0.59 (EUR 0.52 net under the current taxation regime), subject to adjustment prior to execution of the DPLTA due to changes in interest rates and borrowing costs prior to November 30, 2022, which is the reference date for the valuation of ADVA shares (“Annual Recurring Compensation”).

[0000950170-22-023803:mdna:17]
The amount of the Annual Recurring Compensation payment of EUR 0.59 (EUR 0.52 net) is determined on the basis of a rounded annuity interest rate (Verrentungszinssatz) of 3.00% and is still subject to an adjustment in case of a change of interest rates and borrowing costs prior to November 30, 2022 which is the reference date for the valuation. An increase of borrowing costs could lead to an increase of the Annual Recurring Compensation payment. The potential increase ranges from EUR 0.62 (EUR 0.54 net), if the annuity interest rate is increased by 25 basis points to 3.25%, up to an Annual Recurring Compensation payment of EUR 1.00 (EUR 0.87 net), if the annuity interest rate in increased by 250 basis points to 5.50%.

[0000950170-22-023803:mdna:18]
During the three months ended September 30, 2022, we recognized $10.6 million of transaction costs. We expect to incur an estimated $1.1 million of additional transaction costs related to the Business Combination and we will continue to incur integration costs and costs associated with the implementation, if any, of a DPLTA, during the remainder of the year and such costs are expected to be material.

[0000950170-22-023803:mdna:19]
[same as prior period, unchanged from 0000950170-22-015058:mdna:15]

[0000950170-22-023803:mdna:20]
The Company ended the third quarter of 2022 with a year-over-year revenue increase of 146.7% as compared to the three months ended September 30, 2021, driven by increased volume of sales activity due to the Business Combination with ADVA and to service provider customers. During the third quarter of 2022, the Company had two 10% revenue customers, one U.S. service provider customer, and one international service provider customer. Our year-over-year domestic revenue increased by 84.7%, driven by increased sales volume due to the Business Combination with ADVA and an increased sales volume of residential gateways and optical network terminals in our Network Solutions segment. Internationally, our revenue increased by 270.1% compared to the prior year period, primarily driven by increased volume of sales activity due to the Business Combination with ADVA and increased shipments to a Tier-1 network operator in Europe. We experienced strong demand for our solutions in the first nine months of 2022 and achieved significant year-over-year bookings growth. Bookings are defined as orders received for a product or service during a fiscal period that will be delivered or performed sometime in the future and is a forward looking metric that we utilize to help us understand future revenue growth for the Company. Bookings are generally subject to modification and or cancellation per the terms of the order. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing nonbinding purchase commitments. Our increase in demand comes from service providers planning to deploy our fiber access platforms, in-home service delivery platforms and SaaS applications. We expect this growth to accelerate. During 2021 and continuing in 2022, we secured several Tier-1 next-generation fiber customers, and previously announced Tier-1 fiber customers significantly increased their bookings for our fiber access platforms. Although we expect our revenue growth and profitability in the near-term to continue to

[0000950170-22-023803:mdna:21]
be negatively impacted by supply chain issues, our outlook continues to strengthen given the increased demand for our products and our expectation of an improving supply chain over the longer term.

[0000950170-22-023803:mdna:22]
In March 2020, the World Health Organization declared the novel coronavirus ("COVID-19") outbreak a global pandemic. The SARS-CoV-2 coronavirus (or variants of the SARS-CoV-2 coronavirus) continues to spread throughout the U.S. and the world and has resulted in authorities implementing varying measures to contain the virus. Although vaccines have been approved and continue to be distributed, it cannot be predicted how long it will take before market conditions return to normal and there can be no assurance that the economic recovery will occur or offset the uncertainty and instability triggered by the pandemic. New and potentially more contagious variants of the COVID-19 virus may develop in various countries, including in regions in which we have significant operations. The COVID-19 variants could further amplify the impact of the pandemic. While we are unable to accurately predict the full impact that the COVID-19 global pandemic will have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time. We have experienced a significant impact to our supply chain given COVID-19 and the related global semiconductor chip shortage, including delays in supply chain deliveries, extended lead times and shortages of some key components, some raw material cost increases and slowdowns at certain production facilities. We have also had to increase our volume of inventory to ensure supply continuity during the pandemic. In addition, we have experienced significant increases in freight-related costs due to global shipping disruptions. Starting in the third quarter of 2021 and continuing into 2022, the Company has incurred supply chain constraint expenses, including price inflation for certain electronic components, semiconductor chips and transportation related costs, which have lowered our gross margins and decreased our profitability. While throughout the pandemic we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments, as well as COVID-19 related reductions in travel and infrastructure expenses, it is possible that we could experience some slowdown in demand, further supply chain issues and an increased impact from the ongoing semiconductor shortage and shortages of certain other key components as the pandemic continues. If the impacts of this shortage are more severe than we expect, it could result in longer lead times, inventory supply challenges and further increased costs, all of which could result in the deterioration of our results, potentially for a longer period than currently anticipated. To support the health and well-being of our employees, customers, partners and communities, many of our employees are working remotely or on a hybrid schedule as of the date of filing this report. Additionally, there is risk that a number of our employees may become infected with COVID-19, including our key personnel. In addition, actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for certain employees, as well as the impacts to our supply chain, including delays in supply chain deliveries and the related global semiconductor chip shortage, have delayed and may continue to delay the timing of some orders and expected deliveries. Lastly, even after the COVID-19 pandemic has subsided, we may continue to experience adverse impacts to our business as a result of any economic recession that has occurred or may occur in the future as a result of the COVID-19 pandemic or other factors.

[0000950170-22-023803:mdna:23]
In addition to the Company's reportable segments, revenue is also reported for the following three categories – Subscriber Solutions, Access & Aggregation Solutions, and Optical Networking Solutions.

[0000950170-22-023803:mdna:24]
Prior to the Business Combination with ADVA on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with ADVA, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable ADVA solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable ADVA solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of ADVA’s portfolio.

[0000950170-22-023803:mdna:25]
Our Subscriber Solutions portfolio is used by service providers to terminate their access services infrastructure at the customer premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

[0000950170-22-023803:mdna:26]
Our Access & Aggregation Solutions are solutions that are used by communications service providers to connect residential subscribers, business subscribers and mobile radio networks to the service providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions, and access orchestration solutions that ensure highly reliable and efficient network performance.

[0000950170-22-023803:mdna:27]
Our Optical Networking Solutions are used by communications service providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules,

[0000950170-22-023803:mdna:28]
network infrastructure assurance systems, and automation platforms that are used to build high-scale, secure and assured optical networks.

[0000950170-22-023803:mdna:29]
Our operating results have fluctuated, and may continue to fluctuate, on a quarterly basis due to several factors, including customer order activity, supply chain constraints, component availability, backlog, the Company's consolidation, purchase accounting, and integration with ADVA. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days requiring us to maintain higher inventory levels. These factors normally result in a varying order backlog and limited order flow visibility; however, with the current global supply chain and transportation constraints, and limited availability of semiconductor chips and other components of our products, we have experienced and may continue to experience extended lead times, increased logistics intervals and costs, and lower volume of products deliveries, which has had and may continue to have a material adverse effect on our operating results and could have a material adverse effect on customer relations and our financial condition. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0000950170-22-023803:mdna:30]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that initially resulted from the COVID-19 pandemic and that may recur and foreign currency exchange rate movements, inflation, regional conflicts, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Specifically, we expect inflationary pressures on input costs, such as raw materials and labor, and distribution costs to increase. We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors, and customers to address and to limit the disruption to our operations and order fulfillment. Our attempts to offset these cost pressures, such as through increases in the selling prices of some of our products and services, may not be successful and could negatively affect our operating results. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results.

[0000950170-22-023803:mdna:31]
We are exposed to changes in foreign currencies relative to the U.S. dollar, which are references to the differences between the foreign-exchanges rates we use to convert the financial results of our international operations from local currencies and non-U.S. dollar denominated functional currencies into U.S. dollars for financial reporting purposes. This impact of foreign-exchange rate changes is calculated based on the difference between the current period’s currency exchange rates and that of the comparable prior period. Our primary exposures to foreign currency exchange rate movements are with our European subsidiaries, whose functional currency is the Euro, our Australian subsidiary, whose functional currency is the Australian dollar, and our U.K. subsidiary, who transacts in the British pound sterling with a U.S. dollar functional currency. As a result of our global operations, our revenue, gross margins, operating expense and operating income in some international markets have been and may continue to be affected by foreign currency fluctuations.

[0000950170-22-023803:mdna:32]
[same as prior period, unchanged from 0000950170-22-015058:mdna:30]

[0000950170-22-023803:mdna:33]
[same as prior period, unchanged from 0000950170-22-015058:mdna:31]

[0000950170-22-023803:mdna:34]
[same as prior period, unchanged from 0000950170-22-015058:mdna:32]

[0000950170-22-023803:mdna:35]
[same as prior period, unchanged from 0000950170-22-015058:mdna:33]

[0000950170-22-023803:mdna:36]
[same as prior period, unchanged from 0000950170-22-015058:mdna:34]

[0000950170-22-023803:mdna:37]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2022 COMPARED TO THE THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2021

[0000950170-22-023803:mdna:38]
The following table presents selected financial information derived from our Condensed Consolidated Statements of Loss expressed as a percentage of revenue for the periods indicated. Amounts may not foot due to rounding.

[0000950170-22-023803:mdna:39]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 89.5 |  | % |  | 87.5 |  | % |  | 89.8 |  | % |  | 88.1 |  | % |
| Services & Support |  |  | 10.5 |  |  |  | 12.5 |  |  |  | 10.2 |  |  |  | 11.9 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 65.3 |  |  |  | 58.7 |  |  |  | 61.9 |  |  |  | 52.8 |  |  |
| Services & Support |  |  | 4.4 |  |  |  | 6.8 |  |  |  | 5.1 |  |  |  | 7.1 |  |  |
| Total Cost of Revenue |  |  | 69.8 |  |  |  | 65.5 |  |  |  | 67.1 |  |  |  | 59.9 |  |  |
| Gross Profit |  |  | 30.2 |  |  |  | 34.5 |  |  |  | 32.9 |  |  |  | 40.1 |  |  |
| Selling, general and administrative expenses |  |  | 22.0 |  |  |  | 22.4 |  |  |  | 19.6 |  |  |  | 21.8 |  |  |
| Research and development expenses |  |  | 17.4 |  |  |  | 19.4 |  |  |  | 16.8 |  |  |  | 20.1 |  |  |
| Asset impairment |  |  | 5.0 |  |  |  | — |  |  |  | 2.5 |  |  |  | — |  |  |
| Operating Loss |  |  | (14.1 | ) |  |  | (7.3 | ) |  |  | (6.0 | ) |  |  | (1.8 | ) |  |
| Interest and dividend income |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |
| Interest expense |  |  | (0.4 | ) |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |  |
| Net investment (loss) gain |  |  | (0.8 | ) |  |  | — |  |  |  | (1.6 | ) |  |  | 0.7 |  |  |
| Other income, net |  |  | 0.7 |  |  |  | 0.5 |  |  |  | 0.4 |  |  |  | 0.7 |  |  |
| Loss Before Income Taxes |  |  | (14.4 | ) |  |  | (6.6 | ) |  |  | (7.3 | ) |  |  | (0.2 | ) |  |
| Income tax benefit (expense) |  |  | 1.3 |  |  |  | (0.9 | ) |  |  | 0.7 |  |  |  | (0.8 | ) |  |
| Net Loss |  |  | (13.2 | ) | % |  | (7.6 | ) | % |  | (6.6 | ) | % |  | (1.1 | ) | % |

[0000950170-22-023803:mdna:40]
[same as prior period, unchanged from 0000950170-22-015058:mdna:39]

[0000950170-22-023803:mdna:41]
Our revenue increased 146.7% from $138.1 million for the three months ended September 30, 2021 to $340.7 million for the three months ended September 30, 2022 and increased 63.2% from $408.8 million for the nine months ended September 30, 2021 to $667.3 million for the nine months ended September 30, 2022. The increase in revenue for the three and nine months ended September 30, 2022 is primarily attributable to a $163.8 million increase in volume of sales activity due to the Business Combination with ADVA and a $38.8 million and $94.6 million increase in volume of sales activity related to our ADTRAN, Inc. operations, respectively. The increase in revenue by category for the three months ended September 30, 2022 was primarily attributable to a $118.8 million increase in Optical Networking Solutions products due to the Business Combination with ADVA, a $86.8 million increase in Subscriber Solutions products, partially offset by a $3.0 million decrease in Access & Aggregation Solutions revenue. The increase in revenue by category for the nine months ended September 30, 2022 was attributable to a $118.8 million increase in Optical Networking Solutions products due to the Business Combination with ADVA, a $117.7 million increase in Subscriber Solutions products, and a $21.9 million increase in Access & Aggregation Solutions revenue. Although our revenue increased, supply of semiconductor chips and other components of our products has become constrained resulting in extended lead times and increased costs. Transportation constraints, including shortages for both air and surface freight, as well as labor shortages in the transportation industry, have also affected the timing and the cost of obtaining raw materials and production supplies. Although our revenue growth and profitability in the near-term may be impacted by these global supply chain issues, our longer term outlook continues to strengthen given our progress with new customer opportunities and the increased customer demand.

[0000950170-22-023803:mdna:42]
Network Solutions segment revenue increased 152.5% from $120.8 million for the three months ended September 30, 2021 to $304.9 million for the three months ended September 30, 2022 and increased 66.5% from $360.0 million for the nine months ended September 30, 2021 to $599.3 million for the nine months ended September 30, 2022. The increase in revenue for the three months ended September 30, 2022 was due primarily to the increase of $143.4 million in volume of sales activity due to the Business Combination with ADVA and an increase of $55.1 million in Subscriber Solutions products in our ADTRAN, Inc. operations. The increase in revenue for the nine months ended September 30, 2022 was due to the Business Combination with ADVA and increases in all revenue categories in our ADTRAN, Inc. operations.

[0000950170-22-023803:mdna:43]
Services & Support segment revenue increased 106.6% from $17.3 million for the three months ended September 30, 2021 to $35.8 million for the three months ended September 30, 2022 and increased 39.2% from $48.8 million for the nine months ended September 30, 2021 to $68.0 million for the nine months ended September 30, 2022. The increase in revenue for the three and nine

[0000950170-22-023803:mdna:44]
45

[0000950170-22-023803:mdna:45]
months ended September 30, 2022 was primarily attributable to the increase of $20.4 million in volume of sales activity from the Business Combination with ADVA partially offset by a $2.6 million decrease in revenue for Access & Aggregation Solutions products in our ADTRAN, Inc. operations.

[0000950170-22-023803:mdna:46]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., increased by 270.1% from $46.2 million for the three months ended September 30, 2021 to $171.0 million for the three months ended September 30, 2022 and increased by 115.5% from $135.8 million for the nine months ended September 30, 2021 to $292.8 million for the nine months ended September 30, 2022. International revenue, as a percentage of total revenue, increased from 33.5% for the three months ended September 30, 2021 to 50.2% for the three months ended September 30, 2022 and increased from 33.2% for the nine months ended September 30, 2021 to 43.9% for the nine months ended September 30, 2022 was primarily attributable to the increase in volume of $113.2 million in sales activity from the Business Combination with ADVA and increased shipments to a Tier-1 network operator and multiple alternative network operators in Europe. While international revenue has increased to approximately 50% of total revenues for the three months ended September 30, 2022, the mix of our Network Solutions and Services & Support segments as a percentage of total international revenue remains relatively linear. For the three and nine months ended September 30, 2022 as compared to the three and nine months ended September 30, 2021, changes in foreign currencies relative to the U.S dollar decreased our net sales by approximately $15.5 million and $34.4 million, respectively.

[0000950170-22-023803:mdna:47]
Our ADTRAN, Inc. international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income. Our ADVA international revenue is largely focused on the manufacture and selling of networking solutions that are based on three core areas of expertise: fiber-optic transmission technology (cloud interconnect), cloud access technology for rapid creation of innovative services around the network edge and solutions for precise timing and synchronization of networks. In addition, ADVA's international operations offers a comprehensive portfolio of network design, implementation and maintenance services to assist operators in the deployment of market-leading networks while reducing their cost to maintain these networks.

[0000950170-22-023803:mdna:48]
[same as prior period, unchanged from 0000950170-22-015058:mdna:45]

[0000950170-22-023803:mdna:49]
As a percentage of revenue, cost of revenue increased from 65.5% for the three months ended September 30, 2021 to 69.8% for the three months ended September 30, 2022 and increased from 59.9% for the nine months ended September 30, 2021 to 67.1% for the nine months ended September 30, 2022. For the three and nine months ended September 30, 2022, the increase was primarily attributable to $25.5 million in acquisition related expenses, amortizations, and adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with ADVA as well as supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations. For the three and nine months ended September 30, 2022, as compared to the three and nine months ended September 30, 2021, changes in foreign currencies relative to the U.S. dollar decreased our cost of revenue by approximately $2.9 million and $6.7 million, respectively. See additional information related to amortization lives and expense in Notes 2 and 11 of Notes to the Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-22-023803:mdna:50]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 67.1% for the three months ended September 30, 2021 to 73.0% for the three months ended September 30, 2022 and increased from 60.0% for the nine months ended September 30, 2021 to 68.9% for the nine months ended September 30, 2022. The increase in cost of revenue as a percentage of revenue for the three and nine months ended September 30, 2022 was primarily attributable to acquisition related expenses, amortizations and adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with ADVA as well as supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations.

[0000950170-22-023803:mdna:51]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 54.2% for the three months ended September 30, 2021 to 42.1% for the three months ended September 30, 2022 and decreased from 59.1% for the nine months ended September 30, 2021 to 50.4% for the nine months ended September 30, 2022. The decrease in cost of revenue as a percentage of revenue for the three and nine months ended September 30, 2022 was primarily attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with ADVA.

[0000950170-22-023803:mdna:52]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower

[0000950170-22-023803:mdna:53]
average gross margins as compared to maintenance and support services. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0000950170-22-023803:mdna:54]
[same as prior period, unchanged from 0000950170-22-015058:mdna:50]

[0000950170-22-023803:mdna:55]
As a percentage of revenue, selling, general and administrative expenses decreased from 22.4% for the three months ended September 30, 2021 to 22.0% for the three months ended September 30, 2022 and decreased from 21.8% for the nine months ended September 30, 2021 to 19.6% for the nine months ended September 30, 2022. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0000950170-22-023803:mdna:56]
Selling, general and administrative expenses increased 141.8% from $31.0 million for the three months ended September 30, 2021 to $74.9 million for the three months ended September 30, 2022 and increased 46.3% from $89.3 million for the nine months ended September 30, 2021 to $130.6 million for the nine months ended September 30, 2022. The increase in selling, general and administrative expenses for the three and nine months ended September 30, 2022 was primarily attributable to increased expenses related to the Business Combination with ADVA such as employee-related costs due to an increase in the number of employees, amortization of intangible assets, depreciation of property, plant and equipment and transactions costs. For the three and nine months ended September 30, 2022 as compared to the three and nine months ended September 30, 2021, changes in foreign currencies relative to the U.S dollar decreased our selling, general and administrative expenses by approximately $1.8 million and $4.6 million, respectively.

[0000950170-22-023803:mdna:57]
[same as prior period, unchanged from 0000950170-22-015058:mdna:53]

[0000950170-22-023803:mdna:58]
As a percentage of revenue, research and development expenses decreased from 19.4% for the three months ended September 30, 2021 to 17.4% for the three months ended September 30, 2022 and decreased from 20.1% for the nine months ended September 30, 2021 to 16.8% for the nine months ended September 30, 2022. Research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0000950170-22-023803:mdna:59]
Research and development expenses increased 121.2% from $26.8 million for the three months ended September 30, 2021 to $59.2 million for the three months ended September 30, 2022 and increased 36.6% from $82.1 million for the nine months ended September 30, 2021 to $112.2 million for the nine months ended September 30, 2022. The increase in research and development expenses for the three and nine months ended September 30, 2022 was primarily attributable to increased expenses related to the Business Combination with ADVA such as employee-related costs due to an increase in the number of employees, amortization of intangible assets and depreciation of property, plant and equipment. For the three and nine months ended September 30, 2022 as compared to the three and nine months ended September 30, 2021, changes in foreign currencies relative to the U.S. dollar decreased our research and development expenses by approximately $1.9 million and $4.8 million, respectively.

[0000950170-22-023803:mdna:60]
ADVA has arrangements with governmental entities for the purposes of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the three and nine months ended September 30, 2022, the Company recognized $0.3 million as a reduction of research and development expense.

[0000950170-22-023803:mdna:61]
[same as prior period, unchanged from 0000950170-22-015058:mdna:56]

[0000950170-22-023803:mdna:62]
ASSET IMPAIRMENT

[0000950170-22-023803:mdna:63]
In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result the Company recognized impairment charges of $17.0 million during the three and nine months ended September 30, 2022 related to capitalized implementation costs for a cloud computing arrangement. There were no asset impairments recognized during the three and nine months ended September 30, 2021. See Note 9 of Notes to the Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0000950170-22-023803:mdna:64]
[same as prior period, unchanged from 0000950170-22-015058:mdna:57]

[0000950170-22-023803:mdna:65]
Interest and dividend income was $0.3 million for the three months ended September 30, 2022 and 2021 and decreased 13.4% from $0.9 million for the nine months ended September 30, 2021 to $0.8 million for the nine months ended September 30, 2022. Interest and dividend income was down due to a decrease in the investment balance for the nine months ended September 30, 2022. Our total long-term investments decreased from $83.9 million as of September 30, 2021 to $50.1 million as of September 30, 2022.

[0000950170-22-023803:mdna:66]
[same as prior period, unchanged from 0000950170-22-015058:mdna:59]

[0000950170-22-023803:mdna:67]
Interest expense increased from less than $0.1 million for the three months ended September 30, 2021 to $1.3 million for the three months ended September 30, 2022. Interest expense increased from less than $0.1 million for the nine months ended September 30, 2021 to $1.4 million for the nine months ended September 30, 2022. The increase in interest expense during the three and nine months ended September 30, 2022 was primarily related to an increase in assumed debt associated with the Business Combination with ADVA and the new Wells Fargo Credit Agreement. See Note 13 and Note 14 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-22-023803:mdna:68]
[same as prior period, unchanged from 0000950170-22-015058:mdna:61]

[0000950170-22-023803:mdna:69]
We recognized a net investment loss of $0.1 million and $2.7 million for the three months ended September 30, 2021 and 2022, respectively and recognized a net investment gain of $2.9 million and a net investment loss of $10.8 million for the nine months ended September 30, 2021 and 2022, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See Note 7 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-22-023803:mdna:70]
[same as prior period, unchanged from 0000950170-22-015058:mdna:63]

[0000950170-22-023803:mdna:71]
Other income, net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, increased from income of $0.6 million for the three months ended September 30, 2021 to income of $2.5 million for the three months ended September 30, 2022 and increased from income of $2.7 million for the nine months ended September 30, 2021 to income of $2.9 million for the nine months ended September 30, 2022.

[0000950170-22-023803:mdna:72]
[same as prior period, unchanged from 0000950170-22-015058:mdna:65]

[0000950170-22-023803:mdna:73]
Our effective tax rate changed from an expense of 14.1% of pre-tax income for the three months ended September 30, 2021, to a benefit of 8.8% of pre-tax income for the three months ended September 30, 2022 and changed from an expense of 354.5% of pre-tax income for the nine months ended September 30, 2021, to a benefit of 9.4% of pre-tax income for the nine months ended September 30, 2022. The change in the effective tax rate for the three and nine months ended September 30, 2022, was driven primarily by a change in our estimated tax rate as a result of the closing of the Business Combination with ADVA during the third quarter of 2022, the requirement to begin capitalizing Research and Development expenses for U.S. tax purposes beginning in 2022 as previously passed as part of the Tax Cuts and Jobs Act in December 2017 and the associated impact of those changes on our previously established valuation allowance.

[0000950170-22-023803:mdna:74]
NET LOSS ATTRIBUTABLE TO ADTRAN HOLDINGS, INC.

[0000950170-22-023803:mdna:75]
As a result of the above factors, net loss attributable to ADTRAN Holdings, Inc. increased from $10.4 million for the three months ended September 30, 2021 to $41.9 million for the three months ended September 30, 2022 and increased from $4.4 million for the nine months ended September 30, 2021 to $40.9 million for the nine months ended September 30, 2022.

[0000950170-22-023803:mdna:76]
[same as prior period, unchanged from 0000950170-22-015058:mdna:69]

[0000950170-22-023803:mdna:77]
[same as prior period, unchanged from 0000950170-22-015058:mdna:70]

[0000950170-22-023803:mdna:78]
We have historically financed, our ongoing business with existing cash, investments and cash flow from operations. In the current supply environment we also expect to utilize our credit arrangements to manage our working capital needs. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital, business acquisitions, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures. As of September 30, 2022, the Company has incurred $25.2 million of transaction costs related to the Business Combination and expects to incur an estimated $1.1 million of additional transaction costs. We believe that our cash and cash equivalents, investments, cash generated from operations and access to funds under the new Wells Fargo credit facility (described below) will be adequate to meet our operating and capital needs for at least the next 12 months.

[0000950170-22-023803:mdna:79]
As of September 30, 2022, cash on hand was $111.1 million and short-term investments were $0.8 million, which resulted in available short-term liquidity of $111.9 million, of which $77.0 million was held by our foreign subsidiaries. As of December 31, 2021, cash on hand was $56.6 million and short-term investments were $0.4 million, which resulted in available short-term liquidity of $57.0 million, of which $47.7 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax.

[0000950170-22-023803:mdna:80]
[same as prior period, unchanged from 0000950170-22-015058:mdna:73]

[0000950170-22-023803:mdna:81]
Net cash used in operating activities of $42.7 million during the nine months ended September 30, 2022 decreased by $71.6 million compared to net cash provided of $28.9 million during the nine months ended September 30, 2021. This decrease was primarily due to net cash outflows from working capital, specifically, an inventory build related to component availability, an increase in accounts receivables and transaction costs related to the Business Combination partially offset by an increase in the average number of days payable to our trade suppliers. Additional details related to our working capital and its drivers are discussed below.

[0000950170-22-023803:mdna:82]
Net accounts receivable increased 90.5% from $158.7 million as of December 31, 2021 to $302.4 million as of September 30, 2022. There was an allowance for credit losses of $0.2 million as of September 30, 2022 and no allowance for credit losses as of December 31, 2021. The increase in net accounts receivable was due primarily to the increase in sales volume related to the Business Combination with ADVA and an increase in sales volume in our ADTRAN, Inc. operations. Quarterly accounts receivable DSO decreased from 95 days as of December 31, 2021 to 82 days as of September 30, 2022. The decrease in DSO was due to customer and geographical mix associated with the Business Combination with ADVA and timing of sales within the quarter.

[0000950170-22-023803:mdna:83]
Other receivables increased 27.8% from $11.2 million as of December 31, 2021 to $14.4 million as of September 30, 2022. The increase in other receivables was primarily attributable to an increase in prepaid taxes associated with Business Combination with ADVA and contract assets partially offset by a decrease in our receivables for sales of raw materials and reclaimed duty drawbacks.

[0000950170-22-023803:mdna:84]
Quarterly inventory turnover was 3.0 turns as of December 31, 2021 and 3.1 turns as of September 30, 2022, respectively. Inventory increased 197.5% from $139.9 million as of December 31, 2021 to $416.2 million as of September 30, 2022. The increase in inventory was due to Business Combination with ADVA and strategic inventory buffer purchases given extended component lead times and availability constraints as well as new product ramp ups to ensure supply continuity. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to supply chain uncertainties.

[0000950170-22-023803:mdna:85]
Accounts payable increased 169.3% from $102.5 million as of December 31, 2021 to $276.0 million as of September 30, 2022. The increase in accounts payable was primarily due to the increase in volume of operating costs associated with the Business Combination with ADVA, additional purchases of raw material inventory and extended payment terms. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-22-023803:mdna:86]
[same as prior period, unchanged from 0000950170-22-015058:mdna:79]

[0000950170-22-023803:mdna:87]
Capital expenditures totaled approximately $10.1 million and $3.6 million for the nine months ended September 30, 2022 and 2021, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements.

[0000950170-22-023803:mdna:88]
Our combined short-term and long-term investments decreased $20.1 million from $71.0 million as of December 31, 2021 to $50.9 million as of September 30, 2022. This decrease reflects the impact of the sale of portions of our equity and fixed income investments and the net unrealized and realized gains and losses on our investments.

[0000950170-22-023803:mdna:89]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 7 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0000950170-22-023803:mdna:90]
As of September 30, 2022, our corporate bonds, municipal bonds, asset-backed bonds, mortgage/agency bonds, U.S. government bonds and other government bonds were classified as available-for-sale and had a combined duration of 1.71 years with an average Standard & Poor’s credit rating of AA-. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0000950170-22-023803:mdna:91]
Our long-term investments decreased 29.0% from $70.6 million as of December 31, 2021 to $50.1 million as of September 30, 2022. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $0.8 million and $12.6 million as of September 30, 2022 and December 31, 2021, respectively. Long-term investments as of September 30, 2022 and December 31, 2021 also included $21.5 million and $26.9 million, respectively, related to our deferred compensation plans.

[0000950170-22-023803:mdna:92]
[same as prior period, unchanged from 0000950170-22-015058:mdna:85]

[0000950170-22-023803:mdna:93]
[same as prior period, unchanged from 0000950170-22-015058:mdna:86]

[0000950170-22-023803:mdna:94]
During the nine month periods ended September 30, 2022 and 2021, we paid dividends totaling $15.9 million and $13.1 million, respectively. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0000950170-22-023803:mdna:95]
[same as prior period, unchanged from 0000950170-22-015058:mdna:88]

[0000950170-22-023803:mdna:96]
To accommodate employee stock option exercises, the Company issued 0.4 million and 0.1 million shares of common stock and treasury stock which resulted in proceeds of $4.8 million and $2.6 million during the three months ended September 30, 2022 and 2021, respectively and issued 0.4 and 0.4 million shares of common stock and treasury stock which resulted in proceeds of $5.4 million and $6.1 million during the nine months ended September 30, 2022 and 2021, respectively.

[0000950170-22-023803:mdna:97]
[same as prior period, unchanged from 0000950170-22-015058:mdna:90]

[0000950170-22-023803:mdna:98]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0000950170-22-023803:mdna:99]
[same as prior period, unchanged from 0000950170-22-015058:mdna:92]

[0000950170-22-023803:mdna:100]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of September 30, 2022, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied.

[0000950170-22-023803:mdna:101]
| (In thousands) |  | Total |  |  | 2022 |  |  | 2023 |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | After 2026 |  |
| Wells Fargo credit agreement(1) |  | $ | 60,000 |  |  | $ | — |  |  | $ | 60,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Nord/LB revolving line of credit(2) |  |  | 14,702 |  |  |  | — |  |  |  | 14,702 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Syndicated credit agreement working capital line of credit(3) |  |  | 9,801 |  |  |  | — |  |  |  | 9,801 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Syndicated credit agreement note payable(4) |  |  | 29,782 |  |  |  | 7,351 |  |  |  | 22,431 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations(5) |  |  | 454,143 |  |  |  | 218,792 |  |  |  | 226,130 |  |  |  | 8,852 |  |  |  | 192 |  |  |  | 166 |  |  |  | 11 |  |
| Operating lease obligations(6) |  |  | 32,027 |  |  |  | 2,209 |  |  |  | 8,421 |  |  |  | 7,098 |  |  |  | 5,838 |  |  |  | 3,354 |  |  |  | 5,107 |  |
| Business combination transaction costs(7) |  |  | 1,144 |  |  |  | 1,144 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Totals |  | $ | 601,599 |  |  | $ | 229,496 |  |  | $ | 341,485 |  |  | $ | 15,950 |  |  | $ | 6,030 |  |  | $ | 3,520 |  |  | $ | 5,118 |  |

[0000950170-22-023803:mdna:102]
(5) We have purchase obligations related to open purchase orders to our contract manufacturers, ODMs, component suppliers, service partners and other vendors. The settlement of our purchase obligations will occur at various dates beginning in 2022 and going through 2027. See Note 20 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for more information.

[0000950170-22-023803:mdna:103]
(6) We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Our operating leases had remaining lease terms ranging from one month to 75 months as of September 30, 2022.

[0000950170-22-023803:mdna:104]
(7) Pursuant to the Business Combination Agreement, the Company is bearing the transaction costs of the Business Combination attributable to the Company. For additional information on the Business Combination, see Note 2 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-22-023803:mdna:105]
[same as prior period, unchanged from 0000950170-22-015058:mdna:93]

[0000950170-22-023803:mdna:106]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allows for borrowings of up to $100 million in aggregate principal amount, subject to being increased to up to $400 million in aggregate principal amount upon the Company or Borrower’s execution of a DPLTA with ADVA or a parent of ADVA, among other conditions (the “Senior Credit Facilities Increase”). On October 18, 2022, the Board of Directors of the Company. and the management board of ADVA, agreed on a final draft of a DPLTA between the Company, as the controlling company, and ADVA, as the controlled company. See Note 21 of the Notes to Condensed Consolidated Financial Statements for further information.

[0000950170-22-023803:mdna:107]
As of September 30, 2022, ADTRAN, Inc.’s borrowings under the revolving line of credit were $60.0 million in tranches that mature during the fourth quarter of 2022 and can either be repaid or borrowed again for a one month, three month or six month period. In addition, we may issue up to $25 million in letters of credit against our $100 million dollar total facility. As of September 30, 2022, we had a total of $16.0 million in letters of credit with ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $24.0 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-22-023803:mdna:108]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-22-023803:mdna:109]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participations in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-22-023803:mdna:110]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the Consolidated Interest Coverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions.

[0000950170-22-023803:mdna:111]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

[0000950170-22-023803:mdna:112]
Nord/LB Revolving Line of Credit

[0000950170-22-023803:mdna:113]
On August 8, 2022, ADVA entered into a $14.7 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate + 1.4% and which matures in August 2023. During the term of the loan, ADVA is obligated to maintain an adjusted net debt to cover ratio that is equal to or less than 2.75. The revolving line of credit grants Nord/LB a lien on assets of any kind which come into the possession of ADVA. Assets of any kind includes goods, foreign exchange, securities including interest, annuity and profit notes, collective securities deposits, subscription rights, checks, bills of exchange, bills of lading, storage and loading slips. As of September 30, 2022, ADVA’s borrowings under the revolving line of credit were $14.7 million.

[0000950170-22-023803:mdna:114]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-22-023803:mdna:115]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $9.8 million as part of a working capital line of credit. The interest rate for the working capital line of credit is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of September 30, 2022. The working capital line of credit matures in September 2023. As of September 30, 2022, borrowings under the working capital line of credit totaled $9.8 million.

[0000950170-22-023803:mdna:116]
Syndicated Credit Agreement Note Payable

[0000950170-22-023803:mdna:117]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. The interest rate for the note payable is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of September 30, 2022. The note payable matures in September 2023.

[0000950170-22-023803:mdna:118]
Proposed Domination and Profit and Loss Transfer Agreement

[0000950170-22-023803:mdna:119]
On October 18, 2022, the Board of Directors of the Company and the management board of ADVA agreed on a final draft of a DPLTA between the Company, as the controlling company, and ADVA, as the controlled company. The parties’ execution of the DPLTA remains subject to approval of the DPLTA by shareholders of ADVA with 75% of the votes cast in an extraordinary general meeting, which is scheduled to be held on November 30, 2022. If and when signed, effectiveness of the DPLTA is subject to the subsequent registration of the DPLTA with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered offices of ADVA, with such effectiveness to occur no earlier than January 1, 2023.

[0000950170-22-023803:mdna:120]
Pursuant to Sections 302 et seq. of the German Stock Corporation Act, under the proposed DPLTA, we would be obligated to compensate any annual net loss of ADVA. Additionally, pursuant to the terms of the proposed DPLTA, each ADVA shareholder (other than the Company) will be offered to elect either (1) to remain an ADVA shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation. Assuming all of the minority holders of currently outstanding ADVA shares were to elect the second option, the Company would be obligated to make aggregate Exit Compensation payments of approximately EUR 309.8 million (or approximately $303.6 million at the exchange rate in effect on September 30, 2022). Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. Our obligation to pay Annual Recurring Compensation under the proposed DPLTA would lead to a continuing payment obligation, which would amount to approximately $10.4 million per year assuming none of the minority ADVA shareholders were to elect Exit Compensation and no adjustment is made to the Annual Recurring Compensation Payment Amount between now and November 30, 2022. Any such adjustments could materially increase the amount of the Annual Recurring Compensation Payment Amount. The amount of this Annual Recurring Compensation payment obligation pursuant to the proposed DPLTA could exceed the amount of dividends that otherwise might be distributed by ADVA to minority shareholders and would even have to be paid if ADVA incurs losses, which could have a material adverse impact on our financial results and financial condition.

[0000950170-22-023803:mdna:121]
Other Cash Requirements

[0000950170-22-023803:mdna:122]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of September 30, 2022.

[0000950170-22-023803:mdna:123]
During the nine months ended September 30, 2022, there have been no other material changes in cash requirements from those discussed in the 2021 Form 10-K other than the Company's commitments and contingencies that were assumed due to the Business Combination with ADVA that occurred on July 15, 2022.

[0000950170-22-023803:mdna:124]
Performance Bonds

[0000950170-22-023803:mdna:125]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2022 and December 31, 2021, we had commitments related to these bonds totaling $21.1 million and $22.9 million, respectively, which expire at various dates through April 2025. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-22-023803:mdna:126]
Critical Accounting Policies and Estimates

[0000950170-22-023803:mdna:127]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part I, Item 1 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable.

[0000950170-22-023803:mdna:128]
We believe the critical accounting policies affect our more significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements. During the nine months ended September 30, 2022, there were no significant changes to our critical accounting policies and estimates as described in the financial statements contained in the 2021 Form 10-K.

[0000950170-22-023803:mdna:129]
53
