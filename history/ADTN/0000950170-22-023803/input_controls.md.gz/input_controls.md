# ADTN 10-Q controls and the auditor's report


## item_4_controls

[0000950170-22-023803:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000950170-22-023803:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000950170-22-023803:item_4_controls:3]
We maintain disclosure controls and procedures that are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure. Because of the inherent limitations to the effectiveness of any system of disclosure controls and procedures, no evaluation of disclosure controls and procedures can provide absolute assurance that all control issues, if any, with a company have been prevented or detected on a timely basis. Even disclosure controls and procedures determined to be effective can only provide reasonable assurance that their objectives are achieved.

[0000950170-22-023803:item_4_controls:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and our Chief Financial Officer, of the effectiveness of our disclosure controls and procedures, as such term is defined under Rule 13a-15(e) promulgated under the Exchange Act. Based on that evaluation, which excluded the impact of the acquisition of a controlling equity stake in ADVA discussed below, our Chief Executive Officer and our Chief Financial Officer concluded that, as of the end of the period covered by this report, our disclosure controls and procedures were effective at the reasonable assurance level.

[0000950170-22-023803:item_4_controls:5]
Changes in Internal Control over Financial Reporting.

[0000950170-22-023803:item_4_controls:6]
On July 15, 2022, the Company acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of such date, as further described in Note 2 of the Notes to the Condensed Consolidated Financial Statements. At September 30, 2022, ADVA’s assets represented approximately 66.0% of our consolidated assets. For the three and nine months ended September 30, 2022, ADVA’s revenues represented approximately 48.1% and 24.6% of our consolidated revenues, respectively, and loss before income taxes represented approximately 23.3% and 23.7% of our consolidated loss before income taxes, respectively. As permitted by SEC guidance, we currently exclude ADVA in our evaluation of internal controls over financial reporting and related disclosure controls and procedures for the first year after the Business Combination. However, we are in the process of extending our oversight and monitoring processes that support our internal control over financial reporting and disclosure controls and procedures to include ADVA’s operations. There were no other changes in the Company’s internal control over financial reporting that occurred during the most recent fiscal quarter covered by this report that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.

[0000950170-22-023803:item_4_controls:7]
55
