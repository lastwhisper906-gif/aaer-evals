# ADTN 8-K — 0000950170-22-022906 filed 2022-11-08

## item codes, every 8-K on or before 2022-11-09

- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2022-11-09

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-22-022906:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0000950170-22-022906:8k_2_02:2]
EX-99.1

[0000950170-22-022906:8k_2_02:3]
EXHIBIT 99.1

[0000950170-22-022906:8k_2_02:4]
ADTRAN Holdings, Inc. Reports Earnings for the Third Quarter of 2022 and Declares Quarterly Cash Dividend

[0000950170-22-022906:8k_2_02:5]
HUNTSVILLE, Ala. — (November 7, 2022) — ADTRAN Holdings, Inc., (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” or the “Company”), today announced financial results for the third quarter of 2022. For the quarter, revenue was $340.7 million. Net loss inclusive of the non-controlling interest for the third quarter of 2022 was $44.9 million. Net loss attributable to the Company for the third quarter of 2022 was $41.9 million and loss per share attributable to the Company was $0.57. Net loss and loss per share are inclusive of consolidated financial results, significant purchase accounting adjustments, and certain one-time transaction expenses related to the business combination of the Company, ADTRAN, Inc. (“ADTRAN”), and ADVA Optical Networking SE (“ADVA”). Inclusive of non-controlling interests, non-GAAP net income was $12.2 million. Non-GAAP net income attributable to the Company was $7.7 million and non-GAAP diluted earnings per share attributable to the Company was $0.11. Non-GAAP net income and non-GAAP earnings per share exclude acquisition related expenses, amortizations, and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments), stock-based compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, certain asset impairments, changes in valuation allowance related to our deferred tax assets, and the tax effect of these adjustments to net income.  The reconciliations between the non-GAAP net income measures presented herein and the respective equivalent GAAP financial measures are set forth in the tables provided below.

[0000950170-22-022906:8k_2_02:6]
ADTRAN Holdings Chairman and Chief Executive Officer Tom Stanton stated, “Our third quarter marked a new era in our history as we closed the business combination agreement with ADVA Optical Networking SE. The combined company’s broader portfolio, paired with a larger, more diversified, and regionally balanced customer base, positions us to capitalize on the global fiber conversion. The Q3 results highlight our increased market presence in optical networking and subscriber solutions, two portfolio categories that complement our continued success in fiber access. This success reinforces the positive outlook we have in our ability to maximize our growth potential in the ongoing global investment cycle in fiber networks.”

[0000950170-22-022906:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the third quarter of 2022. The quarterly cash dividend of $0.09 per common share is to be paid to the Company’s stockholders of record as of the close of business on November 22, 2022. The ex-dividend date is November 21, 2022, and the payment date will be December 6, 2022.

[0000950170-22-022906:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its third quarter results on Tuesday, November 8, 2022, at 9:30 a.m. Central Time or 4:30 p.m. Central European Time. ADTRAN Holdings will webcast this conference call. To listen, simply visit our Investor Relations site at adtran.com/investor approximately 10 minutes prior to the start of the call, click on the event “ADTRAN Holdings Releases 3rd Quarter 2022 Financial Results and Earnings Call”, and click on the Webcast link.

[0000950170-22-022906:8k_2_02:9]
An online replay of the Company’s conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or email at investor.relations@adtran.com.

[0000950170-22-022906:8k_2_02:10]
About ADTRAN Holdings, Inc.

[0000950170-22-022906:8k_2_02:11]
ADTRAN Holdings, Inc. is the parent company of ADTRAN, Inc., a wholly owned subsidiary and a leading global provider of open, disaggregated networking and communications solutions. ADTRAN Holdings is also the largest shareholder of ADVA, a European telecommunications vendor that provides network equipment for data, storage, voice, and video services.

[0000950170-22-022906:8k_2_02:12]
Cautionary Note Regarding Forward-Looking Statements

[0000950170-22-022906:8k_2_02:13]
This press release contains forward-looking statements, generally identified by the use of words such as “believe,” “expect,” “intend,” “estimate,” “anticipate,” “will,” “may,” “could” and similar expressions, which forward-looking statements reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including: (i) risks and uncertainties related to the continued impact of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (including variants of the SARS-CoV-2 coronavirus), including with respect to continued manufacturing and supply chain constraints; (ii) risks and uncertainties related to the completed business combination between the Company, ADTRAN and ADVA, including risks related to regulatory or other limitations imposed following the closing of the business combination on July 15, 2022 and the proposed domination and profit and loss transfer agreement between the Company as the controlling entity, and ADVA as the controlled entity; the ability to successfully integrate the ADTRAN and ADVA businesses; risks related to disruption of management time from ongoing business operations due to integration efforts following the business combination; the risk that the business combination could have adverse effects on the market

[0000950170-22-022906:8k_2_02:14]
price of ADTRAN Holdings’ common stock or ADVA’s common shares or the ability of the Company, ADTRAN, and ADVA to retain customers, retain or hire key personnel, maintain relationships with their respective suppliers and customers, and on their operating results and businesses generally; the risk that ADTRAN Holdings may be unable to achieve expected synergies or that it may take longer or be more costly than expected to achieve those synergies; the risk of fluctuations in revenue due to lengthy sales and approval processes required by major and other service providers for new products; the risk posed by potential breaches of information systems and cyber-attacks; the risks that ADTRAN, ADVA or ADTRAN Holdings may not be able to effectively compete, including through product improvements and development; and (iii) other risks set forth in ADVA’s annual and interim financial reports made publicly available and ADTRAN’s and ADTRAN Holdings’ public filings made with the Securities and Exchange Commission, including ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2021 and ADTRAN Holdings’ Form 10-Q for the quarterly period ended June 30, 2022. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0000950170-22-022906:8k_2_02:15]
Explanation of Use of Non-GAAP Financial Measures

[0000950170-22-022906:8k_2_02:16]
Set forth in the tables below are reconciliations of operating loss, net loss inclusive of the non-controlling interest, net loss attributable to the Company, and loss per share attributable to the Company, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP operating income, non-GAAP net income inclusive of the non-controlling interest, non-GAAP net income attributable to the Company, and non-GAAP diluted earnings per share attributable to the Company, respectively. Such non-GAAP measures exclude acquisition related expenses, amortizations and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments), stock-based compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, certain asset impairments, changes in valuation allowance related to our deferred tax assets, and the tax effect of these adjustments to net income. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of non-GAAP operating income, non-GAAP net income inclusive of the non-controlling interest, non-GAAP net income attributable to the Company, and non-GAAP diluted earnings per share attributable to the Company, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0000950170-22-022906:8k_2_02:17]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP operating income, non-GAAP net income and non-GAAP earnings per share - basic and diluted, may not be comparable to similar measures calculated by other companies.

[0000950170-22-022906:8k_2_02:18]
Investor Services/Assistance:

[0000950170-22-022906:8k_2_02:19]
Rhonda Lambert/256-963-7450

[0000950170-22-022906:8k_2_02:20]
Investor.relations@adtran.com

[0000950170-22-022906:8k_2_02:21]
Condensed Consolidated Balance Sheets

[0000950170-22-022906:8k_2_02:22]
(Unaudited)

[0000950170-22-022906:8k_2_02:23]
(In thousands)

[0000950170-22-022906:8k_2_02:24]
|  | September 30, |  |  | December 31, |  |
|  | 2022 |  |  | 2021 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 111,099 |  |  | $ | 56,603 |  |
| Restricted cash |  | — |  |  |  | 215 |  |
| Short-term investments |  | 803 |  |  |  | 350 |  |
| Accounts receivable, net |  | 302,401 |  |  |  | 158,742 |  |
| Other receivables |  | 14,350 |  |  |  | 11,228 |  |
| Inventory, net |  | 416,163 |  |  |  | 139,891 |  |
| Prepaid expenses and other current assets |  | 30,739 |  |  |  | 9,296 |  |
| Total Current Assets |  | 875,555 |  |  |  | 376,325 |  |
| Property, plant and equipment, net |  | 104,577 |  |  |  | 55,766 |  |
| Deferred tax assets, net |  | — |  |  |  | 9,079 |  |
| Goodwill |  | 357,869 |  |  |  | 6,968 |  |
| Intangibles, net |  | 393,575 |  |  |  | 19,293 |  |
| Other non-current assets |  | 56,347 |  |  |  | 30,971 |  |
| Long-term investments |  | 50,131 |  |  |  | 70,615 |  |
| Total Assets | $ | 1,838,054 |  |  | $ | 569,017 |  |
| Liabilities and Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 276,026 |  |  | $ | 102,489 |  |
| Revolving credit agreements outstanding |  | 84,503 |  |  |  | — |  |
| Notes payable |  | 29,782 |  |  |  | — |  |
| Unearned revenue |  | 40,993 |  |  |  | 17,737 |  |
| Accrued expenses and other liabilities |  | 25,554 |  |  |  | 13,673 |  |
| Accrued wages and benefits |  | 41,595 |  |  |  | 14,900 |  |
| Income tax payable, net |  | 26,838 |  |  |  | 6,560 |  |
| Total Current Liabilities |  | 525,291 |  |  |  | 155,359 |  |
| Deferred tax liabilities, net |  | 36,884 |  |  |  | — |  |
| Non-current unearned revenue |  | 18,269 |  |  |  | 9,271 |  |
| Pension liability |  | 16,220 |  |  |  | 11,402 |  |
| Deferred compensation liability |  | 25,376 |  |  |  | 31,383 |  |
| Non-current lease obligations |  | 21,490 |  |  |  | 3,269 |  |
| Other non-current liabilities |  | 9,697 |  |  |  | 1,231 |  |
| Total Liabilities |  | 653,227 |  |  |  | 211,915 |  |
| Common stock |  | 776 |  |  |  | 797 |  |
| Additional paid-in capital |  | 883,210 |  |  |  | 288,946 |  |
| Accumulated other comprehensive loss |  | (40,288 | ) |  |  | (11,914 | ) |
| Retained earnings |  | 31,535 |  |  |  | 740,820 |  |
| Treasury stock |  | (4,083 | ) |  |  | (661,547 | ) |
| Non-controlling interest |  | 313,677 |  |  |  | — |  |
| Total Equity |  | 1,184,827 |  |  |  | 357,102 |  |
| Total Liabilities Equity | $ | 1,838,054 |  |  | $ | 569,017 |  |

[0000950170-22-022906:8k_2_02:25]
Condensed Consolidated Statements of Loss

[0000950170-22-022906:8k_2_02:26]
(Unaudited)

[0000950170-22-022906:8k_2_02:27]
(In thousands, except per share data)

[0000950170-22-022906:8k_2_02:28]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 304,940 |  |  | $ | 120,767 |  |  | $ | 599,306 |  |  | $ | 360,025 |  |  |
| Services & Support |  |  | 35,769 |  |  |  | 17,314 |  |  |  | 67,959 |  |  |  | 48,821 |  |  |
| Total Revenue |  |  | 340,709 |  |  |  | 138,081 |  |  |  | 667,265 |  |  |  | 408,846 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 226,635 |  |  |  | 81,029 |  |  |  | 417,209 |  |  |  | 216,044 |  |  |
| Services & Support |  |  | 11,047 |  |  |  | 9,379 |  |  |  | 30,207 |  |  |  | 28,860 |  |  |
| Total Cost of Revenue |  |  | 237,682 |  |  |  | 90,408 |  |  |  | 447,416 |  |  |  | 244,904 |  |  |
| Gross Profit |  |  | 103,027 |  |  |  | 47,673 |  |  |  | 219,849 |  |  |  | 163,942 |  |  |
| Selling, general and administrative expenses |  |  | 74,880 |  |  |  | 30,972 |  |  |  | 130,646 |  |  |  | 89,273 |  |  |
| Research and development expenses |  |  | 59,196 |  |  |  | 26,759 |  |  |  | 112,187 |  |  |  | 82,131 |  |  |
| Asset impairment |  |  | 16,969 |  |  |  | — |  |  |  | 16,969 |  |  |  | — |  |  |
| Operating Loss |  |  | (48,018 | ) |  |  | (10,058 | ) |  |  | (39,953 | ) |  |  | (7,462 | ) |  |
| Interest and dividend income |  |  | 347 |  |  |  | 344 |  |  |  | 768 |  |  |  | 887 |  |  |
| Interest expense |  |  | (1,303 | ) |  |  | (6 | ) |  |  | (1,427 | ) |  |  | (18 | ) |  |
| Net investment (loss) gain |  |  | (2,691 | ) |  |  | (63 | ) |  |  | (10,752 | ) |  |  | 2,942 |  |  |
| Other income, net |  |  | 2,494 |  |  |  | 648 |  |  |  | 2,949 |  |  |  | 2,673 |  |  |
| Loss Before Income Taxes |  |  | (49,171 | ) |  |  | (9,135 | ) |  |  | (48,415 | ) |  |  | (978 | ) |  |
| Income tax benefit (expense) |  |  | 4,312 |  |  |  | (1,292 | ) |  |  | 4,572 |  |  |  | (3,467 | ) |  |
| Net Loss |  | $ | (44,859 | ) |  | $ | (10,427 | ) |  | $ | (43,843 | ) |  | $ | (4,445 | ) |  |
| Less: Net Loss attributable to non-controlling interest |  |  | (2,925 | ) |  |  | — |  |  |  | (2,925 | ) |  |  | — |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (41,934 | ) |  | $ | (10,427 | ) |  | $ | (40,918 | ) |  | $ | (4,445 | ) |  |
| Weighted average shares outstanding – basic |  |  | 73,036 |  |  |  | 48,609 |  |  |  | 57,175 |  |  |  | 48,470 |  |  |
| Weighted average shares outstanding – diluted |  |  | 73,036 |  |  |  | 48,609 |  |  |  | 57,175 |  |  |  | 48,470 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.57 | ) |  | $ | (0.21 | ) |  | $ | (0.72 | ) |  | $ | (0.09 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.57 | ) |  | $ | (0.21 | ) |  | $ | (0.72 | ) |  | $ | (0.09 | ) |  |

[0000950170-22-022906:8k_2_02:29]
Condensed Consolidated Statements of Cash Flows

[0000950170-22-022906:8k_2_02:30]
(Unaudited)

[0000950170-22-022906:8k_2_02:31]
(In thousands)

[0000950170-22-022906:8k_2_02:32]
|  |  | Nine Months Ended |  |
|  |  | September 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net loss |  | $ | (43,843 | ) |  | $ | (4,445 | ) |
| Adjustments to reconcile net income to net cash (used in) provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 34,783 |  |  |  | 12,246 |  |
| Asset impairment |  |  | 16,969 |  |  |  | — |  |
| Amortization of debt issuance cost |  |  | 200 |  |  |  | — |  |
| Loss (gain) on investments |  |  | 10,395 |  |  |  | (3,320 | ) |
| Stock-based compensation expense |  |  | 15,912 |  |  |  | 5,457 |  |
| Deferred income taxes |  |  | (26,366 | ) |  |  | 437 |  |
| Other, net |  |  | 32 |  |  |  | 89 |  |
| Inventory reserves |  |  | (6,681 | ) |  |  | (4,789 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (34,535 | ) |  |  | (26,346 | ) |
| Other receivables |  |  | (2,154 | ) |  |  | 11,152 |  |
| Inventory |  |  | (76,293 | ) |  |  | 2,120 |  |
| Prepaid expenses, other current assets and other assets |  |  | 610 |  |  |  | (8,514 | ) |
| Accounts payable |  |  | 70,381 |  |  |  | 29,614 |  |
| Accrued expenses and other liabilities |  |  | (23,005 | ) |  |  | 10,392 |  |
| Income taxes payable, net |  |  | 20,862 |  |  |  | 4,798 |  |
| Net cash (used in) provided by operating activities |  |  | (42,733 | ) |  |  | 28,891 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (10,141 | ) |  |  | (3,572 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 30,474 |  |  |  | 28,305 |  |
| Purchases of available-for-sale investments |  |  | (22,215 | ) |  |  | (28,853 | ) |
| Proceeds from beneficial interests in securitized accounts receivable |  |  | 1,294 |  |  |  | — |  |
| Proceeds from disposals of property, plant and equipment |  |  | 12 |  |  |  | — |  |
| Insurance proceeds received |  |  | — |  |  |  | 500 |  |
| Acquisition of business, net of cash acquired |  |  | 43,957 |  |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | 43,381 |  |  |  | (3,620 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (515 | ) |  |  | (113 | ) |
| Proceeds from stock option exercises |  |  | 5,434 |  |  |  | 6,111 |  |
| Dividend payments |  |  | (15,859 | ) |  |  | (13,124 | ) |
| Proceeds from draw on revolving credit agreement |  |  | 133,141 |  |  |  | — |  |
| Repayment of revolving credit agreement |  |  | (48,000 | ) |  |  | — |  |
| Payment of debt issuance cost |  |  | (3,015 | ) |  |  | — |  |
| Repayment of notes payable |  |  | (10,057 | ) |  |  | — |  |
| Net cash provided by (used in) financing activities |  |  | 61,129 |  |  |  | (7,126 | ) |
| Net increase in cash, cash equivalents and restricted cash |  |  | 61,777 |  |  |  | 18,145 |  |
| Effect of exchange rate changes |  |  | (7,496 | ) |  |  | (2,719 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  |  | 56,818 |  |  |  | 60,179 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 111,099 |  |  | $ | 75,605 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 633 |  |  | $ | — |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 904 |  |  | $ | 1,833 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 1,037 |  |  | $ | 100 |  |
| ADVA common shares exchanged in acquisition |  | $ | 565,491 |  |  | $ | — |  |
| ADVA options assumed in acquisition |  | $ | 12,769 |  |  | $ | — |  |
| Non-controlling interest related to ADVA |  | $ | 316,415 |  |  | $ | — |  |

[0000950170-22-022906:8k_2_02:33]
Supplemental Information

[0000950170-22-022906:8k_2_02:34]
Reconciliation of Operating Loss to Non-GAAP Operating Income (Loss)

[0000950170-22-022906:8k_2_02:35]
(Unaudited)

[0000950170-22-022906:8k_2_02:36]
(In thousands)

[0000950170-22-022906:8k_2_02:37]
|  |  | Three Months Ended September 30, |  |  | Nine Months ended September 30, |  |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |  |
| Operating Loss |  | $ | (48,018 | ) |  | $ | (10,058 | ) |  | $ | (39,953 | ) |  | $ | (7,462 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 40,310 |  | (1) |  | 6,041 |  | (6) |  | 44,763 |  | (8) |  | 9,470 |  | (11) |
| Asset impairments |  |  | 16,969 |  | (2) |  | — |  |  |  | 16,969 |  | (2) |  | — |  |  |
| Stock-based compensation expense |  |  | 12,131 |  | (3) |  | 1,842 |  | (7) |  | 15,912 |  | (9) |  | 5,457 |  | (12) |
| Pension adjustments |  |  | 244 |  | (4) |  | — |  |  |  | 244 |  | (4) |  | — |  |  |
| Restructuring expenses |  |  | — |  |  |  | — |  |  |  | 2 |  | (10) |  | 309 |  | (13) |
| Deferred compensation adjustments |  |  | (740 | ) | (5) |  | (459 | ) | (5) |  | (7,173 | ) | (5) |  | 2,091 |  | (5) |
| Non-GAAP Operating Income (Loss) |  | $ | 20,896 |  |  | $ | (2,634 | ) |  | $ | 30,764 |  |  | $ | 9,865 |  |  |

[0000950170-22-022906:8k_2_02:38]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $25.5 million is included in total cost of revenue, $14.3 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-22-022906:8k_2_02:39]
(2) Includes impairment charges related to the abandonment of certain information technology projects due to the business combination.

[0000950170-22-022906:8k_2_02:40]
(3) $1.3 million is included in total cost of revenue, $9.1 million is included in selling, general and administrative expenses and $1.7 million is included in research and development expenses on the condensed consolidated statements of income (loss).  Includes $8.9 million of incremental stock-based award modification expense related to the business combination.

[0000950170-22-022906:8k_2_02:41]
(4)  Less than $0.1 million is included in total cost of revenue, $0.1 million is included in selling, general and administrative expenses and $0.1 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-22-022906:8k_2_02:42]
(5) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of income (loss).

[0000950170-22-022906:8k_2_02:43]
(6) $5.5 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-22-022906:8k_2_02:44]
(7) $0.1 million is included in total cost of revenue, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the consolidated statements of income (loss).

[0000950170-22-022906:8k_2_02:45]
(8) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $25.5 million is included in total cost of revenue, $17.8 million is included in selling, general and administrative expenses and $1.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-22-022906:8k_2_02:46]
(9) $1.6 million is included in total cost of revenue, $11.4 million is included in selling, general and administrative expenses and $2.9 million is included in research and development expenses on the condensed consolidated statements of income (loss).  Includes $8.9 million of incremental stock-based award modification expense related to the business combination.

[0000950170-22-022906:8k_2_02:47]
(10) Less than $0.1 million is included in selling, general and administrative expenses condensed consolidated statements of income (loss).

[0000950170-22-022906:8k_2_02:48]
(11) $8.0 million is included in selling, general and administrative expenses and $1.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-22-022906:8k_2_02:49]
(12) $0.4 million is included in total cost of revenue, $3.3 million is included in selling, general and administrative expenses and $1.8 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-22-022906:8k_2_02:50]
(13) $0.1 million is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-22-022906:8k_2_02:51]
Supplemental Information

[0000950170-22-022906:8k_2_02:52]
Reconciliation of Net Loss inclusive of Non-Controlling Interest to

[0000950170-22-022906:8k_2_02:53]
Non-GAAP Net Income (Loss) inclusive of Non-Controlling Interest

[0000950170-22-022906:8k_2_02:54]
(Unaudited)

[0000950170-22-022906:8k_2_02:55]
and

[0000950170-22-022906:8k_2_02:56]
Reconciliation of Net Loss attributable to ADTRAN Holdings, Inc. and Loss per Common Share attributable to

[0000950170-22-022906:8k_2_02:57]
ADTRAN Holdings, Inc. – Basic and Diluted to Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc.

[0000950170-22-022906:8k_2_02:58]
and Non-GAAP Earnings (Loss) per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0000950170-22-022906:8k_2_02:59]
(Unaudited)

[0000950170-22-022906:8k_2_02:60]
(In thousands, except per share amounts)

[0000950170-22-022906:8k_2_02:61]
|  |  | Three Months Ended September 30, |  |  | Nine Months ended September 30, |  |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (41,934 | ) |  | $ | (10,427 | ) |  | $ | (40,918 | ) |  | $ | (4,445 | ) |  |
| Plus: Net Loss attributable to non-controlling interest |  |  | (2,925 | ) |  |  | — |  |  |  | (2,925 | ) |  |  | — |  |  |
| Net Loss inclusive of non-controlling interest |  | $ | (44,859 | ) |  | $ | (10,427 | ) |  | $ | (43,843 | ) |  | $ | (4,445 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 40,310 |  |  |  | 6,041 |  |  |  | 44,763 |  |  |  | 9,470 |  |  |
| Asset impairments |  |  | 16,969 |  |  |  | — |  |  |  | 16,969 |  |  |  | — |  |  |
| Stock-based compensation expense |  |  | 12,131 |  |  |  | 1,842 |  |  |  | 15,912 |  |  |  | 5,457 |  |  |
| Valuation allowance |  |  | 3,182 |  |  |  | 2,455 |  |  |  | 15,550 |  |  |  | 4,413 |  |  |
| Deferred compensation adjustments (1) |  |  | 383 |  |  |  | (262 | ) |  |  | (612 | ) |  |  | 552 |  |  |
| Pension adjustments (2) |  |  | 325 |  |  |  | 272 |  |  |  | 499 |  |  |  | 825 |  |  |
| Restructuring expenses |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | 309 |  |  |
| Tax effect of adjustments to net income (loss) |  |  | (16,245 | ) |  |  | (736 | ) |  |  | (17,430 | ) |  |  | (2,931 | ) |  |
| Non-GAAP Net Income (Loss) inclusive of non-controlling interest |  | $ | 12,196 |  |  | $ | (815 | ) |  | $ | 31,810 |  |  | $ | 13,650 |  |  |
| Less: Non-GAAP Net Income attributable to non-controlling interest |  |  | 4,486 |  |  |  | — |  |  |  | 4,486 |  |  |  | — |  |  |
| Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. |  | $ | 7,710 |  |  | $ | (815 | ) |  | $ | 27,324 |  |  | $ | 13,650 |  |  |
| Weighted average shares outstanding – basic |  |  | 73,036 |  |  |  | 48,609 |  |  |  | 57,175 |  |  |  | 48,470 |  |  |
| Weighted average shares outstanding – diluted |  |  | 73,036 |  |  |  | 48,609 |  |  |  | 57,175 |  |  |  | 48,470 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. - basic |  | $ | (0.57 | ) |  | $ | (0.21 | ) |  | $ | (0.72 | ) |  | $ | (0.09 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. - diluted |  | $ | (0.57 | ) |  | $ | (0.21 | ) |  | $ | (0.72 | ) |  | $ | (0.09 | ) |  |
| Non-GAAP earnings (loss) per common share attributable to ADTRAN Holdings, Inc. - basic |  | $ | 0.11 |  |  | $ | (0.02 | ) |  | $ | 0.48 |  |  | $ | 0.28 |  |  |
| Non-GAAP earnings (loss) per common share attributable to ADTRAN Holdings, Inc. - basic |  | $ | 0.11 |  |  | $ | (0.02 | ) |  | $ | 0.48 |  |  | $ | 0.28 |  |  |

[0000950170-22-022906:8k_2_02:62]
(1) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-22-022906:8k_2_02:63]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.
