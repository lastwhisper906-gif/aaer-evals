# ADTN notes — 0000950170-22-023803


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-22-023803:notes:1]
GENERAL

[0000950170-22-023803:notes:2]
On July 8, 2022, Acorn MergeCo, Inc. (“Merger Sub”), a Delaware corporation and wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (f/k/a Acorn HoldCo, Inc.), merged with and into ADTRAN, Inc., with ADTRAN, Inc. surviving the merger as a wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (the “Merger”). The Merger was consummated pursuant to the Business Combination Agreement, dated as of August 30, 2021 (the “Business Combination Agreement”), by and among ADTRAN Holdings, Inc., ADTRAN, Inc., ADVA Optical Networking SE, a company organized and existing under the laws of Germany (“ADVA”), and Merger Sub. In accordance with the Business Combination Agreement, ADTRAN Holdings, Inc. made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of common stock, par value $0.01 per share (the “Company Common Stock”), of ADTRAN Holdings, Inc. (the “Exchange Offer” and, together with the Merger, the “Business Combination”). On July 15, 2022 (the “Exchange Offer Settlement Date”), ADTRAN Holdings, Inc. completed the Exchange Offer, in which ADTRAN Holdings, Inc. acquired 34.0 million bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 28.0 million shares of Company Common Stock. See Note 2 for additional information.

[0000950170-22-023803:notes:3]
On October 18, 2022, the Board of Directors of the Company and the management board of ADVA agreed on a final draft of a domination and profit and loss transfer agreement (the “DPLTA”) between the Company, as the controlling company, and ADVA, as the controlled company. The parties’ execution of the DPLTA remains subject to approval of the DPLTA by shareholders of ADVA with 75% of the votes cast in an extraordinary general meeting, which is scheduled to be held on November 30, 2022. If and when signed, effectiveness of the DPLTA is subject to the subsequent registration of the DPLTA with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered offices of ADVA, with such effectiveness to occur no earlier than January 1, 2023. The Company currently holds 33,957,538 shares of ADVA, representing 65.35% of ADVA’s outstanding shares on September 30, 2022. Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to “ADTRAN,” the “Company,” “we,” “us” and “our” refer to ADTRAN, Inc. and its consolidated subsidiaries prior to the Merger on July 8, 2022, and to ADTRAN Holdings, Inc. and its consolidated subsidiaries following the Merger.

[0000950170-22-023803:notes:4]
[same as prior period, unchanged from 0000950170-22-015058:notes:3]

[0000950170-22-023803:notes:5]
[same as prior period, unchanged from 0000950170-22-015058:notes:4]

[0000950170-22-023803:notes:6]
The accompanying unaudited Condensed Consolidated Financial Statements of ADTRAN Holdings, Inc. and its subsidiaries have been prepared pursuant to the rules and regulations of the SEC applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. Certain prior year amounts have been reclassified to conform to the current period presentation. The December 31, 2021 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

[0000950170-22-023803:notes:7]
[same as prior period, unchanged from 0000950170-22-015058:notes:6]

[0000950170-22-023803:notes:8]
[same as prior period, unchanged from 0000950170-22-015058:notes:7]

[0000950170-22-023803:notes:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

[0000950170-22-023803:notes:10]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus), supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of September 30, 2022 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints and inflationary pressures could result in further impacts to the Company's consolidated financial statements in future reporting periods.

[0000950170-22-023803:notes:11]
Recently Adopted Accounting Pronouncements

[0000950170-22-023803:notes:12]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. The Company early adopted ASU 2021-08 on July 1, 2022 and the standard was applied retrospectively beginning with January 1, 2022. The effect of the adoption of this standard on the Company's Condensed Consolidated Financial Statements as of the date of this report is included in Note 2 of the Notes to Condensed Consolidated Financial Statements.

[0000950170-22-023803:notes:13]
[same as prior period, unchanged from 0000950170-22-015058:notes:12]

[0000950170-22-023803:notes:14]
There are currently no accounting pronouncements not yet adopted that had a material effect on the Condensed Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-22-023803:notes:15]
2. BUSINESS COMBINATION

[0000950170-22-023803:notes:16]
ADVA Optical Networking SE

[0000950170-22-023803:notes:17]
On August 30, 2021, ADTRAN and ADVA, entered into a Business Combination Agreement, pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, ADTRAN Holdings, Inc. (formerly known as Acorn HoldCo, Inc.) which was formed as a wholly-owned subsidiary of ADTRAN in order to consummate the transactions under the Business Combination Agreement. Under the terms of the Business Combination Agreement, on July 8, 2022, Acorn MergeCo, Inc, a Delaware corporation and wholly-owned direct subsidiary of the Company, merged with and into ADTRAN Holdings, Inc. with ADTRAN Holdings, Inc. surviving the Business Combination as a wholly-owned direct subsidiary of the Company.

[0000950170-22-023803:notes:18]
Additionally, pursuant to the Business Combination Agreement, the Company made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of Company Common Stock, par value $0.01 per share of the Company. The Exchange Offer was settled on Exchange Offer Settlement Date, on which date the Company acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of Company Common Stock. Additionally, pursuant to the Business Combination Agreement, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN, Inc. The fair value of the ADVA stock options assumed by ADTRAN, Inc. was $12.8 million, estimated using the Monte Carlo method.

[0000950170-22-023803:notes:19]
ADTRAN, Inc. and ADVA became subsidiaries of ADTRAN Holdings, Inc. as a result of the Business Combination. ADTRAN was determined to be the accounting acquirer of ADVA based on ADTRAN shareholders’ majority equity stake in the combined company, the composition of the board of directors and senior management of the combined company, among other factors. The Business Combination of ADVA has been accounted for using the acquisition method of accounting as per the provisions of Accounting Standards Codification 805, “Business Combinations” (“ASC 805”). The Business Combination Agreement used a fixed exchange ratio of Company Common Stock for ADVA shares of common stock, which resulted in a 36% equity stake for ADVA stockholders and 64% equity stake for ADTRAN stockholders in the post-closing combined company (calculated on a fully diluted basis and utilizing the tender of 65.43% of ADVA’s current issued and outstanding share capital). Therefore, ADTRAN shareholders continue to hold a majority interest in the combined company after the Business Combination was completed. Additionally, the Board of Directors is comprised of six members from ADTRAN and three members from ADVA; the current ADTRAN chief executive officer acts as the chairman of the Board of Directors and the former ADVA chief executive officer as the vice chairman of the Board of Directors. Additionally, the current ADTRAN chief executive officer and ADTRAN chief financial officer hold these positions within the combined company. After these and other considerations as outlined in ASC 805, ADTRAN represents the accounting acquirer.

[0000950170-22-023803:notes:20]
The following table summarizes the purchase price for the ADVA business combination:

[0000950170-22-023803:notes:21]
| (In thousands, except shares, share price and exchange ratio) |  | Purchase Price |  |
| ADVA shares exchanged |  |  | 33,957,538 |  |
| Exchange ratio |  |  | 0.8244 |  |
| ADTRAN Holdings, Inc. shares issued |  |  | 27,994,595 |  |
| ADTRAN Holdings, Inc. share price on July 15, 2022 |  | $ | 20.20 |  |
| Purchase price paid for ADVA shares |  | $ | 565,491 |  |
| Equity compensation (1) |  | $ | 12,769 |  |
| Total purchase price |  | $ | 578,260 |  |

[0000950170-22-023803:notes:22]
(1) Represents the portion of replacement share-based payment awards that relates to pre-combination vesting.

[0000950170-22-023803:notes:23]
Assets acquired and liabilities assumed were recognized at their respective fair values as of July 15, 2022. The following table summarizes the preliminary purchase price allocation for each major class of assets acquired and liabilities assumed in the acquisition of ADVA (in thousands):

[0000950170-22-023803:notes:24]
| (In thousands) |  |  |  |
| Total purchase price |  | $ | 578,260 |  |
| Non-controlling interest |  | $ | 316,415 |  |
| Net Assets: |  |  |  |
| Cash and cash equivalents |  | $ | 44,003 |  |
| Accounts receivable |  |  | 114,659 |  |
| Other receivables |  |  | 1,457 |  |
| Inventory |  |  | 200,532 |  |
| Prepaid expenses and other current assets |  |  | 29,474 |  |
| Property plant and equipment |  |  | 52,796 |  |
| Deferred tax assets |  |  | 1,599 |  |
| Intangibles |  |  | 405,385 |  |
| Other non-current assets |  |  | 30,588 |  |
| Accounts payable |  |  | (98,587 | ) |
| Current unearned revenue |  |  | (26,047 | ) |
| Accrued expenses and other liabilities |  |  | (59,600 | ) |
| Current portion of notes payable |  |  | (25,254 | ) |
| Income tax payable |  |  | (1,400 | ) |
| Non-current unearned revenue |  |  | (11,498 | ) |
| Pension liability |  |  | (6,820 | ) |
| Other non-current liabilities |  |  | (6,094 | ) |
| Non-current portion of revolving credit agreements and notes payable |  |  | (15,250 | ) |
| Non-current lease obligations |  |  | (20,046 | ) |
| Deferred tax liabilities |  |  | (74,379 | ) |
| Total net assets acquired |  | $ | 535,518 |  |
| Goodwill |  | $ | 359,157 |  |

[0000950170-22-023803:notes:25]
The allocation of the purchase price and fair value assessment of goodwill, property, plant and equipment, intangible assets, inventory, deferred tax assets, and deferred tax liabilities is preliminary as a result of ongoing valuation procedures on the assets acquired and liabilities assumed. The acquisition accounting is subject to revision once the Company receives final information. It is possible that the final assessment of fair value may differ materially from the preliminary assessment. If the final assessment differs from this preliminary assessment, the measurement period adjustments will be recorded in the period in which they are determined as if they had been completed at the acquisition date.

[0000950170-22-023803:notes:26]
The preliminary fair value of the assets acquired include accounts receivable of $114.7 million and other receivables of $1.5 million. The unpaid principal balance under these receivables is $118.5 million and $1.5 million, respectively. The difference between the fair value and the unpaid principal balance primarily represents amounts expected to be uncollectible.

[0000950170-22-023803:notes:27]
The fair value of the intangible assets acquired as of the acquisition date:

[0000950170-22-023803:notes:28]
| (In thousands) | Estimated-average useful life (in years) (1) |  |  | Fair value |  |  | Income Statement Amortization Classification |
| Developed technology |  | 8.5 |  |  | $ | 293,530 |  |  | Cost of revenue - Network Solutions |
| Backlog |  | 1.4 |  |  |  | 52,165 |  |  | Cost of revenue - Network Solutions and Services & Support |
| Customer relationships |  | 10.5 |  |  |  | 32,704 |  |  | Selling, general and administrative expenses |
| Trade name |  | 2.8 |  |  |  | 26,986 |  |  | Selling, general and administrative expenses |
| Total |  |  |  | $ | 405,385 |  |  |  |

[0000950170-22-023803:notes:29]
(1) Determination of the weighted average period of the individual categories of intangible assets was based on the nature of the applicable intangible asset and the expected future cash flows to be derived from the intangible asset. Amortization of intangible assets with definite lives is recognized over the period of time the assets are expected to contribute to future cash flows.

[0000950170-22-023803:notes:30]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and intangible assets acquired. Based on preliminary estimates, the ADVA acquisition resulted in the recognition of goodwill of $359.2 million, which the Company believes is attributable to the value driven by the Company’s expected growth of the business, synergies, and expanded market and product opportunities. Goodwill created as a result of the ADVA acquisition is not deductible for tax purposes.

[0000950170-22-023803:notes:31]
After the Business Combination, the chief operating decision maker assessed and will continue to assess the Company’s performance and allocate resources to its two segments (1) Network Solutions and (2) Services & Support. Based on preliminary estimates, the goodwill resulting from the Business Combination of $270.6 million was allocated to the Network Solutions segment, and $88.6 million was allocated to the Services & Support segment. See Note 18 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for more information about the Company’s segments.

[0000950170-22-023803:notes:32]
As of the acquisition date, the fair value of the non-controlling interest was approximately $316.4 million and determined using a market approach. As a portion of ADVA shares will remain trading after the Business Combination, the non-controlling interest was calculated using 17,941,496 ADVA shares held by non-controlling interest multiplied by the ADVA closing share price of €17.58 ($17.64 using the July 15, 2022 EUR to USD conversion rate of $1.00318) on July 15, 2022.

[0000950170-22-023803:notes:33]
The Company included the financial results of ADVA in its consolidated financial statements since July 15, 2022, the acquisition date. The net revenue and net loss from the ADVA business since July 15, 2022, were $163.8 million and $8.4 million, respectively, which are included in the Company’s Condensed Consolidated Statement of Loss. The net loss attributable to non-controlling interest from the ADVA business for the three and nine months ended September 30, 2022 was $2.9 million.

[0000950170-22-023803:notes:34]
As of September 30, 2022, the Company has incurred $25.2 million of transaction costs related to the Business Combination, of which $10.6 million and $5.1 million were incurred during the three months ended September 30, 2022 and 2021, respectively and $13.3 million and $6.4 million were incurred during the nine months ended September, 30 2022 and 2021, respectively. The Company expects to incur an estimated $1.1 million of additional transaction costs related to the Business Combination. These transaction costs are recorded in selling, general and administrative expense in the Condensed Consolidated Statements of Loss.

[0000950170-22-023803:notes:35]
Supplemental Pro Forma Information (Unaudited)

[0000950170-22-023803:notes:36]
The unaudited pro forma financial information in the table below summarizes the combined results of operations for ADTRAN and ADVA as though the Business Combination had occurred on January 1, 2021. The pro forma amounts have been adjusted for differences in basis of accounting which are determined before taking into effect the impacts of purchase accounting and Business Combination accounting impacts.

[0000950170-22-023803:notes:37]
The following unaudited pro forma information is presented for illustrative purposes only. It is not necessarily indicative of the results of operations of future periods, the results of operations that actually would have been realized had the entities been a single company as of January 1, 2021, or the future operating results of the combined entities. The unaudited pro forma information does not give effect to the potential impact of current financial conditions, regulatory matters or any anticipated synergies, operating efficiencies or cost savings that may be associated with the acquisition. The unaudited pro forma information also does not include any integration costs or remaining future transaction costs that the Company may incur related to the acquisition as part of combining the operations of the companies.

[0000950170-22-023803:notes:38]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | September 30, |  |  | September 30, |  |
| (In thousands) | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Revenue | $ | 368,192 |  |  | $ | 317,067 |  |  | $ | 1,053,510 |  |  | $ | 942,003 |  |
| Net income (loss) | $ | (48,084 | ) |  | $ | (44,154 | ) |  | $ | (60,494 | ) |  | $ | (133,321 | ) |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000950170-22-023803:notes:39]
The unaudited pro forma financial information in the table below summarizes the combined results of operations for ADTRAN and ADVA as though the Business Combination had occurred on January 1, 2021.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000950170-22-023803:notes:40]
3. CASH, CASH EQUIVALENTS AND RESTRICTED CASH

[0000950170-22-023803:notes:41]
[same as prior period, unchanged from 0000950170-22-015058:notes:15]

[0000950170-22-023803:notes:42]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Cash and cash equivalents |  | $ | 111,099 |  |  | $ | 56,603 |  |
| Restricted cash |  |  | — |  |  |  | 215 |  |
| Cash, cash equivalents and restricted cash |  | $ | 111,099 |  |  | $ | 56,818 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-22-023803:notes:43]
4. REVENUE

[0000950170-22-023803:notes:44]
[same as prior period, unchanged from 0000950170-22-015058:notes:18]

[0000950170-22-023803:notes:45]
Network Solutions Segment - Includes hardware and software products that enable a digital future.

[0000950170-22-023803:notes:46]
Services & Support Segment - Includes network design, implementation, maintenance and cloud-hosted services supporting the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

[0000950170-22-023803:notes:47]
[same as prior period, unchanged from 0000950170-22-015058:notes:21]

[0000950170-22-023803:notes:48]
In addition to the Company's reportable segments, revenue is also reported for the following three categories – Subscriber Solutions, Access & Aggregation Solutions and Optical Networking Solutions.

[0000950170-22-023803:notes:49]
Prior to the Business Combination with ADVA on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with ADVA, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable ADVA solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable ADVA solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of ADVA’s portfolio.

[0000950170-22-023803:notes:50]
Our Subscriber Solutions portfolio is used by service providers to terminate their access services infrastructure at the customer premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

[0000950170-22-023803:notes:51]
Our Access & Aggregation Solutions are solutions that are used by communications service providers to connect residential subscribers, business subscribers and mobile radio networks to the service providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions, and access orchestration solutions that ensure highly reliable and efficient network performance.

[0000950170-22-023803:notes:52]
Our Optical Networking Solutions are used by communications service providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems, and automation platforms that are used to build high-scale, secure and assured optical networks.

[0000950170-22-023803:notes:53]
The following tables disaggregate revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

[0000950170-22-023803:notes:54]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 125,338 |  |  | $ | 8,337 |  |  | $ | 133,675 |  |  | $ | 42,704 |  |  | $ | 4,163 |  |  | $ | 46,867 |  |
| Access & Aggregation Solutions |  |  | 76,591 |  |  |  | 11,598 |  |  |  | 88,189 |  |  |  | 78,063 |  |  |  | 13,151 |  |  |  | 91,214 |  |
| Optical Networking Solutions |  |  | 103,011 |  |  |  | 15,834 |  |  |  | 118,845 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 304,940 |  |  | $ | 35,769 |  |  | $ | 340,709 |  |  | $ | 120,767 |  |  | $ | 17,314 |  |  | $ | 138,081 |  |

[0000950170-22-023803:notes:55]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 252,899 |  |  | $ | 17,248 |  |  | $ | 270,147 |  |  | $ | 140,257 |  |  | $ | 12,232 |  |  | $ | 152,489 |  |
| Access & Aggregation Solutions |  |  | 243,396 |  |  |  | 34,877 |  |  |  | 278,273 |  |  |  | 219,768 |  |  |  | 36,589 |  |  |  | 256,357 |  |
| Optical Networking Solutions |  |  | 103,011 |  |  |  | 15,834 |  |  |  | 118,845 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 599,306 |  |  | $ | 67,959 |  |  | $ | 667,265 |  |  | $ | 360,025 |  |  | $ | 48,821 |  |  | $ | 408,846 |  |

[0000950170-22-023803:notes:56]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of September 30, 2022 and December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $276.5 million and $101.1 million, respectively. As of September 30, 2022, approximately 82% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at September 30, 2022 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-22-023803:notes:57]
[same as prior period, unchanged from 0000950170-22-015058:notes:27]

[0000950170-22-023803:notes:58]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Accounts receivable, net |  | $ | 302,401 |  |  | $ | 158,742 |  |
| Contract assets(1) |  | $ | 1,790 |  |  | $ | 464 |  |
| Unearned revenue |  | $ | 40,993 |  |  | $ | 17,737 |  |
| Non-current unearned revenue |  | $ | 18,269 |  |  | $ | 9,271 |  |

[0000950170-22-023803:notes:59]
[same as prior period, unchanged from 0000950170-22-015058:notes:29]

[0000950170-22-023803:notes:60]
The Company is party to a receivables purchase agreement with a financial institution (the “Factor”). Pursuant to the terms of the arrangement, the Company, on a revolving basis, sells to the Factor certain of its accounts receivable balances without recourse. On each sale date, the Factor retains from the sale price a default reserve, up to a required balance, which are held by the Factor in a reserve account and pledged to the Company. The Factor is entitled to withdraw from the reserve account the sale price of a defaulted receivable. As of September 30, 2022, accounts receivable totaling $16.1 million were sold, of which $1.3 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of September 30, 2022, the Company has an allowance for doubtful accounts related to factored accounts receivable totaling $0.1 million. As of September 30, 2022, accounts receivables include $31.1 million related to the existing sale of receivables for which the transfer of the receivable has not taken place. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three and nine months ended September 30, 2022.

[0000950170-22-023803:notes:61]
Of the outstanding unearned revenue balances as of December 31, 2021, $2.8 million and $12.3 million was recognized as revenue during the three and nine months ended September 30, 2022, respectively. Of the $14.1 million of outstanding unearned revenue balances as of December 31, 2020, $2.0 million and $9.8 million was recognized as revenue during the three and nine months ended September 30, 2021, respectively.

[0000950170-22-023803:notes:62]
Accounts Receivable

[0000950170-22-023803:notes:63]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. Accounts receivable balances are considered past due when payment has not been received by the date indicated on the relevant invoice or based on agreed upon terms between the customer and the Company.

[0000950170-22-023803:notes:64]
As of September 30, 2022 and December 31, 2021, the Company’s outstanding accounts receivable balance was $302.4 million, and $158.7 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0000950170-22-023803:notes:65]
The allowance for credit losses was $0.2 million as of September 30, 2022 related to accounts receivable. No allowance for credit losses was recorded as of December 31, 2021 related to accounts receivable.

[0000950170-22-023803:notes:66]
Contract Assets

[0000950170-22-023803:notes:67]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of September 30, 2022 and December 31, 2021, the Company’s outstanding contract asset balance was $1.8 million and $0.5 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0000950170-22-023803:notes:68]
No allowance for credit losses was recorded for the year ended September 30, 2022 and December 31, 2021 related to contract assets.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000950170-22-023803:notes:69]
The table below presents revenue information by category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

[0000950170-22-023803:notes:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Subscriber Solutions |  | $ | 133,675 |  |  | $ | 46,867 |  |  | $ | 270,147 |  |  | $ | 152,489 |  |
| Access & Aggregation Solutions |  |  | 88,189 |  |  |  | 91,214 |  |  |  | 278,273 |  |  |  | 256,357 |  |
| Optical Networking Solutions |  |  | 118,845 |  |  |  | — |  |  |  | 118,845 |  |  |  | — |  |
| Total |  | $ | 340,709 |  |  | $ | 138,081 |  |  | $ | 667,265 |  |  | $ | 408,846 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-22-023803:notes:71]
5. INCOME TAXES

[0000950170-22-023803:notes:72]
The Company's effective tax rate changed from an expense of 14.1% of pre-tax income for the three months ended September 30, 2021, to a benefit of 8.8% of pre-tax income for the three months ended September 30, 2022 and changed from an expense of 354.5% of pre-tax income for the nine months ended September 30, 2021, to a benefit of 9.4% of pre-tax income for the nine months ended September 30, 2022. The change in the effective tax rate for the three and nine months ended September 30, 2022, was driven primarily by a change in our estimated tax rate as a result of the closing of the Business Combination with ADVA during the third quarter of 2022, the requirement to begin capitalizing Research and Development expenses for U.S. tax purposes beginning in 2022 as previously passed as part of the Tax Cuts and Jobs Act in December 2017 and the associated impact of those changes on our previously established valuation allowance.

[0000950170-22-023803:notes:73]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of September 30, 2022, the Company had net deferred tax assets totaling $29.2 million, and a valuation allowance totaling $66.1 million against those deferred tax assets. The remaining $36.9 million in deferred tax liabilities are primarily related to purchase price intangibles from the Business Combination closed with ADVA during the third quarter of 2022. During the nine months ended September 30, 2022, the total change in the valuation allowance against our domestic and international deferred tax assets was recorded in the amount of $15.8 million and $0.2 million, respectively. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results as well as the evaluation of evidence which requires significant judgment, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance, or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.

[0000950170-22-023803:notes:74]
Supplemental balance sheet information related to deferred tax assets (liabilities) is as follows:

[0000950170-22-023803:notes:75]
|  |  | As of September 30, 2022 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Liabilities, net |  |
| Domestic |  | $ | 68,723 |  |  | $ | (64,054 | ) |  | $ | 4,669 |  |
| International |  |  | (39,493 | ) |  |  | (2,060 | ) |  |  | (41,553 | ) |
| Total |  | $ | 29,230 |  |  | $ | (66,114 | ) |  | $ | (36,884 | ) |

[0000950170-22-023803:notes:76]
[same as prior period, unchanged from 0000950170-22-015058:notes:38]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-22-023803:notes:77]
6. STOCK-BASED COMPENSATION

[0000950170-22-023803:notes:78]
For the three months ended September 30, 2022 and 2021, stock-based compensation expense was $12.1 million and $1.8 million, respectively. For the nine months ended September 30, 2022 and 2021, stock-based compensation expense was $15.9 million and $5.5 million, respectively.

[0000950170-22-023803:notes:79]
PSUs, RSUs and Restricted Stock - ADTRAN Holdings, Inc.

[0000950170-22-023803:notes:80]
The following table summarizes the RSUs and restricted stock outstanding as of December 31, 2021 and September 30, 2022 and the changes that occurred during the nine months ended September 30, 2022:

[0000950170-22-023803:notes:81]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2021 |  |  | 1,930 |  |  | $ | 14.11 |  |
| RSUs and restricted stock granted |  |  | 545 |  |  | $ | 19.96 |  |
| RSUs and restricted stock vested |  |  | (20 | ) |  | $ | 13.67 |  |
| RSUs and restricted stock forfeited |  |  | (46 | ) |  | $ | 14.18 |  |
| Unvested RSUs and restricted stock outstanding, September 30, 2022 |  |  | 2,409 |  |  | $ | 17.36 |  |

[0000950170-22-023803:notes:82]
During each of the nine months ended September 30, 2022 and 2021, the Company granted 0.3 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over one-year, two-year and three-year periods, respectively, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements. Pursuant to the Business Combination, the unearned performance-based PSUs converted to time-based RSUs which was treated as an award modification during the third quarter of 2022. This resulted in incremental compensation and unrecognized compensation expense totaling $17.8 million of which $8.9 million was recognized during the three months ended September 30, 2022 and the remainder will be recognized over the remaining service period of 0.3 years. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0000950170-22-023803:notes:83]
Pursuant to the Business Combination, 0.3 million shares of market-based PSU awards converted to time-based RSU's awards which was treated as an award modification during the third quarter of 2022. Given that the fair value of these awards after the modification was less than the fair value of the awards immediately before the modification, no incremental compensation expense was recognized. The Company continued to recognize compensation expense based on the award's original grant date fair value. As of September 30, 2022, there was $2.1 million of unrecognized compensation expense related to these awards which will be recognized over the weighted average remaining service period of 1.1 years.

[0000950170-22-023803:notes:84]
The fair value of RSUs and restricted stock is equal to the closing price of its stock on the date of grant. The fair value of PSUs with market conditions is calculated using a Monte Carlo simulation valuation method.

[0000950170-22-023803:notes:85]
As of September 30, 2022, total unrecognized compensation expense related to non-vested market-based RSUs and restricted stock was approximately $24.6 million, which will be recognized over the remaining weighted-average period of 1.6 years.

[0000950170-22-023803:notes:86]
As of September 30, 2022, 3.4 million shares were available for issuance under stockholder-approved equity plans.

[0000950170-22-023803:notes:87]
Stock Options - ADTRAN Holdings, Inc.

[0000950170-22-023803:notes:88]
The following table summarizes ADTRAN Holdings, Inc. stock options outstanding as of December 31, 2021 and September 30, 2022 and the changes that occurred during the nine months ended September 30, 2022:

[0000950170-22-023803:notes:89]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2021 |  |  | 1,721 |  |  | $ | 19.37 |  |  |  | 2.4 |  |  | $ | 6,669 |  |
| ADVA stock options replaced by ADTRAN Holdings stock options(1) |  |  | 1,980 |  |  | $ | 11.16 |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (439 | ) |  | $ | 16.16 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (12 | ) |  | $ | 11.08 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (70 | ) |  | $ | 26.38 |  |  |  |  |  |  |  |
| Stock options outstanding, September 30, 2022 |  |  | 3,180 |  |  | $ | 14.58 |  |  |  | 3.5 |  |  | $ | 17,839 |  |
| Stock options exercisable, September 30, 2022 |  |  | 1,627 |  |  | $ | 16.85 |  |  |  | 2.0 |  |  | $ | 6,375 |  |

[0000950170-22-023803:notes:90]
(1) Each ADVA stock option surrendered was exchanged for 0.8244 ADTRAN Holdings stock options.

[0000950170-22-023803:notes:91]
As of September 30, 2022, there was $9.0 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 2.7 years.

[0000950170-22-023803:notes:92]
Pursuant to the Business Combination, which closed on July 15, 2022, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings. The maximum number of shares of ADTRAN Holdings stock potentially issuable upon such assumption was 2.1 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.0 million shares of ADTRAN Holdings stock are subject to assumed ADVA options. The determination of the fair value of stock options assumed by ADTRAN Holdings was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors.

[0000950170-22-023803:notes:93]
All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0000950170-22-023803:notes:94]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on September 30, 2022. The amount of aggregate intrinsic value was $17.8 million as of September 30, 2022 and will change based on the fair market value of ADTRAN’s stock. The total pre-tax intrinsic value of options exercised during the nine months ended September 30, 2022 was $3.4 million.

[0000950170-22-023803:notes:95]
Stock Options - ADVA Optical Networking SE

[0000950170-22-023803:notes:96]
The following table summarizes ADVA Optical Networking SE stock options outstanding as of July 15, 2022 (the Business Combination closing date) and September 30, 2022 and the changes that occurred between July 15, 2022 and September 30, 2022:

[0000950170-22-023803:notes:97]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, July 15, 2022 |  |  | 2,745 |  |  | $ | 9.09 |  |  |  | 4.6 |  |  | $ | 27,205 |  |
| Stock options exercised |  |  | (56 | ) |  | $ | 6.79 |  |  |  |  |  |  |  |
| ADVA stock options replaced by ADTRAN Holdings stock options(1) |  |  | (2,403 | ) |  | $ | 9.25 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (4 | ) |  | $ | 7.91 |  |  |  |  |  |  |  |
| Stock options outstanding, September 30, 2022 |  |  | 282 |  |  | $ | 8.45 |  |  |  | 3.9 |  |  | $ | 2,976 |  |
| Stock options exercisable, September 30, 2022 |  |  | 32 |  |  | $ | 7.72 |  |  |  | 1.2 |  |  | $ | 363 |  |

[0000950170-22-023803:notes:98]
As of September 30, 2022, there was $0.3 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 1.1 years.

[0000950170-22-023803:notes:99]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADVA's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on September 30, 2022. The amount of aggregate intrinsic value was $3.0 million as of September 30, 2022 and will change based on the fair market value of ADVA's stock. The total pre-tax intrinsic value of options exercised during the period July 15, 2022 through September 30, 2022 was $0.7 million.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-22-023803:notes:100]
7. INVESTMENTS

[0000950170-22-023803:notes:101]
Debt Securities and Other Investments

[0000950170-22-023803:notes:102]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value:

[0000950170-22-023803:notes:103]
|  |  | As of September 30, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,358 |  |  | $ | — |  |  | $ | (374 | ) |  | $ | 8,984 |  |
| Municipal fixed-rate bonds |  |  | 1,411 |  |  |  | — |  |  |  | (54 | ) |  |  | 1,357 |  |
| Asset-backed bonds |  |  | 2,988 |  |  |  | — |  |  |  | (77 | ) |  |  | 2,911 |  |
| Mortgage/Agency-backed bonds |  |  | 4,720 |  |  |  | — |  |  |  | (280 | ) |  |  | 4,440 |  |
| U.S. government bonds |  |  | 11,231 |  |  |  | — |  |  |  | (642 | ) |  |  | 10,589 |  |
| Foreign government bonds |  |  | 409 |  |  |  | — |  |  |  | (27 | ) |  |  | 382 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,117 |  |  | $ | — |  |  | $ | (1,454 | ) |  | $ | 28,663 |  |

[0000950170-22-023803:notes:104]
|  |  | As of December 31, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,776 |  |  | $ | 6 |  |  | $ | (35 | ) |  | $ | 10,747 |  |
| Municipal fixed-rate bonds |  |  | 1,553 |  |  |  | 2 |  |  |  | (4 | ) |  |  | 1,551 |  |
| Asset-backed bonds |  |  | 322 |  |  |  | 3 |  |  |  | (3 | ) |  |  | 322 |  |
| Mortgage/Agency-backed bonds |  |  | 4,754 |  |  |  | 15 |  |  |  | (33 | ) |  |  | 4,736 |  |
| U.S. government bonds |  |  | 12,251 |  |  |  | 12 |  |  |  | (92 | ) |  |  | 12,171 |  |
| Foreign government bonds |  |  | 543 |  |  |  | — |  |  |  | (4 | ) |  |  | 539 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,199 |  |  | $ | 38 |  |  | $ | (171 | ) |  | $ | 30,066 |  |

[0000950170-22-023803:notes:105]
The contractual maturities related to debt securities and other investments were as follows:

[0000950170-22-023803:notes:106]
|  |  | As of September 30, 2022 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 96 |  |  | $ | 525 |  |  | $ | — |  |  | $ | 182 |  |  | $ | — |  |  | $ | — |  |  |
| One to two years |  |  | 5,371 |  |  |  | 722 |  |  |  | 95 |  |  |  | 464 |  |  |  | 7,421 |  |  |  | 275 |  |  |
| Two to three years |  |  | 3,517 |  |  |  | 110 |  |  |  | 715 |  |  |  | 1,321 |  |  |  | 2,889 |  |  |  | 107 |  |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 1,306 |  |  |  | 166 |  |  |  | 279 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 382 |  |  |  | 810 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 413 |  |  |  | 1,497 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 8,984 |  |  | $ | 1,357 |  |  | $ | 2,911 |  |  | $ | 4,440 |  |  | $ | 10,589 |  |  | $ | 382 |  |  |

[0000950170-22-023803:notes:107]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0000950170-22-023803:notes:108]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to its debt securities:

[0000950170-22-023803:notes:109]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Gross realized gain on debt securities |  | $ | 1 |  |  | $ | 22 |  |  | $ | 14 |  |  | $ | 206 |  |
| Gross realized loss on debt securities |  |  | (116 | ) |  |  | (17 | ) |  |  | (242 | ) |  |  | (53 | ) |
| Total (loss) gain recognized, net |  | $ | (115 | ) |  | $ | 5 |  |  | $ | (228 | ) |  | $ | 153 |  |

[0000950170-22-023803:notes:110]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. No allowance for credit losses was recorded for the nine months ended September 30, 2022 and 2021 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the nine months ended September 30, 2022.

[0000950170-22-023803:notes:111]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0000950170-22-023803:notes:112]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Realized (loss) gain on equity securities sold |  | $ | (1,358 | ) |  | $ | — |  |  | $ | (1,675 | ) |  | $ | (55 | ) |
| Unrealized (loss) gain on equity securities held |  |  | (1,217 | ) |  |  | (68 | ) |  |  | (8,849 | ) |  |  | 2,844 |  |
| Total (loss) gain recognized, net |  | $ | (2,575 | ) |  | $ | (68 | ) |  | $ | (10,524 | ) |  | $ | 2,789 |  |

[0000950170-22-023803:notes:113]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-22-023803:notes:114]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-22-023803:notes:115]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-22-023803:notes:116]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-22-023803:notes:117]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-22-023803:notes:118]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 698 |  |  | $ | 698 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 8,984 |  |  |  | — |  |  |  | 8,984 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,357 |  |  |  | — |  |  |  | 1,357 |  |  |  | — |  |
| Asset-backed bonds |  |  | 2,911 |  |  |  | — |  |  |  | 2,911 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,440 |  |  |  | — |  |  |  | 4,440 |  |  |  | — |  |
| U.S. government bonds |  |  | 10,589 |  |  |  | 10,589 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 382 |  |  |  | — |  |  |  | 382 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 760 |  |  |  | 760 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,511 |  |  |  | 21,511 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 51,632 |  |  | $ | 33,558 |  |  | $ | 18,074 |  |  | $ | — |  |

[0000950170-22-023803:notes:119]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 652 |  |  | $ | 652 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,747 |  |  |  | — |  |  |  | 10,747 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,551 |  |  |  | — |  |  |  | 1,551 |  |  |  | — |  |
| Asset-backed bonds |  |  | 322 |  |  |  | — |  |  |  | 322 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,736 |  |  |  | — |  |  |  | 4,736 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,171 |  |  |  | 12,171 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 539 |  |  |  | — |  |  |  | 539 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 12,606 |  |  |  | 12,606 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,935 |  |  |  | 26,935 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 70,259 |  |  | $ | 52,364 |  |  | $ | 17,895 |  |  | $ | — |  |

[0000950170-22-023803:notes:120]
The fair value of its Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-22-023803:notes:121]
8. INVENTORY

[0000950170-22-023803:notes:122]
[same as prior period, unchanged from 0000950170-22-015058:notes:81]

[0000950170-22-023803:notes:123]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Raw materials |  | $ | 177,554 |  |  | $ | 74,709 |  |
| Work in process |  |  | 10,625 |  |  |  | 2,143 |  |
| Finished goods |  |  | 227,984 |  |  |  | 63,039 |  |
| Total inventory, net |  | $ | 416,163 |  |  | $ | 139,891 |  |

[0000950170-22-023803:notes:124]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which considers historical usage, known trends, inventory age and market conditions. As of September 30, 2022 and December 31, 2021, inventory reserves were $51.3 million and $44.6 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-22-023803:notes:125]
9. PROPERTY, PLANT AND EQUIPMENT

[0000950170-22-023803:notes:126]
[same as prior period, unchanged from 0000950170-22-015058:notes:85]

[0000950170-22-023803:notes:127]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Engineering and other equipment |  | $ | 162,445 |  |  | $ | 134,771 |  |
| Building |  |  | 80,807 |  |  |  | 68,157 |  |
| Computer hardware and software |  |  | 79,990 |  |  |  | 72,274 |  |
| Building and land improvements |  |  | 40,132 |  |  |  | 35,578 |  |
| Furniture and fixtures |  |  | 20,891 |  |  |  | 19,917 |  |
| Land |  |  | 5,298 |  |  |  | 4,575 |  |
| Other assets |  |  | 4,835 |  |  |  | — |  |
| Total property, plant and equipment |  |  | 394,398 |  |  |  | 335,272 |  |
| Less: accumulated depreciation |  |  | (289,821 | ) |  |  | (279,506 | ) |
| Total property, plant and equipment, net |  | $ | 104,577 |  |  | $ | 55,766 |  |

[0000950170-22-023803:notes:128]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result the Company recognized impairment charges of $17.0 million during the three and nine months ended September 30, 2022 related to capitalized implementation costs for a cloud computing arrangement. The impairment charges were determined based on actual costs incurred.

[0000950170-22-023803:notes:129]
Depreciation expense was $7.1 million and $3.0 million for the three months ended September 30, 2022 and 2021, respectively, and $12.6 million and $9.1 million for the nine months ended September 30, 2022 and 2021, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-22-023803:notes:130]
10. GOODWILL

[0000950170-22-023803:notes:131]
The changes in the carrying amount of goodwill for the nine months ended September 30, 2022 are as follows:

[0000950170-22-023803:notes:132]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2021 |  | $ | 6,568 |  |  | $ | 400 |  |  | $ | 6,968 |  |
| Goodwill from Business Combination with ADVA |  |  | 270,568 |  |  |  | 88,589 |  |  |  | 359,157 |  |
| Foreign currency translation adjustments |  |  | (6,220 | ) |  |  | (2,036 | ) |  |  | (8,256 | ) |
| As of September 30, 2022 |  | $ | 270,916 |  |  | $ | 86,953 |  |  | $ | 357,869 |  |

[0000950170-22-023803:notes:133]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We qualitatively assess the carrying value of goodwill each reporting period for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Based on its assessment of certain qualitative factors such as macro-economic conditions, industry and market considerations, costs factors and overall financial performance, management concluded that no such events or circumstance changes were identified that would suggest that the fair value of the goodwill was more likely than not greater than its carrying amount as of September 30, 2022. No impairment of goodwill was recorded during the three and nine months ended September 30, 2022 and 2021.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-22-023803:notes:134]
11. INTANGIBLE ASSETS

[0000950170-22-023803:notes:135]
[same as prior period, unchanged from 0000950170-22-015058:notes:93]

[0000950170-22-023803:notes:136]
|  |  |  |  | As of September 30, 2022 |  |  | As of December 31, 2021 |  |
| (In thousands) | Weighted Average Useful Life(in years) |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | 10.9 |  |  | $ | 52,139 |  |  | $ | (11,207 | ) |  | $ | 40,932 |  |  | $ | 20,796 |  |  | $ | (9,906 | ) |  | $ | 10,890 |  |
| Backlog |  | 1.4 |  |  |  | 50,966 |  |  |  | (9,325 | ) |  |  | 41,641 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Developed technology |  | 8.5 |  |  |  | 294,983 |  |  |  | (11,565 | ) |  |  | 283,418 |  |  |  | 8,200 |  |  |  | (3,683 | ) |  |  | 4,517 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (2,977 | ) |  |  | 2,923 |  |  |  | 5,900 |  |  |  | (2,486 | ) |  |  | 3,414 |  |
| Licensing agreements |  | 8.5 |  |  |  | 560 |  |  |  | (280 | ) |  |  | 280 |  |  |  | 560 |  |  |  | (225 | ) |  |  | 335 |  |
| Patents |  | 7.3 |  |  |  | 500 |  |  |  | (414 | ) |  |  | 86 |  |  |  | 500 |  |  |  | (363 | ) |  |  | 137 |  |
| Trade names |  | 2.8 |  |  |  | 26,575 |  |  |  | (2,280 | ) |  |  | 24,295 |  |  |  | 210 |  |  |  | (210 | ) |  |  | — |  |
| Total |  |  |  | $ | 431,623 |  |  | $ | (38,048 | ) |  | $ | 393,575 |  |  | $ | 36,166 |  |  | $ | (16,873 | ) |  | $ | 19,293 |  |

[0000950170-22-023803:notes:137]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to intangible assets during each financial period in 2022 and 2021. As a result, no quantitative impairment test of long-lived assets was performed as of September 30, 2022 and 2021, and no impairment losses of intangible assets were recorded during the three and nine months ended September 30, 2022 and 2021.

[0000950170-22-023803:notes:138]
Amortization expense was $20.4 million and $1.0 million in the three months ended September 30, 2022 and 2021, respectively, and $22.2 million and $3.1 million in the nine months ended September 30, 2022 and 2021, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.

[0000950170-22-023803:notes:139]
[same as prior period, unchanged from 0000950170-22-015058:notes:97]

[0000950170-22-023803:notes:140]
|  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |
| 2022 |  | $ | 23,691 |  |
| 2023 |  |  | 75,677 |  |
| 2024 |  |  | 53,021 |  |
| 2025 |  |  | 42,623 |  |
| 2026 |  |  | 39,505 |  |
| Thereafter |  |  | 159,058 |  |
| Total |  | $ | 393,575 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000950170-22-023803:notes:141]
12. LEASES

[0000950170-22-023803:notes:142]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain potential embedded leases. These other contracts are specifically reviewed to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease.

[0000950170-22-023803:notes:143]
As of September 30, 2022, our operating leases had remaining lease terms ranging from one month to seventy-eight months, some of which included options to extend the leases for up to five years, and some of which included options to terminate the leases within three months. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. Supplemental balance sheet information related to operating leases is as follows:

[0000950170-22-023803:notes:144]
| (In thousands) |  | Classification |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Assets |  |  |  |  |  |  |  |  |
| Operating lease asset |  | Other assets |  | $ | 28,081 |  |  | $ | 4,922 |  |
| Total lease asset |  |  |  | $ | 28,081 |  |  | $ | 4,922 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses |  | $ | 6,604 |  |  | $ | 1,730 |  |
| Non-current operating lease liability |  | Non-current lease obligations |  |  | 21,490 |  |  |  | 3,269 |  |
| Total lease liability |  |  |  | $ | 28,094 |  |  | $ | 4,999 |  |

[0000950170-22-023803:notes:145]
Leases with an initial term of 12 months or less are not recorded on the balance sheet and the lease expense for these leases is recognized on a straight-line basis over the lease term. Lease expense related to these short-term leases was less than $0.1 million for the three and nine months ended September 30, 2022 and 2021, and is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss. Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.2 million and $0.1 million for the three months ended September 30, 2022 and 2021, respectively, and $0.5 million and $0.4 million for the nine months ended September 30, 2022 and 2021, respectively. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. Our lease agreements do not contain any material residual value guarantees.

[0000950170-22-023803:notes:146]
The components of lease expense included in the Condensed Consolidated Statements of Loss were as follows:

[0000950170-22-023803:notes:147]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Selling, general and administrative expenses |  | $ | 1,444 |  |  | $ | 196 |  |  | $ | 1,704 |  |  | $ | 645 |  |
| Research and development expenses |  |  | 228 |  |  |  | 261 |  |  |  | 719 |  |  |  | 815 |  |
| Cost of sales |  |  | 20 |  |  |  | 14 |  |  |  | 59 |  |  |  | 38 |  |
| Total operating lease expense |  | $ | 1,692 |  |  | $ | 471 |  |  | $ | 2,482 |  |  | $ | 1,498 |  |

[0000950170-22-023803:notes:148]
As of September 30, 2022 and December 31, 2021, operating lease liabilities included on the Condensed Consolidated Balance Sheets by future maturity were as follows:

[0000950170-22-023803:notes:149]
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| 2022 |  | $ | 2,209 |  |  | $ | 1,767 |  |
| 2023 |  |  | 8,421 |  |  |  | 1,419 |  |
| 2024 |  |  | 7,098 |  |  |  | 1,188 |  |
| 2025 |  |  | 5,838 |  |  |  | 710 |  |
| 2026 |  |  | 3,354 |  |  |  | — |  |
| Thereafter |  |  | 5,107 |  |  |  | — |  |
| Total lease payments |  |  | 32,027 |  |  |  | 5,084 |  |
| Less: Interest |  |  | (3,933 | ) |  |  | (85 | ) |
| Present value of lease liabilities |  | $ | 28,094 |  |  | $ | 4,999 |  |

[0000950170-22-023803:notes:150]
Future operating lease payments include $4.5 million related to options to extend lease terms that are reasonably certain of being exercised. There are material legally binding leases that have not yet commenced.

[0000950170-22-023803:notes:151]
An incremental borrowing rate is used based on information available at the commencement date in determining the present value of lease payments. The incremental borrowing rate is determined on a portfolio basis by grouping leases with similar terms, as well as grouping leases based on a U.S. dollar or Euro functional currency. The following table provides information about our weighted average lease terms and weighted average discount rates:

[0000950170-22-023803:notes:152]
|  |  | As of September 30, 2022 |  |
| Weighted average remaining lease term (in years) |  |  |  |
| Operating leases with USD functional currency |  |  | 1.6 |  |
| Operating leases with Euro functional currency |  |  | 4.5 |  |
| Weighted average discount rate |  |  |  |
| Operating leases with USD functional currency |  |  | 3.93 | % |
| Operating leases with Euro functional currency |  |  | 4.05 | % |

[0000950170-22-023803:notes:153]
For the nine months ended September 30, 2022 and 2021, the Company used $2.3 million and $1.4 million of cash in operating activities related to operating leases, respectively.

[0000950170-22-023803:notes:154]
[same as prior period, unchanged from 0000950170-22-015058:notes:100]

[0000950170-22-023803:notes:155]
[same as prior period, unchanged from 0000950170-22-015058:notes:101]

[0000950170-22-023803:notes:156]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Current minimum lease payments receivable(1) |  | $ | 11 |  |  | $ | 92 |  |
| Non-current minimum lease payments receivable(2) |  |  | — |  |  |  | 4 |  |
| Total minimum lease payments receivable |  |  | 11 |  |  |  | 96 |  |
| Less: Current unearned revenue(1) |  |  | 5 |  |  |  | 70 |  |
| Less: Non-current unearned revenue(2) |  |  | — |  |  |  | 1 |  |
| Net investment in sales-type leases |  | $ | 6 |  |  | $ | 25 |  |

[0000950170-22-023803:notes:157]
[same as prior period, unchanged from 0000950170-22-015058:notes:103]

[0000950170-22-023803:notes:158]
[same as prior period, unchanged from 0000950170-22-015058:notes:104]


## us-gaap:DebtDisclosureTextBlock

[0000950170-22-023803:notes:159]
13. REVOLVING CREDIT AGREEMENTS

[0000950170-22-023803:notes:160]
The carrying amounts of the Company's revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-22-023803:notes:161]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Wells Fargo credit agreement |  | $ | 60,000 |  |  | $ | — |  |
| Nord/LB revolving line of credit |  |  | 14,702 |  |  |  | — |  |
| Syndicated credit agreement working capital line of credit |  |  | 9,801 |  |  |  | — |  |
| Wells Fargo revolving credit agreement |  |  | — |  |  |  | — |  |
| Cadence revolving credit agreement |  |  | — |  |  |  | — |  |
| Total revolving credit agreements |  | $ | 84,503 |  |  | $ | — |  |

[0000950170-22-023803:notes:162]
As of September 30, 2022, the weighted average interest rate on our revolving credit agreements was 4.05%

[0000950170-22-023803:notes:163]
Wells Fargo Credit Agreement

[0000950170-22-023803:notes:164]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allows for borrowings of up to $100 million in aggregate principal amount, subject to being increased to up to $400 million in aggregate principal amount upon the Company or Borrower’s execution of a DPLTA with ADVA or a parent of ADVA, among other conditions (the “Senior Credit Facilities Increase”). On October 18, 2022, the Board of Directors of the Company. and the management board of ADVA, agreed on a final draft of a DPLTA between the Company, as the controlling company, and ADVA, as the controlled company. See Note 21 of the Notes to Condensed Consolidated Financial Statements for further information.

[0000950170-22-023803:notes:165]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

[0000950170-22-023803:notes:166]
As of September 30, 2022, ADTRAN, Inc.’s borrowings under the revolving line of credit were $60.0 million in tranches that mature during the fourth quarter of 2022 and can either be repaid or borrowed again for a one month, three month or six month period. In addition, we may issue up to $25 million in letters of credit against our $100 million dollar total facility. As of September 30, 2022, we had a total of $16.0 million in letters of credit with ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $24.0 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-22-023803:notes:167]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-22-023803:notes:168]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participations in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-22-023803:notes:169]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the consolidated total net leverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the consolidated interest coverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of September 30, 2022, the Company was in compliance with all material covenants. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions.

[0000950170-22-023803:notes:170]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

[0000950170-22-023803:notes:171]
Nord/LB Revolving Line of Credit

[0000950170-22-023803:notes:172]
August 8, 2022, ADVA entered into a $14.7 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate + 1.4% and which matures in August 2023. During the term of the loan, ADVA is obligated to maintain an adjusted net debt to cover ratio that is equal to or less than 2.75. As of September 30, 2022, The Company was in compliance with the adjusted net debt to cover ratio. The revolving line of credit grants Nord/LB a lien on assets of any kind which come into the possession of ADVA. Assets of any kind includes goods, foreign exchange, securities including interest, annuity and

[0000950170-22-023803:notes:173]
profit notes, collective securities deposits, subscription rights, checks, bills of exchange, bills of lading, storage and loading slips. As of September 30, 2022, ADVA’s borrowings under the revolving line of credit were $14.7 million, with no amounts available for future borrowings.

[0000950170-22-023803:notes:174]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-22-023803:notes:175]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $9.8 million as part of a working capital line of credit. The interest rate for the working capital line of credit is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of September 30, 2022. The working capital line of credit matures in September 2023. As of September 30, 2022, borrowings under the working capital line of credit totaled $9.8 million, with no amounts available for future borrowings.

[0000950170-22-023803:notes:176]
Prior Wells Fargo Revolving Credit Agreement

[0000950170-22-023803:notes:177]
On April 1, 2022, ADTRAN, Inc. entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Prior Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provided the Company with a $25.0 million secured revolving credit facility. During the first nine months of 2022, the Company made draws totaling $10.0 million under the Prior Wells Revolving Credit Agreement all of which had been repaid as of September 30, 2022. The Wells Fargo Credit Agreement replaced the Prior Wells Fargo Revolving Credit Agreement and all outstanding borrowings have been repaid and the prior agreement was terminated.

[0000950170-22-023803:notes:178]
Prior Cadence Revolving Credit Agreement

[0000950170-22-023803:notes:179]
On May 19, 2022, ADTRAN, Inc., as borrower, modified its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The modified Prior Cadence Revolving Credit Agreement provided the Company with a $25.0 million secured revolving credit facility. During the first nine months of 2022, the Company made draws totaling $18.0 million under the Prior Cadence Revolving Credit Agreement all of which had been repaid as of September 30, 2022. The Wells Fargo Credit Agreement replaced the Prior Cadence Revolving Credit Agreement and all outstanding borrowings have been repaid and the prior agreement was terminated.


## adtn:NotesPayableDisclosureTextBlock

[0000950170-22-023803:notes:180]
14. NOTES PAYABLE

[0000950170-22-023803:notes:181]
The carrying amounts of the Company's notes payable in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-22-023803:notes:182]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | September 30, 2022 |  |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Syndicated credit agreement note payable |  | $ | 29,611 |  |  | $ | 29,782 |  |  | $ | — |  |
| Deutsche Bank term loan |  |  | — |  |  |  | — |  |  |  | — |  |
| Total Notes Payable |  | $ | 29,611 |  |  | $ | 29,782 |  |  | $ | — |  |

[0000950170-22-023803:notes:183]
Syndicated Credit Agreement Note Payable

[0000950170-22-023803:notes:184]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. The interest rate for the note payable is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of September 30, 2022. The note payable matures in September 2023.

[0000950170-22-023803:notes:185]
Deutsche Bank Term Loan

[0000950170-22-023803:notes:186]
In October 2019, ADVA entered into a $9.8 million revolving line of credit with Deutsche Bank that bears interest of EURIBOR plus 1.1%. The line of credit matured in September 2022 and was repaid as of September 30, 2022.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-22-023803:notes:187]
15. EMPLOYEE BENEFIT PLANS

[0000950170-22-023803:notes:188]
We maintain defined benefit pension plans covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by its actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. The Company's net pension liability totaled $16.2 million and $11.4 million as of September 30, 2022 and December 31, 2021, respectively.

[0000950170-22-023803:notes:189]
The following table summarizes the components of net periodic pension cost related to a defined benefit pension plan covering employees in certain foreign countries:

[0000950170-22-023803:notes:190]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Service cost |  | $ | 478 |  |  | $ | 307 |  |  | $ | 981 |  |  | $ | 931 |  |
| Interest cost |  |  | 204 |  |  |  | 84 |  |  |  | 638 |  |  |  | 257 |  |
| Expected return on plan assets |  |  | (465 | ) |  |  | (460 | ) |  |  | (1,384 | ) |  |  | (1,396 | ) |
| Amortization of actuarial losses |  |  | 81 |  |  |  | 272 |  |  |  | 254 |  |  |  | 825 |  |
| Net periodic pension cost |  | $ | 298 |  |  | $ | 203 |  |  | $ | 489 |  |  | $ | 617 |  |

[0000950170-22-023803:notes:191]
The components of net periodic pension cost, other than the service cost component, are included in other income, net in the Condensed Consolidated Statements of Loss. Service cost is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss. The Company made contributions to the defined benefit pension plans totaling $1.2 million during the nine months ending September 30, 2022. Contributions to the defined benefit pension plans for the remainder of 2022 will be limited to benefit payments to retirees which are paid out of the operating cash flows of the Company and are expected to be approximately $0.6 million.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-22-023803:notes:192]
16. EQUITY

[0000950170-22-023803:notes:193]
Non-Controlling Interest

[0000950170-22-023803:notes:194]
Non-controlling interest represents the equity interest in ADVA held by holders other than the Company. On July 15, 2022, upon the closing of the Business Combination, the ADVA stockholders’ equity ownership percentage in ADVA was 34.57%. The Company has consolidated the financial position and results of operations of ADVA and reflected the proportionate interest held by the ADVA stockholders as non-controlling interest in the accompanying Condensed Consolidated Balance Sheet. As of September 30, 2022, the ADVA stockholders’ equity ownership percentage in ADVA was 34.65%.

[0000950170-22-023803:notes:195]
[same as prior period, unchanged from 0000950170-22-015058:notes:111]

[0000950170-22-023803:notes:196]
During the nine months ended September 30, 2022, the Company did not repurchase any shares of Company Common Stock and there is no current authorization to repurchase Company Common Stock.

[0000950170-22-023803:notes:197]
[same as prior period, unchanged from 0000950170-22-015058:notes:113]

[0000950170-22-023803:notes:198]
[same as prior period, unchanged from 0000950170-22-015058:notes:114]

[0000950170-22-023803:notes:199]
|  |  | Three Months Ended September 30, 2022 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of June 30, 2022 |  | $ | (1,476 | ) |  | $ | (5,713 | ) |  | $ | (9,892 | ) |  | $ | 385 |  |  | $ | (16,696 | ) |
| Other comprehensive loss before reclassifications |  |  | (254 | ) |  |  | — |  |  |  | (23,172 | ) |  |  | — |  |  |  | (23,426 | ) |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (142 | ) |  |  | (118 | ) |  |  | — |  |  |  | — |  |  |  | (260 | ) |
| Net current period other comprehensive (loss) income |  |  | (396 | ) |  |  | (118 | ) |  |  | (23,172 | ) |  |  | — |  |  |  | (23,686 | ) |
| Less: Comprehensive Loss attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | (94 | ) |  |  | — |  |  |  | (94 | ) |
| Balance as of September 30, 2022 |  | $ | (1,872 | ) |  | $ | (5,831 | ) |  | $ | (32,970 | ) |  | $ | 385 |  |  | $ | (40,288 | ) |

[0000950170-22-023803:notes:200]
|  |  | Three Months Ended September 30, 2021 |  |
| (In thousands) |  | UnrealizedGains(Losses)onAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of June 30, 2021 |  | $ | (255 | ) |  | $ | (9,310 | ) |  | $ | (3,960 | ) |  | $ | 385 |  |  | $ | (13,140 | ) |
| Other comprehensive loss before reclassifications |  |  | (29 | ) |  |  | — |  |  |  | (1,389 | ) |  |  | — |  |  |  | (1,418 | ) |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (32 | ) |  |  | 124 |  |  |  | — |  |  |  | — |  |  |  | 92 |  |
| Net current period other comprehensive (loss) income |  |  | (61 | ) |  |  | 124 |  |  |  | (1,389 | ) |  |  | — |  |  |  | (1,326 | ) |
| Balance as of September 30, 2021 |  | $ | (316 | ) |  | $ | (9,186 | ) |  | $ | (5,349 | ) |  | $ | 385 |  |  | $ | (14,466 | ) |

[0000950170-22-023803:notes:201]
|  |  | Nine Months Ended September 30, 2022 |  |
| (In thousands) |  | UnrealizedGains (Losses)onAvailable-for-SaleSecurities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2021 |  | $ | (552 | ) |  | $ | (5,613 | ) |  | $ | (6,134 | ) |  | $ | 385 |  |  | $ | (11,914 | ) |
| Other comprehensive loss before reclassifications |  |  | (1,818 | ) |  |  | — |  |  |  | (26,930 | ) |  |  | — |  |  |  | (28,748 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 498 |  |  |  | (218 | ) |  |  | — |  |  |  | — |  |  |  | 280 |  |
| Net current period other comprehensive loss |  |  | (1,320 | ) |  |  | (218 | ) |  |  | (26,930 | ) |  |  | — |  |  |  | (28,468 | ) |
| Less: Comprehensive Loss attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | (94 | ) |  |  | — |  |  |  | (94 | ) |
| As of September 30, 2022 |  | $ | (1,872 | ) |  | $ | (5,831 | ) |  | $ | (32,970 | ) |  | $ | 385 |  |  | $ | (40,288 | ) |

[0000950170-22-023803:notes:202]
|  |  | Nine Months Ended September 30, 2021 |  |
| (In thousands) |  | UnrealizedGains (Losses) on Available-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2020 |  | $ | 32 |  |  | $ | (9,621 | ) |  | $ | (2,435 | ) |  | $ | 385 |  |  | $ | (11,639 | ) |
| Other comprehensive loss before reclassifications |  |  | (358 | ) |  |  | — |  |  |  | (2,914 | ) |  |  | — |  |  |  | (3,272 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | 10 |  |  |  | 435 |  |  |  | — |  |  |  | — |  |  |  | 445 |  |
| Net current period other comprehensive (loss) income |  |  | (348 | ) |  |  | 435 |  |  |  | (2,914 | ) |  |  | — |  |  |  | (2,827 | ) |
| As of September 30, 2021 |  | $ | (316 | ) |  | $ | (9,186 | ) |  | $ | (5,349 | ) |  | $ | 385 |  |  | $ | (14,466 | ) |

[0000950170-22-023803:notes:203]
[same as prior period, unchanged from 0000950170-22-015058:notes:119]

[0000950170-22-023803:notes:204]
|  |  | Three Months Ended September 30, 2022 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in theStatement Where Net(Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | 187 |  |  | Net investment (loss) gain |
| Defined benefit plan adjustments – actuarial loss |  |  | 171 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | 358 |  |  |  |
| Tax benefit |  |  | (98 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 260 |  |  |  |

[0000950170-22-023803:notes:205]
(1)
A part of the computation of net periodic pension cost, which is included in other income, net in the Condensed Consolidated Statements of Loss.

[0000950170-22-023803:notes:206]
|  |  | Three Months Ended September 30, 2021 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where Net (Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | 42 |  |  | Net investment (loss) gain |
| Defined benefit plan adjustments – actuarial gain |  |  | (180 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (138 | ) |  |  |
| Tax expense |  |  | 46 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (92 | ) |  |  |

[0000950170-22-023803:notes:207]
|  |  | Nine Months Ended September 30, 2022 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where Net (Loss)Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | (655 | ) |  | Net investment (loss) gain |
| Defined benefit plan adjustments – actuarial loss |  |  | 316 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (339 | ) |  |  |
| Tax expense |  |  | 59 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (280 | ) |  |  |

[0000950170-22-023803:notes:208]
|  |  | Nine Months Ended September 30, 2021 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where Net (Loss)Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | (13 | ) |  | Net investment (loss) gain |
| Defined benefit plan adjustments – actuarial gain |  |  | (630 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (643 | ) |  |  |
| Tax expense |  |  | 198 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (445 | ) |  |  |

[0000950170-22-023803:notes:209]
The following tables present the tax effects related to the change in each component of other comprehensive loss:

[0000950170-22-023803:notes:210]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized loss on available-for-sale securities |  | $ | (334 | ) |  | $ | 80 |  |  | $ | (254 | ) |  | $ | (38 | ) |  | $ | 9 |  |  | $ | (29 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net loss |  |  | (187 | ) |  |  | 45 |  |  |  | (142 | ) |  |  | (42 | ) |  |  | 10 |  |  |  | (32 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) gain |  |  | (171 | ) |  |  | 53 |  |  |  | (118 | ) |  |  | 180 |  |  |  | (56 | ) |  |  | 124 |  |
| Foreign currency translation adjustments |  |  | (23,172 | ) |  |  | — |  |  |  | (23,172 | ) |  |  | (1,389 | ) |  |  | — |  |  |  | (1,389 | ) |
| Total Other Comprehensive Loss |  | $ | (23,864 | ) |  | $ | 178 |  |  | $ | (23,686 | ) |  | $ | (1,289 | ) |  | $ | (37 | ) |  | $ | (1,326 | ) |

[0000950170-22-023803:notes:211]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized loss on available-for-sale securities |  | $ | (2,392 | ) |  | $ | 574 |  |  | $ | (1,818 | ) |  | $ | (471 | ) |  | $ | 113 |  |  | $ | (358 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net gain |  |  | 655 |  |  |  | (157 | ) |  |  | 498 |  |  |  | 13 |  |  |  | (3 | ) |  |  | 10 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) gain |  |  | (316 | ) |  |  | 98 |  |  |  | (218 | ) |  |  | 630 |  |  |  | (195 | ) |  |  | 435 |  |
| Foreign currency translation adjustments |  |  | (26,930 | ) |  |  | — |  |  |  | (26,930 | ) |  |  | (2,914 | ) |  |  | — |  |  |  | (2,914 | ) |
| Total Other Comprehensive Loss |  | $ | (28,983 | ) |  | $ | 515 |  |  | $ | (28,468 | ) |  | $ | (2,742 | ) |  | $ | (85 | ) |  | $ | (2,827 | ) |


## us-gaap:EarningsPerShareTextBlock

[0000950170-22-023803:notes:212]
17. LOSS PER SHARE

[0000950170-22-023803:notes:213]
The calculation of basic and diluted loss per share is as follows:

[0000950170-22-023803:notes:214]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss attributable to ADTRAN Holdings, Inc. |  | $ | (41,934 | ) |  | $ | (10,427 | ) |  | $ | (40,918 | ) |  | $ | (4,445 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 73,036 |  |  |  | 48,609 |  |  |  | 57,175 |  |  |  | 48,470 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 73,036 |  |  |  | 48,609 |  |  |  | 57,175 |  |  |  | 48,470 |  |
| Loss per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.57 | ) |  | $ | (0.21 | ) |  | $ | (0.72 | ) |  | $ | (0.09 | ) |
| Loss per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.57 | ) |  | $ | (0.21 | ) |  | $ | (0.72 | ) |  | $ | (0.09 | ) |

[0000950170-22-023803:notes:215]
For the three months ended September 30, 2022 and 2021, four thousand and less than one thousand shares, respectively, and for the nine months ended September 30, 2022 and 2021, four thousand shares of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0000950170-22-023803:notes:216]
For the three months ended September 30, 2022 and 2021, 0.1 million and 0.2 million stock options, respectively, and for the nine months ended September 30, 2022 and 2021, 0.2 million and 0.4 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the applicable period, making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-22-023803:notes:217]
18. SEGMENT INFORMATION

[0000950170-22-023803:notes:218]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support.

[0000950170-22-023803:notes:219]
The Network Solutions segment includes hardware and software products that enable a digital future. The Company's cloud-managed Wi-Fi gateways, virtualization software, and switches provide a mix of wired and wireless connectivity at the customer premises. In addition, its Carrier Ethernet products support a variety of applications at the network edge ranging from mobile backhaul to connecting enterprise customers (“Subscriber Solutions"). The Company's portfolio includes products for multi-gigabit service delivery over fiber or alternative media to homes and businesses. The Company supports traditional chassis-based network solutions, such as the Total Access 5000 and hiX 5600. The Company accelerates the industry’s transition to open, disaggregated fiber access solutions with our SDX Series. Data is aggregated via its XG400 product family and synchronized by its Oscilloquartz offerings (“Access and Aggregation Solutions”). All resulting traffic requires transport through fiber-based networks as supported by its FSP 3000 and MicroMux product families while the underlying infrastructure is monitored by its ALM product offering (“Optical Networking Solutions”). The Company's customers can use its Mosaic and Ensemble software suites to manage and orchestrate its complete portfolio of subscriber solutions, access and aggregation solutions and optical networking solutions. The Mosaic and Ensemble software suites includes a mix of orchestration and management solutions that simplify the deployment and virtualization of next generation fiber networks.

[0000950170-22-023803:notes:220]
The Services & Support segment offers a comprehensive portfolio of network design, implementation, maintenance and cloud-hosted services supporting its Subscriber, Access and Aggregation, and Optical Networking Solutions. These services assist operators in the deployment of multi-vendor networks while reducing their cost to maintain these networks. The cloud-hosted services include a suite of SaaS applications under its Mosaic One platform that manages end-to-end network and service optimization for both fiber access infrastructure and mesh Wi-Fi connectivity. We back these services with a global support organization that offers on-site and off-site support services with varying SLAs. By pairing the Company's network solutions with its global services and support organization, customers can turn to the Company as their single turnkey partner to assist with the deployment and maintenance of modern fiber-based networks to connect homes, businesses and datacenters with the metro or network core.

[0000950170-22-023803:notes:221]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment (loss) gain, other income, net and income tax benefit (expense) are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-22-023803:notes:222]
The following tables present information about the revenue and gross profit of its reportable segments:

[0000950170-22-023803:notes:223]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 304,940 |  |  | $ | 82,334 |  |  | $ | 120,767 |  |  | $ | 39,738 |  |
| Services & Support |  |  | 35,769 |  |  |  | 20,693 |  |  |  | 17,314 |  |  |  | 7,935 |  |
| Total |  | $ | 340,709 |  |  | $ | 103,027 |  |  | $ | 138,081 |  |  | $ | 47,673 |  |

[0000950170-22-023803:notes:224]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 599,306 |  |  | $ | 186,126 |  |  | $ | 360,025 |  |  | $ | 143,981 |  |
| Services & Support |  |  | 67,959 |  |  |  | 33,723 |  |  |  | 48,821 |  |  |  | 19,961 |  |
| Total |  | $ | 667,265 |  |  | $ | 219,849 |  |  | $ | 408,846 |  |  | $ | 163,942 |  |

[0000950170-22-023803:notes:225]
In addition to its reportable segments, revenue is also reported for the following three categories – Subscriber Solutions, Access & Aggregation Solutions, and Optical Networking Solutions.

[0000950170-22-023803:notes:226]
[same as prior period, unchanged from 0000950170-22-015058:notes:139]

[0000950170-22-023803:notes:227]
[same as prior period, unchanged from 0000950170-22-015058:notes:140]

[0000950170-22-023803:notes:228]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| United States |  | $ | 169,669 |  |  | $ | 91,868 |  |  | $ | 374,470 |  |  | $ | 273,009 |  |
| United Kingdom |  |  | 64,234 |  |  |  | 12,504 |  |  |  | 123,477 |  |  |  | 34,006 |  |
| Germany |  |  | 46,569 |  |  |  | 17,782 |  |  |  | 71,945 |  |  |  | 50,737 |  |
| Other international |  |  | 60,237 |  |  |  | 15,927 |  |  |  | 97,373 |  |  |  | 51,094 |  |
| Total |  | $ | 340,709 |  |  | $ | 138,081 |  |  | $ | 667,265 |  |  | $ | 408,846 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-22-023803:notes:229]
19. LIABILITY FOR WARRANTY RETURNS

[0000950170-22-023803:notes:230]
The Company's products generally include warranties of 90 days to five years for product defects. The Company accrues for warranty returns at the time of product shipment based on its historical return rate and estimate of the cost to repair or replace the defective products. The Company engages in extensive product quality programs and processes, including actively monitoring and evaluating the quality of its component suppliers. The increasing complexity of the Company's products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should the Company's actual experience relative to these factors be worse than its estimates, the Company will be required to record additional warranty expense. The liability for warranty obligations totaled $8.6 million and $5.4 million as of September 30, 2022 and December 31, 2021, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. During the three months ended September 30, 2021, the Company had a net reversal of prior provisions related to warranty expirations the impact of which is reflected in the table below. The warranty expense and write-off activity for the three and nine months ended September 30, 2022 and 2021 are summarized as follows:

[0000950170-22-023803:notes:231]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 4,842 |  |  | $ | 5,997 |  |  | $ | 5,403 |  |  | $ | 7,146 |  |
| Plus: ADVA acquisition |  |  | 3,756 |  |  |  | — |  |  |  | 3,756 |  |  |  | — |  |
| Plus: Amounts charged to cost and expenses |  |  | 616 |  |  |  | 472 |  |  |  | 1,727 |  |  |  | 253 |  |
| Less: Deductions |  |  | (613 | ) |  |  | (822 | ) |  |  | (2,285 | ) |  |  | (1,752 | ) |
| Balance at end of period |  | $ | 8,601 |  |  | $ | 5,647 |  |  | $ | 8,601 |  |  | $ | 5,647 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-22-023803:notes:232]
20. COMMITMENTS AND CONTINGENCIES

[0000950170-22-023803:notes:233]
Legal Maters

[0000950170-22-023803:notes:234]
From time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

[0000950170-22-023803:notes:235]
Performance Bonds

[0000950170-22-023803:notes:236]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2022 and December 31, 2021, we had commitments related to these bonds totaling $21.1 million and $22.9 million, respectively, which expire at various dates through April 2025. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-22-023803:notes:237]
Purchase Commitments

[0000950170-22-023803:notes:238]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2022, purchase commitments totaled $454.1 million.

[0000950170-22-023803:notes:239]
Investment Commitment

[0000950170-22-023803:notes:240]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of September 30, 2022.


## us-gaap:SubsequentEventsTextBlock

[0000950170-22-023803:notes:241]
21. SUBSEQUENT EVENTS

[0000950170-22-023803:notes:242]
Dividend Approval

[0000950170-22-023803:notes:243]
On November 7, 2022, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 22, 2022. The payment date will be December 6, 2022 in the aggregate amount of approximately $7.0 million.

[0000950170-22-023803:notes:244]
Assumed ADVA Options

[0000950170-22-023803:notes:245]
Pursuant to the Business Combination which closed on July 15, 2022, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings, Inc. The period in which such options could be assumed ended July 22, 2022. However, that period was subsequently extended and a total of 0.1 million shares of ADTRAN Holdings, Inc. stock are subject to additional assumed ADVA options. The fair value of the stock options assumed by ADTRAN Holdings, Inc. will be estimated using a Black-Scholes model. The valuation of this component of consideration is not yet complete.

[0000950170-22-023803:notes:246]
Approval of Proposed Domination and Profit and Loss Transfer Agreement

[0000950170-22-023803:notes:247]
On October 18, 2022, the Board of Directors of the Company and the management board of ADVA, agreed on a final draft of a domination and profit and loss transfer agreement (the “DPLTA”) between the Company, as the controlling company, and ADVA, as the controlled company. The parties’ execution of the DPLTA remains subject to the approval of the DPLTA by shareholders of ADVA with 75% of the votes cast in an extraordinary general meeting, which is scheduled to be held on November 30, 2022. The Company currently holds 33,957,538 shares of ADVA, representing 65.35% of ADVA’s outstanding shares as of September 30, 2022.

[0000950170-22-023803:notes:248]
Subject to the approval of the DPLTA shareholders and the subsequent registration of the DPLTA with the commercial register of the local court at ADVA’s registered offices, the Company will offer, at the election of each shareholder of ADVA (other than the Company), (i) to acquire the shares of such shareholder for a compensation (Abfindung) of EUR 17.21 per share pursuant to Sec. 305 German Stock Corporation Akt (Aktiengesetz, “AktG”), or (ii) to pay such shareholder a fixed annual recurring compensation payment (Ausgleichszahlung) pursuant to Sec. 304 AktG in an amount of EUR 0.59 (EUR 0.52 net under the current taxation regime), subject to adjustment prior to execution of the DPLTA due to changes in interest rates and borrowing costs prior to November 30, 2022, which is the reference date for the valuation of ADVA shares ("Annual Recurring Compensation").

[0000950170-22-023803:notes:249]
The amount of the Annual Recurring Compensation payment of EUR 0.59 (EUR 0.52 net) is determined on the basis of a rounded annuity interest rate (Verrentungszinssatz) of 3.00% and still subject to an adjustment in case of a change of interest rates and borrowing costs prior to November 30, 2022 which is the reference date for the valuation. An increase of borrowing costs could lead to an increase of the Annual Recurring Compensation payment. The potential increase ranges from EUR 0.62 (EUR 0.54 net), if the annuity interest rate is increased by 25 basis points to 3.25%, up to an Annual Recurring Compensation payment at the amount of EUR 1.00 (EUR 0.87 net), if the annuity interest rate is increased by 250 basis points to 5.50%.

[0000950170-22-023803:notes:250]
Board Approval Purchase of ADVA Common Stock

[0000950170-22-023803:notes:251]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of ADVA through open market purchases not to exceed 15,346,544 shares.

[0000950170-22-023803:notes:252]
Foreign Currency Hedging Agreement

[0000950170-22-023803:notes:253]
On November 3, 2022, the Company entered into a Euro/U.S. dollar cross-currency swap arrangement (the “Swap”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Swap, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its Euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Swap, the Company will exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of $160.0 million will be divided into eight quarterly tranches of $20.0 million. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Swap may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.
