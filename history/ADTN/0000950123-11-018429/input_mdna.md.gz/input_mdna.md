# ADTN MD&A — 0000950123-11-018429


## mdna

[0000950123-11-018429:mdna:1]
| ITEM 7. |  | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0000950123-11-018429:mdna:2]
Overview

[0000950123-11-018429:mdna:3]
ADTRAN, Inc. designs, manufactures, markets and services network access solutions for
communications networks. Our solutions are widely deployed by providers of communications services
(serviced by our Carrier Networks Division), and small and mid-sized enterprises (SMEs) (serviced
by our Enterprise Networks Division), and enable voice, data, video and Internet communications
across wireline and wireless networks. Many of these solutions are currently in use by every major
United States and many global service providers, as well as by many public, private and
governmental organizations worldwide.

[0000950123-11-018429:mdna:4]
Our success depends upon our ability to increase unit volume and market share through the
introduction of new products and succeeding generations of products having lower selling prices and
increased functionality as compared to both the prior generation of a product and to the products
of competitors. An important part of our strategy is to reduce the cost of each succeeding product
generation and then lower the product’s selling price based on the cost savings achieved in order
to gain market share and/or improve gross margins. As a part of this strategy, we seek in most
instances to be a high-quality, low-cost provider of products in our markets. Our success to date
is attributable in large measure to our ability to design our products initially with a view to
their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in
each succeeding product generation. This strategy enables us to sell succeeding generations of
products to existing customers, while increasing our market share by selling these enhanced
products to new customers.

[0000950123-11-018429:mdna:5]
Our three major product categories are Carrier Systems, Business Networking and Loop Access.

[0000950123-11-018429:mdna:6]
Carrier Systems products are used by communications service providers to provide last mile access
in support of data, voice and video services to consumers and enterprises. The Carrier Systems
category includes our broadband access products comprised of Total Access® 5000 multi-service
access and aggregation platform products, Total Access 1100/1200 Series Fiber-To-The-Node (FTTN)
products, and Digital Subscriber Line Access Multiplexer (DSLAM) products. Our broadband access
products are used by service providers to deliver high-speed Internet access, Voice over Internet
Protocol (VoIP), IP Television (IPTV), and/or Ethernet services from the central office or remote
terminal locations to customer premises. The Carrier Systems category also includes our optical
access products. These products consist of optical access multiplexers including our family of
OPTI products and our Optical Networking Edge (ONE) products. Optical access products are used to
deliver higher bandwidth services, or to aggregate large numbers of low bandwidth services for
transportation across fiber optic infrastructure. Total Access 1500 products, 303 concentrator
products, M13 multiplexer products, and a number of mobile backhaul products are also included in
the Carrier Systems product category.

[0000950123-11-018429:mdna:7]
Business Networking products provide access to telecommunication services, facilitating the
delivery of converged services and Unified Communications to the SME market. The Business
Networking category includes Internetworking products and Integrated Access Devices (IADs).
Internetworking products consist of our Total Access IP Business Gateways, Optical Network
Terminals (ONTs), and NetVanta product lines. NetVanta products include multi-service routers,
managed Ethernet switches, IP Private Branch Exchange (PBX) products, IP phone products, Unified
Communications solutions, Unified Threat Management (UTM) solutions and Carrier Ethernet Network
Terminating Equipment (NTE). Integrated Access Device (IAD) products consist of our Total Access
600 Series and the Total Access 850.

[0000950123-11-018429:mdna:8]
Loop Access products are used by carrier and enterprise customers for access to copper-based
telecommunications networks. The Loop Access category includes products such as: Digital Data
Service (DDS) and Integrated Services Digital Network (Total Reach) products, High bit-rate Digital
Subscriber Line (HDSL) products including Total Access 3000 HDSL and Time Division
Multiplexed-Symmetrical HDSL (TDM-SHDSL) products, T1/E1/T3, Channel Service Units/Data Service
Units, and TRACER fixed wireless products.

[0000950123-11-018429:mdna:9]
In addition, we identify sub-categories of product revenues, which we divide into growth products,
representing our primary growth areas, and traditional products. Our growth products consist of
Broadband Access and Optical Access products (included in Carrier Systems) and Internetworking
products (included in Business Networking) and our traditional products include HDSL products
(included in Loop Access) and other products not included in the aforementioned growth products.
Many of our customers are migrating their networks to deliver higher bandwidth services by
utilizing newer technologies. We believe that products and services offered in our primary growth
areas position us well for this migration. Despite short-term increases, we anticipate that
revenues of many of our traditional products, including HDSL, will decline over time; however,
revenues from these products may continue for years because of the time required for our customers
to transition to newer technologies.

[0000950123-11-018429:mdna:10]
Sales were $605.7 million in 2010 compared to $484.2 million in 2009 and $500.7 million in 2008.
Sales increased in each of our primary growth areas, Broadband Access, Optical Access and
Internetworking. Total sales of products in these three growth areas increased 40.2% in 2010
compared to 2009 and 13.5% in 2009 compared to 2008. Our gross profit margin remained consistent
in 2010 and 2009 at 59.3%, which decreased from 59.7% in 2008. Our operating income margin
increased to 25.4% in 2010 compared to 21.5% in 2009 and 22.7% in 2008. Net income was $114.0
million in 2010 compared to $74.2 million in 2009 and $78.6 million in 2008. Earnings per share,
assuming dilution, were $1.78 in 2010 compared to $1.17 in 2009 and $1.22 in 2008. Earnings per
share in 2010, 2009 and 2008 reflect the repurchase of 0.7 million, 0.8 million and 3.1 million
shares of our stock, respectively.

[0000950123-11-018429:mdna:11]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly
in future periods due to a number of factors, including customer order activity and backlog.
Backlog levels vary because of seasonal trends, the timing of customer projects and other factors
that affect customer order lead times. Many of our customers require prompt delivery of products.
This requires us to maintain sufficient inventory levels to satisfy anticipated customer demand.
If near-term demand for our products declines, or if potential sales in any quarter do not occur as
anticipated, our financial results could be adversely affected. Operating expenses are relatively
fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact
our financial results in a given quarter.

[0000950123-11-018429:mdna:12]
Our operating results may also fluctuate as a result of a number of other factors, including a
decline in general economic and market conditions, increased competition, customer order patterns,
changes in product mix, timing differences between price decreases and product cost reductions,
product warranty returns, expediting costs and announcements of new products by us or our
competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of
our products increases the amount of inventory that may become obsolete and increases the risk that
the obsolescence of this inventory may have an adverse effect on our business and operating
results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our
products may cause us to incur expediting costs to meet customer delivery requirements, which may
negatively impact our operating results in a given quarter.

[0000950123-11-018429:mdna:13]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of
future results, and, in general, management expects that our financial results may vary from period
to period. See Note 12 of Notes to Consolidated Financial Statements. For a discussion of risks
associated with our operating results, see Item 1A of this report.

[0000950123-11-018429:mdna:14]
Critical Accounting Policies and Estimates

[0000950123-11-018429:mdna:15]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made
based on assumptions about matters that are highly uncertain at the time the estimate is made, if
different estimates reasonably could have been used, or if changes in the accounting estimate that
are reasonably likely to occur could materially impact the results of financial operations. We
believe the following critical accounting policies affect our more significant judgments and
estimates used in the preparation of our consolidated financial statements. These policies have
been consistently applied across our two reportable segments: (1) Carrier Networks Division and (2)
Enterprise Networks Division.

[0000950123-11-018429:mdna:16]
|  | • |  | We review customer contracts to determine if all of the requirements for revenue recognition have been met prior to recording revenues from sales transactions. We generally record sales revenue upon shipment of our products, net of any rebates or discounts, since: (i) we generally do not have significant post-delivery obligations, (ii) the product price is fixed or determinable, (iii) collection of the resulting receivable is probable, and (iv) product returns are reasonably estimable. We generally ship products upon receipt of a purchase order from a customer. We evaluate shipping terms and we record revenue on products shipped in accordance with the terms of each respective contract where applicable, or under our standard shipping terms for purchase orders accepted without a contract, generally FOB shipping point. In the case of consigned inventory, revenue is recognized when the customer assumes ownership of the product. When contracts contain multiple elements, contract interpretation is sometimes required to determine the appropriate accounting, including whether the deliverables specified in a multiple element contract should be treated as separate units of accounting for revenue recognition purposes, and, if so, how the price should be allocated among the elements and when to recognize revenue for each element. We record revenue associated with installation services when all contractual obligations are complete. Contracts that include both installation services and product sales are evaluated for revenue recognition in accordance with contract terms. As a result, depending on contract terms, installation services may be considered as a separate deliverable item or may be considered an element of the delivered product. Either the purchaser, ADTRAN, or a third party can perform installation of our products. Revenues related to maintenance services are recognized on a straight line basis over the contract term. |

[0000950123-11-018429:mdna:17]
|  | • |  | Sales returns are accrued based on historical sales return experience, which we believe provides a reasonable estimate of future returns. A significant portion of Enterprise Networks products are sold in the United States through a non-exclusive distribution network of major technology distributors. These organizations then distribute to an extensive network of value-added resellers and system integrators. Value-added resellers and system integrators may be affiliated with us as a channel partner, or they may purchase from the distributor on an unaffiliated basis. Additionally, with certain limitations, our distributors may return unused and unopened product for stock-balancing purposes when these returns are accompanied by offsetting orders for products of equal or greater value. |

[0000950123-11-018429:mdna:18]
We participate in cooperative advertising and market development programs with certain
customers. We use these programs to reimburse customers for certain forms of advertising, and
in general, to allow our customers credits up to a specified percentage of their net
purchases. Our costs associated with these programs are estimated and accrued at the time of
sale and are included in selling, general and administrative expenses in our consolidated
statements of income. We also participate in rebate programs to provide sales incentives for
certain products. Our costs associated with these programs are estimated and accrued at the
time of sale and are recorded as a reduction of sales in our consolidated statements of
income.

[0000950123-11-018429:mdna:19]
Prior to issuing payment terms to a new customer, we perform a detailed credit review of the
customer. Credit limits and payment terms are established for each new customer based on the
results of this credit review. Collection experience is reviewed periodically in order to
determine if the customer’s payment terms and credit limits need to be revised. We maintain
allowances for doubtful accounts for losses resulting from the inability of our customers to
make required payments. If the financial condition of our customers deteriorates, resulting
in an impairment of their ability to make payments, we may be required to make additional
allowances. If circumstances change with regard to individual receivable balances that have
previously been determined to be uncollectible (and for which a specific reserve has been
established), a reduction in our allowance for doubtful accounts may be required. Our
allowance for doubtful accounts was $0.2 million at December 31, 2010 and $0.1 million at
December 31, 2009.

[0000950123-11-018429:mdna:20]
|  | • |  | We carry our inventory at the lower of cost or market, with cost being determined using the first-in, first-out method. We use standard costs for material, labor, and manufacturing overhead to value our inventory. Our standard costs are updated on at least a quarterly basis and any variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We write down our inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated fair value based upon assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $8.9 million and $7.8 million at December 31, 2010 and 2009, respectively. Inventory write-downs charged to the reserve were $0.8 million, $1.7 million and $1.0 million for the years ended December 31, 2010, 2009 and 2008, respectively. |

[0000950123-11-018429:mdna:21]
|  | • |  | The objective of our short-term investment policy is to preserve principal and maintain adequate liquidity with appropriate diversification, while achieving market returns. The objective of our long-term investment policy is principal preservation and total return; that is, the aggregate return from capital appreciation, dividend income, and interest income. These objectives are achieved through investments with appropriate diversification in fixed and variable rate income securities, public equity, and private equity portfolios. We have experienced significant volatility in the market prices of our publicly traded equity investments. These investments are recorded on the consolidated balance sheets at fair value with unrealized gains and losses reported as a component of accumulated other comprehensive income, net of tax. The ultimate realized value on these equity investments is subject to market price volatility. |

[0000950123-11-018429:mdna:22]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have
categorized our cash equivalents held in money market funds and our investments held at fair
value into a three-level fair value hierarchy based on the priority of the inputs to the
valuation technique for the cash equivalents and investments as follows: Level 1 — Values
based on unadjusted quoted prices for identical assets or liabilities in an active market;
Level 2 — Values based on quoted prices in markets that are not active or model inputs that
are observable either directly or indirectly for substantially the full term of the asset or
liability; Level 3 — Values based on prices or valuation techniques that require inputs that
are both unobservable and significant to the overall fair value measurement. These inputs
include information supplied by investees. At December 31, 2010, we categorized $53.0
million and $315.3 million of our available-for-sale investments as Level 1 and Level 2,
respectively, and $14.5 million of our cash equivalents as Level 1. At December 31, 2009, we
categorized $38.1 million and $246.1 million of our available-for-sale investments as Level 1
and Level 2, respectively, and $18.4 million of our cash equivalents as Level 1.

[0000950123-11-018429:mdna:23]
28

[0000950123-11-018429:mdna:24]
We review our investment portfolio for potential “other-than-temporary” declines in
value on an individual investment basis. We assess, on a quarterly basis, significant
declines in value which may be considered other-than-temporary and, if necessary, recognize
and record the appropriate charge to write-down the carrying value of such investments. In
making this assessment, we take into consideration qualitative and quantitative information,
including but not limited to the following: the magnitude and duration of historical declines
in market prices, credit rating activity, assessments of liquidity, public filings, and
statements made by the issuer. We generally begin our identification of potential
other-than-temporary impairments by reviewing any security with a fair value that has
declined from its original or adjusted cost basis by 25% or more for six or
more consecutive months. We then evaluate the individual security based on the previously
identified factors to determine the amount of the write-down, if any. As a result of our
review, we did not record any other-than-temporary impairment charge during the fourth
quarter of 2010. For the years ended December 31, 2010, 2009 and 2008, we recorded charges
of $43 thousand, $2.9 million and $2.4 million, respectively, related to the
other-than-temporary impairment of certain publicly traded equity securities, a fixed income
bond fund, and deferred compensation plan assets. Actual losses, if any, could ultimately
differ from these estimates. Future adverse changes in market conditions or poor operating
results of underlying investments could result in additional losses that may not be reflected
in an investment’s current carrying value, thereby possibly requiring an impairment charge in
the future. See Note 3 of Notes to the Consolidated Financial Statements in this report for
more information about our investments.

[0000950123-11-018429:mdna:25]
We also invest in privately held entities and private equity funds and record these
investments at cost. We review these investments periodically in order to determine if
circumstances (both financial and non-financial) exist that indicate that we will not recover
our initial investment. Impairment charges are recorded on investments having a cost basis
that is greater than the value that we would reasonably expect to receive in an arm’s length
sale of the investment. We have not been required to record any impairment losses relating
to these investments in 2010, 2009 or 2008.

[0000950123-11-018429:mdna:26]
|  | • |  | For purposes of determining the estimated fair value of our stock option awards on the date of grant under the Stock Compensation Topic of the FASB ASC, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable single measure of the fair value of our stock option awards. For purposes of determining the estimated fair value of our performance-based restricted stock unit awards on the date of grant, we use a Monte Carlo Simulation valuation method. The restricted stock units are subject to a market condition based on the relative total shareholder return of ADTRAN against a peer group of companies (2008 and 2009 grants) or against all companies in the NASDAQ Telecommunications Index (2010 grant) and vest at the end of a three-year performance period. The fair value of restricted stock issued to our Directors in 2010 is equal to the closing price of our stock on the date of grant. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change and we use different assumptions in the application of the Stock Compensation Topic of the FASB ASC in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. |

[0000950123-11-018429:mdna:27]
|  | • |  | We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets, and establish reserves where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets in accordance with the Income Taxes Topic of the FASB ASC. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. At December 31, 2010 and 2009 respectively, the valuation allowance was $5.6 million and $5.3 million. As of December 31, 2010, we have state research tax credit carry-forwards of $2.2 million, which will expire between 2015 and 2025. These carry-forwards were caused by tax credits in excess of our annual tax liabilities to an individual state where we no longer generate sufficient state income. In addition, as of December 31, 2010, we have a deferred tax asset of $3.8 million relating to net operating loss carry-forwards which will expire between 2014 and 2029. These carry-forwards are the result of a foreign acquisition in 2009. The acquired net operating losses are in excess of the amount of estimated earnings. In accordance with the Income Taxes Topic of the FASB ASC, we believe it is more likely than not that we will not realize the full benefits of our deferred tax asset arising from these credits and net operating losses, and accordingly, have provided a valuation allowance against them. This valuation allowance is included in non-current deferred tax liabilities in the accompanying balance sheets. |

[0000950123-11-018429:mdna:28]
|  | • |  | Our products generally include warranties of one to ten years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to systems products. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty returns totaled $3.3 million and $2.8 million at December 31, 2010 and 2009, respectively. These liabilities are included in accrued expenses in the accompanying consolidated balance sheets. |

[0000950123-11-018429:mdna:29]
Results of Operations

[0000950123-11-018429:mdna:30]
The following table presents selected financial information derived from our consolidated
statements of income expressed as a percentage of sales for the years indicated.

[0000950123-11-018429:mdna:31]
| Year Ended December 31, |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Carrier Networks Division |  |  | 78.6 | % |  |  | 76.7 | % |  |  | 78.3 | % |
| Enterprise Networks Division |  |  | 21.4 |  |  |  | 23.3 |  |  |  | 21.7 |  |
| Total sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of sales |  |  | 40.7 |  |  |  | 40.7 |  |  |  | 40.3 |  |
| Gross profit |  |  | 59.3 |  |  |  | 59.3 |  |  |  | 59.7 |  |
| Selling, general and administrative expenses |  |  | 19.0 |  |  |  | 20.5 |  |  |  | 20.6 |  |
| Research and development expenses |  |  | 14.9 |  |  |  | 17.2 |  |  |  | 16.4 |  |
| Operating income |  |  | 25.4 |  |  |  | 21.6 |  |  |  | 22.7 |  |
| Interest and dividend income |  |  | 1.1 |  |  |  | 1.4 |  |  |  | 1.7 |  |
| Interest expense |  |  | (0.4 | ) |  |  | (0.5 | ) |  |  | (0.5 | ) |
| Net realized investment gain (loss) |  |  | 1.8 |  |  |  | (0.3 | ) |  |  | (0.5 | ) |
| Other income (expense), net |  |  | (0.1 | ) |  |  | — |  |  |  | 0.2 |  |
| Income before provision for income taxes |  |  | 27.8 |  |  |  | 22.2 |  |  |  | 23.6 |  |
| Provision for income taxes |  |  | (9.0 | ) |  |  | (6.9 | ) |  |  | (7.9 | ) |
| Net income |  |  | 18.8 | % |  |  | 15.3 | % |  |  | 15.7 | % |

[0000950123-11-018429:mdna:32]
2010 Compared to 2009

[0000950123-11-018429:mdna:33]
Sales

[0000950123-11-018429:mdna:34]
ADTRAN’s sales increased 25.1% from $484.2 million in 2009 to $605.7 million in 2010. This
increase in sales is primarily attributable to a $64.6 million increase in sales of our Broadband
Access products, a $31.1 million increase in sales of our Internetworking products, a $27.0 million
increase in sales of our HDSL products, and a $5.6 million increase in our Optical Access products,
partially offset by a $4.2 million decrease in traditional IAD products and a $2.6 million decrease
in enterprise T1 products.

[0000950123-11-018429:mdna:35]
Carrier Networks sales increased 28.2% from $371.3 million in 2009 to $476.0 million in 2010. The
increase is primarily attributable to increases in Broadband Access, Optical Access, TDM, HDSL and
Internetworking NTE product sales, partially offset by a decrease in other traditional products.

[0000950123-11-018429:mdna:36]
Enterprise Networks sales increased 14.9% from $112.8 million in 2009 to $129.6 million in 2010.
The increase is primarily attributable to an increase in Internetworking product sales, partially
offset by decreases in IAD and enterprise T1 product sales. Internetworking product sales were
77.3% of Enterprise Network sales in 2010 compared with 67.4% in 2009. Traditional products
primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a
percentage of total sales decreased from 23.3% in 2009 to 21.4% in 2010.

[0000950123-11-018429:mdna:37]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts
discussed above, increased 14.6% from $27.8 million in 2009 to $31.8 million in 2010.
International sales, as a percentage of total sales, decreased from 5.7% in 2009 to 5.3% in 2010.
The increase in international sales in 2010 was primarily attributable to an increase in sales in
Australia, Mexico and Europe, partially offset by a decrease in sales in Canada.

[0000950123-11-018429:mdna:38]
Carrier Systems product sales increased $73.6 million in 2010 compared to 2009 primarily due to a
$64.6 million increase in Broadband Access product sales and a $5.6 million increase in Optical
Access product sales. The increase in Broadband Access product sales was primarily attributable to
continued growth in deployments of our TA 5000 platform and Fiber to the Node products resulting
from market share gains across all major market segments.

[0000950123-11-018429:mdna:39]
Business Networking product sales increased $26.8 million in 2010 compared to 2009 primarily due to
an increase in Internetworking product sales. Growth in Internetworking product sales occurred
across all areas, including routers, Ethernet switches, IP gateways,
access termination products and our IP PBX segment as a result of market share gains in SME and
distributed enterprise applications. This increase was partially offset by a decrease in
traditional IAD product sales as customers shifted emphasis to newer technologies. Many of these
newer technologies are integral to our Internetworking product area.

[0000950123-11-018429:mdna:40]
Loop Access product sales increased $21.1 million in 2010 compared to 2009 primarily due to a $27.0
million increase in HDSL product sales, partially offset by decreases in other traditional product
sales. The increase in HDSL product sales is primarily attributable to carriers increasing
investment to cost effectively and quickly add capacity to mobility networks.

[0000950123-11-018429:mdna:41]
Cost of Sales

[0000950123-11-018429:mdna:42]
Cost of sales remained consistent in 2010 and 2009 at 40.7% of sales. Gross margins benefited from
improved product mix, cost absorption and manufacturing efficiencies achieved at the higher
production volumes, offset by higher warranty expense and an increase in lower margin installation
services revenue. However, installation services revenue was accretive to operating income margins
in 2010.

[0000950123-11-018429:mdna:43]
Carrier Networks cost of sales decreased from 40.8% of sales in 2009 to 40.5% of sales in 2010.
The decrease was primarily related to improved cost absorption and manufacturing efficiencies
achieved at the higher production volumes, which was partially offset by an increase in lower
margin installation services revenue.

[0000950123-11-018429:mdna:44]
Enterprise Networks cost of sales increased from 40.4% of sales in 2009 to 41.7% of sales in 2010.
The increase was primarily related to a higher cost product mix and the impact of cost allocations
between divisions.

[0000950123-11-018429:mdna:45]
An important part of our strategy is to reduce the product cost of each succeeding product
generation and then to lower the product’s price based on the cost savings achieved. This may cause
variations in our gross profit percentage due to timing differences between the recognition of cost
reductions and the lowering of product selling prices.

[0000950123-11-018429:mdna:46]
Selling, General, and Administrative Expenses

[0000950123-11-018429:mdna:47]
Selling, general, and administrative expenses increased 15.3% from $99.4 million in 2009 to $114.7
million in 2010. Selling, general, and administrative expenses include personnel costs for
administration, finance, information systems, human resources, sales and marketing, and general
management, as well as rent, utilities, legal and accounting expenses, bad debt expense,
advertising, promotional material, trade show expenses, and related travel costs. The increase in
selling, general, and administrative expenses was primarily related to an increase in staffing
costs and fringe benefits due to increased headcount, and increases in incentive compensation,
contract services and travel expenses.

[0000950123-11-018429:mdna:48]
Selling, general and administrative expenses as a percentage of sales decreased from 20.5% for the
year ended December 31, 2009 to 18.9% for the year ended December 31, 2010. Selling, general and
administrative expenses as a percent of sales will generally fluctuate whenever there is
significant fluctuation in revenues for the periods being compared.

[0000950123-11-018429:mdna:49]
Research and Development Expenses

[0000950123-11-018429:mdna:50]
Research and development expenses increased 8.4% from $83.3 million in 2009 to $90.3 million in
2010. The increase in research and development expenses was a result of increased staffing costs
and fringe benefits, engineering and testing expense primarily related to customer specific product
development activities as well as costs related to product approvals, primarily for one or more of
the top three U.S. carriers.

[0000950123-11-018429:mdna:51]
Research and development expenses as a percentage of sales decreased from 17.2% for the year ended
December 31, 2009 to 14.9% for the year ended December 31, 2010. Research and development expenses
as a percentage of sales will fluctuate whenever there are incremental product development
activities or a significant fluctuation in revenues for the periods being compared.

[0000950123-11-018429:mdna:52]
We expect to continue to incur research and development expenses in connection with our new and
existing products and our expansion into international markets. We continually evaluate new
product opportunities and engage in intensive research and product development efforts which
provides for new product development, enhancement of existing products and product cost reductions.
We may incur significant research and development expenses prior to the receipt of revenues from a
major new product group.

[0000950123-11-018429:mdna:53]
Interest and Dividend Income

[0000950123-11-018429:mdna:54]
Interest and dividend income decreased 5.4% from $6.9 million in 2009 to $6.6 million in 2010.
This decrease was primarily attributable to a 22.2% reduction in the average rate of return on our
investments as a result of lower interest rates, partially offset by a 23.7% increase in our
average investment balances.

[0000950123-11-018429:mdna:55]
Interest Expense

[0000950123-11-018429:mdna:56]
Interest expense remained consistent at $2.4 million in 2010 and 2009, as we had no substantial
change in our fixed rate borrowing. See “Liquidity and Capital Resources” below for additional
information.

[0000950123-11-018429:mdna:57]
Net Realized Investment Gain (Loss)

[0000950123-11-018429:mdna:58]
Net realized investment gain (loss) changed from a $1.3 million loss in 2009 to an $11.0 million
gain in 2010. This change is primarily a result of the other-than-temporary impairments of $2.0
million related to our marketable equity securities, $0.4 million related to our investment in a
fixed income bond fund, and $0.5 million related to our deferred compensation plan assets in 2009
and the realized gains of $8.1 million on the sale of one security and $1.6 million from the sale
of previously impaired marketable equity securities in 2010. See “Investing Activities” in
“Liquidity and Capital Resources” below for additional information.

[0000950123-11-018429:mdna:59]
Other Income (Expense), net

[0000950123-11-018429:mdna:60]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on
foreign currency transactions, investment account management fees, and gains or losses on the
disposal of property, plant and equipment occurring in the normal course of business, changed from
$0.1 million of income in 2009 to $0.8 million of expense in 2010.

[0000950123-11-018429:mdna:61]
Income Taxes

[0000950123-11-018429:mdna:62]
Our effective tax rate increased from 31.0% in 2009 to 32.2% in 2010. This increase is primarily
due to the reduced impact of available statutory tax benefits applied to the increased level of
pretax income in 2010. The statutory benefits include the research and development tax credit,
deduction for domestic manufacturing under Internal Revenue Code Section 199 and stock option
related tax benefits.

[0000950123-11-018429:mdna:63]
Net Income

[0000950123-11-018429:mdna:64]
As a result of the above factors, net income increased from $74.2 million in 2009 to $114.0 million
in 2010. As a percentage of sales, net income increased from 15.3% in 2009 to 18.8% in 2010.

[0000950123-11-018429:mdna:65]
2009 Compared to 2008

[0000950123-11-018429:mdna:66]
Sales

[0000950123-11-018429:mdna:67]
ADTRAN’s sales decreased 3.3% from $500.7 million in 2008 to $484.2 million in 2009. This decrease
in sales is primarily attributable to a $46.6 million decrease in sales of HDSL and other
traditional products, partially offset by a $9.1 million increase in sales of our Broadband Access
products, a $6.8 million increase in sales of our Optical Access products, and a $14.2 million
increase in sales of our Internetworking products.

[0000950123-11-018429:mdna:68]
Carrier Networks sales decreased 5.3% from $392.2 million in 2008 to $371.3 million in 2009. The
decrease is primarily attributable to decreases in HDSL, DDS, and other traditional TDM products
sales, partially offset by an increase in Broadband Access and Optical Access product sales.

[0000950123-11-018429:mdna:69]
Enterprise Networks sales increased 4.0% from $108.5 million in 2008 to $112.8 million in 2009.
The increase is primarily attributable to an increase in sales of Internetworking products,
partially offset by declines in sales of traditional IAD products, and Enterprise T1 products.
Internetworking product sales were 67.4% of Enterprise Network sales in 2009 compared with 58.3% in
2008. Traditional products primarily comprise the remainder of Enterprise Networks sales.
Enterprise Networks sales as a percentage of total sales increased from 21.7% in 2008 to 23.3% in
2009.

[0000950123-11-018429:mdna:70]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts
discussed above, decreased 7.7% from $30.1 million in 2008 to $27.8 million in 2009. International
sales, as a percentage of total sales, decreased from 6.0% in 2008 to 5.7% in 2009. International
sales in 2009 decreased primarily due to a decline in macroeconomic conditions.

[0000950123-11-018429:mdna:71]
Carrier Systems product sales increased $9.5 million in 2009 compared to 2008 primarily due to a
$9.1 million increase in Broadband Access product sales and a $6.8 million increase in Optical
Access product sales. These increases were primarily attributable to increased shipments of our
Total Access® 5000 products, our OPTI family of products and continuing deployments of FTTN
products, resulting from market share gains across all major market segments. Partially offsetting
these increases were decreases in TDM and other traditional product sales as customers shifted
emphasis to newer technologies. Many of these newer technologies are integral to our Broadband
Access and Optical Access product areas.

[0000950123-11-018429:mdna:72]
Business Networking product sales increased $10.9 million in 2009 compared to 2008 due to a $14.2
million increase in Internetworking product sales, primarily as a result of market share gains in
SMB and distributed enterprise applications. Partially offsetting this increase in Internetworking
product sales was a decline in sales of traditional IAD products as customers shifted emphasis to
newer technologies. Many of these newer technologies are integral to our Internetworking product
area.

[0000950123-11-018429:mdna:73]
Loop Access product sales decreased $36.9 million in 2009 compared to 2008 primarily due to
declines in HDSL, Enterprise T1, and DDS product sales.

[0000950123-11-018429:mdna:74]
Cost of Sales

[0000950123-11-018429:mdna:75]
Cost of sales increased from 40.3% of sales in 2008 to 40.7% of sales in 2009. The increase in
cost of sales as a percentage of sales is primarily related to costs incurred to expedite delivery
of materials and costs related to a new product release, which were partially offset by cost
reductions generated through improved manufacturing efficiencies.

[0000950123-11-018429:mdna:76]
Carrier Networks cost of sales increased from 39.8% of sales in 2008 to 40.8% of sales in 2009.
The increase was primarily related to costs incurred to expedite delivery of materials and costs
related to a new product release.

[0000950123-11-018429:mdna:77]
Enterprise Networks cost of sales decreased from 42.2% of sales in 2008 to 40.4% of sales in 2009.
The decrease was primarily related to lower freight costs and other cost reductions generated
through improved manufacturing efficiencies.

[0000950123-11-018429:mdna:78]
An important part of our strategy is to reduce the product cost of each succeeding product
generation and then to lower the product’s price based on the cost savings achieved. This may cause
variations in our gross profit percentage due to timing differences between the recognition of cost
reductions and the lowering of product selling prices.

[0000950123-11-018429:mdna:79]
Selling, General, and Administrative Expenses

[0000950123-11-018429:mdna:80]
Selling, general, and administrative expenses decreased 3.7% from $103.3 million, or 20.6% of sales
in 2008, to $99.4 million, or 20.5% of sales in 2009. Selling, general, and administrative
expenses include personnel costs for administration, finance, information systems, human resources,
sales and marketing, and general management, as well as rent, utilities, legal and accounting
expenses, bad debt expense, advertising, promotional material, trade show expenses, and related
travel costs. The decrease in selling, general, and administrative expenses was primarily related
to a reduction in discretionary expenditures including temporary labor, travel, and various
promotional expenses.

[0000950123-11-018429:mdna:81]
Selling, general and administrative expenses as a percent of sales will generally fluctuate
whenever there is significant fluctuation in revenues for the periods being compared.

[0000950123-11-018429:mdna:82]
Research and Development Expenses

[0000950123-11-018429:mdna:83]
Research and development expenses increased 1.8% from $81.8 million, or 16.3% of sales, in 2008 to
$83.3 million, or 17.2% of sales, in 2009. The increase in research and development expenses was a
result of increased staffing, engineering and testing expense primarily related to customer
specific product development activities as well as costs related to product approvals, primarily
for one or more of the top three U.S. carriers. Research and development expenses as a percentage
of sales will fluctuate whenever there are incremental product development activities or a
significant fluctuation in revenues for the periods being compared.

[0000950123-11-018429:mdna:84]
ADTRAN expects to continue to incur research and development expenses in connection with its new
and existing products and its expansion into international markets. ADTRAN continually evaluates
new product opportunities and engages in intensive research and product development efforts which
provides for new product development, enhancement of existing products and product cost
reductions. ADTRAN may incur significant research and development expenses prior to the receipt of
revenues from a major new product group or market expansion.

[0000950123-11-018429:mdna:85]
Interest and Dividend Income

[0000950123-11-018429:mdna:86]
Interest and dividend income decreased 20.4% from $8.7 million in 2008 to $6.9 million in 2009.
This decrease was the result of a 39.6% reduction in the average rate of return on our investments
due to lower interest rates.

[0000950123-11-018429:mdna:87]
Interest Expense

[0000950123-11-018429:mdna:88]
Interest expense decreased from $2.5 million in 2008 to $2.4 million in 2009. The decrease was due
to a lower principal balance in 2009 as compared to 2008. See “Liquidity and Capital Resources”
below for additional information.

[0000950123-11-018429:mdna:89]
Net Realized Investment Gain (Loss)

[0000950123-11-018429:mdna:90]
Net realized investment gain (loss) changed from a $2.4 million loss in 2008 to a $1.3 million loss
in 2009. The change is a result of lower other-than-temporary impairments of certain securities in
our equity portfolio during 2009 as compared to 2008 and the sales of certain securities for a
gain. See “Investing Activities” in “Liquidity and Capital Resources” below for additional
information.

[0000950123-11-018429:mdna:91]
Other Income (Expense), net

[0000950123-11-018429:mdna:92]
Other income, net, comprised primarily of miscellaneous income, gains and losses on foreign
currency transactions, investment account management fees, and gains or losses on the disposal of
property, plant and equipment occurring in the normal course of business, decreased from $0.7
million in 2008 to $0.1 million in 2009.

[0000950123-11-018429:mdna:93]
Income Taxes

[0000950123-11-018429:mdna:94]
Our effective tax rate decreased from 33.6% in 2008 to 31.0% in 2009, primarily due to increased
benefits relating to the deduction for manufacturer’s domestic production activities under Internal
Revenue Code Section 199 and an increase in our federal research and development credits, partially
offset by an increase in state income tax expense.

[0000950123-11-018429:mdna:95]
Net Income

[0000950123-11-018429:mdna:96]
As a result of the above factors, net income decreased from $78.6 million in 2008 to $74.2 million
in 2009. As a percentage of sales, net income decreased from 15.7% in 2008 to 15.3% in 2009.

[0000950123-11-018429:mdna:97]
Liquidity and Capital Resources

[0000950123-11-018429:mdna:98]
Liquidity

[0000950123-11-018429:mdna:99]
We intend to finance our operations with cash flow from operations. We have used, and expect to
continue to use, the cash generated from operations for working capital, purchases of treasury
stock, dividend payments, and other general corporate purposes, including (i) product development
activities to enhance our existing products and develop new products and (ii) expansion of sales
and marketing activities. We believe our cash and cash equivalents, investments and cash generated
from operations to be adequate to meet our operating and capital needs.

[0000950123-11-018429:mdna:100]
At December 31, 2010, cash on hand was $31.7 million and short-term investments were $157.5
million, which placed our short-term liquidity at $189.2 million. At December 31, 2009, our cash
on hand of $24.1 million and short-term investments of $172.5 million placed our short-term
liquidity at $196.6 million. The decrease in liquidity from 2009 to 2010 primarily reflects a
partial realignment of our investment portfolio from short-term to long-term, which increased
long-term investments by $99.0 million in 2010.

[0000950123-11-018429:mdna:101]
Operating Activities

[0000950123-11-018429:mdna:102]
Our working capital, which consists of current assets less current liabilities, increased 9.7% from
$278.0 million as of December 31, 2009 to $305.0 million as of December 31, 2010, primarily due to
an increase in inventory of $28.6 million. Inventory increased during 2010 to support increasing
customer demand, increases in inventories related to an increase in installation services
contracts, and to mitigate component supply constraints broadly affecting the industry. The quick
ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable,
divided by current liabilities, decreased from 5.54 as of December 31, 2009 to 5.21 as of December
31, 2010. The quick ratio decreased primarily due to a decrease in short-term investments of $15.0
million, which was a
result of the partial realignment of our investment portfolio from short-term to long-term. The
current ratio, defined as current assets divided by current liabilities, increased from 6.82 as of
December 31, 2009 to 7.10 as of December 31, 2010. The current ratio increased primarily due to
the increase in inventory of $28.6 million for the reasons stated above.

[0000950123-11-018429:mdna:103]
Net accounts receivable increased 4.2% from $68.0 million at December 31, 2009 to $70.9 million at
December 31, 2010. Our allowance for doubtful accounts increased from $0.1 million at December 31,
2009 to $0.2 million at December 31, 2010. Quarterly accounts receivable days sales outstanding
(DSO) decreased from 50 days as of December 31, 2009 to 39 days as of December 31, 2010.
Generally, the change in net accounts receivable and DSO is due to the timing of sales and
collections during the quarter. Other receivables decreased from $4.1 million at December 31, 2009
to $4.0 million at December 31, 2010. Other receivables may fluctuate due to the timing of
collections for materials supplied to our contract manufacturers.

[0000950123-11-018429:mdna:104]
Quarterly inventory turnover decreased from 4.5 turns as of December 31, 2009 to 3.8 turns as of
December 31, 2010. Inventory increased 62.6% from December 31, 2009 to December 31, 2010. Our
investment in inventory increased during 2010 to support increasing customer demand, increases in
inventories related to an increase in installation services contracts, and to mitigate component
supply constraints broadly affecting the industry. We expect inventory levels to fluctuate as we
attempt to maintain sufficient inventory in response to seasonal cycles of our business; ensuring
competitive lead times while managing the risk of inventory obsolescence that may occur due to
rapidly changing technology and customer demand.

[0000950123-11-018429:mdna:105]
Accounts payable decreased 11.6% from $25.8 million at December 31, 2009 to $22.8 million at
December 31, 2010. Generally, the change in accounts payable is due to variations in the timing of
the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0000950123-11-018429:mdna:106]
Investing Activities

[0000950123-11-018429:mdna:107]
Capital expenditures totaled approximately $9.9 million, $8.7 million and $9.5 million for the
years ended December 31, 2010, 2009 and 2008, respectively. These expenditures were primarily used
to purchase computer hardware, software and manufacturing and test equipment.

[0000950123-11-018429:mdna:108]
Our combined short-term and long-term investments increased $84.0 million from $334.6 million at
December 31, 2009 to $418.6 million at December 31, 2010. This increase reflects the impact of
additional funds available for investment provided by our operating activities, reduced by our cash
needs for equipment acquisitions, stock repurchases and dividends, as well as net realized and
unrealized losses and amortization of net premiums on our combined investments.

[0000950123-11-018429:mdna:109]
We invest all available cash not required for immediate use in operations primarily in securities
that we believe bear minimal risk of loss. At December 31, 2010, these investments included
municipal variable rate demand notes of $116.7 million, municipal fixed-rate bonds of $71.5 million
and corporate bonds of $127.1 million. At December 31, 2009, these investments included municipal
variable rate demand notes of $84.4 million, municipal fixed-rate bonds of $141.3 million and
corporate bonds of $20.4 million.

[0000950123-11-018429:mdna:110]
Our municipal variable rate demand notes are classified as available-for-sale short-term
investments. At December 31, 2010, 29% of our municipal variable rate demand notes had a credit
rating of AAA, 63% had a credit rating of AA, 8% had a credit rating of A, and all contained put
options of seven days. Despite the long-term nature of their stated contractual maturities, we
routinely buy and sell these securities and we believe that we have the ability to quickly
liquidate them. Our investments in these securities are recorded at fair value, and the interest
rates reset every seven days. We believe we have the ability to sell our variable rate demand
notes to the remarketing agent, tender agent, or issuer at par value plus accrued interest in the
event we decide to liquidate our investment in a particular variable rate demand note. At December
31, 2010, approximately 28% of our variable rate demand notes were supported by letters of credit
from banks that we believe to be in good financial condition. The remaining 72% of our variable
rate demand notes were supported by standby purchase agreements. As a result of all of these
factors, we had no cumulative gross unrealized holding gains (losses) or gross realized gains
(losses) from these investments. All income generated from these investments was recorded as
interest income. We have not been required to record any losses relating to municipal variable
rate demand notes.

[0000950123-11-018429:mdna:111]
At December 31, 2010, approximately 15% of our municipal fixed-rate bond portfolio had a credit
rating of AAA, 74% had a credit rating of AA, and 11% had a credit rating of A. These bonds are
classified as available-for-sale investments and had an average duration of 1.2 years at December
31, 2010. Because our bond portfolio has a high quality rating and contractual maturities of a
short duration, we are able to obtain prices for these bonds derived from observable market inputs,
or for similar securities traded in an active market, on a daily basis.

[0000950123-11-018429:mdna:112]
At December 31, 2010, we held $127.1 million of corporate bonds. These bonds are classified as
available-for-sale and had an average duration of 2.0 years at December 31, 2010. At December 31,
2010, approximately 3% of our corporate bond portfolio had a credit rating of AAA, 11% had a credit
rating of AA, 51% had a credit rating of A, and 35% had a credit rating of BBB.

[0000950123-11-018429:mdna:113]
Our long-term investments increased 61.0% from $162.2 million at December 31, 2009 to $261.2
million at December 31, 2010. Municipal fixed-rate bonds classified as long-term investments
decreased $11.1 million from $53.2 million at December 31, 2009 to $42.1 million at December 31,
2010. The primary reason for the decrease in our long-term municipal fixed rate bonds was a change
in investment strategy that placed additional long-term investments in corporate bonds. Long-term
investments at December 31, 2010 and 2009 include an investment in a certificate of deposit of
$48.3 million which serves as collateral for our revenue bonds, as discussed below. We have
various equity investments included in long-term investments at a cost of $11.5 million and $9.8
million, and with a fair value of $48.0 million and $33.5 million, at December 31, 2010 and 2009,
respectively, including a single equity security, of which we held 1.5 million shares and 2.1
million shares, carried at $34.2 million and $22.4 million of fair value, at December 31, 2010 and
2009, respectively. This single security traded approximately 1.0 million shares per day in 2010
in an active market on a European stock exchange. Of the gross unrealized gains included in the
fair value of our marketable securities at December 31, 2010 and 2009, this single security
comprised $33.7 million and $21.7 million, respectively, of the unrealized gain. The remaining
$3.0 million of gross unrealized gains and $0.1 million in gross unrealized losses at December 31,
2010 were spread amongst more than 415 marketable equity securities. Long-term investments at
December 31, 2010 and 2009 also included $4.2 million and $3.4 million, respectively, related to
our deferred compensation plan; $2.1 million and $2.2 million, respectively, of other investments
carried at cost, consisting of interests in two private equity funds and an investment in a
privately held telecommunications equipment manufacturer; and $0.7 million and $1.2 million,
respectively, of a fixed income bond fund. This bond fund had unrealized gains of $0.2 million and
$0.3 million at December 31, 2010 and 2009, respectively.

[0000950123-11-018429:mdna:114]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
individual investment basis. We assess, on a quarterly basis, significant declines in value which
may be considered other-than-temporary and, if necessary, recognize and record the appropriate
charge to write-down the carrying value of such investments. In making this assessment, we take
into consideration qualitative and quantitative information, including but not limited to the
following: the magnitude and duration of historical declines in market prices, credit rating
activity, assessments of liquidity, public filings, and statements made by the issuer. We generally
begin our identification of potential other-than-temporary impairments by reviewing any security
with a fair value that has declined from its original or adjusted cost basis by 25% or more for six
or more consecutive months. We then evaluate the individual security based on the previously
identified factors to determine the amount of the write-down, if any. As a result of our review,
we did not record any other-than-temporary impairment charge during the fourth quarter of 2010.
For the years ended December 31, 2010, 2009 and 2008 we recorded charges of $43 thousand, $2.9
million and $2.4 million, respectively, related to the other-than-temporary impairment of certain
publicly traded equity securities, a fixed income bond fund, and deferred compensation plan assets.

[0000950123-11-018429:mdna:115]
Financing Activities

[0000950123-11-018429:mdna:116]
Fifty million dollars of the expansion of Phase III of our corporate headquarters was approved for
participation in an incentive program offered by the Alabama State Industrial Development Authority
(the Authority). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million
of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN. The
bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the Bank).
Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee,
Nashville, Tennessee) (the Bondholder), which was acquired by Wells Fargo & Company on December 31,
2008, purchased the original bonds from the Bank and made further advances to the Authority,
bringing the total amount outstanding to $50.0 million. The incentive program enables participating
companies to generate Alabama corporate income tax credits that can be used to reduce the amount of
Alabama corporate income taxes that would otherwise be payable, in exchange for investing capital
and creating jobs in Alabama. We cannot be certain that the state of Alabama will continue to make
these corporate income tax credits available; therefore, we may not realize the full benefit of
these incentives. Through December 31, 2010, the Authority had issued $50.0 million of its taxable
revenue bonds pursuant to the incentive program and loaned the proceeds from the sale of the bonds
to ADTRAN. We are required to make payments to the Authority in the amounts necessary to pay the
principal of, and interest on, the Authority’s Taxable Revenue Bond, Series 1995, as amended,
currently outstanding in the aggregate principal amount of $48.0 million. The bond matures on
January 1, 2020, and bears interest at the rate of 5% per annum. Included in long-term investments
at December 31, 2010 is $48.3 million of restricted funds, which is a collateral deposit against
the principal amount of this bond. We have the right to set-off the balance of the Bond with the
collateral deposit in order to reduce the balance of the indebtedness. In conjunction with this
program, we are eligible to receive certain economic incentives from the state of Alabama that
reduce the amount of payroll withholdings that we are required to remit to the state for those
employment positions that qualify under the program.

[0000950123-11-018429:mdna:117]
Due to continued positive cash flow from operating activities, we made a business decision in 2006
to begin an early partial redemption of the Bond. It is our intent to make annual principal
payments in addition to the interest amounts that are due. In connection with this decision, $0.5
million of the bond debt has been reclassified to a current liability in the Consolidated Balance
Sheets at December 31, 2010 and 2009.

[0000950123-11-018429:mdna:118]
36

[0000950123-11-018429:mdna:119]
The following table shows dividends paid in each quarter of 2010, 2009 and 2008. During 2010, 2009
and 2008, ADTRAN paid dividends totaling $22.5 million, $22.5 million and $22.9 million,
respectively. The Board of Directors presently anticipates that it will declare a regular
quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of
liquidity are maintained.

[0000950123-11-018429:mdna:120]
Dividends per Common Share

[0000950123-11-018429:mdna:121]
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0000950123-11-018429:mdna:122]
Stock Repurchase Program

[0000950123-11-018429:mdna:123]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have
authorized open market repurchase transactions of up to 30 million shares of our common stock. We
currently have the authority to purchase an additional 2.0 million shares of our common stock under
the plan approved by the Board of Directors on April 14, 2008. For the years 2010, 2009 and 2008,
we repurchased 0.7 million shares, 0.8 million shares and 3.1 million shares, respectively, for a
cost of $18.3 million, $15.9 million and $63.6 million, respectively, at a weighted average price
of $25.12, $21.05 and $20.65 per share, respectively.

[0000950123-11-018429:mdna:124]
To accommodate employee stock option exercises, we issued 1.5 million shares of treasury stock for
$24.9 million during the year ended December 31, 2010, 0.9 million shares of treasury stock for
$13.5 million during the year ended December 31, 2009, and 0.3 million shares of treasury stock for
$3.7 million during the year ended December 31, 2008.

[0000950123-11-018429:mdna:125]
Off-Balance Sheet Arrangements and Contractual Obligations

[0000950123-11-018429:mdna:126]
We have various contractual obligations and commercial commitments. The following table sets
forth, in millions, the annual payments we are required to make under contractual cash obligations
and other commercial commitments at December 31, 2010.

[0000950123-11-018429:mdna:127]
Contractual Obligations

[0000950123-11-018429:mdna:128]
| (In millions) |  | Total |  |  | 2011 |  |  | 2012 |  |  | 2013 |  |  | 2014 |  |  | After 2014 |  |
| Long-term debt |  | $ | 48.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 48.0 |  |
| Interest on long-term debt |  |  | 21.6 |  |  |  | 2.4 |  |  |  | 2.4 |  |  |  | 2.4 |  |  |  | 2.4 |  |  |  | 12.0 |  |
| Purchase obligations |  |  | 69.5 |  |  |  | 66.7 |  |  |  | 1.8 |  |  |  | 0.8 |  |  |  | 0.2 |  |  |  | — |  |
| Operating lease obligations |  |  | 4.8 |  |  |  | 1.5 |  |  |  | 1.1 |  |  |  | 0.7 |  |  |  | 0.7 |  |  |  | 0.8 |  |
| Investment commitments |  |  | 0.5 |  |  |  | — |  |  |  | 0.4 |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |
| Totals |  | $ | 144.4 |  |  | $ | 70.6 |  |  | $ | 5.7 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |  | $ | 60.8 |  |

[0000950123-11-018429:mdna:129]
We are required to make payments necessary to pay the interest on the Taxable Revenue Bond, Series
1995, as amended, currently outstanding in the aggregate principal amount of $48.0 million. The
bond matures on January 1, 2020, and bears interest at the rate of 5% per annum. Included in
long-term investments are $48.3 million of restricted funds, which is a collateral deposit against
the principal amount of this bond.

[0000950123-11-018429:mdna:130]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
have contributed $8.0 million as of December 31, 2010, of which $7.4 million has been applied to
these commitments. See Note 3 of Notes to Consolidated Financial Statements for additional
information.

[0000950123-11-018429:mdna:131]
We also have obligations related to uncertain income tax positions that have not been included in
the table above due to the uncertainty of when the related expense will be recognized. See Note 7
of Notes to Consolidated Financial Statements for additional information.

[0000950123-11-018429:mdna:132]
We do not have off-balance sheet financing arrangements and have not engaged in any related party
transactions or arrangements with unconsolidated entities or other persons that are reasonably
likely to materially affect liquidity or the availability of or requirements for capital resources.
See Notes 6 and 10 of Notes to Consolidated Financial Statements for additional information on our
revenue bond and operating lease obligations, respectively.

[0000950123-11-018429:mdna:133]
Effect of Recent Accounting Pronouncements

[0000950123-11-018429:mdna:134]
In October 2009, the Financial Accounting Standards Board (FASB) issued Update No. 2009-13,
which amends the Revenue Recognition topic of the FASB Accounting Standards Codification (ASC).
This update provides amendments to the criteria in Subtopic 605-25 of the ASC for separating
consideration in multiple-deliverable arrangements. As a result of those amendments,
multiple-deliverable arrangements will be separated in more circumstances than under existing U.S.
GAAP. The amendments establish a selling price hierarchy for determining the selling price of a
deliverable and will replace the term fair value in the revenue allocation guidance with selling
price to clarify that the allocation of revenue is based on entity-specific assumptions rather than
assumptions of a marketplace participant. The amendments will also eliminate the residual method
of allocation and require that arrangement consideration be allocated at the inception of the
arrangement to all deliverables using the relative selling price method and will require that a
vendor determine its best estimate of selling price in a manner that is consistent with that used
to determine the price to sell the deliverable on a standalone basis. These amendments will be
effective prospectively for revenue arrangements entered into or materially modified in fiscal
years beginning on or after June 15, 2010, with early adoption permitted. We do not expect the
adoption of this amendment will have a material impact on our consolidated results of operations or
financial condition.

[0000950123-11-018429:mdna:135]
In October 2009, the FASB issued Update No. 2009-14, which amends the Software topic of the ASC.
The amendments in this update change the accounting model for revenue arrangements that include
both tangible products and software elements. Tangible products containing software components and
non-software components that function together to deliver the tangible product’s essential
functionality is no longer within the scope of the software revenue guidance in Subtopic 985-605 of
the ASC. In addition, the amendments in this update require that hardware components of a tangible
product containing software components always be excluded from the software revenue guidance. In
that regard, the amendments provide additional guidance on how to determine which software, if any,
relating to the tangible product also would be excluded from the scope of the software revenue
guidance. The amendments also provide guidance on how a vendor should allocate arrangement
consideration to deliverables in an arrangement that includes both tangible products and software.
The amendments also provide further guidance on how to allocate arrangement consideration when an
arrangement includes deliverables both included and excluded from the scope of the software revenue
guidance. These amendments will be effective prospectively for revenue arrangements entered into
or materially modified in fiscal years beginning on or after June 15, 2010, with early adoption
permitted. We do not expect the adoption of this amendment will have a material impact on our
consolidated results of operations or financial condition.

[0000950123-11-018429:mdna:136]
During 2010, we adopted the following accounting standards, which had no material effect on our
consolidated results of operations or financial condition:

[0000950123-11-018429:mdna:137]
In January 2010, the FASB issued Update No. 2010-06, which amends the Fair Value Measurements and
Disclosures topic of the ASC. The amendments in this update require new disclosures about
transfers in and out of Level 1 and Level 2 fair value measurements and the activity in Level 3
fair value measurements and, in addition, clarify existing disclosures required for levels of
disaggregation and inputs and valuation techniques. These amendments are effective for interim and
annual reporting periods beginning after December 15, 2009, except for the disclosures about
activity in Level 3 fair value measurements, which is effective for fiscal years beginning after
December 15, 2010, and for interim periods within those fiscal years. We adopted this amendment
during the period ended March 31, 2010, and we have provided the disclosures required for the three
and twelve months ended December 31, 2010.

[0000950123-11-018429:mdna:138]
In February 2010, the FASB issued Update No. 2010-09, which amends the Subsequent Events topic of
the ASC. The amendments in this update require entities that are SEC filers to evaluate subsequent
events through the date that the financial statements are issued. Additionally, SEC filers are no
longer required to disclose the date through which subsequent events were evaluated. The
amendments in this update were effective upon issuance. We adopted this amendment during the
period ended March 31, 2010.

[0000950123-11-018429:mdna:139]
Subsequent Events

[0000950123-11-018429:mdna:140]
On January 18, 2011, the Board declared a quarterly cash dividend of $0.09 per common share to
be paid to stockholders of record at the close of business on February 3, 2011. The quarterly
dividend payment was $5.8 million and was paid on February 17, 2011.
