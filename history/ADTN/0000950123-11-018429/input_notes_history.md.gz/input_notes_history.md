# ADTN note change history — 0000950123-10-069734 → 0000950123-10-099391


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2010-11-02):
[0000950123-10-099391:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.0 million as of September 30, 2010, of which $7.5 million has been applied to
   these commitments. See Note 4 of Notes to Consolidated Financial Statements for additional
   information.
  (was, 2010-07-29, similarity 0.8757):
[0000950123-10-069734:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.0 million as of June 30, 2010, of which $7.5 million has been applied to these
   commitments. See Note 4 of Notes to Consolidated Financial Statements for additional information.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2010-11-02):
[0000950123-10-099391:note_history:2]
In October 2009, the Financial Accounting Standards Board (FASB) issued Update No. 2009-13, which
   amends the Revenue Recognition topic of the FASB Accounting Standards Codification (ASC). This
   update provides amendments to the criteria in Subtopic 605-25 of the ASC for separating
   consideration in multiple-deliverable arrangements. As a result of those amendments,
   multiple-deliverable arrangements will be separated in more circumstances than under existing U.S.
   GAAP. The amendments establish a selling price hierarchy for determining the selling price of a
   deliverable and will replace the term fair value in the revenue allocation guidance with selling
   price to clarify that the allocation of revenue is based on entity-specific assumptions rather than
   assumptions of a marketplace participant. The amendments will also eliminate the residual method
   of allocation and require that arrangement consideration be allocated at the inception of the
   arrangement to all deliverables using the relative selling price method and will require that a
   vendor determine its best estimate of selling price in a manner that is consistent with that used
   to determine the price to sell the deliverable on a standalone basis. These amendments will be
   effective prospectively for revenue arrangements entered into or materially modified in fiscal
   years beginning on or after June 15, 2010, with early adoption permitted. We do not expect the
   adoption of this amendment will have a material impact on our consolidated results of operations or
   financial condition.
  (was, 2010-07-29, similarity 0.9903):
[0000950123-10-069734:note_history:2]
In October 2009, the Financial Accounting Standards Board (FASB) issued Update No. 2009-13, which
   amends the Revenue Recognition topic of the FASB Accounting Standards Codification (Codification).
   This update provides amendments to the criteria in Subtopic 605-25 of the Codification for
   separating consideration in multiple-deliverable arrangements. As a result of those amendments,
   multiple-deliverable arrangements will be separated in more circumstances than under existing U.S.
   GAAP. The amendments establish a selling price hierarchy for determining the selling price of a
   deliverable and will replace the term fair value in the revenue allocation guidance with selling
   price to clarify that the allocation of revenue is based on entity-specific assumptions rather than
   assumptions of a marketplace participant. The amendments will also eliminate the residual method
   of allocation and require that arrangement consideration be allocated at the inception of the
   arrangement to all deliverables using the relative selling price method and will require that a
   vendor determine its best estimate of selling price in a manner that is consistent with that used
   to determine the price to sell the deliverable on a standalone basis. These amendments will be
   effective prospectively for revenue arrangements entered into or materially modified in fiscal
   years beginning on or after June 15, 2010, with early adoption permitted. We do not expect the
   adoption of this amendment will have a material impact on our consolidated results of operations or
   financial condition.

- changed (2010-11-02):
[0000950123-10-099391:note_history:3]
In October 2009, the FASB issued Update No. 2009-14, which amends the Software topic of the ASC.
   The amendments in this update change the accounting model for revenue arrangements that include
   both tangible products and software elements. Tangible products containing software components and
   non-software components that function together to deliver the tangible product’s essential
   functionality is no longer within the scope of the software revenue guidance in Subtopic 985-605 of
   the ASC. In addition, the amendments in this update require that hardware components of a tangible
   product containing software components always be excluded from the software revenue guidance. In
   that regard, the amendments provide additional guidance on how to determine which software, if any,
   relating to the tangible product also would be excluded from the scope of the software revenue
   guidance. The amendments also provide
   guidance on how a vendor should allocate arrangement consideration to deliverables in an
   arrangement that includes both tangible products and software. The amendments also provide further
   guidance on how to allocate arrangement consideration when an arrangement includes deliverables
   both included and excluded from the scope of the software revenue guidance. These amendments will
   be effective prospectively for revenue arrangements entered into or materially modified in fiscal
   years beginning on or after June 15, 2010, with early adoption permitted. We do not expect the
   adoption of this amendment will have a material impact on our consolidated results of operations or
   financial condition.
  (was, 2010-07-29, similarity 0.9906):
[0000950123-10-069734:note_history:3]
In October 2009, the FASB issued Update No. 2009-14, which amends the Software topic of the
   Codification. The amendments in this update change the accounting model for revenue arrangements
   that include both tangible products and software elements. Tangible products containing software
   components and non-software components that function together to deliver the tangible product’s
   essential functionality is no longer within the scope of the software revenue guidance in Subtopic
   985-605 of the Codification. In addition, the amendments in this update require that hardware
   components of a tangible product containing software components always be excluded from the
   software revenue guidance. In that regard, the amendments provide additional guidance on how to
   determine which software, if any, relating to the tangible product also would be excluded from the
   scope of the software revenue guidance. The amendments also provide guidance on how a vendor
   should allocate arrangement consideration to deliverables in an arrangement that includes both
   tangible products and software. The amendments also provide further guidance on how to allocate
   arrangement consideration when an arrangement includes deliverables both included and excluded from
   the scope of the software revenue guidance. These amendments will be effective prospectively for
   revenue arrangements entered into or materially modified in fiscal years beginning on or after June
   15, 2010, with early adoption permitted. We do not expect the adoption of this amendment will have
   a material impact on our consolidated results of operations or financial condition.

- changed (2010-11-02):
[0000950123-10-099391:note_history:4]
During the nine months ended September 30, 2010, we adopted the following accounting standards,
   which had no material effect on our consolidated results of operations or financial condition:
  (was, 2010-07-29, similarity 0.9558):
[0000950123-10-069734:note_history:4]
During the six months ended June 30, 2010, we adopted the following accounting standards,
   which had no material effect on our consolidated results of operations or financial condition:

- changed (2010-11-02):
[0000950123-10-099391:note_history:5]
In January 2010, the FASB issued Update No. 2010-06, which amends the Fair Value Measurements and
   Disclosures topic of the ASC. The amendments in this update require new disclosures about
   transfers in and out of Level 1 and Level 2 fair value measurements and the activity in Level 3
   fair value measurements and, in addition, clarify existing disclosures required for levels of
   disaggregation and inputs and valuation techniques. These amendments are effective for interim and
   annual reporting periods beginning after December 15, 2009, except for the disclosures about
   activity in Level 3 fair value measurements, which is effective for fiscal years beginning after
   December 15, 2010, and for interim periods within those fiscal years. We adopted this amendment
   for the period ended March 31, 2010, and we have provided the disclosures required for the period
   ended September 30, 2010.
  (was, 2010-07-29, similarity 0.9743):
[0000950123-10-069734:note_history:5]
In January 2010, the FASB issued Update No. 2010-06, which amends the Fair Value Measurements and
   Disclosures topic of the Codification. The amendments in this update require new disclosures about
   transfers in and out of Level 1 and Level 2 fair value measurements and the activity in Level 3
   fair value measurements and, in addition, clarify existing disclosures required for levels of
   disaggregation and inputs and valuation techniques. These amendments will be effective for interim
   and annual reporting periods beginning after December 15, 2009, except for the disclosures about
   activity in Level 3 fair value measurements, which is effective for fiscal years beginning after
   December 15, 2010, and for interim periods within those fiscal years. We adopted this amendment
   for the period ended March 31, 2010, and we have provided the disclosures required for the period
   ended June 30, 2010.

- changed (2010-11-02):
[0000950123-10-099391:note_history:6]
In February 2010, the FASB issued Update No. 2010-09, which amends the Subsequent Events topic of
   the ASC. The amendments in this update require entities that are SEC filers to evaluate subsequent
   events through the date that the financial statements are issued. Additionally, SEC filers are no
   longer required to disclose the date through which subsequent events were evaluated. The
   amendments in this update were effective upon issuance. We adopted this amendment for the period
   ended March 31, 2010, and we have provided the disclosures required for the period ended September
   30, 2010.
  (was, 2010-07-29, similarity 0.9684):
[0000950123-10-069734:note_history:6]
In February 2010, the FASB issued Update No. 2010-09, which amends the Subsequent Events topic of
   the Codification. The amendments in this update require entities that are SEC filers to evaluate
   subsequent events through the date that the financial statements are issued. Additionally, SEC
   filers are no longer required to disclose the date through which subsequent events were evaluated.
   The amendments in this update were effective upon issuance. We adopted this amendment for the
   period ended March 31, 2010, and we have provided the disclosures required for the period ended
   June 30, 2010.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2010-11-02):
[0000950123-10-099391:note_history:7]
At September 30, 2010, we held the following securities and investments, recorded at either fair
   value or cost.
  (was, 2010-07-29, similarity 0.9463):
[0000950123-10-069734:note_history:7]
At June 30, 2010, we held the following securities and investments, recorded at either fair value
   or cost.

- changed (2010-11-02):
[0000950123-10-099391:note_history:8]
At September 30, 2010, we held $3.9 million of deferred compensation plan assets, carried at fair
   value.
  (was, 2010-07-29, similarity 0.9412):
[0000950123-10-069734:note_history:8]
At June 30, 2010, we held $3.5 million of deferred compensation plan assets, carried at fair value.

- changed (2010-11-02):
[0000950123-10-099391:note_history:9]
At September 30, 2010, we held $110.3 million of corporate bonds, including a $1.5 million bond
   that has been issued by one bank and is guaranteed by the Federal Deposit Insurance Corporation
   (FDIC) under the Temporary Liquidity Guarantee Program (TLGP). These bonds are classified as
   available-for-sale and had an average duration of 2.2 years at September 30, 2010. At September
   30, 2010, approximately 4% of our corporate bond portfolio had a credit rating of AAA, 11% had a
   credit rating of AA, 51% had a credit rating of A, and 34% had a credit rating of BBB.
  (was, 2010-07-29, similarity 0.7724):
[0000950123-10-069734:note_history:9]
At June 30, 2010, we held $76.7 million of corporate bonds. Of this amount, we held $41.2 million
   in bonds that have been issued by various banks that have been guaranteed by the Federal Deposit
   Insurance Corporation (FDIC) under the Temporary Liquidity Guarantee Program (TLGP). These bonds
   are classified as available-for-sale and had an average duration of 2.0 years at June 30, 2010. At
   June 30, 2010, approximately 54% of our corporate bond portfolio had a credit rating of AAA, 10%
   had a credit rating of AA, 21% had a credit rating of A, and 15% had a credit rating of BBB.

- added (2010-11-02):
[0000950123-10-099391:note_history:10]
At September 30, 2010, we held $83.8 million of municipal fixed-rate bonds. These bonds are
   classified as available-for-sale investments and had an average duration of 1.1 years at September
   30, 2010. At September 30, 2010, approximately 19% of our municipal fixed-rate bond portfolio had
   a credit rating of AAA, 69% had a credit rating of AA, and 12% had
   a credit rating of A. Because our bond portfolio has a high quality rating and contractual
   maturities of a short duration, we are able to obtain prices for these bonds derived from
   observable market inputs, or for similar securities traded in an active market, on a daily basis.

- added (2010-11-02):
[0000950123-10-099391:note_history:11]
At September 30, 2010, we held $107.4 million of municipal variable rate demand notes, all of which
   are classified as available-for-sale short-term investments. At September 30, 2010, 33% of our
   municipal variable rate demand notes had a credit rating of AAA, 59% had a credit rating of AA, 8%
   had a credit rating of A, and all contained put options of seven days. Despite the long-term
   nature of their stated contractual maturities, we routinely buy and sell these securities and we
   believe that we have the ability to quickly liquidate them. Our investments in these securities
   are recorded at fair value, and the interest rates reset every seven days. We believe we have the
   ability to sell our variable rate demand notes to the remarketing agent, tender agent or issuer at
   par value plus accrued interest in the event we decide to liquidate our investment in a particular
   variable rate demand note. At September 30, 2010, approximately 32% of our variable rate demand
   notes were supported by letters of credit from banks that we believe to be in good financial
   condition. The remaining 68% of our variable rate demand notes were supported by standby purchase
   agreements. As a result of these factors, we had no cumulative gross unrealized holding gains
   (losses) or gross realized gains (losses) from these investments. All income generated from these
   investments was recorded as interest income. We have not been required to record any losses
   relating to municipal variable rate demand notes.

- changed (2010-11-02):
[0000950123-10-099391:note_history:12]
At September 30, 2010, we held $0.7 million of a fixed income bond fund.
  (was, 2010-07-29, similarity 0.9106):
[0000950123-10-069734:note_history:12]
At June 30, 2010, we held $0.7 million of a fixed income bond fund.

- added (2010-11-02):
[0000950123-10-099391:note_history:13]
At September 30, 2010, we held $38.6 million of marketable equity securities, including a single
   security, of which we held 1.6 million shares, carried at a fair value of $26.6 million. We sold
   416 thousand shares of this security during the nine months ended September 30, 2010. The sales
   resulted in proceeds of $6.2 million and a realized gain of $6.0 million. This single security
   traded approximately 1.1 million shares per day in the first nine months of 2010 in an active
   market on a European stock exchange. This single security comprises $26.1 million of the gross
   unrealized gains included in the fair value of our marketable equity securities at September 30,
   2010. The remaining $2.5 million of gross unrealized gains and $0.3 million of gross unrealized
   losses at September 30, 2010 were spread among 397 equity securities.

- changed (2010-11-02):
[0000950123-10-099391:note_history:14]
At September 30, 2010, we held a $48.3 million restricted certificate of deposit, which is carried
   at cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At September 30, 2010, the estimated fair value of the Bond was approximately
   $47.1 million, based on a debt security with a comparable interest rate and maturity and a Standard
   and Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.
  (was, 2010-07-29, similarity 0.9848):
[0000950123-10-069734:note_history:14]
At June 30, 2010, we held a $48.3 million restricted certificate of deposit, which is carried at
   cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At June 30, 2010, the estimated fair value of the Bond was approximately $45.8
   million, based on a debt security with a comparable interest rate and maturity and a Standard and
   Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.

- added (2010-11-02):
[0000950123-10-099391:note_history:15]
At September 30, 2010, we held $2.2 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.2 million at September 30, 2010, based on unobservable inputs including information supplied by
   the company and the fund managers. We have committed to invest up to an aggregate of $7.9 million
   in the two private equity funds, and we have contributed $8.0 million as of September 30, 2010, of
   which $7.5 million has been applied toward these commitments. As of September 30, 2010, we have
   received distributions related to these two private equity funds of $6.7 million, of which $0.9
   million was recorded as a realized investment gain. These investments are carried at cost, net of
   distributions, with distributions in excess of our investment recorded as a realized investment
   gain. The duration of each of these commitments is ten years with $0.1 million expiring in 2010
   and $0.3 million expiring in 2012. We have not been required to record any impairment losses
   related to these investments during the nine months ended September 30, 2010.

- changed (2010-11-02):
[0000950123-10-099391:note_history:16]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to
   the following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $43 thousand during the nine
   months ending September 30, 2010 related to five marketable equity securities. For the nine months
   ended September 30, 2009, we recorded an other-than-temporary impairment charge of $2.0 million
   related to 117 marketable equity securities. In addition to the impairment charge we recorded on
   our marketable equity securities, we recorded an impairment charge of $0.4 million related to our
   investment in a fixed income bond fund and $0.5 million related to our deferred compensation plan
   assets during the first nine months of 2009 as a result of similar reviews. There were no
   impairment charges related to the fixed income bond fund or deferred compensation plan assets
   during the nine months ended September 30, 2010.
  (was, 2010-07-29, similarity 0.9255):
[0000950123-10-069734:note_history:16]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $42 thousand during the six
   months ending June 30, 2010 related to three marketable equity securities. For the six months
   ended June 30, 2009, we recorded an other-than-temporary impairment charge of $2.0 million related
   to 107 publicly traded equity securities. In addition to the impairment charge we recorded on our
   marketable equity securities, we recorded an impairment charge of $0.4 million related to our
   investment in a fixed income bond fund and $0.5 million related to our deferred compensation plan
   during the first six months of 2009 as a result of similar reviews. There were no impairment
   charges related to the fixed income bond fund or deferred compensation plan assets during the six
   months ended June 30, 2010.

- changed (2010-11-02):
[0000950123-10-099391:note_history:17]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have
   categorized our cash equivalents held in money market funds and our investments held at fair value
   into a three-level fair value hierarchy based on the priority of the inputs to the valuation
   technique for the cash equivalents and investments as follows: Level 1 — Values based on
   unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 — Values
   based on quoted prices in markets that are not active or model inputs that are observable either
   directly or indirectly; Level 3 — Values based on prices or valuation techniques that require
   inputs that are both unobservable and significant to the overall fair value measurement. These
   inputs include information supplied by issuers.
  (was, 2010-07-29, similarity 0.9834):
[0000950123-10-069734:note_history:17]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB Codification, we
   have categorized our cash equivalents held in money market funds and our investments held at fair
   value into a three-level fair value hierarchy based on the priority of the inputs to the valuation
   technique for the cash equivalents and investments as follows: Level 1 — Values based on
   unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 — Values
   based on quoted prices in markets that are not active or model inputs that are observable either
   directly or indirectly; Level 3 — Values based on prices or valuation techniques that require
   inputs that are both unobservable and significant to the overall fair value measurement. These
   inputs include information supplied by investees.

- changed (2010-11-02):
[0000950123-10-099391:note_history:18]
|  |  | Fair Value Measurements at September 30, 2010 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 12,569 |  |  | $ | 12,569 |  |  | $ | — |  |  | $ | — |  |
| Deferred compensation plan assets |  |  | 3,911 |  |  |  | 3,911 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 110,348 |  |  |  | — |  |  |  | 110,348 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 83,782 |  |  |  | — |  |  |  | 83,782 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 107,420 |  |  |  | — |  |  |  | 107,420 |  |  |  | — |  |
| Fixed income bond fund |  |  | 742 |  |  |  | 742 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities — technology industry |  |  | 27,802 |  |  |  | 27,802 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities — other |  |  | 10,767 |  |  |  | 10,767 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 344,772 |  |  |  | 43,222 |  |  |  | 301,550 |  |  |  | — |  |
| Total |  | $ | 357,341 |  |  | $ | 55,791 |  |  | $ | 301,550 |  |  | $ | — |  |
  (was, 2010-07-29, similarity 0.985):
[0000950123-10-069734:note_history:18]
|  |  | Fair Value Measurements at December 31, 2009 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 18,370 |  |  | $ | 18,370 |  |  | $ | — |  |  | $ | — |  |
| Deferred compensation plan assets |  |  | 3,424 |  |  |  | 3,424 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,414 |  |  |  | — |  |  |  | 20,414 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 141,285 |  |  |  | — |  |  |  | 141,285 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 84,359 |  |  |  | — |  |  |  | 84,359 |  |  |  | — |  |
| Fixed income bond fund |  |  | 1,163 |  |  |  | 1,163 |  |  |  | — |  |  |  | — |  |
| Available-for-sale equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 23,491 |  |  |  | 23,491 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 10,044 |  |  |  | 10,044 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 284,180 |  |  |  | 38,122 |  |  |  | 246,058 |  |  |  | — |  |
| Total |  | $ | 302,550 |  |  | $ | 56,492 |  |  | $ | 246,058 |  |  | $ | — |  |

- changed (2010-11-02):
[0000950123-10-099391:note_history:19]
|  |  | Fair Value Measurements at December 31, 2009 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 18,370 |  |  | $ | 18,370 |  |  | $ | — |  |  | $ | — |  |
| Deferred compensation plan assets |  |  | 3,424 |  |  |  | 3,424 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,414 |  |  |  | — |  |  |  | 20,414 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 141,285 |  |  |  | — |  |  |  | 141,285 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 84,359 |  |  |  | — |  |  |  | 84,359 |  |  |  | — |  |
| Fixed income bond fund |  |  | 1,163 |  |  |  | 1,163 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities — technology industry |  |  | 23,491 |  |  |  | 23,491 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities — other |  |  | 10,044 |  |  |  | 10,044 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 284,180 |  |  |  | 38,122 |  |  |  | 246,058 |  |  |  | — |  |
| Total |  | $ | 302,550 |  |  | $ | 56,492 |  |  | $ | 246,058 |  |  | $ | — |  |
  (was, 2010-07-29, similarity 0.9831):
[0000950123-10-069734:note_history:19]
|  |  | Fair Value Measurements at June 30, 2010 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 9,043 |  |  | $ | 9,043 |  |  | $ | — |  |  | $ | — |  |
| Deferred compensation plan assets |  |  | 3,510 |  |  |  | 3,510 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 76,725 |  |  |  | — |  |  |  | 76,725 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 113,321 |  |  |  | — |  |  |  | 113,321 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 83,643 |  |  |  | — |  |  |  | 83,643 |  |  |  | — |  |
| Fixed income bond fund |  |  | 710 |  |  |  | 710 |  |  |  | — |  |  |  | — |  |
| Available-for-sale equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 22,726 |  |  |  | 22,726 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 9,620 |  |  |  | 9,620 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 310,255 |  |  |  | 36,566 |  |  |  | 273,689 |  |  |  | — |  |
| Total |  | $ | 319,298 |  |  | $ | 45,609 |  |  | $ | 273,689 |  |  | $ | — |  |

- changed (2010-11-02):
[0000950123-10-099391:note_history:20]
As of September 30, 2010 and December 31, 2009, the fair value of the investments in
   available-for-sale Level 2 corporate bonds and municipal fixed-rate bonds was $194.1 million and
   $161.7 million, respectively. The fair value of these securities is calculated using a weighted
   average market price for each security. Market prices are obtained from a variety of industry
   standard data providers, security master files from large financial institutions, and other
   third-party sources. These multiple market prices are used as inputs into a
   distribution-curve-based algorithm to determine the daily market value of each security.
  (was, 2010-07-29, similarity 0.9893):
[0000950123-10-069734:note_history:20]
As of June 30, 2010 and December 31, 2009, the fair value of the investments in available-for-sale
   Level 2 corporate bonds and municipal fixed-rate bonds was $190.0 million and $161.7 million,
   respectively. The fair value of these securities is calculated using a weighted average market
   price for each security. Market prices are obtained from a variety of industry standard data
   providers, security master files from large financial institutions, and other third-party sources.
   These multiple market prices are used as inputs into a distribution-curve-based algorithm to
   determine the daily market value of each security.

- changed (2010-11-02):
[0000950123-10-099391:note_history:21]
As of September 30, 2010 and December 31, 2009, the fair value of the investments in
   available-for-sale Level 2 municipal variable rate demand notes was $107.4 million and $84.4
   million, respectively. These securities have a structure that implies a standard expected market
   price. The frequent interest rate resets make it reasonable to expect the price to stay at par.
   These securities are priced at the expected market price.
  (was, 2010-07-29, similarity 0.984):
[0000950123-10-069734:note_history:21]
As of June 30, 2010 and December 31, 2009, the fair value of the investments in available-for-sale
   Level 2 municipal variable rate demand notes was $83.6 million and $84.4 million, respectively.
   These securities have a structure that implies a standard expected market price. The frequent
   interest rate resets make it reasonable to expect the price to stay at par. These securities are
   priced at the expected market price.

- removed (2010-11-02):
[0000950123-10-069734:note_history:22]
At June 30, 2010, we held $113.3 million of municipal fixed-rate bonds. At June 30, 2010,
   approximately 39% of our municipal fixed-rate bond portfolio had a credit rating of AAA, 52% had a
   credit rating of AA, and 9% had a credit rating of A. These bonds are classified as
   available-for-sale investments and had an average duration of 1.0 years at June 30, 2010. Because
   our bond portfolio has a high quality rating and contractual maturities of a short duration, we are
   able to obtain prices for these bonds derived from observable market inputs, or for similar
   securities traded in an active market, on a daily basis.

- removed (2010-11-02):
[0000950123-10-069734:note_history:23]
At June 30, 2010, we held $83.6 million of municipal variable rate demand notes, all of which are
   classified as available-for-sale short-term investments. At June 30, 2010, 24% of our municipal
   variable rate demand notes had a credit rating of AAA, 64% had a credit rating of AA, 12% had a
   credit rating of A, and all contained put options of seven days. Despite the long-term nature of
   their stated contractual maturities, we believe that we have the ability to quickly liquidate these
   securities. Our investments in these securities are recorded at fair value, and the interest rates
   reset every seven days. We believe we have the ability to sell our variable rate demand notes to
   the remarketing agent, tender agent or issuer at par value plus accrued interest in the event we
   decide to liquidate our investment in a particular variable rate demand note. Approximately 41% of
   our variable rate demand notes are supported by letters of credit from banks that we believe to be
   in good financial condition. The remaining 59% of our variable rate demand notes are supported by
   standby purchase agreements. As a result of these factors, we had no cumulative gross unrealized
   holding gains (losses) or gross realized gains (losses) from these investments. All income
   generated from these investments was recorded as interest income. We have not been required to
   record any losses relating to municipal variable rate demand notes.

- removed (2010-11-02):
[0000950123-10-069734:note_history:24]
At June 30, 2010, we held $32.3 million of marketable equity securities, including a single
   security, of which we held 1.8 million shares, carried at a fair value of $21.6 million. We sold
   268 thousand shares of this security during the six months ended June 30, 2010. The sale resulted
   in proceeds of $4.1 million and a realized gain of $4.0 million. This single security traded
   approximately 1.3 million shares per day in the first six months of 2010 in an active market on a
   European stock exchange. This single security comprises $21.0 million of the gross unrealized
   gains included in the fair value of our marketable equity securities at June 30, 2010. The
   remaining $1.6 million of gross unrealized gains and $0.7 million of gross unrealized losses at
   June 30, 2010 were spread among 395 equity securities.

- removed (2010-11-02):
[0000950123-10-069734:note_history:25]
At June 30, 2010, we held $2.3 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.2 million at June 30, 2010, based on unobservable inputs including information supplied by the
   company and the fund managers. We have committed to invest up to an aggregate of $7.9 million in
   the two private equity funds, and we have contributed $8.0 million as of June 30, 2010, of which
   $7.5 million has been applied toward these commitments. As of June 30, 2010, we have received
   distributions related to these two private equity funds of $6.6 million, of which $0.8 million was
   recorded as a realized investment gain. These investments are carried at cost, net of
   distributions, with distributions in excess of our investment recorded as a realized investment
   gain. The duration of each of these commitments is ten years with $0.1 million expiring in 2010
   and $0.3 million expiring in 2012. We have not been required to record any impairment losses
   related to these investments during the six months ended June 30, 2010.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2010-11-02):
[0000950123-10-099391:note_history:26]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three and nine month periods ended September 30, 2010 and 2009, we incurred fees of
   $10 thousand per month for these legal services.
  (was, 2010-07-29, similarity 0.9257):
[0000950123-10-069734:note_history:26]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three and six month periods ended June 30, 2010 and 2009, we incurred fees of $10
   thousand per month for these legal services.


## us-gaap:ScheduleOfSubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2010-11-02):
[0000950123-10-099391:note_history:27]
On October 12, 2010, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on October 28,
   2010. The payment date will be November 11, 2010. The quarterly dividend payment will be
   approximately $5.7 million. In July 2003, our Board of Directors elected to begin declaring
   quarterly dividends on our common stock considering the favorable tax treatment of dividends and
   adequate levels of Company liquidity.
  (was, 2010-07-29, similarity 0.9628):
[0000950123-10-069734:note_history:27]
On July 13, 2010, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on July 29,
   2010. The payment date will be August 12, 2010. The quarterly dividend payment will be
   approximately $5.6 million. In July 2003, our Board of Directors elected to begin declaring
   quarterly dividends on our common stock considering the favorable tax treatment of dividends and
   adequate levels of Company liquidity.
