# ADTN notes — 0000950123-11-018429


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950123-11-018429:notes:1]
Note 1 — Nature of Business and Summary of Significant Accounting Policies

[0000950123-11-018429:notes:2]
ADTRAN, Inc. designs, manufactures, markets and services network access solutions for
   communications networks. Our solutions are widely deployed by providers of communications services
   (serviced by our Carrier Networks Division), and small and mid-sized enterprises (SMEs)
   (serviced by our Enterprise Networks Division), and enable voice, data, video and Internet
   communications across wireline and wireless networks. Many of these solutions are currently in use
   by every major United States service provider and many global ones, as well as by many public,
   private and governmental organizations worldwide.

[0000950123-11-018429:notes:3]
Principles of Consolidation

[0000950123-11-018429:notes:4]
Our consolidated financial statements include ADTRAN and its wholly owned subsidiaries. All
   significant inter-company accounts and transactions have been eliminated in consolidation.

[0000950123-11-018429:notes:5]
Cash and Cash Equivalents

[0000950123-11-018429:notes:6]
Cash and cash equivalents represent demand deposits, money market funds, and short-term investments
   classified as available for sale with original maturities of three months or less. We maintain
   depository investments with certain financial institutions. Although these depository investments
   may exceed government insured depository limits, we have evaluated the credit worthiness of these
   applicable financial institutions, and determined the risk of material financial loss due to
   exposure of such credit risk to be minimal. As of December 31, 2010, $22.0 million of our cash and
   cash equivalents, primarily certain domestic money market funds and foreign depository accounts,
   were in excess of government provided insured depository limits.

[0000950123-11-018429:notes:7]
Financial Instruments

[0000950123-11-018429:notes:8]
The carrying amounts reported in the consolidated balance sheets for cash and cash equivalents,
   accounts receivable, and accounts payable approximate fair value due to the immediate or short-term
   maturity of these financial instruments. The carrying amount reported for bonds payable was $48.0
   million compared to an estimated fair value of $42.5 million, based on a debt security with a
   comparable interest rate and maturity and a Standard & Poor’s credit rating of A+.

[0000950123-11-018429:notes:9]
Investments with maturities beyond one year, such as our municipal variable rate demand notes, may
   be classified as short-term based on their highly liquid nature and because such marketable
   securities represent the investment of cash that is available for current operations. At December
   31, 2010, 29% of our municipal variable rate demand notes had a credit rating of AAA, 63% had a
   credit rating of AA, 8% had a credit rating of A, and all contained put options of seven days.
   Despite the long-term nature of their stated contractual maturities, we routinely buy and sell
   these securities and we believe that we have the ability to quickly liquidate them. Our
   investments in these securities are recorded at fair value, and the interest rates reset every
   seven days. We believe we have the ability to sell our variable rate demand notes to the
   remarketing agent, tender agent, or issuer at par value plus accrued interest in the event we
   decide to liquidate our investment in a particular variable rate demand note. At December 31,
   2010, approximately 28% of our variable rate demand notes were supported by letters of credit from
   banks that we believe to be in good financial condition. The remaining 72% of our variable rate
   demand notes were supported by standby purchase agreements. As a result of these factors, we had
   no cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from these
   investments at December 31, 2010. All income generated from these investments was recorded as
   interest income. We have not been required to record any losses relating to municipal variable
   rate demand notes.

[0000950123-11-018429:notes:10]
Long-term investments represent a restricted certificate of deposit, municipal fixed-rate bonds,
   corporate bonds, a fixed income bond fund, marketable equity securities, and other equity
   investments. Marketable equity securities are reported at fair value as determined by the most
   recently traded price of the securities at the balance sheet date, although the securities may not
   be readily marketable due to the size of the available market. Unrealized gains and losses, net of
   tax, are reported as a separate component of stockholders’ equity. Realized gains and losses on
   sales of securities are computed under the specific identification method and are included in
   current income. We periodically review our investment portfolio for investments considered to have
   sustained an other-than-temporary decline in value. Impairment charges for other-than-temporary
   declines in value are recorded as realized losses in the accompanying consolidated statements of
   income. All of our investments at December 31, 2010 and 2009 are classified as available-for-sale
   (see Note 3).

[0000950123-11-018429:notes:11]
Accounts Receivable

[0000950123-11-018429:notes:12]
We record accounts receivable at net realizable value. Prior to issuing payment terms to a new
   customer, we perform a detailed credit review of the customer. Credit limits are established for
   each new customer based on the results of this credit review. Payment terms are established for
   each new customer, and collection experience is reviewed periodically in order to determine if the
   customer’s payment terms and credit limits need to be revised.

[0000950123-11-018429:notes:13]
We maintain an allowance for doubtful accounts for losses resulting from the inability of our
   customers to make required payments. We regularly review the allowance for doubtful accounts and
   consider factors such as the age of accounts receivable balances, the current economic conditions
   that may affect a customer’s ability to pay, significant one-time events and our historical
   experience. If the financial condition of a customer deteriorates, resulting in an impairment of
   their ability to make payments, we may be required to make additional allowances. If circumstances
   change with regard to individual receivable balances that have previously been determined to be
   uncollectible (and for which a specific reserve has been established), a reduction in our allowance
   for doubtful accounts may be required. Our allowance for doubtful accounts was $162 thousand at
   December 31, 2010 and $138 thousand at December 31, 2009.

[0000950123-11-018429:notes:14]
Other Receivables

[0000950123-11-018429:notes:15]
Other receivables are comprised primarily of amounts due from subcontract manufacturers for product
   component transfers, accrued interest on a restricted certificate of deposit and amounts due from
   employee stock option exercises.

[0000950123-11-018429:notes:16]
Inventory

[0000950123-11-018429:notes:17]
Inventory is carried at the lower of cost or market, with cost being determined using the first-in,
   first-out method. Standard costs for material, labor and manufacturing overhead are used to value
   inventory. Standard costs are updated at least quarterly; therefore, inventory costs approximate
   actual costs at the end of each reporting period. We establish reserves for estimated excess,
   obsolete or unmarketable inventory equal to the difference between the cost of the inventory and
   the estimated fair value of the inventory based upon assumptions about future demand and market
   conditions. When we dispose of excess and obsolete inventories, the related write-downs are charged
   against the inventory reserve.

[0000950123-11-018429:notes:18]
Property, Plant and Equipment

[0000950123-11-018429:notes:19]
Property, plant and equipment, which are stated at cost, are depreciated using straight-line
   depreciation over the estimated useful lives of the assets. We depreciate building and land
   improvements from five to 39 years, office machinery and equipment from three to seven years,
   engineering machinery and equipment from three to seven years and computer software from three to
   five years. Expenditures for repairs and maintenance are charged to expense as incurred.
   Betterments that materially prolong the lives of the assets are capitalized. The cost of assets
   retired or otherwise disposed of and the related accumulated depreciation are removed from the
   accounts, and the gain or loss on such disposition is included in other income, net in the
   accompanying consolidated statements of income.

[0000950123-11-018429:notes:20]
Liability for Warranty

[0000950123-11-018429:notes:21]
Our products generally include warranties of one to ten years for product defects. We accrue for
   warranty returns at the time revenue is recognized based on our estimate of the cost to repair or
   replace the defective products. We engage in extensive product quality programs and processes,
   including actively monitoring and evaluating the quality of our component suppliers. Our products
   continue to become more complex in both size and functionality as many of our product offerings
   migrate from line card applications to systems products. The increasing complexity of our products
   will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future
   warranty obligations may change due to product failure rates, material usage, and other rework
   costs incurred in correcting a product failure. In addition, from time to time, specific warranty
   accruals may be recorded if unforeseen problems arise. Should our actual experience relative to
   these factors be worse than our estimates, we will be required to record additional warranty
   expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion
   of such provisions in future periods. The liability for warranty obligations totaled $3.3 million
   and $2.8 million at December 31, 2010 and 2009, respectively. These liabilities are included in
   accrued expenses in the accompanying consolidated balance sheets.

[0000950123-11-018429:notes:22]
A summary of warranty expense and write-off activity for the years ended December 31, 2010 and 2009
   is as follows:

[0000950123-11-018429:notes:23]
| Year Ended December 31, (In thousands) |  | 2010 |  |  | 2009 |  |
| Balance at beginning of period |  | $ | 2,833 |  |  | $ | 2,812 |  |
| Plus: amounts acquired or charged to cost and expenses |  |  | 5,309 |  |  |  | 2,665 |  |
| Less: deductions |  |  | (4,838 | ) |  |  | (2,644 | ) |
| Balance at end of period |  | $ | 3,304 |  |  | $ | 2,833 |  |

[0000950123-11-018429:notes:24]
Stock-Based Compensation

[0000950123-11-018429:notes:25]
We have two Board and stockholder approved stock option plans from which stock options and other
   awards are available for grant to employees and directors. All employee and director stock options
   granted under our stock option plans have an exercise price equal to the fair market value of the
   award, as defined in the plan, of the underlying common stock on the grant date. There are
   currently no vesting provisions tied to performance or market conditions for any option awards;
   vesting for all outstanding option grants is based only on continued service as an employee or
   director of ADTRAN. All of our outstanding stock option awards are classified as equity awards.

[0000950123-11-018429:notes:26]
Under the provisions of our approved plans, we made grants of performance-based restricted stock
   units to five of our executive officers in 2010, 2009 and 2008. The restricted stock units are
   subject to a market condition based on the relative total shareholder return of ADTRAN against a
   peer group of companies (2008 and 2009 grant) or against all the companies in the NASDAQ
   Telecommunications Index (2010 grant) and vest at the end of a three-year performance period. The
   restricted stock units are converted into shares of common stock upon vesting. Depending on the
   relative total shareholder return over the performance period, the executive officers may earn from
   0% to 150% of the number of restricted stock units granted. The fair value of the award is based
   on the market price of our common stock on the date of grant, adjusted for the expected outcome of
   the impact of market conditions using a Monte Carlo Simulation valuation method. The recipients of
   the restricted stock units also earn dividend credits during the performance period, which will be
   paid in cash upon the issuance of common stock for the restricted stock units.

[0000950123-11-018429:notes:27]
Stock-based compensation expense recognized under the Stock Compensation Topic of the Financial
   Accounting Standards Board Accounting Standards Codification (FASB ASC) in 2010, 2009 and 2008 was
   approximately $7.7 million, $7.0 million and $7.3 million, respectively. As of December 31, 2010,
   total compensation cost related to non-vested stock options, restricted stock units and restricted
   stock not yet recognized was approximately $20.3 million, which is expected to be recognized over
   an average remaining recognition period of 3.1 years. See Note 2 of Notes to Consolidated
   Financial Statements for additional information.

[0000950123-11-018429:notes:28]
Impairment of Long-Lived Assets

[0000950123-11-018429:notes:29]
We review long-lived assets for impairment under the guidance prescribed by the Property, Plant and
   Equipment Topic of the FASB ASC. We evaluate long-lived assets used in operations for impairment
   whenever events or changes in circumstances indicate that the carrying amount of an asset may not
   be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than
   the asset’s carrying value. An impairment loss would be recognized in the amount by which the
   recorded value of the asset exceeds the fair value of the asset, measured by the quoted market
   price of an asset or an estimate based on the best information available in the circumstances.
   There were no such impairment losses recognized during 2010, 2009 or 2008.

[0000950123-11-018429:notes:30]
Research and Development Costs

[0000950123-11-018429:notes:31]
Research and development costs include compensation for engineers and support personnel, outside
   contracted services, depreciation and material costs associated with new product development, the
   enhancement of current products, and product cost reductions. We continually evaluate new product
   opportunities and engage in intensive research and product development efforts. Research and
   development costs totaled $90.3 million, $83.3 million and $81.8 million for the years ended
   December 31, 2010, 2009 and 2008, respectively.

[0000950123-11-018429:notes:32]
Comprehensive Income

[0000950123-11-018429:notes:33]
Comprehensive income consists of all changes in equity (net assets) during a period from non-owner
   sources. Items included in comprehensive income include net income, changes in unrealized gains and
   losses on marketable securities, and foreign currency translation adjustments. Comprehensive income
   is presented in the Consolidated Statements of Changes in Stockholders’ Equity and Comprehensive
   Income.

[0000950123-11-018429:notes:34]
The components of accumulated comprehensive income (loss) are as follows:

[0000950123-11-018429:notes:35]
|  |  | Change in |  |  |  |  |  |  |  |
|  |  | Unrealized Gains |  |  | Foreign |  |  | Accumulated |  |
|  |  | and (Losses) on |  |  | Currency |  |  | Other |  |
|  |  | Marketable |  |  | Translation |  |  | Comprehensive |  |
| (In thousands) |  | Securities, Net of Tax |  |  | Adjustment |  |  | Income (Loss) |  |
| Balance at December 31, 2007 |  | $ | 4,646 |  |  | $ | 1,058 |  |  | $ | 5,704 |  |
| Activity in 2008 |  |  | (4,889 | ) |  |  | (1,824 | ) |  |  | (6,713 | ) |
| Balance at December 31, 2008 |  |  | (243 | ) |  |  | (766 | ) |  |  | (1,009 | ) |
| Activity in 2009 |  |  | 16,394 |  |  |  | 2,468 |  |  |  | 18,862 |  |
| Balance at December 31, 2009 |  |  | 16,151 |  |  |  | 1,702 |  |  |  | 17,853 |  |
| Activity in 2010 |  |  | 7,701 |  |  |  | 1,394 |  |  |  | 9,095 |  |
| Balance at December 31, 2010 |  | $ | 23,852 |  |  | $ | 3,096 |  |  | $ | 26,948 |  |

[0000950123-11-018429:notes:36]
Income Taxes

[0000950123-11-018429:notes:37]
The provision for income taxes has been determined using the asset and liability approach of
   accounting for income taxes. Under this approach, deferred taxes represent the future tax
   consequences expected to occur when the reported amounts of assets and liabilities are recovered or
   paid. The provision for income taxes represents income taxes paid or payable for the current year
   plus the change in deferred taxes during the year. Deferred taxes result from the difference
   between financial and tax bases of our assets and liabilities and are adjusted for changes in tax
   rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce
   deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0000950123-11-018429:notes:38]
Foreign Currency

[0000950123-11-018429:notes:39]
We record transactions denominated in foreign currencies on a monthly basis using exchange rates
   from throughout the year. Assets and liabilities denominated in foreign currencies are translated
   at the balance sheet dates using the closing rates of exchange between those foreign currencies and
   the U.S. dollar with any transaction gains or losses reported in income. Adjustments from
   translating financial statements of international subsidiaries are recorded as a component of
   accumulated comprehensive income (loss).

[0000950123-11-018429:notes:40]
Revenue Recognition

[0000950123-11-018429:notes:41]
Revenue is generally recognized upon shipment of the product to our customer in accordance with the
   title transfer terms of the sales agreement, generally FOB shipping point. In the case of consigned
   inventory, revenue is recognized when the end customer assumes ownership of the product. When
   contracts contain multiple elements, contract interpretation is sometimes required to determine the
   appropriate accounting, including whether the deliverables specified in a multiple element contract
   should be treated as separate units of accounting for revenue recognition purposes, and, if so, how
   the price should be allocated among the elements and when to recognize the revenue for each
   element. We record revenue associated with installation services when all contractual obligations
   are complete. Contracts that include both installation services and product sales are evaluated for
   revenue recognition in accordance with contract terms. As a result, depending on contract terms,
   installation services may be considered as a separate deliverable item or may be considered an
   element of the delivered product. Either the purchaser, ADTRAN, or a third party can perform the
   installation of our products. Shipping fees are recorded as revenue and the related cost is
   included in cost of sales. Revenue is recorded net of discounts. Also, revenue is recorded when the
   product price is fixed or determinable, collection of the resulting receivable is probable, and
   product returns are reasonably estimable. Sales returns are accrued based on historical sales
   return experience, which we believe provides a reasonable estimate of future returns.

[0000950123-11-018429:notes:42]
A portion of Enterprise Networks products are sold to a non-exclusive distribution network of major
   technology distributors in the United States. These large organizations then distribute to an
   extensive network of value-added resellers and system integrators. Value-added resellers and
   system integrators may be affiliated with us as a channel partner, or they may purchase from the
   distributor in an unaffiliated fashion. Additionally, with certain limitations our distributors may
   return unused and unopened product for stock-balancing purposes when such returns are accompanied
   by offsetting orders for products of equal or greater value.

[0000950123-11-018429:notes:43]
We participate in cooperative advertising and market development programs with certain customers.
   We use these programs to reimburse customers for certain forms of advertising, and in general, to
   allow our customers credits up to a specified percentage of their net purchases. Our costs
   associated with these programs are estimated and included in marketing expenses in our consolidated
   statements of income. We also participate in rebate programs to provide sales incentives for
   certain products. Our costs associated
   with these programs are estimated and accrued at the time of sale, and are recorded as a reduction
   of sales in our consolidated statements of income.

[0000950123-11-018429:notes:44]
Unearned Revenue

[0000950123-11-018429:notes:45]
Unearned revenue primarily represents customer billings on our maintenance service programs and
   deferred revenues relating to multiple element contracts where we still have contractual
   obligations to our customers. We currently offer maintenance contracts ranging from one to five
   years, primarily on Enterprise Networks Division products sold through distribution channels.
   Revenue attributable to maintenance contracts is recognized on a straight-line basis over the
   related contract term. In addition, we provide software maintenance and a variety of hardware
   maintenance services to Carrier Network Division customers under contracts with terms up to ten
   years. Non-current unearned revenue is included in other non-current liabilities in the
   accompanying consolidated balance sheets. At December 31, 2010 and 2009, unearned revenue was as
   follows:

[0000950123-11-018429:notes:46]
| (In thousands) |  | 2010 |  |  | 2009 |  |
| Current unearned revenue |  | $ | 10,138 |  |  | $ | 7,138 |  |
| Non-current unearned revenue |  |  | 3,801 |  |  |  | 3,915 |  |
| Total |  | $ | 13,939 |  |  | $ | 11,053 |  |

[0000950123-11-018429:notes:47]
Other Income, net

[0000950123-11-018429:notes:48]
Other income, net, is comprised primarily of miscellaneous income and expense, gains and losses on
   foreign currency transactions, investment account management fees, and gains or losses on the
   disposal of property, plant and equipment occurring in the normal course of business.

[0000950123-11-018429:notes:49]
Earnings per Share

[0000950123-11-018429:notes:50]
Earnings per common share, and earnings per common share assuming dilution, are based on the
   weighted average number of common shares and, when dilutive, common equivalent shares outstanding
   during the year (see Note 11).

[0000950123-11-018429:notes:51]
Dividends

[0000950123-11-018429:notes:52]
The Board of Directors presently anticipates that it will declare a regular quarterly dividend as
   long as the current tax treatment of dividends exists and adequate levels of liquidity are
   maintained. During the years ended December 31, 2010, 2009 and 2008, we paid $22.5 million, $22.5
   million and $22.9 million, respectively, in dividend payments. On January 18, 2011, the Board of
   Directors declared a quarterly cash dividend of $0.09 per common share to be paid to holders of
   record at the close of business on February 3, 2011. The ex-dividend date was February 1, 2011 and
   the payment date was February 17, 2011. The quarterly dividend payment was $5.8 million.

[0000950123-11-018429:notes:53]
Business Combinations

[0000950123-11-018429:notes:54]
On September 15, 2009, we acquired all of the outstanding stock of Objectworld Communications
   Corporation (Objectworld), a provider of unified communication solutions. The purpose of this
   acquisition was to acquire unified communications technologies. These technologies have been
   integrated into our NetVanta® product line. The purchase price was approximately $1.5 million in
   cash subject to certain post closing adjustments, and was allocated to the individual assets and
   liabilities acquired. There was no goodwill determined in the final purchase price allocation.
   Objectworld’s financial statements have been included in our consolidated statements of income and
   cash flows since the date of the acquisition and our consolidated balance sheets dated December 31,
   2010 and 2009.

[0000950123-11-018429:notes:55]
Use of Estimates

[0000950123-11-018429:notes:56]
The preparation of financial statements in conformity with accounting principles generally accepted
   in the United States of America requires management to make estimates and assumptions that affect
   the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities
   at the date of the financial statements, and the reported amounts of revenue and expense during the
   reporting period. Our more significant estimates include the allowance for doubtful accounts,
   obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales
   returns, determination of the deferred revenue components of multiple element sales agreements,
   estimated income tax contingencies, the fair value of stock-based compensation, and the evaluation
   of other-than-temporary declines in the value of investments. Actual amounts could differ
   significantly from these estimates.

[0000950123-11-018429:notes:57]
Recently Issued Accounting Standards

[0000950123-11-018429:notes:58]
In October 2009, the Financial Accounting Standards Board (FASB) issued Update No. 2009-13, which
   amends the Revenue Recognition topic of the FASB Accounting Standards Codification (ASC). This
   update provides amendments to the criteria in Subtopic 605-25 of the ASC for separating
   consideration in multiple-deliverable arrangements. As a result of those amendments,
   multiple-deliverable arrangements will be separated in more circumstances than under existing U.S.
   GAAP. The amendments establish a selling price hierarchy for determining the selling price of a
   deliverable and will replace the term fair value in the revenue allocation guidance with selling
   price to clarify that the allocation of revenue is based on entity-specific assumptions rather than
   assumptions of a marketplace participant. The amendments will also eliminate the residual method
   of allocation and require that arrangement consideration be allocated at the inception of the
   arrangement to all deliverables using the relative selling price method and will require that a
   vendor determine its best estimate of selling price in a manner that is consistent with that used
   to determine the price to sell the deliverable on a standalone basis. These amendments will be
   effective prospectively for revenue arrangements entered into or materially modified in fiscal
   years beginning on or after June 15, 2010, with early adoption permitted. We do not expect the
   adoption of this amendment will have a material impact on our consolidated results of operations or
   financial condition.

[0000950123-11-018429:notes:59]
In October 2009, the FASB issued Update No. 2009-14, which amends the Software topic of the ASC.
   The amendments in this update change the accounting model for revenue arrangements that include
   both tangible products and software elements. Tangible products containing software components and
   non-software components that function together to deliver the tangible product’s essential
   functionality is no longer within the scope of the software revenue guidance in Subtopic 985-605 of
   the ASC. In addition, the amendments in this update require that hardware components of a tangible
   product containing software components always be excluded from the software revenue guidance. In
   that regard, the amendments provide additional guidance on how to determine which software, if any,
   relating to the tangible product also would be excluded from the scope of the software revenue
   guidance. The amendments also provide guidance on how a vendor should allocate arrangement
   consideration to deliverables in an arrangement that includes both tangible products and software.
   The amendments also provide further guidance on how to allocate arrangement consideration when an
   arrangement includes deliverables both included and excluded from the scope of the software revenue
   guidance. These amendments will be effective prospectively for revenue arrangements entered into
   or materially modified in fiscal years beginning on or after June 15, 2010, with early adoption
   permitted. We do not expect the adoption of this amendment will have a material impact on our
   consolidated results of operations or financial condition.

[0000950123-11-018429:notes:60]
During 2010, we adopted the following accounting standards, which had no material effect on our
   consolidated results of operations or financial condition:

[0000950123-11-018429:notes:61]
In January 2010, the FASB issued Update No. 2010-06, which amends the Fair Value Measurements and
   Disclosures topic of the ASC. The amendments in this update require new disclosures about
   transfers in and out of Level 1 and Level 2 fair value measurements and the activity in Level 3
   fair value measurements and, in addition, clarify existing disclosures required for levels of
   disaggregation and inputs and valuation techniques. These amendments are effective for interim and
   annual reporting periods beginning after December 15, 2009, except for the disclosures about
   activity in Level 3 fair value measurements, which is effective for fiscal years beginning after
   December 15, 2010, and for interim periods within those fiscal years. We adopted this amendment
   during the period ended March 31, 2010, and we have provided the disclosures required for the three
   and twelve months ended December 31, 2010.

[0000950123-11-018429:notes:62]
In February 2010, the FASB issued Update No. 2010-09, which amends the Subsequent Events topic of
   the ASC. The amendments in this update require entities that are SEC filers to evaluate subsequent
   events through the date that the financial statements are issued. Additionally, SEC filers are no
   longer required to disclose the date through which subsequent events were evaluated. The
   amendments in this update were effective upon issuance. We adopted this amendment during the
   period ended March 31, 2010.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950123-11-018429:notes:63]
Note 2 — Stock Incentive Plans

[0000950123-11-018429:notes:64]
Stock Incentive Program Descriptions

[0000950123-11-018429:notes:65]
Our Board of Directors adopted the 1996 Employee Incentive Stock Option Plan (1996 Plan) effective
   February 14, 1996, as amended, under which 17.0 million shares of common stock were authorized for
   issuance to certain employees and officers through incentive stock options and non-qualified stock
   options. Options granted under the 1996 Plan typically become exercisable beginning after one year
   of continued employment, normally pursuant to a four or five-year vesting schedule beginning on the
   first anniversary of the grant date, and have a ten-year contractual term. The 1996 Plan expired
   February 14, 2006, and expiration dates of options outstanding at December 31, 2010 under the 1996
   Plan range from 2011 to 2016.

[0000950123-11-018429:notes:66]
On January 23, 2006, the Board of Directors adopted the 2006 Employee Stock Incentive Plan (2006
   Plan), which authorizes 13.0 million shares of common stock for issuance to certain employees and
   officers through incentive stock options and non-qualified stock options, stock appreciation
   rights, restricted stock and restricted stock units. The 2006 Plan was adopted by stockholder
   approval at our annual meeting of stockholders held on May 9, 2006. Options granted under the 2006
   Plan typically become exercisable beginning after one year of continued employment, normally
   pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date, and
   have a ten-year contractual term. Expiration dates of options outstanding at December 31, 2010
   under the 2006 Plan range from 2016 to 2020.

[0000950123-11-018429:notes:67]
Our stockholders approved the 2010 Directors Stock Plan (2010 Directors Plan) on May 5, 2010, under
   which 0.5 million shares of common stock have been reserved. This plan replaces the 2005 Directors
   Stock Option Plan. The 2010 Directors Plan provides that the Company may issue stock options,
   restricted stock and restricted stock units to our non-employee directors. Stock awards issued
   under the 2010 Directors Plan normally become vested in full on the first anniversary of the grant
   date. Options issued under the 2010 Directors Plan have a ten-year contractual term. We currently
   also have options outstanding under the 1995 Directors Plan, as amended, and the 2005 Directors
   Plan. Expiration dates of options outstanding under both plans at December 31, 2010 range from
   2011 to 2019.

[0000950123-11-018429:notes:68]
The following table is a summary of our stock options outstanding as of December 31, 2009 and 2010
   and the changes that occurred during 2010:

[0000950123-11-018429:notes:69]
|  |  |  |  |  |  |  |  |  |  | Weighted Avg. |  |  |  |  |
|  |  |  |  |  |  | Weighted |  |  | Remaining |  |  |  |  |
|  |  | Number of |  |  | Average |  |  | Contractual Life |  |  | Aggregate |  |
| (In thousands, except per share amounts) |  | Options |  |  | Exercise Price |  |  | in Years |  |  | Intrinsic Value |  |
| Options outstanding, December 31, 2009 |  |  | 6,916 |  |  | $ | 20.42 |  |  |  | 6.05 |  |  | $ | 25,719 |  |
| Options granted |  |  | 888 |  |  | $ | 33.55 |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (87 | ) |  | $ | 23.53 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (1,483 | ) |  | $ | 16.88 |  |  |  |  |  |  |  |  |  |
| Options outstanding, December 31, 2010 |  |  | 6,234 |  |  | $ | 23.09 |  |  |  | 6.21 |  |  | $ | 81,561 |  |
| Options exercisable, December 31, 2010 |  |  | 3,964 |  |  | $ | 21.56 |  |  |  | 4.70 |  |  | $ | 57,896 |  |

[0000950123-11-018429:notes:70]
The following table further describes our stock options outstanding as of December 31, 2010:

[0000950123-11-018429:notes:71]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
|  |  | Options |  |  | Weighted Avg. |  |  | Weighted |  |  | Options |  |  | Weighted |  |
|  |  | Outstanding at |  |  | Remaining |  |  | Average |  |  | Exercisable at |  |  | Average |  |
| Range of |  | 12/31/10 |  |  | Contractual Life |  |  | Exercise |  |  | 12/31/10 |  |  | Exercise |  |
| Exercise Prices |  | (In thousands) |  |  | in Years |  |  | Price |  |  | (In thousands) |  |  | Price |  |
| $8.70 – $15.28 |  |  | 892 |  |  |  | 1.55 |  |  | $ | 11.58 |  |  |  | 892 |  |  | $ | 11.58 |  |
| $15.29 – $22.53 |  |  | 1,727 |  |  |  | 6.29 |  |  | $ | 18.91 |  |  |  | 1,269 |  |  | $ | 20.19 |  |
| $22.54 – $30.03 |  |  | 1,802 |  |  |  | 7.86 |  |  | $ | 23.46 |  |  |  | 862 |  |  | $ | 23.51 |  |
| $30.04 – $37.18 |  |  | 1,813 |  |  |  | 6.77 |  |  | $ | 32.36 |  |  |  | 941 |  |  | $ | 31.11 |  |
|  |  |  | 6,234 |  |  |  |  |  |  |  |  |  |  |  | 3,964 |  |  |  |  |  |

[0000950123-11-018429:notes:72]
All of the options above were issued at exercise prices that approximate fair market value at
   the date of grant. At December 31, 2010, 9.0 million options were available for grant under the
   shareholder approved plans.

[0000950123-11-018429:notes:73]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the
   difference between ADTRAN’s closing stock price on the last trading day of 2010 and the exercise
   price, multiplied by the number of in-the-money options) that would have been received by the
   option holders had all option holders exercised their options on December 31, 2010. The amount of
   aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock.

[0000950123-11-018429:notes:74]
The total pre-tax intrinsic value of options exercised during 2010, 2009 and 2008 was $20.3
   million, $5.3 million and $3.7 million, respectively. The fair value of options fully vesting
   during 2010, 2009 and 2008 was $6.9 million, $7.1 million and $7.4 million, respectively.

[0000950123-11-018429:notes:75]
Restricted Stock Program Description

[0000950123-11-018429:notes:76]
On November 6, 2008, the Compensation Committee of the Board of Directors approved the Performance
   Shares Agreement under the 2006 Plan which sets forth the terms and conditions of awards of
   performance-based restricted stock units (RSUs). Of the 13.0 million shares of common stock
   authorized for issuance under the 2006 Plan, we may grant up to 5.0 million shares of common stock
   for issuance to certain employees and officers for awards other than stock options, which would
   include RSUs. Under a proposal that
   was approved by the Board of Directors and shareholders at the 2010 annual meeting, the number of
   shares available for awards other than stock options under all stock plans was reduced to 3.3
   million. The number of shares of common stock earned by a recipient pursuant to the RSUs is
   subject to a market condition based on ADTRAN’s relative total shareholder return against a peer
   group (2008 and 2009 grants) or against all companies in the NASDAQ Telecommunications Index (2010
   grant) at the end of a three-year performance period. Depending on the relative total shareholder
   return over the performance period, the recipient may earn from 0% to 150% of the shares underlying
   the RSUs, with the shares earned distributed upon the vesting of the RSUs at the end of the
   three-year performance period. The fair value of the award is based on the market price of our
   common stock on the date of grant, adjusted for the expected outcome of the impact of market
   conditions using a Monte Carlo Simulation valuation method. A portion of the granted RSUs also
   vest and the underlying shares become deliverable upon the death or disability of the recipient or
   upon a change of control of ADTRAN, as defined by the 2006 Plan. The recipients of the RSUs
   receive dividend credits based on the shares of common stock underlying the RSUs. The dividend
   credits are vested and earned in the same manner as the RSUs and will be paid in cash upon the
   issuance of common stock for the RSUs.

[0000950123-11-018429:notes:77]
The following table is a summary of our RSUs and restricted stock outstanding as of December 31,
   2009 and 2010 and the changes that occurred during 2010:

[0000950123-11-018429:notes:78]
|  |  |  |  |  |  | Weighted |  |
|  |  | Number of |  |  | Average Grant |  |
| (In thousands, except per share amounts) |  | RSUs |  |  | Date Fair Value |  |
| RSUs and restricted stock outstanding, December 31, 2009 |  |  | 52 |  |  | $ | 21.85 |  |
| RSUs and restricted stock granted |  |  | 35 |  |  | $ | 38.40 |  |
| RSUs and restricted stock vested |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  | $ | — |  |
| Unvested RSUs and restricted stock, December 31, 2010 |  |  | 87 |  |  | $ | 28.46 |  |

[0000950123-11-018429:notes:79]
As of December 31, 2010, there was approximately $1.9 million of total unamortized
   compensation cost related to the non-vested portion of RSUs and restricted stock granted, which
   will be recognized on a straight-line basis over the remainder of the three-year performance period
   for RSUs and over the remainder of the one-year vesting period for restricted stock.

[0000950123-11-018429:notes:80]
Valuation and Expense Information

[0000950123-11-018429:notes:81]
We use the Black-Scholes option pricing model (Black-Scholes Model) for the purpose of determining
   the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model
   requires the input of certain assumptions that involve judgment. Because our stock options have
   characteristics significantly different from those of traded options, and because changes in the
   input assumptions can materially affect the fair value estimate, existing models may not provide
   reliable measures of fair value of our stock options. We use a Monte Carlo Simulation valuation
   method to value our performance-based RSUs. The fair value of restricted stock issued to our
   Directors in 2010 is equal to the closing price of our stock on the date of grant. We will
   continue to assess the assumptions and methodologies used to calculate the estimated fair value of
   stock-based compensation. If circumstances change, and additional data becomes available over
   time, we may change our assumptions and methodologies, which may materially impact our fair value
   determination.

[0000950123-11-018429:notes:82]
The following table summarizes stock-based compensation expense related to stock options and RSUs
   under the Stock Compensation Topic of the FASB ASC for the years ended December 31, 2010, 2009 and
   2008, which was recognized as follows:

[0000950123-11-018429:notes:83]
| (In thousands) |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 317 |  |  | $ | 268 |  |  | $ | 253 |  |
| Selling, general and administrative expense |  |  | 3,575 |  |  |  | 3,039 |  |  |  | 3,263 |  |
| Research and development expense |  |  | 3,825 |  |  |  | 3,680 |  |  |  | 3,822 |  |
| Stock-based compensation expense included in operating expenses |  |  | 7,400 |  |  |  | 6,719 |  |  |  | 7,085 |  |
| Total stock-based compensation expense |  |  | 7,717 |  |  |  | 6,987 |  |  |  | 7,338 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (650 | ) |  |  | (634 | ) |  |  | (669 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 7,067 |  |  | $ | 6,353 |  |  | $ | 6,669 |  |

[0000950123-11-018429:notes:84]
At December 31, 2010, total compensation cost related to non-vested stock options, RSUs and
   restricted stock not yet recognized was approximately $20.3 million, which is expected to be
   recognized over an average remaining recognition period of 3.1 years.

[0000950123-11-018429:notes:85]
The stock option pricing model requires the use of several significant assumptions that impact the
   fair value estimate. These variables include, but are not limited to, the volatility of our stock
   price and employee exercise behaviors. The assumptions and variables used for the current period
   grants were developed based on guidance in the Stock Compensation Topic of the FASB ASC. There were
   no material changes made during 2010 to the methodology used to determine our assumptions.

[0000950123-11-018429:notes:86]
The weighted-average estimated fair value of stock options granted to employees and directors
   during the twelve months ended December 31, 2010, 2009 and 2008 was $11.69 per share, $8.11 per
   share and $4.96 per share, respectively, with the following weighted-average assumptions:

[0000950123-11-018429:notes:87]
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Expected volatility |  |  | 39.57 | % |  |  | 41.86 | % |  |  | 41.70 | % |
| Risk-free interest rate |  |  | 1.35 | % |  |  | 2.29 | % |  |  | 2.43 | % |
| Expected dividend yield |  |  | 1.08 | % |  |  | 1.55 | % |  |  | 2.33 | % |
| Expected life (in years) |  |  | 5.78 |  |  |  | 5.10 |  |  |  | 4.97 |  |

[0000950123-11-018429:notes:88]
We based our estimate of expected volatility for the 12 months ended December 31, 2010, 2009
   and 2008 on the sequential historical daily trading data of our common stock for a period equal to
   the expected life of the options granted. The selection of the historical volatility method was
   based on available data indicating our historical volatility is as equally representative of our
   future stock price trends as is our implied volatility. We have no reason to believe the future
   volatility of our stock price is likely to differ from its past volatility.

[0000950123-11-018429:notes:89]
The risk-free interest rate assumption is based upon implied yields of U.S. Treasury zero-coupon
   bonds on the date of grant having a remaining term equal to the expected life of the options
   granted. The dividend yield is based on our historical and expected dividend payouts.

[0000950123-11-018429:notes:90]
The expected life of our stock options is based upon historical exercise and cancellation activity
   of our previous stock-based grants with a ten-year contractual term.

[0000950123-11-018429:notes:91]
The RSU pricing model also requires the use of several significant assumptions that impact the fair
   value estimate. The estimated fair value of the RSUs granted to employees 2010, 2009 and 2008 was
   $39.21, $26.65 and $17.05, respectively, with the following assumptions:

[0000950123-11-018429:notes:92]
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Expected volatility |  |  | 40.82 | % |  |  | 41.41 | % |  |  | 38.61 | % |
| Risk-free interest rate |  |  | 0.51 | % |  |  | 1.40 | % |  |  | 1.63 | % |
| Expected dividend yield |  |  | 1.07 | % |  |  | 1.53 | % |  |  | 2.35 | % |
| Fair value of future dividend payments |  | $ | 1.07 |  |  | $ | 1.06 |  |  | $ | 1.06 |  |

[0000950123-11-018429:notes:93]
Stock-based compensation expense recognized in our Consolidated Statements of Income for the
   12 months ended December 31, 2010, 2009 and 2008 is based on RSUs and options ultimately expected
   to vest, and has been reduced for estimated forfeitures. Estimates for forfeiture rates are based
   upon historical experience and are evaluated quarterly. We expect our forfeiture rate for stock
   option awards to be approximately 2% annually. We estimated a 0% forfeiture rate for our RSUs and
   restricted stock due to the limited number of recipients and historical experience for these
   awards.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950123-11-018429:notes:94]
Note 3 — Investments

[0000950123-11-018429:notes:95]
We classify our investments as available-for-sale. At December 31, 2010, we held the
   following securities and investments, recorded at either fair value or cost.

[0000950123-11-018429:notes:96]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Fair Value / |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 3,483 |  |  | $ | 770 |  |  | $ | (7 | ) |  | $ | 4,246 |  |
| Corporate bonds |  |  | 126,671 |  |  |  | 630 |  |  |  | (229 | ) |  |  | 127,072 |  |
| Municipal fixed-rate bonds |  |  | 71,212 |  |  |  | 268 |  |  |  | (13 | ) |  |  | 71,467 |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | — |  |  |  | 116,745 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 220 |  |  |  | — |  |  |  | 746 |  |
| Marketable equity securities |  |  | 11,486 |  |  |  | 36,657 |  |  |  | (133 | ) |  |  | 48,010 |  |
| Available-for-sale securities held at fair value |  | $ | 330,123 |  |  | $ | 38,545 |  |  | $ | (382 | ) |  | $ | 368,286 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,103 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 418,639 |  |

[0000950123-11-018429:notes:97]
At December 31, 2009, we held the following securities and investments, recorded at either
   fair value or cost.

[0000950123-11-018429:notes:98]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Fair Value / |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 2,904 |  |  | $ | 528 |  |  | $ | (8 | ) |  | $ | 3,424 |  |
| Corporate bonds |  |  | 20,127 |  |  |  | 287 |  |  |  | — |  |  |  | 20,414 |  |
| Municipal fixed-rate bonds |  |  | 140,278 |  |  |  | 1,009 |  |  |  | (2 | ) |  |  | 141,285 |  |
| Municipal variable rate demand notes |  |  | 84,359 |  |  |  | — |  |  |  | — |  |  |  | 84,359 |  |
| Fixed income bond fund |  |  | 867 |  |  |  | 296 |  |  |  | — |  |  |  | 1,163 |  |
| Marketable equity securities |  |  | 9,805 |  |  |  | 23,927 |  |  |  | (197 | ) |  |  | 33,535 |  |
| Available-for-sale securities held at fair value |  | $ | 258,340 |  |  | $ | 26,047 |  |  | $ | (207 | ) |  | $ | 284,180 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,208 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 334,638 |  |

[0000950123-11-018429:notes:99]
At December 31, 2010 and 2009, we held $4.2 million and $3.4 million, respectively, of
   deferred compensation plan assets, carried at fair value.

[0000950123-11-018429:notes:100]
At December 31, 2010 and 2009, we held $127.1 million and $20.4 million, respectively, of corporate
   bonds. These bonds are classified as available-for-sale and had an average duration of 2.0 years
   at December 31, 2010. At December 31, 2010, approximately 3% of our corporate bond portfolio had a
   credit rating of AAA, 11% had a credit rating of AA, 51% had a credit rating of A, and 35% had a
   credit rating of BBB.

[0000950123-11-018429:notes:101]
At December 31, 2010 and 2009, we held $71.5 million and $141.3 million, respectively, of municipal
   fixed-rate bonds. These bonds are classified as available-for-sale investments and had an average
   duration of 1.2 years at December 31, 2010. At December 31, 2010, approximately 15% of our
   municipal fixed-rate bond portfolio had a credit rating of AAA, 74% had a credit rating of AA, and
   11% had a credit rating of A. Because our bond portfolio has a high quality rating and contractual
   maturities of a short duration, we are able to obtain prices for these bonds derived from
   observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0000950123-11-018429:notes:102]
As of December 31, 2010, corporate and municipal fixed-rate bonds had the following contractual
   maturities:

[0000950123-11-018429:notes:103]
|  |  | Corporate |  |  | Municipal |  |
| (In thousands) |  | bonds |  |  | fixed-rate bonds |  |
| Less than one year |  | $ | 11,335 |  |  | $ | 29,399 |  |
| One year to four years |  |  | 115,737 |  |  |  | 42,068 |  |
| Total |  | $ | 127,072 |  |  | $ | 71,467 |  |

[0000950123-11-018429:notes:104]
At December 31, 2010 and 2009, we held $116.7 million and $84.4 million, respectively, of
   municipal variable rate demand notes, all of which were classified as available-for-sale short-term
   investments. At December 31, 2010, 29% of our municipal variable rate demand notes had a credit
   rating of AAA, 63% had a credit rating of AA, 8% had a credit rating of A, and all contained put
   options of seven days. Despite the long-term nature of their stated contractual maturities, we
   routinely buy and sell these securities and we believe that we have the ability to quickly
   liquidate them. Our investments in these securities are recorded at fair value, and the interest
   rates reset every seven days. We believe we have the ability to sell our variable rate demand
   notes to the remarketing agent, tender agent or issuer at par value plus accrued interest in the
   event we decide to liquidate our investment in a particular variable rate demand note. At December
   31, 2010, approximately 28% of our variable rate demand notes were supported by letters of credit
   from banks that we believe to be in good financial condition. The remaining 72% of our variable
   rate demand notes were supported by standby purchase agreements. As a result of these factors, we
   had no cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from
   these investments. All income generated from these investments was recorded as interest income.
   We have not been required to record any losses relating to municipal variable rate demand notes.

[0000950123-11-018429:notes:105]
At December 31, 2010 and 2009, we held $0.7 million and $1.2 million, respectively, of a fixed
   income bond fund. This bond fund had unrealized gains of $0.2 million and $0.3 million at December
   31, 2010 and 2009, respectively.

[0000950123-11-018429:notes:106]
At December 31, 2010, we held $48.0 million of marketable equity securities, including a single
   security, of which we held 1.5 million shares, carried at a fair value of $34.2 million. We sold
   0.5 million shares of this security during the 12 months ended December 31, 2010. The sales
   resulted in proceeds of $8.2 million and a realized gain of $8.1 million. This single security
   traded approximately 1.0 million shares per day in 2010, in an active market on a European stock
   exchange. This single security comprises $33.7 million of the gross unrealized gains included in
   the fair value of our marketable equity securities at December 31, 2010. The remaining $3.0
   million of gross unrealized gains and $0.1 million of gross unrealized losses at December 31, 2010
   were spread amongst more than 415 equity securities. At December 31, 2009, we held $33.5 million
   of marketable equity securities, including the single security mentioned above, of which we held
   2.1 million shares, carried at a fair value of $22.4 million. This single security comprised $21.7
   million of the gross unrealized gains included in the fair value of our marketable equity
   securities at December 31, 2009. The remaining $2.2 million of unrealized gains and $0.2 million
   of gross unrealized losses at December 31, 2009 were spread amongst more than 375 equity
   securities.

[0000950123-11-018429:notes:107]
At December 31, 2010 and 2009, we held a $48.3 million restricted certificate of deposit, which is
   carried at cost. This investment serves as a collateral deposit against the principal amount
   outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development
   Authority revenue bond (the Bond). At December 31, 2010, the estimated fair value of the Bond was
   approximately $42.5 million, based on a debt security with a comparable interest rate and maturity
   and a Standard & Poor’s credit rating of A+. We have the right to set-off the balance of the Bond
   with the collateral deposit in order to reduce the balance of the indebtedness. For more
   information on the Bond, see Note 6 of Notes to Consolidated Financial Statements.

[0000950123-11-018429:notes:108]
At December 31, 2010 and 2009, we held $2.1 million of other investments carried at cost,
   consisting of interests in two private equity funds and an investment in a privately held
   telecommunications equipment manufacturer. The fair value of these investments was estimated to be
   approximately $10.0 million at December 31, 2010, based on unobservable inputs including
   information supplied by the company and the fund managers. We have committed to invest up to an
   aggregate of $7.9 million in the two private equity funds, and we have contributed $8.0 million as
   of December 31, 2010, of which $7.4 million has been applied toward these commitments. As of
   December 31, 2010 we have received distributions related to these two private equity funds of $7.1
   million, of which $0.9 million was recorded as investment income. These investments are carried at
   cost, net of distributions, with distributions in excess of our investment recorded as investment
   income. The duration of each of these commitments is ten years with $0.1 million expiring in 2013
   and $0.4 million expiring in 2012. We have not been required to record any impairment losses
   related to these investments during the years ended December 31, 2010, 2009 or 2008.

[0000950123-11-018429:notes:109]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of
   historical declines in market prices, credit rating activity, assessments of liquidity, public
   filings, and statements made by the issuer. We generally begin our identification of potential
   other-than-temporary impairments by reviewing any security with a fair value that has declined from
   its original or adjusted cost basis by 25% or more for six or more consecutive months. We then
   evaluate the individual security based on the previously identified factors to determine the amount
   of the write-down, if any. As a result of our review, we did not record any other-than-temporary
   impairment charge during the fourth quarter of 2010. For each of the years ended December 31,
   2010, 2009 and 2008 we recorded a charge of $43 thousand, $2.9 million and $2.4 million,
   respectively, related to the other-than-temporary impairment of certain marketable equity
   securities, a fixed income bond fund and deferred compensation plan assets.

[0000950123-11-018429:notes:110]
Realized gains and losses on sales of securities are computed under the specific identification
   method. The following table presents gross realized gains and losses related to our investments.

[0000950123-11-018429:notes:111]
| Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (In thousands) |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Gross realized gains |  | $ | 12,191 |  |  | $ | 1,978 |  |  | $ | 1,884 |  |
| Gross realized losses |  | $ | (1,183 | ) |  | $ | (3,275 | ) |  | $ | (4,293 | ) |

[0000950123-11-018429:notes:112]
The following table presents the breakdown of investments with unrealized losses at December
   31, 2010.

[0000950123-11-018429:notes:113]
|  |  | Continuous Unrealized |  |  | Continuous Unrealized |  |  |  |  |
|  |  | Loss Position for Less |  |  | Loss Position for 12 |  |  |  |  |
|  |  | than 12 Months |  |  | Months or Greater |  |  | Total |  |
|  |  |  |  |  |  | Unrealized |  |  |  |  |  |  | Unrealized |  |  |  |  |  |  | Unrealized |  |
| (In thousands) |  | Fair Value |  |  | Losses |  |  | Fair Value |  |  | Losses |  |  | Fair Value |  |  | Losses |  |
| Deferred compensation plan assets |  | $ | 338 |  |  | $ | (7 | ) |  | $ | — |  |  | $ | — |  |  | $ | 338 |  |  | $ | (7 | ) |
| Corporate bonds |  |  | 32,326 |  |  |  | (229 | ) |  |  | — |  |  |  | — |  |  |  | 32,326 |  |  |  | (229 | ) |
| Municipal fixed-rate bonds |  |  | 5,869 |  |  |  | (13 | ) |  |  | — |  |  |  | — |  |  |  | 5,869 |  |  |  | (13 | ) |
| Marketable equity securities |  |  | 2,021 |  |  |  | (107 | ) |  |  | 176 |  |  |  | (26 | ) |  |  | 2,197 |  |  |  | (133 | ) |
| Total |  | $ | 40,554 |  |  | $ | (356 | ) |  | $ | 176 |  |  | $ | (26 | ) |  | $ | 40,730 |  |  | $ | (382 | ) |

[0000950123-11-018429:notes:114]
The increase in unrealized losses during 2010, as reflected in the table above, primarily
   occurred due to an increase in intermediate term interest rates during the last two months of 2010
   primarily impacting our corporate bonds. At December 31, 2010, a total of 160 of our marketable
   equity securities were in an unrealized loss position.

[0000950123-11-018429:notes:115]
The following table presents the breakdown of investments with unrealized losses at December 31,
   2009.

[0000950123-11-018429:notes:116]
|  |  | Continuous Unrealized |  |  | Continuous Unrealized |  |  |  |  |
|  |  | Loss Position for Less |  |  | Loss Position for 12 |  |  |  |  |
|  |  | than 12 Months |  |  | Months or Greater |  |  | Total |  |
|  |  |  |  |  |  | Unrealized |  |  |  |  |  |  | Unrealized |  |  |  |  |  |  | Unrealized |  |
| (In thousands) |  | Fair Value |  |  | Losses |  |  | Fair Value |  |  | Losses |  |  | Fair Value |  |  | Losses |  |
| Deferred compensation plan assets |  | $ | — |  |  | $ | — |  |  | $ | 160 |  |  | $ | (8 | ) |  | $ | 160 |  |  | $ | (8 | ) |
| Municipal fixed-rate bonds |  |  | 1,481 |  |  |  | (2 | ) |  |  | — |  |  |  | — |  |  |  | 1,481 |  |  |  | (2 | ) |
| Marketable equity securities |  |  | 2,428 |  |  |  | (91 | ) |  |  | 1,834 |  |  |  | (106 | ) |  |  | 4,262 |  |  |  | (197 | ) |
| Total |  | $ | 3,909 |  |  | $ | (93 | ) |  | $ | 1,994 |  |  | $ | (114 | ) |  | $ | 5,903 |  |  | $ | (207 | ) |

[0000950123-11-018429:notes:117]
The decrease in unrealized losses during 2009, as reflected in the table above, primarily
   occurred due to the improvements in the credit markets and improved equity market conditions. At
   December 31, 2009, a total of 145 of our marketable equity securities were in an unrealized loss
   position.

[0000950123-11-018429:notes:118]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have
   categorized our cash equivalents held in money market funds and our investments held at fair value
   into a three-level fair value hierarchy based on the priority of the inputs to the valuation
   technique for the cash equivalents and investments as follows: Level 1 — Values based on
   unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 — Values
   based on quoted prices in markets that are not active or model inputs that are observable either
   directly or indirectly; Level 3 — Values based on prices or valuation techniques that require
   inputs that are both unobservable and significant to the overall fair value measurement. These
   inputs include information supplied by investees.

[0000950123-11-018429:notes:119]
|  |  | Fair Value Measurements at December 31, 2010 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Markets for |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Identical Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 14,532 |  |  | $ | 14,532 |  |  | $ | — |  |  | $ | — |  |
| Available for sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 4,246 |  |  |  | 4,246 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 127,072 |  |  |  | — |  |  |  | 127,072 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 71,467 |  |  |  | — |  |  |  | 71,467 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | 116,745 |  |  |  | — |  |
| Fixed income bond fund |  |  | 746 |  |  |  | 746 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities — technology industry |  |  | 35,596 |  |  |  | 35,596 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities — other |  |  | 12,414 |  |  |  | 12,414 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 368,286 |  |  |  | 53,002 |  |  |  | 315,284 |  |  |  | — |  |
| Total |  | $ | 382,818 |  |  | $ | 67,534 |  |  | $ | 315,284 |  |  | $ | — |  |

[0000950123-11-018429:notes:120]
|  |  | Fair Value Measurements at December 31, 2009 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Markets for |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Identical Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 18,370 |  |  | $ | 18,370 |  |  | $ | — |  |  | $ | — |  |
| Available for sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 3,424 |  |  |  | 3,424 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,414 |  |  |  | — |  |  |  | 20,414 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 141,285 |  |  |  | — |  |  |  | 141,285 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 84,359 |  |  |  | — |  |  |  | 84,359 |  |  |  | — |  |
| Fixed income bond fund |  |  | 1,163 |  |  |  | 1,163 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities — technology industry |  |  | 23,491 |  |  |  | 23,491 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities — other |  |  | 10,044 |  |  |  | 10,044 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 284,180 |  |  |  | 38,122 |  |  |  | 246,058 |  |  |  | — |  |
| Total |  | $ | 302,550 |  |  | $ | 56,492 |  |  | $ | 246,058 |  |  | $ | — |  |

[0000950123-11-018429:notes:121]
As of December 31, 2010 and 2009, the fair value of the investments in available-for-sale
   Level 2 corporate bonds and municipal fixed-rate bonds was $198.5 million and $161.7 million,
   respectively. The fair value of these securities is calculated using a weighted average market
   price for each security. Market prices are obtained from a variety of industry standard data
   providers, security master files from large financial institutions, and other third-party sources.
   These multiple market prices are used as inputs into a distribution-curve-based algorithm to
   determine the daily market value of each security.

[0000950123-11-018429:notes:122]
As of December 31, 2010 and 2009, the fair value of the investments in available-for-sale Level 2
   municipal variable rate demand notes was $116.7 million and $84.4 million, respectively. These
   securities have a structure that implies a standard expected market price. The frequent interest
   rate resets make it reasonable to expect the price to stay at par. These securities are priced at
   the expected market price.


## us-gaap:InventoryDisclosureTextBlock

[0000950123-11-018429:notes:123]
Note 4 — Inventory

[0000950123-11-018429:notes:124]
At December 31, 2010 and 2009, inventory was comprised of the following:

[0000950123-11-018429:notes:125]
| (In thousands) |  | 2010 |  |  | 2009 |  |
| Raw materials |  | $ | 43,897 |  |  | $ | 27,326 |  |
| Work in process |  |  | 2,871 |  |  |  | 2,662 |  |
| Finished goods |  |  | 27,506 |  |  |  | 15,686 |  |
| Total |  | $ | 74,274 |  |  | $ | 45,674 |  |

[0000950123-11-018429:notes:126]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the
   difference between the cost of the inventory and the estimated fair value of the inventory based
   upon assumptions about future demand and market conditions. At December 31, 2010 and 2009, raw
   materials reserves totaled $7.3 million and $6.6 million, respectively, and finished goods
   inventory reserves totaled $1.6 million and $1.1 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950123-11-018429:notes:127]
Note 5 — Property, Plant and Equipment

[0000950123-11-018429:notes:128]
At December 31, 2010 and 2009, property, plant and equipment were comprised of the following:

[0000950123-11-018429:notes:129]
| (In thousands) |  | 2010 |  |  | 2009 |  |
| Land |  | $ | 4,263 |  |  | $ | 4,263 |  |
| Building and land improvements |  |  | 15,507 |  |  |  | 14,638 |  |
| Building |  |  | 68,479 |  |  |  | 68,495 |  |
| Furniture and fixtures |  |  | 16,130 |  |  |  | 15,746 |  |
| Computer hardware and software |  |  | 61,898 |  |  |  | 57,218 |  |
| Engineering and other equipment |  |  | 83,946 |  |  |  | 80,289 |  |
| Total Property, Plant and Equipment |  |  | 250,223 |  |  |  | 240,649 |  |
| Less accumulated depreciation |  |  | (176,237 | ) |  |  | (166,340 | ) |
| Total Property, Plant and Equipment (net) |  | $ | 73,986 |  |  | $ | 74,309 |  |

[0000950123-11-018429:notes:130]
Depreciation expense was $10.2 million, $10.0 million and $9.9 million in 2010, 2009 and 2008,
   respectively.


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0000950123-11-018429:notes:131]
Note 6 — Alabama State Industrial Development Authority Financing and Economic Incentives

[0000950123-11-018429:notes:132]
In conjunction with an expansion of our Huntsville, Alabama, facility, we were approved for
   participation in an incentive program offered by the State of Alabama Industrial Development
   Authority (the “Authority”). Pursuant to the program, on January 13, 1995, the Authority issued
   $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to
   ADTRAN. The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the
   “Bank”). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of
   Tennessee) (the “Bondholder”), which was acquired by Wells Fargo & Company on December 31, 2008,
   purchased the original bonds from the Bank and made further advances to the Authority, bringing the
   total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond (“Amended
   and Restated Bond”) was issued and the original financing agreement was amended. The Amended and
   Restated Bond bears interest, payable monthly. The interest rate is 5%. The Amended and Restated
   Bond matures on January 1, 2020. The estimated fair value of the bond at December 31, 2010 was
   approximately $42.5 million, based on a debt security with a comparable interest rate and maturity
   and a Standard & Poor’s credit rating of A+. We are required to make payments to the Authority in
   amounts necessary to pay the principal of and interest on the Amended and Restated Bond. Included
   in long-term investments at December 31, 2010 is $48.3 million which is invested in a restricted
   certificate of deposit. These funds serve as a collateral deposit against the principal of this
   bond, and we have the right to set-off the balance of the Bond with the collateral deposit in order
   to reduce the balance of the indebtedness. In conjunction with this program, we are eligible to
   receive certain economic incentives from the state of Alabama that reduce the amount of payroll
   withholdings that we are required to remit to the state for those employment positions that qualify
   under the program. For the years ended December 31, 2010, 2009 and 2008, we realized economic
   incentives totaling $1.5 million, $1.5 million and $1.4 million, respectively.

[0000950123-11-018429:notes:133]
We are required to make payments in the amounts necessary to pay the principal and interest on the
   amounts currently outstanding. Based on positive cash flow from operating activities, we have
   decided to continue early partial redemptions of the Bond. It is our intent to make annual
   principal payments in addition to the interest amounts that are due. In connection with this
   decision, $0.5 million of the Bond debt has been classified as a current liability in the
   Consolidated Balance Sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-11-018429:notes:134]
Note 7 — Income Taxes

[0000950123-11-018429:notes:135]
A summary of the components of the provision for income taxes as of December 31, 2010, 2009
   and 2008 is as follows:

[0000950123-11-018429:notes:136]
| (In thousands) |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 49,144 |  |  | $ | 30,756 |  |  | $ | 37,245 |  |
| State |  |  | 6,380 |  |  |  | 3,615 |  |  |  | 3,350 |  |
| Total current |  |  | 55,524 |  |  |  | 34,371 |  |  |  | 40,595 |  |
| Deferred tax benefit |  |  | (1,324 | ) |  |  | (1,024 | ) |  |  | (903 | ) |
| Total provision for income taxes |  | $ | 54,200 |  |  | $ | 33,347 |  |  | $ | 39,692 |  |

[0000950123-11-018429:notes:137]
The effective income tax rate differs from the federal statutory rate due to the following:

[0000950123-11-018429:notes:138]
|  |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Tax provision computed at the federal statutory rate |  |  | 35.00 | % |  |  | 35.00 | % |  |  | 35.00 | % |
| State income tax provision, net of federal benefit |  |  | 3.33 |  |  |  | 3.68 |  |  |  | 2.95 |  |
| Federal research credits |  |  | (2.90 | ) |  |  | (3.37 | ) |  |  | (1.86 | ) |
| Tax-exempt income |  |  | (0.46 | ) |  |  | (1.05 | ) |  |  | (1.59 | ) |
| State tax incentives |  |  | (0.86 | ) |  |  | (1.36 | ) |  |  | (1.15 | ) |
| Stock-based compensation |  |  | 0.34 |  |  |  | 1.64 |  |  |  | 1.59 |  |
| Domestic production activity deduction |  |  | (2.37 | ) |  |  | (3.33 | ) |  |  | (1.62 | ) |
| Other, net |  |  | 0.15 |  |  |  | (0.21 | ) |  |  | 0.24 |  |
| Effective tax rate |  |  | 32.23 | % |  |  | 31.00 | % |  |  | 33.56 | % |

[0000950123-11-018429:notes:139]
Deferred income taxes on the balance sheet result from temporary differences between the amount of
   assets and liabilities recognized for financial reporting and tax purposes. The principal
   components of our current and non-current deferred taxes are as follows:

[0000950123-11-018429:notes:140]
| (In thousands) |  | 2010 |  |  | 2009 |  |
| Current deferred tax assets |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 61 |  |  | $ | 46 |  |
| Inventory |  |  | 6,032 |  |  |  | 4,682 |  |
| Accrued expenses |  |  | 4,524 |  |  |  | 3,875 |  |
| Total current deferred tax assets |  |  | 10,617 |  |  |  | 8,603 |  |
| Non-current deferred tax assets |  |  |  |  |  |  |  |  |
| Accrued expenses |  |  | 102 |  |  |  | 103 |  |
| Deferred compensation |  |  | 1,539 |  |  |  | 1,364 |  |
| Stock-based compensation |  |  | 3,542 |  |  |  | 2,891 |  |
| State tax and interest expense |  |  | 861 |  |  |  | 1,002 |  |
| Foreign loss and state credit carry-forwards |  |  | 5,988 |  |  |  | 5,559 |  |
| Valuation allowance |  |  | (5,627 | ) |  |  | (5,340 | ) |
| Total non-current deferred tax assets |  |  | 6,405 |  |  |  | 5,579 |  |
| Total deferred tax assets |  | $ | 17,022 |  |  | $ | 14,182 |  |

[0000950123-11-018429:notes:141]
|  |  | 2010 |  |  | 2009 |  |
| Non-current deferred tax liabilities |  |  |  |  |  |  |  |  |
| Accumulated depreciation |  | $ | (4,782 | ) |  | $ | (3,809 | ) |
| Investments |  |  | (11,973 | ) |  |  | (6,805 | ) |
| Total non-current deferred tax liabilities |  | $ | (16,755 | ) |  | $ | (10,614 | ) |
| Net deferred tax assets |  | $ | 267 |  |  | $ | 3,568 |  |

[0000950123-11-018429:notes:142]
At December 31, 2010 and 2009, non-current deferred tax liabilities and non-current deferred tax
   assets, respectively, related to investments reflect deferred taxes on unrealized gains and losses
   on available-for-sale investments. The net change in non-current deferred taxes associated with
   these investments, a deferred tax provision of $4.6 million in 2010 and a deferred tax provision of
   $9.8 million in 2009, is recorded as an adjustment to other comprehensive income, presented in the
   Consolidated Statements of Changes in Stockholders’ Equity and Comprehensive Income.

[0000950123-11-018429:notes:143]
We have deferred tax assets for foreign loss and state credit carry-forwards of $6.0 million which
   will expire between 2014 and 2029. These carry-forwards were caused by tax credits in excess of
   our annual tax liabilities to an individual state where we no longer generate sufficient state
   income and net operating loss carry-forwards acquired through the acquisition of a foreign entity.
   In accordance with the Income Taxes Topic of the FASB ASC, we believe it is more likely than not
   that we will not realize the full benefits of the deferred tax asset arising from these losses and
   credits, and accordingly, have provided a valuation allowance against these assets. We do not
   provide for U.S. income tax on undistributed earnings of our foreign operations, whose earnings are
   intended to be permanently reinvested. For years ended December 31, 2010, 2009 and 2008, foreign
   profits before income taxes were not material.

[0000950123-11-018429:notes:144]
During 2010, 2009 and 2008, we recorded an income tax benefit of $4.9 million, $1.5 million and
   $1.0 million, respectively, as an adjustment to equity in accordance with the Stock Compensation
   Topic of the FASB ASC. This deduction is calculated on the difference between the exercise price
   of stock option exercises and the market price of the underlying common stock upon exercise.

[0000950123-11-018429:notes:145]
The change in the unrecognized income tax benefits for 2010, 2009 and 2008 is reconciled below:

[0000950123-11-018429:notes:146]
| (In thousands) |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Balance at beginning of period |  | $ | 2,919 |  |  | $ | 2,775 |  |  | $ | 2,645 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | 197 |  |  |  | 390 |  |  |  | 159 |  |
| Current year |  |  | 818 |  |  |  | 610 |  |  |  | 718 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | (16 | ) |  |  | (1 | ) |  |  | (119 | ) |
| Settlements with taxing authorities |  |  | (630 | ) |  |  | (413 | ) |  |  | (49 | ) |
| Expiration of applicable statute of limitations |  |  | (695 | ) |  |  | (442 | ) |  |  | (579 | ) |
| Balance at end of period |  | $ | 2,593 |  |  | $ | 2,919 |  |  | $ | 2,775 |  |

[0000950123-11-018429:notes:147]
As of December 31, 2010, 2009, and 2008, our total liability for unrecognized tax benefits was $2.6
   million, $2.9 million, and $2.8 million, respectively, of which $2.0 million, $2.3 million, and
   $2.2 million, respectively, would reduce our effective tax rate if we were successful in upholding
   all of the uncertain positions and recognized the amounts recorded. We classify interest and
   penalties recognized on the liability for unrecognized tax benefits as income tax expense. The
   balances of accrued interest and penalties were $1.0 million as of December 31, 2010 and $1.2
   million as of December 31, 2009 and 2008.

[0000950123-11-018429:notes:148]
We do not anticipate a single tax position generating a significant increase or decrease in our
   liability for unrecognized tax benefits within 12 months of this reporting date. We file income
   tax returns in the U.S. federal and various state jurisdictions and several foreign jurisdictions.
   We have been audited by the Internal Revenue Service and the state of Alabama through the 2007 tax
   year. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the
   years prior to 2007.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950123-11-018429:notes:149]
Note 8 — Employee Benefit Plans

[0000950123-11-018429:notes:150]
401(k) Savings Plan

[0000950123-11-018429:notes:151]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (Savings Plan) for the benefit of our eligible
   employees. The Savings Plan is intended to qualify under Sections 401(a) and 401(k) of the
   Internal Revenue Code of 1986, as amended (Code), and is intended to be a “safe harbor” 401(k) plan
   under Code Section 401(k)(12). The Savings Plan allows employees to save for retirement by
   contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plan also
   requires us to contribute a “safe harbor” amount each year. Beginning January 1, 2008, we changed
   our contribution such that we matched up to 4% of employee contributions (100% of an employee’s
   first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s
   one year anniversary date. In calculating our matching contribution, we only use compensation up
   to the statutory maximum under the Code ($245 thousand for 2010). All contributions under the
   Savings Plan are 100% vested. Expenses recorded for employer contributions and plan administration
   costs for the Savings Plan amounted to approximately $4.6 million, $4.2 million and $3.9 million in
   2010, 2009 and 2008, respectively.

[0000950123-11-018429:notes:152]
Deferred Compensation Plan

[0000950123-11-018429:notes:153]
We maintain the ADTRAN, Inc. Deferred Compensation Plan (Deferred Compensation Plan). This plan is
   offered as a supplement to our tax-qualified 401(k) plan and is available to our management and
   highly compensated employees who have been designated by
   our Board of Directors. The deferred compensation plan allows participants to defer all or a
   portion of certain specified bonuses and up to 25% of remaining cash compensation, and permits us
   to make matching contributions on a discretionary basis, without the limitations that apply to the
   401(k) plan. To date, we have not made any matching contributions under this plan. We have set
   aside the plan assets in a rabbi trust (Trust) and all contributions are credited to bookkeeping
   accounts for the participants. The Trust assets are subject to the claims of our creditors in the
   event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in
   pre-approved mutual funds as directed by each participant, and the participant’s bookkeeping
   account is credited with the earnings and losses attributable to those investments. None of the
   Trust assets are invested in shares of ADTRAN common stock. Benefits are usually distributed six
   months after termination of employment in a single lump sum cash payment. We account for the
   deferred compensation plan in accordance with the Compensation Topic of the FASB ASC.

[0000950123-11-018429:notes:154]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging
   from equities to money market instruments. These mutual funds are publicly quoted and reported at
   fair value. We account for these investments in accordance with the Investments in Debt and Equity
   Securities Topic of the FASB ASC. The fair value of the assets held by the Trust and the amounts
   payable to the plan participants are as follows:

[0000950123-11-018429:notes:155]
| (In thousands) |  | 2010 |  |  | 2009 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |  |  |
| Short-term Investments |  | $ | — |  |  | $ | — |  |
| Long-term Investments |  |  | 4,246 |  |  |  | 3,424 |  |
| Total Fair Value of Plan Assets |  | $ | 4,246 |  |  | $ | 3,424 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |  |  |
| Current Liabilities |  | $ | — |  |  | $ | — |  |
| Non-current Liabilities |  |  | 4,246 |  |  |  | 3,424 |  |
| Total Amounts Payable to Plan Participants |  | $ | 4,246 |  |  | $ | 3,424 |  |

[0000950123-11-018429:notes:156]
In accordance with the Compensation Topic of the FASB ASC, changes in the fair value of
   the plan assets held by the Trust have been included as other income in the accompanying 2010, 2009
   and 2008 Consolidated Statements of Income and in other comprehensive income in the accompanying
   2010 and 2009 Consolidated Balance Sheets. Changes in the fair value of the deferred compensation
   liability are included as selling, general and administrative expense in the accompanying 2010,
   2009 and 2008 Consolidated Statements of Income. Based on the changes in the total fair value of
   the Trust’s assets, we recorded deferred compensation adjustments in 2010, 2009 and 2008 of $0.4
   million, $0.6 million and $(0.9) million, respectively.

[0000950123-11-018429:notes:157]
Retiree Medical Coverage

[0000950123-11-018429:notes:158]
We provide medical, dental and prescription drug coverage to one retired former officer and his
   spouse, for his life, on the same terms as provided to our active officers, and to the spouse of a
   former deceased officer for up to 30 years. At December 31, 2010 and 2009, this liability totaled
   $0.2 million.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950123-11-018429:notes:159]
Note 9 — Segment Information and Major Customers

[0000950123-11-018429:notes:160]
ADTRAN operates two reportable segments: (1) the Carrier Networks Division and (2) the
   Enterprise Networks Division. The accounting policies of the segments are the same as those
   described in the “Nature of Business and Summary of Significant Accounting Policies” (see Note 1)
   to the extent that such policies affect the reported segment information. We evaluate the
   performance of our segments based on gross profit; therefore, selling, general and administrative
   expense, as well as research and development expenses, interest income/expense, net realized
   investment gains/loss, other income/expense and provision for taxes are reported on an entity-wide
   basis only. There are no inter-segment revenues.

[0000950123-11-018429:notes:161]
The following table presents information about the reported sales and gross profit of our
   reportable segments for each of the years ended December 31, 2010, 2009 and 2008. Asset information
   by reportable segment is not reported, since we do not produce such information internally.

[0000950123-11-018429:notes:162]
| Sales and Gross Profit by Market Segment |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 476,030 |  |  | $ | 283,310 |  |  | $ | 371,349 |  |  | $ | 219,681 |  |  | $ | 392,219 |  |  | $ | 236,168 |  |
| Enterprise Networks |  |  | 129,644 |  |  |  | 75,553 |  |  |  | 112,836 |  |  |  | 67,281 |  |  |  | 108,457 |  |  |  | 62,737 |  |
|  |  | $ | 605,674 |  |  | $ | 358,863 |  |  | $ | 484,185 |  |  | $ | 286,962 |  |  | $ | 500,676 |  |  | $ | 298,905 |  |

[0000950123-11-018429:notes:163]
Sales by Product

[0000950123-11-018429:notes:164]
Our three major product categories are Carrier Systems, Business Networking and Loop Access.

[0000950123-11-018429:notes:165]
Carrier Systems products are used by communications service providers to provide last mile access
   in support of data, voice and video services to consumers and enterprises. The Carrier Systems
   category includes our broadband access products comprised of Total Access® 5000 multi-service
   access and aggregation platform products, Total Access 1100/1200 Series Fiber-To-The-Node (FTTN)
   products, and Digital Subscriber Line Access Multiplexer (DSLAM) products. Our broadband access
   products are used by service providers to deliver high-speed Internet access, Voice over Internet
   Protocol (VoIP), IP Television (IPTV), and/or Ethernet services from the central office or remote
   terminal locations to customer premises. The Carrier Systems category also includes our optical
   access products. These products consist of optical access multiplexers including our family of
   OPTI products and our Optical Networking Edge (ONE) products. Optical access products are used to
   deliver higher bandwidth services, or to aggregate large numbers of low bandwidth services for
   transportation across fiber optic infrastructure. Total Access 1500 products, 303 concentrator
   products, M13 multiplexer products, and a number of mobile backhaul products are also included in
   the Carrier Systems product category.

[0000950123-11-018429:notes:166]
Business Networking products provide access to telecommunication services, facilitating the
   delivery of converged services and Unified Communications to the SME market. The Business
   Networking category includes Internetworking products and Integrated Access Devices (IADs).
   Internetworking products consist of our Total Access IP Business Gateways, Optical Network
   Terminals (ONTs), and NetVanta product lines. NetVanta products include multi-service routers,
   managed Ethernet switches, IP Private Branch Exchange (PBX) products, IP phone products, Unified
   Communications solutions, Unified Threat Management (UTM) solutions, and Carrier Ethernet Network
   Terminating Equipment (NTE). Integrated Access Device (IAD) products consist of our Total Access
   600 Series and the Total Access 850.

[0000950123-11-018429:notes:167]
Loop Access products are used by carrier and enterprise customers for access to copper-based
   telecommunications networks. The Loop Access category includes products such as: Digital Data
   Service (DDS) and Integrated Services Digital Network (Total Reach) products, High bit-rate Digital
   Subscriber Line (HDSL) products including Total Access 3000 HDSL and Time Division
   Multiplexed-Symmetrical HDSL (TDM-SHDSL) products, T1/E1/T3, Channel Service Units/Data Service
   Units, and TRACER fixed wireless products.

[0000950123-11-018429:notes:168]
The table below presents sales information by product category for the years ended December 31,
   2010, 2009 and 2008:

[0000950123-11-018429:notes:169]
| (In thousands) |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Carrier Systems |  | $ | 289,314 |  |  | $ | 215,715 |  |  | $ | 206,225 |  |
| Business Networking |  |  | 127,233 |  |  |  | 100,451 |  |  |  | 89,577 |  |
| Loop Access |  |  | 189,127 |  |  |  | 168,019 |  |  |  | 204,874 |  |
| Total |  | $ | 605,674 |  |  | $ | 484,185 |  |  | $ | 500,676 |  |

[0000950123-11-018429:notes:170]
In addition, we identify sub-categories of product revenues, which we divide into growth
   products, representing our primary growth areas, and traditional products. Our growth products
   consist of Broadband Access and Optical Access products (included in Carrier Systems) and
   Internetworking products (included in Business Networking) and our traditional products include
   HDSL products (included in Loop Access) and other products not included in the aforementioned
   growth products.

[0000950123-11-018429:notes:171]
The table below presents subcategory revenues for the years ended December 31, 2010, 2009 and 2008:

[0000950123-11-018429:notes:172]
| (In thousands) |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Growth Products |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 176,116 |  |  | $ | 111,470 |  |  | $ | 102,335 |  |
| Optical Access (included in Carrier Systems) |  |  | 66,206 |  |  |  | 60,596 |  |  |  | 53,844 |  |
| Internetworking (NetVanta® & Multi-service Access Gateways) (included in Business Networking) |  |  | 111,123 |  |  |  | 79,979 |  |  |  | 65,791 |  |
| Total |  | $ | 353,445 |  |  | $ | 252,045 |  |  | $ | 221,970 |  |
| Traditional Products |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 177,249 |  |  |  | 150,276 |  |  |  | 179,814 |  |
| Other products (excluding HDSL) |  |  | 74,980 |  |  |  | 81,864 |  |  |  | 98,892 |  |
| Total |  | $ | 252,229 |  |  | $ | 232,140 |  |  | $ | 278,706 |  |
| Total |  | $ | 605,674 |  |  | $ | 484,185 |  |  | $ | 500,676 |  |

[0000950123-11-018429:notes:173]
Sales by Geographic Region

[0000950123-11-018429:notes:174]
The following is sales information by geographic area for the years ended December 31, 2010, 2009
   and 2008. International sales correlate to shipments with a non-U.S. destination.

[0000950123-11-018429:notes:175]
| (In thousands) |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| United States |  | $ | 573,845 |  |  | $ | 456,402 |  |  | $ | 470,563 |  |
| International |  |  | 31,829 |  |  |  | 27,783 |  |  |  | 30,113 |  |
| Total |  | $ | 605,674 |  |  | $ | 484,185 |  |  | $ | 500,676 |  |

[0000950123-11-018429:notes:176]
Single customers comprising more than 10% of our revenue in 2010 include Qwest Communications
   International, Inc. at 20%, AT&T Inc. at 18%, and Verizon Communications, Inc. at 11%. Single
   customers comprising more than 10% of our revenue in 2009 include AT&T Inc. at 22%, Qwest
   Communications International, Inc. at 19%, and Verizon Communications, Inc. at 11%. Single
   customers comprising more than 10% of our revenue in 2008 include AT&T Inc. at 24%, Qwest
   Communications International, Inc. at 16%, Verizon Communications, Inc. at 12%, and Embarq
   Corporation (formerly Sprint Corporation) at 10%. No other customer accounted for 10% or more of
   our sales in 2010, 2009 or 2008.

[0000950123-11-018429:notes:177]
Sales to Major Service Providers amounted to approximately 72%, 69% and 72% of total sales during
   the years ended December 31, 2010, 2009 and 2008, respectively. In addition, a significant portion
   of our products are sold directly to distributors and certain value-added resellers, which
   accounted for approximately 26%, 28% and 25% of our revenue for each of the years ended December
   31, 2010, 2009 and 2008, respectively.

[0000950123-11-018429:notes:178]
As of December 31, 2010, long-lived assets, net totaled $74.0 million, which includes $73.0 million
   held in the United States and $1.0 million held outside the United States. As of December 31,
   2009, long-lived assets, net totaled $74.3 million, which includes $73.9 million held in the United
   States and $0.4 million held outside the United States.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-11-018429:notes:179]
Note 10 — Commitments and Contingencies

[0000950123-11-018429:notes:180]
In the ordinary course of business, we may be subject to various legal proceedings and claims,
   including employment disputes, patent claims, disputes over contract agreements and other
   commercial disputes. In some cases, claimants seek damages or other relief, such as royalty
   payments related to patents, which, if granted, could require significant expenditures. Although
   the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of
   all contingencies of which we are currently aware will not materially affect our business,
   operations, financial condition or cash flows.

[0000950123-11-018429:notes:181]
We lease office space and equipment under operating leases which expire at various dates through
   2016. As of December 31, 2010, future minimum rental payments under non-cancelable operating leases
   with original maturities of greater than 12 months are approximately as follows:

[0000950123-11-018429:notes:182]
| (In thousands) |  |  |  |  |
| 2011 |  | $ | 1,547 |  |
| 2012 |  |  | 1,086 |  |
| 2013 |  |  | 714 |  |
| 2014 |  |  | 682 |  |
| Thereafter |  |  | 769 |  |
| Total |  | $ | 4,798 |  |

[0000950123-11-018429:notes:183]
Rental expense was approximately $1.8 million for the year ended December 31, 2010 and $1.5
   million for years ended December 31, 2009 and 2008.


## us-gaap:EarningsPerShareTextBlock

[0000950123-11-018429:notes:184]
Note 11 — Earnings per Share

[0000950123-11-018429:notes:185]
A summary of the calculation of basic and diluted earnings per share (EPS) for the years ended
   December 31, 2010, 2009 and 2008 is as follows:

[0000950123-11-018429:notes:186]
|  |  | Year Ended |  |
| (In thousands, except for per share amounts) |  | 2010 |  |  | 2009 |  |  | 2008 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 113,989 |  |  | $ | 74,221 |  |  | $ | 78,581 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares — basic |  |  | 62,490 |  |  |  | 62,459 |  |  |  | 63,549 |  |
| Effect of dilutive securities — stock options |  |  | 1,389 |  |  |  | 897 |  |  |  | 859 |  |
| Weighted average number of shares — diluted |  |  | 63,879 |  |  |  | 63,356 |  |  |  | 64,408 |  |
| Net income per share — basic |  | $ | 1.82 |  |  | $ | 1.19 |  |  | $ | 1.24 |  |
| Net income per share — diluted |  | $ | 1.78 |  |  | $ | 1.17 |  |  | $ | 1.22 |  |

[0000950123-11-018429:notes:187]
For each of the years ended December 31, 2010, 2009 and 2008, 2.0 million, 3.5 million and 3.5
   million stock options were outstanding but were not included in the computation of that year’s
   diluted EPS because the options’ exercise prices were greater than the average market price of the
   common shares, therefore making them anti-dilutive under the treasury stock method.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000950123-11-018429:notes:188]
Note 12 — Summarized Quarterly Financial Data (Unaudited)

[0000950123-11-018429:notes:189]
The following table presents unaudited quarterly operating results for each of our last eight
   fiscal quarters. This information has been prepared on a basis consistent with our audited
   financial statements and includes all adjustments, consisting only of normal recurring adjustments,
   considered necessary for a fair presentation of the data.

[0000950123-11-018429:notes:190]
Unaudited Quarterly Operating Results

[0000950123-11-018429:notes:191]
(In thousands, except for per share amounts)

[0000950123-11-018429:notes:192]
| Three Months Ended |  | March 31, 2010 |  |  | June 30, 2010 |  |  | September 30, 2010 |  |  | December 31, 2010 |  |
| Net sales |  | $ | 127,027 |  |  | $ | 150,361 |  |  | $ | 162,957 |  |  | $ | 165,329 |  |
| Gross profit |  | $ | 75,328 |  |  | $ | 89,329 |  |  | $ | 97,299 |  |  | $ | 96,907 |  |
| Operating income |  | $ | 25,345 |  |  | $ | 38,617 |  |  | $ | 45,045 |  |  | $ | 44,857 |  |
| Net income |  | $ | 18,194 |  |  | $ | 27,751 |  |  | $ | 32,084 |  |  | $ | 35,960 |  |
| Earnings per common share |  | $ | 0.29 |  |  | $ | 0.45 |  |  | $ | 0.51 |  |  | $ | 0.57 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.29 |  |  | $ | 0.44 |  |  | $ | 0.50 |  |  | $ | 0.56 |  |

[0000950123-11-018429:notes:193]
| Three Months Ended |  | March 31, 2009 |  |  | June 30, 2009 |  |  | September 30, 2009 |  |  | December 31, 2009 |  |
| Net sales |  | $ | 110,364 |  |  | $ | 121,528 |  |  | $ | 128,062 |  |  | $ | 124,231 |  |
| Gross profit |  | $ | 67,460 |  |  | $ | 71,690 |  |  | $ | 74,457 |  |  | $ | 73,355 |  |
| Operating income |  | $ | 22,901 |  |  | $ | 26,135 |  |  | $ | 28,959 |  |  | $ | 26,236 |  |
| Net income |  | $ | 15,184 |  |  | $ | 18,839 |  |  | $ | 21,583 |  |  | $ | 18,615 |  |
| Earnings per common share |  | $ | 0.24 |  |  | $ | 0.30 |  |  | $ | 0.34 |  |  | $ | 0.30 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.24 |  |  | $ | 0.30 |  |  | $ | 0.34 |  |  | $ | 0.29 |  |

[0000950123-11-018429:notes:194]
| (1) |  | Assumes exercise of dilutive stock options calculated under the treasury stock method. |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000950123-11-018429:notes:195]
Note 13 — Related Party Transactions

[0000950123-11-018429:notes:196]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the years ended 2010, 2009 and 2008, we incurred fees of $10 thousand per month for these
   legal services.


## us-gaap:ScheduleOfSubsequentEventsTextBlock

[0000950123-11-018429:notes:197]
Note 14 — Subsequent Events

[0000950123-11-018429:notes:198]
On January 18, 2011, the Board declared a quarterly cash dividend of $0.09 per common share to
   be paid to stockholders of record at the close of business on February 3, 2011. The quarterly
   dividend payment was $5.8 million and was paid on February 17, 2011. In July 2003, our Board of
   Directors elected to begin declaring quarterly dividends on our common stock considering the tax
   treatment of dividends and adequate levels of Company liquidity.


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000950123-11-018429:notes:199]
VALUATION AND QUALIFYING ACCOUNTS

[0000950123-11-018429:notes:200]
| Column A |  | Column B |  |  | Column C |  |  | Column D |  |  | Column E |  |  | Column F |  |
|  |  | Balance at |  |  | Assumed |  |  | Charged to |  |  |  |  |  |  | Balance at |  |
|  |  | Beginning |  |  | on |  |  | Costs & |  |  |  |  |  |  | End of |  |
| (In thousands) |  | of Period |  |  | Acquisition |  |  | Expenses |  |  | Deductions |  |  | Period |  |
| Year ended December 31, 2010 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 138 |  |  |  | — |  |  |  | 72 |  |  |  | 48 |  |  | $ | 162 |  |
| Inventory Reserve |  | $ | 7,750 |  |  |  | — |  |  |  | 1,992 |  |  |  | 810 |  |  | $ | 8,932 |  |
| Warranty Liability |  | $ | 2,833 |  |  |  | — |  |  |  | 5,309 |  |  |  | 4,838 |  |  | $ | 3,304 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 5,340 |  |  |  | — |  |  |  | 391 |  |  |  | 104 |  |  | $ | 5,627 |  |
| Year ended December 31, 2009 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 38 |  |  |  | 3 |  |  |  | 102 |  |  |  | 5 |  |  | $ | 138 |  |
| Inventory Reserve |  | $ | 7,728 |  |  |  | — |  |  |  | 1,681 |  |  |  | 1,659 |  |  | $ | 7,750 |  |
| Warranty Liability |  | $ | 2,812 |  |  |  | — |  |  |  | 2,665 |  |  |  | 2,644 |  |  | $ | 2,833 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 1,581 |  |  |  | 3,549 |  |  |  | 251 |  |  |  | 41 |  |  | $ | 5,340 |  |
| Year ended December 31, 2008 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 109 |  |  |  | — |  |  |  | (18 | ) |  |  | 53 |  |  | $ | 38 |  |
| Inventory Reserve |  | $ | 6,424 |  |  |  | — |  |  |  | 2,261 |  |  |  | 957 |  |  | $ | 7,728 |  |
| Warranty Liability |  | $ | 2,944 |  |  |  | — |  |  |  | 2,261 |  |  |  | 2,393 |  |  | $ | 2,812 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 1,236 |  |  |  | — |  |  |  | 345 |  |  |  | — |  |  | $ | 1,581 |  |
