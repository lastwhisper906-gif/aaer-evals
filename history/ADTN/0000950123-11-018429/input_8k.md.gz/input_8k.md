# ADTN 8-K — 0001157523-11-000232 filed 2011-01-19

## item codes, every 8-K on or before 2011-02-25

- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2011-02-25

- none on or before 2011-02-25

## item 2.02 — earnings release, exhibit 99.1

[0001157523-11-000232:8k_2_02:1]
EX-99.1
2
a6577354ex99-1.htm
EXHIBIT 99.1

[0001157523-11-000232:8k_2_02:2]
Exhibit 99.1

[0001157523-11-000232:8k_2_02:3]
ADTRAN,
      Inc. Reports Record Results for Fourth Quarter 2010 and Declares
      Quarterly Cash Dividend

[0001157523-11-000232:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--January 18, 2011--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the fourth quarter of 2010. Sales
      increased 33% to an all time record level of $165,329,000 for the
      quarter, compared to $124,231,000 for the fourth quarter of 2009.
      Operating income increased 71% to $44,857,000 for the quarter compared
      to $26,236,000 for the fourth quarter of 2009. Net income increased 93%
      to $35,960,000 for the quarter, compared to $18,615,000 for the fourth
      quarter of 2009. Earnings per share, assuming dilution, increased 93% to
      $0.56 for the quarter, compared to $0.29 for the fourth quarter of 2009.

[0001157523-11-000232:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “Our fourth quarter
      results highlight the demand that has been building in our business as
      quarterly and yearly sales both achieved new record levels. Most notably
      in the quarter, total sales of our three growth categories increased 50%
      over the fourth quarter the prior year. This performance included
      individual records in each of these categories. Broadband Access saw
      growth of 75% over the fourth quarter the prior year led by expanding
      deployments of our Total Access 5000 platform and related services
      revenue. Our Internetworking category grew 37% over the fourth quarter
      the prior year as we continued to see growth across all of our
      distribution channels. Optical Access grew 24% over the fourth quarter
      the prior year, indicative of the strength we saw across all of our
      mobility products. We believe increasing customer investments are
      aligned well with our strategic areas of focus and that we are
      positioned well for long term growth.”

[0001157523-11-000232:8k_2_02:6]
The Company also reported that the provision for income taxes in the
      fourth quarter of 2010 included a benefit of $4.5 million as a result of
      federal legislation extending research tax credits for the 2010 year.

[0001157523-11-000232:8k_2_02:7]
The Company reported that stock-based compensation expense for the
      fourth quarter of 2010 reduced diluted earnings per share by $0.03
      compared to a reduction of $0.03 for the fourth quarter of 2009.

[0001157523-11-000232:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash
      dividend for the fourth quarter of 2010. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on February 3, 2011. The ex-dividend date is February 1, 2011
      and the payment date is February 17, 2011.

[0001157523-11-000232:8k_2_02:9]
The Company confirmed that its fourth quarter conference call will be
      held Wednesday, January 19, 2011 at 9:30 a.m. Central Time. This
      conference call will be web cast live through StreetEvents.com. To
      listen, simply visit the Investor Relations site at http://www.adtran.com
      or http://streetevents.com approximately 10 minutes prior to the
      start of the call and click on the conference call link provided.

[0001157523-11-000232:8k_2_02:10]
An online replay of the conference call will be available for seven days
      at http://streetevents.com. In addition, an online replay of the
      conference call, as well as the text of the Company's earnings release,
      will be available on the Investor Relations site at http://www.adtran.com
      for at least 12 months following the call.

[0001157523-11-000232:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment, with a portfolio of more than 1,700 solutions
      for use in the last mile of today's telecommunications networks. Widely
      deployed by carriers and enterprises alike, ADTRAN solutions enable
      voice, data, video, and Internet communications across a variety of
      network infrastructures. ADTRAN solutions are currently in use by every
      major U.S. service provider and many global ones, as well as by
      thousands of public, private and governmental organizations worldwide.

[0001157523-11-000232:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-11-000232:8k_2_02:13]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2009 and our quarterly report on Form 10-Q for the quarter ended
      September 30, 2010. These risks and uncertainties could cause actual
      results to differ materially from those in the forward-looking
      statements included in this press release.

[0001157523-11-000232:8k_2_02:14]
| Condensed Consolidated Balance Sheet Unaudited (In thousands) |
|  |  |  | December 31, 2010 |  |  | December 31, 2009 |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 31,677 |  |  | $ | 24,135 |
| Short-term investments |  |  |  | 157,479 |  |  |  | 172,469 |
| Accounts receivable, net |  |  |  | 70,893 |  |  |  | 68,044 |
| Other receivables |  |  |  | 3,962 |  |  |  | 4,097 |
| Income tax receivable, net |  |  |  | 2,741 |  |  |  | - |
| Inventory |  |  |  | 74,274 |  |  |  | 45,674 |
| Prepaid expenses |  |  |  | 3,270 |  |  |  | 2,795 |
| Deferred tax assets, net |  |  |  | 10,617 |  |  |  | 8,603 |
| Total current assets |  |  |  | 354,913 |  |  |  | 325,817 |
| Property, plant and equipment, net |  |  |  | 73,986 |  |  |  | 74,309 |
| Other assets |  |  |  | 1,915 |  |  |  | 2,168 |
| Long-term investments |  |  |  | 261,160 |  |  |  | 162,169 |
| Total assets |  |  | $ | 691,974 |  |  | $ | 564,463 |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 22,785 |  |  | $ | 25,782 |
| Unearned revenue |  |  |  | 10,138 |  |  |  | 7,138 |
| Accrued expenses |  |  |  | 4,913 |  |  |  | 4,202 |
| Accrued wages and benefits |  |  |  | 12,125 |  |  |  | 7,634 |
| Income tax payable, net |  |  |  | - |  |  |  | 3,017 |
| Total current liabilities |  |  |  | 49,961 |  |  |  | 47,773 |
| Deferred tax liabilities, net |  |  |  | 10,350 |  |  |  | 5,035 |
| Other non-current liabilities |  |  |  | 11,841 |  |  |  | 11,390 |
| Bonds payable |  |  |  | 47,500 |  |  |  | 47,750 |
| Total liabilities |  |  |  | 119,652 |  |  |  | 111,948 |
| Stockholders' equity |  |  |  | 572,322 |  |  |  | 452,515 |
| Total liabilities and stockholders' equity |  |  | $ | 691,974 |  |  | $ | 564,463 |

[0001157523-11-000232:8k_2_02:15]
| Consolidated Statements of Income Unaudited (In thousands, except per share data) |
|  |  |  | Three Months Ended |  |  | Twelve Months Ended |
|  |  |  | December 31, |  |  | December 31, |
|  |  |  | 2010 |  |  | 2009 |  |  | 2010 |  |  | 2009 |
| Sales |  |  | $ | 165,329 |  |  |  | $ | 124,231 |  |  |  | $ | 605,674 |  |  |  | $ | 484,185 |  |
| Cost of Sales |  |  |  | 68,422 |  |  |  |  | 50,876 |  |  |  |  | 246,811 |  |  |  |  | 197,223 |  |
| Gross Profit |  |  |  | 96,907 |  |  |  |  | 73,355 |  |  |  |  | 358,863 |  |  |  |  | 286,962 |  |
| Selling, general and administrative expenses |  |  |  | 29,588 |  |  |  |  | 25,863 |  |  |  |  | 114,699 |  |  |  |  | 99,446 |  |
| Research and development expenses |  |  |  | 22,462 |  |  |  |  | 21,256 |  |  |  |  | 90,300 |  |  |  |  | 83,285 |  |
| Operating income |  |  |  | 44,857 |  |  |  |  | 26,236 |  |  |  |  | 153,864 |  |  |  |  | 104,231 |  |
| Interest and dividend income |  |  |  | 1,754 |  |  |  |  | 1,660 |  |  |  |  | 6,557 |  |  |  |  | 6,933 |  |
| Interest expense |  |  |  | (608 | ) |  |  |  | (605 | ) |  |  |  | (2,436 | ) |  |  |  | (2,430 | ) |
| Net realized investment gain (loss) |  |  |  | 2,953 |  |  |  |  | 146 |  |  |  |  | 11,008 |  |  |  |  | (1,297 | ) |
| Other income (expense), net |  |  |  | (163 | ) |  |  |  | 59 |  |  |  |  | (804 | ) |  |  |  | 131 |  |
| Income before provision for income taxes |  |  |  | 48,793 |  |  |  |  | 27,496 |  |  |  |  | 168,189 |  |  |  |  | 107,568 |  |
| Provision for income taxes |  |  |  | (12,833 | ) |  |  |  | (8,881 | ) |  |  |  | (54,200 | ) |  |  |  | (33,347 | ) |
| Net Income |  |  | $ | 35,960 |  |  |  | $ | 18,615 |  |  |  | $ | 113,989 |  |  |  | $ | 74,221 |  |
| Weighted average shares outstanding - basic |  |  |  | 63,007 |  |  |  |  | 62,586 |  |  |  |  | 62,490 |  |  |  |  | 62,459 |  |
| Weighted average shares outstanding - diluted (1) |  |  |  | 64,660 |  |  |  |  | 63,642 |  |  |  |  | 63,879 |  |  |  |  | 63,356 |  |
| Earnings per common share - basic |  |  | $ | 0.57 |  |  |  | $ | 0.30 |  |  |  | $ | 1.82 |  |  |  | $ | 1.19 |  |
| Earnings per common share - diluted (1) |  |  | $ | 0.56 |  |  |  | $ | 0.29 |  |  |  | $ | 1.78 |  |  |  | $ | 1.17 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001157523-11-000232:8k_2_02:16]
| Supplemental Information Stock Based Compensation Expense Unaudited (In thousands) |
|  |  |  | Three Months Ended |  |  | Twelve Months Ended |
|  |  |  | December 31, |  |  | December 31, |
|  |  |  | 2010 |  |  | 2009 |  |  | 2010 |  |  | 2009 |
| Stock-based compensation expense included in cost of sales |  |  | $ | 107 |  |  |  | $ | 72 |  |  |  | $ | 317 |  |  |  | $ | 268 |  |
| Selling, general and administrative expense |  |  |  | 1,215 |  |  |  |  | 879 |  |  |  |  | 3,575 |  |  |  |  | 3,039 |  |
| Research and development expense |  |  |  | 1,168 |  |  |  |  | 1,041 |  |  |  |  | 3,825 |  |  |  |  | 3,680 |  |
| Stock-based compensation expense included in operating expenses |  |  |  | 2,383 |  |  |  |  | 1,920 |  |  |  |  | 7,400 |  |  |  |  | 6,719 |  |
| Total stock-based compensation expense |  |  |  | 2,490 |  |  |  |  | 1,992 |  |  |  |  | 7,717 |  |  |  |  | 6,987 |  |
| Tax benefit for expense associated with non-qualified options |  |  |  | (235 | ) |  |  |  | (181 | ) |  |  |  | (650 | ) |  |  |  | (634 | ) |
| Total stock-based compensation expense, net of tax |  |  | $ | 2,255 |  |  |  | $ | 1,811 |  |  |  | $ | 7,067 |  |  |  | $ | 6,353 |  |

[0001157523-11-000232:8k_2_02:17]
| Consolidated Statements of Cash Flow Unaudited (In thousands) |
|  |  |  | Twelve Months Ended |
|  |  |  | December 31, |
|  |  |  | 2010 |  |  | 2009 |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  |  | $ | 113,989 |  |  |  | $ | 74,221 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  | 10,545 |  |  |  |  | 10,084 |  |
| Amortization of net premium on available-for-sale investments |  |  |  | 4,380 |  |  |  |  | 3,686 |  |
| Net realized (gain) loss on long-term investments |  |  |  | (11,008 | ) |  |  |  | 1,297 |  |
| Net (gain) loss on disposal of property, plant and equipment |  |  |  | 2 |  |  |  |  | (31 | ) |
| Stock-based compensation expense |  |  |  | 7,717 |  |  |  |  | 6,987 |  |
| Deferred income taxes |  |  |  | (1,324 | ) |  |  |  | (1,024 | ) |
| Tax benefit from stock option exercises |  |  |  | 4,909 |  |  |  |  | 1,549 |  |
| Excess tax benefit from stock-based compensation arrangements |  |  |  | (4,404 | ) |  |  |  | (998 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  | (2,849 | ) |  |  |  | (15,143 | ) |
| Other receivables |  |  |  | 135 |  |  |  |  | (1,195 | ) |
| Income tax receivable, net |  |  |  | (2,741 | ) |  |  |  | - |  |
| Inventory |  |  |  | (28,600 | ) |  |  |  | 1,732 |  |
| Prepaid expenses and other assets |  |  |  | (574 | ) |  |  |  | (489 | ) |
| Accounts payable |  |  |  | (2,997 | ) |  |  |  | 5,442 |  |
| Accrued expenses and other liabilities |  |  |  | 8,626 |  |  |  |  | 1,010 |  |
| Income tax payable, net |  |  |  | (3,017 | ) |  |  |  | 3,027 |  |
| Net cash provided by operating activities |  |  |  | 92,789 |  |  |  |  | 90,155 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  |  | (9,872 | ) |  |  |  | (8,740 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  |  | 275,442 |  |  |  |  | 186,193 |  |
| Purchases of available-for-sale investments |  |  |  | (340,489 | ) |  |  |  | (262,067 | ) |
| Acquisition of business, net of cash acquired |  |  |  | - |  |  |  |  | (1,370 | ) |
| Net cash used in investing activities |  |  |  | (74,919 | ) |  |  |  | (85,984 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  |  | 24,942 |  |  |  |  | 13,471 |  |
| Purchases of treasury stock |  |  |  | (18,316 | ) |  |  |  | (15,896 | ) |
| Dividend payments |  |  |  | (22,502 | ) |  |  |  | (22,486 | ) |
| Payments on long-term debt |  |  |  | (250 | ) |  |  |  | (500 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  |  | 4,404 |  |  |  |  | 998 |  |
| Net cash used in financing activities |  |  |  | (11,722 | ) |  |  |  | (24,413 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  |  | 6,148 |  |  |  |  | (20,242 | ) |
| Effect of exchange rate changes |  |  |  | 1,394 |  |  |  |  | 2,468 |  |
| Cash and cash equivalents, beginning of period |  |  |  | 24,135 |  |  |  |  | 41,909 |  |
| Cash and cash equivalents, end of period |  |  | $ | 31,677 |  |  |  | $ | 24,135 |  |

[0001157523-11-000232:8k_2_02:18]
CONTACT:
ADTRAN, Inc.
Jim Matthews, 256-963-8775
Senior
      Vice President/CFO
or
Investor Services/Assistance:
Gayle
      Ellis, 256-963-8220
