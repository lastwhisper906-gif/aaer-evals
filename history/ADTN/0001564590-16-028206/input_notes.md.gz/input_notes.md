# ADTN notes — 0001564590-16-028206


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-16-028206:notes:1]
[same as prior period, unchanged from 0001564590-16-022906:notes:1]

[0001564590-16-028206:notes:2]
[same as prior period, unchanged from 0001564590-16-022906:notes:2]

[0001564590-16-028206:notes:3]
[same as prior period, unchanged from 0001564590-16-022906:notes:3]

[0001564590-16-028206:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim statements should be read in conjunction with the financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2015, filed on February 24, 2016 with the SEC.

[0001564590-16-028206:notes:5]
[same as prior period, unchanged from 0001564590-16-022906:notes:5]

[0001564590-16-028206:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-16-028206:notes:7]
[same as prior period, unchanged from 0001564590-16-022906:notes:7]

[0001564590-16-028206:notes:8]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; and ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018, and we are currently evaluating the transition method that will be elected and the impact that the adoption of ASU 2014-09 will have on our financial position, results of operations and cash flows.

[0001564590-16-028206:notes:9]
In July 2015, the FASB issued Accounting Standards Update No.  2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We do not believe the adoption of ASU 2015-05 will have a material impact on our financial position, results of operations and cash flows.

[0001564590-16-028206:notes:10]
In November 2015, the FASB issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17). ASU 2015-17 amends the existing guidance on income taxes to require the classification of all deferred tax assets and liabilities as non-current on the balance sheet. ASU 2015-17 is effective for fiscal years beginning after December 15, 2016, including interim periods within those years. Early adoption is permitted. The guidance may be applied either prospectively, for all deferred tax assets and liabilities, or retrospectively to all periods presented. We have not selected a transition method or determined whether to early adopt ASU 2015-17 in 2016. Other than the revised balance sheet presentation of current deferred tax assets and liabilities, we do not believe the adoption of ASU 2015-17 will have a material impact on our financial position, results of operations and cash flows.

[0001564590-16-028206:notes:11]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years, with early adoption permitted. A modified retrospective approach is required. We are currently evaluating the impact that the adoption of ASU 2016-02 will have on our financial position, results of operations and cash flows.

[0001564590-16-028206:notes:12]
In March 2016, the FASB issued Accounting Standards Update No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09). ASU 2016-09 simplifies several aspects of accounting for share-based compensation arrangements, including income tax effects, the classification of tax-related cash flows on the statement of cash flows, and accounting for forfeitures. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016, including interim periods within those years. Early adoption is permitted. We are currently evaluating the impact that the adoption of ASU 2016-09 will have on our financial position, results of operations and cash flows.

[0001564590-16-028206:notes:13]
[same as prior period, unchanged from 0001564590-16-022906:notes:13]

[0001564590-16-028206:notes:14]
In April 2015, the FASB issued Accounting Standards Update No. 2015-05, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on accounting for fees paid by a customer in a cloud computing arrangement. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. ASU 2015-05 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period. The amendments may be applied either prospectively to all arrangements entered into or materially modified after the effective date or retrospectively. We adopted ASU 2015-05 during the first quarter of 2016 and will apply the new standard prospectively. The adoption of ASU 2015-05 did not have a material impact on our financial position, results of operations and cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-16-028206:notes:15]
2.  BUSINESS COMBINATIONS

[0001564590-16-028206:notes:16]
On September 13, 2016, we acquired key fiber access products, technologies and service relationships from subsidiaries of CommScope, Inc. for $0.9 million in cash. This acquisition will enhance our solutions for the cable MSO industry and will provide cable operators with the scalable solutions, services and support they require to compete in the multi-gigabit service delivery market. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. These revenues are included in the Network Solutions reportable segment, and in the Access & Aggregation and Customer Devices categories.

[0001564590-16-028206:notes:17]
We recorded a bargain purchase gain of $3.6 million, net of income taxes, subject to customary working capital adjustments between the parties. The bargain purchase gain of $3.6 million represents the excess fair value of the net assets acquired over the consideration exchanged. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and pro forma data for future periods and have concluded that our valuation procedures and resulting measures were appropriate. The gain is included in the line item “Gain on bargain purchase of a business” in the 2016 Consolidated Statements of Income.

[0001564590-16-028206:notes:18]
The preliminary allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date, subject to working capital adjustments, is as follows:

[0001564590-16-028206:notes:19]
| (In Thousands) |  |  |  |
| Assets |  |  |  |
| Inventory |  | 3,272 |  |
| Property, plant and equipment |  | 352 |  |
| Intangible assets |  | 4,700 |  |
| Total assets acquired |  | 8,324 |  |
| Liabilities |  |  |  |
| Accounts payable |  | (1,378 | ) |
| Warranty payable |  | (61 | ) |
| Accrued wages and benefits |  | (122 | ) |
| Deferred income taxes |  | (2,270 | ) |
| Total liabilities assumed |  | (3,831 | ) |
| Total net assets |  | 4,493 |  |
| Gain on bargain purchase of a business, net of tax |  | (3,550 | ) |
| Total purchase price | $ | 943 |  |

[0001564590-16-028206:notes:20]
The details of the acquired intangible assets are as follows:

[0001564590-16-028206:notes:21]
| In thousands | Value |  |  | Life (years) |
| Supply agreement | $ | 1,400 |  |  | 0.8 |
| Customer relationships |  | 1,200 |  |  | 6 |
| Developed technology |  | 800 |  |  | 10 |
| License |  | 500 |  |  | 1.3 |
| Patent |  | 500 |  |  | 7.3 |
| Non-compete |  | 200 |  |  | 2.3 |
| Trade name |  | 100 |  |  | 2 |
| Total | $ | 4,700 |  |  |  |

[0001564590-16-028206:notes:22]
The actual revenue and pre-tax loss included in our Consolidated Statements of Income for the period September 13, 2016 to September 30, 2016 are as follows:

[0001564590-16-028206:notes:23]
|  | September 13 to |  |
| (In thousands) | September 30, 2016 |  |
| Revenue | $ | 1,291 |  |
| Pre-tax loss | $ | (70 | ) |

[0001564590-16-028206:notes:24]
The following supplemental pro forma information presents the financial results as if the acquisition had occurred on January 1, 2015.  This supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2015, nor is it indicative of any future results. Aside from revising the 2015 pre-tax income for the effect of the bargain purchase gain, there were no material, non-recurring adjustments to this pro forma information.

[0001564590-16-028206:notes:25]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Pro forma revenue |  | $ | 170,498 |  |  | $ | 159,375 |  |  | $ | 478,184 |  |  | $ | 463,916 |  |
| Pro forma pre-tax income |  | $ | 11,778 |  |  | $ | 10,294 |  |  | $ | 35,771 |  |  | $ | 21,826 |  |

[0001564590-16-028206:notes:26]
For the three months ended September 30, 2016, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $0.2 million related to this acquisition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-028206:notes:27]
3. INCOME TAXES

[0001564590-16-028206:notes:28]
Our effective tax rate decreased from 36.9% in the nine months ended September 30, 2015 to 34.0%, excluding the tax impact of the bargain purchase gain, in the nine months ended September 30, 2016. The decrease in the effective tax rate between the two periods is primarily attributable to the research and development tax credit being made permanent.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-16-028206:notes:29]
4. PENSION BENEFIT PLAN

[0001564590-16-028206:notes:30]
[same as prior period, unchanged from 0001564590-16-022906:notes:18]

[0001564590-16-028206:notes:31]
The following table summarizes the components of net periodic pension cost for the three and nine months ended September 30, 2016 and 2015:

[0001564590-16-028206:notes:32]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Service cost |  | $ | 305 |  |  | $ | 328 |  |  | $ | 912 |  |  | $ | 992 |  |
| Interest cost |  |  | 182 |  |  |  | 153 |  |  |  | 542 |  |  |  | 464 |  |
| Expected return on plan assets |  |  | (266 | ) |  |  | (252 | ) |  |  | (796 | ) |  |  | (763 | ) |
| Amortization of actuarial losses |  |  | 44 |  |  |  | 102 |  |  |  | 132 |  |  |  | 307 |  |
| Net periodic pension cost |  | $ | 265 |  |  | $ | 331 |  |  | $ | 790 |  |  | $ | 1,000 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-16-028206:notes:33]
5. STOCK-BASED COMPENSATION

[0001564590-16-028206:notes:34]
The following table summarizes the stock-based compensation expense related to stock options, restricted stock units (RSUs) and restricted stock for the three and nine months ended September 30, 2016 and 2015, which was recognized as follows:

[0001564590-16-028206:notes:35]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 88 |  |  | $ | 59 |  |  | $ | 282 |  |  | $ | 202 |  |
| Selling, general and administrative expense |  |  | 765 |  |  |  | 812 |  |  |  | 2,322 |  |  |  | 2,226 |  |
| Research and development expense |  |  | 639 |  |  |  | 803 |  |  |  | 1,997 |  |  |  | 2,360 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,404 |  |  |  | 1,615 |  |  |  | 4,319 |  |  |  | 4,586 |  |
| Total stock-based compensation expense |  |  | 1,492 |  |  |  | 1,674 |  |  |  | 4,601 |  |  |  | 4,788 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (218 | ) |  |  | (218 | ) |  |  | (643 | ) |  |  | (620 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,274 |  |  | $ | 1,456 |  |  | $ | 3,958 |  |  | $ | 4,168 |  |

[0001564590-16-028206:notes:36]
[same as prior period, unchanged from 0001564590-16-022906:notes:24]

[0001564590-16-028206:notes:37]
The weighted-average assumptions and value of options granted during the three and nine months ended September 30, 2016 and 2015 are as follows:

[0001564590-16-028206:notes:38]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Expected volatility |  |  | 34.55 | % |  |  | 34.80 | % |  |  | 34.66 | % |  |  | 36.24 | % |
| Risk-free interest rate |  |  | 1.20 | % |  |  | 1.84 | % |  |  | 1.28 | % |  |  | 1.70 | % |
| Expected dividend yield |  |  | 1.83 | % |  |  | 2.13 | % |  |  | 1.88 | % |  |  | 1.94 | % |
| Expected life (in years) |  |  | 6.21 |  |  |  | 6.24 |  |  |  | 6.24 |  |  |  | 6.32 |  |
| Weighted-average estimated value |  | $ | 5.64 |  |  | $ | 4.89 |  |  | $ | 5.50 |  |  | $ | 5.89 |  |

[0001564590-16-028206:notes:39]
The fair value of our RSUs is calculated using a Monte Carlo Simulation valuation method. No RSUs were granted or vested during the three and nine months ended September 30, 2016 and 2015. Twelve thousand RSUs were forfeited during the nine months ended September 30, 2015.

[0001564590-16-028206:notes:40]
The fair value of restricted stock is equal to the closing price of our stock on the date of grant. Two thousand shares and four thousand shares of restricted stock were granted during the three and nine months ended September 30, 2016, respectively. Two thousand shares of restricted stock vested during the three and nine months ended September 30, 2015.

[0001564590-16-028206:notes:41]
Stock-based compensation expense recognized in our Consolidated Statements of Income for the three and nine months ended September 30, 2016 and 2015 is based on options, RSUs and restricted stock ultimately expected to vest, and has been reduced for estimated forfeitures. Estimated forfeitures for stock options are based upon historical experience and approximate 3.7% annually. We estimated a 0% forfeiture rate for our RSUs and restricted stock due to the limited number of recipients and historical experience for these awards.

[0001564590-16-028206:notes:42]
As of September 30, 2016, total compensation expense related to non-vested stock options, RSUs and restricted stock not yet recognized was approximately $9.9 million, which is expected to be recognized over an average remaining recognition period of 2.2 years.

[0001564590-16-028206:notes:43]
The following table is a summary of our stock options outstanding as of December 31, 2015 and September 30, 2016 and the changes that occurred during the nine months ended September 30, 2016:

[0001564590-16-028206:notes:44]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2015 |  |  | 7,108 |  |  | $ | 21.97 |  |  |  | 6.42 |  |  | $ | 3,284 |  |
| Options granted |  |  | 2 |  |  | $ | 19.19 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (65 | ) |  | $ | 16.49 |  |  |  |  |  |  |  |  |  |
| Options forfeited |  |  | (78 | ) |  | $ | 17.93 |  |  |  |  |  |  |  |  |  |
| Options expired |  |  | (142 | ) |  | $ | 25.49 |  |  |  |  |  |  |  |  |  |
| Options outstanding, September 30, 2016 |  |  | 6,825 |  |  | $ | 22.01 |  |  |  | 5.69 |  |  | $ | 7,675 |  |
| Options vested and expected to vest, September 30, 2016 |  |  | 6,729 |  |  | $ | 22.09 |  |  |  | 5.65 |  |  | $ | 7,414 |  |
| Options exercisable, September 30, 2016 |  |  | 4,322 |  |  | $ | 24.40 |  |  |  | 4.19 |  |  | $ | 2,719 |  |

[0001564590-16-028206:notes:45]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between the closing price of our stock on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on September 30, 2016. The aggregate intrinsic value will change based on the fair market value of our stock.

[0001564590-16-028206:notes:46]
The total pre-tax intrinsic value of options exercised during the three and nine months ended September 30, 2016 was $0.1 million and $0.2 million, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-16-028206:notes:47]
6. INVESTMENTS

[0001564590-16-028206:notes:48]
At September 30, 2016, we held the following securities and investments, recorded at either fair value or cost.

[0001564590-16-028206:notes:49]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,656 |  |  | $ | 2,172 |  |  | $ | (20 | ) |  | $ | 13,808 |  |
| Corporate bonds |  |  | 59,900 |  |  |  | 136 |  |  |  | (50 | ) |  |  | 59,986 |  |
| Municipal fixed-rate bonds |  |  | 17,589 |  |  |  | 54 |  |  |  | (4 | ) |  |  | 17,639 |  |
| Asset-backed bonds |  |  | 22,564 |  |  |  | 72 |  |  |  | (23 | ) |  |  | 22,613 |  |
| Mortgage/Agency-backed bonds |  |  | 15,055 |  |  |  | 24 |  |  |  | (43 | ) |  |  | 15,036 |  |
| U.S. government bonds |  |  | 28,437 |  |  |  | 168 |  |  |  | - |  |  |  | 28,605 |  |
| Foreign government bonds |  |  | 6,428 |  |  |  | 3 |  |  |  | (1 | ) |  |  | 6,430 |  |
| Variable rate demand notes |  |  | 12,315 |  |  |  | - |  |  |  | - |  |  |  | 12,315 |  |
| Marketable equity securities |  |  | 26,975 |  |  |  | 1,468 |  |  |  | (1,076 | ) |  |  | 27,367 |  |
| Available-for-sale securities held at fair value |  | $ | 200,919 |  |  | $ | 4,097 |  |  | $ | (1,217 | ) |  | $ | 203,799 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 28,900 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,196 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 233,895 |  |

[0001564590-16-028206:notes:50]
At December 31, 2015, we held the following securities and investments, recorded at either fair value or cost.

[0001564590-16-028206:notes:51]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,325 |  |  | $ | 1,575 |  |  | $ | (66 | ) |  | $ | 12,834 |  |
| Corporate bonds |  |  | 58,328 |  |  |  | 20 |  |  |  | (734 | ) |  |  | 57,614 |  |
| Municipal fixed-rate bonds |  |  | 26,414 |  |  |  | 28 |  |  |  | (18 | ) |  |  | 26,424 |  |
| Asset-backed bonds |  |  | 19,281 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 19,239 |  |
| Mortgage/Agency-backed bonds |  |  | 15,463 |  |  |  | 1 |  |  |  | (91 | ) |  |  | 15,373 |  |
| U.S. Government bonds |  |  | 35,646 |  |  |  | - |  |  |  | (248 | ) |  |  | 35,398 |  |
| Marketable equity securities |  |  | 31,643 |  |  |  | 4,301 |  |  |  | (1,693 | ) |  |  | 34,251 |  |
| Available-for-sale securities held at fair value |  | $ | 198,100 |  |  | $ | 5,927 |  |  | $ | (2,894 | ) |  | $ | 201,133 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,289 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 232,422 |  |

[0001564590-16-028206:notes:52]
As of September 30, 2016, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds had the following contractual maturities:

[0001564590-16-028206:notes:53]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 22,993 |  |  | $ | 12,156 |  |  | $ | - |  |  | $ | - |  |  | $ | 2,952 |  |  | $ | 5,100 |  |
| One to two years |  |  | 24,504 |  |  |  | 3,186 |  |  |  | 1,094 |  |  |  | 1,385 |  |  |  | 9,096 |  |  |  | 1,330 |  |
| Two to three years |  |  | 9,296 |  |  |  | 858 |  |  |  | 8,989 |  |  |  | 2,004 |  |  |  | 4,573 |  |  |  | - |  |
| Three to five years |  |  | 3,193 |  |  |  | 1,439 |  |  |  | 9,739 |  |  |  | - |  |  |  | 11,984 |  |  |  | - |  |
| Five to ten years |  |  | - |  |  |  | - |  |  |  | 2,614 |  |  |  | 1,448 |  |  |  | - |  |  |  | - |  |
| More than ten years |  |  | - |  |  |  | - |  |  |  | 177 |  |  |  | 10,199 |  |  |  | - |  |  |  | - |  |
| Total |  | $ | 59,986 |  |  | $ | 17,639 |  |  | $ | 22,613 |  |  | $ | 15,036 |  |  | $ | 28,605 |  |  | $ | 6,430 |  |

[0001564590-16-028206:notes:54]
Actual maturities may differ from contractual maturities because some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-16-028206:notes:55]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-16-028206:notes:56]
At September 30, 2016, we held a $28.9 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $28.9 million at September 30, 2016 and December 31, 2015. At September 30, 2016, the estimated fair value of the Bond using a level 2 valuation technique was approximately $29.3 million, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

[0001564590-16-028206:notes:57]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and nine months ended September 30, 2016, other-than-temporary impairment charges were not significant.

[0001564590-16-028206:notes:58]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments.

[0001564590-16-028206:notes:59]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Gross realized gains |  | $ | 1,346 |  |  | $ | 2,251 |  |  | $ | 5,226 |  |  | $ | 8,856 |  |
| Gross realized losses |  | $ | (30 | ) |  | $ | (191 | ) |  | $ | (1,072 | ) |  | $ | (426 | ) |

[0001564590-16-028206:notes:60]
As of September 30, 2016 and 2015, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.

[0001564590-16-028206:notes:61]
We have categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows:  Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-16-028206:notes:62]
|  |  | Fair Value Measurements at September 30, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,032 |  |  | $ | 2,032 |  |  | $ | - |  |  | $ | - |  |
| Commercial Paper |  |  | 3,585 |  |  |  | - |  |  |  | 3,585 |  |  |  | - |  |
| Cash equivalents |  |  | 5,617 |  |  |  | 2,032 |  |  |  | 3,585 |  |  |  | - |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,808 |  |  |  | 13,808 |  |  |  | - |  |  |  | - |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 59,986 |  |  |  | - |  |  |  | 59,986 |  |  |  | - |  |
| Municipal fixed-rate bonds |  |  | 17,639 |  |  |  | - |  |  |  | 17,639 |  |  |  | - |  |
| Asset-backed bonds |  |  | 22,613 |  |  |  | - |  |  |  | 22,613 |  |  |  | - |  |
| Mortgage/Agency-backed bonds |  |  | 15,036 |  |  |  | - |  |  |  | 15,036 |  |  |  | - |  |
| U.S. government bonds |  |  | 28,605 |  |  |  | 28,605 |  |  |  | - |  |  |  | - |  |
| Foreign government bonds |  |  | 6,430 |  |  |  | - |  |  |  | 6,430 |  |  |  | - |  |
| Variable rate demand notes |  |  | 12,315 |  |  |  | - |  |  |  | 12,315 |  |  |  | - |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 3,693 |  |  |  | 3,693 |  |  |  | - |  |  |  | - |  |
| Marketable equity securities – other |  |  | 23,674 |  |  |  | 23,674 |  |  |  | - |  |  |  | - |  |
| Available-for-sale securities |  |  | 203,799 |  |  |  | 69,780 |  |  |  | 134,019 |  |  |  | - |  |
| Total |  | $ | 209,416 |  |  | $ | 71,812 |  |  | $ | 137,604 |  |  | $ | - |  |

[0001564590-16-028206:notes:63]
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,271 |  |  | $ | 1,271 |  |  | $ | - |  |  | $ | - |  |
| Commercial Paper |  |  | 11,696 |  |  |  | - |  |  |  | 11,696 |  |  |  | - |  |
| Cash equivalents |  |  | 12,967 |  |  |  | 1,271 |  |  |  | 11,696 |  |  |  | - |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,834 |  |  |  | 12,834 |  |  |  | - |  |  |  | - |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 57,614 |  |  |  | - |  |  |  | 57,614 |  |  |  | - |  |
| Municipal fixed-rate bonds |  |  | 26,424 |  |  |  | - |  |  |  | 26,424 |  |  |  | - |  |
| Asset-backed bonds |  |  | 19,239 |  |  |  | - |  |  |  | 19,239 |  |  |  | - |  |
| Mortgage/Agency-backed bonds |  |  | 15,373 |  |  |  | - |  |  |  | 15,373 |  |  |  | - |  |
| U.S. government bonds |  |  | 35,398 |  |  |  | 35,398 |  |  |  | - |  |  |  | - |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,384 |  |  |  | 5,384 |  |  |  | - |  |  |  | - |  |
| Marketable equity securities – other |  |  | 28,867 |  |  |  | 28,867 |  |  |  | - |  |  |  | - |  |
| Available-for-sale securities |  |  | 201,133 |  |  |  | 82,483 |  |  |  | 118,650 |  |  |  | - |  |
| Total |  | $ | 214,100 |  |  | $ | 83,754 |  |  | $ | 130,346 |  |  | $ | - |  |

[0001564590-16-028206:notes:64]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-16-028206:notes:65]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-16-028206:notes:66]
7. DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001564590-16-028206:notes:67]
We have certain customers and suppliers who are invoiced or pay in a non-functional currency. Changes in the monetary exchange rates may adversely affect our results of operations and financial condition, as these are remeasured to the functional currency through profit and loss. When appropriate, we enter into various derivative transactions to enhance our ability to manage the volatility relating to these typical business exposures. We do not hold or issue derivative instruments for trading or other speculative purposes. Our derivative instruments are recorded in the Consolidated Balance Sheets at their fair values. Our derivative instruments do not qualify for hedge accounting, and accordingly, all changes in the fair value of the instruments are recognized as other income (expense) in the Consolidated Statements of Income. Our derivative instruments are not subject to master netting arrangements and are not offset in the Consolidated Balance Sheets.

[0001564590-16-028206:notes:68]
As of September 30, 2016 and December 31, 2015, we had no forward contracts outstanding.

[0001564590-16-028206:notes:69]
The change in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the three and nine months ended September 30, 2016 and 2015 were as follows:

[0001564590-16-028206:notes:70]
|  |  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Income Statement |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | Location |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | (37 | ) |  | $ | 30 |  |  | $ | 153 |  |  | $ | 208 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-16-028206:notes:71]
8. INVENTORY

[0001564590-16-028206:notes:72]
At September 30, 2016 and December 31, 2015, inventory consisted of the following:

[0001564590-16-028206:notes:73]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Raw materials |  | $ | 37,879 |  |  | $ | 34,223 |  |
| Work in process |  |  | 3,044 |  |  |  | 2,893 |  |
| Finished goods |  |  | 55,111 |  |  |  | 54,417 |  |
| Total |  | $ | 96,034 |  |  | $ | 91,533 |  |

[0001564590-16-028206:notes:74]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At  September 30, 2016 and December 31, 2015, raw materials reserves totaled $18.3 million and $17.5 million, respectively, and finished goods inventory reserves totaled $10.1 million and $9.2 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-16-028206:notes:75]
9. GOODWILL AND INTANGIBLE ASSETS

[0001564590-16-028206:notes:76]
Goodwill, all of which relates to our acquisition of Bluesocket, Inc., was $3.5 million at September 30, 2016 and December 31, 2015, and was previously recorded in our Enterprise Networks reportable segment. As a result of our new reporting structure, which is discussed further in Note 12, we reallocated goodwill from our Enterprise Networks reportable segment to our two, new reportable segments – Network Solutions and Services & Support. As a result, goodwill of $3.1 million and $0.4 million was reallocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-16-028206:notes:77]
[same as prior period, unchanged from 0001564590-16-022906:notes:67]

[0001564590-16-028206:notes:78]
Intangible assets are included in other assets in the accompanying Consolidated Balance Sheets and include intangibles acquired in conjunction with our acquisitions of Objectworld Communications Corporation on September 15, 2009, Bluesocket, Inc. on August 4, 2011, the NSN BBA business on May 4, 2012, and CommScope’s active fiber access business on September 13, 2016.

[0001564590-16-028206:notes:79]
The following table presents our intangible assets as of September 30, 2016 and December 31, 2015:

[0001564590-16-028206:notes:80]
| (In thousands) |  | September 30, 2016 |  |  | December 31, 2015 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 7,178 |  |  | $ | (3,147 | ) |  |  | 4,031 |  |  | $ | 5,828 |  |  | $ | (2,627 | ) |  | $ | 3,201 |  |
| Developed technology |  |  | 6,609 |  |  |  | (4,995 | ) |  |  | 1,614 |  |  |  | 5,720 |  |  |  | (4,329 | ) |  |  | 1,391 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (2,096 | ) |  |  | 244 |  |  |  | 2,340 |  |  |  | (1,854 | ) |  |  | 486 |  |
| Supply agreement |  |  | 1,400 |  |  |  | (78 | ) |  |  | 1,322 |  |  |  | - |  |  |  | - |  |  |  | - |  |
| License |  |  | 500 |  |  |  | (16 | ) |  |  | 484 |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Patent |  |  | 500 |  |  |  | (3 | ) |  |  | 497 |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Trade names |  |  | 370 |  |  |  | (272 | ) |  |  | 98 |  |  |  | 270 |  |  |  | (265 | ) |  |  | 5 |  |
| Non-compete |  |  | 200 |  |  |  | (4 | ) |  |  | 196 |  |  |  | 11 |  |  |  | (11 | ) |  |  | - |  |
| Total |  | $ | 19,097 |  |  | $ | (10,611 | ) |  | $ | 8,486 |  |  | $ | 14,169 |  |  | $ | (9,086 | ) |  | $ | 5,083 |  |

[0001564590-16-028206:notes:81]
Amortization expense, all of which relates to business acquisitions, was $0.5 million for the three months ended September 30, 2016 and 2015, and $1.4 million and $1.5 million for the nine months ended September 30, 2016 and 2015, respectively.

[0001564590-16-028206:notes:82]
As of September 30, 2016, the estimated future amortization expense of our intangible assets is as follows:

[0001564590-16-028206:notes:83]
| (In thousands) |  | Amount |  |
| Remainder of 2016 |  | $ | 1,058 |  |
| 2017 |  |  | 2,901 |  |
| 2018 |  |  | 1,189 |  |
| 2019 |  |  | 675 |  |
| 2020 |  |  | 640 |  |
| Thereafter |  |  | 2,023 |  |
| Total |  | $ | 8,486 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-16-028206:notes:84]
10. STOCKHOLDERS’ EQUITY

[0001564590-16-028206:notes:85]
A summary of the changes in stockholders’ equity for the nine months ended September 30, 2016 is as follows:

[0001564590-16-028206:notes:86]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2015 |  | $ | 480,160 |  |
| Net income |  |  | 27,657 |  |
| Dividend payments |  |  | (13,230 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (30 | ) |
| Net unrealized losses on available-for-sale securities (net of tax) |  |  | (162 | ) |
| Defined benefit plan adjustments |  |  | 103 |  |
| Foreign currency translation adjustment |  |  | 1,202 |  |
| Proceeds from stock option exercises |  |  | 1,076 |  |
| Purchase of treasury stock |  |  | (22,917 | ) |
| Income tax effect of stock compensation arrangements |  |  | (263 | ) |
| Stock-based compensation expense |  |  | 4,601 |  |
| Balance, September 30, 2016 |  | $ | 478,197 |  |

[0001564590-16-028206:notes:87]
[same as prior period, unchanged from 0001564590-16-022906:notes:77]

[0001564590-16-028206:notes:88]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the nine months ended September 30, 2016, we repurchased 1.2 million shares of our common stock at an average price of $18.34 per share. As of September 30, 2016, we have the authority to purchase an additional 4.6 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-16-028206:notes:89]
[same as prior period, unchanged from 0001564590-16-022906:notes:79]

[0001564590-16-028206:notes:90]
We issued 0.1 million shares of treasury stock during the nine months ended September 30, 2016 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $1.1 million from the exercise of these stock options during the nine months ended September 30, 2016.

[0001564590-16-028206:notes:91]
[same as prior period, unchanged from 0001564590-16-022906:notes:81]

[0001564590-16-028206:notes:92]
During the nine months ended September 30, 2016, we paid cash dividends as follows (in thousands except per share amounts):

[0001564590-16-028206:notes:93]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 4, 2016 |  | February 18, 2016 |  | $ | 0.09 |  |  | $ | 4,453 |  |
| April 28, 2016 |  | May 12, 2016 |  | $ | 0.09 |  |  | $ | 4,407 |  |
| July 28, 2016 |  | August 11, 2016 |  | $ | 0.09 |  |  | $ | 4,370 |  |

[0001564590-16-028206:notes:94]
[same as prior period, unchanged from 0001564590-16-022906:notes:84]

[0001564590-16-028206:notes:95]
[same as prior period, unchanged from 0001564590-16-022906:notes:85]

[0001564590-16-028206:notes:96]
The following tables present changes in accumulated other comprehensive income, net of tax, by component for the three months ended September 30, 2016 and 2015:

[0001564590-16-028206:notes:97]
|  |  | Three Months Ended September 30, 2016 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,512 |  |  | $ | (3,828 | ) |  | $ | (6,379 | ) |  | $ | (8,695 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,028 |  |  |  | - |  |  |  | 575 |  |  |  | 1,603 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (770 | ) |  |  | 36 |  |  |  | - |  |  |  | (734 | ) |
| Net current period other comprehensive income (loss) |  |  | 258 |  |  |  | 36 |  |  |  | 575 |  |  |  | 869 |  |
| Ending balance |  | $ | 1,770 |  |  | $ | (3,792 | ) |  | $ | (5,804 | ) |  | $ | (7,826 | ) |

[0001564590-16-028206:notes:98]
|  |  | Three Months Ended September 30, 2015 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 6,678 |  |  | $ | (5,617 | ) |  | $ | (5,728 | ) |  | $ | (4,667 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (3,034 | ) |  |  | - |  |  |  | (1,351 | ) |  |  | (4,385 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,257 | ) |  |  | 71 |  |  |  | - |  |  |  | (1,186 | ) |
| Net current period other comprehensive income (loss) |  |  | (4,291 | ) |  |  | 71 |  |  |  | (1,351 | ) |  |  | (5,571 | ) |
| Ending balance |  | $ | 2,387 |  |  | $ | (5,546 | ) |  | $ | (7,079 | ) |  | $ | (10,238 | ) |

[0001564590-16-028206:notes:99]
The following tables present changes in accumulated other comprehensive income, net of tax, by component for the nine months ended September 30, 2016 and 2015:

[0001564590-16-028206:notes:100]
|  |  | Nine Months Ended September 30, 2016 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,932 |  |  | $ | (3,895 | ) |  | $ | (7,006 | ) |  | $ | (8,969 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 2,267 |  |  |  | - |  |  |  | 1,202 |  |  |  | 3,469 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,429 | ) |  |  | 103 |  |  |  | - |  |  |  | (2,326 | ) |
| Net current period other comprehensive income (loss) |  |  | (162 | ) |  |  | 103 |  |  |  | 1,202 |  |  |  | 1,143 |  |
| Ending balance |  | $ | 1,770 |  |  | $ | (3,792 | ) |  | $ | (5,804 | ) |  | $ | (7,826 | ) |

[0001564590-16-028206:notes:101]
|  |  | Nine Months Ended September 30, 2015 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 8,964 |  |  | $ | (5,757 | ) |  | $ | (3,282 | ) |  | $ | (75 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (1,497 | ) |  |  | - |  |  |  | (3,797 | ) |  |  | (5,294 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (5,080 | ) |  |  | 211 |  |  |  | - |  |  |  | (4,869 | ) |
| Net current period other comprehensive income (loss) |  |  | (6,577 | ) |  |  | 211 |  |  |  | (3,797 | ) |  |  | (10,163 | ) |
| Ending balance |  | $ | 2,387 |  |  | $ | (5,546 | ) |  | $ | (7,079 | ) |  | $ | (10,238 | ) |

[0001564590-16-028206:notes:102]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the three months ended September 30, 2016 and 2015:

[0001564590-16-028206:notes:103]
| (In thousands) |  | Three Months Ended September 30, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,268 |  |  | Net realized investment gain |
| Impairment expense |  |  | (6 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (51 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,211 |  |  |  |
| Tax (expense) benefit |  |  | (477 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 734 |  |  |  |

[0001564590-16-028206:notes:104]
| (1) | Included in the computation of net periodic pension cost. See Note 4 of Notes to Consolidated Financial Statements. |

[0001564590-16-028206:notes:105]
| (In thousands) |  | Three Months Ended September 30, 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 2,098 |  |  | Net realized investment gain |
| Impairment expense |  |  | (37 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (103 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,958 |  |  |  |
| Tax (expense) benefit |  |  | (772 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,186 |  |  |  |

[0001564590-16-028206:notes:106]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the nine months ended September 30, 2016 and 2015:

[0001564590-16-028206:notes:107]
| (In thousands) |  | Nine Months Ended September 30, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 4,383 |  |  | Net realized investment gain |
| Impairment expense |  |  | (401 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (149 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 3,833 |  |  |  |
| Tax (expense) benefit |  |  | (1,507 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,326 |  |  |  |

[0001564590-16-028206:notes:108]
| (In thousands) |  | Nine Months Ended September 30, 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 8,438 |  |  | Net realized investment gain |
| Impairment expense |  |  | (110 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (306 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 8,022 |  |  |  |
| Tax (expense) benefit |  |  | (3,153 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 4,869 |  |  |  |

[0001564590-16-028206:notes:109]
The following table presents the tax effects related to the change in each component of other comprehensive income for the three months ended September 30, 2016 and 2015:

[0001564590-16-028206:notes:110]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 1,685 |  |  | $ | (657 | ) |  | $ | 1,028 |  |  | $ | (4,974 | ) |  | $ | 1,940 |  |  | $ | (3,034 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (1,262 | ) |  |  | 492 |  |  |  | (770 | ) |  |  | (2,061 | ) |  |  | 804 |  |  |  | (1,257 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 51 |  |  |  | (15 | ) |  |  | 36 |  |  |  | 103 |  |  |  | (32 | ) |  |  | 71 |  |
| Foreign currency translation adjustment |  |  | 575 |  |  |  | - |  |  |  | 575 |  |  |  | (1,351 | ) |  |  | - |  |  |  | (1,351 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 1,049 |  |  | $ | (180 | ) |  | $ | 869 |  |  | $ | (8,283 | ) |  | $ | 2,712 |  |  | $ | (5,571 | ) |

[0001564590-16-028206:notes:111]
The following table presents the tax effects related to the change in each component of other comprehensive income for the nine months ended September 30, 2016 and 2015:

[0001564590-16-028206:notes:112]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 3,716 |  |  | $ | (1,449 | ) |  | $ | 2,267 |  |  | $ | (2,454 | ) |  | $ | 957 |  |  | $ | (1,497 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (3,982 | ) |  |  | 1,553 |  |  |  | (2,429 | ) |  |  | (8,328 | ) |  |  | 3,248 |  |  |  | (5,080 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 149 |  |  |  | (46 | ) |  |  | 103 |  |  |  | 306 |  |  |  | (95 | ) |  |  | 211 |  |
| Foreign currency translation adjustment |  |  | 1,202 |  |  |  | - |  |  |  | 1,202 |  |  |  | (3,797 | ) |  |  | - |  |  |  | (3,797 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 1,085 |  |  | $ | 58 |  |  | $ | 1,143 |  |  | $ | (14,273 | ) |  | $ | 4,110 |  |  | $ | (10,163 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-028206:notes:113]
11. EARNINGS PER SHARE

[0001564590-16-028206:notes:114]
A summary of the calculation of basic and diluted earnings per share for the three and nine months ended September 30, 2016 and 2015 is as follows:

[0001564590-16-028206:notes:115]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 12,415 |  |  | $ | 7,067 |  |  | $ | 27,657 |  |  | $ | 12,928 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,470 |  |  |  | 49,862 |  |  |  | 48,839 |  |  |  | 51,682 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 137 |  |  |  | 29 |  |  |  | 137 |  |  |  | 94 |  |
| Restricted stock and restricted stock units |  |  | 71 |  |  |  | 36 |  |  |  | 60 |  |  |  | 16 |  |
| Weighted average number of shares – diluted |  |  | 48,678 |  |  |  | 49,927 |  |  |  | 49,036 |  |  |  | 51,792 |  |
| Net income per share – basic |  | $ | 0.26 |  |  | $ | 0.14 |  |  | $ | 0.57 |  |  | $ | 0.25 |  |
| Net income per share – diluted |  | $ | 0.26 |  |  | $ | 0.14 |  |  | $ | 0.56 |  |  | $ | 0.25 |  |

[0001564590-16-028206:notes:116]
Anti-dilutive options to purchase common stock outstanding were excluded from the above calculations. Anti-dilutive options totaled 5.6 million and 6.0 million for the three months ended September 30, 2016 and 2015, respectively, and 5.7 million and 6.1 million for the nine months ended September 30, 2016 and 2015, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-028206:notes:117]
12. SEGMENT INFORMATION

[0001564590-16-028206:notes:118]
[same as prior period, unchanged from 0001564590-16-022906:notes:108]

[0001564590-16-028206:notes:119]
[same as prior period, unchanged from 0001564590-16-022906:notes:109]

[0001564590-16-028206:notes:120]
The following table presents information about the reported sales and gross profit of our reportable segments for the three and nine months ended September 30, 2016 and 2015. We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-16-028206:notes:121]
|  |  | Three Months Ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 136,277 |  |  | $ | 65,289 |  |  | $ | 138,120 |  |  | $ | 62,151 |  |
| Services & Support |  |  | 32,613 |  |  |  | 10,519 |  |  |  | 19,958 |  |  |  | 8,498 |  |
| Total |  | $ | 168,890 |  |  | $ | 75,808 |  |  | $ | 158,078 |  |  | $ | 70,649 |  |

[0001564590-16-028206:notes:122]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 398,709 |  |  | $ | 195,804 |  |  | $ | 411,723 |  |  | $ | 179,984 |  |
| Services & Support |  |  | 75,086 |  |  |  | 24,753 |  |  |  | 49,328 |  |  |  | 24,474 |  |
| Total |  | $ | 473,795 |  |  | $ | 220,557 |  |  | $ | 461,051 |  |  | $ | 204,458 |  |

[0001564590-16-028206:notes:123]
[same as prior period, unchanged from 0001564590-16-022906:notes:113]

[0001564590-16-028206:notes:124]
[same as prior period, unchanged from 0001564590-16-022906:notes:114]

[0001564590-16-028206:notes:125]
[same as prior period, unchanged from 0001564590-16-022906:notes:115]

[0001564590-16-028206:notes:126]
[same as prior period, unchanged from 0001564590-16-022906:notes:116]

[0001564590-16-028206:notes:127]
|  | • | Total Access® 5000 Series Fiber to the Premises (FTTP) and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001564590-16-028206:notes:128]
|  | • | hiX 5600 Series fiber aggregation and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001564590-16-028206:notes:129]
|  | • | A9000 Series of EPON DOCSIS-provisioned Optical Line Terminals (OLT) |

[0001564590-16-028206:notes:130]
|  | • | Fiber to the Distribution Point (FTTdp) Optical Network Units (ONU) |

[0001564590-16-028206:notes:131]
|  | • | Optical Line Terminals (OLT) |

[0001564590-16-028206:notes:132]
|  | • | Optical Networking Edge (ONE) aggregation |

[0001564590-16-028206:notes:133]
|  | • | Distribution Point Units (DPUs) |

[0001564590-16-028206:notes:134]
|  | • | IP Digital Subscriber Line Access Multiplexers (DSLAMs) |

[0001564590-16-028206:notes:135]
|  | • | Cabinet and Outside-Plant (OSP) enclosures and services |

[0001564590-16-028206:notes:136]
|  | • | Network Management and Cloud based software platforms and applications |

[0001564590-16-028206:notes:137]
|  | • | Pluggable optical transceivers (i.e., SFP, SFP+, XFP, QSFP), cables and other miscellaneous materials |

[0001564590-16-028206:notes:138]
|  | • | Other products and services that are generally applicable to Access & Aggregation |

[0001564590-16-028206:notes:139]
[same as prior period, unchanged from 0001564590-16-022906:notes:128]

[0001564590-16-028206:notes:140]
[same as prior period, unchanged from 0001564590-16-022906:notes:129]

[0001564590-16-028206:notes:141]
|  | • | Broadband customer premise solutions, including Passive Optical Network (PON) and point-to-point Ethernet Optical Network Terminals (ONTs) |

[0001564590-16-028206:notes:142]
|  | • | Radio Frequency over Glass (RFoG) MicroNodes |

[0001564590-16-028206:notes:143]
|  | • | Residential and business gateways |

[0001564590-16-028206:notes:144]
|  | • | Wi-Fi access points and associated powering and switching infrastructure |

[0001564590-16-028206:notes:145]
|  | • | enterprise Session Border Controllers (eSBC) |

[0001564590-16-028206:notes:146]
|  | • | Branch office and access routers |

[0001564590-16-028206:notes:147]
|  | • | Carrier Ethernet services termination devices |

[0001564590-16-028206:notes:148]
|  | • | VoIP media gateways |

[0001564590-16-028206:notes:149]
|  | • | ProServices® |

[0001564590-16-028206:notes:150]
|  | • | Planning, engineering, program management, maintenance, installation and commissioning services to implement the customer devices solutions into consumer, small business and enterprise locations |

[0001564590-16-028206:notes:151]
|  | • | Other products and services that are generally applicable to customer devices |

[0001564590-16-028206:notes:152]
[same as prior period, unchanged from 0001564590-16-022906:notes:140]

[0001564590-16-028206:notes:153]
[same as prior period, unchanged from 0001564590-16-022906:notes:141]

[0001564590-16-028206:notes:154]
|  | • | Time Division Multiplexed (TDM) and Asynchronous Transfer Mode (ATM) based aggregation systems and customer devices |

[0001564590-16-028206:notes:155]
|  | • | HDSL, ADSL and other mature technologies used to deliver business and residential services over the CSP access and customer networks |

[0001564590-16-028206:notes:156]
|  | • | Other products and services that do not fit within the Access & Aggregation and Customer Devices categories |

[0001564590-16-028206:notes:157]
The table below presents sales information by category for the three and nine months ended September 30, 2016 and 2015:

[0001564590-16-028206:notes:158]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Access & Aggregation |  | $ | 120,618 |  |  | $ | 103,431 |  |  | $ | 316,705 |  |  | $ | 309,014 |  |
| Customer Devices |  |  | 32,984 |  |  |  | 35,545 |  |  |  | 106,213 |  |  |  | 97,291 |  |
| Traditional & Other Products |  |  | 15,288 |  |  |  | 19,102 |  |  |  | 50,877 |  |  |  | 54,746 |  |
| Total |  | $ | 168,890 |  |  | $ | 158,078 |  |  | $ | 473,795 |  |  | $ | 461,051 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-16-028206:notes:159]
13. LIABILITY FOR WARRANTY RETURNS

[0001564590-16-028206:notes:160]
Our products generally include warranties of 90 days to ten years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.8 million and $8.7 million at September 30, 2016 and December 31, 2015, respectively. During the three months ended September 30, 2016, we incurred an increase in warranty expense related to a product recall caused by a defect in a part provided by a third party supplier. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0001564590-16-028206:notes:161]
A summary of warranty expense and write-off activity for the three and nine months ended September 30, 2016 and 2015 is as follows:

[0001564590-16-028206:notes:162]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 8,935 |  |  | $ | 8,933 |  |  | $ | 8,739 |  |  | $ | 8,415 |  |
| Plus: Amounts charged to cost and expenses |  |  | 4,012 |  |  |  | 777 |  |  |  | 6,341 |  |  |  | 1,905 |  |
| Less: Deductions |  |  | (4,195 | ) |  |  | (994 | ) |  |  | (6,328 | ) |  |  | (1,604 | ) |
| Balance at end of period |  | $ | 8,752 |  |  | $ | 8,716 |  |  | $ | 8,752 |  |  | $ | 8,716 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-028206:notes:163]
14. COMMITMENTS AND CONTINGENCIES

[0001564590-16-028206:notes:164]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-16-028206:notes:165]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2016, of which $7.7 million has been applied to these commitments.


## us-gaap:SubsequentEventsTextBlock

[0001564590-16-028206:notes:166]
15. SUBSEQUENT EVENTS

[0001564590-16-028206:notes:167]
On October 18, 2016, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on November 03, 2016. The payment date will be November 17, 2016. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-16-028206:notes:168]
During the fourth quarter and as of November 8, 2016, we have repurchased 0.2 million shares of our common stock through open market purchases at an average cost of $17.96 per share. We currently have the authority to purchase an additional 4.4 million shares of our common stock under the current plan approved by the Board of Directors.
