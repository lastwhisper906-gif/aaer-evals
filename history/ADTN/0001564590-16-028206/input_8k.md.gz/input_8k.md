# ADTN 8-K — 0001193125-16-741087 filed 2016-10-19

## item codes, every 8-K on or before 2016-11-08

- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2016-11-08

- none on or before 2016-11-08

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-741087:8k_2_02:1]
EX-99.1
2
d68979dex991.htm
EX-99.1

[0001193125-16-741087:8k_2_02:2]
EX-99.1

[0001193125-16-741087:8k_2_02:3]
EXHIBIT 99.1

[0001193125-16-741087:8k_2_02:4]
ADTRAN, Inc.

[0001193125-16-741087:8k_2_02:5]
REPORTS
RESULTS for the THIRD QUARTER 2016

[0001193125-16-741087:8k_2_02:6]
and DECLARES QUARTERLY CASH DIVIDEND

[0001193125-16-741087:8k_2_02:7]
HUNTSVILLE, AL.—October 18, 2016—ADTRAN, Inc. (NASDAQ:ADTN) reported results for the third quarter 2016. For the quarter, sales were $168,890,000
compared to $158,078,000 for the third quarter of 2015. Net income was $12,415,000 compared to $7,067,000 for the third quarter of 2015. Earnings per share, assuming dilution, were $0.26 compared to $0.14 for the third quarter of 2015. Non-GAAP
earnings per share were $0.26 compared to $0.19 for the third quarter of 2015. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-16-741087:8k_2_02:8]
ADTRAN Chief Executive Officer Tom Stanton stated, “Our revenue performance for the quarter exceeded expectations with total revenue increasing 7% over
the same period last year. I am particularly pleased to see our international business grow 42 percent over the previous quarter and 7 percent year-over-year, driven by stronger broadband access sales in Europe. I am also pleased with the continued
growth in our services business which increased 35 percent over the previous quarter and grew 63 percent year-over-year as we execute on our leading market position in CAF II and vectoring solutions and services. We continue to believe that
ADTRAN’s ability to help service providers grow revenue, reduce costs, accelerate buildout and transition to a software-defined access network is proving to be a catalyst for change within the industry.”

[0001193125-16-741087:8k_2_02:9]
The Company also announced that its Board of Directors declared a cash dividend for the third quarter of 2016. The quarterly cash dividend is $0.09 per common
share to be paid to holders of record at the close of business on November 3, 2016. The ex-dividend date is November 1, 2016, and the payment date is November 17, 2016.

[0001193125-16-741087:8k_2_02:10]
The Company confirmed that its third quarter conference call will be held Wednesday, October 19, 2016, at 9:30 a.m. Central Time. This conference call will be
web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the call and click on the conference call link provided.

[0001193125-16-741087:8k_2_02:11]
An online replay of the conference call will be available for seven days at www.streetevents.com. In addition, an online replay of the conference call, as
well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following the call.

[0001193125-16-741087:8k_2_02:12]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet
communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit
www.adtran.com.

[0001193125-16-741087:8k_2_02:13]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web, visit
www.adtran.com.

[0001193125-16-741087:8k_2_02:14]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known.
However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs,
manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2015. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements
included in this press release.

[0001193125-16-741087:8k_2_02:15]
| CONTACT: Roger Shannon Senior Vice President & CFO 256-963-8775 |  | INVESTOR SERVICES/ASSISTANCE: Gayle Ellis Investor Services 256-963-8220 |

[0001193125-16-741087:8k_2_02:16]
Condensed Consolidated Balance Sheet

[0001193125-16-741087:8k_2_02:17]
(Unaudited)

[0001193125-16-741087:8k_2_02:18]
(In
thousands)

[0001193125-16-741087:8k_2_02:19]
|  |  | September 30,2016 |  |  | December 31,2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 66,292 |  |  | $ | 84,550 |  |
| Short-term investments |  |  | 55,516 |  |  |  | 34,396 |  |
| Accounts receivable, net |  |  | 101,822 |  |  |  | 71,917 |  |
| Other receivables |  |  | 12,159 |  |  |  | 19,321 |  |
| Income tax receivable, net |  |  | 540 |  |  |  | — |  |
| Inventory |  |  | 96,034 |  |  |  | 91,533 |  |
| Prepaid expenses and other current assets |  |  | 14,477 |  |  |  | 10,145 |  |
| Deferred tax assets, net |  |  | 17,963 |  |  |  | 18,924 |  |
| Total Current Assets |  |  | 364,803 |  |  |  | 330,786 |  |
| Property, plant and equipment, net |  |  | 78,078 |  |  |  | 73,233 |  |
| Deferred tax assets, net |  |  | 17,263 |  |  |  | 18,091 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 13,548 |  |  |  | 9,276 |  |
| Long-term investments |  |  | 178,379 |  |  |  | 198,026 |  |
| Total Assets |  | $ | 655,563 |  |  | $ | 632,904 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 67,399 |  |  | $ | 48,668 |  |
| Unearned revenue |  |  | 15,744 |  |  |  | 16,615 |  |
| Accrued expenses |  |  | 16,010 |  |  |  | 12,108 |  |
| Accrued wages and benefits |  |  | 16,468 |  |  |  | 12,857 |  |
| Income tax payable, net |  |  | — |  |  |  | 2,395 |  |
| Total Current Liabilities |  |  | 115,621 |  |  |  | 92,643 |  |
| Non-current unearned revenue |  |  | 7,105 |  |  |  | 7,965 |  |
| Other non-current liabilities |  |  | 26,740 |  |  |  | 24,236 |  |
| Bonds payable |  |  | 27,900 |  |  |  | 27,900 |  |
| Total Liabilities |  |  | 177,366 |  |  |  | 152,744 |  |
| Stockholders’ Equity |  |  | 478,197 |  |  |  | 480,160 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 655,563 |  |  | $ | 632,904 |  |

[0001193125-16-741087:8k_2_02:20]
Consolidated Statements of Income

[0001193125-16-741087:8k_2_02:21]
(Unaudited)

[0001193125-16-741087:8k_2_02:22]
(In
thousands, except per share data)

[0001193125-16-741087:8k_2_02:23]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 136,277 |  |  | $ | 138,120 |  |  | $ | 398,709 |  |  | $ | 411,723 |  |
| Services |  |  | 32,613 |  |  |  | 19,958 |  |  |  | 75,086 |  |  |  | 49,328 |  |
| Total Sales |  |  | 168,890 |  |  |  | 158,078 |  |  |  | 473,795 |  |  |  | 461,051 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 70,988 |  |  |  | 75,969 |  |  |  | 202,905 |  |  |  | 231,739 |  |
| Services |  |  | 22,094 |  |  |  | 11,460 |  |  |  | 50,333 |  |  |  | 24,854 |  |
| Total Cost of Sales |  |  | 93,082 |  |  |  | 87,429 |  |  |  | 253,238 |  |  |  | 256,593 |  |
| Gross Profit |  |  | 75,808 |  |  |  | 70,649 |  |  |  | 220,557 |  |  |  | 204,458 |  |
| Selling, general and administrative expenses |  |  | 33,716 |  |  |  | 30,016 |  |  |  | 97,367 |  |  |  | 93,203 |  |
| Research and development expenses |  |  | 31,962 |  |  |  | 32,561 |  |  |  | 92,727 |  |  |  | 100,576 |  |
| Operating Income |  |  | 10,130 |  |  |  | 8,072 |  |  |  | 30,463 |  |  |  | 10,679 |  |
| Interest and dividend income |  |  | 910 |  |  |  | 839 |  |  |  | 2,692 |  |  |  | 2,680 |  |
| Interest expense |  |  | (143 | ) |  |  | (151 | ) |  |  | (430 | ) |  |  | (448 | ) |
| Net realized investment gain |  |  | 1,316 |  |  |  | 2,060 |  |  |  | 4,154 |  |  |  | 8,430 |  |
| Other income (expense), net |  |  | (246 | ) |  |  | 52 |  |  |  | (378 | ) |  |  | (848 | ) |
| Gain on bargain purchase of a business |  |  | 3,550 |  |  |  | — |  |  |  | 3,550 |  |  |  | — |  |
| Income before provision for income taxes |  |  | 15,517 |  |  |  | 10,872 |  |  |  | 40,051 |  |  |  | 20,493 |  |
| Provision for income taxes |  |  | (3,102 | ) |  |  | (3,805 | ) |  |  | (12,394 | ) |  |  | (7,565 | ) |
| Net Income |  | $ | 12,415 |  |  | $ | 7,067 |  |  | $ | 27,657 |  |  | $ | 12,928 |  |
| Weighted average shares outstanding—basic |  |  | 48,470 |  |  |  | 49,862 |  |  |  | 48,839 |  |  |  | 51,682 |  |
| Weighted average shares outstanding—diluted (1) |  |  | 48,678 |  |  |  | 49,927 |  |  |  | 49,036 |  |  |  | 51,792 |  |
| Earnings per common share—basic |  | $ | 0.26 |  |  | $ | 0.14 |  |  | $ | 0.57 |  |  | $ | 0.25 |  |
| Earnings per common share—diluted (1) |  | $ | 0.26 |  |  | $ | 0.14 |  |  | $ | 0.56 |  |  | $ | 0.25 |  |

[0001193125-16-741087:8k_2_02:24]
(1) Assumes exercise of dilutive stock options calculated under the
treasury stock method.

[0001193125-16-741087:8k_2_02:25]
Consolidated Statements of Comprehensive Income

[0001193125-16-741087:8k_2_02:26]
(Unaudited)

[0001193125-16-741087:8k_2_02:27]
(In
thousands)

[0001193125-16-741087:8k_2_02:28]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net Income |  | $ | 12,415 |  |  | $ | 7,067 |  |  | $ | 27,657 |  |  | $ | 12,928 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | 258 |  |  |  | (4,291 | ) |  |  | (162 | ) |  |  | (6,577 | ) |
| Defined benefit plan adjustments |  |  | 36 |  |  |  | 71 |  |  |  | 103 |  |  |  | 211 |  |
| Foreign currency translation |  |  | 575 |  |  |  | (1,351 | ) |  |  | 1,202 |  |  |  | (3,797 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  | 869 |  |  |  | (5,571 | ) |  |  | 1,143 |  |  |  | (10,163 | ) |
| Comprehensive Income, net of tax |  | $ | 13,284 |  |  | $ | 1,496 |  |  | $ | 28,800 |  |  | $ | 2,765 |  |

[0001193125-16-741087:8k_2_02:29]
Consolidated Statements of Cash Flows

[0001193125-16-741087:8k_2_02:30]
(Unaudited)

[0001193125-16-741087:8k_2_02:31]
(In
thousands)

[0001193125-16-741087:8k_2_02:32]
|  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 27,657 |  |  | $ | 12,928 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 10,260 |  |  |  | 10,765 |  |
| Amortization of net premium on available-for-sale investments |  |  | 489 |  |  |  | 2,085 |  |
| Net realized gain on long-term investments |  |  | (4,154 | ) |  |  | (8,430 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 21 |  |  |  | 189 |  |
| Gain on bargain purchase of a business |  |  | (3,550 | ) |  |  | — |  |
| Stock-based compensation expense |  |  | 4,601 |  |  |  | 4,788 |  |
| Deferred income taxes |  |  | (447 | ) |  |  | (2,332 | ) |
| Tax impact from stock option exercises |  |  | (16 | ) |  |  | (40 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | — |  |  |  | (3 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (29,370 | ) |  |  | 843 |  |
| Other receivables |  |  | 7,475 |  |  |  | 10,532 |  |
| Inventory |  |  | (683 | ) |  |  | (14,945 | ) |
| Prepaid expenses and other assets |  |  | (5,180 | ) |  |  | (1,665 | ) |
| Accounts payable |  |  | 16,363 |  |  |  | 13,687 |  |
| Accrued expenses and other liabilities |  |  | 7,307 |  |  |  | (3,996 | ) |
| Income tax payable/receivable, net |  |  | (2,941 | ) |  |  | (1,137 | ) |
| Net cash provided by operating activities |  |  | 27,832 |  |  |  | 23,269 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (12,684 | ) |  |  | (7,843 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 122 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 141,103 |  |  |  | 189,728 |  |
| Purchases of available-for-sale investments |  |  | (139,181 | ) |  |  | (113,227 | ) |
| Acquisition of business |  |  | (943 | ) |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | (11,705 | ) |  |  | 68,780 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 1,076 |  |  |  | 907 |  |
| Purchases of treasury stock |  |  | (22,917 | ) |  |  | (65,808 | ) |
| Dividend payments |  |  | (13,230 | ) |  |  | (13,989 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | — |  |  |  | 3 |  |
| Net cash used in financing activities |  |  | (35,071 | ) |  |  | (78,887 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (18,944 | ) |  |  | 13,162 |  |
| Effect of exchange rate changes |  |  | 686 |  |  |  | (2,914 | ) |
| Cash and cash equivalents, beginning of period |  |  | 84,550 |  |  |  | 73,439 |  |
| Cash and cash equivalents, end of period |  | $ | 66,292 |  |  | $ | 83,687 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 1,174 |  |  | $ | 1,303 |  |

[0001193125-16-741087:8k_2_02:33]
Supplemental Information

[0001193125-16-741087:8k_2_02:34]
Restructuring Expenses

[0001193125-16-741087:8k_2_02:35]
(Unaudited)

[0001193125-16-741087:8k_2_02:36]
(In
thousands)

[0001193125-16-741087:8k_2_02:37]
Restructuring expenses were recorded in the following Consolidated Statements of Income categories for the three and nine months ended
September 30, 2016 and 2015:

[0001193125-16-741087:8k_2_02:38]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Restructuring expense included in cost of sales |  | $ | 1,307 |  |  | $ | 9 |  |  | $ | 1,307 |  |  | $ | 107 |  |
| Selling, general and administrative expense |  |  | 637 |  |  |  | 194 |  |  |  | 637 |  |  |  | 838 |  |
| Research and development expense |  |  | — |  |  |  | 712 |  |  |  | — |  |  |  | 2,095 |  |
| Restructuring expense included in operating expenses |  |  | 637 |  |  |  | 906 |  |  |  | 637 |  |  |  | 2,933 |  |
| Total restructuring expense |  |  | 1,944 |  |  |  | 915 |  |  |  | 1,944 |  |  |  | 3,040 |  |
| Provision for income taxes |  |  | (603 | ) |  |  | (357 | ) |  |  | (603 | ) |  |  | (1,186 | ) |
| Total restructuring expense, net of tax |  | $ | 1,341 |  |  | $ | 558 |  |  | $ | 1,341 |  |  | $ | 1,854 |  |

[0001193125-16-741087:8k_2_02:39]
Supplemental Information

[0001193125-16-741087:8k_2_02:40]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-16-741087:8k_2_02:41]
(Unaudited)

[0001193125-16-741087:8k_2_02:42]
(In
thousands)

[0001193125-16-741087:8k_2_02:43]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc., on May 4, 2012, we closed on the acquisition of the Nokia
Siemens Networks Broadband Access business (NSN BBA), and on September 13, 2016, we closed on the acquisition of CommScope’s active fiber business (CommScope). Acquisition related expenses, amortizations and adjustments for the three and
nine months ended September 30, 2016 and 2015 for all three transactions are as follows:

[0001193125-16-741087:8k_2_02:44]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 158 |  |  | $ | 191 |  |  | $ | 504 |  |  | $ | 643 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 225 |  |  |  | 231 |  |  |  | 680 |  |  |  | 701 |  |
| Amortization of other purchase accounting adjustments |  |  | 114 |  |  |  | 101 |  |  |  | 194 |  |  |  | 395 |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | 20 |  |  |  | — |  |  |  | 61 |  |
| Subtotal NSN BBA acquisition |  |  | 339 |  |  |  | 352 |  |  |  | 874 |  |  |  | 1,157 |  |
| CommScope acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 112 |  |  |  | — |  |  |  | 112 |  |  |  | — |  |
| Amortization of other purchase accounting adjustments |  |  | 84 |  |  |  | — |  |  |  | 84 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | 45 |  |  |  | — |  |  |  | 45 |  |  |  | — |  |
| Subtotal CommScope acquisition |  |  | 241 |  |  |  | — |  |  |  | 241 |  |  |  | — |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 738 |  |  |  | 543 |  |  |  | 1,619 |  |  |  | 1,800 |  |
| Provision for income taxes |  |  | (261 | ) |  |  | (183 | ) |  |  | (512 | ) |  |  | (609 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 477 |  |  | $ | 360 |  |  | $ | 1,057 |  |  | $ | 1,191 |  |

[0001193125-16-741087:8k_2_02:45]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three and nine months ended September 30, 2016 and 2015:

[0001193125-16-741087:8k_2_02:46]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | — |  |  | $ | 65 |  |  | $ | — |  |  | $ | 196 |  |
| Cost of goods sold |  |  | 169 |  |  |  | 7 |  |  |  | 189 |  |  |  | 52 |  |
| Subtotal |  |  | 169 |  |  |  | 72 |  |  |  | 189 |  |  |  | 248 |  |
| Selling, general and administrative expenses |  |  | 54 |  |  |  | 23 |  |  |  | 61 |  |  |  | 74 |  |
| Research and development expenses |  |  | 515 |  |  |  | 448 |  |  |  | 1,369 |  |  |  | 1,478 |  |
| Subtotal |  |  | 569 |  |  |  | 471 |  |  |  | 1,430 |  |  |  | 1,552 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 738 |  |  |  | 543 |  |  |  | 1,619 |  |  |  | 1,800 |  |
| Provision for income taxes |  |  | (261 | ) |  |  | (183 | ) |  |  | (562 | ) |  |  | (609 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 477 |  |  | $ | 360 |  |  | $ | 1,057 |  |  | $ | 1,191 |  |

[0001193125-16-741087:8k_2_02:47]
Supplemental Information

[0001193125-16-741087:8k_2_02:48]
Stock-based Compensation Expense

[0001193125-16-741087:8k_2_02:49]
(Unaudited)

[0001193125-16-741087:8k_2_02:50]
(In
thousands)

[0001193125-16-741087:8k_2_02:51]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 88 |  |  | $ | 59 |  |  | $ | 282 |  |  | $ | 202 |  |
| Selling, general and administrative expense |  |  | 765 |  |  |  | 812 |  |  |  | 2,322 |  |  |  | 2,226 |  |
| Research and development expense |  |  | 639 |  |  |  | 803 |  |  |  | 1,997 |  |  |  | 2,360 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,404 |  |  |  | 1,615 |  |  |  | 4,319 |  |  |  | 4,586 |  |
| Total stock-based compensation expense |  |  | 1,492 |  |  |  | 1,674 |  |  |  | 4,601 |  |  |  | 4,788 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (218 | ) |  |  | (218 | ) |  |  | (643 | ) |  |  | (620 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,274 |  |  | $ | 1,456 |  |  | $ | 3,958 |  |  | $ | 4,168 |  |

[0001193125-16-741087:8k_2_02:52]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-16-741087:8k_2_02:53]
Non-GAAP net income per share, diluted

[0001193125-16-741087:8k_2_02:54]
(Unaudited)

[0001193125-16-741087:8k_2_02:55]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| GAAP earnings per common share – diluted |  | $ | 0.26 |  |  | $ | 0.14 |  |  | $ | 0.56 |  |  | $ | 0.25 |  |
| Restructuring expense |  |  | 0.03 |  |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.04 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.02 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.08 |  |  |  | 0.08 |  |
| Gain on bargain purchase of a business |  |  | (0.07 | ) |  |  | — |  |  |  | (0.07 | ) |  |  | — |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.26 |  |  | $ | 0.19 |  |  | $ | 0.62 |  |  | $ | 0.39 |  |
