# ADTN MD&A — 0001564590-16-028206


## mdna

[0001564590-16-028206:mdna:1]
[same as prior period, unchanged from 0001564590-16-022906:mdna:1]

[0001564590-16-028206:mdna:2]
[same as prior period, unchanged from 0001564590-16-022906:mdna:2]

[0001564590-16-028206:mdna:3]
[same as prior period, unchanged from 0001564590-16-022906:mdna:3]

[0001564590-16-028206:mdna:4]
[same as prior period, unchanged from 0001564590-16-022906:mdna:4]

[0001564590-16-028206:mdna:5]
[same as prior period, unchanged from 0001564590-16-022906:mdna:5]

[0001564590-16-028206:mdna:6]
[same as prior period, unchanged from 0001564590-16-022906:mdna:6]

[0001564590-16-028206:mdna:7]
[same as prior period, unchanged from 0001564590-16-022906:mdna:7]

[0001564590-16-028206:mdna:8]
[same as prior period, unchanged from 0001564590-16-022906:mdna:8]

[0001564590-16-028206:mdna:9]
|  | • | Total Access® 5000 Series Fiber to the Premises (FTTP) and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001564590-16-028206:mdna:10]
|  | • | hiX 5600 Series fiber aggregation and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001564590-16-028206:mdna:11]
|  | • | A9000 Series of EPON DOCSIS-provisioned Optical Line Terminals (OLT) |

[0001564590-16-028206:mdna:12]
|  | • | Fiber to the Distribution Point (FTTdp) Optical Network Units (ONU) |

[0001564590-16-028206:mdna:13]
|  | • | Optical Line Terminals (OLT) |

[0001564590-16-028206:mdna:14]
|  | • | Optical Networking Edge (ONE) aggregation |

[0001564590-16-028206:mdna:15]
|  | • | Distribution Point Units (DPUs) |

[0001564590-16-028206:mdna:16]
|  | • | IP Digital Subscriber Line Access Multiplexers (DSLAMs) |

[0001564590-16-028206:mdna:17]
|  | • | Cabinet and Outside-Plant (OSP) enclosures and services |

[0001564590-16-028206:mdna:18]
|  | • | Network Management and Cloud based software platforms and applications |

[0001564590-16-028206:mdna:19]
|  | • | Pluggable optical transceivers (i.e., SFP, SFP+, XFP, QSFP), cables and other miscellaneous materials |

[0001564590-16-028206:mdna:20]
|  | • | Other products and services that are generally applicable to Access & Aggregation |

[0001564590-16-028206:mdna:21]
[same as prior period, unchanged from 0001564590-16-022906:mdna:20]

[0001564590-16-028206:mdna:22]
[same as prior period, unchanged from 0001564590-16-022906:mdna:21]

[0001564590-16-028206:mdna:23]
|  | • | Broadband customer premise solutions, including Passive Optical Network (PON) and point-to-point Ethernet Optical Network Terminals (ONTs) |

[0001564590-16-028206:mdna:24]
|  | • | Radio Frequency over Glass (RFoG) MicroNodes |

[0001564590-16-028206:mdna:25]
|  | • | Residential and business gateways |

[0001564590-16-028206:mdna:26]
|  | • | Wi-Fi access points and associated powering and switching infrastructure |

[0001564590-16-028206:mdna:27]
|  | • | enterprise Session Border Controllers (eSBC) |

[0001564590-16-028206:mdna:28]
|  | • | Branch office and access routers |

[0001564590-16-028206:mdna:29]
|  | • | Carrier Ethernet services termination devices |

[0001564590-16-028206:mdna:30]
|  | • | VoIP media gateways |

[0001564590-16-028206:mdna:31]
|  | • | ProServices |

[0001564590-16-028206:mdna:32]
|  | • | Planning, engineering, program management, maintenance, installation and commissioning services to implement the customer devices solutions into consumer, small business and enterprise locations |

[0001564590-16-028206:mdna:33]
|  | • | Other products and services that are generally applicable to customer devices |

[0001564590-16-028206:mdna:34]
[same as prior period, unchanged from 0001564590-16-022906:mdna:32]

[0001564590-16-028206:mdna:35]
[same as prior period, unchanged from 0001564590-16-022906:mdna:33]

[0001564590-16-028206:mdna:36]
|  | • | Time Division Multiplexed (TDM) and Asynchronous Transfer Mode (ATM) based aggregation systems and customer devices |

[0001564590-16-028206:mdna:37]
|  | • | HDSL, ADSL and other mature technologies used to deliver business and residential services over the CSP access and customer networks |

[0001564590-16-028206:mdna:38]
|  | • | Other products and services that do not fit within the Access & Aggregation and Customer Devices categories |

[0001564590-16-028206:mdna:39]
See Note 12 of Notes to Consolidated Financial Statements in this report for further information regarding these product categories.

[0001564590-16-028206:mdna:40]
Sales were $168.9 million and $473.8 million for the three and nine months ended September 30, 2016 compared to $158.1 million and $461.1 million for the three and nine months ended September 30, 2015. Our gross margin increased to 44.9% and 46.6% for the three and nine months ended September 30, 2016 from 44.7% and 44.3% for the three and nine months ended September 30, 2015. Our operating income margin increased to 6.0% and 6.4% for the three and nine months ended September 30, 2016 from 5.1% and 2.3% for the three and nine months ended September 30, 2015. Net income was $12.4 million and $27.7 million for the three and nine months ended September 30, 2016, compared to $7.1 million and $12.9 million for the three and nine months ended September 30, 2015. Our effective tax rate, excluding the tax impact of the bargain purchase gain, decreased to 25.9% and 34.0% for the three and nine months ended September 30, 2016 from 35.0% and 36.9% for the three and nine months ended September 30, 2015.  Earnings per share, assuming dilution, were $0.26 and $0.56 for the three and nine months ended September 30, 2016, compared to $0.14 and $0.25 for the three and nine months ended September 30, 2015.

[0001564590-16-028206:mdna:41]
[same as prior period, unchanged from 0001564590-16-022906:mdna:39]

[0001564590-16-028206:mdna:42]
[same as prior period, unchanged from 0001564590-16-022906:mdna:40]

[0001564590-16-028206:mdna:43]
[same as prior period, unchanged from 0001564590-16-022906:mdna:41]

[0001564590-16-028206:mdna:44]
[same as prior period, unchanged from 0001564590-16-022906:mdna:42]

[0001564590-16-028206:mdna:45]
[same as prior period, unchanged from 0001564590-16-022906:mdna:43]

[0001564590-16-028206:mdna:46]
[same as prior period, unchanged from 0001564590-16-022906:mdna:44]

[0001564590-16-028206:mdna:47]
[same as prior period, unchanged from 0001564590-16-022906:mdna:45]

[0001564590-16-028206:mdna:48]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2016 COMPARED TO THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2015

[0001564590-16-028206:mdna:49]
[same as prior period, unchanged from 0001564590-16-022906:mdna:47]

[0001564590-16-028206:mdna:50]
Our sales increased 6.8% from $158.1 million in the three months ended September 30, 2015 to $168.9 million in the three months ended September 30, 2016, and increased 2.8% from $461.1 million in the nine months ended September 30, 2015 to $473.8 million in the nine months ended September 30, 2016. The increase in sales for the three months ended September 30, 2016 is primarily attributable to a $17.2 million increase in our Access and Aggregation products, partially offset by a $3.8 million decrease in sales of our Traditional & Other products and a $2.6 million decrease in sales of our Customer Devices products. The increase in sales for the nine months ended September 30, 2016 is primarily attributable to a $8.9 million increase in sales of our Customer Devices products and a $7.7 million increase in sales of our Access & Aggregation products, partially offset by a $3.9 million decrease in sales of our Traditional & Other products.

[0001564590-16-028206:mdna:51]
Network Solutions sales decreased 1.3% from $138.1 million in the three months ended September 30, 2015 to $136.3 million in the three months ended September 30, 2016, and decreased 3.2% from $411.7 million in the nine months ended September 30, 2015 to $398.7 million in the nine months ended September 30, 2016. The decrease in sales for the three months ended September 30, 2016 is primarily attributable to a decrease in sales of Customer Devices products and Traditional & Other products, partially offset by an increase in Access & Aggregation products. The decrease in sales of our Customer Devices products is primarily attributable to decreased sales of our Ethernet products. The increase in sales of our Access and Aggregation products for the three months ended September 30, 2016 is primarily attributable to an increase in international hiX product sales. The decrease in sales for the nine months ended September 30, 2016 is primarily attributable to a decrease in sales of Access & Aggregation products and Traditional & Other products, partially offset by an increase in Customer Devices products. The decrease in sales of our Access and Aggregation products is primarily attributable to a decrease in international hiX product sales, partially offset by an increase in U.S. Total Access 5000 product sales. The increase in sales of our Customer Devices products is primarily attributable to increased sales of our FTTP ONT products and Ethernet products. While we expect that revenues from Traditional & Other products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-16-028206:mdna:52]
Services & Support sales increased 63.4% from $20.0 million in the three months ended September 30, 2015 to $32.6 million in the three months ended September 30, 2016, and increased 52.2% from $49.3 million in the nine months ended September 30, 2015 to $75.1 million in the nine months ended September 30, 2016. The increase in sales for the three and nine months ended September 30, 2016 is primarily attributable to an increase in network installation services for Access and Aggregation products.

[0001564590-16-028206:mdna:53]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, increased 6.7% from $38.6 million in the three months ended September 30, 2015 to $41.2 million in the three months ended September 30, 2016, and decreased 37.4% from $153.7 million in the nine months ended September 30, 2015 to $96.2 million in the nine months ended September 30, 2016. International sales, as a percentage of total sales, stayed consistent at 24.4% for the three months ended September 30, 2016 and 2015, and decreased from 33.3% for the nine months ended September 30, 2015 to 20.3% for the nine months ended September 30, 2016. Our international revenues are affected to a great extent by the timing of network upgrade projects at our larger European and Latin American customers and by changes in foreign exchange rates in territories in which we sell or products and services. Throughout 2016, our largest European customer has focused on completing network upgrade activities in regions outside of our footprint with them, and we currently expect this pattern to continue throughout the remainder of 2016. However, we expect that once current projects are completed, future network upgrades will resume in the second half of 2017 within our geographic footprint with this customer. Additionally, after reaching a cyclical high in the second quarter of 2014, the value of the Euro currency relative to the U.S. dollar declined significantly throughout the second half of 2014 and in 2015. Though the Euro-USD exchange rate appears to have stabilized since reaching a low in the fourth quarter of 2015, it remains approximately 20% below the highs of 2014. This decline in the value of the Euro throughout 2015 and into 2016 significantly reduced the U.S. dollar value of revenue from our European sales.

[0001564590-16-028206:mdna:54]
[same as prior period, unchanged from 0001564590-16-022906:mdna:52]

[0001564590-16-028206:mdna:55]
As a percentage of sales, cost of sales decreased from 55.3% in the three months ended September 30, 2015 to 55.1% in the three months ended September 30, 2016, and decreased from 55.7% in the nine months ended September 30, 2015 to 53.4% in the nine months ended September 30, 2016. The decrease in cost of sales as a percentage of sales for the three and nine months ended September 30, 2016 is primarily attributable to a regional revenue shift and customer and product mix, partially offset by a change in services mix, restructuring expenses and an increase in warranty expense related to a product recall caused by a defect in a part provided by a third party supplier.

[0001564590-16-028206:mdna:56]
Network Solutions cost of sales, as a percent of that segment’s sales, decreased from 55.0% in the three months ended September 30, 2015 to 52.1% in the three months ended September 30, 2016, and decreased from 56.3% in the nine months ended September 30, 2015 to 50.9% in the nine months ended September 30, 2016. The decrease in cost of sales as a percent of that segment’s sales for the three and nine months ended September 30, 2016 is primarily attributable to a regional revenue shift and customer and product mix, partially offset by restructuring expenses and an increase in warranty expense related to a product recall caused by a defect in a part provided by a third party supplier.

[0001564590-16-028206:mdna:57]
Services & Support cost of sales, as a percent of that segment’s sales, increased from 57.4% in the three months ended September 30, 2015 to 67.7% in the three months ended September 30, 2016, and increased from 50.4% in the nine months ended September 30, 2015 to 67.0% in the nine months ended September 30, 2016. The increase in cost of sales as a percent of that segment’s sales for the three and nine months ended September 30, 2016 is primarily attributable to an increase in network installation services, which have higher costs, versus a greater mix of maintenance and support services in the prior periods, and in restructuring expenses.

[0001564590-16-028206:mdna:58]
[same as prior period, unchanged from 0001564590-16-022906:mdna:56]

[0001564590-16-028206:mdna:59]
[same as prior period, unchanged from 0001564590-16-022906:mdna:57]

[0001564590-16-028206:mdna:60]
Selling, general and administrative expenses increased 12.3% from $30.0 million in the three months ended September 30, 2015 to $33.7 million in the three months ended September 30, 2016, and increased 4.5% from $93.2 million in the nine months ended September 30, 2015 to $97.4 million in the nine months ended September 30, 2016. The increase in selling, general and administrative expenses for the three months ended September 30, 2016 is primarily attributable to an increase in variable incentive compensation expense, partially offset by a decrease in marketing expenses. The increase in selling, general and administrative expenses for the nine months ended September 30, 2016 is primarily attributable to an increase in variable incentive compensation expense and contract services, partially offset by a decrease in professional services and marketing expenses.

[0001564590-16-028206:mdna:61]
As a percentage of sales, selling, general and administrative expenses increased from 19.0% in the three months ended September 30, 2015 to 20.0% in the three months ended September 30, 2016, and increased from 20.2% in the nine months ended September 30, 2015 to 20.6% in the nine months ended September 30, 2016. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-16-028206:mdna:62]
[same as prior period, unchanged from 0001564590-16-022906:mdna:60]

[0001564590-16-028206:mdna:63]
Research and development expenses decreased 1.8% from $32.6 million in the three months ended September 30, 2015 to $32.0 million in the three months ended September 30, 2016, and decreased 7.8% from $100.6 million in the nine months ended September 30, 2015 to $92.7 million in the nine months ended September 30, 2016. The decrease in research and development expenses for the three months ended September 30, 2016 is primarily attributable to a decrease in compensation expense, lease expense and testing expense. The decrease in research and development expenses for the nine months ended September 30, 2016 is primarily attributable to a decrease in compensation expense, lease expense and testing expense, partially offset by an increase in contract services. The decrease in compensation expense and lease expense for the three and nine months ended September 30, 2016 was primary attributable to the consolidation of engineering resources that occurred during the second quarter of 2015.

[0001564590-16-028206:mdna:64]
As a percentage of sales, research and development expenses decreased from 20.6% in the three months ended September 30, 2015 to 18.9% in the three months ended September 30, 2016, and decreased from 21.8% in the nine months ended September 30, 2015 to 19.6% in the nine months ended September 30, 2016. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001564590-16-028206:mdna:65]
[same as prior period, unchanged from 0001564590-16-022906:mdna:63]

[0001564590-16-028206:mdna:66]
[same as prior period, unchanged from 0001564590-16-022906:mdna:64]

[0001564590-16-028206:mdna:67]
Interest and dividend income increased 8.5%, or $0.1 million from the three months ended September 30, 2015 to the three months ended September 30, 2016, and was consistent at $2.7 million for the nine months ended September 30, 2016 and 2015. The increase in interest and dividend income for the three months ended September 30, 2016, is primarily attributable to an increase in the rate of return on fixed income investments.

[0001564590-16-028206:mdna:68]
[same as prior period, unchanged from 0001564590-16-022906:mdna:66]

[0001564590-16-028206:mdna:69]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.14 million and $0.15 million in the three months ended September 30, 2015 and 2016, respectively, and $0.4 million in the nine months ended September 30, 2015 and 2016, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-16-028206:mdna:70]
[same as prior period, unchanged from 0001564590-16-022906:mdna:68]

[0001564590-16-028206:mdna:71]
Net realized investment gains decreased 36.1% from $2.1 million in the three months ended September 30, 2015 to $1.3 million in the three months ended September 30, 2016, and decreased 50.7% from $8.4 million in the nine months ended September 30, 2015 to $4.2 million in the nine months ended September 30, 2016. The decrease in realized investment gains for the three and nine months ended September 30, 2016 is primarily attributable to decreased gains from the sale of equity securities. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-16-028206:mdna:72]
[same as prior period, unchanged from 0001564590-16-022906:mdna:70]

[0001564590-16-028206:mdna:73]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, and scrap raw material sales, changed from $0.1 million of income in the three months ended September 30, 2015 to $0.2 million of expense in the three months ended September 30, 2016, and changed from $0.8 million of expense in the nine months ended September 30, 2015 to $0.4 million of expense in the nine months ended September 30, 2016. The changes for the three and nine months ended September 30, 2016 is primarily attributable to foreign currency transactions.

[0001564590-16-028206:mdna:74]
[same as prior period, unchanged from 0001564590-16-022906:mdna:72]

[0001564590-16-028206:mdna:75]
Our effective tax rate decreased from 36.9% in the nine months ended September 30, 2015 to 34.0%, excluding the tax impact of the bargain purchase gain, in the nine months ended September 30, 2016. The decrease in the effective tax rate between the two periods is primarily attributable to the research and development tax credit being made permanent.

[0001564590-16-028206:mdna:76]
[same as prior period, unchanged from 0001564590-16-022906:mdna:74]

[0001564590-16-028206:mdna:77]
As a result of the above factors, net income increased $5.3 million from $7.1 million in the three months ended September 30, 2015 to $12.4 million in the three months ended September 30, 2016, and increased $14.7 million from $12.9 million in the nine months ended September 30, 2015 to $27.7 million in the nine months ended September 30, 2016.

[0001564590-16-028206:mdna:78]
As a percentage of sales, net income increased from 4.5% in the three months ended September 30, 2015 to 7.4% in the three months ended September 30, 2016, and increased from 2.8% in the nine months ended September 30, 2015 to 5.8% in the nine months ended September 30, 2016.

[0001564590-16-028206:mdna:79]
32

[0001564590-16-028206:mdna:80]
[same as prior period, unchanged from 0001564590-16-022906:mdna:77]

[0001564590-16-028206:mdna:81]
[same as prior period, unchanged from 0001564590-16-022906:mdna:78]

[0001564590-16-028206:mdna:82]
[same as prior period, unchanged from 0001564590-16-022906:mdna:79]

[0001564590-16-028206:mdna:83]
At September 30, 2016, cash on hand was $66.3 million and short-term investments were $55.5 million, which resulted in available short-term liquidity of $121.8 million, of which $45.3 million was held by our foreign subsidiaries. At December 31, 2015, cash on hand was $84.6 million and short-term investments were $34.4 million, which resulted in available short-term liquidity of $118.9 million, of which $38.9 million was held by our foreign subsidiaries. The increase in short-term liquidity from December 31, 2015 to September 30, 2016 is primarily attributable to shifts among available investment option tenures to provide funds for our short-term cash needs.

[0001564590-16-028206:mdna:84]
[same as prior period, unchanged from 0001564590-16-022906:mdna:81]

[0001564590-16-028206:mdna:85]
Our working capital, which consists of current assets less current liabilities, increased 4.6% from $238.1 million as of December 31, 2015 to $249.2 million as of September 30, 2016. The increase in our working capital is primarily attributable to an increase in accounts receivable, partially offset by a decrease in other receivables and an increase in accounts payable, accrued expenses, and accrued wages and benefits. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.06 as of December 31, 2015 to 1.93 as of September 30, 2016. The decrease in the quick ratio is primarily attributable to an increase in accounts receivable, partially offset by an increase in accounts payable, accrued expenses, and accrued wages and benefits. The current ratio, defined as current assets divided by current liabilities, decreased from 3.57 as of December 31, 2015 to 3.16 as of September 30, 2016. The decrease in the current ratio is primarily attributable to an increase in accounts payable, accrued expenses, accrued wages and benefits, and a decrease in other receivables, partially offset by an increase in accounts receivable.

[0001564590-16-028206:mdna:86]
Net accounts receivable increased 41.6% from $71.9 million at December 31, 2015 to $101.8 million at September 30, 2016. Our allowance for doubtful accounts was $19 thousand at December 31, 2015 and nil at September 30, 2016. Quarterly accounts receivable days sales outstanding (DSO) increased from 48 days as of December 31, 2015 to 55 days as of September 30, 2016. The change in net accounts receivable is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than U.S. customers. Other receivables decreased from $19.3 million at December 31, 2015 to $12.2 million at September 30, 2016. The decrease in other receivables is primarily attributable to the timing of filing returns and collections of VAT receivables in our international subsidiaries. Other receivables will also fluctuate due to the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001564590-16-028206:mdna:87]
Quarterly inventory turnover increased from 3.3 turns as of December 31, 2015 to 4.1 turns at September 30, 2016. Inventory increased 4.9% from December 31, 2015 to September 30, 2016. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-16-028206:mdna:88]
Accounts payable increased 38.5% from $48.7 million at December 31, 2015 to $67.4 million at September 30, 2016. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-16-028206:mdna:89]
[same as prior period, unchanged from 0001564590-16-022906:mdna:86]

[0001564590-16-028206:mdna:90]
Capital expenditures totaled approximately $12.7 million and $7.8 million for the nine months ended September 30, 2016 and 2015, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-16-028206:mdna:91]
On September 13, 2016, we acquired key fiber access products, technologies and service relationships from subsidiaries of CommScope, Inc. for $0.9 million in cash. This acquisition will enhance our solutions for the cable MSO industry and will provide cable operators with the scalable solutions, services and support they require to compete in the multi-gigabit service delivery market. We recorded a bargain purchase gain of $3.6 million, net of income taxes, subject to customary working capital adjustments between the parties.

[0001564590-16-028206:mdna:92]
Our combined short-term and long-term investments increased $1.5 million from $232.4 million at December 31, 2015 to $233.9 million at September 30, 2016. This increase reflects funds available for investment provided by our operating activities and stock option exercises by our employees, partially offset by our cash needs for capital expenditures, purchases of treasury stock, and shareholder dividends, as well as net realized and unrealized gains and losses and amortization of net premiums on our combined investments.

[0001564590-16-028206:mdna:93]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At September 30, 2016 these investments included corporate bonds of $60.0 million, municipal fixed-rate bonds of $17.6 million, asset-backed bonds of $22.6 million, mortgage/agency-backed bonds of $15.0 million, U.S. government bonds of $28.6 million, foreign government bonds of $6.4 million, and variable rate demand notes of $12.3 million. At December 31, 2015, these investments included corporate bonds of $57.6 million, municipal fixed-rate bonds of $26.4 million, asset-backed bonds of $19.2 million, mortgage/agency-backed bonds of $15.4 million, and U.S. government bonds of $35.4 million. As of September 30, 2016, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, foreign government bonds, and variable rate demand notes were classified as available-for-sale and had a combined duration of 1.0 years with an average Standard & Poor’s credit rating of AA-. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-16-028206:mdna:94]
Our long-term investments decreased 9.9% from $198.0 million at December 31, 2015 to $178.4 million at September 30, 2016. Long-term investments at September 30, 2016 and December 31, 2015 included an investment in a certificate of deposit of $28.9 and $30.0 million, respectively, which serves as collateral for our revenue bond. See “Debt” below for additional information. We have various equity investments included in long-term investments at a cost of $27.0 million and $31.6 million, and with a fair value of $27.4 million and $34.3 million, at September 30, 2016 and December 31, 2015, respectively.

[0001564590-16-028206:mdna:95]
Long-term investments at September 30, 2016 and December 31, 2015 also included $13.8 million and $12.8 million, respectively, related to our deferred compensation plans, and $1.2 million and $1.3 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001564590-16-028206:mdna:96]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and nine months ended September 30, 2016 and 2015, other-than-temporary impairment charges were not significant.

[0001564590-16-028206:mdna:97]
[same as prior period, unchanged from 0001564590-16-022906:mdna:93]

[0001564590-16-028206:mdna:98]
[same as prior period, unchanged from 0001564590-16-022906:mdna:94]

[0001564590-16-028206:mdna:99]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the nine months ended September 30, 2016, we paid dividends totaling $13.2 million.

[0001564590-16-028206:mdna:100]
[same as prior period, unchanged from 0001564590-16-022906:mdna:96]

[0001564590-16-028206:mdna:101]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $28.9 million at September 30, 2016 and December 31, 2015. At September 30, 2016, the estimated fair value of the Bond was approximately $29.3 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $28.9 million at September 30, 2016 and $30.0 million at December 31, 2015, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.0 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at September 30, 2016.

[0001564590-16-028206:mdna:102]
[same as prior period, unchanged from 0001564590-16-022906:mdna:98]

[0001564590-16-028206:mdna:103]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the nine months ended September 30, 2016, we repurchased 1.2 million shares of our common stock at an average price of $18.34 per share. As of September 30, 2016, we have the authority to purchase an additional 4.6 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-16-028206:mdna:104]
[same as prior period, unchanged from 0001564590-16-022906:mdna:100]

[0001564590-16-028206:mdna:105]
We issued 0.1 million shares of treasury stock during the nine months ended September 30, 2016 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $1.1 million from the exercise of these stock options during the nine months ended September 30, 2016.

[0001564590-16-028206:mdna:106]
[same as prior period, unchanged from 0001564590-16-022906:mdna:102]

[0001564590-16-028206:mdna:107]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the nine months ended September 30, 2016, there have been no material changes in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2015 filed on February 24, 2016 with the SEC.

[0001564590-16-028206:mdna:108]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2016, of which $7.7 million has been applied to these commitments.
