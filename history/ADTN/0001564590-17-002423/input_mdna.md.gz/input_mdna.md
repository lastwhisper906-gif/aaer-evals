# ADTN MD&A — 0001564590-17-002423


## mdna

[0001564590-17-002423:mdna:1]
| ITEM 7. | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001564590-17-002423:mdna:2]
Overview

[0001564590-17-002423:mdna:3]
ADTRAN, Inc. (ADTRAN) is a leading global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications across a variety of network infrastructures. These solutions are deployed by many of the United States’ and the world’s largest CSPs, distributed enterprises and small and medium-sized businesses, public and private enterprises, and millions of individual users worldwide.

[0001564590-17-002423:mdna:4]
Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek in most instances to be a high-quality, low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001564590-17-002423:mdna:5]
In addition to reporting our Network Solutions and Services & Support segments, we report revenue across three categories – Access & Aggregation, Customer Devices, and Traditional & Other Products.

[0001564590-17-002423:mdna:6]
Access & Aggregation solutions are used by CSPs to connect their network infrastructure to their subscribers. This category includes software and hardware-based products and services that aggregate and/or originate access technologies. The portfolio of ADTRAN solutions within this category includes a wide array of modular or fixed physical form factors designed to deliver the best technology and economic fit based on the target subscriber density and environmental conditions.

[0001564590-17-002423:mdna:7]
The Access & Aggregation category includes product and service families such as:

[0001564590-17-002423:mdna:8]
|  | • | Total Access 5000 Series Fiber to the Premises (FTTP) and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001564590-17-002423:mdna:9]
|  | • | hiX 5600 Series fiber aggregation and FTTN MSAN |

[0001564590-17-002423:mdna:10]
|  | • | Fiber to the Distribution Point (FTTdp) Optical Network Units (ONU) |

[0001564590-17-002423:mdna:11]
|  | • | GPON, EPON and 10G PON Optical Line Terminals (OLT) |

[0001564590-17-002423:mdna:12]
|  | • | Optical Networking Edge (ONE) aggregation |

[0001564590-17-002423:mdna:13]
|  | • | IP Digital Subscriber Line Access Multiplexers (DSLAMs) |

[0001564590-17-002423:mdna:14]
|  | • | Cabinet and Outside-Plant (OSP) enclosures and services |

[0001564590-17-002423:mdna:15]
|  | • | Network Management and Cloud-based software platforms and applications |

[0001564590-17-002423:mdna:16]
|  | • | Pluggable optical transceivers (i.e., SFP, SFP+, XFP, QSFP), cables and other miscellaneous materials |

[0001564590-17-002423:mdna:17]
|  | • | Planning, engineering, program management, maintenance, installation and commissioning services to implement customer network solutions |

[0001564590-17-002423:mdna:18]
|  | • | Other products and services that are generally applicable to Access & Aggregation |

[0001564590-17-002423:mdna:19]
Customer Devices includes our products and services that provide end users access to CSP networks. Our Customer Devices portfolio includes a comprehensive array of service provider and enterprise hardware and software products and services.

[0001564590-17-002423:mdna:20]
The Customer Devices category includes products and services such as:

[0001564590-17-002423:mdna:21]
|  | • | Broadband customer premise solutions, including Passive Optical Network (PON) and point-to-point Ethernet Optical Network Terminals (ONTs) |

[0001564590-17-002423:mdna:22]
|  | • | Radio Frequency over Glass (RFoG) MicroNodes |

[0001564590-17-002423:mdna:23]
|  | • | Residential and business gateways |

[0001564590-17-002423:mdna:24]
|  | • | Wi-Fi access points and associated powering and switching infrastructure |

[0001564590-17-002423:mdna:25]
|  | • | Enterprise Session Border Controllers (eSBC) |

[0001564590-17-002423:mdna:26]
|  | • | Branch office and access routers |

[0001564590-17-002423:mdna:27]
|  | • | Carrier Ethernet services termination devices |

[0001564590-17-002423:mdna:28]
|  | • | VoIP media gateways |

[0001564590-17-002423:mdna:29]
|  | • | ProServices pre-sale and post-sale technical support |

[0001564590-17-002423:mdna:30]
|  | • | Planning, engineering, program management, maintenance, installation and commissioning services to implement the customer devices solutions into consumer, small business and enterprise locations |

[0001564590-17-002423:mdna:31]
|  | • | Other products and services that are generally applicable to customer devices |

[0001564590-17-002423:mdna:32]
Traditional & Other Products generally includes a mix of prior generation technologies’ products and services, as well as other products and services that do not fit within the Access & Aggregation or Customer Devices categories.

[0001564590-17-002423:mdna:33]
The Traditional & Other Products category includes products and services such as:

[0001564590-17-002423:mdna:34]
|  | • | Time Division Multiplexed (TDM) and Asynchronous Transfer Mode (ATM) based aggregation systems and customer devices |

[0001564590-17-002423:mdna:35]
|  | • | HDSL, ADSL and other mature technologies used to deliver business and residential services over the CSP access and customer networks |

[0001564590-17-002423:mdna:36]
|  | • | Other products and services that do not fit within the Access & Aggregation and Customer Devices categories |

[0001564590-17-002423:mdna:37]
Sales were $636.8 million in 2016, compared to $600.1 million in 2015 and $630.0 million in 2014. Our gross profit margin was 45.8% in 2016, compared to 44.5% in 2015 and 49.4% in 2014. Net income was $35.2 million in 2016, compared to $18.6 million in 2015 and $44.6 million in 2014. Earnings per share, assuming dilution, were $0.72 in 2016, compared to $0.36 in 2015 and $0.80 in 2014. Earnings per share in 2016, 2015 and 2014 include the effect of the repurchase of 1.4 million, 4.0 million and 3.7 million shares of our stock in those years, respectively.

[0001564590-17-002423:mdna:38]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future periods due to a number of factors, including customer order activity and backlog. Backlog levels vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001564590-17-002423:mdna:39]
28

[0001564590-17-002423:mdna:40]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter.

[0001564590-17-002423:mdna:41]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. See Note 15 of Notes to Consolidated Financial Statements for additional information. For a discussion of risks associated with our operating results, see Item 1A of this report.

[0001564590-17-002423:mdna:42]
Critical Accounting Policies and Estimates

[0001564590-17-002423:mdna:43]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. These policies have been consistently applied across our two reportable segments: (1) Network Solutions and (2) Services & Support.

[0001564590-17-002423:mdna:44]
|  | • | Revenue is generally recognized when persuasive evidence of an arrangement exists, delivery has occurred, the product price is fixed or determinable, collection of the resulting receivable is reasonably assured, and product returns are reasonably estimable. For product sales, revenue is generally recognized upon shipment of the product to our customer in accordance with the title transfer terms of the sales agreement, generally Ex Works, per International Commercial Terms. In the case of consigned inventory, revenue is recognized when the end customer assumes ownership of the product. Contracts that contain multiple deliverables are evaluated to determine the units of accounting, and the consideration from the arrangement is allocated to each unit of accounting based on the relative selling price and corresponding terms of the contract. We use vendor-specific objective evidence of selling price. When this evidence is not available, we are generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. In these instances, we use best estimates to allocate consideration to each respective unit of accounting. These estimates include analysis of respective bills of material and review and analysis of similar product and service offerings. We record revenue associated with installation services when respective contractual obligations are complete. In instances where customer acceptance is required, revenue is deferred until respective acceptance criteria have been met. Contracts that include both installation services and product sales are evaluated for revenue recognition in accordance with contract terms. As a result, installation services may be considered a separate deliverable or may be considered a combined single unit of accounting with the delivered product. Generally, either the purchaser, ADTRAN, or a third party can perform the installation of our products. Sales taxes invoiced to customers are included in revenue, and represent less than one percent of total revenues. The corresponding sales taxes paid are included in cost of goods sold. Value added taxes collected from customers in international jurisdictions are recorded in accrued expenses as a liability. Revenue is recorded net of discounts. Sales returns are recorded as a reduction of revenue and accrued based on historical sales return experience, which we believe provides a reasonable estimate of future returns. |

[0001564590-17-002423:mdna:45]
A significant portion of our products are sold in the United States through a non-exclusive distribution network of major technology distributors. These organizations then distribute or provide fulfillment services to an extensive network of VARs and SIs. VARs and SIs may be affiliated with us as a channel partner, or they may purchase from the distributor on an unaffiliated basis. Additionally, with certain limitations, our distributors may return unused and unopened product for stock-balancing purposes when these returns are accompanied by offsetting orders for products of equal or greater value.

[0001564590-17-002423:mdna:46]
|  | • | We carry our inventory at the lower of cost or market, with cost being determined using the first-in, first-out method. We use standard costs for material, labor, and manufacturing overhead to value our inventory. Our standard costs are updated on at least a quarterly basis and any variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We write down our inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated fair value based upon assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $25.2 million and $26.7 million at December 31, 2016 and 2015, respectively. Inventory disposals charged against the reserve were $4.7 million, $0.2 million and $2.1 million for the years ended December 31, 2016, 2015 and 2014, respectively. |

[0001564590-17-002423:mdna:47]
|  | • | For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable, single measure of the fair value of our stock option awards. For purposes of determining the estimated fair value of our performance-based performance stock unit (PSU) awards on the date of grant, we use a Monte Carlo Simulation valuation method. The PSUs are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of restricted stock and restricted stock units (RSUs) is equal to the closing price of our stock on the business day immediately preceding the grant date. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. |

[0001564590-17-002423:mdna:48]
|  | • | We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets, and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. At December 31, 2016 and 2015 respectively, the valuation allowance was $6.1 million and $7.3 million. As of December 31, 2016, we have state research tax credit carry-forwards of $3.9 million, which will expire between 2017 and 2030. These carry-forwards were caused by tax credits in excess of our annual tax liabilities to an individual state where we no longer generate sufficient state income. In addition, as of December 31, 2016, we have a deferred tax asset of $7.3 million relating to net operating loss carry-forwards which will expire between 2017 and 2030. These carry-forwards are the result of acquisitions in 2009 and in 2011. The acquired net operating losses are in excess of the amount of estimated earnings. We believe it is more likely than not that we will not realize the full benefits of our deferred tax asset arising from these credits and net operating losses, and accordingly, have provided a valuation allowance against that piece. |

[0001564590-17-002423:mdna:49]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain.  We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001564590-17-002423:mdna:50]
|  | • | Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.5 million and $8.7 million at December 31, 2016 and 2015, respectively. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets. |

[0001564590-17-002423:mdna:51]
30

[0001564590-17-002423:mdna:52]
|  | • | Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates, and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $10.0 million and $7.6 million at December 31, 2016 and 2015, respectively. This liability is included in other non-current liabilities in the accompanying Consolidated Balance Sheets. |

[0001564590-17-002423:mdna:53]
|  | • | We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying value. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2016, we concluded that it was not necessary to perform the two-step impairment test. There have been no impairment losses recognized since the acquisition in 2011. |

[0001564590-17-002423:mdna:54]
Results of Operations

[0001564590-17-002423:mdna:55]
The following table presents selected financial information derived from our consolidated statements of income expressed as a percentage of sales for the years indicated.

[0001564590-17-002423:mdna:56]
| Year Ended December 31, |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 82.5 | % |  |  | 87.9 | % |  |  | 88.8 | % |
| Services |  |  | 17.5 |  |  |  | 12.1 |  |  |  | 11.2 |  |
| Total sales |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 42.5 |  |  |  | 49.0 |  |  |  | 45.7 |  |
| Services |  |  | 11.7 |  |  |  | 6.6 |  |  |  | 4.9 |  |
| Gross profit |  |  | 45.8 |  |  |  | 44.5 |  |  |  | 49.4 |  |
| Selling, general and administrative expenses |  |  | 20.7 |  |  |  | 20.6 |  |  |  | 20.9 |  |
| Research and development expenses |  |  | 19.6 |  |  |  | 21.6 |  |  |  | 21.0 |  |
| Operating income |  |  | 5.5 |  |  |  | 2.2 |  |  |  | 7.5 |  |
| Interest and dividend income |  |  | 0.6 |  |  |  | 0.7 |  |  |  | 0.8 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Net realized investment gain |  |  | 0.9 |  |  |  | 1.7 |  |  |  | 1.2 |  |
| Other income (expense), net |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | 0.2 |  |
| Gain on bargain purchase of a business |  |  | 0.6 |  |  |  | — |  |  |  | — |  |
| Income before provision for income taxes |  |  | 7.4 |  |  |  | 4.3 |  |  |  | 9.5 |  |
| Provision for income taxes |  |  | (1.8 | ) |  |  | (1.2 | ) |  |  | (2.4 | ) |
| Net income |  |  | 5.5 | % |  |  | 3.1 | % |  |  | 7.1 | % |

[0001564590-17-002423:mdna:57]
31

[0001564590-17-002423:mdna:58]
2016 Compared to 2015

[0001564590-17-002423:mdna:59]
Sales

[0001564590-17-002423:mdna:60]
Our sales increased 6.1% from $600.1 million in 2015 to $636.8 million in 2016. The increase in sales is primarily attributable to a $38.6 million increase in Services & Support sales, partially offset by a $1.9 million decrease in Network Solutions sales.

[0001564590-17-002423:mdna:61]
Network Solutions sales decreased 0.4% from $527.4 million in 2015 to $525.5 million in 2016. The decrease in sales in 2016 is primarily attributable to a decrease in sales of our Access & Aggregation products and Traditional & Other products, partially offset by an increase in sales of our Customer Devices products. The decrease in sales of our Access & Aggregation products is primarily attributable to a decrease in international hiX product sales, partially offset by an increase in OSP DSLAM sales. The increase in sales of our Customer Devices products is primarily attributable to increased sales of our FTTP ONT products. While we expect that revenues from Traditional & Other products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-17-002423:mdna:62]
Services & Support sales increased 53.2% from $72.6 million in 2015 to $111.3 million in 2016. The increase in sales in 2016 is primarily attributable to an increase in network installation services for Access & Aggregation products.

[0001564590-17-002423:mdna:63]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, decreased 25.0% from $180.7 million in 2015 to $135.4 million in 2016. International sales, as a percentage of total sales, decreased from 30.1% in 2015 to 21.3% in 2016. Our international revenues are affected to a great extent by the timing of network upgrade projects at our larger European and Latin American customers and by changes in foreign exchange rates in territories in which we sell our products and services. Throughout 2016, our largest European customer focused on completing network upgrade activities in regions outside of our footprint with them. However, we expect that once current projects are completed, future network upgrades will resume in the second half of 2017 within our geographic footprint with this customer. Additionally, after reaching a cyclical high in the second quarter of 2014, the value of the Euro currency relative to the U.S. dollar declined significantly throughout the second half of 2014 and in 2015. Though the Euro-USD exchange rate appears to have stabilized since reaching a low in the fourth quarter of 2015, it remains approximately 20% below the highs of 2014. This decline in the value of the Euro throughout 2015 and into 2016 significantly reduced the U.S. dollar value of revenue from our European sales.

[0001564590-17-002423:mdna:64]
Cost of Sales

[0001564590-17-002423:mdna:65]
As a percentage of sales, cost of sales decreased from 55.5% in 2015 to 54.2% in 2016. The decrease is primarily attributable to a regional revenue shift and customer and product mix, partially offset by a change in services mix, restructuring expenses and an increase in warranty expense related to a product recall caused by a defect in a part provided by a third party supplier.

[0001564590-17-002423:mdna:66]
Network Solutions cost of sales, as a percent of that segment’s sales, decreased from 55.7% of sales in 2015 to 51.5% of sales in 2016. The decrease in Network Solutions cost of sales as a percentage of that segment’s sales is primarily attributable to a regional revenue shift and customer and product mix, partially offset by restructuring expenses and an increase in warranty expense related to a product recall caused by a defect in a part provided by a third party supplier.

[0001564590-17-002423:mdna:67]
Services & Support cost of sales, as a percent of that segment’s sales, increased from 54.1% of sales in 2015 to 67.2% of sales in 2016. The increase in Services & Support cost of sales as a percentage of that segment’s sales is primarily attributable to an increase in network installation services, which have higher costs than maintenance and support services, and in restructuring expenses.

[0001564590-17-002423:mdna:68]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-17-002423:mdna:69]
Selling, General and Administrative Expenses

[0001564590-17-002423:mdna:70]
Selling, general and administrative expenses increased 6.7% from $123.5 million in 2015 to $131.8 million in 2016. Selling, general and administrative expenses include personnel costs for administration, finance, information systems, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material, trade show expenses, and related travel costs. The increase in selling, general and administrative expenses is primarily attributable to an increase in variable incentive compensation expense and use tax expense, partially offset by a decrease in professional services.

[0001564590-17-002423:mdna:71]
Selling, general and administrative expenses as a percentage of sales increased from 20.6% for the year ended December 31, 2015 to 20.7% for the year ended December 31, 2016. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-17-002423:mdna:72]
Research and Development Expenses

[0001564590-17-002423:mdna:73]
Research and development expenses decreased 3.9% from $129.9 million in 2015 to $124.8 million in 2016. The decrease in research and development expenses is primarily attributable to a decrease in compensation expense, lease expense and testing expense, partially offset by an increase in contract services. The decrease in compensation expense and lease expense in 2016 was primarily attributable to the consolidation of engineering resources that occurred during the second quarter of 2015.

[0001564590-17-002423:mdna:74]
Research and development expenses as a percentage of sales decreased from 21.6% for the year ended December 31, 2015 to 19.6% for the year ended December 31, 2016. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001564590-17-002423:mdna:75]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provide for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001564590-17-002423:mdna:76]
Interest and Dividend Income

[0001564590-17-002423:mdna:77]
Interest and dividend income remained constant at $3.95 million in 2015 and $3.92 million in 2016.

[0001564590-17-002423:mdna:78]
Interest Expense

[0001564590-17-002423:mdna:79]
Interest expense, which is primarily related to our taxable revenue bond, remained consistent at $0.6 million in 2015 and 2016, as we had no substantial change in our fixed-rate borrowing. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001564590-17-002423:mdna:80]
Net Realized Investment Gain

[0001564590-17-002423:mdna:81]
Net realized investment gain decreased from $10.3 million in 2015 to $5.9 million in 2016. The decrease in realized investment gains is primarily attributable to fewer gains from the sale of equity securities in 2016. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-17-002423:mdna:82]
Other Income (Expense), net

[0001564590-17-002423:mdna:83]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses resulting from foreign currency exchange rate movements, and investment account management fees, decreased from $1.5 million of expense in 2015 to $0.7 million of expense in 2016. The change is primarily attributable to gains on forward currency contracts during the fourth quarter of 2016.

[0001564590-17-002423:mdna:84]
Gain on Bargain Purchase of a Business

[0001564590-17-002423:mdna:85]
Gain on bargain purchase of a business is related to our acquisition of key fiber access products, technologies and service relationships from a third party on September 13, 2016. See note 2 of Notes to Consolidated Financial Statements for additional information.

[0001564590-17-002423:mdna:86]
Income Taxes

[0001564590-17-002423:mdna:87]
Our effective tax rate decreased from 27.5% in 2015 to 24.9% in 2016. The decrease in the effective tax rate between the two periods is primarily attributable to the benefit associated with the bargain purchase gain.

[0001564590-17-002423:mdna:88]
Net Income

[0001564590-17-002423:mdna:89]
As a result of the above factors, net income increased from $18.6 million in 2015 to $35.2 million in 2016. As a percentage of sales, net income increased from 3.1% in 2015 to 5.5% in 2016.

[0001564590-17-002423:mdna:90]
2015 Compared to 2014

[0001564590-17-002423:mdna:91]
Sales

[0001564590-17-002423:mdna:92]
Our sales decreased 4.8% from $630.0 million in 2014 to $600.1 million in 2015. The decrease in sales is primarily attributable to a $32.1 million decrease in Network Solutions sales, partially offset by a $2.2 million increase in Services & Support sales.

[0001564590-17-002423:mdna:93]
Network Solutions sales decreased 5.7% from $559.5 million in 2014 to $527.4 million in 2015. The decrease in sales in 2015 is primarily attributable to a decrease in sales of our Customer Devices products and Traditional & Other products. The decrease in sales of our Customer Devices products is primarily attributable to weakness in sales of IP gateway products to the CLEC and MSO markets. While we expect that revenues from Traditional & Other products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies. Network Solutions sales were also negatively impacted by the impact of the strengthening U.S. dollar against the Euro.

[0001564590-17-002423:mdna:94]
Services & Support sales increased 3.1% from $70.5 million in 2014 to $72.6 million in 2015. The increase in sales in 2015 is primarily attributable to an increase in network installation services for Access & Aggregation products.

[0001564590-17-002423:mdna:95]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, decreased 27.3% from $248.6 million in 2014 to $180.7 million in 2015. International sales, as a percentage of total sales, decreased from 39.5% in 2014 to 30.1% in 2015. Our international revenues are affected to a great extent by the timing of network upgrade projects at our larger European and Latin American customers and by changes in foreign exchange rates in territories in which we sell or products and services. After reaching a cyclical high in the second quarter of 2014, the value of the Euro currency relative to the U.S. dollar declined significantly throughout the second half of 2014 and in 2015. This decline in the value of the Euro throughout 2015 significantly reduced the U.S. dollar value of revenue from our European sales.

[0001564590-17-002423:mdna:96]
Cost of Sales

[0001564590-17-002423:mdna:97]
As a percentage of sales, cost of sales increased from 50.6% in 2014 to 55.5% in 2015. The increase is primarily attributable to the strengthening of the U.S. dollar against the Euro, growth in our service-related material sales in the U.S. market, and customer and product mix.

[0001564590-17-002423:mdna:98]
Network Solutions cost of sales, as a percent of that segment’s sales, increased from 51.5% of sales in 2014 to 55.7% of sales in 2015. The increase in Network Solutions cost of sales as a percentage of that segment’s sales is primarily attributable to the strengthening of the U.S. dollar against the Euro, and customer and product mix.

[0001564590-17-002423:mdna:99]
Services & Support cost of sales, as a percent of that segment’s sales, increased from 43.5% of sales in 2014 to 54.1% of sales in 2015. The increase in Services & Support cost of sales as a percentage of that segment’s sales is primarily attributable to an increase in network installation services, which have higher costs, versus a greater mix of maintenance and support services in the prior period.

[0001564590-17-002423:mdna:100]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-17-002423:mdna:101]
Selling, General and Administrative Expenses

[0001564590-17-002423:mdna:102]
Selling, general and administrative expenses decreased 6.4% from $132.0 million in 2014 to $123.5 million in 2015. Selling, general and administrative expenses include personnel costs for administration, finance, information systems, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material, trade show expenses, and related travel costs. The decrease in selling, general and administrative expenses is primarily attributable to decreases in compensation expense, travel expense, and independent contractor expense, partially offset by an increase in professional services and restructuring charges.

[0001564590-17-002423:mdna:103]
Selling, general and administrative expenses as a percentage of sales decreased from 20.9% for the year ended December 31, 2014 to 20.6% for the year ended December 31, 2015. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-17-002423:mdna:104]
Research and Development Expenses

[0001564590-17-002423:mdna:105]
Research and development expenses decreased 1.8% from $132.3 million in 2014 to $129.9 million in 2015. The decrease in research and development expenses is primarily attributable to decreases in compensation expense and independent contractors, partially offset by an increase in engineering and testing expense and restructuring charges.

[0001564590-17-002423:mdna:106]
Research and development expenses as a percentage of sales increased from 21.0% for the year ended December 31, 2014 to 21.6% for the year ended December 31, 2015. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001564590-17-002423:mdna:107]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provide for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001564590-17-002423:mdna:108]
Interest and Dividend Income

[0001564590-17-002423:mdna:109]
Interest and dividend income decreased from $5.0 million in 2014 to $4.0 million in 2015. The decrease in interest and dividend income is primarily attributable to a reduction in the average rate of return on our investments, as well as a decrease in our average investment balances.

[0001564590-17-002423:mdna:110]
Interest Expense

[0001564590-17-002423:mdna:111]
Interest expense, which is primarily related to our taxable revenue bond, decreased from $0.7 million in 2014 to $0.6 million in 2015. The decrease is primarily attributable to a reduction in the principal and the impact of an interest rate reduction, which occurred during the first quarter of 2014. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001564590-17-002423:mdna:112]
Net Realized Investment Gain

[0001564590-17-002423:mdna:113]
Net realized investment gain increased from $7.3 million in 2014 to $10.3 million in 2015. The increase in realized investment gains is primarily attributable to larger gains from the sale of equity securities in 2015. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-17-002423:mdna:114]
Other Income (Expense), net

[0001564590-17-002423:mdna:115]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses resulting from foreign currency exchange rate movements, and investment account management fees, changed from $1.2 million of income in 2014 to $1.5 million of expense in 2015. The change is primarily attributable to a $2.4 million gain recorded in the fourth quarter of 2014 related to the settlement of working capital items from an acquisition transaction that closed in 2012.

[0001564590-17-002423:mdna:116]
Income Taxes

[0001564590-17-002423:mdna:117]
Our effective tax rate increased from 25.5% in 2014 to 27.5% in 2015. The increase in the effective tax rate between the two periods is primarily attributable to a foreign tax benefit from the elimination of a valuation allowance in 2014, partially offset by a benefit from the closure of an audit and a higher R&D credit in 2015.

[0001564590-17-002423:mdna:118]
Net Income

[0001564590-17-002423:mdna:119]
As a result of the above factors, net income decreased from $44.6 million in 2014 to $18.6 million in 2015. As a percentage of sales, net income decreased from 7.1% in 2014 to 3.1% in 2015.

[0001564590-17-002423:mdna:120]
Liquidity and Capital Resources

[0001564590-17-002423:mdna:121]
Liquidity

[0001564590-17-002423:mdna:122]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-17-002423:mdna:123]
At December 31, 2016, cash on hand was $79.9 million and short-term investments were $43.2 million, which resulted in available short-term liquidity of $123.1 million, of which $42.1 million was held by our foreign subsidiaries. At December 31, 2015, cash on hand was $84.6 million and short-term investments were $34.4 million, which resulted in available short-term liquidity of $118.9 million, of which $38.9 million was held by our foreign subsidiaries. The increase in short-term liquidity from December 31, 2015 to December 31, 2016 is primarily attributable to shifts among available investment option tenures to provide funds for our short-term cash needs.

[0001564590-17-002423:mdna:124]
Operating Activities

[0001564590-17-002423:mdna:125]
Our working capital, which consists of current assets less current liabilities, increased 3.3% from $219.2 million as of December 31, 2015 to $226.4 million as of December 31, 2016. The increase in our working capital is primarily attributable to an increase in accounts receivable and inventory, partially offset by an increase in accounts payable and accrued wages and benefits. The quick ratio, defined as cash and cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.06 as of December 31, 2015 to 1.70 as of December 31, 2016. The decrease in the quick ratio is primarily attributable to an increase in accounts payable and accrued wages and benefits, partially offset by an increase in accounts receivable. The current ratio, defined as current assets divided by current liabilities, decreased from 3.37 as of December 31, 2015 to 2.79 as of December 31, 2016. The decrease in the current ratio is primarily attributable to an increase in accounts payable and accrued wages and benefits, partially offset by an increase in accounts receivable and inventory. The increase in accrued wages and benefits was primarily attributable to an increase in accrued variable incentive compensation.

[0001564590-17-002423:mdna:126]
Net accounts receivable increased 28.4% from $71.9 million at December 31, 2015 to $92.3 million at December 31, 2016. Our allowance for doubtful accounts was $19 thousand at December 31, 2015 and nil at December 31, 2016. Quarterly accounts receivable DSO increased from 48 days as of December 31, 2015 to 52 days as of December 31, 2016. The change in net accounts receivable and DSO is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than U.S. customers.

[0001564590-17-002423:mdna:127]
Annual inventory turnover decreased from 3.75 turns as of December 31, 2015 to 3.51 turns as of December 31, 2016. Inventory increased 14.8% from $91.5 million at December 31, 2015 to $105.1 million at December 31, 2016. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-17-002423:mdna:128]
Accounts payable increased 58.9% from $48.7 million at December 31, 2015 to $77.3 million at December 31, 2016. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-17-002423:mdna:129]
Investing Activities

[0001564590-17-002423:mdna:130]
Capital expenditures totaled approximately $21.4 million, $11.8 million and $11.3 million for the years ended December 31, 2016, 2015 and 2014, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-17-002423:mdna:131]
Our combined short-term and long-term investments decreased $13.1 million from $232.4 million at December 31, 2015 to $219.3 million at December 31, 2016. This decrease reflects the impact of our cash needs for share repurchases, shareholder dividends, equipment acquisitions, as well as net realized and unrealized losses, and amortization of net premiums on our combined investments, partially offset by additional funds available for investment provided by our operating activities and stock option exercises by our employees.

[0001564590-17-002423:mdna:132]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At December 31, 2016, these investments included corporate bonds of $66.4 million, municipal fixed-rate bonds of $11.8 million, asset-backed bonds of $10.2 million, mortgage/agency-backed bonds of $13.0 million, U.S. government bonds of $29.8 million, foreign government bonds of $3.7 million, and variable rate demand notes of $11.9 million. At December 31, 2015, these investments included corporate bonds of $57.6 million, municipal fixed-rate bonds of $26.4 million, asset-backed bonds of $19.2 million, mortgage/agency-backed bonds of $15.4 million and government bonds of $35.4 million. As of December 31, 2016, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, foreign government bonds, and municipal variable rate demand notes were classified as available-for-sale and had a combined duration of 1.15 years with an average credit rating of A+. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-17-002423:mdna:133]
Our long-term investments decreased 11.1% from $198.0 million at December 31, 2015 to $176.1 million at December 31, 2016. Long-term investments at December 31, 2016 and December 31, 2015 included an investment in a certificate of deposit of $27.8 million and $30.0 million, respectively, which serves as collateral for our revenue bond, as discussed below. We have investments in various marketable equity securities classified as long-term investments at a cost of $30.6 million and $31.6 million, and with a fair value of $29.4 million and $34.3 million, at December 31, 2016 and December 31, 2015, respectively.

[0001564590-17-002423:mdna:134]
Long-term investments at December 31, 2016 and 2015 also included $14.6 million and $12.8 million, respectively, related to our deferred compensation plan, and $0.8 million and $1.3 million, respectively, of other investments, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001564590-17-002423:mdna:135]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the years ended December 31, 2016, 2015, and 2014, we recorded charges of $0.8 million, $0.2 million and $0.1 million, respectively, related to the other-than-temporary impairment of certain publicly traded equity securities,  our deferred compensation plan assets, and our investments in two private equity funds.

[0001564590-17-002423:mdna:136]
Financing Activities

[0001564590-17-002423:mdna:137]
In conjunction with an expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN. The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the “Bank”). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the “Bondholder”), which was acquired by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond (“Amended and Restated Bond”) was issued and the original financing agreement was amended. The Amended and Restated Bond bears interest, payable monthly. The interest rate is 2% per annum. The Amended and Restated Bond matures on January 1, 2020, and is currently outstanding in the aggregate principal amount of $27.8 million. The estimated fair value of the bond using a level 2 valuation technique at December 31, 2016 was approximately $28.1 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. We are required to make payments to the Authority in amounts necessary to pay the interest on the Amended and Restated Bond. Included in long-term investments at December 31, 2016 is $27.8 million which is invested in a restricted certificate of deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness.

[0001564590-17-002423:mdna:138]
In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we are required to remit to the state for those employment positions that qualify under the program. We realized economic incentives related to payroll withholdings totaling $1.3 million for each of the years ended December 31, 2016, 2015 and 2014.

[0001564590-17-002423:mdna:139]
We made principal payments of $1.1 million for the years ended December 31, 2016 and 2015, respectively, and we anticipate making a principal payment in 2017.  At December 31, 2016, $1.0 million of the bond debt was classified as a current liability in accounts payable in the Consolidated Balance Sheets.

[0001564590-17-002423:mdna:140]
Dividends

[0001564590-17-002423:mdna:141]
During 2016, 2015 and 2014, we paid shareholder dividends totaling $17.6 million, $18.4 million and $19.9 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained. The following table shows dividends paid to our shareholders in each quarter of 2016, 2015 and 2014.

[0001564590-17-002423:mdna:142]
| Dividends per Common Share |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001564590-17-002423:mdna:143]
Stock Repurchase Program

[0001564590-17-002423:mdna:144]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. For the years 2016, 2015 and 2014, we repurchased 1.4 million shares, 4.0 million shares and 3.7 million shares, respectively, for a cost of $25.8 million, $66.2 million and $80.6 million, respectively, at an average price of $18.29, $16.68 and $21.96 per share, respectively. We currently have the authority to purchase an additional 4.4 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-17-002423:mdna:145]
Stock Option Exercises

[0001564590-17-002423:mdna:146]
To accommodate employee stock option exercises, we issued 0.3 million shares of treasury stock for $4.7 million during the year ended December 31, 2016, 0.1 million shares of treasury stock for $1.0 million during the year ended December 31, 2015, and 0.1 million shares of treasury stock for $2.8 million during the year ended December 31, 2014.

[0001564590-17-002423:mdna:147]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001564590-17-002423:mdna:148]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0001564590-17-002423:mdna:149]
We have various contractual obligations and commercial commitments. The following table sets forth, in millions, the annual payments we are required to make under contractual cash obligations and other commercial commitments at December 31, 2016.

[0001564590-17-002423:mdna:150]
Contractual Obligations

[0001564590-17-002423:mdna:151]
| (In millions) |  | Total |  |  | 2017 |  |  | 2018 |  |  | 2019 |  |  | 2020 |  |  | After 2020 |  |
| Long-term debt |  | $ | 27.8 |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 26.8 |  |  | $ | — |  |
| Interest on long-term debt |  |  | 1.5 |  |  |  | 0.5 |  |  |  | 0.5 |  |  |  | 0.5 |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 184.5 |  |  |  | 183.4 |  |  |  | 0.8 |  |  |  | 0.3 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations |  |  | 10.5 |  |  |  | 3.8 |  |  |  | 2.0 |  |  |  | 0.8 |  |  |  | 0.7 |  |  |  | 3.2 |  |
| Totals |  | $ | 224.3 |  |  | $ | 188.7 |  |  | $ | 3.3 |  |  | $ | 1.6 |  |  | $ | 27.5 |  |  | $ | 3.2 |  |

[0001564590-17-002423:mdna:152]
We are required to make payments necessary to pay the interest on the Amended and Restated Bond, currently outstanding in the aggregate principal amount of $27.8 million. The bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. Included in long-term investments are $27.8 million of restricted funds, which is a collateral deposit against the principal amount of this bond. We made principal payments of $1.1 million for the years ended December 31, 2016 and 2015.  We anticipate making a principal payment in 2017. At December 31, 2016 and 2015, $1.0 million of the bond debt was classified as a current liability in accounts payable in the Consolidated Balance Sheets. See Note 9 of Notes to Consolidated Financial Statements for additional information.

[0001564590-17-002423:mdna:153]
Purchase obligations primarily relate to open purchase orders to our contract manufacturers, component suppliers, service partners, and other vendors.

[0001564590-17-002423:mdna:154]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of December 31, 2016, of which $7.7 million has been applied to these commitments. The additional $0.2 million commitment has been excluded from the table above due to uncertainty of when it will be applied.

[0001564590-17-002423:mdna:155]
We also have obligations related to uncertain income tax positions that have been excluded from the table above due to the uncertainty of when the related expense will be recognized. See Note 10 of Notes to Consolidated Financial Statements for additional information.

[0001564590-17-002423:mdna:156]
Recently Issued Accounting Pronouncements

[0001564590-17-002423:mdna:157]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018, and we are currently evaluating the transition method that will be elected. We are continuing to evaluate the potential impact of these ASUs, and we believe the most significant potential impact relates to our accounting for software license and installation services revenues. We do not believe there will be a significant impact to product or maintenance revenues.

[0001564590-17-002423:mdna:158]
In July 2015, the FASB issued Accounting Standards Update No.  2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We adopted ASU 2015-05 in the first quarter of 2017, and there was no material impact on our financial position, results of operations and cash flows.

[0001564590-17-002423:mdna:159]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of ASU 2016-02 will have a material impact on our financial position; however, we do not believe adoption will have a material impact on our results of operations. We believe the most significant impact relates to our accounting for operating leases for office space and equipment.

[0001564590-17-002423:mdna:160]
In March 2016, the FASB issued Accounting Standards Update No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09). ASU 2016-09 simplifies several aspects of accounting for share-based compensation arrangements, including income tax effects, the classification of tax-related cash flows on the statement of cash flows, and accounting for forfeitures. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016, including interim periods within those years. We adopted ASU 2016-09 in the first quarter of 2017, and there was no material impact on our financial position, results of operations and cash flows.

[0001564590-17-002423:mdna:161]
In January 2017, the FASB issued Accounting Standards Update No. 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04). ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We do not expect the adoption of ASU 2017-04 will have a material impact on our financial position, results of operations or cash flows.

[0001564590-17-002423:mdna:162]
During 2016, we adopted the following accounting standards, which had no material effect on our financial position, results of operations or cash flows:

[0001564590-17-002423:mdna:163]
In April 2015, the FASB issued Accounting Standards Update No. 2015-05, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on accounting for fees paid by a customer in a cloud computing arrangement. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. ASU 2015-05 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period. The amendments may be applied either prospectively to all arrangements entered into or materially modified after the effective date or retrospectively. We adopted ASU 2015-05 during the first quarter of 2016 and will apply the new standard prospectively. The adoption of ASU 2015-05 did not have a material impact on our financial position, results of operations and cash flows.

[0001564590-17-002423:mdna:164]
In November 2015, the FASB issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17). ASU 2015-17 amends the existing guidance on income taxes to require the classification of all deferred tax assets and liabilities as non-current on the balance sheet. ASU 2015-17 is effective for fiscal years beginning after December 15, 2016, including interim periods within those years. Early adoption is permitted. The guidance may be applied either prospectively, for all deferred tax assets and liabilities, or retrospectively to all periods presented. We elected to early adopt ASU 2015-17 during the fourth quarter of 2016, and we applied the guidance retrospectively to all periods presented. As a result, $17.3 million and $18.9 million were reclassified from current deferred tax assets to non-current deferred tax assets at December 31, 2016 and 2015, respectively.

[0001564590-17-002423:mdna:165]
Subsequent Events

[0001564590-17-002423:mdna:166]
On January 17, 2017, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on February 2, 2017. The quarterly dividend payment was $4.4 million and was paid on February 16, 2017. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-17-002423:mdna:167]
During the first quarter and as of February 24, 2017, we have repurchased 0.2 million shares of our common stock through open market purchases at an average cost of $21.46 per share. We currently have the authority to purchase an additional 4.2 million shares of our common stock under the current plan approved by the Board of Directors.

[0001564590-17-002423:mdna:168]
41
