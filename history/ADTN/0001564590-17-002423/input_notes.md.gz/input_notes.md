# ADTN notes — 0001564590-17-002423


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-17-002423:notes:1]
Note 1 – Nature of Business and Summary of Significant Accounting Policies

[0001564590-17-002423:notes:2]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications across a variety of network infrastructures. These solutions are deployed by many of the United States’ and the world’s largest CSPs, distributed enterprises and small and medium-sized businesses, public and private enterprises, and millions of individual users worldwide.

[0001564590-17-002423:notes:3]
Principles of Consolidation

[0001564590-17-002423:notes:4]
Our consolidated financial statements include ADTRAN and its wholly owned subsidiaries. All inter-company accounts and transactions have been eliminated in consolidation.

[0001564590-17-002423:notes:5]
Use of Estimates

[0001564590-17-002423:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues and network installations, estimated income tax provision and income tax contingencies, the fair value of stock- based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-17-002423:notes:7]
Cash and Cash Equivalents

[0001564590-17-002423:notes:8]
Cash and cash equivalents represent demand deposits, money market funds, and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions, and determined the risk of material financial loss due to the exposure of such credit risk to be minimal. As of December 31, 2016, $77.9 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits.

[0001564590-17-002423:notes:9]
Financial Instruments

[0001564590-17-002423:notes:10]
The carrying amounts reported in the consolidated balance sheets for cash and cash equivalents, accounts receivable, and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments. The carrying amount reported for bonds payable was $27.8 million, compared to an estimated fair value of $28.1 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA.

[0001564590-17-002423:notes:11]
Investments with contractual maturities beyond one year, such as our variable rate demand notes, may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe we have the ability to quickly sell them to the remarketing agent, tender agent, or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. All income generated from these investments was recorded as interest income. We have not been required to record any losses relating to variable rate demand notes.

[0001564590-17-002423:notes:12]
Long-term investments represent a restricted certificate of deposit held at cost, deferred compensation plan assets, corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency backed bonds, U.S. and foreign government bonds, variable rate demand notes, marketable equity securities, and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Unrealized gains and losses, net of tax, are reported as a separate component of stockholders’ equity. Realized gains and losses on sales of securities are computed under the specific identification method and are included in current income. We review our investment portfolio quarterly for investments considered to have sustained an other-than-temporary decline in value. Impairment charges for other-than-temporary declines in value are recorded as realized losses in the accompanying consolidated statements of income. All of our investments at December 31, 2016 and 2015 are classified as available-for-sale securities. See Note 4 of Notes to Consolidated Financial Statements for additional information.

[0001564590-17-002423:notes:13]
Accounts Receivable

[0001564590-17-002423:notes:14]
We record accounts receivable at net realizable value. Prior to establishing payment terms for a new customer, we evaluate the credit risk of the customer. Credit limits and payment terms established for new customers are re-evaluated periodically based on customer collection experience and other financial factors. At December 31, 2016, three customers accounted for 63.3% of our total accounts receivable. At December 31, 2015, three customers accounted for 37.3% of our total accounts receivable.

[0001564590-17-002423:notes:15]
We maintain an allowance for doubtful accounts for losses resulting from the inability of our customers to make required payments. We regularly review the allowance for doubtful accounts and consider factors such as the age of accounts receivable balances, the current economic conditions that may affect a customer’s ability to pay, significant one-time events and our historical experience. If the financial condition of a customer deteriorates, resulting in an impairment of their ability to make payments, we may be required to record an allowance for doubtful accounts. If circumstances change with regard to individual receivable balances that have previously been determined to be uncollectible (and for which a specific reserve has been established), a reduction in our allowance for doubtful accounts may be required. Our allowance for doubtful accounts was nil and $19 thousand at December 31, 2016 and December 31, 2015, respectively.

[0001564590-17-002423:notes:16]
Other Receivables

[0001564590-17-002423:notes:17]
Other receivables are comprised primarily of amounts due from subcontract manufacturers for product component transfers, accrued interest on investments and on a restricted certificate of deposit, amounts due from various jurisdictions for value-added tax, and amounts due from employee stock option exercises.

[0001564590-17-002423:notes:18]
Inventory

[0001564590-17-002423:notes:19]
Inventory is carried at the lower of cost or market, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory. Standard costs are updated at least quarterly; therefore, inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess, obsolete or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand, market conditions and age. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 6 of Notes to Consolidated Financial Statements for additional information.

[0001564590-17-002423:notes:20]
Property, Plant and Equipment

[0001564590-17-002423:notes:21]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. We depreciate building and land improvements from five to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years, and computer software from three to five years. Expenditures for repairs and maintenance are charged to expense as incurred. Betterments that materially prolong the lives of the assets are capitalized. Gains and losses on the disposal of property, plant and equipment are recorded in operating income. See Note 7 of Notes to Consolidated Financial Statements for additional information.

[0001564590-17-002423:notes:22]
Liability for Warranty

[0001564590-17-002423:notes:23]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. During 2016, we incurred an increase in warranty expense related to a product recall caused by a defect in a part provided by a third party supplier. The liability for warranty obligations totaled $8.5 million and $8.7 million at December 31, 2016 and 2015, respectively. These liabilities are included in accrued expenses in the accompanying consolidated balance sheets.

[0001564590-17-002423:notes:24]
A summary of warranty expense and write-off activity for the years ended December 31, 2016, 2015 and 2014 is as follows:

[0001564590-17-002423:notes:25]
| Year Ended December 31, |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| (In thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 8,739 |  |  | $ | 8,415 |  |  | $ | 8,977 |  |
| Plus: Amounts charged to cost and expenses |  |  | 8,561 |  |  |  | 2,998 |  |  |  | 3,103 |  |
| Less: Deductions |  |  | (8,752 | ) |  |  | (2,674 | ) |  |  | (3,665 | ) |
| Balance at end of period |  | $ | 8,548 |  |  | $ | 8,739 |  |  | $ | 8,415 |  |

[0001564590-17-002423:notes:26]
Pension Benefit Plan Obligations

[0001564590-17-002423:notes:27]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations.

[0001564590-17-002423:notes:28]
Stock-Based Compensation

[0001564590-17-002423:notes:29]
We have two Board and stockholder approved stock incentive plans from which stock options and other awards are available for grant to employees and directors. All employee and director stock options granted under our stock option plans have an exercise price equal to the fair market value of the award, as defined in the plan, of the underlying common stock on the grant date. There are currently no vesting provisions tied to performance or market conditions for any stock awards. Vesting for all outstanding award grants is based only on continued service as an employee or director of ADTRAN. All of our outstanding stock option awards are classified as equity awards.

[0001564590-17-002423:notes:30]
Under the provisions of our approved plans, we made grants of performance stock units to certain of our executive officers in 2016, 2015, and 2014. The performance stock units are subject to a market condition based on the relative total shareholder return of ADTRAN against all the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The performance stock units are converted into shares of common stock upon vesting. Depending on the relative total shareholder return over the performance period, the executive officers may earn from 0% to 150% of the number of restricted stock units granted. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. The recipients of the performance stock units also earn dividend credits during the performance period, which are paid in cash upon the issuance of common stock for the restricted stock units.

[0001564590-17-002423:notes:31]
Stock-based compensation expense recognized in 2016, 2015 and 2014 was approximately $6.7 million, $6.7 million and $8.6 million, respectively. As of December 31, 2016, total compensation cost related to non-vested stock options, restricted stock units, performance stock units and restricted stock not yet recognized was approximately $16.4 million, which is expected to be recognized over an average remaining recognition period of 2.9 years. See Note 3 of Notes to Consolidated Financial Statements for additional information.

[0001564590-17-002423:notes:32]
Impairment of Long-Lived Assets

[0001564590-17-002423:notes:33]
We review long-lived assets used in operations for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. An impairment loss would be recognized in the amount by which the recorded value of the asset exceeds the fair value of the asset, measured by the quoted market price of an asset or an estimate based on the best information available in the circumstances. There were no impairment losses recognized during 2016, 2015 or 2014.

[0001564590-17-002423:notes:34]
Goodwill and Purchased Intangible Assets

[0001564590-17-002423:notes:35]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2016, we concluded that it was not necessary to perform the two-step impairment test. There have been no impairment losses recognized since the acquisition in 2011. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets, which is 9 months to 14 years.

[0001564590-17-002423:notes:36]
Research and Development Costs

[0001564590-17-002423:notes:37]
Research and development costs include compensation for engineers and support personnel, outside contracted services, depreciation and material costs associated with new product development, the enhancement of current products, and product cost reductions. We continually evaluate new product opportunities and engage in intensive research and product development efforts. Research and development costs totaled $124.8 million, $129.9 million and $132.3 million for the years ended December 31, 2016, 2015 and 2014, respectively.

[0001564590-17-002423:notes:38]
Other Comprehensive Income

[0001564590-17-002423:notes:39]
Other comprehensive income consists of unrealized gains (losses) on available-for-sale securities, reclassification adjustments for amounts included in net income related to impairments of available-for-sale securities and realized gains (losses) on available-for-sale securities, defined benefit plan adjustments and foreign currency translation adjustments.

[0001564590-17-002423:notes:40]
The following table presents changes in accumulated other comprehensive income, net of tax, by component for the years ended December 31, 2014, 2015 and 2016:

[0001564590-17-002423:notes:41]
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Balance at December 31, 2013 |  | $ | 10,737 |  |  | $ | (891 | ) |  | $ | 907 |  |  | $ | 10,753 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 2,363 |  |  |  | (4,866 | ) |  |  | (4,189 | ) |  |  | (6,692 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (4,136 | ) |  |  | — |  |  |  | — |  |  |  | (4,136 | ) |
| Balance at December 31, 2014 |  |  | 8,964 |  |  |  | (5,757 | ) |  |  | (3,282 | ) |  |  | (75 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (844 | ) |  |  | 1,589 |  |  |  | (3,724 | ) |  |  | (2,979 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (6,188 | ) |  |  | 273 |  |  |  | — |  |  |  | (5,915 | ) |
| Balance at December 31, 2015 |  |  | 1,932 |  |  |  | (3,895 | ) |  |  | (7,006 | ) |  |  | (8,969 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,515 |  |  |  | (1,229 | ) |  |  | (569 | ) |  |  | (283 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (3,043 | ) |  |  | 107 |  |  |  | — |  |  |  | (2,936 | ) |
| Balance at December 31, 2016 |  | $ | 404 |  |  | $ | (5,017 | ) |  | $ | (7,575 | ) |  | $ | (12,188 | ) |

[0001564590-17-002423:notes:42]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the years ended December 31, 2016, 2015 and 2014:

[0001564590-17-002423:notes:43]
| (In thousands) |  | 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 5,408 |  |  | Net realized investment gain |
| Impairment expense |  |  | (419 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (156 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 4,833 |  |  |  |
| Tax (expense) benefit |  |  | (1,897 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,936 |  |  |  |

[0001564590-17-002423:notes:44]
| (1) | Included in the computation of net periodic pension cost. See Note 11 of Notes to Consolidated Financial Statements. |

[0001564590-17-002423:notes:45]
| (In thousands) |  | 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 10,348 |  |  | Net realized investment gain |
| Impairment expense |  |  | (203 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (396 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 9,749 |  |  |  |
| Tax (expense) benefit |  |  | (3,834 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 5,915 |  |  |  |

[0001564590-17-002423:notes:46]
| (In thousands) |  | 2014 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 6,895 |  |  | Net realized investment gain |
| Impairment expense |  |  | (115 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 6,780 |  |  |  |
| Tax (expense) benefit |  |  | (2,644 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 4,136 |  |  |  |

[0001564590-17-002423:notes:47]
The following tables present the tax effects related to the change in each component of other comprehensive income for the years ended December 31, 2016, 2015 and 2014:

[0001564590-17-002423:notes:48]
|  |  | 2016 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 2,484 |  |  | $ | (969 | ) |  | $ | 1,515 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (4,989 | ) |  |  | 1,946 |  |  |  | (3,043 | ) |
| Defined benefit plan adjustments |  |  | (1,782 | ) |  |  | 553 |  |  |  | (1,229 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 156 |  |  |  | (49 | ) |  |  | 107 |  |
| Foreign currency translation adjustment |  |  | (569 | ) |  |  | — |  |  |  | (569 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (4,700 | ) |  | $ | 1,481 |  |  | $ | (3,219 | ) |

[0001564590-17-002423:notes:49]
|  |  | 2015 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (1,384 | ) |  | $ | 540 |  |  | $ | (844 | ) |
| Reclassification adjustment for amounts related to available- for-sale investments included in net income |  |  | (10,145 | ) |  |  | 3,957 |  |  |  | (6,188 | ) |
| Defined benefit plan adjustments |  |  | 2,303 |  |  |  | (714 | ) |  |  | 1,589 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 396 |  |  |  | (123 | ) |  |  | 273 |  |
| Foreign currency translation adjustment |  |  | (3,724 | ) |  |  | — |  |  |  | (3,724 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (12,554 | ) |  | $ | 3,660 |  |  | $ | (8,894 | ) |

[0001564590-17-002423:notes:50]
|  |  | 2014 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 3,874 |  |  | $ | (1,511 | ) |  | $ | 2,363 |  |
| Reclassification adjustment for amounts related to available- for-sale investments included in net income |  |  | (6,780 | ) |  |  | 2,644 |  |  |  | (4,136 | ) |
| Defined benefit plan adjustments |  |  | (7,052 | ) |  |  | 2,186 |  |  |  | (4,866 | ) |
| Foreign currency translation adjustment |  |  | (4,189 | ) |  |  | — |  |  |  | (4,189 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (14,147 | ) |  | $ | 3,319 |  |  | $ | (10,828 | ) |

[0001564590-17-002423:notes:51]
Income Taxes

[0001564590-17-002423:notes:52]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax bases of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0001564590-17-002423:notes:53]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain.  We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001564590-17-002423:notes:54]
Foreign Currency

[0001564590-17-002423:notes:55]
We record transactions denominated in foreign currencies on a monthly basis using exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are translated at the balance sheet dates using the closing rates of exchange between those foreign currencies and the functional currency with any transaction gains or losses reported in other income (expense). Our primary exposures to foreign currency exchange rate movements are with our German subsidiary, whose functional currency is the Euro, our Australian subsidiary, whose functional currency is the Australian dollar, and our Mexican subsidiary, whose functional currency is the U.S. dollar. Adjustments resulting from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive income (loss).

[0001564590-17-002423:notes:56]
Revenue Recognition

[0001564590-17-002423:notes:57]
Revenue is generally recognized when persuasive evidence of an arrangement exists, delivery has occurred, the product price is fixed or determinable, collection of the resulting receivable is reasonably assured, and product returns are reasonably estimable. For product sales, revenue is generally recognized upon shipment of the product to our customer in accordance with the title transfer terms of the sales agreement, generally Ex Works, per International Commercial Terms. In the case of consigned inventory, revenue is recognized when the end customer assumes ownership of the product. Contracts that contain multiple deliverables are evaluated to determine the units of accounting, and the consideration from the arrangement is allocated to each unit of accounting based on the relative selling price and corresponding terms of the contract. We use vendor-specific objective evidence of selling price. When this evidence is not available, we are generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. In these instances, we use best estimates to allocate consideration to each respective unit of accounting. These estimates include analysis of respective bills of material and review and analysis of similar product and service offerings. We record revenue associated with installation services when respective contractual obligations are complete. In instances where customer acceptance is required, revenue is deferred until respective acceptance criteria have been met. Contracts that include both installation services and product sales are evaluated for revenue recognition in accordance with contract terms. As a result, installation services may be considered a separate deliverable or may be considered a combined single unit of accounting with the delivered product. Generally, either the purchaser, ADTRAN, or a third party can perform the installation of our products. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales taxes invoiced to customers are included in revenues, and represent less than one percent of total revenues. The corresponding sales taxes paid are included in cost of goods sold. Value added taxes collected from customers in international jurisdictions are recorded in accrued expenses as a liability. Revenue is recorded net of discounts. Sales returns are recorded as a reduction of revenue and accrued based on historical sales return experience, which we believe provides a reasonable estimate of future returns.

[0001564590-17-002423:notes:58]
A portion of our products are sold to a non-exclusive distribution network of major technology distributors in the United States. These large organizations then distribute or provide fulfillment services to an extensive network of VARs and SIs. VARs and SIs may be affiliated with us as a channel partner, or they may purchase from the distributor in an unaffiliated fashion. Additionally, with certain limitations our distributors may return unused and unopened product for stock-balancing purposes when such returns are accompanied by offsetting orders for products of equal or greater value.

[0001564590-17-002423:notes:59]
We participate in cooperative advertising and market development programs with certain customers. We use these programs to reimburse customers for certain forms of advertising, and in general, to allow our customers credits up to a specified percentage of their net purchases. Our costs associated with these programs are estimated and included in marketing expenses in our consolidated statements of income. We also participate in rebate programs to provide sales incentives for certain products. Our costs associated with these programs are estimated and accrued at the time of sale, and are recorded as a reduction of sales in our consolidated statements of income.

[0001564590-17-002423:notes:60]
Unearned Revenue

[0001564590-17-002423:notes:61]
Unearned revenue primarily represents customer billings on our maintenance service programs and unearned revenues relating to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one to five years. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. In addition, we provide software maintenance and a variety of hardware maintenance services to customers under contracts with terms up to ten years. When we defer revenue related to multiple-element contracts where we still have contractual obligations, we also defer the related costs. Deferred costs are included in prepaid expenses and other assets and totaled $10.7 million and $5.2 million at December 31, 2016 and 2015, respectively.

[0001564590-17-002423:notes:62]
Other Income (Expense), Net

[0001564590-17-002423:notes:63]
Other income (expense), net, is comprised primarily of miscellaneous income and expense, gains and losses on foreign currency transactions, and investment account management fees. For the year ended December 31, 2014, other income (expense), net included a $2.4 million gain related to the settlement of working capital items from an acquisition transaction that closed in 2012.

[0001564590-17-002423:notes:64]
Earnings per Share

[0001564590-17-002423:notes:65]
Earnings per common share, and earnings per common share assuming dilution, are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year. See Note 14 of Notes to Consolidated Financial Statements for additional information.

[0001564590-17-002423:notes:66]
Dividends

[0001564590-17-002423:notes:67]
During 2016, 2015 and 2014, we paid shareholder dividends totaling $17.6 million, $18.4 million and $19.9 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained. The following table shows dividends paid to our shareholders in each quarter of 2016, 2015 and 2014.

[0001564590-17-002423:notes:68]
| Dividends per Common Share |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001564590-17-002423:notes:69]
On January 17, 2017, the Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on February 2, 2017. The ex-dividend date was January 31, 2017 and the payment date was February 16, 2017. The quarterly dividend payment was $4.4 million.

[0001564590-17-002423:notes:70]
Business Combinations

[0001564590-17-002423:notes:71]
We use the acquisition method to account for business combinations. Under the acquisition method of accounting, we recognize the assets acquired and liabilities assumed at their fair value on the acquisition date. Goodwill is measured as the excess of the consideration transferred over the net assets acquired. Costs incurred to complete the business combination, such as legal, accounting or other professional fees, are charged to general and administrative expenses as they are incurred.

[0001564590-17-002423:notes:72]
Recently Issued Accounting Standards

[0001564590-17-002423:notes:73]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018, and we are currently evaluating the transition method that will be elected. We are continuing to evaluate the potential impact of these ASUs, and we believe the most significant potential impact relates to our accounting for software license and installation services revenues. We do not believe there will be a significant impact to product or maintenance revenues.

[0001564590-17-002423:notes:74]
In July 2015, the FASB issued Accounting Standards Update No.  2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We adopted ASU 2015-05 in the first quarter of 2017, and there was no material impact on our financial position, results of operations and cash flows.

[0001564590-17-002423:notes:75]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of ASU 2016-02 will have a material impact on our financial position; however, we do not believe adoption will have a material impact on our results of operations. We believe the most significant impact relates to our accounting for operating leases for office space and equipment.

[0001564590-17-002423:notes:76]
In March 2016, the FASB issued Accounting Standards Update No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09). ASU 2016-09 simplifies several aspects of accounting for share-based compensation arrangements, including income tax effects, the classification of tax-related cash flows on the statement of cash flows, and accounting for forfeitures. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016, including interim periods within those years. We adopted ASU 2016-09 in the first quarter of 2017, and there was no material impact on our financial position, results of operations and cash flows.

[0001564590-17-002423:notes:77]
In January 2017, the FASB issued Accounting Standards Update No. 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04). ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We do not expect the adoption of ASU 2017-04 will have a material impact on our financial position, results of operations or cash flows.

[0001564590-17-002423:notes:78]
During 2016, we adopted the following accounting standards, which had no material effect on our financial position, results of operations or cash flows:

[0001564590-17-002423:notes:79]
In April 2015, the FASB issued Accounting Standards Update No. 2015-05, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on accounting for fees paid by a customer in a cloud computing arrangement. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. ASU 2015-05 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period. The amendments may be applied either prospectively to all arrangements entered into or materially modified after the effective date or retrospectively. We adopted ASU 2015-05 during the first quarter of 2016 and will apply the new standard prospectively. The adoption of ASU 2015-05 did not have a material impact on our financial position, results of operations and cash flows.

[0001564590-17-002423:notes:80]
In November 2015, the FASB issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17). ASU 2015-17 amends the existing guidance on income taxes to require the classification of all deferred tax assets and liabilities as non-current on the balance sheet. ASU 2015-17 is effective for fiscal years beginning after December 15, 2016, including interim periods within those years. Early adoption is permitted. The guidance may be applied either prospectively, for all deferred tax assets and liabilities, or retrospectively to all periods presented. We elected to early adopt ASU 2015-17 during the fourth quarter of 2016, and we applied the guidance retrospectively to all periods presented. As a result, $17.3 million and $18.9 million were reclassified from current deferred tax assets to non-current deferred tax assets at December 31, 2016 and 2015, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-002423:notes:81]
Note 2 – Business Combinations

[0001564590-17-002423:notes:82]
On September 13, 2016, we acquired key fiber access products, technologies and service relationships from subsidiaries of CommScope, Inc. for $0.9 million in cash. This acquisition will enhance our solutions for the cable MSO industry and will provide cable operators with the scalable solutions, services and support they require to compete in the multi-gigabit service delivery market. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. These revenues are included in the Network Solutions reportable segment, and in the Access & Aggregation and Customer Devices categories.

[0001564590-17-002423:notes:83]
We recorded a bargain purchase gain of $3.5 million, net of income taxes, subject to customary working capital adjustments between the parties. The bargain purchase gain represents the excess fair value of the net assets acquired over the consideration exchanged. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and pro forma data for future periods and have concluded that our valuation procedures and resulting measures were appropriate. The gain is included in the line item “Gain on bargain purchase of a business” in the 2016 Consolidated Statements of Income.

[0001564590-17-002423:notes:84]
The allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date, subject to working capital adjustments, is as follows:

[0001564590-17-002423:notes:85]
| (In Thousands) |  |  |  |  |
| Assets |  |  |  |  |
| Inventory |  | $ | 3,131 |  |
| Property, plant and equipment |  |  | 352 |  |
| Intangible assets |  |  | 4,700 |  |
| Total assets acquired |  |  | 8,183 |  |
| Liabilities |  |  |  |  |
| Accounts payable |  |  | (1,250 | ) |
| Warranty payable |  |  | (61 | ) |
| Accrued wages and benefits |  |  | (122 | ) |
| Deferred income taxes |  |  | (2,265 | ) |
| Total liabilities assumed |  |  | (3,698 | ) |
| Total net assets |  |  | 4,485 |  |
| Gain on bargain purchase of a business, net of tax |  |  | (3,542 | ) |
| Total purchase price |  | $ | 943 |  |

[0001564590-17-002423:notes:86]
The details of the acquired intangible assets are as follows:

[0001564590-17-002423:notes:87]
| In thousands |  | Value |  |  | Life (years) |  |
| Supply agreement |  | $ | 1,400 |  |  |  | 0.8 |  |
| Customer relationships |  |  | 1,200 |  |  |  | 6.0 |  |
| Developed technology |  |  | 800 |  |  |  | 10.0 |  |
| License |  |  | 500 |  |  |  | 1.3 |  |
| Patent |  |  | 500 |  |  |  | 7.3 |  |
| Non-compete |  |  | 200 |  |  |  | 2.3 |  |
| Trade name |  |  | 100 |  |  |  | 2.0 |  |
| Total |  | $ | 4,700 |  |  |  |  |  |

[0001564590-17-002423:notes:88]
The actual revenue and net loss included in our Consolidated Statements of Income for the period September 13, 2016 to December 31, 2016 are as follows:

[0001564590-17-002423:notes:89]
| (In thousands) |  | September 13 to December 31, 2016 |  |
| Revenue |  | $ | 2,768 |  |
| Net loss |  | $ | (805 | ) |

[0001564590-17-002423:notes:90]
The following supplemental unaudited pro forma information presents the financial results as if the acquisition had occurred on January 1, 2015. This supplemental unaudited pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2015, nor is it indicative of any future results. Aside from revising the 2015 net income for the effect of the bargain purchase gain, there were no material, non-recurring adjustments to this unaudited pro forma information.

[0001564590-17-002423:notes:91]
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Pro forma revenue |  | $ | 641,170 |  |  | $ | 603,923 |  |
| Pro forma net income |  | $ | 31,212 |  |  | $ | 22,945 |  |

[0001564590-17-002423:notes:92]
For the year ended December 31, 2016, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $1.0 million related to this acquisition.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-17-002423:notes:93]
Note 3 – Stock-Based Compensation

[0001564590-17-002423:notes:94]
Stock Incentive Program Descriptions

[0001564590-17-002423:notes:95]
On January 23, 2006, the Board of Directors adopted the ADTRAN, Inc. 2006 Employee Stock Incentive Plan (2006 Plan), which authorized 13.0 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, restricted stock and restricted stock units (RSUs). The 2006 Plan was adopted by stockholder approval at our annual meeting of stockholders held on May 9, 2006. Options granted under the 2006 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date, and have a ten-year contractual term. The 2006 Plan was replaced on May 13, 2015 by the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (2015 Plan). Expiration dates of options outstanding at December 31, 2016 under the 2006 Plan range from 2017 to 2024.

[0001564590-17-002423:notes:96]
Our stockholders approved the 2010 Directors Stock Plan (2010 Directors Plan) on May 5, 2010, under which 0.5 million shares of common stock have been reserved. This plan replaces the 2005 Directors Stock Option Plan. Under the 2010 Directors Plan, the Company may issue stock options, restricted stock and RSUs to our non-employee directors. Stock awards issued under the 2010 Directors Plan normally become vested in full on the first anniversary of the grant date. Options issued under the 2010 Directors Plan have a ten-year contractual term. Expiration dates of options outstanding at December 31, 2016 under the 2010 Directors Plan range from 2017 to 2019.

[0001564590-17-002423:notes:97]
On January 20, 2015, the Board of Directors adopted the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (2015 Plan), which authorizes 7.7 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, performance stock units (PSUs), restricted stock and RSUs. The 2015 Plan was adopted by stockholder approval at our annual meeting of stockholders held on May 13, 2015. PSUs, restricted stock and RSUs granted under the 2015 Plan reduce the shares authorized for issuance under the 2015 Plan by 2.5 shares of common stock for each share underlying the award. Options granted under the 2015 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date, and have a ten-year contractual term. Expiration dates of options outstanding at December 31, 2015 under the 2015 Plan range from 2025 to 2026.

[0001564590-17-002423:notes:98]
The following table summarizes stock-based compensation expense related to stock options, PSUs, restricted stock and RSUs for the years ended December 31, 2016, 2015 and 2014, which was recognized as follows:

[0001564590-17-002423:notes:99]
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 389 |  |  | $ | 280 |  |  | $ | 479 |  |
| Selling, general and administrative expense |  |  | 3,341 |  |  |  | 3,261 |  |  |  | 4,185 |  |
| Research and development expense |  |  | 2,965 |  |  |  | 3,171 |  |  |  | 3,899 |  |
| Stock-based compensation expense included in operating expenses |  |  | 6,306 |  |  |  | 6,432 |  |  |  | 8,084 |  |
| Total stock-based compensation expense |  |  | 6,695 |  |  |  | 6,712 |  |  |  | 8,563 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (963 | ) |  |  | (862 | ) |  |  | (1,157 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 5,732 |  |  | $ | 5,850 |  |  | $ | 7,406 |  |

[0001564590-17-002423:notes:100]
Stock-based compensation expense recognized in our Consolidated Statements of Income for the years ended December 31, 2016, 2015 and 2014 is based on stock options, PSUs, restricted stock and RSUs ultimately expected to vest, and has been reduced for estimated forfeitures. Estimates for forfeiture rates are based upon historical experience and are evaluated quarterly. We expect our forfeiture rate for stock options and RSUs to be approximately 3.7% annually. We estimated a 0% forfeiture rate for our PSUs and restricted stock due to the limited number of recipients and historical experience for these awards.

[0001564590-17-002423:notes:101]
Stock Options

[0001564590-17-002423:notes:102]
The following table is a summary of our stock options outstanding as of December 31, 2015 and 2016 and the changes that occurred during 2016:

[0001564590-17-002423:notes:103]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Average Exercise Price |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2015 |  |  | 7,108 |  |  | $ | 21.97 |  |  |  | 6.42 |  |  | $ | 3,284 |  |
| Options granted |  |  | 19 |  |  | $ | 18.24 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (283 | ) |  | $ | 16.66 |  |  |  |  |  |  |  |  |  |
| Options forfeited |  |  | (93 | ) |  | $ | 17.90 |  |  |  |  |  |  |  |  |  |
| Options expired |  |  | (413 | ) |  | $ | 23.96 |  |  |  |  |  |  |  |  |  |
| Options outstanding, December 31, 2016 |  |  | 6,338 |  |  | $ | 22.14 |  |  |  | 5.63 |  |  | $ | 16,972 |  |
| Options vested and expected to vest, December 31, 2016 |  |  | 6,276 |  |  | $ | 22.20 |  |  |  | 5.60 |  |  | $ | 16,606 |  |
| Options exercisable, December 31, 2016 |  |  | 4,757 |  |  | $ | 23.67 |  |  |  | 4.73 |  |  | $ | 9,137 |  |

[0001564590-17-002423:notes:104]
At December 31, 2016, total compensation cost related to non-vested stock options not yet recognized was approximately $7.5 million, which is expected to be recognized over an average remaining recognition period of 2.1 years.

[0001564590-17-002423:notes:105]
All of the options above were issued at exercise prices that approximated fair market value at the date of grant. At December 31, 2016, 5.6 million options were available for grant under the shareholder approved plans.

[0001564590-17-002423:notes:106]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of 2016 and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2016. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock.

[0001564590-17-002423:notes:107]
The total pre-tax intrinsic value of options exercised during 2016, 2015 and 2014 was $1.1 million, $0.1 million and $0.7 million, respectively. The fair value of options fully vesting during 2016, 2015 and 2014 was $5.7 million, $6.6 million and $7.7 million, respectively.

[0001564590-17-002423:notes:108]
The following table further describes our stock options outstanding as of December 31, 2016:

[0001564590-17-002423:notes:109]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range of Exercise Prices |  | Options Outstanding at 12/31/16 (In thousands) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Weighted Average Exercise Price |  |  | Options Exercisable at 12/31/16 (In thousands) |  |  | Weighted Average Exercise Price |  |
| $14.88 – 18.96 |  |  | 2,101 |  |  |  | 6.78 |  |  | $ | 15.82 |  |  |  | 1,217 |  |  | $ | 16.14 |  |
| $18.97 – 23.45 |  |  | 1,380 |  |  |  | 5.79 |  |  | $ | 20.17 |  |  |  | 881 |  |  | $ | 20.84 |  |
| $23.46 – 30.35 |  |  | 1,491 |  |  |  | 5.08 |  |  | $ | 23.89 |  |  |  | 1,293 |  |  | $ | 23.92 |  |
| $30.36 – 41.92 |  |  | 1,366 |  |  |  | 4.29 |  |  | $ | 31.94 |  |  |  | 1,366 |  |  | $ | 31.94 |  |
|  |  |  | 6,338 |  |  |  |  |  |  |  |  |  |  |  | 4,757 |  |  |  |  |  |

[0001564590-17-002423:notes:110]
PSUs, restricted stock and RSUs

[0001564590-17-002423:notes:111]
Under the 2015 Plan, awards other than stock options, including PSUs, restricted stock and RSUs, may be granted to certain employees and officers. Under our PSU program, the number of shares of common stock earned by a recipient pursuant to the PSUs is subject to a market condition based on ADTRAN’s relative total shareholder return against all companies in the NASDAQ Telecommunications Index at the end of a three-year performance period. Depending on the relative total shareholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the PSUs, with the shares earned distributed upon the vesting of the PSUs at the end of the three-year performance period. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted PSUs also vest and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of ADTRAN, as defined by the 2015 Plan. The recipients of the PSUs receive dividend credits based on the shares of common stock underlying the PSUs. The dividend credits are vested and earned in the same manner as the PSUs and are paid in cash upon the issuance of common stock for the PSUs. The fair value of restricted stock and RSUs is equal to the closing price of our stock on the business day immediately preceding the grant date.  Restricted stock and RSUs vest ratably over one year and four year periods, respectively.

[0001564590-17-002423:notes:112]
The following table is a summary of our PSUs, restricted stock and RSUs outstanding as of December 31, 2015 and 2016 and the changes that occurred during 2016:

[0001564590-17-002423:notes:113]
| (In thousands, except per share amounts) |  | Number of shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested PSUs, restricted stock and RSUs outstanding, December 31, 2015 |  |  | 106 |  |  | $ | 21.09 |  |
| PSUs, restricted stock and RSUs granted |  |  | 460 |  |  | $ | 20.63 |  |
| PSUs, restricted stock and RSUs vested |  |  | (46 | ) |  | $ | 22.50 |  |
| PSUs, restricted stock and RSUs forfeited |  |  | (1 | ) |  | $ | 20.00 |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2016 |  |  | 519 |  |  | $ | 20.51 |  |

[0001564590-17-002423:notes:114]
At December 31, 2016, total compensation cost related to the non-vested portion of PSUs, restricted stock and RSUs not yet recognized was approximately $8.9 million, which is expected to be recognized over an average remaining recognition period of 3.6 years.

[0001564590-17-002423:notes:115]
Valuation and Expense Information

[0001564590-17-002423:notes:116]
We use the Black-Scholes option pricing model (Black-Scholes Model) for the purpose of determining the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options. We use a Monte Carlo Simulation valuation method to value our performance-based PSUs. The fair value of RSUs and restricted stock issued is equal to the closing price of our stock on the date of grant. We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0001564590-17-002423:notes:117]
The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors. There were no changes made during 2016 to the methodology used to determine our assumptions.

[0001564590-17-002423:notes:118]
The weighted-average estimated fair value of stock options granted to employees during the years ended December 31, 2016, 2015 and 2014 was $5.22 per share, $4.28 per share and $6.31 per share, respectively, with the following weighted-average assumptions:

[0001564590-17-002423:notes:119]
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Expected volatility |  |  | 34.79 | % |  |  | 34.57 | % |  |  | 39.05 | % |
| Risk-free interest rate |  |  | 1.36 | % |  |  | 1.81 | % |  |  | 1.79 | % |
| Expected dividend yield |  |  | 1.98 | % |  |  | 2.35 | % |  |  | 1.90 | % |
| Expected life (in years) |  |  | 6.25 |  |  |  | 6.23 |  |  |  | 6.33 |  |

[0001564590-17-002423:notes:120]
We based our estimate of expected volatility for the years ended December 31, 2016, 2015 and 2014 on the sequential historical daily trading data of our common stock for a period equal to the expected life of the options granted. The selection of the historical volatility method was based on available data indicating our historical volatility is as equally representative of our future stock price trends as is our implied volatility. We have no reason to believe the future volatility of our stock price is likely to differ from its past volatility. The risk-free interest rate assumption is based upon implied yields of U.S. Treasury zero-coupon bonds on the date of grant having a remaining term equal to the expected life of the options granted. The dividend yield is based on our historical and expected dividend payouts. The expected life of our stock options is based upon historical exercise and forfeiture activity of our previous stock-based grants with a ten-year contractual term.

[0001564590-17-002423:notes:121]
The PSU pricing model also requires the use of several significant assumptions that impact the fair value estimate. The estimated fair value of the PSUs granted to employees during the years ended December 31, 2016, 2015 and 2014 was $23.50 per share, $17.64 per share and $22.11 per share, respectively, with the following assumptions:

[0001564590-17-002423:notes:122]
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Expected volatility |  |  | 29.79 | % |  |  | 31.34 | % |  |  | 36.40 | % |
| Risk-free interest rate |  |  | 1.17 | % |  |  | 1.20 | % |  |  | 0.96 | % |
| Expected dividend yield |  |  | 1.80 | % |  |  | 2.35 | % |  |  | 1.89 | % |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-17-002423:notes:123]
Note 4 – Investments

[0001564590-17-002423:notes:124]
At December 31, 2016, we held the following securities and investments, recorded at either fair value or cost:

[0001564590-17-002423:notes:125]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Fair Value / |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 12,367 |  |  | $ | 2,271 |  |  | $ | (42 | ) |  | $ | 14,596 |  |
| Corporate bonds |  |  | 66,522 |  |  |  | 64 |  |  |  | (174 | ) |  |  | 66,412 |  |
| Municipal fixed-rate bonds |  |  | 11,799 |  |  |  | 12 |  |  |  | (37 | ) |  |  | 11,774 |  |
| Asset-backed bonds |  |  | 10,201 |  |  |  | 19 |  |  |  | (14 | ) |  |  | 10,206 |  |
| Mortgage/Agency-backed bonds |  |  | 13,080 |  |  |  | 15 |  |  |  | (91 | ) |  |  | 13,004 |  |
| U.S. government bonds |  |  | 30,022 |  |  |  | 15 |  |  |  | (270 | ) |  |  | 29,767 |  |
| Foreign government bonds |  |  | 3,729 |  |  |  | 2 |  |  |  | (1 | ) |  |  | 3,730 |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | — |  |  |  | 11,855 |  |
| Marketable equity securities |  |  | 30,571 |  |  |  | 311 |  |  |  | (1,503 | ) |  |  | 29,379 |  |
| Available-for-sale securities held at fair value |  | $ | 190,146 |  |  | $ | 2,709 |  |  | $ | (2,132 | ) |  | $ | 190,723 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 767 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 219,290 |  |

[0001564590-17-002423:notes:126]
At December 31, 2015, we held the following securities and investments, recorded at either fair value or cost:

[0001564590-17-002423:notes:127]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Fair Value / |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,325 |  |  | $ | 1,575 |  |  | $ | (66 | ) |  | $ | 12,834 |  |
| Corporate bonds |  |  | 58,328 |  |  |  | 20 |  |  |  | (734 | ) |  |  | 57,614 |  |
| Municipal fixed-rate bonds |  |  | 26,414 |  |  |  | 28 |  |  |  | (18 | ) |  |  | 26,424 |  |
| Asset-backed bonds |  |  | 19,281 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 19,239 |  |
| Mortgage/Agency-backed bonds |  |  | 15,463 |  |  |  | 1 |  |  |  | (91 | ) |  |  | 15,373 |  |
| Government bonds |  |  | 35,646 |  |  |  | — |  |  |  | (248 | ) |  |  | 35,398 |  |
| Marketable equity securities |  |  | 31,643 |  |  |  | 4,301 |  |  |  | (1,693 | ) |  |  | 34,251 |  |
| Available-for-sale securities held at fair value |  | $ | 198,100 |  |  | $ | 5,927 |  |  | $ | (2,894 | ) |  | $ | 201,133 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,289 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 232,422 |  |

[0001564590-17-002423:notes:128]
As of December 31, 2016, corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds had the following contractual maturities:

[0001564590-17-002423:notes:129]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage / Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 18,912 |  |  | $ | 8,321 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,701 |  |  | $ | 2,400 |  |
| One to two years |  |  | 32,497 |  |  |  | 1,703 |  |  |  | 635 |  |  |  | 976 |  |  |  | 4,903 |  |  |  | 1,330 |  |
| Two to three years |  |  | 11,486 |  |  |  | 351 |  |  |  | 2,415 |  |  |  | 980 |  |  |  | 13,072 |  |  |  | — |  |
| Three to five years |  |  | 3,517 |  |  |  | 1,399 |  |  |  | 5,402 |  |  |  | — |  |  |  | 10,091 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,600 |  |  |  | 2,060 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 154 |  |  |  | 8,988 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 66,412 |  |  | $ | 11,774 |  |  | $ | 10,206 |  |  | $ | 13,004 |  |  | $ | 29,767 |  |  | $ | 3,730 |  |

[0001564590-17-002423:notes:130]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-17-002423:notes:131]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For each of the years ended December 31, 2016, 2015 and 2014, we recorded a charge of $0.8 million, $0.2 million and $0.1 million, respectively, related to the other-than-temporary impairment of certain marketable equity securities and our deferred compensation plan assets.

[0001564590-17-002423:notes:132]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments for the years ended December 31, 2016, 2015 and 2014:

[0001564590-17-002423:notes:133]
| Year Ended December 31, (In thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Gross realized gains |  | $ | 7,530 |  |  | $ | 10,906 |  |  | $ | 7,586 |  |
| Gross realized losses |  | $ | (1,607 | ) |  | $ | (569 | ) |  | $ | (308 | ) |

[0001564590-17-002423:notes:134]
The following table presents the breakdown of investments with unrealized losses at December 31, 2016:

[0001564590-17-002423:notes:135]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Deferred compensation plan assets |  | $ | 294 |  |  | $ | (12 | ) |  | $ | 245 |  |  | $ | (30 | ) |  | $ | 539 |  |  | $ | (42 | ) |
| Corporate bonds |  |  | 32,562 |  |  |  | (166 | ) |  |  | 2,722 |  |  |  | (8 | ) |  |  | 35,284 |  |  |  | (174 | ) |
| Municipal fixed-rate bonds |  |  | 8,936 |  |  |  | (37 | ) |  |  | — |  |  |  | — |  |  |  | 8,936 |  |  |  | (37 | ) |
| Asset-backed bonds |  |  | 2,986 |  |  |  | (14 | ) |  |  | — |  |  |  | — |  |  |  | 2,986 |  |  |  | (14 | ) |
| Mortgage/Agency-backed bonds |  |  | 7,842 |  |  |  | (81 | ) |  |  | 1,239 |  |  |  | (10 | ) |  |  | 9,081 |  |  |  | (91 | ) |
| U.S. government bonds |  |  | 26,449 |  |  |  | (270 | ) |  |  | — |  |  |  | — |  |  |  | 26,449 |  |  |  | (270 | ) |
| Foreign government bonds |  |  | 924 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 924 |  |  |  | (1 | ) |
| Marketable equity securities |  |  | 21,607 |  |  |  | (1,200 | ) |  |  | 1,495 |  |  |  | (303 | ) |  |  | 23,102 |  |  |  | (1,503 | ) |
| Total |  | $ | 101,600 |  |  | $ | (1,781 | ) |  | $ | 5,701 |  |  | $ | (351 | ) |  | $ | 107,301 |  |  | $ | (2,132 | ) |

[0001564590-17-002423:notes:136]
The following table presents the breakdown of investments with unrealized losses at December 31, 2015:

[0001564590-17-002423:notes:137]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Deferred compensation plan assets |  | $ | 1,243 |  |  | $ | (53 | ) |  | $ | 92 |  |  | $ | (13 | ) |  | $ | 1,335 |  |  | $ | (66 | ) |
| Corporate bonds |  |  | 35,952 |  |  |  | (566 | ) |  |  | 3,042 |  |  |  | (168 | ) |  |  | 38,994 |  |  |  | (734 | ) |
| Municipal fixed-rate bonds |  |  | 9,160 |  |  |  | (18 | ) |  |  | — |  |  |  | — |  |  |  | 9,160 |  |  |  | (18 | ) |
| Asset-backed bonds |  |  | 16,857 |  |  |  | (44 | ) |  |  | — |  |  |  | — |  |  |  | 16,857 |  |  |  | (44 | ) |
| Mortgage/Agency-backed bonds |  |  | 15,216 |  |  |  | (91 | ) |  |  | — |  |  |  | — |  |  |  | 15,216 |  |  |  | (91 | ) |
| Government bonds |  |  | 35,397 |  |  |  | (248 | ) |  |  | — |  |  |  | — |  |  |  | 35,397 |  |  |  | (248 | ) |
| Marketable equity securities |  |  | 14,364 |  |  |  | (1,564 | ) |  |  | 374 |  |  |  | (129 | ) |  |  | 14,738 |  |  |  | (1,693 | ) |
| Total |  | $ | 128,189 |  |  | $ | (2,584 | ) |  | $ | 3,508 |  |  | $ | (310 | ) |  | $ | 131,697 |  |  | $ | (2,894 | ) |

[0001564590-17-002423:notes:138]
The decrease in unrealized losses during 2016, as reflected in the table above, results from changes in market positions associated with our fixed income and equity investment portfolio. At December 31, 2016, a total of 293 of our marketable equity securities were in an unrealized loss position.

[0001564590-17-002423:notes:139]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0001564590-17-002423:notes:140]
|  |  | Fair Value Measurements at December 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,878 |  |  | $ | 6,878 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 17,222 |  |  |  | — |  |  |  | 17,222 |  |  |  | — |  |
| Cash equivalents |  |  | 24,100 |  |  |  | 6,878 |  |  |  | 17,222 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 14,596 |  |  |  | 14,596 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 66,412 |  |  |  | — |  |  |  | 66,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 11,774 |  |  |  | — |  |  |  | 11,774 |  |  |  | — |  |
| Asset-backed bonds |  |  | 10,206 |  |  |  | — |  |  |  | 10,206 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 13,004 |  |  |  | — |  |  |  | 13,004 |  |  |  | — |  |
| U.S. government bonds |  |  | 29,767 |  |  |  | 29,767 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 3,730 |  |  |  | — |  |  |  | 3,730 |  |  |  | — |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | 11,855 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 3,374 |  |  |  | 3,374 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 26,005 |  |  |  | 26,005 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 190,723 |  |  |  | 73,742 |  |  |  | 116,981 |  |  |  | — |  |
| Total |  | $ | 214,823 |  |  | $ | 80,620 |  |  | $ | 134,203 |  |  | $ | — |  |
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,271 |  |  | $ | 1,271 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 11,696 |  |  |  | — |  |  |  | 11,696 |  |  |  | — |  |
| Cash equivalents |  |  | 12,967 |  |  |  | 1,271 |  |  |  | 11,696 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,834 |  |  |  | 12,834 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 57,614 |  |  |  | — |  |  |  | 57,614 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 26,424 |  |  |  | — |  |  |  | 26,424 |  |  |  | — |  |
| Asset-backed bonds |  |  | 19,239 |  |  |  | — |  |  |  | 19,239 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 15,373 |  |  |  | — |  |  |  | 15,373 |  |  |  | — |  |
| Government bonds |  |  | 35,398 |  |  |  | 35,398 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,384 |  |  |  | 5,384 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,867 |  |  |  | 28,867 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 201,133 |  |  |  | 82,483 |  |  |  | 118,650 |  |  |  | — |  |
| Total |  | $ | 214,100 |  |  | $ | 83,754 |  |  | $ | 130,346 |  |  | $ | — |  |

[0001564590-17-002423:notes:141]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-17-002423:notes:142]
Our municipal variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-002423:notes:143]
Note 5 – Derivative Instruments and Hedging Activities

[0001564590-17-002423:notes:144]
We have certain customers and suppliers who are invoiced or pay in a non-functional currency. Changes in the monetary exchange rates may adversely affect our results of operations and financial condition, as these are remeasured to the functional currency through profit and loss. When appropriate, we enter into various derivative transactions to enhance our ability to manage the volatility relating to these typical business exposures. We do not hold or issue derivative instruments for trading or other speculative purposes. Our derivative instruments are recorded in the Consolidated Balance Sheets at their fair values. Our derivative instruments do not qualify for hedge accounting, and accordingly, all changes in the fair value of the instruments are recognized as other income (expense) in the Consolidated Statements of Income. Our derivative instruments are not subject to master netting arrangements and are not offset in the Consolidated Balance Sheets.

[0001564590-17-002423:notes:145]
As of December 31, 2016, we had forward contracts outstanding with notional amounts totaling €5.5 million ($5.8 million), which mature in the first quarter of in 2017.

[0001564590-17-002423:notes:146]
The fair values of our derivative instruments recorded in the Consolidated Balance Sheet as of December 31, 2016 and 2015 were as follows:

[0001564590-17-002423:notes:147]
| (In thousands) |  | Balance Sheet Location |  | 2016 |  |  | 2015 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 159 |  |  | $ | — |  |

[0001564590-17-002423:notes:148]
The change in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the years ended December 31, 2016, 2015 and 2014 were as follows:

[0001564590-17-002423:notes:149]
| (In thousands) |  | Income Statement Location |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | 724 |  |  | $ | 511 |  |  | $ | 1,852 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-17-002423:notes:150]
Note 6 – Inventory

[0001564590-17-002423:notes:151]
At December 31, 2016 and 2015, inventory was comprised of the following:

[0001564590-17-002423:notes:152]
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Raw materials |  | $ | 40,461 |  |  | $ | 34,223 |  |
| Work in process |  |  | 4,003 |  |  |  | 2,893 |  |
| Finished goods |  |  | 60,653 |  |  |  | 54,417 |  |
| Total Inventory, net |  | $ | 105,117 |  |  | $ | 91,533 |  |

[0001564590-17-002423:notes:153]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At December 31, 2016 and 2015, raw materials reserves totaled $14.6 million and $17.5 million, respectively, and finished goods inventory reserves totaled $10.6 million and $9.2 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-17-002423:notes:154]
Note 7 – Property, Plant and Equipment

[0001564590-17-002423:notes:155]
At December 31, 2016 and 2015, property, plant and equipment were comprised of the following:

[0001564590-17-002423:notes:156]
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 29,229 |  |  |  | 25,667 |  |
| Building |  |  | 68,301 |  |  |  | 68,301 |  |
| Furniture and fixtures |  |  | 18,477 |  |  |  | 17,347 |  |
| Computer hardware and software |  |  | 87,655 |  |  |  | 76,389 |  |
| Engineering and other equipment |  |  | 118,746 |  |  |  | 112,132 |  |
| Total Property, Plant and Equipment |  |  | 326,983 |  |  |  | 304,411 |  |
| Less accumulated depreciation |  |  | (242,514 | ) |  |  | (231,178 | ) |
| Total Property, Plant and Equipment, net |  | $ | 84,469 |  |  | $ | 73,233 |  |

[0001564590-17-002423:notes:157]
Depreciation expense was $12.0 million, $12.3 million and $12.5 million in 2016, 2015, and 2014, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-17-002423:notes:158]
Note 8 – Goodwill and Intangible Assets

[0001564590-17-002423:notes:159]
Goodwill was $3.5 million at December 31, 2016 and 2015, and was previously recorded in our Enterprise Networks reportable segment. As a result of our new reporting structure adopted in the first quarter of 2016, which is discussed further in Note 12, we reallocated goodwill from our Enterprise Networks reportable segment to our two, new reportable segments – Network Solutions and Services & Support. As a result, goodwill of $3.1 million and $0.4 million was reallocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-17-002423:notes:160]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2016, we concluded that it was not necessary to perform the two-step impairment test. There have been no impairment losses recognized since the acquisition in 2011.

[0001564590-17-002423:notes:161]
Intangible assets are included in other assets in the accompanying Consolidated Balance Sheets. The following table presents our intangible assets as of December 31, 2016 and 2015:

[0001564590-17-002423:notes:162]
| (In thousands) |  | 2016 |  |  | 2015 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,899 |  |  | $ | (3,208 | ) |  | $ | 3,691 |  |  | $ | 5,828 |  |  | $ | (2,627 | ) |  | $ | 3,201 |  |
| Developed technology |  |  | 6,444 |  |  |  | (5,061 | ) |  |  | 1,383 |  |  |  | 5,720 |  |  |  | (4,329 | ) |  |  | 1,391 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (2,129 | ) |  |  | 211 |  |  |  | 2,340 |  |  |  | (1,854 | ) |  |  | 486 |  |
| Supply agreement |  |  | 1,400 |  |  |  | (544 | ) |  |  | 856 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| License |  |  | 500 |  |  |  | (113 | ) |  |  | 387 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Patent |  |  | 500 |  |  |  | (20 | ) |  |  | 480 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Trade names |  |  | 370 |  |  |  | (285 | ) |  |  | 85 |  |  |  | 270 |  |  |  | (265 | ) |  |  | 5 |  |
| Non-compete |  |  | 200 |  |  |  | (26 | ) |  |  | 174 |  |  |  | 11 |  |  |  | (11 | ) |  |  | — |  |
| Total |  | $ | 18,653 |  |  | $ | (11,386 | ) |  | $ | 7,267 |  |  | $ | 14,169 |  |  | $ | (9,086 | ) |  | $ | 5,083 |  |

[0001564590-17-002423:notes:163]
Amortization expense was $2.5 million, $1.9 million and $2.3 million for the years ended December 31, 2016, 2015 and 2014, respectively.

[0001564590-17-002423:notes:164]
As of December 31, 2016, the estimated future amortization expense of intangible assets is as follows:

[0001564590-17-002423:notes:165]
| (In thousands) |  | Amount |  |
| 2017 |  | $ | 2,867 |  |
| 2018 |  |  | 1,168 |  |
| 2019 |  |  | 655 |  |
| 2020 |  |  | 621 |  |
| 2021 |  |  | 568 |  |
| Thereafter |  |  | 1,388 |  |
| Total |  | $ | 7,267 |  |


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001564590-17-002423:notes:166]
Note 9 – Alabama State Industrial Development Authority Financing and Economic Incentives

[0001564590-17-002423:notes:167]
In conjunction with an expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN. The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the “Bank”). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the “Bondholder”), which was acquired by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond (“Amended and Restated Bond”) was issued and the original financing agreement was amended. The Amended and Restated Bond bears interest, payable monthly. The interest rate is 2% per annum. The Amended and Restated Bond matures on January 1, 2020, and is currently outstanding in the aggregate principal amount of $27.8 million. The estimated fair value of the bond using a level 2 valuation technique at December 31, 2016 was approximately $28.1 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. We are required to make payments to the Authority in amounts necessary to pay the interest on the Amended and Restated Bond. Included in long-term investments at December 31, 2016 is $27.8 million which is invested in a restricted certificate of deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness.

[0001564590-17-002423:notes:168]
In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we are required to remit to the state for those employment positions that qualify under the program. We realized economic incentives related to payroll withholdings totaling $1.3 million for each of the years ended December 31, 2016, 2015 and 2014.

[0001564590-17-002423:notes:169]
We made principal payments of $1.1 million for the years ended December 31, 2016 and 2015, respectively, and anticipate making a principal payment in 2017.  At December 31, 2016, $1.0 million of the bond debt was classified as a current liability in accounts payable in the Consolidated Balance Sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-002423:notes:170]
Note 10 – Income Taxes

[0001564590-17-002423:notes:171]
A summary of the components of the provision for income taxes for the years ended December 31, 2016, 2015 and 2014 is as follows:

[0001564590-17-002423:notes:172]
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 12,733 |  |  | $ | 7,504 |  |  | $ | 7,626 |  |
| State |  |  | 1,141 |  |  |  | 279 |  |  |  | 599 |  |
| International |  |  | 477 |  |  |  | (29 | ) |  |  | 12,587 |  |
| Total Current |  |  | 14,351 |  |  |  | 7,754 |  |  |  | 20,812 |  |
| Deferred |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 647 |  |  |  | (585 | ) |  |  | (1,083 | ) |
| State |  |  | 73 |  |  |  | (66 | ) |  |  | (123 | ) |
| International |  |  | (3,405 | ) |  |  | (41 | ) |  |  | (4,320 | ) |
| Total Deferred |  |  | (2,685 | ) |  |  | (692 | ) |  |  | (5,526 | ) |
| Total Provision for Income Taxes |  | $ | 11,666 |  |  | $ | 7,062 |  |  | $ | 15,286 |  |

[0001564590-17-002423:notes:173]
Our effective income tax rate differs from the federal statutory rate due to the following:

[0001564590-17-002423:notes:174]
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Tax provision computed at the federal statutory rate |  |  | 35.00 | % |  |  | 35.00 | % |  |  | 35.00 | % |
| State income tax provision, net of federal benefit |  |  | 3.93 |  |  |  | 4.86 |  |  |  | 2.69 |  |
| Federal research credits |  |  | (8.15 | ) |  |  | (12.55 | ) |  |  | (4.05 | ) |
| Foreign taxes |  |  | (0.34 | ) |  |  | 2.10 |  |  |  | (7.26 | ) |
| Tax-exempt income |  |  | (0.53 | ) |  |  | (1.94 | ) |  |  | (1.25 | ) |
| State tax incentives |  |  | (2.77 | ) |  |  | (5.04 | ) |  |  | (2.21 | ) |
| Stock-based compensation |  |  | 2.53 |  |  |  | 6.91 |  |  |  | 3.06 |  |
| Domestic production activity deduction |  |  | (2.23 | ) |  |  | (3.17 | ) |  |  | (1.15 | ) |
| Bargain purchase |  |  | (2.64 | ) |  |  | — |  |  |  | — |  |
| Other, net |  |  | 0.08 |  |  |  | 1.30 |  |  |  | 0.69 |  |
| Effective Tax Rate |  |  | 24.88 | % |  |  | 27.47 | % |  |  | 25.52 | % |

[0001564590-17-002423:notes:175]
Income before provision for income taxes for the years ended December 31, 2016, 2015 and 2014 is as follows:

[0001564590-17-002423:notes:176]
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| U.S. entities |  | $ | 54,077 |  |  | $ | 27,400 |  |  | $ | 23,812 |  |
| International entities |  |  | (7,182 | ) |  |  | (1,692 | ) |  |  | 36,094 |  |
| Total |  | $ | 46,895 |  |  | $ | 25,708 |  |  | $ | 59,906 |  |

[0001564590-17-002423:notes:177]
Income before provision for income taxes for international entities reflects income based on statutory transfer pricing agreements. This amount does not correlate to consolidated international revenues, many of which occur from our U.S. entity.

[0001564590-17-002423:notes:178]
Deferred income taxes on the balance sheet result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The principal components of our current and non-current deferred taxes are as follows:

[0001564590-17-002423:notes:179]
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Deferred tax assets |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | — |  |  | $ | 7 |  |
| Inventory |  |  | 12,020 |  |  |  | 12,558 |  |
| Accrued expenses |  |  | 5,551 |  |  |  | 6,359 |  |
| Investments |  |  | 1,062 |  |  |  | — |  |
| Deferred compensation |  |  | 5,751 |  |  |  | 5,072 |  |
| Stock-based compensation |  |  | 4,724 |  |  |  | 4,704 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 762 |  |  |  | 1,026 |  |
| Pensions |  |  | 4,273 |  |  |  | 5,729 |  |
| Foreign losses |  |  | 6,486 |  |  |  | 5,389 |  |
| State losses and credit carry-forwards |  |  | 4,021 |  |  |  | 4,187 |  |
| Federal loss and research carry-forwards |  |  | 5,886 |  |  |  | 5,886 |  |
| Valuation allowance |  |  | (6,149 | ) |  |  | (7,250 | ) |
| Total Deferred Tax Assets |  |  | 44,387 |  |  |  | 43,667 |  |
| Deferred tax liabilities |  |  |  |  |  |  |  |  |
| Property, plant and equipment |  |  | (4,433 | ) |  |  | (3,315 | ) |
| Accrued expenses |  |  | — |  |  |  | (2,791 | ) |
| Intellectual property |  |  | (1,918 | ) |  |  | (476 | ) |
| Investments |  |  | — |  |  |  | (70 | ) |
| Total Deferred Tax Liabilities |  |  | (6,351 | ) |  |  | (6,652 | ) |
| Net Deferred Tax Assets |  | $ | 38,036 |  |  | $ | 37,015 |  |

[0001564590-17-002423:notes:180]
At December 31, 2016 and 2015, non-current deferred taxes related to our investments and our defined benefit pension plan, reflect deferred taxes on the net unrealized gains on available-for-sale investments and deferred taxes on unrealized losses in our pension plan. The net change in non-current deferred taxes associated with these items, a deferred tax benefit of $1.5 million and $3.7 million in 2016 and 2015, respectively, is recorded as an adjustment to other comprehensive income, presented in the Consolidated Statements of Comprehensive Income.

[0001564590-17-002423:notes:181]
Based upon our results of operations in 2016 and expected profitability in future years in a certain international jurisdiction, we concluded that it is more likely than not certain foreign deferred tax assets will be realized. As of December 31, 2016, the remaining valuation allowance primarily relates to deferred tax assets related to state credit carry-forwards from tax credits in excess of our annual tax liability to an individual state where we do not generate sufficient state income to offset the credit and net operating losses in foreign jurisdictions. We believe it is more likely than not that we will not realize the full benefits of the deferred tax assets arising from these losses and credits, and accordingly, we have provided a valuation allowance against these deferred tax assets. The deferred tax assets for foreign and domestic carry-forwards, unamortized research and development costs, and state credit carry-forwards of $16.4 million will expire between 2017 and 2030. The loss carry-forwards were acquired through acquisitions in 2009 and 2011. We will continue to assess the realization of our deferred tax assets and related valuations allowances. We do not provide for U.S. income tax on undistributed earnings of our foreign operations, whose earnings are intended to be permanently reinvested. These earnings are not required to service debt or fund our U.S. operations. It is impracticable to determine the amount of any unrecognized deferred tax liability for temporary differences related to investments in foreign subsidiaries. The net change in our valuation allowance from December 31, 2015 to December 31, 2016 was $1.1 million.

[0001564590-17-002423:notes:182]
As of December 31, 2016 and 2015, respectively, our cash and cash equivalents were $79.9 million and $84.6 million and short-term investments were $43.2 million and $34.4 million, which provided an available short-term liquidity of $123.1 million and $118.9 million.  Of these amounts, our foreign subsidiaries held cash of $42.1 million and $38.9 million, respectively, representing approximately 34.2% and 32.7% of available short-term liquidity, which is used to fund on-going liquidity needs of these subsidiaries.  We intend to permanently reinvest these funds outside the U.S. and our current business plans do not indicate a need to repatriate to fund domestic operations.  However, if these funds were repatriated to the U.S. or used for U.S. operations, certain amounts related to the earnings and profits of foreign subsidiaries could be subject to U.S. tax for the incremental amount in excess of the foreign tax paid.  Due to the timing and circumstances of repatriation of such earnings, if any, it is not practical to determine the amount of funds subject to repatriation or the associated unrecognized deferred tax liability related to the amount.

[0001564590-17-002423:notes:183]
During 2016, 2015 and 2014, we recorded an income tax benefit (expense) of nil, $(40) thousand and $0.1 million, respectively, as an adjustment to equity. This is calculated on the difference between the exercise price of stock option exercises and the market price of the underlying common stock upon exercise.

[0001564590-17-002423:notes:184]
The change in the unrecognized income tax benefits for the years ended December 31, 2016, 2015 and 2014 is reconciled below:

[0001564590-17-002423:notes:185]
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period |  | $ | 2,537 |  |  | $ | 3,334 |  |  | $ | 3,240 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | 95 |  |  |  | — |  |  |  | — |  |
| Current year |  |  | 428 |  |  |  | 280 |  |  |  | 522 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | (29 | ) |  |  | — |  |
| Settlements with taxing authorities |  |  | — |  |  |  | (103 | ) |  |  | — |  |
| Expiration of applicable statute of limitations |  |  | (834 | ) |  |  | (945 | ) |  |  | (428 | ) |
| Balance at end of period |  | $ | 2,226 |  |  | $ | 2,537 |  |  | $ | 3,334 |  |

[0001564590-17-002423:notes:186]
As of December 31, 2016, 2015, and 2014, our total liability for unrecognized tax benefits was $2.2 million, $2.5 million, and $3.3 million, respectively, of which $1.7 million, $1.8 million, and $2.6 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of December 31, 2016, 2015 and 2014, the balances of accrued interest and penalties were $0.8 million, $0.9 million and $1.0 million, respectively.

[0001564590-17-002423:notes:187]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date. We file income tax returns in the U.S. federal and various state jurisdictions and several foreign jurisdictions. We are not currently under audit by the Internal Revenue Service. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2013.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-17-002423:notes:188]
Note 11 – Employee Benefit Plans

[0001564590-17-002423:notes:189]
Pension Benefit Plan

[0001564590-17-002423:notes:190]
We maintain a defined benefit pension plan covering employees in certain foreign countries.

[0001564590-17-002423:notes:191]
The pension benefit plan obligations and funded status at December 31, 2016 and 2015, are as follows:

[0001564590-17-002423:notes:192]
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | (26,851 | ) |  | $ | (30,507 | ) |
| Service cost |  |  | (1,211 | ) |  |  | (1,314 | ) |
| Interest cost |  |  | (720 | ) |  |  | (615 | ) |
| Actuarial gain (loss) - experience |  |  | 431 |  |  |  | 247 |  |
| Actuarial gain (loss) - assumptions |  |  | (2,628 | ) |  |  | 2,078 |  |
| Benefit payments |  |  | 52 |  |  |  | 81 |  |
| Effects of foreign currency exchange rate changes |  |  | 916 |  |  |  | 3,179 |  |
| Projected benefit obligation at end of period |  |  | (30,011 | ) |  |  | (26,851 | ) |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  |  | 19,213 |  |  |  | 20,338 |  |
| Actual return on plan assets |  |  | 1,494 |  |  |  | 988 |  |
| Effects of foreign currency exchange rate changes |  |  | (662 | ) |  |  | (2,113 | ) |
| Fair value of plan assets at end of period |  |  | 20,045 |  |  |  | 19,213 |  |
| Funded (unfunded) status at end of period |  | $ | (9,966 | ) |  | $ | (7,638 | ) |

[0001564590-17-002423:notes:193]
The accumulated benefit obligation was $28.7 million and $25.1 million at December 31, 2016 and 2015, respectively. The increase in the accumulated benefit obligation and the change in actuarial gain (loss) is primarily attributable to a decrease in the discount rate used in 2016 to determine the accumulated benefit obligation.

[0001564590-17-002423:notes:194]
The net amounts recognized in the balance sheet for the unfunded pension liability as of December 31, 2016 and 2015 are as follows:

[0001564590-17-002423:notes:195]
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Current liability |  | $ | — |  |  | $ | — |  |
| Non-current liability |  |  | (9,966 | ) |  |  | (7,638 | ) |
| Total |  | $ | (9,966 | ) |  | $ | (7,638 | ) |

[0001564590-17-002423:notes:196]
The components of net periodic pension cost and amounts recognized in other comprehensive income for the years ended December 31, 2016, 2015 and 2014 are as follows:

[0001564590-17-002423:notes:197]
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,211 |  |  | $ | 1,314 |  |  | $ | 1,189 |  |
| Interest cost |  |  | 720 |  |  |  | 615 |  |  |  | 836 |  |
| Expected return on plan assets |  |  | (1,057 | ) |  |  | (1,011 | ) |  |  | (1,086 | ) |
| Amortization of actuarial losses |  |  | 175 |  |  |  | 407 |  |  |  | — |  |
| Net periodic benefit cost |  |  | 1,049 |  |  |  | 1,325 |  |  |  | 939 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | 1,782 |  |  |  | (2,303 | ) |  |  | 7,052 |  |
| Amortization of actuarial losses |  |  | (156 | ) |  |  | (396 | ) |  |  | — |  |
| Amount recognized in other comprehensive income |  |  | 1,626 |  |  |  | (2,699 | ) |  |  | 7,052 |  |
| Total recognized in net periodic benefit cost and other comprehensive income |  | $ | 2,675 |  |  | $ | (1,374 | ) |  | $ | 7,991 |  |

[0001564590-17-002423:notes:198]
The amounts recognized in accumulated other comprehensive income as of December 31, 2016 and 2015 are as follows:

[0001564590-17-002423:notes:199]
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Net actuarial loss |  | $ | 6,871 |  |  | $ | 5,245 |  |

[0001564590-17-002423:notes:200]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the selection of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return.

[0001564590-17-002423:notes:201]
Another key assumption in determining net pension expense is the assumed discount rate to be used to discount plan obligations. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations.

[0001564590-17-002423:notes:202]
The weighted-average assumptions that were used to determine the net periodic benefit cost for the years ended December 31, 2016, 2015 and 2014 are as follows:

[0001564590-17-002423:notes:203]
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Discount rates |  |  | 2.64 | % |  |  | 2.20 | % |  |  | 3.70 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.25 | % |  |  | 2.25 | % |
| Expected long-term rates of return |  |  | 5.40 | % |  |  | 5.40 | % |  |  | 5.40 | % |

[0001564590-17-002423:notes:204]
The weighted-average assumptions that were used to determine the benefit obligation at December 31, 2016 and 2015:

[0001564590-17-002423:notes:205]
|  |  | 2016 |  |  | 2015 |  |
| Discount rates |  |  | 1.90 | % |  |  | 2.64 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.25 | % |

[0001564590-17-002423:notes:206]
Actuarial gains and losses are recorded in accumulated other comprehensive income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants. We estimate that $0.3 million will be amortized from accumulated other comprehensive income into net periodic pension cost in 2017 for the net actuarial loss.

[0001564590-17-002423:notes:207]
We do not anticipate making a contribution to this pension plan in 2017. The following pension benefit payments, which reflect expected future service, as appropriate, are expected to be paid to participants:

[0001564590-17-002423:notes:208]
| (In thousands) |  |  |  |  |
| 2017 |  | $ | 348 |  |
| 2018 |  |  | 515 |  |
| 2019 |  |  | 699 |  |
| 2020 |  |  | 964 |  |
| 2021 |  |  | 1,079 |  |
| 2022 – 2026 |  |  | 5,156 |  |
| Total |  | $ | 8,761 |  |

[0001564590-17-002423:notes:209]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-17-002423:notes:210]
|  |  | Fair Value Measurements at December 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash and cash equivalents |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 12,546 |  |  |  | 12,546 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 2,037 |  |  |  | 2,037 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large cap blend |  |  | 4,462 |  |  |  | 4,462 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 249 |  |  |  | 249 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 745 |  |  |  | 745 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 20,039 |  |  |  | 20,039 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 20,045 |  |  | $ | 20,045 |  |  | $ | — |  |  | $ | — |  |

[0001564590-17-002423:notes:211]
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash and cash equivalents |  | $ | 3 |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,633 |  |  |  | 11,633 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 1,960 |  |  |  | 1,960 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large cap blend |  |  | 4,604 |  |  |  | 4,604 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 258 |  |  |  | 258 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 755 |  |  |  | 755 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 19,210 |  |  |  | 19,210 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 19,213 |  |  | $ | 19,213 |  |  | $ | — |  |  | $ | — |  |

[0001564590-17-002423:notes:212]
Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants, and consider a broad range of economic conditions. Central to the policy are target allocation ranges by asset class, which is currently 75% for bond funds and 25% for equity funds.

[0001564590-17-002423:notes:213]
The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions, and achieve asset returns that are competitive with like institutions employing similar investment strategies.

[0001564590-17-002423:notes:214]
The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations.

[0001564590-17-002423:notes:215]
401(k) Savings Plan

[0001564590-17-002423:notes:216]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (Savings Plan) for the benefit of our eligible employees. The Savings Plan is intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (Code), and is intended to be a “safe harbor” 401(k) plan under Code Section 401(k)(12). The Savings Plan allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plan also requires us to contribute a “safe harbor” amount each year. We match up to 4% of employee contributions (100% of an employee’s first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s one year anniversary date. In calculating our matching contribution, we only use compensation up to the statutory maximum under the Code ($265 thousand for 2016). All contributions under the Savings Plan are 100% vested. Expenses recorded for employer contributions and plan administration costs for the Savings Plan amounted to approximately $4.1 million, $4.7 million and $4.5 million in 2016, 2015 and 2014, respectively.

[0001564590-17-002423:notes:217]
Deferred Compensation Plans

[0001564590-17-002423:notes:218]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors.

[0001564590-17-002423:notes:219]
For our executive management employees, the ADTRAN, Inc. Deferred Compensation Program for Employees is offered as a supplement to our tax-qualified 401(k) plan and is available to certain executive management employees who have been designated by our Board of Directors. This deferred compensation plan allows participants to defer all or a portion of certain specified bonuses and up to 25% of remaining cash compensation, and permits us to make matching contributions on a discretionary basis, without the limitations that apply to the 401(k) plan. To date, we have not made any matching contributions under this plan. We also maintain the ADTRAN, Inc. Equity Deferral Program for Employees. Under this plan, participants may elect to defer all or a portion of their vested PSUs to the Plan. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the Participant.

[0001564590-17-002423:notes:220]
For our Board of Directors, we maintain the ADTRAN, Inc. Deferred Compensation Program for Directors. This program allows our Board of Directors to defer all or a portion of monetary remuneration paid to the Director, including, but not limited to, meeting fees and annual retainers. We also maintain the ADTRAN, Inc. Equity Deferral Program for Directors. Under this plan, participants may elect to defer all or a portion of their vested restricted stock awards. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the Director.

[0001564590-17-002423:notes:221]
We have set aside the plan assets for all plans in a rabbi trust (Trust) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant, and the participant’s bookkeeping account is credited with the earnings and losses attributable to those investments. Benefits are scheduled to be distributed six months after termination of employment in a single lump sum payment or annual installments paid over a three or ten year term. Distributions will be made on a pro rata basis from each of the hypothetical investments of the Participant’s account in cash. Any whole shares of ADTRAN, Inc. common stock that are distributed will be distributed in-kind.

[0001564590-17-002423:notes:222]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging from equities to money market instruments. These mutual funds are publicly quoted and reported at fair value. The fair value of the assets held by the Trust and the amounts payable to the plan participants at December 31, 2016 and 2015 are as follows:

[0001564590-17-002423:notes:223]
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |  |  |
| Long-term Investments |  | $ | 14,596 |  |  | $ | 12,834 |  |
| Total Fair Value of Plan Assets |  | $ | 14,596 |  |  | $ | 12,834 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |  |  |
| Non-current Liabilities |  | $ | 14,596 |  |  | $ | 12,834 |  |
| Total Amounts Payable to Plan Participants |  | $ | 14,596 |  |  | $ | 12,834 |  |

[0001564590-17-002423:notes:224]
Interest and dividend income of the Trust have been included in interest and dividend income in the accompanying 2016, 2015 and 2014 Consolidated Statements of Income. Changes in the fair value of the plan assets held by the Trust have been included in accumulated other comprehensive income in the accompanying 2016 and 2015 Consolidated Balance Sheets. Changes in the fair value of the deferred compensation liability are included as selling, general and administrative expense in the accompanying 2016, 2015 and 2014 Consolidated Statements of Income. Based on the changes in the total fair value of the Trust’s assets, we recorded deferred compensation income (expense) in 2016, 2015 and 2014 of $(1.3) million, $0.3 million and $(0.7) million, respectively.

[0001564590-17-002423:notes:225]
Retiree Medical Coverage

[0001564590-17-002423:notes:226]
We provide medical, dental and prescription drug coverage to one retired former officer and his spouse, for his life, on the same terms as provided to our active officers, and to the spouse of a former deceased officer for up to 30 years. At December 31, 2016 and 2015, this liability totaled $0.2 million.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-002423:notes:227]
Note 12 – Segment Information and Major Customers

[0001564590-17-002423:notes:228]
In 2015, we realigned our organizational structure to better match our market opportunities, technological development initiatives, and improve efficiencies. During the first quarter of 2016, our chief operating decision maker requested changes in the information that he regularly reviews for purposes of allocating resources and assessing performance. As a result, beginning with the quarter ended March 31, 2016, we began reporting our financial performance based on two, new reportable segments – Network Solutions and Services & Support. Network Solutions includes hardware products and next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes our suite of ProCloud managed services, network installation, engineering and maintenance services, and fee-based technical support and equipment repair/replacement plans.

[0001564590-17-002423:notes:229]
We evaluate the performance of our new segments based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net realized investment gain/loss, other income/expense and provision for taxes are reported on a company-wide, functional basis only. Historical financial information by reportable segment and category, as discussed below, has been recast to conform to our new reporting structure. There are no inter-segment revenues.

[0001564590-17-002423:notes:230]
The following table presents information about the reported sales and gross profit of our reportable segments for each of the years ended December 31, 2016, 2015 and 2014. Asset information by reportable segment is not reported, since we do not produce such information internally.

[0001564590-17-002423:notes:231]
| Sales and Gross Profit by Market Segment |  |  |  |  |  |  |  |  |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
|  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 525,502 |  |  | $ | 254,807 |  |  | $ | 527,422 |  |  | $ | 233,579 |  |  | $ | 559,532 |  |  | $ | 271,517 |  |
| Services & Support |  |  | 111,279 |  |  |  | 36,537 |  |  |  | 72,642 |  |  |  | 33,318 |  |  |  | 70,475 |  |  |  | 39,810 |  |
| Total |  | $ | 636,781 |  |  | $ | 291,344 |  |  | $ | 600,064 |  |  | $ | 266,897 |  |  | $ | 630,007 |  |  | $ | 311,327 |  |

[0001564590-17-002423:notes:232]
Sales by Category

[0001564590-17-002423:notes:233]
In addition to our new reporting segments, we will also report revenue for the following three categories – Access & Aggregation, Customer Devices, and Traditional & Other Products.

[0001564590-17-002423:notes:234]
The table below presents sales information by product category for the years ended December 31, 2016, 2015 and 2014:

[0001564590-17-002423:notes:235]
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Access & Aggregation |  | $ | 436,372 |  |  | $ | 405,698 |  |  | $ | 401,769 |  |
| Customer Devices |  |  | 137,608 |  |  |  | 125,565 |  |  |  | 138,051 |  |
| Traditional & Other Products |  |  | 62,801 |  |  |  | 68,801 |  |  |  | 90,187 |  |
| Total |  | $ | 636,781 |  |  | $ | 600,064 |  |  | $ | 630,007 |  |

[0001564590-17-002423:notes:236]
The following table presents sales information by geographic area for the years ended December 31, 2016, 2015 and 2014. International sales correlate to shipments with a non-U.S. destination.

[0001564590-17-002423:notes:237]
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| United States |  | $ | 501,337 |  |  | $ | 419,366 |  |  | $ | 381,382 |  |
| Germany |  |  | 85,780 |  |  |  | 111,666 |  |  |  | 150,987 |  |
| Other international |  |  | 49,664 |  |  |  | 69,032 |  |  |  | 97,638 |  |
| Total |  | $ | 636,781 |  |  | $ | 600,064 |  |  | $ | 630,007 |  |

[0001564590-17-002423:notes:238]
Customers comprising more than 10% of revenue can change from year to year. Single customers comprising more than 10% of our revenue in 2016 included three customers at 24%, 19% and 12%. Single customers comprising more than 10% of our revenue in 2015 included three customers at 20%, 17% and 14%. Single customers comprising more than 10% of our revenue in 2014 included two customers at 21% and 14%. No other customer accounted for 10% or more of our sales in 2016, 2015 or 2014. Our five largest customers, other than those with more than 10 percent of revenues disclosed above, can change from year to year.  These customers represented 13%, 14%, and 22% of total revenue in 2016, 2015 and 2014, respectively. Revenues in this disclosure do not include distributor agents, who predominately provide fulfillment services to end users. In such cases where known, that revenue is associated with the end user.

[0001564590-17-002423:notes:239]
Additional Segment Information

[0001564590-17-002423:notes:240]
As of December 31, 2016, long-lived assets, net totaled $84.5 million, which includes $79.9 million held in the United States and $4.6 million held outside the United States. As of December 31, 2015, long-lived assets, net totaled $73.2 million, which includes $68.8 million held in the United States and $4.4 million held outside the United States.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-002423:notes:241]
Note 13 – Commitments and Contingencies

[0001564590-17-002423:notes:242]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-17-002423:notes:243]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of December 31, 2016, of which $7.7 million has been applied to these commitments.

[0001564590-17-002423:notes:244]
We lease office space and equipment under operating leases which expire at various dates through 2025. As of December 31, 2016, future minimum rental payments under non-cancelable operating leases with original maturities of greater than 12 months are as follows:

[0001564590-17-002423:notes:245]
| (In thousands) |  |  |  |  |
| 2017 |  | $ | 3,788 |  |
| 2018 |  |  | 2,043 |  |
| 2019 |  |  | 847 |  |
| 2020 |  |  | 741 |  |
| Thereafter |  |  | 3,243 |  |
| Total |  | $ | 10,662 |  |

[0001564590-17-002423:notes:246]
Rental expense was $4.2 million, $4.9 million and $4.7 million for the years ended December 31, 2016, 2015 and 2014, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-002423:notes:247]
Note 14 – Earnings per Share

[0001564590-17-002423:notes:248]
A summary of the calculation of basic and diluted earnings per share (EPS) for the years ended December 31, 2016, 2015 and 2014 is as follows:

[0001564590-17-002423:notes:249]
| (In thousands, except for per share amounts) |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 35,229 |  |  | $ | 18,646 |  |  | $ | 44,620 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,724 |  |  |  | 51,145 |  |  |  | 55,120 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 170 |  |  |  | 81 |  |  |  | 304 |  |
| Restricted stock and restricted stock units |  |  | 55 |  |  |  | 41 |  |  |  | 58 |  |
| Weighted average number of shares – diluted |  | $ | 48,949 |  |  | $ | 51,267 |  |  | $ | 55,482 |  |
| Net income per share – basic |  | $ | 0.72 |  |  | $ | 0.36 |  |  | $ | 0.81 |  |
| Net income per share – diluted |  | $ | 0.72 |  |  | $ | 0.36 |  |  | $ | 0.80 |  |

[0001564590-17-002423:notes:250]
For each of the years ended December 31, 2016, 2015 and 2014, 4.6 million, 6.1 million and 4.4 million stock options were outstanding but were not included in the computation of that year’s diluted EPS because the options’ exercise prices were greater than the average market price of the common shares, therefore making them anti-dilutive under the treasury stock method.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001564590-17-002423:notes:251]
Note 15 – Summarized Quarterly Financial Data (Unaudited)

[0001564590-17-002423:notes:252]
The following table presents unaudited quarterly operating results for each of our last eight fiscal quarters. This information has been prepared on a basis consistent with our audited financial statements and includes all adjustments, consisting only of normal recurring adjustments, considered necessary for a fair presentation of the data.

[0001564590-17-002423:notes:253]
Unaudited Quarterly Operating Results

[0001564590-17-002423:notes:254]
(In thousands, except for per share amounts)

[0001564590-17-002423:notes:255]
| Three Months Ended |  | March 31, 2016 |  |  | June 30, 2016 |  |  | September 30, 2016 |  |  | December 31, 2016 |  |
| Net sales |  | $ | 142,204 |  |  | $ | 162,701 |  |  | $ | 168,890 |  |  | $ | 162,986 |  |
| Gross profit |  | $ | 65,794 |  |  | $ | 78,955 |  |  | $ | 75,808 |  |  | $ | 70,787 |  |
| Operating income |  | $ | 5,521 |  |  | $ | 14,812 |  |  | $ | 10,130 |  |  | $ | 4,272 |  |
| Net income |  | $ | 5,014 |  |  | $ | 10,228 |  |  | $ | 12,415 |  |  | $ | 7,572 |  |
| Earnings per common share |  | $ | 0.10 |  |  | $ | 0.21 |  |  | $ | 0.26 |  |  | $ | 0.16 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.10 |  |  | $ | 0.21 |  |  | $ | 0.26 |  |  | $ | 0.16 |  |

[0001564590-17-002423:notes:256]
| Three Months Ended |  | March 31, 2015 |  |  | June 30, 2015 |  |  | September 30, 2015 |  |  | December 31, 2015 |  |
| Net sales |  | $ | 142,835 |  |  | $ | 160,138 |  |  | $ | 158,078 |  |  | $ | 139,013 |  |
| Gross profit |  | $ | 65,563 |  |  | $ | 68,246 |  |  | $ | 70,649 |  |  | $ | 62,439 |  |
| Operating income |  | $ | 1,963 |  |  | $ | 644 |  |  | $ | 8,072 |  |  | $ | 2,800 |  |
| Net income |  | $ | 3,317 |  |  | $ | 2,544 |  |  | $ | 7,067 |  |  | $ | 5,718 |  |
| Earnings per common share |  | $ | 0.06 |  |  | $ | 0.05 |  |  | $ | 0.14 |  |  | $ | 0.12 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.06 |  |  | $ | 0.05 |  |  | $ | 0.14 |  |  | $ | 0.12 |  |

[0001564590-17-002423:notes:257]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001564590-17-002423:notes:258]
Note 16 – Related Party Transactions

[0001564590-17-002423:notes:259]
We employed the law firm of our director emeritus for legal services. All bills for services rendered by this firm were reviewed and approved by our Chief Financial Officer. We believe that the fees for such services are comparable to those charged by other firms for services rendered to us. The services of our director emeritus ended with his death on September 7, 2014. For the year ended 2014, we incurred fees of $0.1 million for these legal services.


## us-gaap:SubsequentEventsTextBlock

[0001564590-17-002423:notes:260]
Note 17 – Subsequent Events

[0001564590-17-002423:notes:261]
On January 17, 2017, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on February 2, 2017. The quarterly dividend payment was $4.4 million and was paid on February 16, 2017. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-17-002423:notes:262]
During the first quarter and as of February 24, 2017, we have repurchased 0.2 million shares of our common stock through open market purchases at an average cost of $21.46 per share. We currently have the authority to purchase an additional 4.2 million shares of our common stock under the current plan approved by the Board of Directors.


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001564590-17-002423:notes:263]
SCHEDULE II

[0001564590-17-002423:notes:264]
VALUATION AND QUALIFYING ACCOUNTS

[0001564590-17-002423:notes:265]
| Column A |  | Column B |  |  | Column C |  |  | Column D |  |  | Column E |  |
| (In thousands) |  | Balance at Beginning of Period |  |  | Charged to Costs & Expenses |  |  | Deductions |  |  | Balance at End of Period |  |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 19 |  |  |  | — |  |  |  | 19 |  |  | $ | — |  |
| Inventory Reserve |  | $ | 26,675 |  |  |  | 3,303 |  |  |  | 4,729 |  |  | $ | 25,249 |  |
| Warranty Liability |  | $ | 8,739 |  |  |  | 8,561 |  |  |  | 8,752 |  |  | $ | 8,548 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 7,250 |  |  |  | 69 |  |  |  | 1,170 |  |  | $ | 6,149 |  |
| Year ended December 31, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 136 |  |  |  | 19 |  |  |  | 136 |  |  | $ | 19 |  |
| Inventory Reserve |  | $ | 24,682 |  |  |  | 2,225 |  |  |  | 232 |  |  | $ | 26,675 |  |
| Warranty Liability |  | $ | 8,415 |  |  |  | 2,998 |  |  |  | 2,674 |  |  | $ | 8,739 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 7,463 |  |  |  | 81 |  |  |  | 294 |  |  | $ | 7,250 |  |
| Year ended December 31, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 130 |  |  |  | 23 |  |  |  | 17 |  |  | $ | 136 |  |
| Inventory Reserve |  | $ | 22,993 |  |  |  | 2,549 |  |  |  | 860 |  |  | $ | 24,682 |  |
| Warranty Liability |  | $ | 8,977 |  |  |  | 3,103 |  |  |  | 3,665 |  |  | $ | 8,415 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 8,842 |  |  |  | 283 |  |  |  | 1,662 |  |  | $ | 7,463 |  |
