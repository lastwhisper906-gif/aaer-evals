# ADTN note change history — 0001564590-16-022906 → 0001564590-16-028206


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-08):
[0001564590-16-028206:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2016, of which $7.7 million has been applied to these commitments.
  (was, 2016-08-05, similarity 0.9726):
[0001564590-16-022906:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2016, of which $7.7 million has been applied to these commitments.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-08):
[0001564590-16-028206:note_history:2]
At September 30, 2016, we held the following securities and investments, recorded at either fair value or cost.
  (was, 2016-08-05, similarity 0.9463):
[0001564590-16-022906:note_history:2]
At June 30, 2016, we held the following securities and investments, recorded at either fair value or cost.

- changed (2016-11-08):
[0001564590-16-028206:note_history:3]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,656 |  |  | $ | 2,172 |  |  | $ | (20 | ) |  | $ | 13,808 |  |
| Corporate bonds |  |  | 59,900 |  |  |  | 136 |  |  |  | (50 | ) |  |  | 59,986 |  |
| Municipal fixed-rate bonds |  |  | 17,589 |  |  |  | 54 |  |  |  | (4 | ) |  |  | 17,639 |  |
| Asset-backed bonds |  |  | 22,564 |  |  |  | 72 |  |  |  | (23 | ) |  |  | 22,613 |  |
| Mortgage/Agency-backed bonds |  |  | 15,055 |  |  |  | 24 |  |  |  | (43 | ) |  |  | 15,036 |  |
| U.S. government bonds |  |  | 28,437 |  |  |  | 168 |  |  |  | - |  |  |  | 28,605 |  |
| Foreign government bonds |  |  | 6,428 |  |  |  | 3 |  |  |  | (1 | ) |  |  | 6,430 |  |
| Variable rate demand notes |  |  | 12,315 |  |  |  | - |  |  |  | - |  |  |  | 12,315 |  |
| Marketable equity securities |  |  | 26,975 |  |  |  | 1,468 |  |  |  | (1,076 | ) |  |  | 27,367 |  |
| Available-for-sale securities held at fair value |  | $ | 200,919 |  |  | $ | 4,097 |  |  | $ | (1,217 | ) |  | $ | 203,799 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 28,900 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,196 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 233,895 |  |
  (was, 2016-08-05, similarity 0.9625):
[0001564590-16-022906:note_history:3]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,516 |  |  | $ | 1,628 |  |  | $ | (49 | ) |  | $ | 13,095 |  |
| Corporate bonds |  |  | 54,044 |  |  |  | 149 |  |  |  | (61 | ) |  |  | 54,132 |  |
| Municipal fixed-rate bonds |  |  | 16,889 |  |  |  | 59 |  |  |  | - |  |  |  | 16,948 |  |
| Asset-backed bonds |  |  | 23,526 |  |  |  | 53 |  |  |  | (6 | ) |  |  | 23,573 |  |
| Mortgage/Agency-backed bonds |  |  | 19,214 |  |  |  | 44 |  |  |  | (39 | ) |  |  | 19,219 |  |
| U.S. Government bonds |  |  | 33,498 |  |  |  | 308 |  |  |  | - |  |  |  | 33,806 |  |
| Variable rate demand notes |  |  | 11,740 |  |  |  | - |  |  |  | - |  |  |  | 11,740 |  |
| Marketable equity securities |  |  | 32,948 |  |  |  | 1,901 |  |  |  | (1,478 | ) |  |  | 33,371 |  |
| Available-for-sale securities held at fair value |  | $ | 203,375 |  |  | $ | 4,142 |  |  | $ | (1,633 | ) |  | $ | 205,884 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,232 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 237,116 |  |

- changed (2016-11-08):
[0001564590-16-028206:note_history:4]
As of September 30, 2016, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds had the following contractual maturities:
  (was, 2016-08-05, similarity 0.8855):
[0001564590-16-022906:note_history:4]
As of June 30, 2016, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, and U.S. government bonds had the following contractual maturities:

- changed (2016-11-08):
[0001564590-16-028206:note_history:5]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 22,993 |  |  | $ | 12,156 |  |  | $ | - |  |  | $ | - |  |  | $ | 2,952 |  |  | $ | 5,100 |  |
| One to two years |  |  | 24,504 |  |  |  | 3,186 |  |  |  | 1,094 |  |  |  | 1,385 |  |  |  | 9,096 |  |  |  | 1,330 |  |
| Two to three years |  |  | 9,296 |  |  |  | 858 |  |  |  | 8,989 |  |  |  | 2,004 |  |  |  | 4,573 |  |  |  | - |  |
| Three to five years |  |  | 3,193 |  |  |  | 1,439 |  |  |  | 9,739 |  |  |  | - |  |  |  | 11,984 |  |  |  | - |  |
| Five to ten years |  |  | - |  |  |  | - |  |  |  | 2,614 |  |  |  | 1,448 |  |  |  | - |  |  |  | - |  |
| More than ten years |  |  | - |  |  |  | - |  |  |  | 177 |  |  |  | 10,199 |  |  |  | - |  |  |  | - |  |
| Total |  | $ | 59,986 |  |  | $ | 17,639 |  |  | $ | 22,613 |  |  | $ | 15,036 |  |  | $ | 28,605 |  |  | $ | 6,430 |  |
  (was, 2016-08-05, similarity 0.9285):
[0001564590-16-022906:note_history:5]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. Government bonds |  |
| Less than one year |  | $ | 20,729 |  |  | $ | 10,473 |  |  | $ | - |  |  | $ | 4,972 |  |  | $ | 2,953 |  |
| One to two years |  |  | 24,884 |  |  |  | 4,488 |  |  |  | 822 |  |  |  | 2,569 |  |  |  | 7,481 |  |
| Two to three years |  |  | 6,099 |  |  |  | 1,536 |  |  |  | 9,077 |  |  |  | 2,058 |  |  |  | 11,344 |  |
| Three to five years |  |  | 2,420 |  |  |  | 451 |  |  |  | 10,991 |  |  |  | - |  |  |  | 12,028 |  |
| Five to ten years |  |  | - |  |  |  | - |  |  |  | 2,506 |  |  |  | 1,036 |  |  |  | - |  |
| More than ten years |  |  | - |  |  |  | - |  |  |  | 177 |  |  |  | 8,584 |  |  |  | - |  |
| Total |  | $ | 54,132 |  |  | $ | 16,948 |  |  | $ | 23,573 |  |  | $ | 19,219 |  |  | $ | 33,806 |  |

- changed (2016-11-08):
[0001564590-16-028206:note_history:6]
At September 30, 2016, we held a $28.9 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $28.9 million at September 30, 2016 and December 31, 2015. At September 30, 2016, the estimated fair value of the Bond using a level 2 valuation technique was approximately $29.3 million, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.
  (was, 2016-08-05, similarity 0.9653):
[0001564590-16-022906:note_history:6]
At June 30, 2016, we held a $30.0 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $28.9 million at June 30, 2016 and December 31, 2015. At June 30, 2016, the estimated fair value of the Bond using a level 2 valuation technique was approximately $29.4 million, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

- changed (2016-11-08):
[0001564590-16-028206:note_history:7]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and nine months ended September 30, 2016, other-than-temporary impairment charges were not significant.
  (was, 2016-08-05, similarity 0.9764):
[0001564590-16-022906:note_history:7]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and six months ended June 30, 2016 and 2015, other-than-temporary impairment charges were not significant.

- changed (2016-11-08):
[0001564590-16-028206:note_history:8]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Gross realized gains |  | $ | 1,346 |  |  | $ | 2,251 |  |  | $ | 5,226 |  |  | $ | 8,856 |  |
| Gross realized losses |  | $ | (30 | ) |  | $ | (191 | ) |  | $ | (1,072 | ) |  | $ | (426 | ) |
  (was, 2016-08-05, similarity 0.86):
[0001564590-16-022906:note_history:8]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Gross realized gains |  | $ | 1,517 |  |  | $ | 3,459 |  |  | $ | 3,881 |  |  | $ | 6,604 |  |
| Gross realized losses |  | $ | (407 | ) |  | $ | (204 | ) |  | $ | (1,043 | ) |  | $ | (234 | ) |

- changed (2016-11-08):
[0001564590-16-028206:note_history:9]
As of September 30, 2016 and 2015, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.
  (was, 2016-08-05, similarity 0.9644):
[0001564590-16-022906:note_history:9]
As of June 30, 2016 and 2015, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.

- changed (2016-11-08):
[0001564590-16-028206:note_history:10]
|  |  | Fair Value Measurements at September 30, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,032 |  |  | $ | 2,032 |  |  | $ | - |  |  | $ | - |  |
| Commercial Paper |  |  | 3,585 |  |  |  | - |  |  |  | 3,585 |  |  |  | - |  |
| Cash equivalents |  |  | 5,617 |  |  |  | 2,032 |  |  |  | 3,585 |  |  |  | - |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,808 |  |  |  | 13,808 |  |  |  | - |  |  |  | - |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 59,986 |  |  |  | - |  |  |  | 59,986 |  |  |  | - |  |
| Municipal fixed-rate bonds |  |  | 17,639 |  |  |  | - |  |  |  | 17,639 |  |  |  | - |  |
| Asset-backed bonds |  |  | 22,613 |  |  |  | - |  |  |  | 22,613 |  |  |  | - |  |
| Mortgage/Agency-backed bonds |  |  | 15,036 |  |  |  | - |  |  |  | 15,036 |  |  |  | - |  |
| U.S. government bonds |  |  | 28,605 |  |  |  | 28,605 |  |  |  | - |  |  |  | - |  |
| Foreign government bonds |  |  | 6,430 |  |  |  | - |  |  |  | 6,430 |  |  |  | - |  |
| Variable rate demand notes |  |  | 12,315 |  |  |  | - |  |  |  | 12,315 |  |  |  | - |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 3,693 |  |  |  | 3,693 |  |  |  | - |  |  |  | - |  |
| Marketable equity securities – other |  |  | 23,674 |  |  |  | 23,674 |  |  |  | - |  |  |  | - |  |
| Available-for-sale securities |  |  | 203,799 |  |  |  | 69,780 |  |  |  | 134,019 |  |  |  | - |  |
| Total |  | $ | 209,416 |  |  | $ | 71,812 |  |  | $ | 137,604 |  |  | $ | - |  |
  (was, 2016-08-05, similarity 0.9735):
[0001564590-16-022906:note_history:10]
|  |  | Fair Value Measurements at June 30, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,915 |  |  | $ | 1,915 |  |  | $ | - |  |  | $ | - |  |
| Commercial Paper |  |  | 15,996 |  |  |  | - |  |  |  | 15,996 |  |  |  | - |  |
| Cash equivalents |  |  | 17,911 |  |  |  | 1,915 |  |  |  | 15,996 |  |  |  | - |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,095 |  |  |  | 13,095 |  |  |  | - |  |  |  | - |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 54,132 |  |  |  | - |  |  |  | 54,132 |  |  |  | - |  |
| Municipal fixed-rate bonds |  |  | 16,948 |  |  |  | - |  |  |  | 16,948 |  |  |  | - |  |
| Asset-backed bonds |  |  | 23,573 |  |  |  | - |  |  |  | 23,573 |  |  |  | - |  |
| Mortgage/Agency-backed bonds |  |  | 19,219 |  |  |  | - |  |  |  | 19,219 |  |  |  | - |  |
| U.S. Government bonds |  |  | 33,806 |  |  |  | 33,806 |  |  |  | - |  |  |  | - |  |
| Variable rate demand notes |  |  | 11,740 |  |  |  | - |  |  |  | 11,740 |  |  |  | - |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 4,386 |  |  |  | 4,386 |  |  |  | - |  |  |  | - |  |
| Marketable equity securities – other |  |  | 28,985 |  |  |  | 28,985 |  |  |  | - |  |  |  | - |  |
| Available-for-sale securities |  |  | 205,884 |  |  |  | 80,272 |  |  |  | 125,612 |  |  |  | - |  |
| Total |  | $ | 223,795 |  |  | $ | 82,187 |  |  | $ | 141,608 |  |  | $ | - |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2016-11-08):
[0001564590-16-028206:note_history:11]
On October 18, 2016, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on November 03, 2016. The payment date will be November 17, 2016. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

- changed (2016-11-08):
[0001564590-16-028206:note_history:12]
During the fourth quarter and as of November 8, 2016, we have repurchased 0.2 million shares of our common stock through open market purchases at an average cost of $17.96 per share. We currently have the authority to purchase an additional 4.4 million shares of our common stock under the current plan approved by the Board of Directors.
  (was, 2016-08-05, similarity 0.9614):
[0001564590-16-022906:note_history:12]
During the third quarter and as of August 5, 2016, we have repurchased 0.3 million shares of our common stock through open market purchases at an average cost of $17.99 per share. We currently have the authority to purchase an additional 4.6 million shares of our common stock under the current plan approved by the Board of Directors.

- removed (2016-11-08):
[0001564590-16-022906:note_history:13]
On July 12, 2016, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on July 28, 2016. The payment date will be August 11, 2016. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
