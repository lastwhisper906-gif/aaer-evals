# ADTN note change history — 0000950170-22-008077 → 0000950170-22-015058


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0000950170-22-015058:note_history:1]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.
  (was, 2022-05-06, similarity 0.7815):
[0000950170-22-008077:note_history:1]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2022-08-05):
[0000950170-22-015058:note_history:2]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2022 and December 31, 2021, we had commitments related to these bonds totaling $21.8 million and $22.9 million, respectively, which expire at various dates through April 2025. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2022-05-06, similarity 0.9913):
[0000950170-22-008077:note_history:2]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2022 and December 31, 2021, we had commitments related to these bonds totaling $20.9 million and $22.9 million, respectively, which expire at various dates through April 2025. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- added (2022-08-05):
[0000950170-22-015058:note_history:3]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. In conjunction with the Company entering into the revolving credit facility with Wells Fargo during the three months ended June 30, 2022, our obligation to maintain the pledged collateral was released.  This pledged collateral value fluctuated as the Company changed the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value was required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. For additional information on the Wells Fargo revolving credit facility see Note 12 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

- changed (2022-08-05):
[0000950170-22-015058:note_history:4]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of June 30, 2022.
  (was, 2022-05-06, similarity 0.9677):
[0000950170-22-008077:note_history:4]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of March 31, 2022.

- removed (2022-08-05):
[0000950170-22-008077:note_history:5]
Business Combination Agreement

- removed (2022-08-05):
[0000950170-22-008077:note_history:6]
On August 30, 2021, the Company and ADVA, entered into a business combination agreement (the “Business Combination Agreement”), pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, Acorn HoldCo, a Delaware corporation and currently a wholly-owned direct subsidiary of the Company.

- removed (2022-08-05):
[0000950170-22-008077:note_history:7]
Under the terms of the Business Combination Agreement, Acorn MergeCo, Inc., a newly formed Delaware corporation and wholly-owned direct subsidiary of Acorn HoldCo (“Merger Sub”), will merge with and into ADTRAN, with ADTRAN surviving the merger (the “Merger”) as a wholly-owned direct subsidiary of Acorn HoldCo. Pursuant to the Merger, each outstanding share of common stock of the Company will be converted into the right to receive one share of common stock of Acorn HoldCo. Acorn HoldCo has also made a public exchange offer to exchange each issued and outstanding no-par value bearer share of ADVA, pursuant to which each ADVA share tendered and accepted for exchange will be exchanged for 0.8244 shares of common stock of Acorn HoldCo (the “Exchange Offer”, and together with the Merger, the “Business Combination”). Upon completion of the Business Combination, and assuming that all of the outstanding ADVA shares are exchanged in the Exchange Offer, former ADTRAN stockholders and former ADVA shareholders will own approximately 54% and 46%, respectively, of the outstanding Acorn HoldCo shares.

- removed (2022-08-05):
[0000950170-22-008077:note_history:8]
The Business Combination Agreement was unanimously approved by the Board of Directors of the Company and by the supervisory board and management board of ADVA. On January 6, 2022, the Company's stockholders approved the Business Combination by an overwhelming majority. The end of the ADVA shareholder tender offer acceptance period was on January 26, 2022, which resulted in the acceptance of the Exchange Offer by more than 60% of all shares of ADVA entitled to voting rights existing as of October 31, 2021, thus exceeding the required minimum acceptance threshold. According to the rules of the German Securities Acquisition and Takeover Act, ADVA shareholders who did not tender their shares during the initial acceptance period could do so during a two-week additional acceptance period that began on February 1, 2022 and ended February 14, 2022. This resulted in the acceptance of the Exchange Offer by approximately 66% of all shares of ADVA entitled to voting rights existing as of November 30, 2021. On January 24, 2022, the Committee on Foreign Investment in the U.S. ("CFIUS") completed its review of the Business Combination and determined that the transaction was not a “covered transaction” subject to CFIUS’ jurisdiction, satisfying the condition of the Business Combination Agreement related to CFIUS notification. On February 16, 2022, the U.K. Secretary of State for Business, Energy and Industrial Strategy completed its review of the Business Combination and determined that the Secretary of State will be taking no further action under the NS&I Act, satisfying the condition of the Business Combination Agreement related to NS&I Act approval. Cooperative proceedings continue with the foreign direct investment authorities in Germany.

- removed (2022-08-05):
[0000950170-22-008077:note_history:9]
The Company anticipates the consummation of the Business Combination around the middle of 2022, subject to customary closing conditions, and regulatory approvals from the foreign direct investment authorities in Germany.

- removed (2022-08-05):
[0000950170-22-008077:note_history:10]
Additional information about the Business Combination Agreement and proposed Business Combination is set forth in the Company’s filings with the SEC, as well as in the registration statement on Form S-4 that Acorn HoldCo filed with the SEC, which was declared effective December 2, 2021 (the “Acorn HoldCo Registration Statement”).

- removed (2022-08-05):
[0000950170-22-008077:note_history:11]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.0 million as of March 31, 2022, of which $0.1 million is included in restricted cash and $17.9 million is included in long-term investments on the Condensed Consolidated Balance Sheets. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of March 31, 2022, the Company believes it was in compliance with all contractual requirements under the letter of credit.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-08-05):
[0000950170-22-015058:note_history:12]
On July 8, 2022, Acorn MergeCo, Inc. (“Merger Sub”), a Delaware corporation and wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (formerly known as Acorn HoldCo), merged with and into ADTRAN, Inc., with ADTRAN, Inc. surviving the merger as a wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (the “Merger”).  The Merger was consummated pursuant to the Business Combination Agreement, dated as of August 30, 2021 (the “Business Combination Agreement”), by and among ADTRAN Holdings, Inc., ADTRAN, Inc., ADVA Optical Networking SE, a company organized and existing under the laws of Germany (“ADVA”), and Merger Sub.  In accordance with the Business Combination Agreement, ADTRAN Holdings, Inc. made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of common stock, par value $0.01 per share (the “Company Common Stock”), of ADTRAN Holdings, Inc. (the “Exchange Offer” and, together with the Merger, the “Business Combination”).  On July 15, 2022 (the “Exchange Offer Settlement Date”), ADTRAN Holdings, Inc. completed the Exchange Offer, in which ADTRAN Holdings, Inc. acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of common stock of ADTRAN Holdings, Inc.

- added (2022-08-05):
[0000950170-22-015058:note_history:13]
Except as otherwise indicated, references in these notes to “ADTRAN,” the “Company,” “we,” “us” and “our” for time periods at and before the effectiveness of the Merger, including all fiscal periods ended on or prior to June 30, 2022, shall be deemed to refer to ADTRAN, Inc. as the predecessor registrant to ADTRAN Holdings, Inc.

- changed (2022-08-05):
[0000950170-22-015058:note_history:14]
The accompanying unaudited condensed consolidated financial statements of ADTRAN and its subsidiaries have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. Certain prior year amounts have been reclassified to conform to the current period presentation. The December 31, 2021 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.
  (was, 2022-05-06, similarity 0.9656):
[0000950170-22-008077:note_history:14]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. Certain prior year amounts have been reclassified to conform to the current period presentation. The December 31, 2021 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

- changed (2022-08-05):
[0000950170-22-015058:note_history:15]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN, Inc. Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022.
  (was, 2022-05-06, similarity 0.9922):
[0000950170-22-008077:note_history:15]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022.

- changed (2022-08-05):
[0000950170-22-015058:note_history:16]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus) as well as supply chain constraints as of June 30, 2022 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints, could result in further impacts to our consolidated financial statements in future reporting periods.
  (was, 2022-05-06, similarity 0.9951):
[0000950170-22-008077:note_history:16]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus) as well as supply chain constraints as of March 31, 2022 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints, could result in further impacts to our consolidated financial statements in future reporting periods.

- changed (2022-08-05):
[0000950170-22-015058:note_history:17]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. ASU 2021-08 is effective for annual periods beginning after December 15, 2022, including interim periods within those fiscal years. Adoption of the ASU should be applied prospectively. Early adoption is also permitted, including adoption in an interim period. If early adopted, the amendments are applied retrospectively to all business combinations for which the acquisition date occurred during the fiscal year of adoption. Given that the Business Combination with ADVA was finalized in July 2022, the Company plans to early adopt ASU 2021-08 during the third quarter of 2022. ASU 2021-08 will be effective as of January 1, 2022 and will be applied on a prospective basis. However, we are unable to estimate the effect on our Condensed Consolidated Financial Statements as of the date of this report.
  (was, 2022-05-06, similarity 0.7938):
[0000950170-22-008077:note_history:17]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. ASU 2021-08 is effective for annual periods beginning after December 15, 2022, including interim periods within those fiscal years. Adoption of the ASU should be applied prospectively. Early adoption is also permitted, including adoption in an interim period. If early adopted, the amendments are applied retrospectively to all business combinations for which the acquisition date occurred during the fiscal year of adoption. The Company plans to early adopt ASU 2021-08 in the event that the Business Combination Agreement with ADVA closes during 2022. However, we are unable to estimate the effect on our Condensed Consolidated Financial Statements as of the date of this report.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0000950170-22-015058:note_history:18]
12. REVOLVING CREDIT AGREEMENTS
  (was, 2022-05-06, similarity 0.8615):
[0000950170-22-008077:note_history:18]
12. CADENCE REVOLVING CREDIT AGREEMENT

- added (2022-08-05):
[0000950170-22-015058:note_history:19]
Cadence Revolving Credit Agreement

- changed (2022-08-05):
[0000950170-22-015058:note_history:20]
On May 19, 2022, the Company, as borrower, modified its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The modified Cadence Revolving Credit Agreement provides the Company with a $25.0 million secured revolving credit facility. Loans under the Cadence Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Cadence Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Cadence Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Cadence Revolving Credit Agreement, at a maximum loan-to-value ratio of 85% determined by dividing the full commitment amount under the Cadence Revolving Credit Agreement on the date of testing, determined by the Cadence Lender each fiscal quarter, by the market value of the collateral. The Cadence Revolving Credit Agreement matures on November 3, 2022, subject to earlier termination upon the concurrence of certain events of default. The Company entered into the Cadence Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. During the first half of 2022, the Company made draws totaling $18.0 million under the Cadence Revolving Credit Agreement all of which had been repaid as of June 30, 2022. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company. As of June 30, 2022, the Company was in compliance with all contractual requirements under the Cadence Revolving Credit Agreement.
  (was, 2022-05-06, similarity 0.9859):
[0000950170-22-008077:note_history:20]
On November 2, 2021, the Company, as borrower, renewed its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The Cadence Revolving Credit Agreement provides the Company with a $10.0 million secured revolving credit facility. Loans under the Cadence Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Cadence Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Cadence Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Cadence Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Cadence Revolving Credit Agreement on the date of testing, determined by the Cadence Lender each fiscal quarter, by the market value of the collateral. The Cadence Revolving Credit Agreement matures on November 3, 2022, subject to earlier termination upon the concurrence of certain events of default. The Company entered into the Cadence Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. During the first quarter of 2022, the Company made draws totaling $8.0 million under the Cadence Revolving Credit Agreement all of which had been repaid as of March 31, 2022. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company. As of March 31, 2022, the Company was in compliance with all contractual requirements under the Cadence Revolving Credit Agreement.

- added (2022-08-05):
[0000950170-22-015058:note_history:21]
Wells Fargo Revolving Credit Agreement

- added (2022-08-05):
[0000950170-22-015058:note_history:22]
On April 1, 2022, the Company entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provides the Company with a new $25.0 million secured revolving credit facility. The Wells Revolving Credit Agreement matures on April 1, 2023, subject to earlier termination upon the occurrence of certain events of default as set forth in the Wells Revolving Credit Agreement. Loans under the Wells Revolving Credit Agreement will bear interest at a fluctuating rate per annum equal to: (i) the Daily Simple SOFR (as defined herein) plus (ii) an applicable margin, which will equal 1.00%, 1.25%, 1.5% or 2.0% per annum depending on the Company’s senior funded debt to EBITDA ratio. The “Daily Simple SOFR” is calculated based upon the greater of (x) a floor of 0.00% and (b) the Secured Overnight Financing Rate, as established by the Federal Reserve Bank of New York (or a successor thereto) from time to time. Accrued interest is payable on the last day of each quarter, commencing June 30, 2022. Borrowings under the Wells Revolving Credit Agreement may be used solely for issuing letters of credit, financing capital expenditures, and working capital and general corporate purposes. Loans under the Wells Revolving Credit Agreement are secured by a first priority security interest in all of the accounts receivable of the Company and its subsidiary, ADTRAN International, Inc. Specifically, in connection with the Wells Revolving Credit Agreement, the Company entered into a security agreement, dated April 1, 2022, pursuant to which the Company pledged to the Wells Lender all of the rights to payment, accounts, deposit accounts, chattel paper (whether electronic or tangible), instruments, promissory notes, documents, licenses, general intangibles, payment intangibles, software, letter of credit rights and healthcare insurance receivables existing as of the date of execution or arising at any time thereafter.  During the first half of 2022, the Company made draws totaling $10.0 million under the Wells Revolving Credit Agreement all of which had been repaid as of June 30, 2022. As of June 30, 2022, the Company was in compliance with all contractual requirements under the Wells Fargo Credit Agreement.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0000950170-22-015058:note_history:23]
|  |  | As of June 30, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,854 |  |  | $ | 1 |  |  | $ | (286 | ) |  | $ | 10,569 |  |
| Municipal fixed-rate bonds |  |  | 1,563 |  |  |  | — |  |  |  | (49 | ) |  |  | 1,514 |  |
| Asset-backed bonds |  |  | 1,018 |  |  |  | 1 |  |  |  | (16 | ) |  |  | 1,003 |  |
| Mortgage/Agency-backed bonds |  |  | 4,199 |  |  |  | — |  |  |  | (185 | ) |  |  | 4,014 |  |
| U.S. government bonds |  |  | 12,287 |  |  |  | — |  |  |  | (503 | ) |  |  | 11,784 |  |
| Foreign government bonds |  |  | 410 |  |  |  | — |  |  |  | (22 | ) |  |  | 388 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,331 |  |  | $ | 2 |  |  | $ | (1,061 | ) |  | $ | 29,272 |  |
  (was, 2022-05-06, similarity 0.9905):
[0000950170-22-008077:note_history:23]
|  |  | As of March 31, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,299 |  |  | $ | 1 |  |  | $ | (206 | ) |  | $ | 9,094 |  |
| Municipal fixed-rate bonds |  |  | 1,684 |  |  |  | — |  |  |  | (37 | ) |  |  | 1,647 |  |
| Asset-backed bonds |  |  | 318 |  |  |  | — |  |  |  | (11 | ) |  |  | 307 |  |
| Mortgage/Agency-backed bonds |  |  | 4,703 |  |  |  | 1 |  |  |  | (142 | ) |  |  | 4,562 |  |
| U.S. government bonds |  |  | 14,000 |  |  |  | — |  |  |  | (446 | ) |  |  | 13,554 |  |
| Foreign government bonds |  |  | 411 |  |  |  | — |  |  |  | (17 | ) |  |  | 394 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,415 |  |  | $ | 2 |  |  | $ | (859 | ) |  | $ | 29,558 |  |

- changed (2022-08-05):
[0000950170-22-015058:note_history:24]
|  |  | As of June 30, 2022 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 621 |  |  | $ | 148 |  |  | $ | — |  |  | $ | 637 |  |  | $ | 367 |  |  | $ | — |  |  |
| One to two years |  |  | 6,484 |  |  |  | 1,254 |  |  |  | — |  |  |  | 472 |  |  |  | 8,315 |  |  |  | 279 |  |  |
| Two to three years |  |  | 3,339 |  |  |  | 112 |  |  |  | 248 |  |  |  | 621 |  |  |  | 3,102 |  |  |  | 109 |  |  |
| Three to five years |  |  | 125 |  |  |  | — |  |  |  | 313 |  |  |  | 189 |  |  |  | — |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 215 |  |  |  | 925 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 227 |  |  |  | 1,170 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 10,569 |  |  | $ | 1,514 |  |  | $ | 1,003 |  |  | $ | 4,014 |  |  | $ | 11,784 |  |  | $ | 388 |  |  |
  (was, 2022-05-06, similarity 0.9897):
[0000950170-22-008077:note_history:24]
|  |  | As of March 31, 2022 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 295 |  |  | $ | 269 |  |  | $ | — |  |  | $ | 1,050 |  |  | $ | 979 |  |  | $ | — |  |  |
| One to two years |  |  | 5,965 |  |  |  | 1,265 |  |  |  | — |  |  |  | 479 |  |  |  | 4,800 |  |  |  | — |  |  |
| Two to three years |  |  | 2,596 |  |  |  | 113 |  |  |  | — |  |  |  | 289 |  |  |  | 7,106 |  |  |  | 394 |  |  |
| Three to five years |  |  | 238 |  |  |  | — |  |  |  | 49 |  |  |  | 371 |  |  |  | 669 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 915 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 258 |  |  |  | 1,458 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 9,094 |  |  | $ | 1,647 |  |  | $ | 307 |  |  | $ | 4,562 |  |  | $ | 13,554 |  |  | $ | 394 |  |  |

- added (2022-08-05):
[0000950170-22-015058:note_history:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | 97 |  |  | $ | 12 |  |  | $ | 184 |  |
| Gross realized loss on debt securities |  |  | (85 | ) |  |  | (20 | ) |  |  | (125 | ) |  |  | (36 | ) |
| Total (loss) gain recognized, net |  | $ | (85 | ) |  | $ | 77 |  |  | $ | (113 | ) |  | $ | 148 |  |

- changed (2022-08-05):
[0000950170-22-015058:note_history:26]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income. No allowance for credit losses was recorded for the six months ended June 30, 2022 and 2021 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the six months ended June 30, 2022.
  (was, 2022-05-06, similarity 0.9236):
[0000950170-22-008077:note_history:26]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. No allowance for credit losses was recorded for the three months ended March 31, 2022 and 2021 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2022.

- changed (2022-08-05):
[0000950170-22-015058:note_history:27]
The Company has an equity investment which does not have a readily determinable fair value and is recorded using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of the equity investment as of June 30, 2022 and December 31, 2021 was $1.0 million. During the year ended December 31, 2021, impairment charges totaling $0.4 million, were recorded related to the equity investment. As of June 30 2022, cumulative impairment charges totaling $2.4 million were recorded related to the equity investment. There were no impairment charges during the three and six months ended June 30, 2022 and 2021. During the year ended December 31, 2021, an unsecured loan totaling $0.5 million was converted to equity which increased the Company's carrying value of the equity investment.
  (was, 2022-05-06, similarity 0.9675):
[0000950170-22-008077:note_history:27]
The Company has an equity investment which does not have a readily determinable fair value, and is recorded using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of the equity investment as of March 31, 2022 and December 31, 2021 was $1.0 million. During the year ended December 31, 2021, impairment charges totaling $0.4 million, were recorded related to the equity investment. As of March 31 2022, cumulative impairment charges totaling $2.4 million were recorded related to the equity investment. There were no impairment charges during the three months ended March 31, 2022 and 2021. During the year ended December 31, 2021, an unsecured loan totaling $0.5 million was converted to equity which increased the Company's carrying value of the equity investment.

- changed (2022-08-05):
[0000950170-22-015058:note_history:28]
The Company has a secured note receivable as of June 30, 2022 and December 31, 2021 which totaled $0.4 million and is included in long term investments on the Consolidated Balance Sheets. During the year ended December 31, 2021, an impairment charge of $0.5 million was recognized against the secured note receivable. There were no impairment charges during the three and six months ended June 30, 2022 and 2021.
  (was, 2022-05-06, similarity 0.9053):
[0000950170-22-008077:note_history:28]
The Company has a secured note receivable as of March 31, 2022 and December 31, 2021 which totaled $0.4 million and is included in long term investments on the Consolidated Balance Sheets. During the year ended December 31, 2021, an impairment charge of $0.5 million was recognized against the secured note receivable. There were no impairment charges during the three months ended March 31, 2022 and 2021.

- added (2022-08-05):
[0000950170-22-015058:note_history:29]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Realized (loss) gain on equity securities sold |  | $ | (293 | ) |  | $ | (79 | ) |  | $ | (318 | ) |  | $ | (55 | ) |
| Unrealized (loss) gain on equity securities held |  |  | (4,268 | ) |  |  | 2,011 |  |  |  | (7,630 | ) |  |  | 2,912 |  |
| Total (loss) gain recognized, net |  | $ | (4,561 | ) |  | $ | 1,932 |  |  | $ | (7,948 | ) |  | $ | 2,857 |  |

- changed (2022-08-05):
[0000950170-22-015058:note_history:30]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:
  (was, 2022-05-06, similarity 0.9885):
[0000950170-22-008077:note_history:30]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

- changed (2022-08-05):
[0000950170-22-015058:note_history:31]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 409 |  |  | $ | 409 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,569 |  |  |  | — |  |  |  | 10,569 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,514 |  |  |  | — |  |  |  | 1,514 |  |  |  | — |  |
| Asset-backed bonds |  |  | 1,003 |  |  |  | — |  |  |  | 1,003 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,014 |  |  |  | — |  |  |  | 4,014 |  |  |  | — |  |
| U.S. government bonds |  |  | 11,784 |  |  |  | 11,784 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 388 |  |  |  | — |  |  |  | 388 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 873 |  |  |  | 873 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,567 |  |  |  | 22,567 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 53,121 |  |  | $ | 35,633 |  |  | $ | 17,488 |  |  | $ | — |  |
  (was, 2022-05-06, similarity 0.9942):
[0000950170-22-008077:note_history:31]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 457 |  |  | $ | 457 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,094 |  |  |  | — |  |  |  | 9,094 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,647 |  |  |  | — |  |  |  | 1,647 |  |  |  | — |  |
| Asset-backed bonds |  |  | 307 |  |  |  | — |  |  |  | 307 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,562 |  |  |  | — |  |  |  | 4,562 |  |  |  | — |  |
| U.S. government bonds |  |  | 13,554 |  |  |  | 13,554 |  |  |  |  |  |  | — |  |
| Foreign government securities |  |  | 394 |  |  |  | — |  |  |  | 394 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 11,143 |  |  |  | 11,143 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,081 |  |  |  | 26,081 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 67,239 |  |  | $ | 51,235 |  |  | $ | 16,004 |  |  | $ | — |  |

- removed (2022-08-05):
[0000950170-22-008077:note_history:32]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Gross realized gain on debt securities |  | $ | 12 |  |  | $ | 87 |  |
| Gross realized loss on debt securities |  |  | (40 | ) |  |  | (16 | ) |
| Total (loss) gain recognized, net |  | $ | (28 | ) |  | $ | 71 |  |

- removed (2022-08-05):
[0000950170-22-008077:note_history:33]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Realized (loss) gain on equity securities sold |  | $ | (25 | ) |  | $ | 24 |  |
| Unrealized (loss) gain on equity securities held |  |  | (3,362 | ) |  |  | 901 |  |
| Total (loss) gain recognized, net |  | $ | (3,387 | ) |  | $ | 925 |  |

- removed (2022-08-05):
[0000950170-22-008077:note_history:34]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consists of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-08-05):
[0000950170-22-015058:note_history:35]
The following tables disaggregate revenue by reportable segment and revenue category:

- changed (2022-08-05):
[0000950170-22-015058:note_history:36]
|  |  | Three Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 78,852 |  |  | $ | 10,909 |  |  | $ | 89,761 |  |  | $ | 78,307 |  |  | $ | 12,657 |  |  | $ | 90,964 |  |
| Subscriber Solutions & Experience |  |  | 75,186 |  |  |  | 2,958 |  |  |  | 78,144 |  |  |  | 45,097 |  |  |  | 2,713 |  |  |  | 47,810 |  |
| Traditional & Other Products |  |  | 1,954 |  |  |  | 2,179 |  |  |  | 4,133 |  |  |  | 2,045 |  |  |  | 2,413 |  |  |  | 4,458 |  |
| Total |  | $ | 155,992 |  |  | $ | 16,046 |  |  | $ | 172,038 |  |  | $ | 125,449 |  |  | $ | 17,783 |  |  | $ | 143,232 |  |
  (was, 2022-05-06, similarity 0.6156):
[0000950170-22-008077:note_history:36]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Access & Aggregation |  | $ | 95,460 |  |  | $ | 69,074 |  |
| Subscriber Solutions & Experience |  |  | 54,606 |  |  |  | 54,569 |  |
| Traditional & Other Products |  |  | 4,452 |  |  |  | 3,890 |  |
| Total |  | $ | 154,518 |  |  | $ | 127,533 |  |

- added (2022-08-05):
[0000950170-22-015058:note_history:37]
|  |  | Six Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 163,141 |  |  | $ | 22,080 |  |  | $ | 185,221 |  |  | $ | 138,360 |  |  | $ | 21,678 |  |  | $ | 160,038 |  |
| Subscriber Solutions & Experience |  |  | 127,009 |  |  |  | 5,741 |  |  |  | 132,750 |  |  |  | 97,366 |  |  |  | 5,013 |  |  |  | 102,379 |  |
| Traditional & Other Products |  |  | 4,216 |  |  |  | 4,369 |  |  |  | 8,585 |  |  |  | 3,532 |  |  |  | 4,816 |  |  |  | 8,348 |  |
| Total |  | $ | 294,366 |  |  | $ | 32,190 |  |  | $ | 326,556 |  |  | $ | 239,258 |  |  | $ | 31,507 |  |  | $ | 270,765 |  |

- added (2022-08-05):
[0000950170-22-015058:note_history:38]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Access & Aggregation |  | $ | 89,761 |  |  | $ | 90,964 |  |  | $ | 185,221 |  |  | $ | 160,038 |  |
| Subscriber Solutions & Experience |  |  | 78,144 |  |  |  | 47,810 |  |  |  | 132,750 |  |  |  | 102,379 |  |
| Traditional & Other Products |  |  | 4,133 |  |  |  | 4,458 |  |  |  | 8,585 |  |  |  | 8,348 |  |
| Total |  | $ | 172,038 |  |  | $ | 143,232 |  |  | $ | 326,556 |  |  | $ | 270,765 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0000950170-22-015058:note_history:39]
|  |  | Three Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 78,852 |  |  | $ | 10,909 |  |  | $ | 89,761 |  |  | $ | 78,307 |  |  | $ | 12,657 |  |  | $ | 90,964 |  |
| Subscriber Solutions & Experience |  |  | 75,186 |  |  |  | 2,958 |  |  |  | 78,144 |  |  |  | 45,097 |  |  |  | 2,713 |  |  |  | 47,810 |  |
| Traditional & Other Products |  |  | 1,954 |  |  |  | 2,179 |  |  |  | 4,133 |  |  |  | 2,045 |  |  |  | 2,413 |  |  |  | 4,458 |  |
| Total |  | $ | 155,992 |  |  | $ | 16,046 |  |  | $ | 172,038 |  |  | $ | 125,449 |  |  | $ | 17,783 |  |  | $ | 143,232 |  |
  (was, 2022-05-06, similarity 0.9652):
[0000950170-22-008077:note_history:39]
|  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 84,289 |  |  | $ | 11,171 |  |  | $ | 95,460 |  |  | $ | 60,053 |  |  | $ | 9,021 |  |  | $ | 69,074 |  |
| Subscriber Solutions & Experience |  |  | 51,823 |  |  |  | 2,783 |  |  |  | 54,606 |  |  |  | 52,269 |  |  |  | 2,300 |  |  |  | 54,569 |  |
| Traditional & Other Products |  |  | 2,262 |  |  |  | 2,190 |  |  |  | 4,452 |  |  |  | 1,487 |  |  |  | 2,403 |  |  |  | 3,890 |  |
| Total |  | $ | 138,374 |  |  | $ | 16,144 |  |  | $ | 154,518 |  |  | $ | 113,809 |  |  | $ | 13,724 |  |  | $ | 127,533 |  |

- added (2022-08-05):
[0000950170-22-015058:note_history:40]
|  |  | Six Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 163,141 |  |  | $ | 22,080 |  |  | $ | 185,221 |  |  | $ | 138,360 |  |  | $ | 21,678 |  |  | $ | 160,038 |  |
| Subscriber Solutions & Experience |  |  | 127,009 |  |  |  | 5,741 |  |  |  | 132,750 |  |  |  | 97,366 |  |  |  | 5,013 |  |  |  | 102,379 |  |
| Traditional & Other Products |  |  | 4,216 |  |  |  | 4,369 |  |  |  | 8,585 |  |  |  | 3,532 |  |  |  | 4,816 |  |  |  | 8,348 |  |
| Total |  | $ | 294,366 |  |  | $ | 32,190 |  |  | $ | 326,556 |  |  | $ | 239,258 |  |  | $ | 31,507 |  |  | $ | 270,765 |  |

- changed (2022-08-05):
[0000950170-22-015058:note_history:41]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2022 and December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $164.5 million and $101.1 million, respectively. As of June 30, 2022, approximately 84% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at June 30, 2022 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.
  (was, 2022-05-06, similarity 0.987):
[0000950170-22-008077:note_history:41]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2022 and December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $133.1 million and $101.1 million, respectively. As of March 31, 2022, approximately 81.1% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at March 31, 2022 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2022-08-05):
[0000950170-22-015058:note_history:42]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2022 |  |  | December 31, 2021 |  |
| Accounts receivable, net |  | $ | 172,088 |  |  | $ | 158,742 |  |
| Contract assets(1) |  | $ | 1,749 |  |  | $ | 464 |  |
| Unearned revenue |  | $ | 22,705 |  |  | $ | 17,737 |  |
| Non-current unearned revenue |  | $ | 10,133 |  |  | $ | 9,271 |  |
  (was, 2022-05-06, similarity 0.9841):
[0000950170-22-008077:note_history:42]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2022 |  |  | December 31, 2021 |  |
| Accounts receivable, net |  | $ | 150,111 |  |  | $ | 158,742 |  |
| Contract assets(1) |  | $ | 8,243 |  |  | $ | 464 |  |
| Unearned revenue |  | $ | 19,454 |  |  | $ | 17,737 |  |
| Non-current unearned revenue |  | $ | 9,381 |  |  | $ | 9,271 |  |

- added (2022-08-05):
[0000950170-22-015058:note_history:43]
Of the outstanding unearned revenue balances as of December 31, 2021, $4.1 million and $9.5 million was recognized as revenue during the three and six months ended June 30, 2022, respectively. Of the $14.1 million of outstanding unearned revenue balances as of December 31, 2020, $2.9 million and $7.9 million was recognized as revenue during the three and six months ended June 30, 2021, respectively.

- removed (2022-08-05):
[0000950170-22-008077:note_history:44]
Of the outstanding unearned revenue balances as of December 31, 2021, $5.4 million was recognized as revenue during the three months ended March 31, 2022. Of the $14.1 million of outstanding unearned revenue balances as of December 31, 2020, $5.0 million was recognized as revenue during the three months ended March 31, 2021.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0000950170-22-015058:note_history:45]
On August 3, 2022, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 18, 2022. The payment date will be September 1, 2022 in the aggregate amount of approximately $7.0 million.
  (was, 2022-05-06, similarity 0.9468):
[0000950170-22-008077:note_history:45]
On May 4, 2022, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 19, 2022. The payment date will be June 2, 2022 in the aggregate amount of approximately $4.4 million.

- added (2022-08-05):
[0000950170-22-015058:note_history:46]
Closing of the Business Combination with ADVA

- added (2022-08-05):
[0000950170-22-015058:note_history:47]
As previously disclosed, on July 8, 2022, Acorn MergeCo, Inc. (“Merger Sub”), a Delaware corporation and wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (f/k/a Acorn HoldCo, Inc.) (the “Company”), merged with and into ADTRAN, Inc. (“ADTRAN”), with ADTRAN surviving the merger as a wholly-owned direct subsidiary of the Company (the “Merger”). The Merger was consummated pursuant to the Business Combination Agreement (the “Business Combination Agreement”), dated as of August 30, 2021, by and among the Company, ADTRAN, ADVA Optical Networking SE, a company organized and existing under the laws of Germany (“ADVA”), and Merger Sub.

- added (2022-08-05):
[0000950170-22-015058:note_history:48]
Pursuant to the Business Combination Agreement, the Company made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of common stock, par value $0.01 per share (the “Company Common Stock”), of the Company (the “Exchange Offer” and, together with the Merger, the “Business Combination”). The acceptance period for the Exchange Offer ended on February 14, 2022, and on July 6, 2022, the Company announced that all special offer conditions to the consummation of the Exchange Offer had been satisfied. The Exchange Offer was settled on July 15, 2022 (the “Exchange Offer Settlement Date”) in which the Company acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of Company Common Stock. Based on the Company's closing share price as of July 15, 2022 of $20.20, the value of the Company Common Stock provided in exchange for ADVA common stock was approximately $565.5 million.

- added (2022-08-05):
[0000950170-22-015058:note_history:49]
The issuance of shares of Company Common Stock in connection with the Business Combination was registered under the Securities Act of 1933, as amended (the “Securities Act”), pursuant to a registration statement on Form S-4 (the “Registration Statement”) (File No. 333-259251), which was declared effective by the U.S. Securities and Exchange Commission on December 2, 2021, and which included a proxy statement of ADTRAN for the special meeting of the stockholders of ADTRAN at which ADTRAN’s stockholders voted to adopt the Business Combination Agreement and that also constituted a prospectus for the Company (the “Proxy Statement”).

- added (2022-08-05):
[0000950170-22-015058:note_history:50]
The Company Common Stock is listed on the Nasdaq Global Select Market (“Nasdaq”) and trades under the symbol “ADTN”. The Company Common Stock was also approved for listing on the regulated market segment (regulierter Markt) of the Frankfurt Stock Exchange (Frankfurter Wertpapierbörse) with simultaneous admission to the sub-segment thereof with additional post-admission obligations (Prime Standard) on July 13, 2022 and trades there under the symbol “QH9”.

- added (2022-08-05):
[0000950170-22-015058:note_history:51]
For the three and six months ended June 30, 2022, the Company incurred $0.9 million and $1.8 million of transaction costs and were recognized as selling, general and administrative expense and research and development expense in our Condensed Consolidated Statements of Income, respectively. For the three and six months ended June 30, 2021, the Company incurred $2.4 million and $3.4 million of transaction costs and were recognized as selling, general and administrative expense and research and development expense in our Condensed Consolidated Statements of Income, respectively.

- added (2022-08-05):
[0000950170-22-015058:note_history:52]
We expect that the business combination will be accounted for using the acquisition method of accounting under ASC 805, with ADTRAN Holdings, Inc. representing the accounting acquirer under this guidance. Due to the timing of the acquisition subsequent to our June 30, 2022 reporting period end, the initial accounting, including the allocation of purchase price and supplemental pro forma information, is incomplete as of the filing date and, therefore, related disclosures are not included herein.

- added (2022-08-05):
[0000950170-22-015058:note_history:53]
Assumed ADVA Options

- added (2022-08-05):
[0000950170-22-015058:note_history:54]
Pursuant to the Business Combination which closed on July 15, 2022, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings. The maximum number of shares of ADTRAN Holdings stock potentially issuable upon such assumption was 2.1 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.0 million shares of ADTRAN Holdings stock are subject to assumed ADVA options. The fair value of the stock options assumed by ADTRAN Holdings will be estimated using a Black-Scholes model. Our valuation of this component of consideration is not yet complete.

- added (2022-08-05):
[0000950170-22-015058:note_history:55]
Wells Fargo Credit Agreement

- added (2022-08-05):
[0000950170-22-015058:note_history:56]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allows for borrowings of up to $100 million in aggregate principal amount, subject to being increased to up to $400 million in aggregate principal amount upon the Company or Borrower’s execution of a domination and profit and loss transfer agreement with ADVA or a parent of ADVA, among other conditions (the “Senior Credit Facilities Increase”).

- added (2022-08-05):
[0000950170-22-015058:note_history:57]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

- added (2022-08-05):
[0000950170-22-015058:note_history:58]
As of August 5, 2022, ADTRAN, Inc.’s borrowings under the revolving line of credit were $50.0 million. In addition, a $17.5 million letter of credit with ADTRAN, Inc. remains outstanding. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

- added (2022-08-05):
[0000950170-22-015058:note_history:59]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”).  All E.U. borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from  1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

- added (2022-08-05):
[0000950170-22-015058:note_history:60]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participations in letters of credit at the then applicable rate for SOFR Loans.

- added (2022-08-05):
[0000950170-22-015058:note_history:61]
The Credit Agreement will mature on July 14, 2027, with the Company’s option to request extensions subject to customary conditions.  The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans).

- added (2022-08-05):
[0000950170-22-015058:note_history:62]
The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements.  It also contains customary events of default (subject to customary cure periods and materiality thresholds).

- added (2022-08-05):
[0000950170-22-015058:note_history:63]
Furthermore, the Credit Agreement requires that the Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not to exceed 3.25 to 1.00 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the Consolidated Interest Coverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00.

- added (2022-08-05):
[0000950170-22-015058:note_history:64]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

- removed (2022-08-05):
[0000950170-22-008077:note_history:65]
On April 1, 2022, the Company entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provides the Company with a new $25 million secured revolving credit facility. The Wells Revolving Credit Agreement matures on April 1, 2023, subject to earlier termination upon the occurrence of certain events of default as set forth in the Wells Revolving Credit Agreement.  Loans under the Wells Revolving Credit Agreement will bear interest at a fluctuating rate per annum equal to: (i) the Daily Simple SOFR (as defined herein) plus (ii) an applicable margin, which will equal 1.00%, 1.25%, 1.5% or 2.0% per annum depending on the Company’s senior funded debt to EBITDA ratio. The “Daily Simple SOFR” is calculated based upon the greater of (x) a floor of 0.00% and (b) the Secured Overnight Financing Rate, as established by the Federal Reserve Bank of New York (or a successor thereto) from time to time. Accrued interest is payable on the last day of each quarter, commencing June 30, 2022. Borrowings under the Wells Revolving Credit Agreement may be used solely for issuing letters of credit, financing capital expenditures, and working capital and general corporate purposes. Loans under the Wells Revolving Credit Agreement are secured by a first priority security interest in all of the accounts receivable of the Company and its subsidiary, ADTRAN International, Inc. Specifically, in connection with the Wells Revolving Credit Agreement, the Company entered into a security agreement, dated April 1, 2022, pursuant to which the Company pledged to the Wells Lender all of the rights to payment, accounts, deposit accounts, chattel paper (whether electronic or tangible), instruments, promissory notes, documents, licenses, general intangibles, payment intangibles, software, letter of credit rights and healthcare insurance receivables existing as of the date of execution or arising at any time thereafter.
