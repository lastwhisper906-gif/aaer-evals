# ADTN notes — 0000950170-22-015058


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-22-015058:notes:1]
On July 8, 2022, Acorn MergeCo, Inc. (“Merger Sub”), a Delaware corporation and wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (formerly known as Acorn HoldCo), merged with and into ADTRAN, Inc., with ADTRAN, Inc. surviving the merger as a wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (the “Merger”).  The Merger was consummated pursuant to the Business Combination Agreement, dated as of August 30, 2021 (the “Business Combination Agreement”), by and among ADTRAN Holdings, Inc., ADTRAN, Inc., ADVA Optical Networking SE, a company organized and existing under the laws of Germany (“ADVA”), and Merger Sub.  In accordance with the Business Combination Agreement, ADTRAN Holdings, Inc. made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of common stock, par value $0.01 per share (the “Company Common Stock”), of ADTRAN Holdings, Inc. (the “Exchange Offer” and, together with the Merger, the “Business Combination”).  On July 15, 2022 (the “Exchange Offer Settlement Date”), ADTRAN Holdings, Inc. completed the Exchange Offer, in which ADTRAN Holdings, Inc. acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of common stock of ADTRAN Holdings, Inc.

[0000950170-22-015058:notes:2]
Except as otherwise indicated, references in these notes to “ADTRAN,” the “Company,” “we,” “us” and “our” for time periods at and before the effectiveness of the Merger, including all fiscal periods ended on or prior to June 30, 2022, shall be deemed to refer to ADTRAN, Inc. as the predecessor registrant to ADTRAN Holdings, Inc.

[0000950170-22-015058:notes:3]
[same as prior period, unchanged from 0000950170-22-008077:notes:1]

[0000950170-22-015058:notes:4]
[same as prior period, unchanged from 0000950170-22-008077:notes:2]

[0000950170-22-015058:notes:5]
The accompanying unaudited condensed consolidated financial statements of ADTRAN and its subsidiaries have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. Certain prior year amounts have been reclassified to conform to the current period presentation. The December 31, 2021 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

[0000950170-22-015058:notes:6]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN, Inc. Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022.

[0000950170-22-015058:notes:7]
[same as prior period, unchanged from 0000950170-22-008077:notes:5]

[0000950170-22-015058:notes:8]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

[0000950170-22-015058:notes:9]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus) as well as supply chain constraints as of June 30, 2022 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints, could result in further impacts to our consolidated financial statements in future reporting periods.

[0000950170-22-015058:notes:10]
Recently Adopted Accounting Pronouncements

[0000950170-22-015058:notes:11]
There are currently no recently adopted accounting pronouncements that had a material effect on the condensed consolidated financial statements.

[0000950170-22-015058:notes:12]
[same as prior period, unchanged from 0000950170-22-008077:notes:10]

[0000950170-22-015058:notes:13]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. ASU 2021-08 is effective for annual periods beginning after December 15, 2022, including interim periods within those fiscal years. Adoption of the ASU should be applied prospectively. Early adoption is also permitted, including adoption in an interim period. If early adopted, the amendments are applied retrospectively to all business combinations for which the acquisition date occurred during the fiscal year of adoption. Given that the Business Combination with ADVA was finalized in July 2022, the Company plans to early adopt ASU 2021-08 during the third quarter of 2022. ASU 2021-08 will be effective as of January 1, 2022 and will be applied on a prospective basis. However, we are unable to estimate the effect on our Condensed Consolidated Financial Statements as of the date of this report.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000950170-22-015058:notes:14]
[same as prior period, unchanged from 0000950170-22-008077:notes:12]

[0000950170-22-015058:notes:15]
[same as prior period, unchanged from 0000950170-22-008077:notes:13]

[0000950170-22-015058:notes:16]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2022 |  |  | December 31, 2021 |  |
| Cash and cash equivalents |  | $ | 43,368 |  |  | $ | 56,603 |  |
| Restricted cash |  |  | — |  |  |  | 215 |  |
| Cash, cash equivalents and restricted cash |  | $ | 43,368 |  |  | $ | 56,818 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-22-015058:notes:17]
[same as prior period, unchanged from 0000950170-22-008077:notes:16]

[0000950170-22-015058:notes:18]
[same as prior period, unchanged from 0000950170-22-008077:notes:17]

[0000950170-22-015058:notes:19]
[same as prior period, unchanged from 0000950170-22-008077:notes:18]

[0000950170-22-015058:notes:20]
[same as prior period, unchanged from 0000950170-22-008077:notes:19]

[0000950170-22-015058:notes:21]
[same as prior period, unchanged from 0000950170-22-008077:notes:20]

[0000950170-22-015058:notes:22]
[same as prior period, unchanged from 0000950170-22-008077:notes:21]

[0000950170-22-015058:notes:23]
[same as prior period, unchanged from 0000950170-22-008077:notes:22]

[0000950170-22-015058:notes:24]
|  |  | Three Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 78,852 |  |  | $ | 10,909 |  |  | $ | 89,761 |  |  | $ | 78,307 |  |  | $ | 12,657 |  |  | $ | 90,964 |  |
| Subscriber Solutions & Experience |  |  | 75,186 |  |  |  | 2,958 |  |  |  | 78,144 |  |  |  | 45,097 |  |  |  | 2,713 |  |  |  | 47,810 |  |
| Traditional & Other Products |  |  | 1,954 |  |  |  | 2,179 |  |  |  | 4,133 |  |  |  | 2,045 |  |  |  | 2,413 |  |  |  | 4,458 |  |
| Total |  | $ | 155,992 |  |  | $ | 16,046 |  |  | $ | 172,038 |  |  | $ | 125,449 |  |  | $ | 17,783 |  |  | $ | 143,232 |  |

[0000950170-22-015058:notes:25]
|  |  | Six Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 163,141 |  |  | $ | 22,080 |  |  | $ | 185,221 |  |  | $ | 138,360 |  |  | $ | 21,678 |  |  | $ | 160,038 |  |
| Subscriber Solutions & Experience |  |  | 127,009 |  |  |  | 5,741 |  |  |  | 132,750 |  |  |  | 97,366 |  |  |  | 5,013 |  |  |  | 102,379 |  |
| Traditional & Other Products |  |  | 4,216 |  |  |  | 4,369 |  |  |  | 8,585 |  |  |  | 3,532 |  |  |  | 4,816 |  |  |  | 8,348 |  |
| Total |  | $ | 294,366 |  |  | $ | 32,190 |  |  | $ | 326,556 |  |  | $ | 239,258 |  |  | $ | 31,507 |  |  | $ | 270,765 |  |

[0000950170-22-015058:notes:26]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2022 and December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $164.5 million and $101.1 million, respectively. As of June 30, 2022, approximately 84% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at June 30, 2022 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-22-015058:notes:27]
[same as prior period, unchanged from 0000950170-22-008077:notes:25]

[0000950170-22-015058:notes:28]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2022 |  |  | December 31, 2021 |  |
| Accounts receivable, net |  | $ | 172,088 |  |  | $ | 158,742 |  |
| Contract assets(1) |  | $ | 1,749 |  |  | $ | 464 |  |
| Unearned revenue |  | $ | 22,705 |  |  | $ | 17,737 |  |
| Non-current unearned revenue |  | $ | 10,133 |  |  | $ | 9,271 |  |

[0000950170-22-015058:notes:29]
[same as prior period, unchanged from 0000950170-22-008077:notes:27]

[0000950170-22-015058:notes:30]
Of the outstanding unearned revenue balances as of December 31, 2021, $4.1 million and $9.5 million was recognized as revenue during the three and six months ended June 30, 2022, respectively. Of the $14.1 million of outstanding unearned revenue balances as of December 31, 2020, $2.9 million and $7.9 million was recognized as revenue during the three and six months ended June 30, 2021, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000950170-22-015058:notes:31]
The table below presents revenue information by category:

[0000950170-22-015058:notes:32]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Access & Aggregation |  | $ | 89,761 |  |  | $ | 90,964 |  |  | $ | 185,221 |  |  | $ | 160,038 |  |
| Subscriber Solutions & Experience |  |  | 78,144 |  |  |  | 47,810 |  |  |  | 132,750 |  |  |  | 102,379 |  |
| Traditional & Other Products |  |  | 4,133 |  |  |  | 4,458 |  |  |  | 8,585 |  |  |  | 8,348 |  |
| Total |  | $ | 172,038 |  |  | $ | 143,232 |  |  | $ | 326,556 |  |  | $ | 270,765 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-22-015058:notes:33]
[same as prior period, unchanged from 0000950170-22-008077:notes:29]

[0000950170-22-015058:notes:34]
Our effective tax rate changed from an expense of 18.1% of pre-tax income for the three months ended June 30, 2021, to an expense of 50.1% of pre-tax income for the three months ended June 30, 2022 and changed from an expense of 26.7% of pre-tax income for the six months ended June 30, 2021, to a benefit of 34.3% of pre-tax income for the six months ended June 30, 2022. The change in the effective tax rate for the three and six months ended June 30, 2022, was driven primarily by a change in our annual estimated tax rate as a result of the requirement to begin capitalizing research and development expenses for U.S. tax purposes beginning in 2022 as previously passed as part of the Tax Cuts and Jobs Act in December 2017 and the associated impact of those changes on our previously established valuation allowance.

[0000950170-22-015058:notes:35]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of June 30, 2022, the Company had deferred tax assets totaling $71.4 million, and a valuation allowance totaling $62.9 million against those deferred tax assets. The remaining $8.5 million in deferred tax assets not offset by a valuation allowance are located in various foreign jurisdictions where the Company believes it is more likely than not we will realize these deferred tax assets. During the six months ended June 30, 2022, the total change in the valuation allowance against our domestic and international deferred tax assets was recorded in the amount of an $12.6 million increase and a $0.2 million decrease, respectively. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results as well as the evaluation of evidence which requires significant judgment, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.

[0000950170-22-015058:notes:36]
[same as prior period, unchanged from 0000950170-22-008077:notes:32]

[0000950170-22-015058:notes:37]
|  |  | As of June 30, 2022 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 60,873 |  |  | $ | (60,873 | ) |  | $ | — |  |
| International |  |  | 10,568 |  |  |  | (2,060 | ) |  |  | 8,508 |  |
| Total |  | $ | 71,441 |  |  | $ | (62,933 | ) |  | $ | 8,508 |  |

[0000950170-22-015058:notes:38]
[same as prior period, unchanged from 0000950170-22-008077:notes:34]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-22-015058:notes:39]
[same as prior period, unchanged from 0000950170-22-008077:notes:35]

[0000950170-22-015058:notes:40]
[same as prior period, unchanged from 0000950170-22-008077:notes:36]

[0000950170-22-015058:notes:41]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Stock-based compensation expense included in cost of revenue |  | $ | 162 |  |  | $ | 125 |  |  | $ | 321 |  |  | $ | 256 |  |
| Selling, general and administrative expense |  |  | 1,135 |  |  |  | 1,098 |  |  |  | 2,259 |  |  |  | 2,196 |  |
| Research and development expense |  |  | 591 |  |  |  | 585 |  |  |  | 1,201 |  |  |  | 1,163 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,726 |  |  |  | 1,683 |  |  |  | 3,460 |  |  |  | 3,359 |  |
| Total stock-based compensation expense |  |  | 1,888 |  |  |  | 1,808 |  |  |  | 3,781 |  |  |  | 3,615 |  |
| Tax benefit for expense associated with stock options, PSUs, RSUs and restricted stock |  |  | (472 | ) |  |  | (452 | ) |  |  | (945 | ) |  |  | (883 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,416 |  |  | $ | 1,356 |  |  | $ | 2,836 |  |  | $ | 2,732 |  |

[0000950170-22-015058:notes:42]
[same as prior period, unchanged from 0000950170-22-008077:notes:38]

[0000950170-22-015058:notes:43]
The following table summarizes PSUs, RSUs and restricted stock outstanding as of December 31, 2021 and June 30, 2022 and the changes that occurred during the six months ended June 30, 2022:

[0000950170-22-015058:notes:44]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2021 |  |  | 1,930 |  |  | $ | 14.11 |  |
| PSUs, RSUs and restricted stock granted |  |  | 336 |  |  | $ | 20.14 |  |
| PSUs, RSUs and restricted stock vested |  |  | (15 | ) |  | $ | 13.26 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (41 | ) |  | $ | 14.08 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, June 30, 2022 |  |  | 2,210 |  |  | $ | 15.04 |  |

[0000950170-22-015058:notes:45]
During each of the six months ended June 30, 2022 and 2021, the Company granted 0.3 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over one-year, two-year and three-year periods, respectively, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0000950170-22-015058:notes:46]
[same as prior period, unchanged from 0000950170-22-008077:notes:42]

[0000950170-22-015058:notes:47]
As of June 30, 2022, total unrecognized compensation expense related to non-vested market-based PSUs, RSUs and restricted stock was approximately $13.9 million, which will be recognized over the remaining weighted-average period of 2.5 years. Pursuant to the Business Combination, which was closed on July 15, 2022, 0.3 million of market-based PSUs were converted to time-based RSUs which will be treated as an award modification under U.S. GAAP in the third quarter of 2022. This will result in incremental compensation expense of $1.6 million which will be recognized over the remaining weighted-average period of 1.1 years. In addition, there was $13.2 million of unrecognized compensation expense related to unvested 2020, 2021 and 2022 performance-based PSUs, which will be recognized over the remaining requisite service period of 0.5 years if achievement of the performance obligation becomes probable. Pursuant to the Business Combination, which was closed on July 15, 2022, the unearned performance-based PSUs were converted to time-based RSUs which will be treated as an award modification under U.S. GAAP in the third quarter of 2022. This will result in incremental compensation and unrecognized compensation expense totaling $17.8 million, which will be recognized over the remaining service period of 0.5 years. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0000950170-22-015058:notes:48]
As of June 30, 2022, 3.5 million shares were available for issuance under stockholder-approved equity plans.

[0000950170-22-015058:notes:49]
[same as prior period, unchanged from 0000950170-22-008077:notes:45]

[0000950170-22-015058:notes:50]
The following table summarizes stock options outstanding as of December 31, 2021 and June 30, 2022 and the changes that occurred during the six months ended June 30, 2022:

[0000950170-22-015058:notes:51]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2021 |  |  | 1,721 |  |  | $ | 19.37 |  |  |  | 2.4 |  |  | $ | 6,669 |  |
| Stock options exercised |  |  | (37 | ) |  | $ | 17.24 |  |  |  |  |  | $ | 110 |  |
| Stock options expired |  |  | (23 | ) |  | $ | 23.67 |  |  |  |  |  | $ | 5 |  |
| Stock options outstanding, June 30, 2022 |  |  | 1,661 |  |  | $ | 19.36 |  |  |  | 1.9 |  |  | $ | 1,127 |  |
| Stock options exercisable, June 30, 2022 |  |  | 1,661 |  |  | $ | 19.36 |  |  |  | 1.9 |  |  | $ | 1,127 |  |

[0000950170-22-015058:notes:52]
As of June 30, 2022, there was no unrecognized compensation expense related to stock options as all awards vested in prior periods.

[0000950170-22-015058:notes:53]
There were no stock options granted during the six months ended June 30, 2022 and 2021. All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0000950170-22-015058:notes:54]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on June 30, 2022. The amount of aggregate intrinsic value was $1.1 million as of June 30, 2022 and will change based on the fair market value of ADTRAN’s stock. The total pre-tax intrinsic value of options exercised during the six months ended June 30, 2022 was $0.1 million.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-22-015058:notes:55]
6. INVESTMENTS

[0000950170-22-015058:notes:56]
Debt Securities and Other Investments

[0000950170-22-015058:notes:57]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

[0000950170-22-015058:notes:58]
|  |  | As of June 30, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,854 |  |  | $ | 1 |  |  | $ | (286 | ) |  | $ | 10,569 |  |
| Municipal fixed-rate bonds |  |  | 1,563 |  |  |  | — |  |  |  | (49 | ) |  |  | 1,514 |  |
| Asset-backed bonds |  |  | 1,018 |  |  |  | 1 |  |  |  | (16 | ) |  |  | 1,003 |  |
| Mortgage/Agency-backed bonds |  |  | 4,199 |  |  |  | — |  |  |  | (185 | ) |  |  | 4,014 |  |
| U.S. government bonds |  |  | 12,287 |  |  |  | — |  |  |  | (503 | ) |  |  | 11,784 |  |
| Foreign government bonds |  |  | 410 |  |  |  | — |  |  |  | (22 | ) |  |  | 388 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,331 |  |  | $ | 2 |  |  | $ | (1,061 | ) |  | $ | 29,272 |  |

[0000950170-22-015058:notes:59]
|  |  | As of December 31, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,776 |  |  | $ | 6 |  |  | $ | (35 | ) |  | $ | 10,747 |  |
| Municipal fixed-rate bonds |  |  | 1,553 |  |  |  | 2 |  |  |  | (4 | ) |  |  | 1,551 |  |
| Asset-backed bonds |  |  | 322 |  |  |  | 3 |  |  |  | (3 | ) |  |  | 322 |  |
| Mortgage/Agency-backed bonds |  |  | 4,754 |  |  |  | 15 |  |  |  | (33 | ) |  |  | 4,736 |  |
| U.S. government bonds |  |  | 12,251 |  |  |  | 12 |  |  |  | (92 | ) |  |  | 12,171 |  |
| Foreign government bonds |  |  | 543 |  |  |  | — |  |  |  | (4 | ) |  |  | 539 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,199 |  |  | $ | 38 |  |  | $ | (171 | ) |  | $ | 30,066 |  |

[0000950170-22-015058:notes:60]
The contractual maturities related to debt securities and other investments were as follows:

[0000950170-22-015058:notes:61]
|  |  | As of June 30, 2022 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 621 |  |  | $ | 148 |  |  | $ | — |  |  | $ | 637 |  |  | $ | 367 |  |  | $ | — |  |  |
| One to two years |  |  | 6,484 |  |  |  | 1,254 |  |  |  | — |  |  |  | 472 |  |  |  | 8,315 |  |  |  | 279 |  |  |
| Two to three years |  |  | 3,339 |  |  |  | 112 |  |  |  | 248 |  |  |  | 621 |  |  |  | 3,102 |  |  |  | 109 |  |  |
| Three to five years |  |  | 125 |  |  |  | — |  |  |  | 313 |  |  |  | 189 |  |  |  | — |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 215 |  |  |  | 925 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 227 |  |  |  | 1,170 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 10,569 |  |  | $ | 1,514 |  |  | $ | 1,003 |  |  | $ | 4,014 |  |  | $ | 11,784 |  |  | $ | 388 |  |  |

[0000950170-22-015058:notes:62]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0000950170-22-015058:notes:63]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to our debt securities:

[0000950170-22-015058:notes:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | 97 |  |  | $ | 12 |  |  | $ | 184 |  |
| Gross realized loss on debt securities |  |  | (85 | ) |  |  | (20 | ) |  |  | (125 | ) |  |  | (36 | ) |
| Total (loss) gain recognized, net |  | $ | (85 | ) |  | $ | 77 |  |  | $ | (113 | ) |  | $ | 148 |  |

[0000950170-22-015058:notes:65]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income. No allowance for credit losses was recorded for the six months ended June 30, 2022 and 2021 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the six months ended June 30, 2022.

[0000950170-22-015058:notes:66]
Marketable Equity Securities

[0000950170-22-015058:notes:67]
Our marketable equity securities consist of publicly traded stock, interests in funds and certain other investments measured at fair value or cost (where appropriate).

[0000950170-22-015058:notes:68]
The Company has an equity investment which does not have a readily determinable fair value and is recorded using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of the equity investment as of June 30, 2022 and December 31, 2021 was $1.0 million. During the year ended December 31, 2021, impairment charges totaling $0.4 million, were recorded related to the equity investment. As of June 30 2022, cumulative impairment charges totaling $2.4 million were recorded related to the equity investment. There were no impairment charges during the three and six months ended June 30, 2022 and 2021. During the year ended December 31, 2021, an unsecured loan totaling $0.5 million was converted to equity which increased the Company's carrying value of the equity investment.

[0000950170-22-015058:notes:69]
The Company has a secured note receivable as of June 30, 2022 and December 31, 2021 which totaled $0.4 million and is included in long term investments on the Consolidated Balance Sheets. During the year ended December 31, 2021, an impairment charge of $0.5 million was recognized against the secured note receivable. There were no impairment charges during the three and six months ended June 30, 2022 and 2021.

[0000950170-22-015058:notes:70]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0000950170-22-015058:notes:71]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Realized (loss) gain on equity securities sold |  | $ | (293 | ) |  | $ | (79 | ) |  | $ | (318 | ) |  | $ | (55 | ) |
| Unrealized (loss) gain on equity securities held |  |  | (4,268 | ) |  |  | 2,011 |  |  |  | (7,630 | ) |  |  | 2,912 |  |
| Total (loss) gain recognized, net |  | $ | (4,561 | ) |  | $ | 1,932 |  |  | $ | (7,948 | ) |  | $ | 2,857 |  |

[0000950170-22-015058:notes:72]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-22-015058:notes:73]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-22-015058:notes:74]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-22-015058:notes:75]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-22-015058:notes:76]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-22-015058:notes:77]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 409 |  |  | $ | 409 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,569 |  |  |  | — |  |  |  | 10,569 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,514 |  |  |  | — |  |  |  | 1,514 |  |  |  | — |  |
| Asset-backed bonds |  |  | 1,003 |  |  |  | — |  |  |  | 1,003 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,014 |  |  |  | — |  |  |  | 4,014 |  |  |  | — |  |
| U.S. government bonds |  |  | 11,784 |  |  |  | 11,784 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 388 |  |  |  | — |  |  |  | 388 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 873 |  |  |  | 873 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,567 |  |  |  | 22,567 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 53,121 |  |  | $ | 35,633 |  |  | $ | 17,488 |  |  | $ | — |  |

[0000950170-22-015058:notes:78]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 652 |  |  | $ | 652 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,747 |  |  |  | — |  |  |  | 10,747 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,551 |  |  |  | — |  |  |  | 1,551 |  |  |  | — |  |
| Asset-backed bonds |  |  | 322 |  |  |  | — |  |  |  | 322 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,736 |  |  |  | — |  |  |  | 4,736 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,171 |  |  |  | 12,171 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 539 |  |  |  | — |  |  |  | 539 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 12,606 |  |  |  | 12,606 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,935 |  |  |  | 26,935 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 70,259 |  |  | $ | 52,364 |  |  | $ | 17,895 |  |  | $ | — |  |

[0000950170-22-015058:notes:79]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-22-015058:notes:80]
[same as prior period, unchanged from 0000950170-22-008077:notes:77]

[0000950170-22-015058:notes:81]
[same as prior period, unchanged from 0000950170-22-008077:notes:78]

[0000950170-22-015058:notes:82]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2022 |  |  | December 31, 2021 |  |
| Raw materials |  | $ | 116,307 |  |  | $ | 74,709 |  |
| Work in process |  |  | 2,258 |  |  |  | 2,143 |  |
| Finished goods |  |  | 78,351 |  |  |  | 63,039 |  |
| Total inventory, net |  | $ | 196,916 |  |  | $ | 139,891 |  |

[0000950170-22-015058:notes:83]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which considers historical usage, known trends, inventory age and market conditions. As of June 30, 2022 and December 31, 2021, inventory reserves were $48.9 million and $44.6 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-22-015058:notes:84]
[same as prior period, unchanged from 0000950170-22-008077:notes:81]

[0000950170-22-015058:notes:85]
[same as prior period, unchanged from 0000950170-22-008077:notes:82]

[0000950170-22-015058:notes:86]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2022 |  |  | December 31, 2021 |  |
| Engineering and other equipment |  | $ | 134,748 |  |  | $ | 134,771 |  |
| Computer hardware and software |  |  | 74,141 |  |  |  | 72,274 |  |
| Building |  |  | 68,151 |  |  |  | 68,157 |  |
| Building and land improvements |  |  | 35,719 |  |  |  | 35,578 |  |
| Furniture and fixtures |  |  | 19,967 |  |  |  | 19,917 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Total property, plant and equipment |  |  | 337,301 |  |  |  | 335,272 |  |
| Less: accumulated depreciation |  |  | (283,869 | ) |  |  | (279,506 | ) |
| Total property, plant and equipment, net |  | $ | 53,432 |  |  | $ | 55,766 |  |

[0000950170-22-015058:notes:87]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. No impairment charges were recognized during the three and six months ended June 30, 2022 and 2021.

[0000950170-22-015058:notes:88]
Depreciation expense was $2.7 million and $3.0 million for the three months ended June 30, 2022 and 2021 and $5.5 million and $6.1 million for the six months ended June 30, 2022 and 2021, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-22-015058:notes:89]
[same as prior period, unchanged from 0000950170-22-008077:notes:86]

[0000950170-22-015058:notes:90]
Goodwill was $7.0 million as of June 30, 2022 and December 31, 2021, of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0000950170-22-015058:notes:91]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We qualitatively assess the carrying value of goodwill each reporting period for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Based on our assessment of certain qualitative factors such as macro-economic conditions, industry and market considerations, costs factors and overall financial performance, management concluded that no such events or circumstance changes were identified that would suggest that the fair value of the goodwill was more likely than not greater than its carrying amount as of June 30, 2022. No impairment of goodwill was recorded during the three and six months ended June 30, 2022 and 2021.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-22-015058:notes:92]
[same as prior period, unchanged from 0000950170-22-008077:notes:89]

[0000950170-22-015058:notes:93]
[same as prior period, unchanged from 0000950170-22-008077:notes:90]

[0000950170-22-015058:notes:94]
|  |  | As of June 30, 2022 |  |  | As of December 31, 2021 |  |
| (In thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | $ | 20,451 |  |  | $ | (10,415 | ) |  | $ | 10,036 |  |  | $ | 20,796 |  |  | $ | (9,906 | ) |  | $ | 10,890 |  |
| Developed technology |  |  | 8,200 |  |  |  | (4,251 | ) |  |  | 3,949 |  |  |  | 8,200 |  |  |  | (3,683 | ) |  |  | 4,517 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (2,813 | ) |  |  | 3,087 |  |  |  | 5,900 |  |  |  | (2,486 | ) |  |  | 3,414 |  |
| Licensing agreements |  |  | 560 |  |  |  | (262 | ) |  |  | 298 |  |  |  | 560 |  |  |  | (225 | ) |  |  | 335 |  |
| Patents |  |  | 500 |  |  |  | (397 | ) |  |  | 103 |  |  |  | 500 |  |  |  | (363 | ) |  |  | 137 |  |
| Trade names |  |  | 210 |  |  |  | (210 | ) |  |  | — |  |  |  | 210 |  |  |  | (210 | ) |  |  | — |  |
| Total |  | $ | 35,821 |  |  | $ | (18,348 | ) |  | $ | 17,473 |  |  | $ | 36,166 |  |  | $ | (16,873 | ) |  | $ | 19,293 |  |

[0000950170-22-015058:notes:95]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to intangible assets during the first and second quarters of 2022 and 2021. As a result, no quantitative impairment test of long-lived assets was performed as of June 30, 2022 and 2021, and no impairment losses of intangible assets were recorded during the three and six months ended June 30, 2022 and 2021.

[0000950170-22-015058:notes:96]
Amortization expense was $0.9 million and $1.0 million in the three months ended June 30, 2022 and 2021 and $1.8 million and $2.1 million in the six months ended June 30, 2022 and 2021, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income.

[0000950170-22-015058:notes:97]
[same as prior period, unchanged from 0000950170-22-008077:notes:95]

[0000950170-22-015058:notes:98]
|  |  | As of |  |
| (In thousands) |  | June 30, 2022 |  |
| 2022 |  | $ | 1,696 |  |
| 2023 |  |  | 3,305 |  |
| 2024 |  |  | 3,213 |  |
| 2025 |  |  | 3,019 |  |
| 2026 |  |  | 1,985 |  |
| Thereafter |  |  | 4,255 |  |
| Total |  | $ | 17,473 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000950170-22-015058:notes:99]
[same as prior period, unchanged from 0000950170-22-008077:notes:97]

[0000950170-22-015058:notes:100]
[same as prior period, unchanged from 0000950170-22-008077:notes:98]

[0000950170-22-015058:notes:101]
[same as prior period, unchanged from 0000950170-22-008077:notes:99]

[0000950170-22-015058:notes:102]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2022 |  |  | December 31, 2021 |  |
| Current minimum lease payments receivable(1) |  | $ | 33 |  |  | $ | 92 |  |
| Non-current minimum lease payments receivable(2) |  |  | — |  |  |  | 4 |  |
| Total minimum lease payments receivable |  |  | 33 |  |  |  | 96 |  |
| Less: Current unearned revenue(1) |  |  | 23 |  |  |  | 70 |  |
| Less: Non-current unearned revenue(2) |  |  | — |  |  |  | 1 |  |
| Net investment in sales-type leases |  | $ | 10 |  |  | $ | 25 |  |

[0000950170-22-015058:notes:103]
[same as prior period, unchanged from 0000950170-22-008077:notes:101]

[0000950170-22-015058:notes:104]
[same as prior period, unchanged from 0000950170-22-008077:notes:102]


## us-gaap:DebtDisclosureTextBlock

[0000950170-22-015058:notes:105]
12. REVOLVING CREDIT AGREEMENTS

[0000950170-22-015058:notes:106]
Cadence Revolving Credit Agreement

[0000950170-22-015058:notes:107]
On May 19, 2022, the Company, as borrower, modified its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The modified Cadence Revolving Credit Agreement provides the Company with a $25.0 million secured revolving credit facility. Loans under the Cadence Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Cadence Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Cadence Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Cadence Revolving Credit Agreement, at a maximum loan-to-value ratio of 85% determined by dividing the full commitment amount under the Cadence Revolving Credit Agreement on the date of testing, determined by the Cadence Lender each fiscal quarter, by the market value of the collateral. The Cadence Revolving Credit Agreement matures on November 3, 2022, subject to earlier termination upon the concurrence of certain events of default. The Company entered into the Cadence Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. During the first half of 2022, the Company made draws totaling $18.0 million under the Cadence Revolving Credit Agreement all of which had been repaid as of June 30, 2022. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company. As of June 30, 2022, the Company was in compliance with all contractual requirements under the Cadence Revolving Credit Agreement.

[0000950170-22-015058:notes:108]
Wells Fargo Revolving Credit Agreement

[0000950170-22-015058:notes:109]
On April 1, 2022, the Company entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provides the Company with a new $25.0 million secured revolving credit facility. The Wells Revolving Credit Agreement matures on April 1, 2023, subject to earlier termination upon the occurrence of certain events of default as set forth in the Wells Revolving Credit Agreement. Loans under the Wells Revolving Credit Agreement will bear interest at a fluctuating rate per annum equal to: (i) the Daily Simple SOFR (as defined herein) plus (ii) an applicable margin, which will equal 1.00%, 1.25%, 1.5% or 2.0% per annum depending on the Company’s senior funded debt to EBITDA ratio. The “Daily Simple SOFR” is calculated based upon the greater of (x) a floor of 0.00% and (b) the Secured Overnight Financing Rate, as established by the Federal Reserve Bank of New York (or a successor thereto) from time to time. Accrued interest is payable on the last day of each quarter, commencing June 30, 2022. Borrowings under the Wells Revolving Credit Agreement may be used solely for issuing letters of credit, financing capital expenditures, and working capital and general corporate purposes. Loans under the Wells Revolving Credit Agreement are secured by a first priority security interest in all of the accounts receivable of the Company and its subsidiary, ADTRAN International, Inc. Specifically, in connection with the Wells Revolving Credit Agreement, the Company entered into a security agreement, dated April 1, 2022, pursuant to which the Company pledged to the Wells Lender all of the rights to payment, accounts, deposit accounts, chattel paper (whether electronic or tangible), instruments, promissory notes, documents, licenses, general intangibles, payment intangibles, software, letter of credit rights and healthcare insurance receivables existing as of the date of execution or arising at any time thereafter.  During the first half of 2022, the Company made draws totaling $10.0 million under the Wells Revolving Credit Agreement all of which had been repaid as of June 30, 2022. As of June 30, 2022, the Company was in compliance with all contractual requirements under the Wells Fargo Credit Agreement.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-22-015058:notes:110]
[same as prior period, unchanged from 0000950170-22-008077:notes:105]

[0000950170-22-015058:notes:111]
[same as prior period, unchanged from 0000950170-22-008077:notes:106]

[0000950170-22-015058:notes:112]
During the six months ended June 30, 2022, we did not repurchase any shares of our common stock. As of June 30, 2022, we had the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares. Subsequent to the Business Combination in July 2022, there is no current authorization to repurchase common stock.

[0000950170-22-015058:notes:113]
Accumulated Other Comprehensive Loss

[0000950170-22-015058:notes:114]
The following tables present the changes in accumulated other comprehensive loss, net of tax, by component:

[0000950170-22-015058:notes:115]
|  |  | Three Months Ended June 30, 2022 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of March 31, 2022 |  | $ | (1,276 | ) |  | $ | (5,626 | ) |  | $ | (7,039 | ) |  | $ | 385 |  |  | $ | (13,556 | ) |
| Other comprehensive loss before reclassifications |  |  | (589 | ) |  |  | — |  |  |  | (2,853 | ) |  |  | — |  |  |  | (3,442 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | 389 |  |  |  | (87 | ) |  |  | — |  |  |  | — |  |  |  | 302 |  |
| Net current period other comprehensive loss |  |  | (200 | ) |  |  | (87 | ) |  |  | (2,853 | ) |  |  | — |  |  |  | (3,140 | ) |
| Balance as of June 30, 2022 |  | $ | (1,476 | ) |  | $ | (5,713 | ) |  | $ | (9,892 | ) |  | $ | 385 |  |  | $ | (16,696 | ) |

[0000950170-22-015058:notes:116]
|  |  | Three Months Ended June 30, 2021 |  |
| (In thousands) |  | UnrealizedGains(Losses)onAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of March 31, 2021 |  | $ | (160 | ) |  | $ | (9,522 | ) |  | $ | (4,298 | ) |  | $ | 385 |  |  | $ | (13,595 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (272 | ) |  |  | — |  |  |  | 338 |  |  |  | — |  |  |  | 66 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | 177 |  |  |  | 212 |  |  |  | — |  |  |  | — |  |  |  | 389 |  |
| Net current period other comprehensive (loss) income |  |  | (95 | ) |  |  | 212 |  |  |  | 338 |  |  |  | — |  |  |  | 455 |  |
| Balance as of June 30, 2021 |  | $ | (255 | ) |  | $ | (9,310 | ) |  | $ | (3,960 | ) |  | $ | 385 |  |  | $ | (13,140 | ) |

[0000950170-22-015058:notes:117]
|  |  | Six Months Ended June 30, 2022 |  |
| (In thousands) |  | UnrealizedGains (Losses)onAvailable-for-SaleSecurities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2021 |  | $ | (552 | ) |  | $ | (5,613 | ) |  | $ | (6,134 | ) |  | $ | 385 |  |  | $ | (11,914 | ) |
| Other comprehensive loss before reclassifications |  |  | (1,564 | ) |  |  | — |  |  |  | (3,758 | ) |  |  | — |  |  |  | (5,322 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | 640 |  |  |  | (100 | ) |  |  | — |  |  |  | — |  |  |  | 540 |  |
| Net current period other comprehensive loss |  |  | (924 | ) |  |  | (100 | ) |  |  | (3,758 | ) |  |  | — |  |  |  | (4,782 | ) |
| As of June 30, 2022 |  | $ | (1,476 | ) |  | $ | (5,713 | ) |  | $ | (9,892 | ) |  | $ | 385 |  |  | $ | (16,696 | ) |

[0000950170-22-015058:notes:118]
|  |  | Six Months Ended June 30, 2021 |  |
| (In thousands) |  | UnrealizedGains (Losses) on Available-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2020 |  | $ | 32 |  |  | $ | (9,621 | ) |  | $ | (2,435 | ) |  | $ | 385 |  |  | $ | (11,639 | ) |
| Other comprehensive loss before reclassifications |  |  | (329 | ) |  |  | — |  |  |  | (1,525 | ) |  |  | — |  |  |  | (1,854 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | 42 |  |  |  | 311 |  |  |  | — |  |  |  | — |  |  |  | 353 |  |
| Net current period other comprehensive (loss) income |  |  | (287 | ) |  |  | 311 |  |  |  | (1,525 | ) |  |  | — |  |  |  | (1,501 | ) |
| As of June 30, 2021 |  | $ | (255 | ) |  | $ | (9,310 | ) |  | $ | (3,960 | ) |  | $ | 385 |  |  | $ | (13,140 | ) |

[0000950170-22-015058:notes:119]
[same as prior period, unchanged from 0000950170-22-008077:notes:112]

[0000950170-22-015058:notes:120]
|  |  | Three Months Ended June 30, 2022 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in theStatement Where Net(Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (512 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial gain |  |  | 126 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (386 | ) |  |  |
| Tax benefit |  |  | 84 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (302 | ) |  |  |

[0000950170-22-015058:notes:121]
(1)
A part of the computation of net periodic pension cost, which is included in other (expense) income, net in the Condensed Consolidated Statements of Income.

[0000950170-22-015058:notes:122]
|  |  | Three Months Ended June 30, 2021 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where Net (Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (233 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (307 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (540 | ) |  |  |
| Tax benefit |  |  | 151 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (389 | ) |  |  |

[0000950170-22-015058:notes:123]
|  |  | Six Months Ended June 30, 2022 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where NetIncome Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (842 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial gain |  |  | 145 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (697 | ) |  |  |
| Tax benefit |  |  | 157 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (540 | ) |  |  |

[0000950170-22-015058:notes:124]
|  |  | Six Months Ended June 30, 2021 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (55 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial gain |  |  | (451 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (506 | ) |  |  |
| Tax benefit |  |  | 153 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (353 | ) |  |  |

[0000950170-22-015058:notes:125]
[same as prior period, unchanged from 0000950170-22-008077:notes:116]

[0000950170-22-015058:notes:126]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized loss on available-for-sale securities |  | $ | (775 | ) |  | $ | 186 |  |  | $ | (589 | ) |  | $ | (358 | ) |  | $ | 86 |  |  | $ | (272 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | 512 |  |  |  | (123 | ) |  |  | 389 |  |  |  | 233 |  |  |  | (56 | ) |  |  | 177 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | (126 | ) |  |  | 39 |  |  |  | (87 | ) |  |  | 307 |  |  |  | (95 | ) |  |  | 212 |  |
| Foreign currency translation adjustment |  |  | (2,853 | ) |  |  | — |  |  |  | (2,853 | ) |  |  | 338 |  |  |  | — |  |  |  | 338 |  |
| Total Other Comprehensive (Loss) Income |  | $ | (3,242 | ) |  | $ | 102 |  |  | $ | (3,140 | ) |  | $ | 520 |  |  | $ | (65 | ) |  | $ | 455 |  |

[0000950170-22-015058:notes:127]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized loss on available-for-sale securities |  | $ | (2,058 | ) |  | $ | 494 |  |  | $ | (1,564 | ) |  | $ | (433 | ) |  | $ | 104 |  |  | $ | (329 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | 842 |  |  |  | (202 | ) |  |  | 640 |  |  |  | 55 |  |  |  | (13 | ) |  |  | 42 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | (145 | ) |  |  | 45 |  |  |  | (100 | ) |  |  | 451 |  |  |  | (140 | ) |  |  | 311 |  |
| Foreign currency translation adjustment |  |  | (3,758 | ) |  |  | — |  |  |  | (3,758 | ) |  |  | (1,525 | ) |  |  | — |  |  |  | (1,525 | ) |
| Total Other Comprehensive Loss |  | $ | (5,119 | ) |  | $ | 337 |  |  | $ | (4,782 | ) |  | $ | (1,452 | ) |  | $ | (49 | ) |  | $ | (1,501 | ) |


## us-gaap:EarningsPerShareTextBlock

[0000950170-22-015058:notes:128]
14. EARNINGS PER SHARE

[0000950170-22-015058:notes:129]
The calculation of basic and diluted earnings per share is as follows:

[0000950170-22-015058:notes:130]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,143 |  |  | $ | 5,086 |  |  | $ | 1,016 |  |  | $ | 5,982 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 49,123 |  |  |  | 48,449 |  |  |  | 49,110 |  |  |  | 48,393 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 84 |  |  | 816 |  |  | 111 |  |  | 722 |  |
| PSUs, RSUs and restricted stock |  |  | 602 |  |  |  | 161 |  |  |  | 592 |  |  |  | 110 |  |
| Weighted average number of shares – diluted |  |  | 49,809 |  |  |  | 49,426 |  |  |  | 49,813 |  |  |  | 49,225 |  |
| Earnings per share – basic |  | $ | 0.04 |  |  | $ | 0.10 |  |  | $ | 0.02 |  |  | $ | 0.12 |  |
| Earnings per share – diluted |  | $ | 0.04 |  |  | $ | 0.10 |  |  | $ | 0.02 |  |  | $ | 0.12 |  |

[0000950170-22-015058:notes:131]
For the three months ended June 30, 2022 and 2021, 33 thousand and one thousand shares, respectively, and for the six months ended June 30, 2022 and 2021, eight thousand and three thousand, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0000950170-22-015058:notes:132]
For the three months ended June 30, 2022 and 2021, 0.2 million and 0.4 million stock options, respectively, and for the six months ended June 30, 2022 and 2021, 0.1 million and 0.6 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the applicable period, making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-22-015058:notes:133]
[same as prior period, unchanged from 0000950170-22-008077:notes:123]

[0000950170-22-015058:notes:134]
[same as prior period, unchanged from 0000950170-22-008077:notes:124]

[0000950170-22-015058:notes:135]
[same as prior period, unchanged from 0000950170-22-008077:notes:125]

[0000950170-22-015058:notes:136]
The following tables present information about the revenue and gross profit of our reportable segments:

[0000950170-22-015058:notes:137]
|  |  | Three Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 155,992 |  |  | $ | 56,071 |  |  | $ | 125,449 |  |  | $ | 55,435 |  |
| Services & Support |  |  | 16,046 |  |  |  | 6,435 |  |  |  | 17,783 |  |  |  | 7,233 |  |
| Total |  | $ | 172,038 |  |  | $ | 62,506 |  |  | $ | 143,232 |  |  | $ | 62,668 |  |

[0000950170-22-015058:notes:138]
|  |  | Six Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 294,366 |  |  | $ | 103,791 |  |  | $ | 239,258 |  |  | $ | 104,243 |  |
| Services & Support |  |  | 32,190 |  |  |  | 13,031 |  |  |  | 31,507 |  |  |  | 12,026 |  |
| Total |  | $ | 326,556 |  |  | $ | 116,822 |  |  | $ | 270,765 |  |  | $ | 116,269 |  |

[0000950170-22-015058:notes:139]
[same as prior period, unchanged from 0000950170-22-008077:notes:130]

[0000950170-22-015058:notes:140]
[same as prior period, unchanged from 0000950170-22-008077:notes:131]

[0000950170-22-015058:notes:141]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| United States |  | $ | 105,752 |  |  | $ | 94,656 |  |  | $ | 204,801 |  |  | $ | 181,141 |  |
| United Kingdom |  |  | 28,838 |  |  |  | 13,566 |  |  |  | 59,243 |  |  |  | 21,501 |  |
| Germany |  |  | 14,859 |  |  |  | 18,750 |  |  |  | 25,376 |  |  |  | 32,955 |  |
| Other international |  |  | 22,589 |  |  |  | 16,260 |  |  |  | 37,136 |  |  |  | 35,168 |  |
| Total |  | $ | 172,038 |  |  | $ | 143,232 |  |  | $ | 326,556 |  |  | $ | 270,765 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-22-015058:notes:142]
[same as prior period, unchanged from 0000950170-22-008077:notes:133]

[0000950170-22-015058:notes:143]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. The increasing complexity of our products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $4.8 million and $5.4 million as of June 30, 2022 and December 31, 2021, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. During the three months ended June 30, 2021, we had a net reversal of prior provisions related to warranty expirations the impact of which is reflected in the table below. The warranty expense and write-off activity for the three and six months ended June 30, 2022 and 2021 is summarized as follows:

[0000950170-22-015058:notes:144]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 5,143 |  |  | $ | 6,472 |  |  | $ | 5,403 |  |  | $ | 7,146 |  |
| Plus: Amounts charged to cost and expenses |  |  | 814 |  |  |  | 11 |  |  |  | 1,111 |  |  |  | (220 | ) |
| Less: Deductions |  |  | (1,115 | ) |  |  | (486 | ) |  |  | (1,672 | ) |  |  | (929 | ) |
| Balance at end of period |  | $ | 4,842 |  |  | $ | 5,997 |  |  | $ | 4,842 |  |  | $ | 5,997 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-22-015058:notes:145]
17. COMMITMENTS AND CONTINGENCIES

[0000950170-22-015058:notes:146]
Shareholder Derivative Lawsuit

[0000950170-22-015058:notes:147]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. Stanton, et al., Case No. 5:20-cv-00447, was filed in the U.S. District Court for the Northern District of Alabama against two of the Company’s current executive officers, one of its former executive officers, and certain current and former members of its Board of Directors, alleging, among other things, that the defendants made or caused the Company to make materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The plaintiff in the shareholder derivative suit sent a demand letter dated June 29, 2021 to ADTRAN’s Board of Directors. The letter contains similar allegations to those made in the plaintiff’s filed complaint and in the now dismissed securities class action, and it demands, among other things, that the Board of Directors commence an investigation into the alleged wrongdoing. On December 10, 2021, after investigating the allegations in the plaintiff’s demand with the assistance of independent counsel, the independent members of the Board of Directors concluded that pursuing the claims asserted in the demand would not be in the Company's best interests and exercised their business judgment to refuse the demand. The plaintiff subsequently dismissed the case. On February 25, 2022, the Court entered an order on the parties’ joint stipulation dismissing the case without prejudice.

[0000950170-22-015058:notes:148]
Other Legal Matters

[0000950170-22-015058:notes:149]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

[0000950170-22-015058:notes:150]
Performance Bonds

[0000950170-22-015058:notes:151]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2022 and December 31, 2021, we had commitments related to these bonds totaling $21.8 million and $22.9 million, respectively, which expire at various dates through April 2025. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-22-015058:notes:152]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. In conjunction with the Company entering into the revolving credit facility with Wells Fargo during the three months ended June 30, 2022, our obligation to maintain the pledged collateral was released.  This pledged collateral value fluctuated as the Company changed the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value was required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. For additional information on the Wells Fargo revolving credit facility see Note 12 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-22-015058:notes:153]
Investment Commitment

[0000950170-22-015058:notes:154]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of June 30, 2022.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-22-015058:notes:155]
[same as prior period, unchanged from 0000950170-22-008077:notes:152]

[0000950170-22-015058:notes:156]
[same as prior period, unchanged from 0000950170-22-008077:notes:153]

[0000950170-22-015058:notes:157]
[same as prior period, unchanged from 0000950170-22-008077:notes:154]

[0000950170-22-015058:notes:158]
The cumulative amount of restructuring expenses incurred as of June 30, 2022 for the restructuring plans was $12.7 million.

[0000950170-22-015058:notes:159]
[same as prior period, unchanged from 0000950170-22-008077:notes:156]

[0000950170-22-015058:notes:160]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (In thousands) |  | June 30, 2022 |  |  | June 30, 2022 |  |
| Balance at beginning of period |  | $ | 260 |  |  | $ | 1,514 |  |
| Plus: Amounts charged to cost and expense |  |  | — |  |  |  | 2 |  |
| Less: Amounts paid |  |  | (13 | ) |  |  | (1,269 | ) |
| Balance as of June 30, 2022 |  | $ | 247 |  |  | $ | 247 |  |

[0000950170-22-015058:notes:161]
|  |  | For the Year Ended |  |
| (In thousands) |  | December 31, 2021 |  |
| Balance as of December 31, 2020 |  | $ | 4,186 |  |
| Plus: Amounts charged to cost and expense |  |  | 411 |  |
| Less: Amounts paid |  |  | (3,083 | ) |
| Balance as of December 31, 2021 |  | $ | 1,514 |  |

[0000950170-22-015058:notes:162]
Restructuring expenses included in the Condensed Consolidated Statements of Income were as follows:

[0000950170-22-015058:notes:163]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Network Solutions - Cost of revenue |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 12 |  |
| Services & Support - Cost of revenue |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3 |  |
| Cost of revenue |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 15 |  |
| Selling, general and administrative expenses (1) |  |  | — |  |  |  | 3 |  |  |  | 2 |  |  |  | 145 |  |
| Research and development expenses (1) |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  | 149 |  |
| Total restructuring expenses |  | $ | — |  |  | $ | 8 |  |  | $ | 2 |  |  | $ | 309 |  |

[0000950170-22-015058:notes:164]
[same as prior period, unchanged from 0000950170-22-008077:notes:161]

[0000950170-22-015058:notes:165]
[same as prior period, unchanged from 0000950170-22-008077:notes:162]

[0000950170-22-015058:notes:166]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| United States |  | $ | — |  |  | $ | 3 |  |  | $ | 2 |  |  | $ | 212 |  |
| International |  |  | — |  |  |  | 5 |  |  |  | — |  |  |  | 97 |  |
| Total restructuring expenses |  | $ | — |  |  | $ | 8 |  |  | $ | 2 |  |  | $ | 309 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-22-015058:notes:167]
19. SUBSEQUENT EVENTS

[0000950170-22-015058:notes:168]
On August 3, 2022, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 18, 2022. The payment date will be September 1, 2022 in the aggregate amount of approximately $7.0 million.

[0000950170-22-015058:notes:169]
Closing of the Business Combination with ADVA

[0000950170-22-015058:notes:170]
As previously disclosed, on July 8, 2022, Acorn MergeCo, Inc. (“Merger Sub”), a Delaware corporation and wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (f/k/a Acorn HoldCo, Inc.) (the “Company”), merged with and into ADTRAN, Inc. (“ADTRAN”), with ADTRAN surviving the merger as a wholly-owned direct subsidiary of the Company (the “Merger”). The Merger was consummated pursuant to the Business Combination Agreement (the “Business Combination Agreement”), dated as of August 30, 2021, by and among the Company, ADTRAN, ADVA Optical Networking SE, a company organized and existing under the laws of Germany (“ADVA”), and Merger Sub.

[0000950170-22-015058:notes:171]
Pursuant to the Business Combination Agreement, the Company made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of common stock, par value $0.01 per share (the “Company Common Stock”), of the Company (the “Exchange Offer” and, together with the Merger, the “Business Combination”). The acceptance period for the Exchange Offer ended on February 14, 2022, and on July 6, 2022, the Company announced that all special offer conditions to the consummation of the Exchange Offer had been satisfied. The Exchange Offer was settled on July 15, 2022 (the “Exchange Offer Settlement Date”) in which the Company acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of Company Common Stock. Based on the Company's closing share price as of July 15, 2022 of $20.20, the value of the Company Common Stock provided in exchange for ADVA common stock was approximately $565.5 million.

[0000950170-22-015058:notes:172]
The issuance of shares of Company Common Stock in connection with the Business Combination was registered under the Securities Act of 1933, as amended (the “Securities Act”), pursuant to a registration statement on Form S-4 (the “Registration Statement”) (File No. 333-259251), which was declared effective by the U.S. Securities and Exchange Commission on December 2, 2021, and which included a proxy statement of ADTRAN for the special meeting of the stockholders of ADTRAN at which ADTRAN’s stockholders voted to adopt the Business Combination Agreement and that also constituted a prospectus for the Company (the “Proxy Statement”).

[0000950170-22-015058:notes:173]
The Company Common Stock is listed on the Nasdaq Global Select Market (“Nasdaq”) and trades under the symbol “ADTN”. The Company Common Stock was also approved for listing on the regulated market segment (regulierter Markt) of the Frankfurt Stock Exchange (Frankfurter Wertpapierbörse) with simultaneous admission to the sub-segment thereof with additional post-admission obligations (Prime Standard) on July 13, 2022 and trades there under the symbol “QH9”.

[0000950170-22-015058:notes:174]
For the three and six months ended June 30, 2022, the Company incurred $0.9 million and $1.8 million of transaction costs and were recognized as selling, general and administrative expense and research and development expense in our Condensed Consolidated Statements of Income, respectively. For the three and six months ended June 30, 2021, the Company incurred $2.4 million and $3.4 million of transaction costs and were recognized as selling, general and administrative expense and research and development expense in our Condensed Consolidated Statements of Income, respectively.

[0000950170-22-015058:notes:175]
We expect that the business combination will be accounted for using the acquisition method of accounting under ASC 805, with ADTRAN Holdings, Inc. representing the accounting acquirer under this guidance. Due to the timing of the acquisition subsequent to our June 30, 2022 reporting period end, the initial accounting, including the allocation of purchase price and supplemental pro forma information, is incomplete as of the filing date and, therefore, related disclosures are not included herein.

[0000950170-22-015058:notes:176]
Assumed ADVA Options

[0000950170-22-015058:notes:177]
Pursuant to the Business Combination which closed on July 15, 2022, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings. The maximum number of shares of ADTRAN Holdings stock potentially issuable upon such assumption was 2.1 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.0 million shares of ADTRAN Holdings stock are subject to assumed ADVA options. The fair value of the stock options assumed by ADTRAN Holdings will be estimated using a Black-Scholes model. Our valuation of this component of consideration is not yet complete.

[0000950170-22-015058:notes:178]
Wells Fargo Credit Agreement

[0000950170-22-015058:notes:179]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allows for borrowings of up to $100 million in aggregate principal amount, subject to being increased to up to $400 million in aggregate principal amount upon the Company or Borrower’s execution of a domination and profit and loss transfer agreement with ADVA or a parent of ADVA, among other conditions (the “Senior Credit Facilities Increase”).

[0000950170-22-015058:notes:180]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

[0000950170-22-015058:notes:181]
As of August 5, 2022, ADTRAN, Inc.’s borrowings under the revolving line of credit were $50.0 million. In addition, a $17.5 million letter of credit with ADTRAN, Inc. remains outstanding. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-22-015058:notes:182]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”).  All E.U. borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from  1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-22-015058:notes:183]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participations in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-22-015058:notes:184]
The Credit Agreement will mature on July 14, 2027, with the Company’s option to request extensions subject to customary conditions.  The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans).

[0000950170-22-015058:notes:185]
The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements.  It also contains customary events of default (subject to customary cure periods and materiality thresholds).

[0000950170-22-015058:notes:186]
Furthermore, the Credit Agreement requires that the Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not to exceed 3.25 to 1.00 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the Consolidated Interest Coverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00.

[0000950170-22-015058:notes:187]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.
