# ADTN MD&A — 0000950170-22-015058


## mdna

[0000950170-22-015058:mdna:1]
[same as prior period, unchanged from 0000950170-22-008077:mdna:1]

[0000950170-22-015058:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and the related notes that appear in Part I, Item 1 of this document.  In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2021, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1, Business, and Item 1A, Risk Factors, included in 2021 Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022.

[0000950170-22-015058:mdna:3]
[same as prior period, unchanged from 0000950170-22-008077:mdna:3]

[0000950170-22-015058:mdna:4]
Unless the context otherwise indicates or requires, references to “ADTRAN,” the “Company,” “we,” “us” and “our” refer to ADTRAN, Inc. and its consolidated affiliates prior to the merger of Acorn MergeCo, Inc. with and into ADTRAN, Inc. on July 8, 2022 (the “Merger”)  and to ADTRAN Holdings, Inc. and its consolidated subsidiaries following the Merger.

[0000950170-22-015058:mdna:5]
[same as prior period, unchanged from 0000950170-22-008077:mdna:4]

[0000950170-22-015058:mdna:6]
The Company is a leading global provider of networking and communications platforms, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, alternative service providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. In order to service our customers and grow revenue, we are continually conducting research and development of new products addressing customer needs and testing those products for the specific requirements of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have sales and research and development facilities in strategic global locations.

[0000950170-22-015058:mdna:7]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of ADVA Optical Networking SE (ADVA). ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. ADVA is a global telecommunications provider of network solutions for data, storage, voice, and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge. Additional information on each of the companies is provided below:

[0000950170-22-015058:mdna:8]
•
ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video, and internet communications across any network infrastructure. ADTRAN Inc.’s award-winning end-to-end fiber broadband solutions portfolio spans from OLTs to in-home services and intelligent SaaS solutions. These solutions empower communications service providers to manage and scale services to meet the needs of their customers. ADTRAN, Inc. serves customers in over 60 countries.

[0000950170-22-015058:mdna:9]
•
ADVA is a global provider of open networking solutions with over 25 years of experience in optical networking, carrier Ethernet access, and network synchronization. ADVA has led the industry for over two decades with open and secure networking solutions that carefully balance space, power, and cost. Founded in 1994 in Germany, ADVA has continually pushed the boundaries of innovation, working side-by-side with leading enterprises and service providers to develop technology that meets real-world demands. From open optical line systems, open terminals, and pluggable multiplexers to programmable cloud access, encryption, and precise timing, ADVA is committed to developing solutions that help its customers succeed.

[0000950170-22-015058:mdna:10]
BUSINESS COMBINATION WITH ADVA

[0000950170-22-015058:mdna:11]
On July 15, 2022, the Company settled a public offer to exchange each issued and outstanding no-par value bearer share of ADVA, in which each ADVA share tendered and accepted for exchange was exchanged for 0.8244 shares of common stock, par value $0.01 per share (the “Company Common Stock”), of ADTRAN Holdings, Inc. (the “Exchange Offer” and, together with the Merger, the “Business Combination”).  At the settlement of the Exchange Offer, the Company acquired 33,957,538 bearer shares of ADVA, or 65.43% of

[0000950170-22-015058:mdna:12]
ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of Company Common Stock.  As a result of the Business Combination, the Company has significantly increased its presence around the world with offices in more than 38 countries with approximately 3,486 employees worldwide. We believe that the combination of talent, industry-leading solution portfolios, and vision for innovation from both ADTRAN, Inc. and ADVA positions the Company as a global leader for service provider, government, and enterprise customers and will provide a firm foundation for our success moving forward.

[0000950170-22-015058:mdna:13]
The Company and ADVA have agreed to enter into negotiations regarding the conclusion of a domination agreement or a domination and profit and loss transfer agreement within the meaning of Sec. 291 para. 1 of the German Stock Corporation Act (Aktiengesetz) (a “DPLTA”), between ADVA, as the dominated entity, and the Company (or a to-be-established subsidiary of the Company), as dominating entity. The effectiveness of the DPLTA is intended to allow both companies to fully integrate and work towards achievement of operational synergy targets.

[0000950170-22-015058:mdna:14]
During the three months ended June 30, 2022, we recognized $0.9 million of transaction costs. We expect to incur an estimated $14.9 million of additional transaction costs related to the Business Combination and we will continue to incur integration costs and costs associated with the negotiation and implementation, if any, of a DPLTA, during the remainder of the year and such costs are expected to be material.  Since the Exchange Offer did not settle until July 15, 2022, the operations of ADVA were not included in our consolidated operating results for the three months ended June 30, 2022.

[0000950170-22-015058:mdna:15]
FINANCIAL PERFORMANCE AND TRENDS

[0000950170-22-015058:mdna:16]
We ended the second quarter of 2022 with a year-over-year revenue increase of 20.1% as compared to the three months ended June 30, 2021, driven by increased sales to Tier-1, Tier-2 and Tier-3 service providers. During the second quarter of 2022, we had three 10% revenue customers; two U.S. distributors and one U.S. service provider customer. Our year-over-year domestic revenue increased by 11.7%, driven by increased volume of network termination and Fiber CPE in our Network Solutions segment. Internationally, our revenue increased by 36.5% compared to the prior year period, primarily driven by increased shipments to a Tier-1 network operator and multiple alternative network operators in Europe. We experienced strong demand for our solutions in the first half of 2022 and achieved significant year-over-year bookings growth. Bookings are defined as orders received for a product or service during a fiscal period that will be delivered or performed sometime in the future and is a forward looking metric that we utilize to help us understand future revenue growth for the Company. Bookings are generally subject to modification and or cancellation per the terms of the order. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing nonbinding purchase commitments. Our increase in demand comes from service providers planning to deploy our fiber access platforms, in-home service delivery platforms and SaaS applications. We expect this growth to accelerate. During 2021 and continuing in 2022, we secured several Tier-1 next-generation fiber customers, and previously announced Tier-1 fiber customers significantly increased their bookings for our fiber access platforms. Although we expect our revenue growth and profitability in the near-term to continue to be negatively impacted by supply chain issues, our outlook continues to strengthen given the increased demand for our products and our expectation of an improving supply chain over the longer term.

[0000950170-22-015058:mdna:17]
In March 2020, the World Health Organization declared the novel coronavirus (COVID-19) outbreak a global pandemic. The SARS-CoV-2 coronavirus (or variants of the SARS-CoV-2 coronavirus) continues to spread throughout the U.S. and the world and has resulted in authorities implementing varying measures to contain the virus. Although vaccines have been approved and continue to be distributed, it cannot be predicted how long it will take before market conditions return to normal and there can be no assurance that the economic recovery will occur or offset the uncertainty and instability triggered by the pandemic. New and potentially more contagious variants of the COVID-19 virus may develop in various countries, including in regions in which we have significant operations. The COVID-19 variants could further amplify the impact of the pandemic. While we are unable to accurately predict the full impact that the COVID-19 global pandemic will have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time. We have experienced a significant impact to our supply chain given COVID-19 and the related global semiconductor chip shortage, including delays in supply chain deliveries, extended lead times and shortages of some key components, some raw material cost increases and slowdowns at certain production facilities. We have also had to increase our volume of inventory to ensure supply continuity during the pandemic. In addition, we have experienced significant increases in freight-related costs due to global shipping disruptions. Starting in the third quarter of 2021 and continuing into 2022, the Company has incurred supply chain constraint expenses, including price inflation for certain electronic components, semiconductor chips and transportation related costs, which have lowered our gross margins and decreased our profitability. While throughout the pandemic we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments, as well as COVID-19 related reductions in travel and infrastructure expenses, it is possible that we could experience some slowdown in demand, further supply chain issues and an increased impact from the ongoing semiconductor shortage and shortages of certain other key components as the pandemic continues. If the impacts of this shortage are more severe than we expect, it could result in longer lead times, inventory supply challenges and further increased costs, all of which could result in the deterioration of our results, potentially for a longer period than currently anticipated. To support the health and well-being of our employees, customers, partners and communities, many of our

[0000950170-22-015058:mdna:18]
35

[0000950170-22-015058:mdna:19]
employees are working remotely or on a hybrid schedule as of the date of filing this report. Additionally, there is risk that a number of our employees may become infected with COVID-19, including our key personnel. In addition, actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for certain employees, as well as the impacts to our supply chain, including delays in supply chain deliveries and the related global semiconductor chip shortage, have delayed and may continue to delay the timing of some orders and expected deliveries. Lastly, even after the COVID-19 pandemic has subsided, we may continue to experience adverse impacts to our business as a result of any economic recession that has occurred or may occur in the future as a result of the COVID-19 pandemic.

[0000950170-22-015058:mdna:20]
[same as prior period, unchanged from 0000950170-22-008077:mdna:8]

[0000950170-22-015058:mdna:21]
[same as prior period, unchanged from 0000950170-22-008077:mdna:9]

[0000950170-22-015058:mdna:22]
[same as prior period, unchanged from 0000950170-22-008077:mdna:10]

[0000950170-22-015058:mdna:23]
[same as prior period, unchanged from 0000950170-22-008077:mdna:11]

[0000950170-22-015058:mdna:24]
[same as prior period, unchanged from 0000950170-22-008077:mdna:12]

[0000950170-22-015058:mdna:25]
Our operating results have fluctuated, and may continue to fluctuate, on a quarterly basis due to several factors, including customer order activity, supply chain constraints, component availability, backlog and the Company's efforts to integrate with ADVA. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days requiring us to maintain higher inventory levels.  These factors normally result in a varying order backlog and limited order flow visibility; however, with the current global supply chain and transportation constraints, and limited availability of semiconductor chips and other components of our products, we have experienced and may continue to experience extended lead times, increased logistics intervals and costs, and lower volume of products deliveries, which has had and may continue to have a material adverse effect on our operating results and could have a material adverse effect on customer relations and our financial condition. Normal operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0000950170-22-015058:mdna:26]
We are exposed to changes in foreign currencies relative to the U.S. dollar, which are references to the differences between the foreign-exchanges rates we use to convert the financial results of our international operations from local currencies into U.S. dollars for financial reporting purposes. This impact of foreign-exchange rate changes is calculated based on the difference between the current period’s currency exchange rates and that of the comparable prior period. Our primary exposures to foreign currency exchange rate movements are with our European subsidiaries, whose functional currency is the Euro, our Australian subsidiary, whose functional currency is the Australian dollar, and our U.K. subsidiary, who transacts in the British pound sterling with a U.S. dollar functional currency. As a result of our global operations, our revenue, gross margins, operating expense and operating income in some international markets have been and may continue to be affected by foreign currency fluctuations.

[0000950170-22-015058:mdna:27]
[same as prior period, unchanged from 0000950170-22-008077:mdna:16]

[0000950170-22-015058:mdna:28]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that initially resulted from the COVID-19 pandemic and that may recur, foreign currency exchange rate movements, inflation, regional conflicts, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Specifically, we expect inflationary pressures on input costs, such as raw materials and labor, and distribution costs to increase. Our attempts to offset these cost pressures, such as through increases in the selling prices of some of our products and services, may not be successful and could negatively affect our operating results. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become

[0000950170-22-015058:mdna:29]
obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results. In recent years, the Company initiated restructuring plans to realign its expense structure with the reduction in revenue experienced and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and implemented certain cost savings initiatives, where possible. See Note 18 of the Notes to Condensed Consolidated Financial Statements included in Part 1, Item 1 of this report for additional information on this restructuring.

[0000950170-22-015058:mdna:30]
[same as prior period, unchanged from 0000950170-22-008077:mdna:18]

[0000950170-22-015058:mdna:31]
[same as prior period, unchanged from 0000950170-22-008077:mdna:26]

[0000950170-22-015058:mdna:32]
[same as prior period, unchanged from 0000950170-22-008077:mdna:27]

[0000950170-22-015058:mdna:33]
[same as prior period, unchanged from 0000950170-22-008077:mdna:28]

[0000950170-22-015058:mdna:34]
[same as prior period, unchanged from 0000950170-22-008077:mdna:29]

[0000950170-22-015058:mdna:35]
37

[0000950170-22-015058:mdna:36]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2022 COMPARED TO THE THREE AND SIX MONTHS ENDED JUNE 30, 2021

[0000950170-22-015058:mdna:37]
The following table presents selected financial information derived from our Condensed Consolidated Statements of Income  expressed as a percentage of revenue for the periods indicated. Amounts may not foot due to rounding.

[0000950170-22-015058:mdna:38]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 90.7 |  | % |  | 87.6 |  | % |  | 90.1 |  | % |  | 88.4 |  | % |
| Services & Support |  |  | 9.3 |  |  |  | 12.4 |  |  |  | 9.9 |  |  |  | 11.6 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 58.1 |  |  |  | 48.9 |  |  |  | 58.4 |  |  |  | 49.9 |  |  |
| Services & Support |  |  | 5.6 |  |  |  | 7.4 |  |  |  | 5.9 |  |  |  | 7.2 |  |  |
| Total Cost of Revenue |  |  | 63.7 |  |  |  | 56.2 |  |  |  | 64.2 |  |  |  | 57.1 |  |  |
| Gross Profit |  |  | 36.3 |  |  |  | 43.8 |  |  |  | 35.8 |  |  |  | 42.9 |  |  |
| Selling, general and administrative expenses |  |  | 16.2 |  |  |  | 21.5 |  |  |  | 17.1 |  |  |  | 21.5 |  |  |
| Research and development expenses |  |  | 15.4 |  |  |  | 19.5 |  |  |  | 16.2 |  |  |  | 20.5 |  |  |
| Operating Income |  |  | 4.7 |  |  |  | 2.7 |  |  |  | 2.5 |  |  |  | 1.0 |  |  |
| Interest and dividend income |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |
| Interest expense |  |  | (0.1 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Net investment (loss) gain |  |  | (2.7 | ) |  |  | 1.4 |  |  |  | (2.5 | ) |  |  | 1.1 |  |  |
| Other income, net |  |  | 0.4 |  |  |  | — |  |  |  | 0.1 |  |  |  | 0.7 |  |  |
| Income Before Income Taxes |  |  | 2.5 |  |  |  | 4.3 |  |  |  | 0.2 |  |  |  | 3.0 |  |  |
| Income tax (expense) benefit |  |  | (1.2 | ) |  |  | (0.8 | ) |  |  | 0.1 |  |  |  | (0.8 | ) |  |
| Net Income |  |  | 1.2 |  | % |  | 3.6 |  | % |  | 0.3 |  | % |  | 2.2 |  | % |

[0000950170-22-015058:mdna:39]
[same as prior period, unchanged from 0000950170-22-008077:mdna:33]

[0000950170-22-015058:mdna:40]
Our revenue increased 20.1% from $143.2 million for the three months ended June 30, 2021 to $172.0 million for the three months ended June 30, 2022 and increased 20.6% from $270.8 million for the six months ended June 30, 2021 to $326.6 million for the six months ended June 30, 2022. The increase in revenue for the three months ended June 30, 2022 was primarily attributable to a $30.3 million increase in Subscriber Solutions & Experience products partially offset by a $1.2 million decrease in Access & Aggregation revenue and a $0.3 million decrease in our Traditional & Other Products, respectively. The increase in revenue for the six months ended June 30, 2022 was attributable to a $30.4 million increase in Subscriber Solutions & Experience products, a $25.2 million increase in Access & Aggregation revenue and a $0.2 million increase in the revenue of our Traditional & Other Products, respectively. Although our revenue increased, supply of semiconductor chips and other components of our products has become constrained resulting in extended lead times and increased costs. Transportation constraints, including shortages for both air and surface freight, as well as labor shortages in the transportation industry, have also affected the timing and the cost of obtaining raw materials and production supplies. Although our revenue growth and profitability in the near-term may be impacted by these global supply chain issues, our longer term outlook continues to strengthen given our progress with new customer opportunities and the increased customer demand.

[0000950170-22-015058:mdna:41]
Network Solutions segment revenue increased 24.3% from $125.4 million for the three months ended June 30, 2021 to $156.0 million for the three months ended June 30, 2022 and increased 23.0% from $239.3 million for the six months ended June 30, 2021 to $294.4 million for the six months ended June 30, 2022. The increase in revenue for the three months ended June 30, 2022 was due primarily to revenue of Subscriber Solutions & Experience and Access & Aggregation products. The increase in revenue for the six months ended June 30, 2022 was due to all revenue categories. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0000950170-22-015058:mdna:42]
Services & Support segment revenue decreased 9.8% from $17.8 million for the three months ended June 30, 2021 to $16.0 million for the three months ended June 30, 2022 and increased 2.2% from $31.5 million for the six months ended June 30, 2021 to $32.2 million for the six months ended June 30, 2022. The decrease in revenue for the three months ended June 30, 2022 was primarily attributable to decreased revenue of Access & Aggregation products. The increase in revenue for the six months ended June 30, 2022 was primarily attributable to increased revenue of Subscriber Solutions & Experience products.

[0000950170-22-015058:mdna:43]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., increased by 36.5% from $48.6 million for the three months ended June 30, 2021 to $66.3 million for the three months ended June 30, 2022 and increased by 35.9% from $89.6 million for the six months ended June 30, 2021 to $121.8 million for the six months ended June 30, 2022. International revenue, as a percentage of total revenue, increased from 33.9% for the three months ended June 30, 2021 to 38.5% for the three months ended June 30, 2022 and increased from 33.1% for the six months ended June 30, 2021 to 37.3% for the six months ended June 30, 2022. The increase in percentage of international revenue for the three and six months ended June 30, 2022, was primarily driven by increased shipments to a Tier-1 network operator and multiple alternative network operators in Europe. For the three and six months ended June 30, 2022 as compared to the three and six months ended June 30, 2021, changes in foreign currencies relative to the U.S dollar decreased our net sales by approximately $6.5 million and $8.8 million, respectively.

[0000950170-22-015058:mdna:44]
[same as prior period, unchanged from 0000950170-22-008077:mdna:39]

[0000950170-22-015058:mdna:45]
[same as prior period, unchanged from 0000950170-22-008077:mdna:40]

[0000950170-22-015058:mdna:46]
As a percentage of revenue, cost of revenue increased from 56.2% for the three months ended June 30, 2021 to 63.7% for the three months ended June 30, 2022 and increased from 57.1% for the six months ended June 30, 2021 to 64.2% for the six months ended June 30, 2022. For the three and six months ended June 30, 2022, the increase was primarily attributable to supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift. For the three and six months ended June 30, 2022, as compared to the three and six months ended June 30, 2021, changes in foreign currencies relative to the U.S. dollar decreased our cost of revenue by approximately $2.5 million and $3.4 million, respectively.

[0000950170-22-015058:mdna:47]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 55.8% for the three months ended June 30, 2021 to 64.1% for the three months ended June 30, 2022 and increased from 56.4% for the six months ended June 30, 2021 to 64.7% for the six months ended June 30, 2022. The increase in cost of revenue as a percentage of revenue for the three and six months ended June 30, 2022 was primarily attributable to supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift.

[0000950170-22-015058:mdna:48]
Services & Support cost of revenue, as a percentage of that segment’s revenue, increased from 59.3% for the three months ended June 30, 2021 to 59.9% for the three months ended June 30, 2022 and decreased from 61.8% for the six months ended June 30, 2021 to 59.5% for the six months ended June 30, 2022. The fluctuation in cost of revenue as a percentage of revenue for the three and six months ended June 30, 2022 was primarily attributable to customer mix, changes in services and support mix.

[0000950170-22-015058:mdna:49]
[same as prior period, unchanged from 0000950170-22-008077:mdna:44]

[0000950170-22-015058:mdna:50]
[same as prior period, unchanged from 0000950170-22-008077:mdna:45]

[0000950170-22-015058:mdna:51]
As a percentage of revenue, selling, general and administrative expenses decreased from 21.5% for the three months ended June 30, 2021 to 16.2% for the three months ended June 30, 2022 and decreased from 21.5% for the six months ended June 30, 2021 to 17.1% for the six months ended June 30, 2022. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0000950170-22-015058:mdna:52]
Selling, general and administrative expenses decreased 9.7% from $30.9 million for the three months ended June 30, 2021 to $27.9 million for the three months ended June 30, 2022 and decreased 4.3% from $58.3 million for the six months ended June 30, 2021 to $55.8 million for the six months ended June 30, 2022. The decrease in selling, general and administrative expenses for the three months ended June 30, 2022 was primarily attributable to lower market driven expenses in our deferred compensation portfolio partially offset by increased salary and commission expenses and travel expense. The decrease in selling, general and administrative expenses for the six months ended June 30, 2022 was primarily attributable to lower in market driven expenses in our deferred compensation portfolio partially offset by increased salary and commission expenses, travel expense, acquisition expense and insurance expense. For the three and six months ended June 30, 2022 as compared to the three and six months ended June 30, 2021, changes in foreign currencies relative to the U.S dollar decreased our selling, general and administrative expenses by approximately $0.6 million and $1.0 million, respectively.

[0000950170-22-015058:mdna:53]
[same as prior period, unchanged from 0000950170-22-008077:mdna:48]

[0000950170-22-015058:mdna:54]
As a percentage of revenue, research and development expenses decreased from 19.5% for the three months ended June 30, 2021 to 15.4% for the three months ended June 30, 2022 and decreased from 20.5% for the six months ended June 30, 2021 to 16.2% for the  six months ended June 30, 2022. Research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0000950170-22-015058:mdna:55]
Research and development expenses decreased 4.9% from $27.9 million for the three months ended June 30, 2021 to $26.5 million for the three months ended June 30, 2022 and decreased 4.3% from $55.4 million for the six months ended June 30, 2021 to $53.0 million for the six months ended June 30, 2022. The decrease in research and development expenses for the three and six months ended June 30, 2022 was primarily attributable to contract services, lower labor, and depreciation expense. For the three and six months ended June 30, 2022 as compared to the three and six months ended June 30, 2021, changes in foreign currencies relative to the U.S. dollar decreased our research and development expenses by approximately $0.7 million and $1.1 million, respectively.

[0000950170-22-015058:mdna:56]
[same as prior period, unchanged from 0000950170-22-008077:mdna:52]

[0000950170-22-015058:mdna:57]
[same as prior period, unchanged from 0000950170-22-008077:mdna:53]

[0000950170-22-015058:mdna:58]
Interest and dividend income decreased 14.2% from $0.3 million for the three months ended June 30, 2021 to $0.2 million for the three months ended June 30, 2022 and decreased 22.5% from $0.5 million for the six months ended June 30, 2021 to $0.4 million for the six months ended June 30, 2022. Although the rate of return investments was up during the three and six month ended June 30, 2022, interest and dividend income was down due to a decrease in the investment balance. Our total long-term investments decreased from $82.8 million as of June 30, 2021 to $52.3 million as of June 30, 2022.

[0000950170-22-015058:mdna:59]
[same as prior period, unchanged from 0000950170-22-008077:mdna:55]

[0000950170-22-015058:mdna:60]
Interest expense was less than $0.1 million for the three months ended June 30, 2022 and $0.1 million for the six months ended June 30, 2022. Interest expense and was less than $0.1 million for each of the three and six months ended June 30, 2021. Interest expense during the three and six months ended June 30, 2022 was primarily related to our Revolving Credit Agreement. See Note 12 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-22-015058:mdna:61]
[same as prior period, unchanged from 0000950170-22-008077:mdna:57]

[0000950170-22-015058:mdna:62]
We recognized a net investment gain of $2.0 million and a net investment loss of $4.6 million for the three months ended June 30, 2021 and 2022, respectively and recognized a net investment gain of $3.0 million and a net investment loss of $8.1 million for the six months ended June 30, 2021 and 2022, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See Note 6 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-22-015058:mdna:63]
OTHER INCOME, NET

[0000950170-22-015058:mdna:64]
Other income, net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, increased from income of $26 thousand for the three months ended June 30, 2021 to income of $0.7 million for the three months ended June 30, 2022 and decreased from income of $2.0 million for the six months ended June 30, 2021 to income of $0.5 million for the six months ended June 30, 2022.

[0000950170-22-015058:mdna:65]
INCOME TAX EXPENSE (BENEFIT)

[0000950170-22-015058:mdna:66]
Our effective tax rate changed from an expense of 18.1% of pre-tax income for the three months ended June 30, 2021, to an expense of 50.1% of pre-tax income for the three months ended June 30, 2022 and changed from an expense of 26.7% of pre-tax income for the six months ended June 30, 2021, to a benefit of 34.3% of pre-tax income for the six months ended June 30, 2022. The change in the effective tax rate for the three and six months ended June 30, 2022, was driven primarily by a change in our annual estimated tax rate as a result of the requirement to begin capitalizing research and development expenses for U.S. tax purposes beginning in 2022 as previously passed as part of the Tax Cuts and Jobs Act in December 2017 and the associated impact of those changes on our previously established valuation allowance. See Note 4 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information

[0000950170-22-015058:mdna:67]
NET INCOME

[0000950170-22-015058:mdna:68]
As a result of the above factors, net income decreased from net income of $5.1 million for the three months ended June 30, 2021 to a net income of $2.1 million for the three months ended June 30, 2022 and decreased from net income of $6.0 million for the six months ended June 30, 2021 to a net income of $1.0 million for the six months ended June 30, 2022.

[0000950170-22-015058:mdna:69]
[same as prior period, unchanged from 0000950170-22-008077:mdna:65]

[0000950170-22-015058:mdna:70]
[same as prior period, unchanged from 0000950170-22-008077:mdna:66]

[0000950170-22-015058:mdna:71]
We have historically financed, our ongoing business with existing cash, investments and cash flow from operations. In the current supply environment we also expect to utilize our credit arrangements to manage our working capital needs. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures. As of June 30, 2022, ADTRAN has incurred $8.7 million of transaction costs related to the Business Combination and expects to incur an estimated $14.9 million of additional transaction costs related to the Business Combination. We believe that our cash and cash equivalents, investments, cash generated from operations and access to funds under the new Wells Fargo credit facility (described below) will be adequate to meet our operating and capital needs for at least the next 12 months.

[0000950170-22-015058:mdna:72]
As of June 30, 2022, cash on hand was $43.3 million and short-term investments were $1.8 million, which resulted in available short-term liquidity of $45.1 million, of which $27.0 million was held by our foreign subsidiaries. As of December 31, 2021, cash on hand was $56.6 million and short-term investments were $0.4 million, which resulted in available short-term liquidity of $57.0 million, of which $47.7 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax.

[0000950170-22-015058:mdna:73]
[same as prior period, unchanged from 0000950170-22-008077:mdna:69]

[0000950170-22-015058:mdna:74]
Net cash used in operating activities of $5.9 million during the six months ended June 30, 2022 decreased by $24.1 million compared to net cash provided of $18.2 million during the six months ended June 30, 2021. This decrease was primarily due to net cash outflows from working capital, specifically, an inventory build related to component availability and an increase in accounts receivables partially offset by an increase in the average number of days payable to our trade suppliers. Additional details related to our working capital and its drivers are discussed below.

[0000950170-22-015058:mdna:75]
Net accounts receivable increased 8.4% from $158.7 million as of December 31, 2021 to $172.1 million as of June 30, 2022. There was no allowance for credit losses as of June 30, 2022 and December 31, 2021. The increase in net accounts receivable was due primarily to an increase in sales volume. Quarterly accounts receivable DSO decreased from 95 days as of December 31, 2021 to 91 days as of June 30, 2022. The decrease in DSO was due to customer and geographical mix and timing of sales within the quarter.

[0000950170-22-015058:mdna:76]
Other receivables decreased 25.1% from $11.2 million as of December 31, 2021 to $8.4 million as of June 30, 2022. The decrease in other receivables was primarily attributable to the decrease in our receivables for sales of raw materials and duty drawbacks partially offset by an increase in contract assets.

[0000950170-22-015058:mdna:77]
Quarterly inventory turnover was 3.0 turns as of December 31, 2021 and 2.4 turns as of June 30, 2022, respectively. Inventory increased 40.8% from $139.9 million as of December 31, 2021 to $196.9 million as of June 30, 2022. The increase in inventory was due to strategic inventory buffer purchases given extended component lead times and availability constraints as well as new product ramp ups to ensure supply continuity during the COVID-19 pandemic. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to COVID-19 uncertainties related to supply chain and supply, seasonal cycles of our business and ensuring competitive lead times while managing the risk of inventory.

[0000950170-22-015058:mdna:78]
Accounts payable increased 40.9% from $102.5 million as of December 31, 2021 to $144.4 million as of June 30, 2022. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases. The significant increase in the first half of 2022 was due to additional purchases of raw material inventory.

[0000950170-22-015058:mdna:79]
[same as prior period, unchanged from 0000950170-22-008077:mdna:75]

[0000950170-22-015058:mdna:80]
Capital expenditures totaled approximately $3.3 million and $2.2 million for the six months ended June 30, 2022 and 2021, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements.

[0000950170-22-015058:mdna:81]
Our combined short-term and long-term investments decreased $16.9 million from $71.0 million as of December 31, 2021 to $54.1 million as of June 30, 2022. This decrease reflects the impact of net unrealized and realized gains and losses on our investments as well as the sale of a portion of our equity investments.

[0000950170-22-015058:mdna:82]
[same as prior period, unchanged from 0000950170-22-008077:mdna:78]

[0000950170-22-015058:mdna:83]
As of June 30, 2022, our corporate bonds, municipal bonds, asset-backed bonds, mortgage/agency bonds, U.S. government bonds, other government bonds and variable-rate demand notes were classified as available-for-sale and had a combined duration of 1.75 years with an average Standard & Poor’s credit rating of AA-. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0000950170-22-015058:mdna:84]
Our long-term investments decreased 25.9% from $70.6 million as of December 31, 2021 to $52.3 million as of June 30, 2022.  Our investments include various marketable equity securities classified as long-term investments with a fair market value of $0.9 million and $12.6 million as of June 30, 2022 and December 31, 2021, respectively. Long-term investments as of June 30, 2022 and December 31, 2021 also included $22.6 million and $26.9 million, respectively, related to our deferred compensation plans.

[0000950170-22-015058:mdna:85]
[same as prior period, unchanged from 0000950170-22-008077:mdna:81]

[0000950170-22-015058:mdna:86]
[same as prior period, unchanged from 0000950170-22-008077:mdna:86]

[0000950170-22-015058:mdna:87]
During the six month periods ended June 30, 2022 and 2021, we paid dividends totaling $8.9 million and $8.7 million, respectively. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0000950170-22-015058:mdna:88]
[same as prior period, unchanged from 0000950170-22-008077:mdna:88]

[0000950170-22-015058:mdna:89]
To accommodate employee stock option exercises, the Company issued four thousand and 0.1 million shares of treasury stock which resulted in proceeds of $0.1 million and $2.3 million during the three months ended June 30, 2022 and 2021, respectively and issued 37 thousand and 0.2 million shares of treasury stock which resulted in proceeds of $0.6 million and $3.6 million during the six months ended June 30, 2022 and 2021, respectively.

[0000950170-22-015058:mdna:90]
[same as prior period, unchanged from 0000950170-22-008077:mdna:90]

[0000950170-22-015058:mdna:91]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0000950170-22-015058:mdna:92]
[same as prior period, unchanged from 0000950170-22-008077:mdna:92]

[0000950170-22-015058:mdna:93]
New Wells Fargo Credit Agreement

[0000950170-22-015058:mdna:94]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allows for borrowings of up to $100 million in aggregate principal amount, subject to being increased to up to $400 million in aggregate principal amount upon the Company or Borrower’s execution of a domination and profit and loss transfer agreement with ADVA or a parent of ADVA, among other conditions (the “Senior Credit Facilities Increase”).

[0000950170-22-015058:mdna:95]
The Credit Agreement replaced ADTRAN, Inc.’s prior credit agreements with the Administrative Agent and Cadence Bank, N.A. entered into on April 1, 2022 and November 4, 2020, respectively. In connection with the entry into the Credit Agreement, all outstanding borrowings under such prior credit agreements have been repaid and the agreements terminated. As of August 5, 2022, ADTRAN, Inc.’s borrowings under the revolving line of credit were $50.0 million. In addition, a $17.5 million letter of credit with ADTRAN, Inc. remains outstanding. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-22-015058:mdna:96]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”).  All E.U. borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”).  The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement.  Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-22-015058:mdna:97]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participations in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-22-015058:mdna:98]
The Credit Agreement will mature on July 18, 2027, with the Company’s option to request extensions subject to customary conditions.  The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans).

[0000950170-22-015058:mdna:99]
The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage

[0000950170-22-015058:mdna:100]
in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements.  It also contains customary events of default (subject to customary cure periods and materiality thresholds).

[0000950170-22-015058:mdna:101]
Furthermore, the Credit Agreement requires that the Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the Consolidated Interest Coverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00.

[0000950170-22-015058:mdna:102]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative

[0000950170-22-015058:mdna:103]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2022 and December 31, 2021, we had commitments related to these bonds totaling $21.8 million and $22.9 million, respectively, which expire at various dates through April 2025. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-22-015058:mdna:104]
Under the Business Combination Agreement, the Company will bear the transaction costs of the Business Combination attributable to ADTRAN Holding, Inc. (formerly known as Acorn HoldCo, Inc.) and the Company. As of June 30, 2022, ADTRAN has incurred $8.7 million of transaction costs related to the Business Combination and expects to incur an estimated $14.9 million of additional transaction costs related to the Business Combination.

[0000950170-22-015058:mdna:105]
In June 2020, we entered into a letter of credit with a bank to guarantee performance obligations under a contract with a customer. In conjunction with the Company entering into the revolving credit facility with Wells Fargo during the three months ended June 30, 2022, our obligation to maintain $15.0 million in pledged collateral was released. For additional information on the Wells Fargo revolving credit facility see Note 12 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-22-015058:mdna:106]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of June 30, 2022.

[0000950170-22-015058:mdna:107]
During the six months ended June 30, 2022, there have been no other material changes in cash requirements from those discussed in the 2021 Form 10-K. However, the Company anticipates that our commitments and contingencies will increase significantly due to the day-to-day business obligations of ADVA as a result of the Business Combination that closed on July 15, 2022.
