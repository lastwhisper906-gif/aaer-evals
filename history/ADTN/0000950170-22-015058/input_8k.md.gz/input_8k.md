# ADTN 8-K — 0000950170-22-014476 filed 2022-08-04

## item codes, every 8-K on or before 2022-08-05

- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2022-08-05

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-22-014476:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0000950170-22-014476:8k_2_02:2]
EX-99.1

[0000950170-22-014476:8k_2_02:3]
EXHIBIT 99.1

[0000950170-22-014476:8k_2_02:4]
ADTRAN Holdings, Inc. Reports Earnings for the Second Quarter of 2022 and Declares Quarterly Cash Dividend

[0000950170-22-014476:8k_2_02:5]
HUNTSVILLE, Ala. — (August 3, 2022) — ADTRAN Holdings, Inc., (NASDAQ: ADTN) (“ADTRAN” or the “Company”), today announced financial results for the second quarter of 2022. For the quarter, revenue was $172.0 million. Net income for the second quarter of 2022 was $2.1 million and earnings per share was $0.04. Non-GAAP net income was $9.7 million and non-GAAP earnings per share was $0.19. Non-GAAP net income and non-GAAP earnings per share exclude stock-based compensation expense, acquisition related expenses, amortizations and adjustments, restructuring expenses, amortization of pension actuarial losses, deferred compensation related adjustments, change in valuation allowance related to our deferred tax assets, and the tax effect of these adjustments to net income. The reconciliations between GAAP net income and earnings per share to non-GAAP net income and non-GAAP earnings per share are set forth in the table provided below.

[0000950170-22-014476:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “We had a strong Q2 fueled by the growing demand for our fiber broadband platforms. Customer demand continues to grow at record levels. We increased revenue both quarter-over-quarter and year-over-year in our domestic and international markets, and also throughout our customer segments. This provides continued momentum as we move forward with our integration of ADVA. The combination of these two companies will strengthen our overall solution portfolio and provide the resources necessary to maximize our success in this unprecedented investment cycle in fiber networks.”

[0000950170-22-014476:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the second quarter of 2022. The quarterly cash dividend of $0.09 per common share is to be paid to the Company’s stockholders of record as of the close of business on August 18, 2022. The ex-dividend date is August 17, 2022 and the payment date will be September 1, 2022.

[0000950170-22-014476:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its second quarter results on Thursday, August 4, 2022, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, simply visit ADTRAN’s Investor Relations site at www.adtran.com/investor approximately ten minutes prior to the start of the call, click on the event “ADTRAN Holdings Releases 2nd Quarter 2022 Financial Results and Earnings Call”, and click on the Webcast link.

[0000950170-22-014476:8k_2_02:9]
An online replay of the Company’s conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or email at investor.relations@adtran.com.

[0000950170-22-014476:8k_2_02:10]
About ADTRAN Holdings, Inc.

[0000950170-22-014476:8k_2_02:11]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. (Adtran) and is the majority shareholder of ADVA Optical Networking SE (ADVA).  Adtran is a leading global provider of open, disaggregated networking and communications solutions. ADVA is a global optical networking solutions provider focused on cloud interconnect, cloud access and network synchronization. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge. Learn more on Adtran.com, LinkedIn, and Twitter.

[0000950170-22-014476:8k_2_02:12]
Unless the context otherwise indicates or requires, references in this press release and the accompanying financial information to  “ADTRAN,” the “Company,” “we,” “us” and “our” refer to (i) ADTRAN, Inc. and its consolidated affiliates prior to the merger on July 8, 2022 of Acorn MergeCo, Inc. (“Merger Sub”), a Delaware corporation and wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (f/k/a Acorn HoldCo), with and into ADTRAN, Inc., as part of ADTRAN’s business combination transaction with ADVA, and (ii) ADTRAN Holdings, Inc. and its consolidated subsidiaries following the Merger.

[0000950170-22-014476:8k_2_02:13]
Cautionary Note Regarding Forward-Looking Statements

[0000950170-22-014476:8k_2_02:14]
This press release contains forward-looking statements, generally identified by the use of words such as “believe,” “expect,” “intend,” “estimate,” “anticipate,” “will,” “may,” “could” and similar expressions, which forward-looking statements reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including: (i) risks and uncertainties related to the continued impact of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (including variants of the SARS-CoV-2 coronavirus), including with respect to continued manufacturing and supply chain constraints; (ii) regulatory or other limitations imposed following the closing of the Company’s business combination with ADVA on July 15, 2022; the success of the combined ADTRAN and ADVA businesses following the business combination; the ability to successfully integrate the ADTRAN and ADVA businesses; risks related to disruption of management time from ongoing business operations due to integration efforts following the business combination; the risk that the publicity surrounding the business combination could have adverse effects on the market

[0000950170-22-014476:8k_2_02:15]
price of ADTRAN’s common stock or ADVA’s common shares or the ability of ADTRAN and ADVA to retain customers, retain or hire key personnel, maintain relationships with their respective suppliers and customers, and on their operating results and businesses generally; the risk that ADTRAN Holdings may be unable to achieve expected synergies or that it may take longer or be more costly than expected to achieve those synergies; the risk of fluctuations in revenue due to lengthy sales and approval process required by major and other service providers for new products; the risk posed by potential breaches of information systems and cyber-attacks; the risks that ADTRAN, ADVA or ADTRAN Holdings may not be able to effectively compete, including through product improvements and development, and (iii) the other risks set forth in ADVA’s annual and interim financial reports made publicly available and ADTRAN’s and ADTRAN Holdings’ public filings made with the Securities and Exchange Commission, including ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2021 and ADTRAN’s Form 10-Q for the quarterly period ended March 31, 2022. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0000950170-22-014476:8k_2_02:16]
To provide additional transparency, we have disclosed in the tables below non-GAAP operating income, which has been reconciled to operating income, and non-GAAP net income and non-GAAP earnings per share - basic and diluted, which have been reconciled to net income and earnings per share - basic and diluted, in each case as reported based on Generally Accepted Accounting Principles in the United States (“U.S. GAAP”). These non-GAAP financial measures exclude certain items which management believes are not reflective of the ongoing operating performance of the business. We believe this information is useful in providing period-to-period comparisons of the results of our ongoing operations. Additionally, these measures are used by management in our ongoing planning and annual budgeting processes. We believe the presentation of non-GAAP operating income, non-GAAP net income and non-GAAP earnings per share - basic and diluted, when combined with the U.S. GAAP presentation of operating income, net income and earnings per share - basic and diluted, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0000950170-22-014476:8k_2_02:17]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, U.S. GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under U.S. GAAP. Additionally, our calculation of non-GAAP operating income, non-GAAP net income and non-GAAP earnings per share - basic and diluted, may not be comparable to similar measures calculated by other companies.

[0000950170-22-014476:8k_2_02:18]
Investor Services/Assistance:

[0000950170-22-014476:8k_2_02:19]
Rhonda Lambert/256-963-7450

[0000950170-22-014476:8k_2_02:20]
investor@adtran.com

[0000950170-22-014476:8k_2_02:21]
Condensed Consolidated Balance Sheets

[0000950170-22-014476:8k_2_02:22]
(Unaudited)

[0000950170-22-014476:8k_2_02:23]
(In thousands)

[0000950170-22-014476:8k_2_02:24]
|  | June 30, |  |  | December 31, |  |
|  | 2022 |  |  | 2021 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 43,368 |  |  | $ | 56,603 |  |
| Restricted cash |  | — |  |  |  | 215 |  |
| Short-term investments |  | 1,773 |  |  |  | 350 |  |
| Accounts receivable, net |  | 172,088 |  |  |  | 158,742 |  |
| Other receivables |  | 8,413 |  |  |  | 11,228 |  |
| Inventory, net |  | 196,916 |  |  |  | 139,891 |  |
| Prepaid expenses and other current assets |  | 9,306 |  |  |  | 9,296 |  |
| Total Current Assets |  | 431,864 |  |  |  | 376,325 |  |
| Property, plant and equipment, net |  | 53,432 |  |  |  | 55,766 |  |
| Deferred tax assets, net |  | 8,508 |  |  |  | 9,079 |  |
| Goodwill |  | 6,968 |  |  |  | 6,968 |  |
| Intangibles, net |  | 17,473 |  |  |  | 19,293 |  |
| Other non-current assets |  | 29,637 |  |  |  | 30,971 |  |
| Long-term investments |  | 52,297 |  |  |  | 70,615 |  |
| Total Assets | $ | 600,179 |  |  | $ | 569,017 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 144,432 |  |  | $ | 102,489 |  |
| Unearned revenue |  | 22,705 |  |  |  | 17,737 |  |
| Accrued expenses and other liabilities |  | 16,759 |  |  |  | 13,673 |  |
| Accrued wages and benefits |  | 13,276 |  |  |  | 14,900 |  |
| Income tax payable, net |  | 4,541 |  |  |  | 6,560 |  |
| Total Current Liabilities |  | 201,713 |  |  |  | 155,359 |  |
| Non-current unearned revenue |  | 10,133 |  |  |  | 9,271 |  |
| Pension liability |  | 9,889 |  |  |  | 11,402 |  |
| Deferred compensation liability |  | 26,014 |  |  |  | 31,383 |  |
| Other non-current liabilities |  | 3,893 |  |  |  | 4,500 |  |
| Total Liabilities |  | 251,642 |  |  |  | 211,915 |  |
| Stockholders' Equity |  | 348,537 |  |  |  | 357,102 |  |
| Total Liabilities and Stockholders' Equity | $ | 600,179 |  |  | $ | 569,017 |  |

[0000950170-22-014476:8k_2_02:25]
Condensed Consolidated Statements of Income

[0000950170-22-014476:8k_2_02:26]
(Unaudited)

[0000950170-22-014476:8k_2_02:27]
(In thousands, except per share data)

[0000950170-22-014476:8k_2_02:28]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 155,992 |  |  | $ | 125,449 |  |  | $ | 294,366 |  |  | $ | 239,258 |  |  |
| Services & Support |  |  | 16,046 |  |  |  | 17,783 |  |  |  | 32,190 |  |  |  | 31,507 |  |  |
| Total Revenue |  |  | 172,038 |  |  |  | 143,232 |  |  |  | 326,556 |  |  |  | 270,765 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 99,921 |  |  |  | 70,014 |  |  |  | 190,575 |  |  |  | 135,015 |  |  |
| Services & Support |  |  | 9,611 |  |  |  | 10,550 |  |  |  | 19,159 |  |  |  | 19,481 |  |  |
| Total Cost of Revenue |  |  | 109,532 |  |  |  | 80,564 |  |  |  | 209,734 |  |  |  | 154,496 |  |  |
| Gross Profit |  |  | 62,506 |  |  |  | 62,668 |  |  |  | 116,822 |  |  |  | 116,269 |  |  |
| Selling, general and administrative expenses |  |  | 27,873 |  |  |  | 30,866 |  |  |  | 55,766 |  |  |  | 58,301 |  |  |
| Research and development expenses |  |  | 26,500 |  |  |  | 27,871 |  |  |  | 52,991 |  |  |  | 55,372 |  |  |
| Operating Income |  |  | 8,133 |  |  |  | 3,931 |  |  |  | 8,065 |  |  |  | 2,596 |  |  |
| Interest and dividend income |  |  | 217 |  |  |  | 253 |  |  |  | 421 |  |  |  | 543 |  |  |
| Interest expense |  |  | (94 | ) |  |  | (6 | ) |  |  | (124 | ) |  |  | (12 | ) |  |
| Net investment (loss) gain |  |  | (4,646 | ) |  |  | 2,009 |  |  |  | (8,061 | ) |  |  | 3,005 |  |  |
| Other income, net |  |  | 681 |  |  |  | 26 |  |  |  | 455 |  |  |  | 2,025 |  |  |
| Income Before Income Taxes |  |  | 4,291 |  |  |  | 6,213 |  |  |  | 756 |  |  |  | 8,157 |  |  |
| Income tax (expense) benefit |  |  | (2,148 | ) |  |  | (1,127 | ) |  |  | 260 |  |  |  | (2,175 | ) |  |
| Net Income |  | $ | 2,143 |  |  | $ | 5,086 |  |  | $ | 1,016 |  |  | $ | 5,982 |  |  |
| Weighted average shares outstanding – basic |  |  | 49,123 |  |  |  | 48,449 |  |  |  | 49,110 |  |  |  | 48,393 |  |  |
| Weighted average shares outstanding – diluted |  |  | 49,809 |  | (1) |  | 49,426 |  | (1) |  | 49,813 |  | (1) |  | 49,225 |  | (1) |
| Earnings per common share – basic |  | $ | 0.04 |  |  | $ | 0.10 |  |  | $ | 0.02 |  |  | $ | 0.12 |  |  |
| Earnings per common share – diluted |  | $ | 0.04 |  | (1) | $ | 0.10 |  | (1) | $ | 0.02 |  | (1) | $ | 0.12 |  | (1) |

[0000950170-22-014476:8k_2_02:29]
(1) Assumes exercise of dilutive stock awards calculated under the treasury stock method.

[0000950170-22-014476:8k_2_02:30]
Condensed Consolidated Statements of Cash Flows

[0000950170-22-014476:8k_2_02:31]
(Unaudited)

[0000950170-22-014476:8k_2_02:32]
(In thousands)

[0000950170-22-014476:8k_2_02:33]
|  |  | Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 1,016 |  |  | $ | 5,982 |  |
| Adjustments to reconcile net income to net cash (used in) provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 7,235 |  |  |  | 8,232 |  |
| Loss (gain) on investments |  |  | 7,882 |  |  |  | (3,255 | ) |
| Stock-based compensation expense |  |  | 3,781 |  |  |  | 3,615 |  |
| Deferred income taxes |  |  | (93 | ) |  |  | 441 |  |
| Other, net |  |  | 27 |  |  |  | 53 |  |
| Inventory reserves |  |  | (4,296 | ) |  |  | (3,167 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (14,315 | ) |  |  | (24,322 | ) |
| Other receivables |  |  | 2,606 |  |  |  | 1,412 |  |
| Inventory |  |  | (53,982 | ) |  |  | 9,107 |  |
| Prepaid expenses, other current assets and other assets |  |  | 671 |  |  |  | (4,767 | ) |
| Accounts payable |  |  | 42,968 |  |  |  | 16,814 |  |
| Accrued expenses and other liabilities |  |  | 2,179 |  |  |  | 6,999 |  |
| Income taxes payable, net |  |  | (1,597 | ) |  |  | 1,069 |  |
| Net cash (used in) provided by operating activities |  |  | (5,918 | ) |  |  | 18,213 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (3,285 | ) |  |  | (2,210 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 25,071 |  |  |  | 20,597 |  |
| Purchases of available-for-sale investments |  |  | (17,002 | ) |  |  | (20,121 | ) |
| Net cash provided by (used in) investing activities |  |  | 4,784 |  |  |  | (1,734 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (333 | ) |  |  | (113 | ) |
| Proceeds from stock option exercises |  |  | 636 |  |  |  | 3,552 |  |
| Dividend payments |  |  | (8,877 | ) |  |  | (8,735 | ) |
| Proceeds from draw on line of credit |  |  | 28,000 |  |  |  | — |  |
| Repayment of line of credit |  |  | (28,000 | ) |  |  | — |  |
| Net cash used in financing activities |  |  | (8,574 | ) |  |  | (5,296 | ) |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  |  | (9,708 | ) |  |  | 11,183 |  |
| Effect of exchange rate changes |  |  | (3,742 | ) |  |  | (1,381 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  |  | 56,818 |  |  |  | 60,179 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 43,368 |  |  | $ | 69,981 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 552 |  |  | $ | 275 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 818 |  |  | $ | 144 |  |

[0000950170-22-014476:8k_2_02:34]
Supplemental Information

[0000950170-22-014476:8k_2_02:35]
Reconciliation of Operating Income to Non-GAAP Operating Income

[0000950170-22-014476:8k_2_02:36]
(Unaudited)

[0000950170-22-014476:8k_2_02:37]
|  |  | Three Months Ended June 30, |  |  |  | Six Months ended June 30, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |  | 2022 |  |  | 2021 |  |  |
| Operating Income |  | $ | 8,133 |  |  | $ | 3,931 |  |  |  | $ | 8,065 |  |  | $ | 2,596 |  |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | 2,123 |  | (1) |  | 2,384 |  | (4) |  |  | 4,453 |  | (7) |  | 3,429 |  | (10) |
| Stock-based compensation expense |  |  | 1,888 |  | (2) |  | 1,808 |  | (5) |  |  | 3,781 |  | (8) |  | 3,615 |  | (11) |
| Restructuring expenses |  |  | — |  |  |  | 8 |  | (6) |  |  | 2 |  | (9) |  | 309 |  | (12) |
| Deferred compensation adjustments |  |  | (3,737 | ) | (3) |  | 1,994 |  | (3) |  |  | (6,433 | ) | (3) |  | 2,550 |  | (3) |
| Non-GAAP Operating Income |  | $ | 8,407 |  |  | $ | 10,125 |  |  |  | $ | 9,868 |  |  | $ | 12,499 |  |  |

[0000950170-22-014476:8k_2_02:38]
(1) $1.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:39]
(2) $0.2 million is included in total cost of revenue, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:40]
(3)Includes non-cash change in fair value of equity investments held in the ADTRAN, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of income.

[0000950170-22-014476:8k_2_02:41]
(4) $1.9 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:42]
(5) $0.1 million is included in total cost of revenue, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:43]
(6) Less than $0.1 million is included in selling, general and administrative expenses and research and development expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:44]
(7) $3.5 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:45]
(8) $0.3 million is included in total cost of revenue, $2.3 million is included in selling, general and administrative expenses and $1.2 million is included in research and development expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:46]
(9) Less than $0.1 million is included in selling, general and administrative expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:47]
(10) $2.4 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:48]
(11) $0.2 million is included in total cost of revenue, $2.2 million is included in selling, general and administrative expenses and $1.2 million is included in research and development expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:49]
(12) $0.1 million is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of income.

[0000950170-22-014476:8k_2_02:50]
Supplemental Information

[0000950170-22-014476:8k_2_02:51]
Reconciliation of Net Income and Earnings per Common Share – Basic and Diluted to

[0000950170-22-014476:8k_2_02:52]
Non-GAAP Net Income and Non-GAAP Earnings per Common Share – Basic and Diluted

[0000950170-22-014476:8k_2_02:53]
(Unaudited)

[0000950170-22-014476:8k_2_02:54]
|  |  | Three Months Ended June 30, |  |  |  | Six Months ended June 30, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |  | 2022 |  |  | 2021 |  |  |
| Net Income |  | $ | 2,143 |  |  | $ | 5,086 |  |  |  | $ | 1,016 |  |  | $ | 5,982 |  |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | 2,123 |  |  |  | 2,384 |  |  |  |  | 4,453 |  |  |  | 3,429 |  |  |
| Stock-based compensation expense |  |  | 1,888 |  |  |  | 1,808 |  |  |  |  | 3,781 |  |  |  | 3,615 |  |  |
| Restructuring expenses |  |  | - |  |  |  | 8 |  |  |  |  | 2 |  |  |  | 309 |  |  |
| Deferred compensation adjustments(1) |  |  | (140 | ) |  |  | 546 |  |  |  |  | (995 | ) |  |  | 814 |  |  |
| Pension expense(2) |  |  | 85 |  |  |  | 275 |  |  |  |  | 174 |  |  |  | 553 |  |  |
| Valuation allowance related to deferred tax assets |  |  | 4,289 |  |  |  | (727 | ) |  |  |  | 12,368 |  |  |  | 1,958 |  |  |
| Tax effect of adjustments to net income |  |  | (680 | ) |  |  | (1,243 | ) |  |  |  | (1,185 | ) |  |  | (2,195 | ) |  |
| Non-GAAP Net Income |  | $ | 9,708 |  |  | $ | 8,137 |  |  |  | $ | 19,614 |  |  | $ | 14,465 |  |  |
| Weighted average shares outstanding – basic |  |  | 49,123 |  |  |  | 48,449 |  |  |  |  | 49,110 |  |  |  | 48,393 |  |  |
| Weighted average shares outstanding – diluted |  |  | 49,809 |  |  |  | 49,426 |  |  |  |  | 49,813 |  |  |  | 49,225 |  |  |
| Earnings per common share - basic |  | $ | 0.04 |  |  | $ | 0.10 |  |  |  | $ | 0.02 |  |  | $ | 0.12 |  |  |
| Earnings per common share - diluted |  | $ | 0.04 |  |  | $ | 0.10 |  |  |  | $ | 0.02 |  |  | $ | 0.12 |  |  |
| Non-GAAP earnings per common share - basic |  | $ | 0.20 |  |  | $ | 0.17 |  |  |  | $ | 0.40 |  |  | $ | 0.30 |  |  |
| Non-GAAP earnings per common share - diluted |  | $ | 0.19 |  |  | $ | 0.16 |  |  |  | $ | 0.39 |  |  | $ | 0.29 |  |  |

[0000950170-22-014476:8k_2_02:55]
(1) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-22-014476:8k_2_02:56]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.
