# ADTN note change history — 0000950170-23-042449 → 0000950170-23-062173


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0000950170-23-062173:note_history:1]
From time to time, the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.
  (was, 2023-08-14, similarity 0.9995):
[0000950170-23-042449:note_history:1]
From time to time the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

- added (2023-11-09):
[0000950170-23-062173:note_history:2]
On May 8, 2023, Adtran Networks SE and its subsidiary, ADVA Optical Networking North America, Inc. (together, “Adtran Networks”), filed a lawsuit in the U.S District Court for the Eastern District of Texas (“EDTX”) against Huawei Technologies Co. Ltd (“Huawei”) seeking a declaration from the court that Huawei violated its commitments to negotiate in good faith and to license standard essential patents (“SEPs”), to the extent any SEPs are practiced by Adtran Networks, on Fair, Reasonable and Non-Discriminatory (“FRAND”) terms and conditions. The case also sought to obtain a ruling by the EDTX that Adtran Networks has complied with its own commitments and requested that the Court establish FRAND terms and conditions for obtaining a FRAND license on any SEPs to the extent they are practiced by Adtran Networks. The lawsuit further sought to enjoin Huawei from enforcing certain Huawei patents that Adtran Networks considers invalid and/or not practiced, and Adtran Networks alleged that Huawei had infringed upon an Adtran Networks patent. On July 20, 2023, Adtran Networks SE was served with a complaint filed by Huawei against Adtran Networks SE in the District Court München I, Germany, alleging that certain of its products infringe upon one of Huawei’s patents. On August 22, 2023, Adtran Networks entered into a settlement agreement with Huawei pursuant to which the parties agreed to, among other things, dismiss the lawsuits described above.

- changed (2023-11-09):
[0000950170-23-062173:note_history:3]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.12% as of September 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €325.3 million or approximately $344.2 million, based on an exchange rate as of September 30, 2023 and reflecting interest accrued through September 30, 2023 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).
  (was, 2023-08-14, similarity 0.919):
[0000950170-23-042449:note_history:3]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid.  The guaranteed interest rate is 5% plus a variable component that was 1.62% as of June 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €319.0 million or approximately $348.1 million, based on an exchange rate as of June 30, 2023 and reflecting interest accrued through June 30, 2023 at a rate of 5.0% in addition to the variable base interest rate according to the German Civil Code (currently 3.12%) during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- changed (2023-11-09):
[0000950170-23-062173:note_history:4]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.2 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and nine months ended September 30, 2023, we accrued $2.9 million and $8.6 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively.
  (was, 2023-08-14, similarity 0.9643):
[0000950170-23-042449:note_history:4]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.6 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and six months ended June 30, 2023, we accrued $2.9 million and $5.7 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively.

- added (2023-11-09):
[0000950170-23-062173:note_history:5]
For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, were paid to Adtran Networks shareholders.

- changed (2023-11-09):
[0000950170-23-062173:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2023 and December 31, 2022, we had commitments related to these bonds totaling $11.8 million and $22.0 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2023-08-14, similarity 0.9874):
[0000950170-23-042449:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2023 and December 31, 2022, we had commitments related to these bonds totaling $12.2 million and $22.0 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2023-11-09):
[0000950170-23-062173:note_history:7]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2023, purchase commitments totaled $308.4 million.
  (was, 2023-08-14, similarity 0.9875):
[0000950170-23-042449:note_history:7]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of June 30, 2023, purchase commitments totaled $377.4 million.

- removed (2023-11-09):
[0000950170-23-042449:note_history:8]
On May 8, 2023, ADVA and its subsidiary, ADVA Optical Networking North America, Inc. filed a lawsuit in the U.S District Court for the Eastern District of Texas (“EDTX”) against Huawei Technologies Co. Ltd (“Huawei”) seeking a declaration from the court that Huawei violated its commitments to negotiate in good faith and to license standard essential patents (“SEPs”), to the extent any SEPs are practiced by Adtran Networks, on Fair, Reasonable and Non-Discriminatory (“FRAND”) terms and conditions. The case also seeks to obtain a ruling by the court that Adtran Networks has complied with its own commitments and requests that the Court establish FRAND terms and conditions for obtaining a FRAND license on any SEPs to the extend they are practiced by Adtran Networks. The lawsuit also seeks to enjoin Huawei from enforcing five Huawei patents that Adtran Networks considers invalid and/or not practiced, and that Huawei has infringed an Adtran Networks patent. Adtran Networks expects Huawei to respond to the action in August 2023 and expects a trial to be scheduled for the second half of 2024. On July 20, 2023, ADVA Optical Networking SE ("ADVA Germany") was served with a complaint filed by Huawei against ADVA Germany in the District Court München I, Germany, alleging that certain of its products infringe upon one of Huawei’s patents. ADVA Germany's response in the case is due in November 2023, and the filing of a separate nullity action to invalidate the patent is also available in Germany. The Company intends to continue to vigorously defend its interests; however, these matters are subject to many uncertainties, and an adverse outcome in any one of these matters could potentially have a materially adverse impact on the Company's financial position, results of operations and cash flows. Given the current status of these matters, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

- removed (2023-11-09):
[0000950170-23-042449:note_history:9]
For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0000950170-23-062173:note_history:10]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.
  (was, 2023-08-14, similarity 0.9893):
[0000950170-23-042449:note_history:10]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

- changed (2023-11-09):
[0000950170-23-062173:note_history:11]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge.
  (was, 2023-08-14, similarity 0.96):
[0000950170-23-042449:note_history:11]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks. ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge.

- changed (2023-11-09):
[0000950170-23-062173:note_history:12]
Domination and Profit and Loss Transfer Agreement
  (was, 2023-08-14, similarity 0.8235):
[0000950170-23-042449:note_history:12]
Effectiveness of the Domination and Profit and Loss Transfer Agreement

- changed (2023-11-09):
[0000950170-23-062173:note_history:13]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.12% as of September 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €325.3 million or approximately $344.2 million, based on an exchange rate as of September 30, 2023 and reflecting interest accrued through September 30, 2023 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).
  (was, 2023-08-14, similarity 0.919):
[0000950170-23-042449:note_history:13]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5% plus a variable component that was 1.62% as of June 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €319.0 million or approximately $348.1 million, based on an exchange rate as of June 30, 2023 and reflecting interest accrued through June 30, 2023 at a rate of 5.0% in addition to the variable base interest rate according to the German Civil Code (currently 3.12%) during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- changed (2023-11-09):
[0000950170-23-062173:note_history:14]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.2 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and nine months ended September 30, 2023, we accrued $2.9 million and $8.6 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively.
  (was, 2023-08-14, similarity 0.6108):
[0000950170-23-042449:note_history:14]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.6 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and six months ended June 30, 2023, we accrued $2.9 million and $5.7 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively. For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

- added (2023-11-09):
[0000950170-23-062173:note_history:15]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, were paid to Adtran Networks shareholders.

- changed (2023-11-09):
[0000950170-23-062173:note_history:16]
As of September 30, 2023, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation assuming a substantial majority of Adtran Networks shareholders elect such option in the current period. We believe the probability that a substantial majority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-36 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks SE shares.
  (was, 2023-08-14, similarity 0.993):
[0000950170-23-042449:note_history:16]
As of June 30, 2023, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation assuming a substantial majority of Adtran Networks shareholders elect such option in the current period. We believe the probability that a substantial majority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-36 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks SE shares.

- added (2023-11-09):
[0000950170-23-062173:note_history:17]
Therefore, we believe that our cash and cash equivalents, investments, working capital management initiatives and access to funds under the Wells Fargo credit facility, including additional funding provided for under the First Amendment to the Wells Fargo credit facility that was signed on August 9, 2023, (described below) will be adequate to meet our operating and capital needs and our obligations under the DPLTA, including potential Exit Compensation, for at least the next 12 months, from the issuance of these financial statements, although we have suspended dividend payments and are implementing a business efficiency program, which includes, but is not limited to, planned reductions in our operating expenses and a site consolidation plan. In connection with the site consolidation plan, we are also exploring a potential sale of our headquarters in Huntsville. We may also need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet such needs and obligations. See Note 22, Subsequent Events, for additional information regarding  the suspension of the quarterly dividend.

- changed (2023-11-09):
[0000950170-23-062173:note_history:18]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100.0 million in aggregate principal amount, but the borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.
  (was, 2023-08-14, similarity 0.8843):
[0000950170-23-042449:note_history:18]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100.0 million in aggregate principal amount, but the borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023. The Credit Agreement matures in July 2027, but provides the Company with an option to request extensions subject to customary conditions.

- added (2023-11-09):
[0000950170-23-062173:note_history:19]
On August 9, 2023, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and, together with the Credit Agreement, the “Credit Facility”). The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. See Note 12, Revolving Credit Agreements, for additional information regarding the terms of the Credit Facility.

- changed (2023-11-09):
[0000950170-23-062173:note_history:20]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of September 30, 2023, and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to supply chain constraints, inflationary pressures, the energy crisis, rising interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.
  (was, 2023-08-14, similarity 0.9934):
[0000950170-23-042449:note_history:20]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of June 30, 2023, and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to supply chain constraints, inflationary pressures, the energy crisis, rising interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.

- changed (2023-11-09):
[0000950170-23-062173:note_history:21]
As of September 30, 2023 and December 31, 2022, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.6% and 34.7%, respectively.
  (was, 2023-08-14, similarity 0.9184):
[0000950170-23-042449:note_history:21]
As of June 30, 2023 and December 31, 2022, the Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.6% and 34.7%, respectively.

- removed (2023-11-09):
[0000950170-23-042449:note_history:22]
On May 24, 2023, at the annual general meeting of the shareholders of ADVA Optical Networking SE, a subsidiary of the Company ("ADVA"), the shareholders of ADVA approved the proposed change of its name to Adtran Networks SE ("Adtran Networks"), which was registered in the commercial register of the local court of Jena, Germany on June 8, 2023. Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to “Adtran Networks” refer to Adtran Networks SE (formerly ADVA Optical Networking SE).

- removed (2023-11-09):
[0000950170-23-042449:note_history:23]
Therefore, we believe that our cash and cash equivalents, investments, working capital management initiatives and access to funds under the Wells Fargo credit facility, including additional funding provided for under the First Amendment to the Wells Fargo credit facility that was signed on August 9, 2023, (described below and as recently expanded) will be adequate to meet our operating and capital needs and our obligations under the DPLTA, including potential Exit Compensation, for at least the next 12 months, from the issuance of these financial statements, although we may need to suspend payment of dividends, reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet such needs and obligations.

- removed (2023-11-09):
[0000950170-23-042449:note_history:24]
On August 9, 2023, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and Wells Fargo Bank, National Association, as administrative agent and as collateral agent, entered into a First Amendment to Credit Agreement (the “First Amendment”), which amended the Credit Agreement. See Note 22, Subsequent Events, for additional information.

- removed (2023-11-09):
[0000950170-23-042449:note_history:25]
Board Approval Purchase of Adtran Networks Common Stock

- removed (2023-11-09):
[0000950170-23-042449:note_history:26]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023 were paid to Adtran Networks' shareholders.


## adtn:NotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-11-09):
[0000950170-23-062173:note_history:27]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | September 30, 2023 |  |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |

- removed (2023-11-09):
[0000950170-23-042449:note_history:28]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | June 30, 2023 |  |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-11-09):
[0000950170-23-062173:note_history:29]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| New Nord/LB revolving line of credit |  | $ | 10,580 |  |  | $ | — |  |
| Nord/LB revolving line of credit |  |  | — |  |  |  | 16,091 |  |
| Syndicated credit agreement working capital line of credit |  |  | — |  |  |  | 10,727 |  |
| DZ bank revolving line of credit |  |  | — |  |  |  | 9,118 |  |
| Total current revolving credit agreements |  | $ | 10,580 |  |  | $ | 35,936 |  |

- added (2023-11-09):
[0000950170-23-062173:note_history:30]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Wells Fargo credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |
| Total non-current revolving credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |

- changed (2023-11-09):
[0000950170-23-062173:note_history:31]
As of September 30, 2023, the weighted average interest rate on our revolving credit agreements was 7.11%.
  (was, 2023-08-14, similarity 0.9418):
[0000950170-23-042449:note_history:31]
As of June 30, 2023, the weighted average interest rate on our revolving credit agreements was 6.4%.

- added (2023-11-09):
[0000950170-23-062173:note_history:32]
On August 9, 2023, (the "First Amendment Effective Date") the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and together with the Credit Agreement, the "Credit Facility").

- added (2023-11-09):
[0000950170-23-062173:note_history:33]
The First Amendment, provides for, among other things, a new $50.0 million delayed draw term loan (“DDTL”), which is available for borrowing in the event of the purchase by the Company of at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company as of the First Amendment Effective Date (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through the period that is three consecutive fiscal quarters thereafter.

- added (2023-11-09):
[0000950170-23-062173:note_history:34]
The First Amendment further added additional financial flexibility by amending the $30.0 million external debt capped basket to be an unlimited amount and permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must be incurred in pro forma compliance with the financial covenants in the Credit Agreement, unsecured and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

- added (2023-11-09):
[0000950170-23-062173:note_history:35]
As of September 30, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $200.0 million. As of September 30, 2023, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million total facility. As of September 30, 2023, we had a total of $2.2 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $197.8 million available for future borrowings. Any future credit extensions

- added (2023-11-09):
[0000950170-23-062173:note_history:36]
under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

- added (2023-11-09):
[0000950170-23-062173:note_history:37]
Revolving Line of Credit Interest Rate

- changed (2023-11-09):
[0000950170-23-062173:note_history:38]
All U.S. borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below)) bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%, plus (ii) the applicable rate, ranging from 0.65% to 1.65% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.65% to 2.65%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.75% to 2.75%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.0% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.
  (was, 2023-08-14, similarity 0.9904):
[0000950170-23-042449:note_history:38]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which bear interest at the Base Rate (as defined below)) bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

- added (2023-11-09):
[0000950170-23-062173:note_history:39]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate ranging from 0.20% to 0.25% per annum on the average daily unused portion of the revolving credit commitment of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for SOFR Loans.

- added (2023-11-09):
[0000950170-23-062173:note_history:40]
DDTL Interest Rate

- added (2023-11-09):
[0000950170-23-062173:note_history:41]
All U.S. borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.9% to 2.9%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”) or (B) the sum of the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%, plus (ii) the applicable rate, ranging from 0.9% to 1.9%. The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.0% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

- added (2023-11-09):
[0000950170-23-062173:note_history:42]
In addition to paying interest on outstanding principal under the DDTL loan, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment until the earliest of (i) the delayed draw funding date, (ii) the delayed draw funding deadline and (iii) the termination in full of the DDTL commitments.

- added (2023-11-09):
[0000950170-23-062173:note_history:43]
Covenants Under the Credit Agreement

- changed (2023-11-09):
[0000950170-23-062173:note_history:44]
The First Amendment permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the First Amendment without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The First Amendment contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds).
  (was, 2023-08-14, similarity 0.627):
[0000950170-23-042449:note_history:44]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the consolidated total net leverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the consolidated interest coverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of June 30, 2023, the Company was in compliance with all material covenants.

- added (2023-11-09):
[0000950170-23-062173:note_history:45]
The First Amendment further included the following revised financial covenants; (i) the addition of an automatic step up in the consolidated total net leverage ratio to 5.00:1.00 from 3.25:1.00 upon the occurrence of a Springing Covenant Event and continuing for the fiscal quarter in which the Springing Covenant Event occurs and the next three consecutive fiscal quarters thereafter (such period, a “Springing Covenant Period”) and (ii) the addition of a consolidated senior secured net leverage ratio covenant to be tested quarterly during a Springing Covenant Period and sized at 4.00:1.00 during the first quarter ending after a Springing Covenant Event, 3.75:1.00 during the second quarter ending after a Springing Covenant Event and 3.50:1.00 during the third and fourth quarters ending after a Springing Covenant Event. Further, if the Company or any of its subsidiaries incurs unsecured indebtedness under the uncapped general indebtedness basket or permitted convertible indebtedness basket of the Credit Agreement in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, then the maximum consolidated senior secured net leverage ratio shall be, or shall automatically step down to, 3.50:1.00 at the time of such incurrence.

- added (2023-11-09):
[0000950170-23-062173:note_history:46]
The First Amendment also requires that the consolidated interest coverage ratio (as defined in the First Amendment) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of September 30, 2023, the Company was in compliance with all material covenants.

- changed (2023-11-09):
[0000950170-23-062173:note_history:47]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the First Amendment are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the First Amendment pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.
  (was, 2023-08-14, similarity 0.6575):
[0000950170-23-042449:note_history:47]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the

- changed (2023-11-09):
[0000950170-23-062173:note_history:48]
On March 29, 2023, Adtran Networks entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of September 30, 2023, Adtran Networks borrowed $10.6 million under this facility.
  (was, 2023-08-14, similarity 0.9826):
[0000950170-23-042449:note_history:48]
On March 29, 2023, Adtran Networks entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of June 30, 2023, Adtran Networks borrowed $10.9 million under this facility.

- changed (2023-11-09):
[0000950170-23-062173:note_history:49]
On August 8, 2022, Adtran Networks entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and matured in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit. No amounts are available for future borrowings.
  (was, 2023-08-14, similarity 0.9727):
[0000950170-23-042449:note_history:49]
On August 8, 2022, Adtran Networks entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and which matures in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit. No amounts are available for future borrowings.

- removed (2023-11-09):
[0000950170-23-042449:note_history:50]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| New Nord/LB revolving line of credit |  | $ | 10,912 |  |  | $ | — |  |
| Nord/LB revolving line of credit |  |  | — |  |  |  | 16,091 |  |
| Syndicated credit agreement working capital line of credit |  |  | — |  |  |  | 10,727 |  |
| DZ bank revolving line of credit |  |  | — |  |  |  | 9,118 |  |
| Total current revolving credit agreements |  | $ | 10,912 |  |  | $ | 35,936 |  |

- removed (2023-11-09):
[0000950170-23-042449:note_history:51]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Wells Fargo credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |
| Total non-current revolving credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |

- removed (2023-11-09):
[0000950170-23-042449:note_history:52]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the prior Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

- removed (2023-11-09):
[0000950170-23-042449:note_history:53]
As of June 30, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $200.0 million. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million total facility. As of June 30, 2023, we had a total of $2.2 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $197.8 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

- removed (2023-11-09):
[0000950170-23-042449:note_history:54]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for SOFR Loans.

- removed (2023-11-09):
[0000950170-23-042449:note_history:55]
Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0000950170-23-062173:note_history:56]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value as of December 31, 2022:
  (was, 2023-08-14, similarity 0.9356):
[0000950170-23-042449:note_history:56]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value:

- changed (2023-11-09):
[0000950170-23-062173:note_history:57]
The Company did not have any debt securities and other investments as of September 30, 2023.
  (was, 2023-08-14, similarity 0.6292):
[0000950170-23-042449:note_history:57]
The contractual maturities related to debt securities and other investments were as follows:

- changed (2023-11-09):
[0000950170-23-062173:note_history:58]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Gross realized gain on debt securities |  | $ | 5 |  |  | $ | 1 |  |  | $ | 9 |  |  | $ | 14 |  |
| Gross realized loss on debt securities |  |  | (317 | ) |  |  | (116 | ) |  |  | (355 | ) |  |  | (242 | ) |
| Total loss recognized, net |  | $ | (312 | ) |  | $ | (115 | ) |  | $ | (346 | ) |  | $ | (228 | ) |
  (was, 2023-08-14, similarity 0.9071):
[0000950170-23-042449:note_history:58]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | — |  |  | $ | 4 |  |  | $ | 12 |  |
| Gross realized loss on debt securities |  |  | (27 | ) |  |  | (85 | ) |  |  | (39 | ) |  |  | (125 | ) |
| Total loss recognized, net |  | $ | (27 | ) |  | $ | (85 | ) |  | $ | (35 | ) |  | $ | (113 | ) |

- changed (2023-11-09):
[0000950170-23-062173:note_history:59]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. No allowance for credit losses was recorded for the nine months ended September 30, 2023 and 2022 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5.0% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the nine months ended September 30, 2023.
  (was, 2023-08-14, similarity 0.9112):
[0000950170-23-042449:note_history:59]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. No allowance for credit losses was recorded for the six months ended June 30, 2023 and 2022 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the six months ended June 30, 2023.

- changed (2023-11-09):
[0000950170-23-062173:note_history:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Unrealized gain (loss) on equity securities held |  | $ | (1,130 | ) |  | $ | (1,217 | ) |  | $ | 1,404 |  |  | $ | (8,849 | ) |
| Realized gain (loss) on equity securities sold |  |  | (1 | ) |  |  | (1,358 | ) |  |  | 13 |  |  |  | (1,675 | ) |
| Total gain (loss) recognized, net |  | $ | (1,131 | ) |  | $ | (2,575 | ) |  | $ | 1,417 |  |  | $ | (10,524 | ) |
  (was, 2023-08-14, similarity 0.8105):
[0000950170-23-042449:note_history:60]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Unrealized gain (loss) on equity securities held |  | $ | 1,288 |  |  | $ | (4,268 | ) |  | $ | 2,535 |  |  | $ | (7,630 | ) |
| Realized gain (loss) on equity securities sold |  |  | 1 |  |  |  | (293 | ) |  |  | 14 |  |  |  | (318 | ) |
| Total gain (loss) recognized, net |  | $ | 1,289 |  |  | $ | (4,561 | ) |  | $ | 2,549 |  |  | $ | (7,948 | ) |

- changed (2023-11-09):
[0000950170-23-062173:note_history:61]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:
  (was, 2023-08-14, similarity 0.9721):
[0000950170-23-042449:note_history:61]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

- added (2023-11-09):
[0000950170-23-062173:note_history:62]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Money market funds |  |  | 5,245 |  |  |  | 5,245 |  |  |  | — |  |  |  | — |  |
| Commercial paper |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total cash equivalents |  | $ | 5,245 |  |  | $ | 5,245 |  |  | $ | - |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 815 |  |  |  | 815 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 24,364 |  |  |  | 24,364 |  |  |  | — |  |  |  | — |  |
| Total long-term investments |  | $ | 25,179 |  |  | $ | 25,179 |  |  | $ | — |  |  | $ | — |  |
| Total |  | $ | 30,424 |  |  | $ | 30,424 |  |  | $ | — |  |  | $ | — |  |

- removed (2023-11-09):
[0000950170-23-042449:note_history:63]
|  |  | As of June 30, 2023 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,897 |  |  | $ | 1 |  |  | $ | (58 | ) |  | $ | 1,840 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (2 | ) |  |  | 183 |  |
| Asset-backed bonds |  |  | 670 |  |  |  | — |  |  |  | (22 | ) |  |  | 648 |  |
| Mortgage/Agency-backed bonds |  |  | 1,298 |  |  |  | — |  |  |  | (74 | ) |  |  | 1,224 |  |
| U.S. government bonds |  |  | 3,955 |  |  |  | — |  |  |  | (162 | ) |  |  | 3,793 |  |
| Foreign government bonds |  |  | 405 |  |  |  | — |  |  |  | (19 | ) |  |  | 386 |  |
| Available-for-sale debt securities held at fair value |  | $ | 8,410 |  |  | $ | 1 |  |  | $ | (337 | ) |  | $ | 8,074 |  |

- removed (2023-11-09):
[0000950170-23-042449:note_history:64]
|  |  | As of June 30, 2023 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 470 |  |  | $ | 183 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,158 |  |  | $ | 278 |  |  |
| One to two years |  |  | 1,048 |  |  |  | — |  |  |  | 218 |  |  |  | 164 |  |  |  | 1,266 |  |  |  | 108 |  |  |
| Two to three years |  |  | 322 |  |  |  | — |  |  |  | — |  |  |  | 288 |  |  |  | 249 |  |  |  | — |  |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 287 |  |  |  | 226 |  |  |  | 120 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 200 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 143 |  |  |  | 346 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 1,840 |  |  | $ | 183 |  |  | $ | 648 |  |  | $ | 1,224 |  |  | $ | 3,793 |  |  | $ | 386 |  |  |

- removed (2023-11-09):
[0000950170-23-042449:note_history:65]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

- removed (2023-11-09):
[0000950170-23-042449:note_history:66]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | — |  |  | $ | — |  |
| Money market funds |  |  | 272 |  |  |  | 272 |  |  |  | — |  |  |  | — |  |
| Commercial paper |  |  | 310 |  |  |  | — |  |  |  | 310 |  |  |  | — |  |
| Total cash equivalents |  | $ | 1,601 |  |  | $ | 1,291 |  |  | $ | 310 |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 1,840 |  |  | $ | — |  |  | $ | 1,840 |  |  | $ | — |  |
| Municipal fixed-rate bonds |  |  | 183 |  |  |  | — |  |  |  | 183 |  |  |  | — |  |
| Asset-backed bonds |  |  | 648 |  |  |  | — |  |  |  | 648 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,224 |  |  |  | — |  |  |  | 1,224 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,793 |  |  |  | 3,793 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 386 |  |  |  | — |  |  |  | 386 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 858 |  |  |  | 854 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 25,395 |  |  |  | 25,395 |  |  |  | — |  |  |  | — |  |
| Total short-term and long-term investments |  | $ | 34,327 |  |  | $ | 30,042 |  |  | $ | 4,281 |  |  | $ | — |  |
| Total |  | $ | 35,928 |  |  | $ | 31,333 |  |  | $ | 4,591 |  |  | $ | — |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-11-09):
[0000950170-23-062173:note_history:67]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | September 30, 2023 |  |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |

- removed (2023-11-09):
[0000950170-23-042449:note_history:68]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | June 30, 2023 |  |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0000950170-23-062173:note_history:69]
|  |  | Three Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 94,592 |  |  | $ | 21,608 |  |  | $ | 116,200 |  |  | $ | 103,011 |  |  | $ | 15,834 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 81,051 |  |  |  | 13,595 |  |  |  | 94,646 |  |  |  | 76,591 |  |  |  | 11,598 |  |  |  | 88,189 |  |
| Subscriber Solutions |  |  | 52,921 |  |  |  | 8,564 |  |  |  | 61,485 |  |  |  | 125,338 |  |  |  | 8,337 |  |  |  | 133,675 |  |
| Total |  | $ | 228,564 |  |  | $ | 43,767 |  |  | $ | 272,331 |  |  | $ | 304,940 |  |  | $ | 35,769 |  |  | $ | 340,709 |  |
  (was, 2023-08-14, similarity 0.9148):
[0000950170-23-042449:note_history:69]
|  |  | Three Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 120,221 |  |  | $ | 22,775 |  |  | $ | 142,996 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 89,263 |  |  |  | 13,454 |  |  |  | 102,717 |  |  |  | 80,821 |  |  |  | 11,467 |  |  |  | 92,288 |  |
| Subscriber Solutions |  |  | 73,518 |  |  |  | 8,147 |  |  |  | 81,665 |  |  |  | 75,171 |  |  |  | 4,579 |  |  |  | 79,750 |  |
| Total |  | $ | 283,002 |  |  | $ | 44,376 |  |  | $ | 327,378 |  |  | $ | 155,992 |  |  | $ | 16,046 |  |  | $ | 172,038 |  |

- changed (2023-11-09):
[0000950170-23-062173:note_history:70]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 342,390 |  |  | $ | 64,562 |  |  | $ | 406,952 |  |  | $ | 103,011 |  |  | $ | 15,834 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 254,868 |  |  |  | 39,315 |  |  |  | 294,183 |  |  |  | 243,396 |  |  |  | 34,877 |  |  |  | 278,273 |  |
| Subscriber Solutions |  |  | 196,726 |  |  |  | 25,760 |  |  |  | 222,486 |  |  |  | 252,899 |  |  |  | 17,248 |  |  |  | 270,147 |  |
| Total |  | $ | 793,984 |  |  | $ | 129,637 |  |  | $ | 923,621 |  |  | $ | 599,306 |  |  | $ | 67,959 |  |  | $ | 667,265 |  |
  (was, 2023-08-14, similarity 0.9085):
[0000950170-23-042449:note_history:70]
|  |  | Six Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 247,798 |  |  | $ | 42,954 |  |  | $ | 290,752 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 173,817 |  |  |  | 25,720 |  |  |  | 199,537 |  |  |  | 166,805 |  |  |  | 23,279 |  |  |  | 190,084 |  |
| Subscriber Solutions |  |  | 143,805 |  |  |  | 17,196 |  |  |  | 161,001 |  |  |  | 127,561 |  |  |  | 8,911 |  |  |  | 136,472 |  |
| Total |  | $ | 565,420 |  |  | $ | 85,870 |  |  | $ | 651,290 |  |  | $ | 294,366 |  |  | $ | 32,190 |  |  | $ | 326,556 |  |

- changed (2023-11-09):
[0000950170-23-062173:note_history:71]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Optical Networking Solutions |  | $ | 116,200 |  |  | $ | 118,845 |  |  | $ | 406,952 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 94,646 |  |  |  | 88,189 |  |  |  | 294,183 |  |  |  | 278,273 |  |
| Subscriber Solutions |  |  | 61,485 |  |  |  | 133,675 |  |  |  | 222,486 |  |  |  | 270,147 |  |
| Total |  | $ | 272,331 |  |  | $ | 340,709 |  |  | $ | 923,621 |  |  | $ | 667,265 |  |
  (was, 2023-08-14, similarity 0.8788):
[0000950170-23-042449:note_history:71]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Optical Networking Solutions |  | $ | 142,996 |  |  | $ | — |  |  | $ | 290,752 |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 102,717 |  |  |  | 92,288 |  |  |  | 199,537 |  |  |  | 190,084 |  |
| Subscriber Solutions |  |  | 81,665 |  |  |  | 79,750 |  |  |  | 161,001 |  |  |  | 136,472 |  |
| Total |  | $ | 327,378 |  |  | $ | 172,038 |  |  | $ | 651,290 |  |  | $ | 326,556 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0000950170-23-062173:note_history:72]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks SE solutions to create Access & Aggregation Solutions; ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions; and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of Adtran Networks' portfolio.
  (was, 2023-08-14, similarity 0.9962):
[0000950170-23-042449:note_history:72]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of Adtran Networks' portfolio.

- changed (2023-11-09):
[0000950170-23-062173:note_history:73]
|  |  | Three Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 94,592 |  |  | $ | 21,608 |  |  | $ | 116,200 |  |  | $ | 103,011 |  |  | $ | 15,834 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 81,051 |  |  |  | 13,595 |  |  |  | 94,646 |  |  |  | 76,591 |  |  |  | 11,598 |  |  |  | 88,189 |  |
| Subscriber Solutions |  |  | 52,921 |  |  |  | 8,564 |  |  |  | 61,485 |  |  |  | 125,338 |  |  |  | 8,337 |  |  |  | 133,675 |  |
| Total |  | $ | 228,564 |  |  | $ | 43,767 |  |  | $ | 272,331 |  |  | $ | 304,940 |  |  | $ | 35,769 |  |  | $ | 340,709 |  |
  (was, 2023-08-14, similarity 0.9148):
[0000950170-23-042449:note_history:73]
|  |  | Three Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 120,221 |  |  | $ | 22,775 |  |  | $ | 142,996 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 89,263 |  |  |  | 13,454 |  |  |  | 102,717 |  |  |  | 80,821 |  |  |  | 11,467 |  |  |  | 92,288 |  |
| Subscriber Solutions |  |  | 73,518 |  |  |  | 8,147 |  |  |  | 81,665 |  |  |  | 75,171 |  |  |  | 4,579 |  |  |  | 79,750 |  |
| Total |  | $ | 283,002 |  |  | $ | 44,376 |  |  | $ | 327,378 |  |  | $ | 155,992 |  |  | $ | 16,046 |  |  | $ | 172,038 |  |

- changed (2023-11-09):
[0000950170-23-062173:note_history:74]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 342,390 |  |  | $ | 64,562 |  |  | $ | 406,952 |  |  | $ | 103,011 |  |  | $ | 15,834 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 254,868 |  |  |  | 39,315 |  |  |  | 294,183 |  |  |  | 243,396 |  |  |  | 34,877 |  |  |  | 278,273 |  |
| Subscriber Solutions |  |  | 196,726 |  |  |  | 25,760 |  |  |  | 222,486 |  |  |  | 252,899 |  |  |  | 17,248 |  |  |  | 270,147 |  |
| Total |  | $ | 793,984 |  |  | $ | 129,637 |  |  | $ | 923,621 |  |  | $ | 599,306 |  |  | $ | 67,959 |  |  | $ | 667,265 |  |
  (was, 2023-08-14, similarity 0.9085):
[0000950170-23-042449:note_history:74]
|  |  | Six Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 247,798 |  |  | $ | 42,954 |  |  | $ | 290,752 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 173,817 |  |  |  | 25,720 |  |  |  | 199,537 |  |  |  | 166,805 |  |  |  | 23,279 |  |  |  | 190,084 |  |
| Subscriber Solutions |  |  | 143,805 |  |  |  | 17,196 |  |  |  | 161,001 |  |  |  | 127,561 |  |  |  | 8,911 |  |  |  | 136,472 |  |
| Total |  | $ | 565,420 |  |  | $ | 85,870 |  |  | $ | 651,290 |  |  | $ | 294,366 |  |  | $ | 32,190 |  |  | $ | 326,556 |  |

- added (2023-11-09):
[0000950170-23-062173:note_history:75]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of September 30, 2023 and December 31, 2022 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $314.0 million and $277.2 million, respectively. As of September 30, 2023, approximately 68.6% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of September 30, 2023 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2023-11-09):
[0000950170-23-062173:note_history:76]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Accounts receivable, net |  | $ | 229,333 |  |  | $ | 279,435 |  |
| Contract assets(1) |  | $ | 888 |  |  | $ | 1,852 |  |
| Unearned revenue |  | $ | 49,832 |  |  | $ | 41,193 |  |
| Non-current unearned revenue |  | $ | 23,501 |  |  | $ | 19,239 |  |
  (was, 2023-08-14, similarity 0.9279):
[0000950170-23-042449:note_history:76]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Accounts receivable, net |  | $ | 239,565 |  |  | $ | 279,435 |  |
| Contract assets(1) |  | $ | 1,153 |  |  | $ | 1,852 |  |
| Unearned revenue |  | $ | 48,030 |  |  | $ | 41,193 |  |
| Non-current unearned revenue |  | $ | 24,111 |  |  | $ | 19,239 |  |

- changed (2023-11-09):
[0000950170-23-062173:note_history:77]
The Company is party to a receivables purchase agreement with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables sold for the nine months ended September 30, 2023 and the twelve months ended December 31, 2022, totaled $17.8 million and $14.9 million, respectively, of which $1.4 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of September 30, 2023 and December 31, 2022, the Company had an allowance for credit losses related to factored accounts receivable totaling less than $0.1 million. The cost of the receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million and $0.9 million for the three and nine months ended September 30, 2023, respectively.
  (was, 2023-08-14, similarity 0.9311):
[0000950170-23-042449:note_history:77]
The Company is party to a receivables purchase agreement with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables sold for the six months ended June 30, 2023 and the twelve months ended December 31, 2022, totaled $14.7 million and $14.9 million, respectively, of which $1.2 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of June 30, 2023 and December 31, 2022, the Company had an allowance for credit losses related to factored accounts receivable totaling less than $0.1 million. The cost of the receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of (Loss) Income and totaled $0.3 million and $0.6 million for the three and six months ended June 30, 2023, respectively.

- changed (2023-11-09):
[0000950170-23-062173:note_history:78]
Of the outstanding unearned revenue balances as of December 31, 2022, $6.1 million and $31.3 million were recognized as revenue during the three and nine months ended September 30, 2023, respectively. Of the $17.7 million of outstanding unearned revenue balances as of December 31, 2021, $2.8 million and $12.3 million were recognized as revenue during the three and nine months ended September 30, 2022, respectively.
  (was, 2023-08-14, similarity 0.8583):
[0000950170-23-042449:note_history:78]
Of the outstanding unearned revenue balances as of December 31, 2022, $24.8 million and $50.5 million was recognized as revenue during the three and six months ended June 30, 2023, respectively. Of the $17.7 million of outstanding unearned revenue balances as of December 31, 2021, $4.1 million and $9.5 million was recognized as revenue during the three and six months ended June 30, 2022, respectively.

- changed (2023-11-09):
[0000950170-23-062173:note_history:79]
As of September 30, 2023 and December 31, 2022, the Company’s outstanding accounts receivable balance was $229.3 million and $279.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method, as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.
  (was, 2023-08-14, similarity 0.9951):
[0000950170-23-042449:note_history:79]
As of June 30, 2023 and December 31, 2022, the Company’s outstanding accounts receivable balance was $239.6 million and $279.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

- changed (2023-11-09):
[0000950170-23-062173:note_history:80]
The allowance for credit losses was $15 thousand and $49 thousand as of September 30, 2023 and December 31, 2022, respectively, related to accounts receivable.
  (was, 2023-08-14, similarity 0.9617):
[0000950170-23-042449:note_history:80]
The allowance for credit losses was $26 thousand and $49 thousand as of June 30, 2023 and December 31, 2022, respectively, related to accounts receivable.

- changed (2023-11-09):
[0000950170-23-062173:note_history:81]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of September 30, 2023 and December 31, 2022, the Company’s outstanding contract asset balance was $0.9 million and $1.9 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method, as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.
  (was, 2023-08-14, similarity 0.9959):
[0000950170-23-042449:note_history:81]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of June 30, 2023 and December 31, 2022, the Company’s outstanding contract asset balance was $1.2 million and $1.9 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

- changed (2023-11-09):
[0000950170-23-062173:note_history:82]
No allowance for credit losses was recorded for the three months ended September 30, 2023 and 2022 related to contract assets.
  (was, 2023-08-14, similarity 0.9524):
[0000950170-23-042449:note_history:82]
No allowance for credit losses was recorded for the three months ended June 30, 2023 and 2022 related to contract assets.

- removed (2023-11-09):
[0000950170-23-042449:note_history:83]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2023 and December 31, 2022 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $369.3 million and $277.2 million, respectively. As of June 30, 2023, approximately 46.5% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of June 30, 2023 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2023-11-09):
[0000950170-23-062173:note_history:84]
Dividend Suspension
  (was, 2023-08-14, similarity 0.6111):
[0000950170-23-042449:note_history:84]
Dividend Approval

- added (2023-11-09):
[0000950170-23-062173:note_history:85]
On November 6, 2023, the Board of Directors suspended the Company’s quarterly cash dividend which will be redirected to reduce debt and interest expense and support the Company's capital efficiency program. The payment of any future dividends will be at the discretion of the Board of Directors and will depend on the Company’s financial condition, results of operations, capital requirements, and any other factors deemed relevant by the Board of Directors.

- added (2023-11-09):
[0000950170-23-062173:note_history:86]
Business Efficiency Program

- added (2023-11-09):
[0000950170-23-062173:note_history:87]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management determined to implement a comprehensive business efficiency program, which includes (i) a cost efficiency program targeting the reduction of ongoing operating expenses, and (ii) a capital efficiency program, which includes a site consolidation plan exploring the partial sale of owned real estate and the suspension of the quarterly dividend. See Part II, Item 5 (a) of this report for additional information regarding the business efficiency program.

- removed (2023-11-09):
[0000950170-23-042449:note_history:88]
On August 6, 2023, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 21, 2023. The payment date will be September 5, 2023 in the aggregate amount of approximately $7.1 million.

- removed (2023-11-09):
[0000950170-23-042449:note_history:89]
Wells Fargo Credit Agreement Amendment

- removed (2023-11-09):
[0000950170-23-042449:note_history:90]
On August 9, 2023, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment”).

- removed (2023-11-09):
[0000950170-23-042449:note_history:91]
The First Amendment, among other things, provides for:

- removed (2023-11-09):
[0000950170-23-042449:note_history:92]
•
a new $50 million delayed draw term loan A tranche (“DDTL”), which is available for borrowing in the event of the purchase by the Company of at least sixty percent (60%) of the outstanding shares of Adtran Networks that are not currently owned by the Company (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through the period that is three consecutive fiscal quarters thereafter;

- removed (2023-11-09):
[0000950170-23-042449:note_history:93]
•
a revised applicable margin, which varies based on consolidated total net leverage ratio and ranges from, (a) in the case of revolving loans, (i) 1.65%, with respect to term SOFR loans, to 2.65%, (ii) 1.75%, with respect to EURIBOR loans, to 2.75% and (iii) 0.65%, with respect to base rate loans (including swingline loans) to 1.65%, and (b) in the case of term loans, ranging from (i) 1.90%, with respect to term SOFR loans, to 2.90% and (ii) 0.90%, with respect to Base Rate Loans, to 1.90% (each as defined in the First Amendment to the Credit Agreement);

- removed (2023-11-09):
[0000950170-23-042449:note_history:94]
•
a revised commitment fee, which varies based on consolidated total net leverage ratio and ranges from 0.20% to 0.25% per annum on the average daily unused portion of the revolving credit commitment of the revolving credit lenders (other than the defaulting lenders, if any) (each as defined in the credit agreement); and

- removed (2023-11-09):
[0000950170-23-042449:note_history:95]
•
revised financial covenants, including (i) the addition of an automatic step up in the consolidated total net leverage ratio to 5.00:1.00 from 3.25:1.00 upon the occurrence of a Springing Covenant Event and continuing for the fiscal quarter in which the Springing Covenant Event occurs and the next three consecutive fiscal quarters thereafter (such period, a “Springing Covenant Period”) and (ii) the addition of a consolidated senior secured net leverage ratio covenant to be tested quarterly during a Springing Covenant Period and sized at 4.00:1.00 during the first quarter ending after a Springing Covenant Event, 3.75:1.00 during the second quarter ending after a Springing Covenant Event and 3.50:1.00 during the third and fourth quarters ending after a Springing Covenant Event. Further, if the Company or any of its subsidiaries incurs unsecured indebtedness under the uncapped general indebtedness basket or permitted convertible indebtedness basket of the Credit Agreement in excess of $50 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, then the maximum consolidated senior secured net leverage ratio shall be, or shall automatically step down to, 3.50:1.00 at the time of such incurrence.

- removed (2023-11-09):
[0000950170-23-042449:note_history:96]
The First Amendment further added additional financial flexibility by amending the $30 million external debt capped basket to be an unlimited amount and permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must be incurred in pro forma compliance with the financial covenants in the Credit Agreement, unsecured and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

- removed (2023-11-09):
[0000950170-23-042449:note_history:97]
Lastly, the First Amendment added market environmental, social and governance provisions and extended the required delivery date of the financial statements of the Company and its subsidiaries for the fiscal quarter ended June 30, 2023 to August 18, 2023.
