# ADTN MD&A — 0000950170-24-032089


## mdna

[0000950170-24-032089:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000950170-24-032089:mdna:2]
The following discussion should be read in conjunction with our audited consolidated financial statements and the related notes included in Part II, Item 8 of this report. We have omitted discussion of the earliest of the three years of financial condition and results of operations and this information can be found in Part I, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the fiscal year ended December 31, 2022, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, and Part I, Item 1A, Risk Factors, included in Amendment No. 1 to our Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on August 14, 2023 (the “2022 Form 10-K/A”), as well as Part I, Item 1, Business, included in our Annual Report on Form 10-K filed with the SEC on March 1, 2023., which is available free of charge on the SEC's website at http://www.sec.gov and on our website at www.adtran.com.

[0000950170-24-032089:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 2 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part I, Item 1A, Risk Factors, of this Form 10-K.

[0000950170-24-032089:mdna:4]
Unless the context otherwise indicates or requires, references in this Annual Report on Form 10-K to "ADTRAN", the “Company,” “we,” “us” and “our” refer to ADTRAN Holdings, Inc. and its consolidated subsidiaries for periods subsequent to the Merger and to ADTRAN, Inc. and its consolidated subsidiaries for periods prior to the Merger. The prior period results do not include the results of Adtran Networks prior to the Business Combination which occurred on July 15, 2022.

[0000950170-24-032089:mdna:5]
Overview

[0000950170-24-032089:mdna:6]
The Company is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Large, Medium and Small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders; cable/MSOs; SMBs; distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies.

[0000950170-24-032089:mdna:7]
Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-24-032089:mdna:8]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer, especially upon the convergence of solutions at the network edge.

[0000950170-24-032089:mdna:9]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. In addition to operating under two reportable segments, the Company also reports revenue across three categories – Subscriber Solutions, Access & Aggregation Solutions and Optical Networking Solutions.

[0000950170-24-032089:mdna:10]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN, Inc. reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, we have recast these revenues such that ADTRAN, Inc's former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions was added as a new revenue category to represent a meaningful portion of Adtran Networks portfolio.

[0000950170-24-032089:mdna:11]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at customers' premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include our Mosaic One SaaS applications, fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers and cloud software solutions covering a mix of subscriber types.

[0000950170-24-032089:mdna:12]
Our Access & Aggregation Solutions are solutions that are used by communications Service Providers to connect residential subscribers, business subscribers and mobile radio networks to the Service Providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions and access orchestration solutions that ensure highly reliable and efficient network performance.

[0000950170-24-032089:mdna:13]
Our Optical Networking Solutions are used by communications Service Providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems and automation platforms that are used to build high-scale, secure and assured optical networks.

[0000950170-24-032089:mdna:14]
Adtran Networks Domination and Profit and Loss Transfer Agreement

[0000950170-24-032089:mdna:15]
The DPLTA between the Company, as the controlling company, and Adtran Networks, as the controlled company, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-24-032089:mdna:16]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is
entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated in 2023.

[0000950170-24-032089:mdna:17]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest (the "Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.59 (€0.52 net under the current tax regime) per share for each full fiscal year of Adtran Networks (the “Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component that was 3.12% as of December 31, 2023. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year), and it will be payable for the first time after the ordinary general shareholders’ meeting of Adtran Networks in 2024 for the fiscal year ended December 31, 2023. The adequacy of both forms of compensation has been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

[0000950170-24-032089:mdna:18]
The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). For the year ended December 31, 2023, 67 thousand shares, respectively, of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €1.2 million or approximately $1.3 million based on an exchange rate as of December 31, 2023, were paid to Adtran Networks' shareholders.

[0000950170-24-032089:mdna:19]
In addition to our cash and cash equivalents and the credit facility, we may fund a portion or all of the Exit Compensation through the sale of securities or additional alternative funding sources, if available. There can be no assurances that we would be successful in effecting these actions on commercially reasonable terms or at all. If we cannot raise additional funds as needed, it could have a material adverse impact on our financial results and financial condition.

[0000950170-24-032089:mdna:20]
We currently hold 33,957,538 no-par value bearer shares of Adtran Networks, representing 65.32% of Adtran Networks outstanding shares as of December 31, 2023.

[0000950170-24-032089:mdna:21]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which is incorporated by reference to Exhibit 10.5 of the 2022 Form 10-K/A. As of December 31, 2023, the Company has incurred $26.2 million of transaction costs related to the Business Combination. During the year ended December 31, 2023, 2022 and 2021, $0.1 million, $14.2 million and $11.9 million of transaction costs were incurred, respectively. These transaction costs are recorded in selling, general and administrative expenses in the Consolidated Statements of Loss.

[0000950170-24-032089:mdna:22]
Multi -Year Integration Program

[0000950170-24-032089:mdna:23]
During the fourth quarter of 2022, the Company initiated a multi-year integration program designed to optimize the assets, business processes, and information technology systems of the Company. The program  was designed to address several potential cost synergies, including realizing operational scale, combining sales channels, streamlining corporate and general and administrative functions, and combined sourcing and production costs.

[0000950170-24-032089:mdna:24]
During the years ended December 31, 2023 and 2022, we recognized $21.5 million and $1.6 million of restructuring costs relating to the Business Combination under the multi-year integration program and synergy realization, respectively, that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss. The Company does not anticipate additional material expenses to be incurred in connection with this integration program.

[0000950170-24-032089:mdna:25]
Business Efficiency Program

[0000950170-24-032089:mdna:26]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (the “Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expands upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment. Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). Additionally, on October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze.

[0000950170-24-032089:mdna:27]
During the year ended December 31, 2023, we recognized $25.1 million of costs relating to the Business Efficiency Program. We expect costs in the first quarter 2024 and thereafter relating to the Business Efficiency Program to range between $22.2 million and $35.2 million. Management expects these planned costs to include severance costs ranging from $12.2 million to $18.9 million in connection with an early retirement program and reductions in workforce, inventory write down of product discontinuances ranging from $7.6 million to $10.3 million, and site consolidation transaction expenses (primarily brokers fees) ranging from $2.4 million to $6.0 million. Future cash payments include: severance costs and outplacement fees that are anticipated to be in the range of $12.2 million to $18.9 million, payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $2.4 million to $6.0 million, and potential cash payments in the range of $3.6 million to $6.3 million for anticipated product discontinuances. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures.  However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing. If required, we will amend this disclosure at such time as management is able in good faith to estimate the amount, or range of amounts, of these charges.

[0000950170-24-032089:mdna:28]
The Business Efficiency Program is expected to be substantially completed by the end of 2024, with expected cash payments continuing into 2025.

[0000950170-24-032089:mdna:29]
See Note 23 of Notes to the Consolidated Financial Statements in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:mdna:30]
Financial Performance and Trends

[0000950170-24-032089:mdna:31]
We ended 2023 with a year-over-year revenue increase of 12.0%, driven by an increase in volume of sales activity during the first half of 2023 due to the Business Combination with Adtran Networks partially offset by decreased volume of sales activity in our domestic ADTRAN, Inc. operations due to customers' focus on reducing inventory levels and customers readjusting their capital expenditure budgets due to the uncertain macroeconomic environment related to continued elevated interest rates and ongoing inflationary pressures. During 2023, we had one customer with revenues greater than 10.0% which was an international Service Provider customer and our five largest customers comprised 37.0% of our revenue. Our year-over-year domestic revenue decreased by 10.9%, driven by lower volume of sales of our residential solutions products as a result of customers focus on reducing inventory levels in our Subscriber

[0000950170-24-032089:mdna:32]
Solutions segment, partially offset by an increase in volume of sales activity in the first half of 2023 as a result of the Business Combination with Adtran Networks. Internationally, our year-over-year revenue increased by 35.4%, primarily driven by an increase in volume of sales activity in the first half of 2023 as a result of the Business Combination with Adtran Networks partially offset by the unfavorable impact on revenue as a result of the strengthened U.S. dollar and decreased shipments to two large network operators and one alternative network operator in Europe.

[0000950170-24-032089:mdna:33]
Revenues in 2023 were impacted by normalization subsequent to the supply chain disruptions we saw during the pandemic. This normalization has led to a reduction in lead times as customer concerns over inventory stocking levels affected the Subscriber Solutions category due to over-supply situation of CPE products which the Company expects to continue into the first half of 2024. In the second half of 2023, our Access & Aggregation and Optical Networking revenue categories experienced a general slowdown in revenue as a result of reduced spending by our medium and large Service Provider customers as they continue to reduce inventory levels and monitor uncertain macroeconomic conditions related to continued elevated interest rates and ongoing inflationary pressures. Despite these challenges, we have maintained our emphasis on product development to enable us to respond to rapidly changing technology and evolving industry standards. For example, we expect public funding through projects such as IPCEI ME/CT to further our research and development for new communication technologies. Additionally, public funding through the Broadband Equity, Access and Deployment Program is expected to commence in late 2024 through 2026, which provides a positive outlook for the future. In Europe, we continue to see increased activity from high-risk vendor replacement and broadband subsidy programs.

[0000950170-24-032089:mdna:34]
Our operating results have fluctuated and may continue to fluctuate on a quarterly basis due to several factors, including customer order activity, supply chain constraints, component availability, and the Company's consolidation and integration with Adtran Networks. Further, a significant percentage of orders require delivery within a few days requiring us to maintain higher inventory levels. These factors may result in limited order flow visibility. For example, although, expedite fees and lead times for semiconductor chips and other key components began to ease during 2023 following shortages in the industry, we continued to be negatively impacted by price increases, which could continue to have a material adverse effect on customer relations and our financial condition. We have taken decisive steps to transform our business into a leaner, more efficient and more profitable company, including through the implementation of a Business Efficiency Program, which includes a significant cost efficiency program targeting a reduction of ongoing operating expenses and a capital efficiency program inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. Nevertheless, our operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues has and may again in the future significantly impact our financial results in a given quarter.

[0000950170-24-032089:mdna:35]
Our operating results have significantly fluctuated and may do so in the future as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, inflation, regional conflicts, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. In recent years, inflationary pressures on input costs, such as raw materials and labor, and distribution costs had a negative impact on our operating results. However, inflationary pressures on our supply chain have eased somewhat, which has led to reductions in cost premiums on raw material costs and freight. We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors, and customers to address and to limit the disruption to our operations and order fulfillment. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an additional adverse effect on our business and operating results beyond the effects of the most recent inventory write-downs. Also, not maintaining sufficient inventory levels to ensure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results.

[0000950170-24-032089:mdna:36]
We are exposed to changes in foreign currencies relative to the U.S. dollar, which are references to the differences between the foreign-exchanges rates we use to convert the financial results of our international operations from local currencies into U.S. dollars for financial reporting purposes. This impact of foreign-exchange rate changes is calculated based on the difference between the current period’s currency exchange rates and that of the comparable prior period. Our primary exposures to foreign currency exchange rate movements are with the Euro and the British pound sterling. As a result of our global operations, our revenue, gross margins, operating expense and operating loss in some international markets have been and may continue to be affected by foreign currency fluctuations.

[0000950170-24-032089:mdna:37]
The Company’s policy is to assess the realizability of assets (long-lived assets, intangibles and goodwill) held within our reporting units and to evaluate such assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. For impairment testing purposes, we determined the Company's reporting units are generally the same as its operating segments, which are identified in Note 18 to the Consolidated Financial Statements. During the third quarter of 2023, the Company's market capitalization and long-term projections decreased which triggered a reassessment of our estimated future undiscounted cash flows within our two identified reporting units. The Company determined the fair value of each reporting unit using a combination of an income approach and a market-based peer group analysis. It was determined that the decreases in projected future

[0000950170-24-032089:mdna:38]
52

[0000950170-24-032089:mdna:39]
cash flows, discount rates, overall macroeconomic conditions, as well as the decrease in our market capitalization applied in the valuation, were required to align with market-based assumptions and company-specific risk, which resulted in lower fair values of the Services & Support reporting unit. Upon the conclusion of its quantitative impairment assessment, the Company recognized a $37.9 million non-cash goodwill impairment charge for the Services & Support reporting unit. The Company did not recognize any impairment charges for the Network Solutions reporting unit during the third quarter of 2023. During the fourth quarter of 2023, the Company qualitatively assessed the carrying value of each reporting unit for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. During the fourth quarter of 2023, the Company completed its annual impairment test of the carrying value of reporting unit assets. Based on our assessment of certain qualitative factors such as macro-economic conditions, industry and market considerations, cost factors and overall financial performance, management concluded that the fair value of the reporting unit was more likely than not greater than its carrying amount as of December 31, 2023.

[0000950170-24-032089:mdna:40]
Our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. For a discussion of risks associated with our operating results, see Part I, Item 1A, Risk Factors of this report.

[0000950170-24-032089:mdna:41]
Results of Operations

[0000950170-24-032089:mdna:42]
The following table presents selected financial information derived from our Consolidated Statements of Loss expressed as a percentage of revenue for the years indicated. Amounts may not foot due to rounding.

[0000950170-24-032089:mdna:43]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Revenue |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 84.8 | % |  |  | 89.4 | % |  |  | 88.6 | % |
| Services & Support |  |  | 15.2 |  |  |  | 10.6 |  |  |  | 11.4 |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 62.9 |  |  |  | 63.1 |  |  |  | 54.7 |  |
| Network Solutions - Inventory Write Down |  |  | 2.1 |  |  |  | — |  |  |  | — |  |
| Services & Support |  |  | 6.0 |  |  |  | 5.0 |  |  |  | 6.5 |  |
| Total Cost of Revenue |  |  | 71.0 |  |  |  | 68.1 |  |  |  | 61.2 |  |
| Gross Profit |  |  | 29.0 |  |  |  | 31.9 |  |  |  | 38.8 |  |
| Selling, general and administrative expenses |  |  | 22.5 |  |  |  | 20.4 |  |  |  | 22.1 |  |
| Research and development expenses |  |  | 22.5 |  |  |  | 16.9 |  |  |  | 19.3 |  |
| Asset impairment |  |  | — |  |  |  | 1.7 |  |  |  | — |  |
| Goodwill impairments |  |  | 3.3 |  |  |  | — |  |  |  | — |  |
| Operating Loss |  |  | (19.3 | ) |  |  | (7.1 | ) |  |  | (2.6 | ) |
| Interest and dividend income |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.5 |  |
| Interest expense |  |  | (1.4 | ) |  |  | (0.3 | ) |  |  | — |  |
| Net investment gain (loss) |  |  | 0.2 |  |  |  | (1.1 | ) |  |  | 0.3 |  |
| Other income, net |  |  | 0.1 |  |  |  | 1.4 |  |  |  | 0.7 |  |
| Loss Before Income Taxes |  |  | (20.1 | ) |  |  | (6.9 | ) |  |  | (1.1 | ) |
| Income tax benefit (expense) |  |  | (2.4 | ) |  |  | 6.1 |  |  |  | (0.4 | ) |
| Net Loss |  |  | (22.6 | )% |  |  | (0.9 | )% |  |  | (1.5 | )% |
| Net Income (loss) attributable to non-controlling interest |  |  | 0.7 |  |  |  | (0.7 | ) |  |  | — |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | (23.3 | )% |  |  | (0.2 | )% |  |  | (1.5 | )% |

[0000950170-24-032089:mdna:44]
The following discussion and financial information are presented to aid in an understanding of our current consolidated financial position, changes in financial position, results of operations and cash flows and should be read in conjunction with the audited consolidated financial statements and notes thereto included herein. The emphasis of the discussion is a comparison of the years ended December 31, 2023 and December 31, 2022. For a discussion of a comparison of the years ended December 31, 2022 and December 31, 2021, please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K/A for the year ended December 31, 2022, filed with the SEC on August 14, 2023.

[0000950170-24-032089:mdna:45]
Comparison of Years Ended December 31, 2023 and December 31, 2022

[0000950170-24-032089:mdna:46]
Revenue

[0000950170-24-032089:mdna:47]
Our revenue increased 12.0% from $1,025.5 million for the year ended December 31, 2022 to $1,149.1 million for the year ended December 31, 2023. The increase in revenue for the year ended December 31, 2023 is primarily attributable to a $379.0 million increase in volume of sales activity during the first half of 2023 due to the Business Combination with Adtran Networks partially offset by a $255.4 million decrease in volume of sales activity due to customers’ focus on reducing inventory levels in our domestic ADTRAN, Inc. operations and customers readjusting their capital expenditure budgets due to the uncertain macroeconomic environment. The increase in revenue by category for the year ended December 31, 2023 was primarily attributable to a $231.9 million increase in Optical Networking Solutions category due to the Business Combination with Adtran Networks partially offset by a $92.7 million decrease in Subscriber Solutions products and a $15.6 million decrease in Access & Aggregation Solutions. Ongoing customer concerns over inventory stocking levels have affected our revenue in the Subscriber Solutions category. We believe that this over-supply of CPE products will continue into the first half of 2024.

[0000950170-24-032089:mdna:48]
Network Solutions segment revenue increased 6.3% from $916.8 million in 2022 to $974.3 million in 2023, primarily due to an increase of $326.8 million in volume of sales activity during the first half of 2023 due to the Business Combination with Adtran Networks partially offset by a decrease of $159.7 million in Subscriber Solutions products, a decrease of $43.3 million in Access & Aggregation Solutions and a decrease of $66.3 million in Optical Networking Solutions product. More specifically, for the year ended December 31,

[0000950170-24-032089:mdna:49]
54

[0000950170-24-032089:mdna:50]
2023, the decrease in revenue for our Subscriber Solutions products was primarily due to lower volume of sales of our residential solutions products as a result of customers focus on reducing inventory levels.

[0000950170-24-032089:mdna:51]
Services & Support revenue increased 60.7% from $108.7 million in 2022 to $174.7 million in 2023. The increase in revenue for 2023 was primarily attributable to the increase of $52.2 million in volume of sales activity during the first half of 2023 from the Business Combination with Adtran Networks, a $7.4 million increase in revenue for Optical Networking Solutions products, a $4.8 million increase in revenue for Access & Aggregation Solutions revenue and a $1.6 million increase in revenue for Subscriber Solutions services. More specifically, the increase in revenue for the year ended December 31, 2023 of our ADTRAN, Inc. operations was primarily due to higher volume of sales of our software services and business solutions services.

[0000950170-24-032089:mdna:52]
Domestic revenue decreased 10.9% from $517.4 million in 2022 to $461.0 million in 2023, driven by lower volume of sales of our residential solutions products as a result of customers' focus on reducing inventory levels in our Subscriber Solutions segment, partially offset by an increase in volume of sales activity during the first half of 2023 from the Business Combination with Adtran Networks.

[0000950170-24-032089:mdna:53]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., increased 35.4% from $508.1 million for the year ended December 31, 2022 to $688.1 million for the year ended December 31, 2023. International revenue, as a percentage of total revenue, increased from 49.5% for the year ended December 31, 2022 to 59.8% for the year ended December 31, 2023. The increase in international revenue for 2023 was primarily attributable to an increase in volume of sales activity during the first half of 2023 as a result of the Business Combination with Adtran Networks and increased shipments partially offset by the unfavorable impact on revenue generated outside of the U.S. as a result of the strengthened U.S. dollar. For the year ended December 31, 2023 as compared to the year ended December 31, 2022, changes in foreign currencies relative to the U.S dollar increased our net revenue by approximately $9.0 million.

[0000950170-24-032089:mdna:54]
Our ADTRAN, Inc. international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income. Our Adtran Networks international revenue is largely focused on the manufacture and selling of networking solutions that are based on three core areas of expertise: fiber-optic transmission technology (cloud interconnect), cloud access technology for rapid creation of innovative services around the network edge and solutions for precise timing and synchronization of networks. In addition, Adtran Networks' international operations offers a comprehensive portfolio of network design, implementation and maintenance services to assist operators in the deployment of market-leading networks while reducing their cost to maintain these networks.

[0000950170-24-032089:mdna:55]
Cost of Revenue

[0000950170-24-032089:mdna:56]
As a percentage of revenue, cost of revenue increased from 68.1% for the year ended December 31, 2022 to 71.0% for the year ended December 31, 2023. The increase was primarily attributable to $89.6 million of adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, acquisition related expenses, a $24.3 million write down of inventory due to a restructuring discontinuation of certain product lines within our Network Solutions segment, and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations partially offset by supply chain cost improvements. As the inventory that was acquired in the Business Combination with Adtran Networks is sold, our cost of revenue as a percentage of revenue will return to more normalized levels.  For the year ended December 31, 2023, changes in foreign currencies relative to the U.S. dollar increased our cost of revenue by approximately $1.5 million.

[0000950170-24-032089:mdna:57]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 70.6% of revenue in 2022 to 76.7% of revenue in 2023. The increase in cost of revenue as a percentage of revenue was primarily attributable to acquisition related expenses, amortizations and adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, a write down of inventory due to a restructuring discontinuation of certain product lines and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations partially offset by supply chain cost improvements.

[0000950170-24-032089:mdna:58]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 47.1% of revenue in 2022 to 39.6% of revenue in 2023. The decrease in cost of revenue as a percentage of revenue was primarily attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with Adtran Networks.

[0000950170-24-032089:mdna:59]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work

[0000950170-24-032089:mdna:60]
for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0000950170-24-032089:mdna:61]
Gross Profit

[0000950170-24-032089:mdna:62]
As a percentage of revenue, gross profit decreased from 31.9% for the year ended December 31, 2022 to 29.0% for the year ended December 31, 2023. The decrease was primarily attributable to $89.6 million of adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, acquisition related expenses, a decrease in volume of sales activity due to customers' focus on reducing inventory levels in our domestic ADTRAN, Inc. operations, a decrease due to the unfavorable impact on revenue generated outside of the U.S. as a result of the strengthened U.S. dollar and a write down of inventory due to a restructuring discontinuation of certain product lines.

[0000950170-24-032089:mdna:63]
As a percentage of that segment's revenue, Network Solutions gross profit decreased from 29.4% for the year ended December 31, 2022 to 23.3% for the year ended December 31, 2023. The decrease was primarily attributable to increases in cost of revenue related to acquisition related expenses, adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks and a decrease in volume of sales activity related to our ADTRAN, Inc. operations, a decrease in volume of sales activity due to customers' focus on reducing inventory levels in our domestic ADTRAN, Inc. operations and a write down of inventory due to a restructuring discontinuation of certain product lines partially offset by an increase in volume of sales activity in the first half of 2023 due to the Business Combination with Adtran Networks.

[0000950170-24-032089:mdna:64]
As a percentage of that segment's revenue, Services & Support gross profit increased from 52.9% for the year ended December 31, 2022 to 60.4% for the year ended December 31, 2023. The increase was primarily attributable to an increase in volume of sales activity in the first half of 2023 due to the Business Combination with Adtran Networks and a decrease in cost of revenue as a percentage of revenue attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with Adtran Networks.

[0000950170-24-032089:mdna:65]
Selling, General and Administrative Expenses

[0000950170-24-032089:mdna:66]
Selling, general and administrative expenses as a percentage of revenue increased from 20.4% for the year ended December 31, 2022, to 22.5% for the year ended December 31, 2023. While selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared, in the year ended December 31, 2023 we saw a more significant increase due to higher expenses related to the Business Combination with Adtran Networks and other items described below. Our restructuring, business efficiency and integration programs are in the process of consolidating, streamlining and integrating the workforce, systems and processes of ADTRAN and Adtran Networks, which we expect will lower selling, general and administrative expense as a percentage of revenue over time.

[0000950170-24-032089:mdna:67]
Selling, general and administrative expenses increased by 23.6% from $208.9 million for the year ended December 31, 2022, to $258.1 million for the year ended December 31, 2023. Selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The increase in selling, general and administrative expenses was primarily attributable to increased expenses in the first half of 2023 related to the Business Combination with Adtran Networks such as employee-related costs due to an increase in the number of employees, costs related to our restructuring program, amortization of intangible assets, depreciation of property, plant and equipment, restructuring expenses and transactions costs partially offset by decreased stock-based compensation expense. For the year ended December 31, 2023, as compared to the year ended December 31, 2022, changes in foreign currencies relative to the U.S dollar increased our selling, general and administrative expenses by approximately $1.3 million.

[0000950170-24-032089:mdna:68]
Research and Development Expenses

[0000950170-24-032089:mdna:69]
Research and development expenses as a percentage of revenue increased from 16.9% for the year ended December 31, 2022, to 22.5% for the year ended December 31, 2023. Although, research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared, in the first half of 2023, we saw a more significant increase in expenses related to the Business Combination with Adtran Networks and other items described below. Our restructuring, business efficiency and integration programs are in the process of consolidating, streamlining and integrating the workforce, systems and processes of ADTRAN and Adtran Networks, which we expect will lower research and development expense as a percentage of revenue over time.

[0000950170-24-032089:mdna:70]
Research and development expenses increased by $84.5 million or 48.7% from $173.8 million for the year ended December 31, 2022, to $258.3 million for the year ended December 31, 2023. The increase in research and development expenses was primarily attributable to increased expenses in the first half of 2023 related to the Business Combination with Adtran Networks such as employee-related costs due to an increase in the number of employees of $70.5 million, depreciation of property, plant and equipment of $6.3 million and

[0000950170-24-032089:mdna:71]
restructuring expenses of $6.2 million. For the year ended December 31, 2023 as compared to the year ended December 31, 2022, changes in foreign currencies relative to the U.S. dollar increased our research and development expenses by approximately $0.1 million.

[0000950170-24-032089:mdna:72]
Adtran Networks has arrangements with governmental entities for the purposes of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the years ended December 31, 2023 and 2022, the Company recognized $5.2 million and $1.1 million, respectively, as a reduction of research and development expense.

[0000950170-24-032089:mdna:73]
We expect to continue to incur research and development expenses in connection with our new and existing products. We continually evaluate new product opportunities and engage in significant research and product development efforts, which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0000950170-24-032089:mdna:74]
Asset Impairments

[0000950170-24-032089:mdna:75]
In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result, the Company recognized impairment charges of $17.4 million during the year ended December 31, 2022, primarily attributable to capitalized implementation costs for a cloud computing arrangement. There were no asset impairments recognized during the years ended December 31, 2023 and 2021. See Note 10 of the Notes to the Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:mdna:76]
Goodwill Impairment

[0000950170-24-032089:mdna:77]
The Company recognized impairment charges of $37.9 million during the year ended December 31, 2023, primarily attributable to lower fair values of the Services & Support reporting unit driven by decreases in projected future cash flows, discount rates, overall macroeconomic conditions, as well as the decrease in our market capitalization. There were no goodwill impairments recognized during the years ended December 31, 2022 and 2021. See Note 9 of the Notes to the Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:mdna:78]
Interest and Dividend Income

[0000950170-24-032089:mdna:79]
Interest and dividend income increased by 10.2% from $2.1 million for the year ended December 31, 2022 to $2.3 million for the year ended December 31, 2023. Interest and dividend income was up due to increased income in the first half of 2023 as a result of the Business Combination with Adtran Networks and increased dividend income from the deferred compensation plan during the year ended December 31, 2023. Our investments decreased from $33.0 million as of December 31, 2022 to $27.7 million as of December 31, 2023 and was primarily attributable to the sale of certain equity and fixed income investments for working capital and other purposes.

[0000950170-24-032089:mdna:80]
Interest Expense

[0000950170-24-032089:mdna:81]
Interest expense increased from $3.4 million for the year ended December 31, 2022 to $16.3 million for the year ended December 31, 2023. The increase in interest expense was primarily related to increased borrowings under the Wells Fargo Credit Agreement and the assumed debt associated with the Business Combination with Adtran Networks. See Note 12 and Note 13 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report and “Financing Activities” in “Liquidity and Capital Resources” below.

[0000950170-24-032089:mdna:82]
Net Investment Gain (Loss)

[0000950170-24-032089:mdna:83]
We recognized a net investment loss of $11.3 million and a gain of $2.8 million for the years ended December 31, 2022 and 2023, respectively. The fluctuations in our net investments were primarily attributable to market driven changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See “Investing Activities” in “Liquidity and Capital Resources” of this report and Note 1 and Note 5 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:mdna:84]
Other Income, net

[0000950170-24-032089:mdna:85]
Other income, net, decreased from income of $14.5 million for the year ended December 31, 2022 to income of $1.3 million for the year ended December 31, 2023. For the years ended December 31, 2023 and 2022, other income, net, is comprised primarily of gains and losses on foreign currency transactions and income from excess material sales. See Note 11 of Notes to Consolidated Financial Statements included in Part II, Item 8 of the report for additional information on foreign exchange contracts.

[0000950170-24-032089:mdna:86]
Income Tax (Expense) Benefit

[0000950170-24-032089:mdna:87]
Our effective tax rate changed from a benefit of 87.5%, for the year ended December 31, 2022 to an expense of 12.2% for the year ended December 31, 2023. The change in the effective tax rate for the year ended December 31, 2023, was driven primarily by the establishment of our valuation allowance against our domestic deferred tax assets during the fourth quarter of 2023, along with an increase in the global intangible low-taxed income ("GILTI") inclusion amount derived from the income of our controlled foreign companies. See Note 14 of the Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:mdna:88]
Net Loss Attributable to ADTRAN Holdings, Inc.

[0000950170-24-032089:mdna:89]
As a result of the above factors, our net loss attributable to ADTRAN Holdings, Inc. increased from $2.0 million for the year ended December 31, 2022 to a net loss of $267.7 million for the year ended December 31, 2023. As a percentage of revenue, net loss was 0.2% for the year ended December 31, 2022 and net loss was 23.3% for the year ended December 31, 2023.

[0000950170-24-032089:mdna:90]
Liquidity and Capital Resources

[0000950170-24-032089:mdna:91]
Liquidity

[0000950170-24-032089:mdna:92]
We have historically financed our ongoing business with existing cash, investments and cash flow from operations. We had a net operating cash outflow in 2023. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital, business acquisitions, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures. In addition, we have increasingly relied upon our credit arrangements to manage our working capital needs.

[0000950170-24-032089:mdna:93]
As of December 31, 2023, our cash on hand was $87.2 million of which $73.0 million was held by our foreign subsidiaries. The Company had access to $202.7 million on its Credit Facility for future borrowings; however, as of December 31, 2023, the Company was limited to additional borrowings of $38.8 million based on debt covenant compliance metrics. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax. As of December 31, 2022, our cash on hand was $108.6 million and our short-term investments were $0.3 million, which resulted in available short-term liquidity of $108.9 million, of which $86.3 million was held by our foreign subsidiaries.

[0000950170-24-032089:mdna:94]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.12% as of December 31, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €310.3 million or approximately $342.5 million, based on an exchange rate as of December 31, 2023 and reflecting interest accrued through December 31, 2023 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-032089:mdna:95]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.7 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the year ended December 31, 2023, we accrued $11.5 million in Annual Recurring Compensation, which was reflected as an increase to retained deficit and shown as an other current liability in our Consolidated Balance Sheets. With respect to the year ended December 31, 2023, we will be obligated to pay $11.5 million in Annual Recurring Compensation on the third banking day following the 2024 ordinary general shareholders’ meeting of Adtran Networks (but in any event within eight months following December 31, 2023).

[0000950170-24-032089:mdna:96]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”), which has since been amended three times. Pursuant to the terms of the Credit Agreement, as amended, the Company, ADTRAN, Inc., and the subsidiary guarantors (together, the “Credit Parties”) are subject to a liquidity covenant, which provides that, during the fourth quarter of 2023 through and including the third quarter of 2024 (the "Covenant Relief Period") or a Springing Covenant Period, (i.e., the period beginning upon the purchase by the Company of at least 60% of the outstanding shares of Adtran Networks not owned by the Company as of August 9, 2023 and the three consecutive quarterly test periods after such date), as of the last day of any fiscal quarter, the cash and cash equivalents of the Credit Parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million, limiting our ability to pay the obligations under the DPLTA. See below, as well as Note 12 and Note 23 of Notes to Consolidated Financial Statements included in Part II, Item, 8 for additional information regarding the terms of each amendment to the Wells Fargo Credit Agreement.

[0000950170-24-032089:mdna:97]
As of December 31, 2023, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet the substantial majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the year ended December 31, 2023, 67 thousand shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €1.2 million or approximately $1.3 million based on an exchange rate of December 31, 2023, were paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-32 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks shares.

[0000950170-24-032089:mdna:98]
The Company experienced revenue declines in 2023. To the extent that the Company is further impacted by the uncertain macroeconomic environment related to continued elevated interest rates and ongoing inflationary pressures, the Company has established plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a Business Efficiency Program, which includes, but is not limited to, planned reductions in operating expenses and a site consolidation plan. In connection with the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

[0000950170-24-032089:mdna:99]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo Credit Facility (described below), including (i) the additional funding provided for under the First Amendment to the Wells Fargo Credit Facility that was signed on August 9, 2023, (ii) the additional covenant headroom during the Covenant Relief Period provided for under the Second Amendment to Wells Fargo Credit Facility, and (iii) the exclusion of the Factoring Agreement as debt for purposes of the Credit Facility’s financial covenants as provided for under the Third Amendment to Wells Fargo Credit Facility (each as described below), will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and continue to comply with our debt covenants under the Second Amendment for at least the next twelve months, from the issuance of these financial statements. See below, as well as Note 12 and Note 23 of Notes to Consolidated Financial Statements included in Part II, Item 8 for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

[0000950170-24-032089:mdna:100]
Wells Fargo Credit Facility

[0000950170-24-032089:mdna:101]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into the Credit Agreement with a syndicate of banks, including Administrative Agent, and the other lenders named therein (the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount, as well as the $50.0 million delayed draw term loan facility described below.

[0000950170-24-032089:mdna:102]
On August 9, 2023, (the "First Amendment Effective Date") the Company, its wholly-owned direct subsidiary, ADTRAN, Inc. and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and together with the Credit Agreement, the "Credit Facility").

[0000950170-24-032089:mdna:103]
The First Amendment, provided for, among other things, a new $50.0 million delayed draw term loan (“DDTL”), which (subject to certain conditions) is available for borrowing in the event of the purchase by the Company of at least sixty percent (60.0%) of the outstanding shares of Adtran Networks SE that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks SE. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through August 9, 2024.

[0000950170-24-032089:mdna:104]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-24-032089:mdna:105]
On January 16, 2024, the Company entered into a Second Amendment to the Credit Agreement and First Amendment to the Collateral Agreement. The Second Amendment, among other things, provided the Company and its subsidiaries with additional covenant headroom for the fourth quarter of 2023 through the third quarter of 2024 (the "Covenant Relief Period") and added certain other financial covenants which are described below.

[0000950170-24-032089:mdna:106]
On March 12, 2024, the Company entered into a Third Amendment to the Credit Agreement. The Third Amendment, among other things, amends the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024 and June 30, 2024. The Company is also currently in negotiations with the Administrative Agent regarding a potential further amendment to the Credit Agreement to address the addition of certain foreign subsidiary guarantors.

[0000950170-24-032089:mdna:107]
As of December 31, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $195.0 million. As of December 31, 2023, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. In addition, we may issue up to $50.0 million in letters of credit against our $400.0 million total facility. As of December 31, 2023, we had a total of $2.3 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $202.7 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of December 31, 2023, the Company was in compliance with all material covenants.

[0000950170-24-032089:mdna:108]
Revolving Line of Credit Interest Rate

[0000950170-24-032089:mdna:109]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin) bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.15% per annum).

[0000950170-24-032089:mdna:110]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.

[0000950170-24-032089:mdna:111]
“Adjusted Term SOFR” means Term SOFR for the applicable interest period plus 0.10% per annum. Adjusted Term SOFR is subject to a floor of 0.00% per annum.

[0000950170-24-032089:mdna:112]
All Euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.25% per annum).

[0000950170-24-032089:mdna:113]
In addition, (x) if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-032089:mdna:114]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

[0000950170-24-032089:mdna:115]
The increases in the commitment fee and margin rates during the Covenant Relief Period (referenced above) continue until the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the (“Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, the Company has repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the Company has reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) the Company is in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-24-032089:mdna:116]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

[0000950170-24-032089:mdna:117]
DDTL Interest Rate

[0000950170-24-032089:mdna:118]
All U.S. dollar borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.90% to 1.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.40% per annum), or (B) Adjusted Term SOFR plus an applicable margin ranging from 1.90% to 2.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.40% per annum).

[0000950170-24-032089:mdna:119]
In addition, (x) if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-032089:mdna:120]
In addition to paying interest on outstanding principal under the DDTL loan, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment.

[0000950170-24-032089:mdna:121]
The increases in the commitment fee and margin rates during the Covenant Relief Period (referenced above) continue until the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the (“Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, the Company has repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the Company has reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) the Company is in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-24-032089:mdna:122]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

[0000950170-24-032089:mdna:123]
Covenants Under the Credit Agreement

[0000950170-24-032089:mdna:124]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable)::

[0000950170-24-032089:mdna:125]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Total Net Leverage Ratio may not exceed 5.00x.

[0000950170-24-032089:mdna:126]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

[0000950170-24-032089:mdna:127]
•
In the event of the purchase by the Company of at least sixty percent (60%) of the outstanding shares of Adtran Networks SE not owned by the Company as of August 9, 2023 that have been tendered (such event, a “Springing Covenant Event” and the fiscal quarter in which the Springing Covenant Event Occurs and the three consecutive quarterly test periods thereafter, the “Springing Covenant Period”), the following covenant levels:

[0000950170-24-032089:mdna:128]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

[0000950170-24-032089:mdna:129]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

[0000950170-24-032089:mdna:130]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

[0000950170-24-032089:mdna:131]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50,000,000 in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

[0000950170-24-032089:mdna:132]
•
If a Springing Covenant Period is not in effect, the following covenant levels:

[0000950170-24-032089:mdna:133]
•
From December 31, 2023 through and including March 31, 2024: 3.25x.

[0000950170-24-032089:mdna:134]
•
From April 1, 2024 through and including June 30, 2024: 3.50x.

[0000950170-24-032089:mdna:135]
•
From July 1, 2024 and thereafter: 3.25x.

[0000950170-24-032089:mdna:136]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not exceed 1.25x.

[0000950170-24-032089:mdna:137]
•
During the Covenant Relief Period or a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million.

[0000950170-24-032089:mdna:138]
The Credit Agreement is guaranteed by certain domestic subsidiaries of the Company, and the Company is also required to add certain additional domestic and international subsidiaries as guarantors under the Credit Agreement (such existing and new guarantors, collectively, the “Guarantors”). In addition to the guarantees provided by the Guarantors, the Guarantors have granted (or will grant) security interests in favor of the Administrative Agent over substantially all tangible and intangible assets, and the Borrower will grant mortgages in favor of the Administrative Agent over certain owned real estate assets. The Company is currently in negotiations with the Administrative Agent regarding a potential further amendment to the Credit Agreement to address the addition of certain foreign subsidiary guarantors.

[0000950170-24-032089:mdna:139]
The Credit Agreement provides for revolving borrowings of up to $400.0 million in aggregate principal amount, as well as an additional $50.0 million delayed draw term loan tranche that would be available upon a Springing Covenant Event. It also continues to permit the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement subject to certain limitations and minimum payment thresholds.

[0000950170-24-032089:mdna:140]
During the Covenant Relief Period, the Company is not permitted to make certain dividend payments to the Company's Stockholders or certain other Restricted Payments. However, the Company is permitted to make the Recurring Compensation Payment to each Adtran Networks shareholder (other than the Company), pursuant to the terms of the DPLTA. See Note 20 for additional information.

[0000950170-24-032089:mdna:141]
Furthermore, the Credit Agreement, as amended, contain customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts; however, certain of the exceptions and carveouts are not permitted to be used during the Covenant Relief Period. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.

[0000950170-24-032089:mdna:142]
Operating Activities

[0000950170-24-032089:mdna:143]
Net cash used in operating activities of $45.6 million during the year ended December 31, 2023 increased by $1.4 million compared to $44.2 million of net cash used in during the year ended December 31, 2022. This increase in net cash used was primarily due to the net loss for the period and net cash outflows from working capital, specifically, a decrease in the average number of days payable to our trade suppliers.

[0000950170-24-032089:mdna:144]
Net accounts receivable decreased 22.5% from $279.4 million as of December 31, 2022 to $216.4 million as of December 31, 2023. There was an allowance for credit losses of $0.4 million and less than $0.1 as of December 31, 2023 and December 31, 2022, respectively. The decrease in net accounts receivable was due primarily to sales volume and timing of sales. Quarterly accounts receivable DSO increased from 72 days as of December 31, 2022 to 88 days as of December 31, 2023. The increase in DSO was primarily driven by customer and geographical mix of commercial terms and the international expansion associated with the Business Combination with Adtran Networks and timing of sales within the quarter.

[0000950170-24-032089:mdna:145]
Other receivables decreased 46.8% from $32.8 million as of December 31, 2022 to $17.5 million as of December 31, 2023. The decrease in other receivables was primarily attributable to a decrease in sales of raw materials to our contract manufacturers.

[0000950170-24-032089:mdna:146]
Annual inventory turnover decreased from 2.46 turns as of December 31, 2022 to 2.07 turns as of December 31, 2023. Inventory decreased 15.3% from $427.5 million as of December 31, 2022 to $362.3 million as of December 31, 2023. The decrease in inventory was primarily due to a $24.3 million write down of inventory due to discontinuation of certain product lines within our Network Solutions segment and a reduction in component purchases due to improved lead times and utilization of buffer stock. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory for customer demand and improve working capital.

[0000950170-24-032089:mdna:147]
Accounts payable decreased 31.5% from $237.7 million as of December 31, 2022 to $162.9 million as of December 31, 2023. The decrease in accounts payable was primarily due to a decrease in the average number of days payable to our trade suppliers and reduced purchases with inventory depletion. Accounts payable fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-24-032089:mdna:148]
Investing Activities

[0000950170-24-032089:mdna:149]
Capital expenditures totaled approximately $43.1 million and $17.1 million for the years ended December 31, 2023 and 2022, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements. The increase in capital expenditures is primarily attributable to an increase in expenditures due to the Business Combination with Adtran Networks and for expenditures related to the construction of a terafactory building in Europe.

[0000950170-24-032089:mdna:150]
Our combined short-term and long-term investments decreased $5.3 million from $33.0 million as of December 31, 2022 to $27.7 million as of December 31, 2023. This decrease reflects the impact of the sale of portions of our equity and fixed income investments and the net unrealized and realized gains and losses on our investments.

[0000950170-24-032089:mdna:151]
See Note 5 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:mdna:152]
Our long-term investments decreased 15.1% from $32.7 million as of December 31, 2022 to $27.7 million as of December 31, 2023. This decrease was due to the sale of our fixed income investments. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $0.9 million and $0.8 million, as of December 31, 2023 and 2022, respectively. Long-term investments as of December 31, 2023 and 2022 also included $26.8 million and $22.9 million, respectively, related to our deferred compensation plan.

[0000950170-24-032089:mdna:153]
63

[0000950170-24-032089:mdna:154]
Financing Activities

[0000950170-24-032089:mdna:155]
Dividends

[0000950170-24-032089:mdna:156]
During 2023 and 2022, we paid shareholder dividends totaling $21.2 million and $22.9 million, respectively. Beginning in the third quarter of 2022, the amount of dividends paid to shareholders increased from approximately $4.4 million per quarter to approximately $7.1 million per quarter which was due to the increased number of shareholders of the Company's stock as a result of the Business Combination with Adtran Networks. On November 6, 2023, the Board of Directors suspended the Company’s quarterly cash dividend in order to reduce debt and interest expense and support the Company's capital efficiency program. The payment of any future dividends will be at the discretion of the Board of Directors and will depend on the Company’s financial condition, results of operations, capital requirements, and any other factors deemed relevant by the Board of Directors. In addition, the Wells Fargo Credit Agreement currently does not allow for the payment of dividends to shareholders. For addition information, see Note 20 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report and Liquidity & Capital Resources above. The following table shows dividends per common share paid to our shareholders in each quarter of 2023 and 2022:

[0000950170-24-032089:mdna:157]
| Dividends per Common Share |  |
|  |  | 2023 |  |  | 2022 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | - |  |  | $ | 0.09 |  |

[0000950170-24-032089:mdna:158]
Stock Repurchase Program

[0000950170-24-032089:mdna:159]
The Company did not repurchase any stock during the years ended December 31, 2023 and 2022, and there currently is no authorized stock repurchase plan.

[0000950170-24-032089:mdna:160]
Stock Option Exercises

[0000950170-24-032089:mdna:161]
To accommodate employee stock option exercises, the Company issued 23 thousand and 0.5 million shares of common stock and treasury stock which resulted in proceeds of $0.5 million and $6.9 million during the years ended December 31, 2023 and 2022, respectively. Additionally, to accommodate Adtran Networks stock option exercises, Adtran Networks issued 0.1 million of Adtran Networks common stock which resulted in proceeds of $0.8 million, during the period July 15, 2022 to December 31, 2022. Adtran Networks issued 0.1 million of Adtran Networks common stock which resulted in proceeds of $0.4 million, during the year ended December 31, 2023. Adtran Networks stock options outstanding as of December 31, 2023 totaled 18 thousand (representing less than 0.1% of Adtran Networks' outstanding shares), of which none were exercisable.

[0000950170-24-032089:mdna:162]
Employee Pension Plan

[0000950170-24-032089:mdna:163]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Details regarding the pension plans are set forth below.

[0000950170-24-032089:mdna:164]
•
In Germany, there is one defined benefit pension plan and one defined contribution plan. Both plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service and salary. The defined benefit plan is financed by contributions paid by the Company and the defined contribution plan is financed by contributions paid by the participants.

[0000950170-24-032089:mdna:165]
•
In Switzerland, there are two defined benefit pension plans. Both plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service, salary and on a participants old age account. The plans are financed by contributions paid by the participants and by the Company.

[0000950170-24-032089:mdna:166]
•
In Italy, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay-as-you-go basis. Employees receive their pension payments as a function of salary, inflation and a notional account.

[0000950170-24-032089:mdna:167]
•
In Israel, there is a defined benefit plan that provides benefits in the event of a participant being dismissed involuntarily, retirement or death. The plan's benefits are based on the higher of the severance benefit required by law or the cash surrender value of the severance benefit component of any qualifying insurance policy or long-term employee benefit fund that is registered in the participants name. The plan is financed by contributions paid by the Company.

[0000950170-24-032089:mdna:168]
•
In India, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay-as-you-go basis.

[0000950170-24-032089:mdna:169]
Our defined benefit plan assets consist of a balanced portfolio of equity funds, bond funds, emerging market funds, real estate funds and balanced funds. Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. The objectives of our investment policy are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies. The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. At December 31, 2023, the estimated fair market value of our defined benefit pension plans' assets increased to $55.2 million from $48.7 million at December 31, 2022.

[0000950170-24-032089:mdna:170]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in euro currency with durations close to the duration of our pension obligations. The projected benefit obligation for our defined benefit pension plans was $67.9 million and $59.3 million as of December 31, 2023 and 2022, respectively.

[0000950170-24-032089:mdna:171]
The components of net periodic pension cost, other than the service cost component, are included in other income, net in the Consolidated Statements of Loss. The components of net periodic pension cost and amounts recognized in other comprehensive income (loss) for the years ended December 31, 2023 and 2022 were $5.1 million and ($5.8) million, respectively.

[0000950170-24-032089:mdna:172]
Actuarial gains and losses are recorded in accumulated other comprehensive (loss) income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants. We estimate that less than $0.1 million will be amortized from accumulated other comprehensive income into net periodic pension cost in 2024 for the net actuarial loss. The net actuarial loss recognized in accumulated other comprehensive loss as of December 31, 2023 and 2022 was $2.5 million and $1.1 million, respectively. See Note 15 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:mdna:173]
Off-Balance Sheet Arrangements

[0000950170-24-032089:mdna:174]
We have exposure to credit losses from off-balance sheet exposures used to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of December 31, 2023. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 20 of the Notes to Condensed Consolidated Financial Statements, included in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:mdna:175]
Cash Requirements

[0000950170-24-032089:mdna:176]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of December 31, 2023, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA and currency hedging arrangements, which are discussed below). Other than operating lease obligations, the cash requirements table excludes interest payments.

[0000950170-24-032089:mdna:177]
| (In thousands) |  | Total |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | 2028 |  |  | Thereafter |  |
| Wells Fargo credit agreement(1) |  | $ | 195,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 195,000 |  |  | $ | — |  |  | $ | — |  |
| Secured borrowings related to accounts receivable(2) |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations(3) |  |  | 252,516 |  |  |  | 237,358 |  |  |  | 9,792 |  |  |  | 5,312 |  |  |  | 54 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations(4) |  |  | 47,720 |  |  |  | 9,639 |  |  |  | 8,423 |  |  |  | 6,608 |  |  |  | 4,923 |  |  |  | 4,723 |  |  |  | 13,404 |  |
| Totals |  | $ | 509,335 |  |  | $ | 261,096 |  |  | $ | 18,215 |  |  | $ | 11,920 |  |  | $ | 199,977 |  |  | $ | 4,723 |  |  | $ | 13,404 |  |

[0000950170-24-032089:mdna:178]
(1) See description below.

[0000950170-24-032089:mdna:179]
(2) Secured borrowings related to our accounts receivable factoring agreement that are expected to be repaid within 12 months..

[0000950170-24-032089:mdna:180]
(3) We have purchase obligations related to open purchase orders to our contract manufacturers, ODMs, component suppliers, service partners and other vendors. The settlement of our purchase obligations will occur at various dates beginning in 2024 and going through 2027. See Note 20 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report for more information.

[0000950170-24-032089:mdna:181]
(4) We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Our operating leases had remaining lease terms ranging from two months to 116 months as of December 31, 2023.

[0000950170-24-032089:mdna:182]
Stock Repurchase Program

[0000950170-24-032089:mdna:183]
There were no stock repurchases during the years ended December 31, 2023 and 2022, and there currently is no authorized stock repurchase plan.

[0000950170-24-032089:mdna:184]
Wells Fargo Credit Agreement

[0000950170-24-032089:mdna:185]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into the Credit Agreement with the Administrative Agent and the other lenders named therein. The Credit Agreement was subsequently amended on August 9, 2023, January 16, 2024 and March 12, 2024. The Credit Agreement provides for a revolving line of credit and a DDTL. As of December 31, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $195.0 million. As of December 31, 2023, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. See Note 12 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report and “Liquidity and Capital Resources” in Part II, Item 7 of this report  for additional information.

[0000950170-24-032089:mdna:186]
Nord/LB Revolving Line of Credit

[0000950170-24-032089:mdna:187]
On March 29, 2023, Adtran Networks entered into a $16.1million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bore interest of Euro Short Term Rate plus 1.94%. The line of credit had a perpetual term that could be terminated by the Company or Nord/LB at any time. As of December 31, 2023, Adtran Networks repaid the outstanding borrowings and terminated the Nord/LB Revolving Line of Credit.

[0000950170-24-032089:mdna:188]
Prior Nord/LB Revolving Line of Credit

[0000950170-24-032089:mdna:189]
On August 8, 2022, Adtran Networks entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bore interest of Euro Short Term Rate plus 1.4% and matured in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings and terminated the Nord/LB revolving line of credit.

[0000950170-24-032089:mdna:190]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-24-032089:mdna:191]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company repaid the outstanding borrowings and terminated the syndicated credit agreement working capital line of credit.

[0000950170-24-032089:mdna:192]
DZ Bank Revolving Line of Credit

[0000950170-24-032089:mdna:193]
In the fourth quarter of 2022, Adtran Networks entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings and terminated the DZ Bank revolving line of credit.

[0000950170-24-032089:mdna:194]
Syndicated Credit Agreement Note Payable

[0000950170-24-032089:mdna:195]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. On January 31, 2023, the Company repaid the outstanding borrowings and terminated the syndicated credit agreement note payable.

[0000950170-24-032089:mdna:196]
Currency Hedging Arrangements

[0000950170-24-032089:mdna:197]
On November 3, 2022, the Company entered into a euro/U.S. dollar forward contract arrangement (the "Initial Forward") with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million for U.S. dollars at a daily fixed forward rate ranging from $1.0141 to $1.0305. The aggregate amount of €160.0 million is divided into eight quarterly tranches of €20.0 million, which commenced in the fourth quarter of 2022. During the twelve months ended December 31, 2023, the Company settled four €20.0 million forward contract tranches and the remaining amount will be divided into four quarterly tranches of €20.0 million. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-24-032089:mdna:198]
On March 21, 2023, the Company entered into a euro/U.S. dollar forward contract arrangement (the “Forward”) with the Hedge Counterparty. Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of €160.0 million U.S. dollars for euros at a daily fixed forward rate ranging from $1.0882 to $1.0955 per €1.00. During the twelve months ended December 31, 2023, the Company settled four $20.0 million forward contract tranches and the remaining amount will be divided into four quarterly tranches of $20.0 million. These forward contracts were executed on March 21, 2023 (to sell EUR/buy USD) and were entered into for the purpose of unwinding the Initial Forward (to buy EUR/sell USD). The drawdown dates of the Initial Forward are set to the same date as the maturity of the new offsetting Forward.

[0000950170-24-032089:mdna:199]
Receivables Purchase Arrangements

[0000950170-24-032089:mdna:200]
The Company is party to a Receivables Purchase and Servicing Agreement with True Value S.A.R.L. (the “Factoring Agreement”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of  December 31, 2023 and  December 31, 2022, totaled $17.5 million and $14.9 million, respectively, of which $2.8 million and $1.2 million was retained pursuant to the Factoring Agreement in the reserve account, respectively. The balance in the reserve account is included in other assets on the Consolidated Balance Sheets. The cost of receivables purchase agreement is included in interest expense in the Consolidated Statements of Loss and totaled $0.9 million and $0.3 million for the years ended December 31, 2023 and December 31, 2022, respectively.

[0000950170-24-032089:mdna:201]
Domination and Profit and Loss Transfer Agreement

[0000950170-24-032089:mdna:202]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE, as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-24-032089:mdna:203]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated in 2023.

[0000950170-24-032089:mdna:204]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.12% as of December 31, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €310.3 million or approximately $342.5 million, based on an exchange rate as of December 31, 2023 and reflecting interest accrued through December 31, 2023 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation

[0000950170-24-032089:mdna:205]
had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-032089:mdna:206]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.7 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the year ended December 31, 2023, we accrued $11.5 million in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

[0000950170-24-032089:mdna:207]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the year ended December 31, 2023, 67 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €1.2 million or approximately $1.3 million based on an exchange rate as of December 31, 2023, were paid to Adtran Networks shareholders.

[0000950170-24-032089:mdna:208]
We currently hold 33,957,538 no-par value bearer shares of Adtran Networks, representing 65.32% of Adtran Networks outstanding shares as of February 2, 2024.

[0000950170-24-032089:mdna:209]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which incorporated by reference to Exhibit 10.5 of this Annual Report on Form 10-K.

[0000950170-24-032089:mdna:210]
Business Combination Transaction Costs

[0000950170-24-032089:mdna:211]
As of December 31, 2023, the Company has incurred $26.2 million of transaction costs related to the Business Combination. During the years ended December 31, 2023, 2022 and 2021, $0.1 million, $14.2 million and $11.9 million of transaction costs were incurred, respectively.

[0000950170-24-032089:mdna:212]
Business Efficiency Program

[0000950170-24-032089:mdna:213]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (the “Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expands upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment. Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). Additionally, on October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze.

[0000950170-24-032089:mdna:214]
During the year ended December 31, 2023, we recognized $25.1 million of costs relating to the Business Efficiency Program. We expect costs in the first quarter 2024 and thereafter relating to the Business Efficiency Program to range between $22.2 million and $35.2 million. Management expects these planned costs to include severance costs ranging from $12.2 million to $18.9 million in connection with an early retirement program and reductions in workforce, inventory write downs from product discontinuances ranging from $7.6 million to $10.3 million, and site consolidation transaction expenses (primarily brokers fees) ranging from $2.4 million to $6.0 million. Future cash payments include: severance costs and outplacement fees that are anticipated to be in the range of $12.2 million to $18.9 million, payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $2.4 million to $6.0 million, and potential cash payments in the range of $3.6 million to $6.3 million for anticipated product discontinuances. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures.  However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing. If required, we will amend this disclosure at such time as management is able in good faith to estimate the amount, or range of amounts, of these charges.

[0000950170-24-032089:mdna:215]
Business Combination Integration Costs

[0000950170-24-032089:mdna:216]
During the year ended December 31, 2023, we recognized $4.9 million of integration costs related to the Business Combination that are included in selling, general and administrative expenses in the Condensed Consolidated Statement of Loss. We expect to incur additional

[0000950170-24-032089:mdna:217]
integration costs and expenses associated with the implementation of the DPLTA throughout 2024 and such costs are expected to be material. These costs are separate and apart from the costs associated with the integration program discussed below.

[0000950170-24-032089:mdna:218]
Multi-Year Integration Program

[0000950170-24-032089:mdna:219]
During the fourth quarter of 2022, the Company initiated a multi-year integration program designed to optimize the assets, business processes, and information technology systems of the Company. During the years ended December 31, 2023 and 2022, we recognized $21.5 million and $1.6 million of restructuring costs relating to the Business Combination under the multi-year integration program, respectively, that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss. The Company does not anticipate additional material expenses to be incurred in connection with this integration program. See Note 23 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:mdna:220]
Other Cash Requirements

[0000950170-24-032089:mdna:221]
During the year ended December 31, 2023, other than the Exit Compensation payments, Annual Recurring Compensation under the DPLTA, restructuring costs and increased debt service costs, there have been no other material changes in cash requirements from those discussed in the 2022 Form 10-K/A and our cash requirements table shown in Liquidity and Capital Resources above.

[0000950170-24-032089:mdna:222]
Performance Bonds

[0000950170-24-032089:mdna:223]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2023 and 2022, we had commitments related to these bonds totaling $10.8 million and $21.1 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract; the probability of which we believe is remote.

[0000950170-24-032089:mdna:224]
Critical Accounting Policies and Estimates

[0000950170-24-032089:mdna:225]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part II, Item 8 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000950170-24-032089:mdna:226]
Revenue

[0000950170-24-032089:mdna:227]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. Review of contracts with customers, for both direct customers and distributors, are performed and assessed for principal versus agent considerations to determine primary responsibility for delivery of performance obligation, presumed inventory risk, and discretion in establishing pricing, when applicable. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost which we have elected to account for as a cost of fulfilling the related contract is included in cost of revenue. Revenue, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract, if material, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0000950170-24-032089:mdna:228]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0000950170-24-032089:mdna:229]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in Service Provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware revenue.

[0000950170-24-032089:mdna:230]
Hardware and Software Revenue

[0000950170-24-032089:mdna:231]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenue from software license sales is recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time products are delivered.

[0000950170-24-032089:mdna:232]
Services & Support Segment - Includes a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services to complement our Network Solutions segment.

[0000950170-24-032089:mdna:233]
Maintenance Revenue

[0000950170-24-032089:mdna:234]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenue, when applicable, is recorded in unearned revenue and non-current unearned revenue. The total balance of our unearned revenue was $71.8 million and $60.4 million as of December 31, 2023 and 2022, respectively.

[0000950170-24-032089:mdna:235]
Network Implementation Revenue

[0000950170-24-032089:mdna:236]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheets. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0000950170-24-032089:mdna:237]
New Accounts Receivable Factoring Agreement

[0000950170-24-032089:mdna:238]
On December 19, 2023, the Company entered into a new factoring agreement with a third-party financial institution to replace the Company’s prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The new factoring agreement qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company is considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retains a residual claim on reserves related to the factored receivables. The receivables factored continue to be carried in accounts receivable, less allowance for credit losses on the Consolidated Balance Sheets, secured borrowings are carried on the Company’s Consolidated Balance Sheets as a current liability, in accounts payable, proceeds and repayments of secured borrowings are reflected as cash flows provided by (used in) financing activities in the Consolidated Statements of Cash Flows and program fees are recorded in interest expense in the Company’s Consolidated Statements of Loss. The short-term liability classification of the secured borrowings is based on the estimated timing of the collection of the accounts receivable which are expected to be received within 12 months. See Note 3 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:mdna:239]
Previous Accounts Receivable Factoring Agreement

[0000950170-24-032089:mdna:240]
The Company had previously entered into a factoring agreement to sell certain receivables to an unrelated third-party financial institution on a non-recourse basis. These transactions were accounted for in accordance with ASC Topic 860 and resulted in a reduction in accounts receivable because the agreement transferred effective control over and risk related to the receivables to the buyers. Trade accounts receivables balances sold were removed from the Consolidated Balance Sheets and cash received was reflected as cash flows (used in) provided by operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense was recorded to interest expense on the Consolidated Statements of Loss. On each sale date, the financial institution retained from the sale price a default reserve, up to a required balance, which was held by the financial institution in a reserve account and pledged to the Company. The financial institution was entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account was included in other assets on the Consolidated Balance Sheets.

[0000950170-24-032089:mdna:241]
Inventory

[0000950170-24-032089:mdna:242]
We carry our inventory at the lower of cost and net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor, and manufacturing overhead are used to value inventory and are updated at least quarterly. Most variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. If actual trends and market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $83.1 million and $51.8 million at December 31, 2023 and 2022, respectively. Inventory disposals charged against the reserve were $7.6 million and $2.9 million for the years ended December 31, 2023 and December 31, 2022, respectively.

[0000950170-24-032089:mdna:243]
Stock-Based Compensation

[0000950170-24-032089:mdna:244]
For purposes of determining the estimated fair value of market-based PSU awards on the date of grant, the Monte Carlo Simulation valuation method is used. These PSUs are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of performance-based PSUs, RSUs and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. Compensation expense related to unvested performance-based PSUs is recognized over the requisite service period of two to three years as the achievement of the performance obligation becomes probable. For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable, single measure of the fair value of our stock option awards. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. As of December 31, 2023, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $15.5 million.

[0000950170-24-032089:mdna:245]
Pursuant to the Business Combination, which closed on July 15, 2022, Adtran Networks stock option holders were entitled to have their Adtran Networks stock options assumed by ADTRAN Holdings (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings. The maximum number of shares of ADTRAN Holdings stock potentially issuable upon such assumption was 2.3 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.1 million shares of ADTRAN Holdings stock were subject to assumed Adtran Networks options. The determination of the fair value of stock options assumed by ADTRAN Holdings was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors. As of December 31, 2023, total unrecognized compensation expense related to the non-vested portion of stock options was approximately $8.1 million.

[0000950170-24-032089:mdna:246]
Goodwill

[0000950170-24-032089:mdna:247]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company’s annual impairment assessment is done at the reporting unit level, which we determined are generally the same as our operating segments, which are identified in Note 18 to the Consolidated Financial Statements. We review goodwill for impairment annually during the fourth quarter and also test for impairment between annual tests if an event occurs or circumstances change that would more likely than not reduce the fair value of our reporting unit below its carrying amount. Such events and circumstances may include among others: a significant adverse change in legal factors or in the general business climate; significant decline in our stock price and market capitalization; unanticipated competition; the testing for recoverability of a significant asset group within the reporting unit; and an adverse action or assessment by a regulator. Any adverse change in these factors could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000950170-24-032089:mdna:248]
Due to the Company's decreased market capitalization and long-term projections, a reassessment of our estimated future undiscounted cash flows within our two identified reporting units was triggered. Therefore an interim impairment test over goodwill was performed as of September 30, 2023. The Company determined the fair value of each reporting unit using a combination of an income approach and a market based peer group analysis. Management’s determination of the fair value of our reporting units, based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to cash flow projections, discount rate, peer group determination and market multiple selection. It was determined that the decreases in projected future cash flows, discount rates, overall macroeconomic conditions, as well as the decrease in our market capitalization applied in the valuation, were required to align with market-based assumptions and company-specific risk, which resulted in lower fair values of the Services & Support reporting unit. As a result of the interim assessment, the Company recorded a goodwill impairment charge of $37.9 million as its estimated fair value was less than its book value on that date.

[0000950170-24-032089:mdna:249]
The Company’s annual impairment test date was October 1, 2023. The Company concluded that there was no goodwill impairment as of that date as there was no change in enterprise value from the September 30, 2023 testing date. Between the annual impairment date of October 1, 2023 and year-end December 31, 2023, there were no additional triggering events.

[0000950170-24-032089:mdna:250]
As a result of the Business Combination during 2022, the Company recognized $350.5 million of goodwill. During the fourth quarter of 2022, we decided to proceed directly to the quantitative test of goodwill and forego the qualitative assessment. We estimated the fair value of our reporting units based on an income approach, whereby we calculated the fair value of a reporting unit based on the present value of estimated future cash flows. Our discounted cash flow analysis required us to make various judgmental assumptions about future sales, operating margins, growth rates and discount rates, which are based on our budgets, business plans, economic projections, anticipated future cash flows and market participants. We also estimated the fair value of our reporting units based on a peer group analysis, whereby companies in the telecommunications industry or with a comparable product and market structure are used to calculate a fair enterprise value using revenue, EBITDA and debt multiples of trading value. Based on our analysis, management concluded that there was no impairment of goodwill as of December 31, 2022.

[0000950170-24-032089:mdna:251]
No goodwill impairment charge was recorded in 2021 as a result of the Company’s internal assessment.

[0000950170-24-032089:mdna:252]
The balance of our goodwill was $353.4 million and $381.7 million as of December 31, 2023 and 2022, respectively.

[0000950170-24-032089:mdna:253]
Intangible Assets

[0000950170-24-032089:mdna:254]
Purchased intangible assets with finite lives are carried at cost less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets.

[0000950170-24-032089:mdna:255]
As part of the purchase price allocation related to the Business Combination with Adtran Networks, the Company recognized $403.8 million of intangible assets on July 15, 2022. The balance of our intangible assets was $328.0 million and $401.2 million as of December 31, 2023 and 2022, respectively.

[0000950170-24-032089:mdna:256]
Impairment of Long-Lived Assets and Intangibles

[0000950170-24-032089:mdna:257]
Long-lived assets and intangibles used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of assets within a reporting unit may not be recoverable and the undiscounted cash flows estimated to be generated by the assets are less than the reporting units carrying value. The identification of our reporting units begins at the operating segment level and considers whether components one level below the operating segment levels should be identified as reporting units for the purpose of testing assets for impairment. For impairment testing purposes, we determined the Company's reporting units are generally the same as its operating segments, which are identified in Note 18 to the Consolidated Financial Statements. Our general policy is to qualitatively assess the carrying value of assets in our reporting units each reporting period for events or changes in circumstances that would more likely than not reduce the fair value of the reporting unit below its carrying amount.

[0000950170-24-032089:mdna:258]
During the fourth quarter of 2023, the Company qualitatively assessed the carrying value of each reporting unit for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Based on our assessment of certain qualitative factors such as macro-economic conditions, industry and market considerations, cost factors and overall financial performance, management concluded that the fair value of the reporting unit was more likely than not greater than its carrying amount as of December 31, 2023.

[0000950170-24-032089:mdna:259]
In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result the Company recognized impairment charges of $17.4 million during the year ended December 31, 2022 primarily related to capitalized implementation costs for a cloud computing arrangement. The impairment charges were determined based on actual costs incurred.

[0000950170-24-032089:mdna:260]
There were no impairment losses for long-lived assets during the years ended December 31, 2023 and 2021, or for intangible assets recognized during the years ended December 31, 2023, 2022 or 2021.

[0000950170-24-032089:mdna:261]
Income Taxes

[0000950170-24-032089:mdna:262]
We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. We continually review the adequacy of our valuation allowance and recognize the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes. During the fourth quarter of 2022, after considering all quantitative and qualitative evidence, including our cumulative income position, historical operating performance and future income projections, we have determined that the positive evidence overcame the negative evidence and have concluded that it is more likely than not that a substantial portion of our U.S. federal and certain other state deferred tax assets were realizable. As a result, we have released the majority of our valuation allowance against those assets. However, the amount of deferred tax assets considered realizable could be adjusted in future periods in the event that sufficient evidence is no longer present to support a conclusion that it is more likely than not that all or a portion of our domestic deferred tax assets will be realized.

[0000950170-24-032089:mdna:263]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0000950170-24-032089:mdna:264]
Liability for Warranty

[0000950170-24-032089:mdna:265]
Our products generally include warranties of 90 days to five years for product defects. We accrue a provision for warranty returns at the time of product shipment based on our historical return rate and an estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $6.4 million and $7.2 million at December 31, 2023 and 2022, respectively. These liabilities are included in accrued expenses and other liabilities in the accompanying Consolidated Balance Sheets.

[0000950170-24-032089:mdna:266]
Pension Benefit Plan Obligations

[0000950170-24-032089:mdna:267]
Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $12.7 million and $10.6 million at December 31, 2023 and December 31, 2022, respectively. This liability is included in pension liability in the accompanying Consolidated Balance Sheets.

[0000950170-24-032089:mdna:268]
Lease Obligations

[0000950170-24-032089:mdna:269]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain potential embedded leases. These other contracts are specifically reviewed to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease. Some of our leases include options to renew. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. The exercise of lease renewal options is at our sole discretion. The depreciable life of leased assets and leasehold improvements are limited by the expected lease term. Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. Our lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-24-032089:mdna:270]
Business Combinations

[0000950170-24-032089:mdna:271]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition subject to purchase accounting adjustments. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets and liabilities assumed or acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired and liabilities assumed exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying Consolidated Statements of Loss since their dates of acquisition. Costs incurred to complete the Business Combination, such as legal, accounting or other professional fees, are charged to selling, general and administrative expenses as incurred.

[0000950170-24-032089:mdna:272]
Recently Issued Accounting Pronouncements

[0000950170-24-032089:mdna:273]
For a discussion of recently issued accounting pronouncements, see Note 1 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.
