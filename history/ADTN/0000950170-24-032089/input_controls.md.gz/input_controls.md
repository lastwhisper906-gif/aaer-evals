# ADTN 10-K controls and the auditor's report


## auditors_report

[0000950170-24-032089:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000950170-24-032089:auditors_report:2]
To the Board of Directors and Stockholders of ADTRAN Holdings, Inc.

[0000950170-24-032089:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000950170-24-032089:auditors_report:4]
We have audited the accompanying consolidated balance sheets of ADTRAN Holdings, Inc. and its subsidiaries (the “Company”) as of December 31, 2023 and 2022, and the related consolidated statements of loss, of comprehensive (loss) income, of changes in equity and of cash flows for each of the three years in the period ended December 31, 2023, including the related notes and financial statement schedule listed in the accompanying index (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of December 31, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000950170-24-032089:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2023 and 2022, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2023 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company did not maintain, in all material respects, effective internal control over financial reporting as of December 31, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO because material weaknesses in internal control over financial reporting existed as of that date related to the Company not (i) designing and maintaining effective controls in response to the risks of material misstatement; (ii) designing and maintaining effective controls over financial statement preparation, presentation and disclosure commensurate with its financial reporting requirements; and (iii) designing and maintaining effective controls to address the initial application of complex accounting standards and accounting of non-routine, unusual or complex events and transactions.

[0000950170-24-032089:auditors_report:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weaknesses referred to above are described in Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. We considered these material weaknesses in determining the nature, timing, and extent of audit tests applied in our audit of the 2023 consolidated financial statements, and our opinion regarding the effectiveness of the Company’s internal control over financial reporting does not affect our opinion on those consolidated financial statements.

[0000950170-24-032089:auditors_report:7]
Basis for Opinions

[0000950170-24-032089:auditors_report:8]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in management's report referred to above. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000950170-24-032089:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000950170-24-032089:auditors_report:10]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000950170-24-032089:auditors_report:11]
Definition and Limitations of Internal Control over Financial Reporting

[0000950170-24-032089:auditors_report:12]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in

[0000950170-24-032089:auditors_report:13]
78

[0000950170-24-032089:auditors_report:14]
accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000950170-24-032089:auditors_report:15]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000950170-24-032089:auditors_report:16]
Critical Audit Matters

[0000950170-24-032089:auditors_report:17]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000950170-24-032089:auditors_report:18]
Interim Goodwill Impairment Assessments – Network Solutions and Services & Support Reporting Units

[0000950170-24-032089:auditors_report:19]
As described in Notes 1 and 9 to the consolidated financial statements, the Company’s goodwill balance was $353.4 million as of December 31, 2023, and the goodwill associated with the Network Solutions and Services & Support reporting units was $297.0 million and $56.4 million, respectively. Goodwill is tested by management for impairment at the reporting unit level annually as of October 1, or if an event occurs or circumstances change that would more likely than not reduce the fair value of the Company’s reporting unit below its carrying amount. During the third quarter of 2023, the Company’s market capitalization and long-term projections decreased and triggered a reassessment of the estimated future undiscounted cash flows within the Company’s two identified reporting units as of September 30, 2023. Management determined the fair value of each reporting unit using a combination of an income approach and a market based peer group analysis. Management’s determination of the fair value of the Company’s reporting units, based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to cash flow projections, discount rate, peer group determination and market multiple selection. As disclosed by management, as a result of the interim assessment, the Company recognized a non-cash goodwill impairment charge of $37.9 million for the Services & Support reporting unit.

[0000950170-24-032089:auditors_report:20]
The principal considerations for our determination that performing procedures relating to the interim goodwill impairment assessments of the Network Solutions and Services & Support reporting units is a critical audit matter are (i) the significant judgment by management when developing the fair value estimates of the Network Solutions and Services & Support reporting units; (ii) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s significant assumptions related to cash flow projections, discount rate, peer group determination and market multiples selection; and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0000950170-24-032089:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to management’s goodwill impairment assessments, including controls over the valuation of the Network Solutions and Services & Support reporting units. These procedures also included, among others (i) testing management’s process for developing the fair value estimates of the Network Solutions and Services & Support reporting units; (ii) evaluating the appropriateness of the income approach and the market based peer group analyses used by management; (iii) testing the completeness and accuracy of underlying data used by management in the income approach and market based peer group analyses; and (iv) evaluating the reasonableness of the significant assumptions used by management related to cash flow projections, discount rate, peer group determination and market multiples selection. Evaluating management’s assumption related to cash flow projections involved evaluating whether the assumption used by management was reasonable considering (i) the current and past performance of the Network Solutions and Services & Support reporting units; (ii) the consistency with external market and industry data; and (iii) whether the assumption was consistent with evidence obtained in other areas of the audit. Professionals with specialized skill and knowledge were used to assist in evaluating (i) the appropriateness of the income approach and market based peer group analyses and (ii) the reasonableness of the assumptions related to the discount rate, peer group determination and market multiples selection.

[0000950170-24-032089:auditors_report:22]
/s/ PricewaterhouseCoopers LLP

[0000950170-24-032089:auditors_report:23]
Birmingham, Alabama

[0000950170-24-032089:auditors_report:24]
March 15, 2024

[0000950170-24-032089:auditors_report:25]
We have served as the Company’s auditor since 1986.

[0000950170-24-032089:auditors_report:26]
79

[0000950170-24-032089:auditors_report:27]
Financial Statements

[0000950170-24-032089:auditors_report:28]
ADTRAN Holdings, Inc.


## item_9a

[0000950170-24-032089:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0000950170-24-032089:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000950170-24-032089:item_9a:3]
We maintain disclosure controls and procedures that are designed to ensure that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000950170-24-032089:item_9a:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e)) under the Exchange Act. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that due to the material weaknesses in our internal control over financial reporting described below, our disclosure controls and procedures were not effective as of December 31, 2023.

[0000950170-24-032089:item_9a:5]
Management's Report on Internal Control over Financial Reporting

[0000950170-24-032089:item_9a:6]
Management of ADTRAN Holdings, Inc. (“ADTRAN”) is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act. ADTRAN’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. ADTRAN’s internal control over financial reporting includes those policies and procedures that:

[0000950170-24-032089:item_9a:7]
•
pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of ADTRAN;

[0000950170-24-032089:item_9a:8]
•
provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of ADTRAN are being made only in accordance with authorizations of management and directors of ADTRAN; and

[0000950170-24-032089:item_9a:9]
•
provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of ADTRAN’s assets that could have a material effect on the financial statements.

[0000950170-24-032089:item_9a:10]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000950170-24-032089:item_9a:11]
Management assessed the effectiveness of ADTRAN’s internal control over financial reporting as of December 31, 2023. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO") in Internal Control-Integrated Framework (2013).

[0000950170-24-032089:item_9a:12]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. In its assessment of the effectiveness of internal control over financial reporting as of December 31, 2023, management determined that there were deficiencies in ADTRAN’s internal control over financial reporting that constituted material weaknesses as follows:

[0000950170-24-032089:item_9a:13]
•
The Company did not design and maintain effective controls in response to the risks of material misstatement. Specifically, changes to existing controls or the implementation of new controls have not been sufficient to respond to changes to the risks of material misstatement to financial reporting. This material weakness contributed to the following additional material weaknesses:

[0000950170-24-032089:item_9a:14]
•
The Company did not design and maintain effective controls over financial statement preparation, presentation and disclosure commensurate with its financial reporting requirements. Specifically, the Company did not design and maintain effective controls over the presentation and disclosure of transactions, including non-controlling interest.

[0000950170-24-032089:item_9a:15]
134

[0000950170-24-032089:item_9a:16]
•
The Company did not design and maintain effective controls to address the initial application of complex accounting standards and accounting of non-routine, unusual or complex events and transactions. Specifically, the Company did not design and maintain effective controls to timely analyze and account for (i) non-controlling interest and (ii) the receivable purchase and servicing agreement.

[0000950170-24-032089:item_9a:17]
The material weaknesses resulted in the restatements and revisions of and immaterial adjustments to our consolidated financial statements for the year ended December 31, 2022, as well as the condensed consolidated financial statements for the quarterly and year-to-date periods ended September 30, 2022, March 31, 2023, June 30, 2023, and September 30, 2023. The material weaknesses also resulted in material adjustments to our consolidated financial statements for the year ended December 31, 2023. Additionally, these material weaknesses could result in misstatements of the Company’s accounts or disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0000950170-24-032089:item_9a:18]
Because of these material weaknesses, management has concluded that the Company did not maintain effective internal control over financial reporting as of December 31, 2023.

[0000950170-24-032089:item_9a:19]
The effectiveness of our internal control over financial reporting as of December 31, 2023 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which appears in Item 8.

[0000950170-24-032089:item_9a:20]
Management’s Remediation Efforts for Unremediated Material Weaknesses

[0000950170-24-032089:item_9a:21]
To remediate the material weaknesses in the Company’s internal control over financial reporting related to the risks of material misstatement, including financial statement preparation, presentation and disclosure of transactions and the non-controlling interest, the Company plans to initiate a remediation plan that includes designing and implementing new or enhanced controls over the review of our consolidated financial statements and identification and assessment of risks of material misstatement. We believe that the foregoing actions will support the improvement of the Company’s internal control over financial reporting, and, through our efforts to identify, design, and implement the necessary control activities, will be effective in remediating such material weaknesses.

[0000950170-24-032089:item_9a:22]
To remediate the material weaknesses in the Company’s internal control over financial reporting relating to accounting of non-routine unusual or complex events and transactions for non-controlling interest and the receivable purchase and servicing agreement, the Company plans to initiate a remediation plan that includes designing and implementing new controls over the identification and review of contracts, transactions or arrangements that may result in a financial obligation including the use of an accounting specialist as needed to ensure proper presentation of these items within our financial statements.

[0000950170-24-032089:item_9a:23]
We will continue to devote significant time and attention to these remediation efforts. As we continue to evaluate and work to improve our internal control over financial reporting, management may determine to take additional measures to address the material weaknesses or determine to modify the remediation plans described above. Until the remediation steps set forth above, including the efforts to implement the necessary control activities that we identify, are fully completed, and there has been time for us to conclude through testing that the control activities are operating effectively, the material weaknesses described above will not be considered remediated.

[0000950170-24-032089:item_9a:24]
Remediation of Previously Disclosed Material Weakness

[0000950170-24-032089:item_9a:25]
As previously reported in Item 9A of our Annual Report on Form 10-K for the year ended December 31, 2022 of Amendment No. 1, we identified the following material weakness in our internal control over financial reporting, which was remediated as of December 31, 2023.

[0000950170-24-032089:item_9a:26]
•
We identified that we did not design and maintain effective controls over the presentation and disclosure of debt agreements, specifically to ensure the presentation and disclosure reflect the terms of the agreements.

[0000950170-24-032089:item_9a:27]
During the three months ended September 30, 2023, our management implemented a new control over the review of new or amendments to our agreements for terms and conditions that impact the presentation or disclosure of debt. As of December 31, 2023, our management determined that the new control has been in place for a sufficient period of time and concluded, through testing, that the material weakness identified above has been remediated.

[0000950170-24-032089:item_9a:28]
Changes in Internal Control over Financial Reporting.

[0000950170-24-032089:item_9a:29]
There were no changes in the Company’s internal control over financial reporting that occurred during the most recent fiscal quarter covered by this report that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.
