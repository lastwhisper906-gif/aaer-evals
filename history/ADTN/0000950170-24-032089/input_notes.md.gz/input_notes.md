# ADTN notes — 0000950170-24-032089


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-24-032089:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0000950170-24-032089:notes:2]
Portions of the Proxy Statement for the registrant's 2024 Annual Meeting of Stockholders are incorporated herein by reference into Part III of this report to the extent described in Part III.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-24-032089:notes:3]
Note 1 – Nature of Business

[0000950170-24-032089:notes:4]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers; alternative Service Providers, such as utilities, municipalities and fiber overbuilders; cable/MSOs; SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-24-032089:notes:5]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs  for high-speed connectivity from the network core to the end consumer and in particular upon the convergence of solutions at the network edge.

[0000950170-24-032089:notes:6]
Liquidity, Domination and Profit and Loss Transfer Agreement and Credit Facility

[0000950170-24-032089:notes:7]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE ("Adtran Networks"), as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-24-032089:notes:8]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated in 2023.

[0000950170-24-032089:notes:9]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.12% as of December 31, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €310.3 million or approximately $342.5 million, based on an exchange rate as of December 31, 2023 and reflecting interest accrued through December 31, 2023 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-032089:notes:10]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.7 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the year ended December 31, 2023, we accrued $11.5 million in Annual Recurring Compensation, which was reflected as an increase to retained deficit. With respect to the year ended December 31,

[0000950170-24-032089:notes:11]
2023, we will be obligated to pay $11.5 million in Annual Recurring Compensation on the third banking day following the 2024 ordinary general shareholders’ meeting of Adtran Networks (but in any event within eight months following December 31, 2023).

[0000950170-24-032089:notes:12]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the year ended December 31, 2023, 67 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €1.2 million or approximately $1.3 million based on an exchange rate as of December 31, 2023, were paid to Adtran Networks shareholders.

[0000950170-24-032089:notes:13]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”), which has since been amended three times. Pursuant to the terms of the Credit Agreement, as amended, the Company, ADTRAN, Inc., and the subsidiary guarantors (together, the “Credit Parties”) are subject to a liquidity covenant, which provides that, during the fourth quarter of 2023 through and including the third quarter of 2024 (the “Covenant Relief Period”) or a Springing Covenant Period (i.e., the period beginning upon the purchase by the Company of at least 60% of the outstanding shares of Adtran Networks not owned by the Company as of August 9, 2023 and the three consecutive quarterly test periods after such date), as of the last day of any fiscal quarter, the cash and cash equivalents of the Credit Parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million, limiting our ability to pay the obligations under the DPLTA. The Company had access to $202.7 million on its Credit Facility for future borrowings; however, as of December 31, 2023, the Company was limited to additional borrowings of  $38.8 million based on debt covenant compliance metrics. See Note 12, Revolving Credit Agreements, and Note 24, Subsequent Events, for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

[0000950170-24-032089:notes:14]
As of December 31, 2023, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. For the year ended December 31, 2023, 67 thousand shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €1.2 million or approximately $1.3 million based on an exchange rate of December 31, 2023, were paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-32 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks shares.

[0000950170-24-032089:notes:15]
The Company experienced revenue declines in 2023. To the extent that the Company is further impacted by the uncertain macroeconomic environment related to continued elevated interest rates and ongoing inflationary pressures, the Company has established plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a business efficiency program, which includes, but is not limited to, our ongoing integration program, planned reductions in operating expenses and a site consolidation plan. In connection with the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

[0000950170-24-032089:notes:16]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility, including (i) the additional funding provided for under the First Amendment to the Wells Fargo Credit Facility that was signed on August 9, 2023, (ii) the additional covenant headroom during the Covenant Relief Period provided for under the Second Amendment to Wells Fargo Credit Facility, and (iii) the exclusion of the Factoring Agreement as debt for purposes of the Credit Facility’s financial covenants as provided for under the Third Amendment to Wells Fargo Credit Facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and continue to comply with our debt covenants under the Credit Facility for at least the next twelve months, from the issuance of these financial statements. See Note 12, Revolving Credit Agreements, for additional information regarding the terms of the First Amendment of the Wells Fargo Credit agreement and Note 24, Subsequent Events, for additional information regarding the terms of the Second and Third Amendments of the Wells Fargo Credit Agreement.

[0000950170-24-032089:notes:17]
Principles of Consolidation

[0000950170-24-032089:notes:18]
The accompanying Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the U.S. (“U.S. GAAP”) and include the financial position, results of operations, comprehensive (loss) income, changes in equity and cash flows of ADTRAN and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000950170-24-032089:notes:19]
Use of Estimates

[0000950170-24-032089:notes:20]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

[0000950170-24-032089:notes:21]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts inflationary pressures, the energy crisis, currency fluctuations and political tensions as of December 31, 2023, and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to ongoing inflationary pressures, the energy crisis, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.

[0000950170-24-032089:notes:22]
Revision of Previously Issued Financial Statements

[0000950170-24-032089:notes:23]
During the fourth quarter of 2023, the Company identified an immaterial error relating to the understatement of non-controlling interest and the overstatement of accumulated other comprehensive income in the Consolidated Balance Sheet as of December 31, 2022. The immaterial misstatements occurred following the Business Combination between the Company and the Company’s majority-owned subsidiary, Adtran Networks on July 15, 2022. The Company incorrectly presented the allocation of foreign currency translation loss attributable to the non-controlling interest as well as loss attributable to non-controlling interest in calculating the comprehensive income attributable to ADTRAN Holdings, Inc., net of tax for the year ended December 31, 2022. Management evaluated the impact of this error on the Company’s full year 2022 consolidated financial statements and determined that the consolidated financial statements were not materially misstated. However, in order to correctly state non-controlling interest and accumulated other comprehensive income (loss) attributable to non-controlling interest and ADTRAN Holdings, Inc. in connection with the filing of this Form 10-K, the December 31, 2022 the balance sheet items and comprehensive loss for the year ended December 31, 2022 have been corrected to reflect the impact of this immaterial error. Accumulated Other Comprehensive Income (Loss) and Non-Controlling Interest were also adjusted within the Consolidated Statement of Changes in Equity to correct these errors.

[0000950170-24-032089:notes:24]
The following table reflects the impact of the revision to the specific line items presented in the Company’s previously reported Consolidated Balance Sheet and Consolidated Statement of Changes in Equity as of December 31, 2022:

[0000950170-24-032089:notes:25]
|  |  | December 31, 2022 |  |
| (In thousands) |  | As Reported |  |  | Adjustment |  |  | As Revised |  |
| Accumulated Other Comprehensive Income (Loss) |  | $ | 46,713 |  |  | $ | (20,587 | ) |  | $ | 26,126 |  |
| Non-Controlling Interest |  | $ | 309,072 |  |  | $ | 20,587 |  |  | $ | 329,659 |  |

[0000950170-24-032089:notes:26]
The following table reflects the impact of the revision to the specific line items presented in the Company’s previously reported Consolidated Statements of Comprehensive Loss for the year ended December 31, 2022:

[0000950170-24-032089:notes:27]
|  |  | Year Ended December 31, 2022 |  |
| (In thousands) |  | As Reported |  |  | Adjustment |  |  | As Revised |  |
| Comprehensive (Loss) Income attributable to non-controlling interest |  | $ | (918 | ) |  | $ | 13,736 |  |  | $ | 12,818 |  |
| Comprehensive Income attributable to ADTRAN Holdings, Inc., net of tax |  | $ | 49,739 |  |  | $ | (13,736 | ) |  | $ | 36,003 |  |

[0000950170-24-032089:notes:28]
The accompanying applicable Notes have been updated to reflect the effects of the revision.

[0000950170-24-032089:notes:29]
Summary of Significant Accounting Policies

[0000950170-24-032089:notes:30]
Cash and Cash Equivalents

[0000950170-24-032089:notes:31]
Cash and cash equivalents represent demand deposits, money market funds and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. As of December 31, 2023, $83.2 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions and determined the risk of material financial loss due to the exposure of such credit risk to be minimal.

[0000950170-24-032089:notes:32]
Fair Value of Financial Instruments

[0000950170-24-032089:notes:33]
Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models may be applied. Assets and liabilities recorded at fair value in our consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair values.

[0000950170-24-032089:notes:34]
The carrying amounts reported in the Consolidated Balance Sheets for cash and cash equivalents, accounts receivable and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments.

[0000950170-24-032089:notes:35]
The fair value measurements of our derivative instruments are determined using models that maximize the use of the observable market inputs including interest rate curves and both forward and spot prices for currencies, and are classified as Level II under the fair value hierarchy. The fair values of our derivatives are included in Note 11.

[0000950170-24-032089:notes:36]
The estimated fair value of our notes payable, approximates the carrying value and is classified as Level II under the fair value hierarchy. The carrying value of our notes payable is included in Note 13.

[0000950170-24-032089:notes:37]
Investments with contractual maturities beyond one year may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe we have the ability to quickly sell them to the remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. All income generated from these investments is recorded as interest income. We have not recorded any losses relating to variable rate demand notes.

[0000950170-24-032089:notes:38]
Long-term investments is comprised of our deferred compensation plan assets, corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. and foreign government bonds, marketable equity securities and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Any changes in fair value are recognized in net investment gain (loss). Realized gains and losses on sales of debt securities are computed under the specific identification method and are included in other income, net. See Note 5 for additional information.

[0000950170-24-032089:notes:39]
Accounts Receivable

[0000950170-24-032089:notes:40]
We record accounts receivable at amortized cost. Prior to establishing payment terms for a new customer, we evaluate the credit risk of the customer. Credit limits and payment terms established for new customers are re-evaluated periodically based on customer collection experience and other financial factors. As of December 31, 2023, a single customer comprised more than 10% of our total accounts receivable balance, which accounted for 11.9% of our total accounts receivable. As of December 31, 2022, single customers comprising more than 10% of our total accounts receivable balance included three customers, which accounted for 33.1% of our total accounts receivable. As of December 31, 2022, these three customers individually accounted for 11.4%, 11.1% and 10.6%, respectively, of our total accounts receivable.

[0000950170-24-032089:notes:41]
We regularly review the need for an allowance for credit losses related to our outstanding accounts receivable balances using the historical loss-rate method, as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition or credit rating by geographic location, as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. Based on this assessment, an allowance for credit losses would be recorded if the Company determined that, based on our historical write-offs, which have been immaterial, and such asset specific risks, there was risk in collectability of the full amount of any accounts receivable.

[0000950170-24-032089:notes:42]
Accounts Receivable Factoring

[0000950170-24-032089:notes:43]
New Accounts Receivable Factoring Agreement

[0000950170-24-032089:notes:44]
On December 19, 2023, the Company entered into a new factoring agreement with a third-party financial institution to replace the Company’s prior accounts receivable purchase agreement, to sell on a revolving basis, undivided interests in the Company’s accounts receivable. The new factoring agreement qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company is considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retains a residual claim on reserves related to the factored receivables. Within the Consolidated Balance Sheets, the receivables factored continue to be carried in accounts receivable, less allowance for credit losses, and the secured borrowings are carried as a current liability within accounts payable. The proceeds and repayments of secured borrowings are reflected as cash flows provided by (used in) financing activities within the Consolidated Statements of Cash Flows, and program fees are recorded as interest expense in the Consolidated Statements of Loss. The short-term liability classification of the

[0000950170-24-032089:notes:45]
secured borrowings is based on the estimated timing of the collection of the accounts receivable which are expected to be received within 12 months. See Note 3 for additional information.

[0000950170-24-032089:notes:46]
Previous Accounts Receivable Factoring Agreement

[0000950170-24-032089:notes:47]
The Company had previously entered into a factoring agreement to sell certain receivables to an unrelated third-party financial institution on a non-recourse basis. These transactions were accounted for in accordance with ASC Topic 860 and resulted in a reduction in accounts receivable because the agreement transferred effective control over and risk related to the receivables to the buyers. Trade accounts receivables balances sold were removed from the Consolidated Balance Sheets and cash received was reflected as cash flows (used in) provided by operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense was recorded to interest expense on the Consolidated Statements of Loss. On each sale date, the financial institution retained from the sale price a default reserve, up to a required balance, which was held by the financial institution in a reserve account and pledged to the Company. The financial institution was entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account was included in other assets on the Consolidated Balance Sheets.

[0000950170-24-032089:notes:48]
Inventory

[0000950170-24-032089:notes:49]
Inventory is carried at the lower of cost and estimated net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory and are updated at least quarterly. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 6 for additional information.

[0000950170-24-032089:notes:50]
Property, Plant and Equipment

[0000950170-24-032089:notes:51]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. We depreciate building and land improvements from five to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years, and computer software from three to five years. Expenditures for repairs and maintenance are charged to expense as incurred. Major improvements that materially prolong the lives of the assets are capitalized. Gains and losses on the disposal of property, plant and equipment are recorded in operating loss. See Note 7 for additional information.

[0000950170-24-032089:notes:52]
Intangible Assets

[0000950170-24-032089:notes:53]
Purchased intangible assets with finite lives are carried at cost less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets. See Note 10 for additional information.

[0000950170-24-032089:notes:54]
Impairment of Long-Lived Assets and Intangibles

[0000950170-24-032089:notes:55]
The Company’s annual impairment assessment is done at the reporting unit level whenever events or changes in circumstances indicate that the carrying amount of assets within a reporting unit may not be recoverable and the undiscounted cash flows estimated to be generated by the assets are less than the reporting units carrying value. The identification of our reporting units begins at the operating segment level and considers whether components one level below the operating segment levels should be identified as reporting units for the purpose of testing assets for impairment. For impairment testing purposes, we determined the Company's reporting units are generally the same as its operating segments, which are identified in Note 18 to the Consolidated Financial Statements. Our general policy is to qualitatively assess the carrying value of assets in our reporting units each reporting period for events or changes in circumstances that would more likely than not reduce the fair value of the reporting unit below its carrying amount.

[0000950170-24-032089:notes:56]
During the fourth quarter of 2023, the Company qualitatively assessed the carrying value of each reporting unit for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. actors and overall financial performance, management concluded that the fair value of the reporting unit was more likely than not greater than its carrying amount as of December 31, 2023.

[0000950170-24-032089:notes:57]
In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result the Company recognized impairment charges of $17.4 million during the year ended December 31, 2022 primarily related to capitalized implementation costs for a cloud computing arrangement. The impairment charges were determined based on actual costs incurred.

[0000950170-24-032089:notes:58]
There were no impairment losses for long-lived assets during the years ended December 31, 2023 and 2021, or for intangible assets recognized during the years ended December 31, 2023, 2022 or 2021.

[0000950170-24-032089:notes:59]
Goodwill

[0000950170-24-032089:notes:60]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company’s annual impairment assessment is done at the reporting unit level, which we determined are generally the same as our operating segments, which are identified in Note 18 to the Consolidated Financial Statements. We review goodwill for impairment annually during the fourth quarter and also test for impairment between annual tests if an event occurs or circumstances change that would more likely than not reduce the fair value of our reporting unit below its carrying amount. Such events and circumstances may include among others: a significant adverse change in legal factors or in the general business climate; significant decline in our stock price and market capitalization; unanticipated competition; the testing for recoverability of a significant asset group within the reporting unit; and an adverse action or assessment by a regulator. Any adverse change in these factors could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000950170-24-032089:notes:61]
Due to the Company's decreased market capitalization and long-term projections, a reassessment of our estimated future undiscounted cash flows within our two identified reporting units was triggered. Therefore an interim impairment test over goodwill was performed as of September 30, 2023. The Company determined the fair value of each reporting unit using a combination of an income approach and a market based peer group analysis. Management’s determination of the fair value of our reporting units, based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to cash flow projections, discount rate, peer group determination and market multiple selection. It was determined that the decreases in projected future cash flows, discount rates, overall macroeconomic conditions, as well as the decrease in our market capitalization applied in the valuation, were required to align with market-based assumptions and company-specific risk, which resulted in lower fair values of the Services & Support reporting unit. As a result of the interim assessment, the Company recorded a goodwill impairment charge of $37.9 million as its estimated fair value was less than its book value on that date.

[0000950170-24-032089:notes:62]
The Company’s annual impairment test date is October 1, 2023. The Company concluded that there was no goodwill impairment as of that date as there was no change in enterprise value from the September 30, 2023 testing date. Between the annual impairment date of October 1, 2023 and year-end December 31, 2023, there were no additional triggering events.

[0000950170-24-032089:notes:63]
As a result of the Business Combination during 2022, the Company recognized $350.5 million of goodwill. During the fourth quarter of 2022, we decided to proceed directly to the quantitative test of goodwill and forego the qualitative assessment. We estimated the fair value of our reporting units based on an income approach, whereby we calculated the fair value of a reporting unit based on the present value of estimated future cash flows. Our discounted cash flow analysis required us to make various judgmental assumptions about future sales, operating margins, growth rates and discount rates, which are based on our budgets, business plans, economic projections, anticipated future cash flows and market participants. We also estimated the fair value of our reporting units based on a peer group analysis, whereby companies in the telecommunications industry or with a comparable product and market structure are used to calculate a fair enterprise value using revenue, EBITDA and debt multiples of trading value. Based on our analysis, management concluded that there was no impairment of goodwill as of December 31, 2022.

[0000950170-24-032089:notes:64]
No goodwill impairment charge was recorded in 2021 as a result of the Company’s internal assessment.

[0000950170-24-032089:notes:65]
Other Non-Current Assets

[0000950170-24-032089:notes:66]
Implementation costs incurred for hosting arrangements that are related to service contracts are capitalized and amortized over the term of the arrangement. Capitalized implementation costs totaled $0.3 million and $6.2 million as of December 31, 2023 and 2022, respectively, and are included in other non-current assets on the Consolidated Balance Sheets. In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result the Company recognized impairment charges of $16.9 million during the year ended December 31, 2022 primarily related to capitalized implementation costs for a cloud computing arrangement. The impairment charges were determined based on actual costs incurred. During the year ended December 31, 2023 and 2021, no impairment charges were recognized. We depreciate capitalized implementation costs over various lives. Amortization expense was $5.9 million, $3.9 million and $1.0 million for the years ended December 31, 2023, 2022 and 2021, respectively, which is recorded almost entirely in selling, general and administrative expenses in the Consolidated Statements of Loss.

[0000950170-24-032089:notes:67]
Liability for Warranty

[0000950170-24-032089:notes:68]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Our liability for warranty returns totaled $6.4 million and $7.2 million as of December 31, 2023 and 2022, respectively.

[0000950170-24-032089:notes:69]
Pension Benefit Plan Obligations

[0000950170-24-032089:notes:70]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $12.7 million and $10.6 million as of December 31, 2023 and 2022, respectively.

[0000950170-24-032089:notes:71]
Lease Obligations

[0000950170-24-032089:notes:72]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain potential embedded leases. These other contracts are specifically reviewed to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease. Some of our leases include options to renew. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. The exercise of lease renewal options is at our sole discretion. The depreciable life of leased assets and leasehold improvements are limited by the expected lease term. Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. Our lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-24-032089:notes:73]
Stock-Based Compensation

[0000950170-24-032089:notes:74]
We have two stock incentive plans from which stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock are available for grant to employees and directors. Costs related to these awards are recognized over their vesting periods.

[0000950170-24-032089:notes:75]
Stock-based compensation expense recognized for the years ended December 31, 2023, 2022 and 2021 was approximately $16.0 million, $28.3 million and $7.5 million, respectively. See Note 4 for additional information.

[0000950170-24-032089:notes:76]
Research and Development Costs

[0000950170-24-032089:notes:77]
Research and development costs include compensation for engineers and support personnel, contracted services, depreciation and material costs associated with new product development, enhancement of current products and product cost reductions. We continually evaluate new product opportunities and engage in intensive research for product and software development efforts. Research and development costs totaled $258.3 million, $173.8 million and $108.7 million for the years ended December 31, 2023, 2022 and 2021, respectively.

[0000950170-24-032089:notes:78]
Adtran Networks has arrangements with governmental entities for the purposes of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the years ended December 31, 2023 and 2022, the Company recognized $5.2 million and $1.1 million, respectively  as a reduction of research and development expense.

[0000950170-24-032089:notes:79]
Income Taxes

[0000950170-24-032089:notes:80]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax basis of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0000950170-24-032089:notes:81]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0000950170-24-032089:notes:82]
Foreign Currency

[0000950170-24-032089:notes:83]
Transactions with customers that are denominated in foreign currencies are recorded using the appropriate exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are remeasured at the balance sheet dates using the closing rates of exchange between those foreign currencies and the functional currency with any transaction gains or losses reported in other income, net. Our primary exposures to foreign currency exchange rate movements are with our German and United Kingdom subsidiaries, whose functional currencies are the Euro and the British pound sterling.  Adjustments resulting from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive income.

[0000950170-24-032089:notes:84]
Revenue

[0000950170-24-032089:notes:85]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. Review of contracts with customers, for both direct customers and distributors, are performed and assessment made regarding principal versus agent considerations to determine primary responsibility for delivery of performance obligation, presumed inventory risk, and discretion in establishing pricing, when applicable. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost is included in cost of revenue. Revenue, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract, if material, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to account for shipping fees as a cost of fulfilling the related contract. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0000950170-24-032089:notes:86]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0000950170-24-032089:notes:87]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in Service Provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware revenue.

[0000950170-24-032089:notes:88]
Hardware and Software Revenue

[0000950170-24-032089:notes:89]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenue from software license sales is recognized at delivery and transfer of control to the customer. Revenue is recognized net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time products are delivered.

[0000950170-24-032089:notes:90]
Services & Support Segment - Includes a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services to complement our Network Solutions segment.

[0000950170-24-032089:notes:91]
Maintenance Revenue

[0000950170-24-032089:notes:92]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenue, when applicable, are recorded in current and non-current unearned revenue.

[0000950170-24-032089:notes:93]
Network Implementation Revenue

[0000950170-24-032089:notes:94]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0000950170-24-032089:notes:95]
See Notes 3 and 18 for additional information on reportable segments.

[0000950170-24-032089:notes:96]
Unearned Revenue

[0000950170-24-032089:notes:97]
Unearned revenue primarily represents customer billings on maintenance service programs and unearned revenue related to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one month to five years. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. In addition, we provide software maintenance and a variety of hardware maintenance services to customers under contracts with terms up to ten years. When we defer revenue related to multiple performance obligations where we still have contractual obligations, we also defer the related costs. Current deferred costs are included in prepaid expenses and other current assets on the accompanying Consolidated Balance Sheets and totaled $2.1 million and $1.5 million as of December 31, 2023 and 2022, respectively. Non-current deferred costs included in other non-current assets on the accompanying Consolidated Balance Sheets were less than $0.1 million as of December 31, 2023 and December 31, 2022.

[0000950170-24-032089:notes:98]
Loss per Share

[0000950170-24-032089:notes:99]
Loss per common share and loss per common share assuming dilution are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year. See Note 22 for additional information.

[0000950170-24-032089:notes:100]
Business Combinations

[0000950170-24-032089:notes:101]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition subject to purchase accounting adjustments. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets and liabilities assumed or acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired and liabilities assumed exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying Consolidated Statements of Loss since their dates of acquisition. Costs incurred to complete the Business Combination, such as legal, accounting or other professional fees are charged to selling, general and administrative expenses as incurred.

[0000950170-24-032089:notes:102]
Redeemable Non-Controlling Interest

[0000950170-24-032089:notes:103]
As of December 31, 2023 and 2022, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.7% and 34.7%, respectively.

[0000950170-24-032089:notes:104]
As a result of the effectiveness of the DPLTA on January 16, 2023, the Adtran Networks shares, representing the equity interest in Adtran Networks held by holders other than the Company, can be tendered at any time and are, therefore, redeemable and must be classified outside stockholders’ equity. Therefore, the permanent equity noncontrolling interest balance was reclassified to redeemable non-controlling interest (RNCI) on January 16, 2023 and was remeasured to fair value based on the trading market price of the Adtran Networks shares.

[0000950170-24-032089:notes:105]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. However, the RNCI will be remeasured using the current exchange rate at each reporting date as long as the RNCI is currently redeemable. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Condensed Consolidated Balance Sheets. See Note 17, Redeemable Non-Controlling Interest, for additional information on RNCI.

[0000950170-24-032089:notes:106]
Recent Accounting Pronouncements Not Yet Adopted

[0000950170-24-032089:notes:107]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2023-09 will have on our disclosures.

[0000950170-24-032089:notes:108]
In November 2023, the FASB issued ASU 2023-7, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures", which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses, allowing financial statement users to better understand the components of a segment's profit or loss to assess potential future cash flows for each reportable segment and the entity as a whole. The amendments expand a public entity's segment disclosures by requiring disclosure of significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), clarifying when an entity may report one or more additional measures to assess segment performance, requiring enhanced interim disclosures, providing new disclosure requirements for entities with a single reportable segment, and requiring other new disclosures. The amendments are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, and early adoption is permitted. The Company expect to adopt the new disclosures as required for the year ended December 31, 2024. The Company is currently evaluating the impact on the related disclosures.

[0000950170-24-032089:notes:109]
Recent Securities and Exchange Commission (SEC) Final Rules Not Yet Adopted

[0000950170-24-032089:notes:110]
In March 2024, the SEC adopted final rules under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, which requires registrants to provide certain climate-related information in their registration statements and annual reports. The rules require information about a registrant's climate-related risks that are reasonably likely to have a material impact on its business, results of operations, or financial condition. The required information about climate-related risks will also include disclosure of a registrant's greenhouse gas emissions. In addition, the rules will require registrants to present certain climate-related financial metrics in their audited financial statements. These requirements are effective for the Company in various fiscal years, starting with its fiscal year beginning January 1, 2025. Disclosures will be required prospectively, with information for prior periods required only to the extent it was previously disclosed in an SEC filing. The Company is currently evaluating the impact of these final rules on its consolidated financial statements and disclosures.

[0000950170-24-032089:notes:111]
Recently Adopted Accounting Pronouncements

[0000950170-24-032089:notes:112]
In October 2021, the FASB issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers", which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. The Company early adopted ASU 2021-08 on July 1, 2022 and the standard was applied retrospectively beginning with January 1, 2022.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-24-032089:notes:113]
Note 2 – Business Combination Agreement

[0000950170-24-032089:notes:114]
There were no business combinations during the years ended December 31, 2023 and 2021.

[0000950170-24-032089:notes:115]
Adtran Networks (formerly ADVA Optical Networking SE)

[0000950170-24-032089:notes:116]
On August 30, 2021, ADTRAN, Inc. and Adtran Networks (then known as ADVA Optical Networking SE) entered into a Business Combination Agreement, pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, ADTRAN Holdings, Inc. (formerly known as Acorn HoldCo, Inc.), which was formed as a wholly-owned subsidiary of ADTRAN, Inc. in order to consummate the transactions under the Business Combination Agreement. Under the terms of the Business Combination Agreement, on July 8, 2022, Acorn MergeCo, Inc, a Delaware corporation and wholly-owned direct subsidiary of the Company, merged with and into ADTRAN, Inc., with ADTRAN, Inc. surviving the Business Combination as a wholly-owned direct subsidiary of the Company.

[0000950170-24-032089:notes:117]
Additionally, pursuant to the Business Combination Agreement, on July 15, 2022, the Company made a public offer to exchange each issued and outstanding no-par value bearer share of Adtran Networks for 0.8244 shares of Company Common Stock, par value $0.01 per share of the Company. The Exchange Offer was settled on July 15, 2022 (the "Exchange Offer Settlement Date"), on which date the Company acquired 33,957,538 bearer shares of Adtran Networks, or 65.43% of Adtran Networks’ outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of Company Common Stock. Additionally, pursuant to the Business Combination Agreement, Adtran Networks stock option holders were entitled to have their Adtran Networks stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN, Holdings, Inc. The fair value of the Adtran Networks stock options assumed by ADTRAN Holdings, Inc. was $12.8 million, estimated using the Monte Carlo method.

[0000950170-24-032089:notes:118]
ADTRAN, Inc. and Adtran Networks became subsidiaries of ADTRAN Holdings, Inc. as a result of the Business Combination. ADTRAN, Inc. was determined to be the accounting acquirer of Adtran Networks based on ADTRAN, Inc. shareholders’ majority equity stake in the combined company, the composition of the board of directors and senior management of the combined company, among other factors. The Business Combination with Adtran Networks has been accounted for using the acquisition method of accounting as per the provisions of Accounting Standards Codification 805, “Business Combinations” (“ASC 805”). The Business Combination Agreement used a fixed exchange ratio of Company Common Stock for Adtran Networks shares of common stock, which resulted in a 36.0% equity stake for Adtran Networks stockholders and a 64.0% equity stake for ADTRAN,  Inc. stockholders in the post-closing combined company (calculated on a fully diluted basis and utilizing the tender of 65.43% of Adtran Networks’ current issued and outstanding share capital) as of July 15, 2022. Therefore, ADTRAN, Inc. shareholders continued to hold a majority interest in the combined company following the completion of the Business Combination. Additionally, following the transaction, the Board of Directors was comprised of six members from ADTRAN, Inc. and three members from Adtran Networks; the ADTRAN, Inc. chief executive officer became and continues to act as the chairman of the Board of Directors and the former Adtran Networks chief executive officer became the vice chairman of the Board of Directors. Additionally, the ADTRAN, Inc. chief executive officer and ADTRAN, Inc. chief financial officer held these positions within the combined company immediately following the completion of the Business Combination. Based upon these and other considerations as outlined in ASC 805, ADTRAN, Inc. represented the accounting acquirer.

[0000950170-24-032089:notes:119]
The following table summarizes the purchase price for the Adtran Networks business combination:

[0000950170-24-032089:notes:120]
| (In thousands, except shares, share price and exchange ratio) |  | Purchase Price |  |
| Adtran Networks shares exchanged |  |  | 33,957,538 |  |
| Exchange ratio |  |  | 0.8244 |  |
| ADTRAN Holdings, Inc. shares issued |  |  | 27,994,595 |  |
| ADTRAN Holdings, Inc. share price on July 15, 2022 |  | $ | 20.20 |  |
| Purchase price paid for Adtran Networks shares |  | $ | 565,491 |  |
| Equity compensation (1) |  | $ | 12,769 |  |
| Total purchase price |  | $ | 578,260 |  |

[0000950170-24-032089:notes:121]
(1) Represents the portion of replacement share-based payment awards that relates to pre-combination vesting.

[0000950170-24-032089:notes:122]
Assets acquired and liabilities assumed were recognized at their respective fair values as of July 15, 2022. In determining the fair value, the Company utilized various methods of the income, cost and market approaches depending on the asset or liability being fair valued. The estimation of fair value required significant judgment related to future net cash flows reflecting the risk inherent in each cash flow stream, competitive trends, market comparables and other factors. Inputs were generally determined by taking into account historical data, current and anticipated market conditions, and growth rates.

[0000950170-24-032089:notes:123]
Developed technology and customer relationships were valued using the multi-period excess earnings method. Backlog was valued using the distributor method. Significant assumptions used in the discounted cash flow analysis for (i) developed technology were the revenue growth rates, long-term revenue growth rate, discount rate, and earnings before interest, taxes, depreciation and amortization (“EBITDA”) margins, obsolescence factors, income tax rate, tax depreciation, and economic depreciation; (ii) customer relationships were earnings before interest and taxes (“EBIT”) margins, contributory asset charges, and customer attrition rate; and (iii) backlog were EBIT margins, adjusted EBIT margins, and contributory asset charges.

[0000950170-24-032089:notes:124]
The allocation of the purchase price to the assets acquired and liabilities assumed was subject to adjustment within the measurement period (up to one year from the acquisition date). The measurement period adjustments since initial preliminary estimates resulted from changes to the fair value estimates of the acquired assets and assumed liabilities based on finalizing the valuations of inventory, prepaid expenses and other current assets, property plant and equipment, intangible assets, other non-current assets and deferred tax assets and liabilities. The cumulative effect of all measurement period adjustments resulted in a decrease to recognized goodwill of $8.7 million.

[0000950170-24-032089:notes:125]
The following table summarizes the final purchase price allocation for each major class of assets acquired and liabilities assumed in the Business Combination (in thousands):

[0000950170-24-032089:notes:126]
| (In thousands) |  |  |  |
| Total purchase price |  | $ | 578,260 |  |
| Non-controlling interest |  | $ | 316,415 |  |
| Net Assets: |  |  |  |
| Cash and cash equivalents |  | $ | 44,003 |  |
| Accounts receivable |  |  | 114,659 |  |
| Other receivables |  |  | 1,457 |  |
| Inventory |  |  | 200,331 |  |
| Prepaid expenses and other current assets |  |  | 28,208 |  |
| Property plant and equipment |  |  | 55,480 |  |
| Deferred tax assets |  |  | 1,759 |  |
| Identifiable intangible assets |  |  | 403,780 |  |
| Other non-current assets |  |  | 31,074 |  |
| Accounts payable |  |  | (98,587 | ) |
| Current unearned revenue |  |  | (26,047 | ) |
| Accrued expenses and other liabilities |  |  | (59,600 | ) |
| Income tax payable, net |  |  | (4,898 | ) |
| Current portion of notes payable |  |  | (25,254 | ) |
| Tax liabilities |  |  | (1,400 | ) |
| Non-current unearned revenue |  |  | (11,498 | ) |
| Pension liability |  |  | (6,820 | ) |
| Other non-current liabilities |  |  | (6,094 | ) |
| Non-current portion of revolving credit agreements and notes payable |  |  | (15,250 | ) |
| Non-current lease obligations |  |  | (20,046 | ) |
| Deferred tax liabilities |  |  | (61,040 | ) |
| Total net assets acquired |  | $ | 544,217 |  |
| Goodwill |  | $ | 350,458 |  |

[0000950170-24-032089:notes:127]
The fair value of the assets acquired included accounts receivable of $114.7 million and other receivables of $1.5 million as of the date of the Business Combination. The unpaid principal balance under these receivables as of the date of the Business Combination was $118.5 million and $1.5 million, respectively. The difference between the fair value and the unpaid principal balance represents an allowance for credit losses that was factored into the fair value calculation as of the date of the Business Combination.

[0000950170-24-032089:notes:128]
The fair value of the identifiable intangible assets acquired as of the acquisition date:

[0000950170-24-032089:notes:129]
| (In thousands) | Estimated-average useful life (in years) (1) |  |  | Fair value |  |  | Income Statement Amortization Classification |
| Developed technology |  | 8.5 |  |  | $ | 291,925 |  |  | Cost of revenue - Network Solutions |
| Backlog |  | 1.4 |  |  |  | 52,165 |  |  | Cost of revenue - Network Solutions and Services & Support |
| Customer relationships |  | 10.5 |  |  |  | 32,704 |  |  | Selling, general and administrative expenses |
| Trade name |  | 2.8 |  |  |  | 26,986 |  |  | Selling, general and administrative expenses |
| Total |  |  |  | $ | 403,780 |  |  |  |

[0000950170-24-032089:notes:130]
(1) Determination of the weighted average period of the individual categories of intangible assets was based on the nature of the applicable intangible asset and the expected future cash flows to be derived from the intangible asset. Amortization of intangible assets with definite lives is recognized over the period of time the assets are expected to contribute to future cash flows.

[0000950170-24-032089:notes:131]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and intangible assets acquired. The Business Combination resulted in the recognition of goodwill of $350.5 million, which the Company believes is attributable to the value driven by the Company’s expected growth of the business, synergies, and expanded market and product opportunities. Goodwill created as a result of the Business Combination is not deductible for tax purposes.

[0000950170-24-032089:notes:132]
After the Business Combination, the chief operating decision maker assessed and will continue to assess the Company’s performance and allocate resources to its two segments (1) Network Solutions and (2) Services & Support. The goodwill resulting from the Business Combination of $272.8 million was allocated to the Network Solutions segment, and $77.7 million was allocated to the Services & Support segment. See Note 18 of the Notes to Consolidated Financial Statements, included in this report for more information about the Company’s segments.

[0000950170-24-032089:notes:133]
As of the acquisition date, the fair value of the non-controlling interest was approximately $316.4 million and determined using a market approach. As a portion of Adtran Networks' shares remains trading after the Business Combination, the non-controlling interest was calculated using 17,941,496 Adtran Networks shares held by non-controlling interest multiplied by the Adtran Networks closing share price of €17.58 ($17.64 using the July 15, 2022 EUR to USD conversion rate of $1.00318) on July 15, 2022.

[0000950170-24-032089:notes:134]
The Company has included the financial results of Adtran Networks in its consolidated financial statements since July 15, 2022, the acquisition date. The net revenue from the Adtran Networks business for the Adtran Networks business for the period from July 15, 2022 through December 31, 2022, was $365.9 million and the net loss from the Adtran Networks business for the period from July 15, 2022 through December 31, 2022, was $12.9 million which are included in the Company’s Consolidated Statement of Loss. The net revenue from the Adtran Networks business for the year ended December 31, 2023, was $666.3 million and the net loss from the Adtran Networks business for the year ended December 31, 2023, was $93.6 million which are included in the Company’s Consolidated Statement of Loss. The net (income) loss attributable to non-controlling interest from the Adtran Networks business for the years ended December 31, 2023 and 2022 was $8.4 million and ($6.9) million, respectively. For the year ended December 31, 2023, we recognized $11.5 million, representing the portion of the annual recurring cash compensation to the non-controlling shareholders accrued during such periods, which will be paid after the ordinary general shareholders' meeting of Adtran Networks beginning in 2024. See Note 1 and Note 17 for additional information on RNCI and the annual dividend.

[0000950170-24-032089:notes:135]
As of December 31, 2023, the Company has incurred $26.2 million of transaction costs related to the Business Combination, of which $0.1 million, $14.2 million and $11.9 million were incurred during the years ended December 31, 2023, 2022 and 2021, respectively. These transaction costs are recorded in selling, general and administrative expenses in the Consolidated Statements of Loss.

[0000950170-24-032089:notes:136]
Supplemental Pro Forma Information (Unaudited)

[0000950170-24-032089:notes:137]
The unaudited pro forma financial information in the table below summarizes the combined results of operations for ADTRAN, Inc. and Adtran Networks as though the Business Combination had occurred on January 1, 2021. The pro forma amounts have been adjusted for differences in basis of accounting which are determined before taking into effect the impacts of purchase accounting and Business Combination accounting impacts.

[0000950170-24-032089:notes:138]
The following unaudited pro forma information is presented for illustrative purposes only. It is not necessarily indicative of the results of operations of future periods, the results of operations that actually would have been realized had the entities been a single company as of January 1, 2021, or the future operating results of the combined entities. The unaudited pro forma information does not give effect to the potential impact of current financial conditions, regulatory matters or any anticipated synergies, operating efficiencies or cost savings that may be associated with the acquisition. The unaudited pro forma information also does not include any integration costs that the Company has incurred and may continue to incur related to the Business Combination as part of combining the operations of the companies.

[0000950170-24-032089:notes:139]
|  | For the Years Ended December 31, |  |
| (In thousands) | 2022 |  |  | 2021 |  |
| Revenue | $ | 1,410,296 |  |  | $ | 1,210,201 |  |
| Net loss attributable to ADTRAN Holdings, Inc. | $ | (46,204 | ) |  | $ | (91,423 | ) |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-24-032089:notes:140]
Note 3 - Revenue

[0000950170-24-032089:notes:141]
The following is a description of the principal activities from which revenue is generated by reportable segment:

[0000950170-24-032089:notes:142]
Network Solutions Segment - Includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

[0000950170-24-032089:notes:143]
Services & Support Segment - Includes network design, implementation, maintenance and cloud-hosted services supporting the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

[0000950170-24-032089:notes:144]
Revenue by Category

[0000950170-24-032089:notes:145]
In addition to operating under two reportable segments, the Company also reports revenue across three categories – Subscriber Solutions, Access & Aggregation Solutions and Optical Networking Solutions.

[0000950170-24-032089:notes:146]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN, Inc. reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, we have recast these revenues such that ADTRAN, Inc.'s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions was added as a new revenue category to represent a meaningful portion of Adtran Networks' portfolio.

[0000950170-24-032089:notes:147]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at the customer premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

[0000950170-24-032089:notes:148]
Our Access & Aggregation Solutions are solutions that are used by communications Service Providers to connect residential subscribers, business subscribers and mobile radio networks to the Service Providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions, and access orchestration solutions that ensure highly reliable and efficient network performance.

[0000950170-24-032089:notes:149]
Our Optical Networking Solutions are used by communications Service Providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems, and automation platforms that are used to build high-scale, secure and assured optical networks.

[0000950170-24-032089:notes:150]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2023:

[0000950170-24-032089:notes:151]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 263,192 |  |  | $ | 34,516 |  |  | $ | 297,708 |  |
| Access & Aggregation Solutions |  |  | 304,074 |  |  |  | 54,344 |  |  |  | 358,418 |  |
| Optical Networking Solutions |  |  | 407,123 |  |  |  | 85,851 |  |  |  | 492,974 |  |
| Total |  | $ | 974,389 |  |  | $ | 174,711 |  |  | $ | 1,149,100 |  |

[0000950170-24-032089:notes:152]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2022:

[0000950170-24-032089:notes:153]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 364,238 |  |  | $ | 26,216 |  |  | $ | 390,454 |  |
| Access & Aggregation Solutions |  |  | 326,934 |  |  |  | 47,068 |  |  |  | 374,002 |  |
| Optical Networking Solutions |  |  | 225,621 |  |  |  | 35,459 |  |  |  | 261,080 |  |
| Total |  | $ | 916,793 |  |  | $ | 108,743 |  |  | $ | 1,025,536 |  |

[0000950170-24-032089:notes:154]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2021:

[0000950170-24-032089:notes:155]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 189,825 |  |  | $ | 16,385 |  |  | $ | 206,210 |  |
| Access & Aggregation Solutions |  |  | 309,009 |  |  |  | 47,785 |  |  |  | 356,794 |  |
| Optical Networking Solutions |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 498,834 |  |  | $ | 64,170 |  |  | $ | 563,004 |  |

[0000950170-24-032089:notes:156]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of December 31, 2023 and December 31, 2022 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $314.8 million and $277.2 million, respectively. As of December 31, 2023, approximately 55% is expected to be recognized over the next 12 months, and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at December 31, 2023 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-24-032089:notes:157]
The following table provides information about accounts receivable, contract assets and unearned revenue from contracts with customers:

[0000950170-24-032089:notes:158]
| (In thousands) |  | December 31, 2023 |  |  | December 31, 2022 |  |
| Accounts receivable |  | $ | 216,445 |  |  | $ | 279,435 |  |
| Contract assets(1) |  | $ | 691 |  |  | $ | 1,852 |  |
| Unearned revenue |  | $ | 46,731 |  |  | $ | 41,193 |  |
| Non-current unearned revenue |  | $ | 25,109 |  |  | $ | 19,239 |  |

[0000950170-24-032089:notes:159]
(1) Included in other receivables on the Consolidated Balance Sheets.

[0000950170-24-032089:notes:160]
The Company was party to a receivable purchase agreement with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of December 31, 2022, totaled $14.9 million of which $1.2 million was retained pursuant to the Factoring Agreement in the reserve account. As of December 31, 2023 no accounts receivable were factored under the agreement or held in the reserve account. The cost of receivables purchase agreement is included in interest expense in the Consolidated Statements of Loss and totaled $0.9 million and $0.3 million for the years ended December 31, 2023 and December 31, 2022, respectively.

[0000950170-24-032089:notes:161]
On December 19, 2023, the agreement with the Factor was terminated and the Company, entered into a receivables purchase agreement with a third-party financial institution (the “New Factor”) to replace the Company’s prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The New Factor provides for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The New Factor qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. Total secured borrowings under the agreement were $14.3 million as of December 31, 2023, leaving $25.4 million available for future borrowings. Accounts receivable pledged as collateral related to the secured borrowings were $16.9 million as of December 31, 2023. For the year ended December 31, 2023, the Company incurred program fee expenses of $13 thousand. As of December 31, 2023, the program fee rate was 6.9% percent for receivables denominated in the U.S. dollar and 5.5% for receivables denominated in the Euro.

[0000950170-24-032089:notes:162]
Of the outstanding unearned revenue balances as of December 31, 2022, $36.2 million was recognized as revenue during the year ended December 31, 2023. Of the outstanding unearned revenue balances as of December 31, 2021, $14.0 million was recognized as revenue during the year ended December 31, 2022.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-032089:notes:163]
Note 4 – Stock-Based Compensation

[0000950170-24-032089:notes:164]
The following table summarizes stock-based compensation expense related to stock options, PSUs, RSUs and restricted stock for the years ended December 31, 2023, 2022 an

[0000950170-24-032089:notes:165]
d 2021:

[0000950170-24-032089:notes:166]
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Stock-based compensation expense included in cost of revenue |  | $ | 1,293 |  |  | $ | 2,876 |  |  | $ | 543 |  |
| Selling, general and administrative expenses |  |  | 10,701 |  |  |  | 20,844 |  |  |  | 4,571 |  |
| Research and development expenses |  |  | 4,022 |  |  |  | 4,602 |  |  |  | 2,366 |  |
| Stock-based compensation expense included in operating expenses |  |  | 14,723 |  |  |  | 25,446 |  |  |  | 6,937 |  |
| Total stock-based compensation expense |  |  | 16,016 |  |  |  | 28,322 |  |  |  | 7,480 |  |
| Tax benefit for expense associated with non-qualified stock options, PSUs, RSUs and restricted stock |  |  | (3,837 | ) |  |  | (5,152 | ) |  |  | (1,849 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 12,179 |  |  | $ | 23,170 |  |  | $ | 5,631 |  |

[0000950170-24-032089:notes:167]
Stock Incentive Program Descriptions

[0000950170-24-032089:notes:168]
2020 Stock Incentive Plans

[0000950170-24-032089:notes:169]
At the annual meeting of stockholders held on May 13, 2020, the Company’s stockholders approved, upon recommendation of the Board of Directors, the adoption of the ADTRAN, Inc. 2020 Employee Stock Incentive Plan (the “2020 Employee Plan”), as well as the ADTRAN, Inc. 2020 Directors Stock Plan (the “2020 Directors Plan”), which were assumed by the Company upon consummation of the Merger. No additional awards will be granted under the Company’s previous stock incentive plans, the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (the “2015 Employee Plan”) or the 2010 Directors Stock Plan (the “2010 Directors Plan”) subsequent to the stockholders’ approval of these new stock plans. Outstanding awards granted under the 2015 Employee Plan and the 2010 Directors Plan will remain subject to the terms of such plans, and shares underlying awards granted under such plans that are cancelled or forfeited will be available for issuance under the 2020 Employee Plan or the 2020 Directors Plan, as applicable.

[0000950170-24-032089:notes:170]
Under the 2020 Employee Plan, the Company is authorized to issue 2.8 million shares of common stock to certain employees, key Service Providers and advisors through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock, any of which may be subject to performance-based conditions. RSUs and restricted stock granted under the 2020 Employee Plan will typically vest pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date. Stock options granted under the 2020 Employee Plan will typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Stock options, RSUs and restricted stock granted under the 2020 Employee Plan reduce the shares authorized for issuance under the 2020 Employee Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations or expirations of awards granted under the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan, with forfeitures, cancellations or expirations of RSUs and restricted stock increasing the shares authorized for issuance by 2.5 shares of common stock for each share underlying the award. Forfeitures, cancellations or expirations of stock options from the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan by one share of common stock for each share underlying the award.

[0000950170-24-032089:notes:171]
Under the 2020 Directors Plan, the Company is authorized to issue 0.4 million shares of common stock through stock options, restricted stock and RSUs to non-employee directors. Stock awards issued under the 2020 Directors Plan typically will become vested in full on the first anniversary of the grant date. Stock options issued under the 2020 Directors Plan will have a ten-year contractual term. Stock options, restricted stock and RSUs granted under the 2020 Directors Plan reduce the shares authorized for issuance under the 2020 Directors Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the 2010 Directors Stock Plan increase the shares authorized for issuance under the 2020 Directors Plan by one share of common stock for each share underlying the award.

[0000950170-24-032089:notes:172]
As of December 31, 2023, 1.1 million shares were available for issuance under shareholder-approved equity plans in connection with the grant and exercise of stock options, PSU’s, RSU’s or restricted stock.

[0000950170-24-032089:notes:173]
Previous Stock Incentive Plans

[0000950170-24-032089:notes:174]
In January 2015, the Board of Directors adopted the 2015 Employee Plan, which authorized 7.7 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, PSUs, RSUs and restricted stock. The 2015 Employee Plan was adopted by stockholder approval at our annual meeting of stockholders held in May 2015. PSUs, RSUs and restricted stock granted under the 2015 Plan reduce the shares authorized for issuance under the 2015 Employee Plan by 2.5 shares of common stock for each share underlying the award. Options granted under the 2015 Employee Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Expiration dates of options outstanding as of December 31, 2023 under the 2015 Employee Plan range from 2024 to 2029.

[0000950170-24-032089:notes:175]
In January 2006, the Board of Directors adopted the ADTRAN, Inc. 2006 Employee Stock Incentive Plan (the “2006 Plan”), which authorized 13.0 million shares of common stock for issuance to officers and certain employees through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock. Options granted under the 2006 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and had a ten-year contractual term. The 2006 Plan was replaced in May 2015 by the 2015 Employee Plan. Options outstanding as of December 31, 2023 under the 2006 Plan expire in 2024.

[0000950170-24-032089:notes:176]
PSUs, RSUs and restricted stock - ADTRAN Holdings, Inc.

[0000950170-24-032089:notes:177]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2022 and 2023 and the changes that occurred during 2023:

[0000950170-24-032089:notes:178]
|  |  | Number ofshares (In thousands) |  |  | WeightedAverage GrantDate Fair Value(Per Share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2022 |  |  | 1,086 |  |  | $ | 17.54 |  |
| PSUs, RSUs and restricted stock granted |  |  | 1,509 |  |  | $ | 16.43 |  |
| PSUs, RSUs and restricted stock vested |  |  | (501 | ) |  | $ | 14.67 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (152 | ) |  | $ | 17.04 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2023 |  |  | 1,942 |  |  | $ | 17.46 |  |

[0000950170-24-032089:notes:179]
The following table details the significant assumptions that impact the fair value estimate of the market-based PSUs:

[0000950170-24-032089:notes:180]
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Estimated fair value per share |  | $ | 19.26 |  |  | $ | 24.01 |  |  | $ | 26.07 |  |
| Expected volatility |  |  | 51.52 | % |  |  | 45.77 | % |  |  | 53.27 | % |
| Risk-free interest rate |  |  | 3.93 | % |  |  | 4.28 | % |  |  | 0.85 | % |
| Expected dividend yield |  |  | 2.55 | % |  |  | 1.76 | % |  |  | 1.63 | % |

[0000950170-24-032089:notes:181]
For market-based PSUs, the number of shares of common stock earned by a recipient is subject to a market condition based on ADTRAN’s relative total shareholder return against all companies in the NASDAQ Telecommunications Index at the end of a three-year performance period. Depending on the relative total shareholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the PSUs, with the shares earned distributed upon the vesting. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted PSUs vests and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of ADTRAN, as defined by the 2020 Employee Plan. The recipients of the PSUs receive dividend credits based on the shares of common stock underlying the PSUs. The dividend credits vest and are earned in the same manner as the PSUs and are paid in cash upon the issuance of common stock for the PSUs.

[0000950170-24-032089:notes:182]
During the year ended December 31, 2023, the Company granted 0.9 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over either a two or three-year period, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to either 100% or 150% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense and liabilities with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0000950170-24-032089:notes:183]
During each of the years ended December 2022 and 2021, the Company granted 0.3 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vested over one-year and two-year periods, respectively, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements. Pursuant to the Business Combination, the unearned performance-based PSUs converted to time-based RSUs which were treated as an award modification during the third quarter of 2022. This resulted in incremental compensation expense totaling $17.8 million being recognized during the twelve months ended December 31, 2022. These awards were fully vested as of December 31, 2022.

[0000950170-24-032089:notes:184]
Pursuant to the Business Combination, 0.3 million shares of market-based PSU awards converted to time-based RSU awards which were treated as an award modification during the third quarter of 2022. Given that the fair value of these awards after the modification was less than the fair value of the awards immediately before the modification, no incremental compensation expense was recognized. The Company continued to recognize compensation expense based on the award's original grant date fair value.

[0000950170-24-032089:notes:185]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the grant date. RSUs and restricted stock vest ratably over four-year and one-year periods, respectively.

[0000950170-24-032089:notes:186]
We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0000950170-24-032089:notes:187]
As of December 31, 2023, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $15.5 million, which is expected to be recognized over an average remaining recognition period of 2.1 years. There was $10.5 million of unrecognized compensation expense related to unvested 2023 performance-based PSUs, which will be recognized over the remaining requisite service period of 2.0 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures as they occur.

[0000950170-24-032089:notes:188]
Stock Options - ADTRAN Holdings, Inc.

[0000950170-24-032089:notes:189]
The following table is a summary of stock options outstanding as of December 31, 2023 and 2022 and the changes that occurred during 2023:

[0000950170-24-032089:notes:190]
|  |  | Number ofOptions(In thousands) |  |  | WeightedAverageExercise Price(Per share) |  |  | Weighted AverageRemainingContractual Lifein Years |  |  | AggregateIntrinsic Value(In thousands) |  |
| Stock options outstanding, December 31, 2022 |  |  | 3,148 |  |  | $ | 14.37 |  |  |  | 3.42 |  |  | $ | 16,251 |  |
| Stock options granted |  |  | 1,330 |  |  | $ | 5.27 |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (23 | ) |  | $ | 7.02 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (74 | ) |  | $ | 11.20 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (487 | ) |  | $ | 22.74 |  |  |  |  |  |  |  |
| Stock options outstanding, December 31, 2023 |  |  | 3,894 |  |  | $ | 10.32 |  |  |  | 5.25 |  |  | $ | 3,087 |  |
| Stock options exercisable, December 31, 2023 |  |  | 1,478 |  |  | $ | 12.47 |  |  |  | 1.62 |  |  | $ | 254 |  |

[0000950170-24-032089:notes:191]
As of December 31, 2023, there was $8.1 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 1.8 years.

[0000950170-24-032089:notes:192]
Pursuant to the Business Combination, which closed on July 15, 2022, Adtran Networks stock option holders were entitled to have their Adtran Networks stock options assumed by ADTRAN Holdings (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings. The maximum number of shares of ADTRAN Holdings stock potentially issuable upon such assumption was 2.3 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.1 million shares of ADTRAN Holdings stock are subject to assumed Adtran Networks options.

[0000950170-24-032089:notes:193]
As part of our Business Efficiency Program, on October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select employees. The Company provided the employees subject to the salary reductions with 1.3 million of stock option awards for retention purposes. Our Chief Executive Officer voluntarily reduced his salary by 50% and did not receive any awards under the Business Efficiency Program.

[0000950170-24-032089:notes:194]
The determination of the fair value of stock options assumed or granted by ADTRAN Holdings was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors.

[0000950170-24-032089:notes:195]
All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0000950170-24-032089:notes:196]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2023. The amount of aggregate intrinsic value was $3.1 million as of December 31, 2023 and will change based on the fair market value of ADTRAN’s stock. The total pre-tax intrinsic value of options exercised during the years ended December 31, 2023, 2022 and 2021 was $0.1 million, $4.0 million and $1.5 million, respectively. The fair value of options fully vesting during the years ended December 31, 2023 and 2022 was $1.1 million and $0.2 million, respectively. No options vested during the year ended December 31, 2021.

[0000950170-24-032089:notes:197]
The following table further describes our stock options outstanding as of December 31, 2023:

[0000950170-24-032089:notes:198]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range ofExercise Prices (Per Share) |  | OptionsOutstanding atDecember 31, 2023(In thousands) |  |  | Weighted AverageRemainingContractual Lifein Years |  |  | WeightedAverageExercise Price(Per Share) |  |  | OptionsExercisable atDecember 31, 2023(In thousands) |  |  | WeightedAverageExercisePrice |  |
| $5.23 – $5.23 |  |  | 1,320 |  |  |  | 9.92 |  |  | $ | 5.23 |  |  |  | — |  |  | $ | — |  |
| $5.24 – $8.58 |  |  | 716 |  |  |  | 2.01 |  |  | $ | 7.37 |  |  |  | 559 |  |  | $ | 7.45 |  |
| $8.59 – $12.17 |  |  | 773 |  |  |  | 3.72 |  |  | $ | 11.49 |  |  |  | 195 |  |  | $ | 9.49 |  |
| $12.18 – $15.33 |  |  | 415 |  |  |  | 2.20 |  |  | $ | 15.33 |  |  |  | 362 |  |  | $ | 15.33 |  |
| $15.34 – $19.08 |  |  | 670 |  |  |  | 2.93 |  |  | $ | 19.02 |  |  |  | 362 |  |  | $ | 18.97 |  |
|  |  |  | 3,894 |  |  |  |  |  |  |  |  |  | 1,478 |  |  |  |  |

[0000950170-24-032089:notes:199]
The Black-Scholes option pricing model (the “Black-Scholes Model”) is used to determine the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0000950170-24-032089:notes:200]
The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0000950170-24-032089:notes:201]
The weighted-average estimated fair value of stock options granted to employees during the years ended December 31, 2023 and 2022 was $2.99 and $5.81 per share, respectively, with the following weighted-average assumptions:

[0000950170-24-032089:notes:202]
|  |  | 2023 |  |  | 2022 |  |
| Expected volatility |  |  | 51.78 | % |  |  | 45.00 | % |
| Risk-free interest rate |  |  | 4.13 | % |  |  | 3.00 | % |
| Expected dividend yield |  |  | — |  |  |  | 1.77 | % |
| Expected life (in years) |  |  | 5.8 |  |  |  | 2.4 |  |

[0000950170-24-032089:notes:203]
There were no stock options granted during the year ended December 31, 2021.

[0000950170-24-032089:notes:204]
Stock Options - Adtran Networks

[0000950170-24-032089:notes:205]
The following table summarizes Adtran Networks stock options outstanding as of December 31, 2022 and December 31, 2023 and the changes that occurred during the year ended December 31, 2023:

[0000950170-24-032089:notes:206]
|  |  | Number ofOptions(In thousands) |  |  | WeightedAverageExercise Price(Per share) |  |  | Weighted AverageRemainingContractual Lifein Years |  |  | AggregateIntrinsic Value(In thousands) |  |
| Stock options outstanding, December 31, 2022 |  |  | 81 |  |  | $ | 8.58 |  |  |  | 4.00 |  |  | $ | 1,222 |  |
| Stock options exercised |  |  | (50 | ) |  | $ | 7.64 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (12 | ) |  | $ | 10.45 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (1 | ) |  | $ | 9.60 |  |  |  |  |  |  |  |
| Stock options outstanding, December 31, 2023 |  |  | 18 |  |  | $ | 11.04 |  |  |  | 4.48 |  |  | $ | 193 |  |
| Stock options exercisable, December 31, 2023 |  |  | — |  |  | $ | — |  |  |  | — |  |  | $ | — |  |

[0000950170-24-032089:notes:207]
As of December 31, 2023, there was $24 thousand of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 1.4 years.

[0000950170-24-032089:notes:208]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between Adtran Networks' closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2023. The amount of aggregate intrinsic value was $0.2 million as of December 31, 2023 and will change based on the fair market value of Adtran Networks' stock. The total pre-tax intrinsic value of options exercised during the year ended December 31, 2023 was $0.7 million. The total pre-tax intrinsic value of options exercised during the period July 15, 2022 through December 31, 2022 was $1.6 million.

[0000950170-24-032089:notes:209]
The following table further describes Adtran Networks' stock options outstanding as of December 31, 2023:

[0000950170-24-032089:notes:210]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range ofExercise Prices (Per Share) |  | OptionsOutstanding atDecember 31, 2023(In thousands) |  |  | Weighted AverageRemainingContractual Lifein Years |  |  | WeightedAverageExercise Price(Per Share) |  |  | OptionsExercisable atDecember 31, 2023(In thousands) |  |  | WeightedAverageExercisePrice |  |
| €10.00 - €10.00 |  |  | 18 |  |  |  | 4.48 |  |  | $ | 11.04 |  |  |  | — |  |  | $ | — |  |
|  |  |  | 18 |  |  |  |  |  |  |  |  |  | — |  |  |  |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-24-032089:notes:211]
Note 5 – Investments

[0000950170-24-032089:notes:212]
Debt Securities and Other Investments

[0000950170-24-032089:notes:213]
The Company did not have any debt securities and other investments as of December 31, 2023.

[0000950170-24-032089:notes:214]
As of December 31, 2022, the following debt securities and other investments were included in short-term investments and long-term investments on the Consolidated Balance Sheet and recorded at fair value:

[0000950170-24-032089:notes:215]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,538 |  |  | $ | 5 |  |  | $ | (81 | ) |  | $ | 2,462 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  |  |  |  | (5 | ) |  |  | 180 |  |
| Asset-backed bonds |  |  | 818 |  |  |  | 1 |  |  |  | (24 | ) |  |  | 795 |  |
| Mortgage/Agency-backed bonds |  |  | 1,853 |  |  |  |  |  |  | (105 | ) |  |  | 1,748 |  |
| U.S. government bonds |  |  | 3,870 |  |  |  | 3 |  |  |  | (188 | ) |  |  | 3,685 |  |
| Foreign government bonds |  |  | 407 |  |  |  |  |  |  | (24 | ) |  |  | 383 |  |
| Available-for-sale debt securities held at fair value |  | $ | 9,671 |  |  | $ | 9 |  |  | $ | (427 | ) |  | $ | 9,253 |  |

[0000950170-24-032089:notes:216]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities for the years ended December 31, 2023, 2022 and 2021:

[0000950170-24-032089:notes:217]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Gross realized gains on debt securities |  | $ | 9 |  |  | $ | 17 |  |  | $ | 241 |  |
| Gross realized losses on debt securities |  |  | (355 | ) |  |  | (1,211 | ) |  |  | (159 | ) |
| Total (loss) gain recognized, net |  | $ | (346 | ) |  | $ | (1,194 | ) |  | $ | 82 |  |

[0000950170-24-032089:notes:218]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt with credit deterioration during the years ended December 31, 2023, 2022 and 2021.

[0000950170-24-032089:notes:219]
The following table presents the breakdown of debt securities and other investments with unrealized losses as of December 31, 2022:

[0000950170-24-032089:notes:220]
|  |  | Continuous UnrealizedLoss Position for Lessthan 12 Months |  |  | Continuous UnrealizedLoss Position for 12Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |
| Corporate bonds |  | $ | 1,367 |  |  | $ | (39 | ) |  | $ | 583 |  |  | $ | (42 | ) |  | $ | 1,950 |  |  | $ | (81 | ) |
| Municipal fixed-rate bonds |  |  | — |  |  |  | — |  |  |  | 180 |  |  |  | (5 | ) |  |  | 180 |  |  |  | (5 | ) |
| Asset-backed bonds |  |  | 524 |  |  |  | (14 | ) |  |  | 117 |  |  |  | (10 | ) |  |  | 641 |  |  |  | (24 | ) |
| Mortgage/Agency-backed bonds |  |  | 825 |  |  |  | (23 | ) |  |  | 844 |  |  |  | (82 | ) |  |  | 1,668 |  |  |  | (105 | ) |
| U.S. government bonds |  |  | 2,215 |  |  |  | (106 | ) |  |  | 1,063 |  |  |  | (82 | ) |  |  | 3,278 |  |  |  | (188 | ) |
| Foreign government bonds |  |  | — |  |  |  | — |  |  |  | 383 |  |  |  | (24 | ) |  |  | 383 |  |  |  | (24 | ) |
| Total |  | $ | 4,931 |  |  | $ | (182 | ) |  | $ | 3,170 |  |  | $ | (245 | ) |  | $ | 8,100 |  |  | $ | (427 | ) |

[0000950170-24-032089:notes:221]
Marketable Equity Securities

[0000950170-24-032089:notes:222]
Marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost, where appropriate.

[0000950170-24-032089:notes:223]
Realized and unrealized gains and losses for our marketable equity securities for the year ended December 31, 2023, 2022 and 2021 were as follows:

[0000950170-24-032089:notes:224]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Realized gains (losses) on equity securities sold |  | $ | 17 |  |  | $ | (1,675 | ) |  | $ | (992 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 3,083 |  |  |  | (8,470 | ) |  |  | 2,671 |  |
| Total gain (loss) recognized, net |  | $ | 3,100 |  |  | $ | (10,145 | ) |  | $ | 1,679 |  |

[0000950170-24-032089:notes:225]
As of December 31,  2022, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.

[0000950170-24-032089:notes:226]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-24-032089:notes:227]
•
Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-24-032089:notes:228]
•
Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-24-032089:notes:229]
•
Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement; inputs could include information supplied by investees.

[0000950170-24-032089:notes:230]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-24-032089:notes:231]
|  |  | Fair Value Measurements as of December 31, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,302 |  |  | $ | 5,302 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities - various industries |  |  | 905 |  |  |  | 905 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,838 |  |  |  | 26,838 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,045 |  |  | $ | 33,045 |  |  | $ | — |  |  | $ | — |  |

[0000950170-24-032089:notes:232]
|  |  | Fair Value Measurements as of December 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 2,462 |  |  |  | — |  |  |  | 2,462 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 180 |  |  |  | — |  |  |  | 180 |  |  |  | — |  |
| Asset-backed bonds |  |  | 795 |  |  |  | — |  |  |  | 795 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,748 |  |  |  | — |  |  |  | 1,748 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,685 |  |  |  | 3,685 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 383 |  |  |  |  |  |  | 383 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities - various industries |  |  | 804 |  |  |  | 804 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,942 |  |  |  | 22,942 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,227 |  |  | $ | 27,659 |  |  | $ | 5,568 |  |  | $ | — |  |

[0000950170-24-032089:notes:233]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0000950170-24-032089:notes:234]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consisted of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.

[0000950170-24-032089:notes:235]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-24-032089:notes:236]
Note 6 – Inventory

[0000950170-24-032089:notes:237]
As of December 31, 2023 and 2022, inventory, net was comprised of the following:

[0000950170-24-032089:notes:238]
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Raw materials |  | $ | 152,140 |  |  | $ | 186,346 |  |
| Work in process |  |  | 17,239 |  |  |  | 12,087 |  |
| Finished goods |  |  | 192,916 |  |  |  | 229,098 |  |
| Total Inventory, net |  | $ | 362,295 |  |  | $ | 427,531 |  |

[0000950170-24-032089:notes:239]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. As of December 31, 2023 and 2022, our inventory reserve was $83.1 million and $57.0 million, respectively.

[0000950170-24-032089:notes:240]
In connection with the Company’s restructuring efforts, for the year ended December 31, 2023, management determined that there would be a discontinuation of product lines in the Network solutions segment and, as a result, wrote-down related inventories of $24.3 million, which is included in cost of revenue in the Condensed Consolidated Statements of Loss.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-24-032089:notes:241]
Note 7 – Property, Plant and Equipment

[0000950170-24-032089:notes:242]
As of December 31, 2023 and 2022, property, plant and equipment, net was comprised of the following:

[0000950170-24-032089:notes:243]
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Engineering and other equipment |  | $ | 183,336 |  |  | $ | 170,785 |  |
| Building |  |  | 79,215 |  |  |  | 82,932 |  |
| Computer hardware and software |  |  | 101,572 |  |  |  | 80,455 |  |
| Building and land improvements |  |  | 58,238 |  |  |  | 47,861 |  |
| Furniture and fixtures |  |  | 21,368 |  |  |  | 22,403 |  |
| Land |  |  | 5,242 |  |  |  | 5,364 |  |
| Total Property, Plant and Equipment |  |  | 448,971 |  |  |  | 409,800 |  |
| Less: accumulated depreciation |  |  | (325,951 | ) |  |  | (299,101 | ) |
| Total Property, Plant and Equipment, net |  | $ | 123,020 |  |  | $ | 110,699 |  |

[0000950170-24-032089:notes:244]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs or strategic plan. As a result, the Company recognized impairment charges of $0.5 million during the year ended December 31, 2022 related to software and web site development. The impairment charges were determined based on actual costs incurred. During the years ended December 31, 2023 and 2021, no impairment charges were recognized.

[0000950170-24-032089:notes:245]
Depreciation expense was $30.2 million, $20.9 million and $12.0 million for the years ended December 31, 2023, 2022 and 2021, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Loss.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000950170-24-032089:notes:246]
Note 8 – Leases

[0000950170-24-032089:notes:247]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. As of December 31, 2023, our operating leases had remaining lease terms of two months to 116 months, some of which included options to extend the leases for up to one year, and some of which included options to terminate the leases within three months. Supplemental balance sheet information related to operating leases is as follows:

[0000950170-24-032089:notes:248]
|  |  |  |  | December 31, |  |  | December 31, |  |
| (In thousands) |  | Classification |  | 2023 |  |  | 2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Other non-current assets |  | $ | 37,474 |  |  | $ | 30,340 |  |
| Total lease asset |  |  |  | $ | 37,474 |  |  | $ | 30,340 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses and other liabilities |  | $ | 7,720 |  |  | $ | 7,596 |  |
| Non-current lease obligations |  | Non-current lease obligations |  |  | 31,420 |  |  |  | 22,807 |  |
| Total lease liability |  |  |  | $ | 39,140 |  |  | $ | 30,403 |  |

[0000950170-24-032089:notes:249]
Lease expense related to short-term leases was less than $0.1 million for the twelve months ended December 31, 2023, 2022 and 2021, and is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Loss. Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.7 million, $0.6 million and $0.5 million for the twelve months ended December 31, 2023, 2022 and 2021, respectively.

[0000950170-24-032089:notes:250]
The components of lease expense included in the Consolidated Statements of Loss were as follows:

[0000950170-24-032089:notes:251]
|  |  | For the Year Ended December 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Cost of revenue |  | $ | 163 |  |  | $ | 110 |  |  | $ | 51 |  |
| Research and development expenses |  |  | 990 |  |  |  | 942 |  |  |  | 1,071 |  |
| Selling, general and administrative expenses |  |  | 9,708 |  |  |  | 3,961 |  |  |  | 883 |  |
| Total operating lease expense |  | $ | 10,861 |  |  | $ | 5,013 |  |  | $ | 2,005 |  |

[0000950170-24-032089:notes:252]
As of December 31, 2023, operating lease liabilities included on the Consolidated Balance Sheet by future maturity were as follows:

[0000950170-24-032089:notes:253]
| (In thousands) |  | Amount |  |
| 2024 |  |  | 9,639 |  |
| 2025 |  |  | 8,423 |  |
| 2026 |  |  | 6,608 |  |
| 2027 |  |  | 4,923 |  |
| 2028 |  |  | 4,723 |  |
| Thereafter |  |  | 13,210 |  |
| Total lease payments |  |  | 47,526 |  |
| Less: Interest |  |  | (8,386 | ) |
| Present value of lease liabilities |  | $ | 39,140 |  |

[0000950170-24-032089:notes:254]
Future operating lease payments include $3.3 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0000950170-24-032089:notes:255]
An incremental borrowing rate is used based on information available at the commencement date in determining the present value of lease payments. The incremental borrowing rate is determined on a portfolio basis by grouping leases with similar terms, as well as grouping leases based on a U.S. dollar or euro functional currency. The following table provides information about our weighted average lease terms and weighted average discount rates:

[0000950170-24-032089:notes:256]
|  |  | As of December 31, |  |
| Weighted average remaining lease term (years) |  | 2023 |  |  | 2022 |  |
| Operating leases with USD functional currency |  |  | 8.1 |  |  |  | 7.9 |  |
| Operating leases with EUR functional currency |  |  | 5.8 |  |  |  | 4.2 |  |
| Weighted average discount rate |  |  |  |  |  |  |
| Operating leases with USD functional currency |  |  | 3.70 | % |  |  | 3.77 | % |
| Operating leases with EUR functional currency |  |  | 3.92 | % |  |  | 3.70 | % |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-24-032089:notes:257]
Note 9 – Goodwill

[0000950170-24-032089:notes:258]
The changes in the carrying amount of goodwill for the year ended December 31, 2023 are as follows:

[0000950170-24-032089:notes:259]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2022 |  | $ | 298,280 |  |  | $ | 83,444 |  |  | $ | 381,724 |  |
| Goodwill impairment |  |  | — |  |  |  | (37,500 | ) |  |  | (37,500 | ) |
| Correction of a purchase allocation adjustment |  |  | (9,662 | ) |  |  | 9,662 |  |  |  | — |  |
| Foreign currency translation adjustments |  |  | 8,413 |  |  |  | 778 |  |  |  | 9,191 |  |
| As of December 31, 2023 |  | $ | 297,031 |  |  | $ | 56,384 |  |  | $ | 353,415 |  |

[0000950170-24-032089:notes:260]
As of December 31, 2023, accumulated goodwill impairment losses in total were $37.9 million. There were no accumulated goodwill impairment losses as of December 31, 2022. No impairment charges on goodwill were recognized during the years ended December 31, 2022 and 2021.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-24-032089:notes:261]
Note 10 – Intangible Assets

[0000950170-24-032089:notes:262]
Intangible assets as of December 31, 2023 and 2022, consisted of the following:

[0000950170-24-032089:notes:263]
|  |  |  |  | 2023 |  |  | 2022 |  |
| (In thousands) | Weighted Average Useful Life(in years) |  |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |
| Customer relationships |  | 10.9 |  |  | $ | 54,856 |  |  | $ | (15,943 | ) |  | $ | 38,913 |  |  | $ | 53,847 |  |  | $ | (11,102 | ) |  | $ | 42,745 |  |
| Backlog |  | 1.6 |  |  |  | 57,391 |  |  |  | (52,022 | ) |  |  | 5,369 |  |  |  | 55,782 |  |  |  | (22,725 | ) |  |  | 33,057 |  |
| Developed technology |  | 8.5 |  |  |  | 329,369 |  |  |  | (61,271 | ) |  |  | 268,098 |  |  |  | 320,364 |  |  |  | (21,856 | ) |  |  | 298,508 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (3,797 | ) |  |  | 2,103 |  |  |  | 5,900 |  |  |  | (3,141 | ) |  |  | 2,759 |  |
| Licensing agreements |  | 8.5 |  |  |  | 560 |  |  |  | (368 | ) |  |  | 192 |  |  |  | 560 |  |  |  | (298 | ) |  |  | 262 |  |
| Patents |  | 7.3 |  |  |  | 500 |  |  |  | (500 | ) |  |  | — |  |  |  | 500 |  |  |  | (431 | ) |  |  | 69 |  |
| Trade names |  | 3.0 |  |  |  | 29,689 |  |  |  | (16,379 | ) |  |  | 13,310 |  |  |  | 28,856 |  |  |  | (5,045 | ) |  |  | 23,811 |  |
| Total |  |  |  | $ | 478,265 |  |  | $ | (150,280 | ) |  | $ | 327,985 |  |  | $ | 465,809 |  |  | $ | (64,598 | ) |  | $ | 401,211 |  |

[0000950170-24-032089:notes:264]
The Company evaluates impairment at the reporting unit level, whenever events or changes in circumstances indicate that the carrying amount of assets within a reporting unit may not be recoverable and the undiscounted cash flows estimated to be generated by the assets are less than the reporting units carrying value. The Company assessed impairment triggers related to our reporting units during each financial period in 2023, 2022 and 2021 and no impairment losses of intangible assets were recorded during the years ended December 31, 2023, 2022 and 2021. See Note 1 for additional information regarding our assessment of impairment for our reporting units.

[0000950170-24-032089:notes:265]
Amortization expense was $82.8 million, $47.3 million and $4.1 million for the years ended December 31, 2023, 2022 and 2021, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Loss.

[0000950170-24-032089:notes:266]
As of December 31, 2023, estimated future amortization expense of intangible assets was as follows:

[0000950170-24-032089:notes:267]
|  |  | As of |  |
| (In thousands) |  | December 31, 2023 |  |
| 2024 |  | $ | 59,112 |  |
| 2025 |  |  | 47,337 |  |
| 2026 |  |  | 44,040 |  |
| 2027 |  |  | 42,647 |  |
| 2028 |  |  | 42,504 |  |
| Thereafter |  |  | 92,345 |  |
| Total |  | $ | 327,985 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-24-032089:notes:268]
Note 11 - Hedging

[0000950170-24-032089:notes:269]
The Company has certain forward rate agreements to hedge foreign currency exposure of expected future cash flows in foreign currency. The Company does not hold or issue derivative instruments for trading or other speculative purposes. Derivatives are initially recognized at fair value on the date a derivative contract is entered into and are subsequently re-measured to their fair value at the end of each reporting period. All changes in the fair value of derivative instruments are recognized as other income, net in the Consolidated Statements of Loss. The derivative instruments are not subject to master netting agreements and are not offset in the Consolidated Balance Sheets. We are exposed to risk from credit-related losses resulting from nonperformance by counterparties to our financial instruments. We perform credit evaluations of our counterparties under forward exchange contracts and expect all counterparties to meet their obligations. We have not experienced credit losses from our counterparties.
 As of December 31, 2023, the Company had 47 forward rate contracts outstanding.

[0000950170-24-032089:notes:270]
Foreign Currency Hedging Agreement

[0000950170-24-032089:notes:271]
On November 3, 2022, the Company entered into a euro/U.S. dollar forward contract arrangement (the "Initial Forward") with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million for U.S. dollars at a daily fixed forward rate ranging from $1.0141 to $1.0305. The aggregate amount of €160.0 million is divided into eight quarterly tranches of €20.0 million, which commenced in the fourth quarter of 2022. During the twelve months ended December 31, 2023, the Company settled four €20.0 million forward contract tranches and the remaining amount will be divided into four quarterly tranches of €20.0 million over the course of 2024. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-24-032089:notes:272]
On March 21, 2023, the Company entered into a euro/U.S. dollar forward contract arrangement (the “Forward”) with the Hedge Counterparty. Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of €160.0 million U.S. dollars for euros at a daily fixed forward rate ranging from $1.0882 to $1.0955 per €1.00. During the twelve months ended December 31, 2023, the Company settled four $20.0 million forward contract tranches and the remaining amount will be divided into four quarterly tranches of $20.0 million. These forward contracts were executed on March 21, 2023 (to sell EUR/buy USD) and were entered into for the purpose of unwinding the Initial Forward (to buy EUR/sell USD). The drawdown dates of the Initial Forward are set to the same date as the maturity of the new offsetting Forward.

[0000950170-24-032089:notes:273]
The fair values of the Company's derivative instruments recorded in the Condensed Consolidated Balance Sheet as of December 31, 2023 were as follows:

[0000950170-24-032089:notes:274]
| (In thousands) |  | Balance Sheet Location |  | December 31, 2023 |  |  | December 31, 2022 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  | $ | 7,125 |  |  | $ | 11,992 |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  | $ | (2,277 | ) |  | $ | (633 | ) |
| Total derivatives |  |  |  | $ | 4,848 |  |  | $ | 11,359 |  |

[0000950170-24-032089:notes:275]
The change in the fair values of the Company's derivative instruments recorded in the Condensed Consolidated Statements of Loss during the years ended December 31, 2023, 2022 and 2021 were as follows:

[0000950170-24-032089:notes:276]
| (In thousands) |  | Income StatementLocation |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income, net |  | $ | 758 |  |  | $ | 10,793 |  |  | $ | — |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-24-032089:notes:277]
Note 12 – Revolving Credit Agreements

[0000950170-24-032089:notes:278]
The carrying amounts of the Company's revolving credit agreements in its Consolidated Balance Sheets were as follows:

[0000950170-24-032089:notes:279]
|  |  | As of December 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Wells Fargo credit agreement |  | $ | 195,000 |  |  | $ | 60,000 |  |
| Nord/LB revolving line of credit |  |  | — |  |  |  | 16,091 |  |
| Syndicated credit agreement working capital line of credit |  |  | — |  |  |  | 10,727 |  |
| DZ bank revolving line of credit |  |  | — |  |  |  | 9,118 |  |
| Total revolving credit agreements |  | $ | 195,000 |  |  | $ | 95,936 |  |

[0000950170-24-032089:notes:280]
As of December 31, 2023 and 2022, the estimated fair value of our revolving credit agreements, approximates the carrying value. As of December 31, 2023 and 2022, the weighted average interest rate on our revolving credit agreements was 7.45% and 4.12%, respectively.

[0000950170-24-032089:notes:281]
Wells Fargo Credit Agreement

[0000950170-24-032089:notes:282]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount, as well as the $50.0 million delayed draw term loan facility described below.

[0000950170-24-032089:notes:283]
On August 9, 2023, (the "First Amendment Effective Date") the Company, its wholly-owned direct subsidiary, ADTRAN, Inc. and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and together with the Credit Agreement, the "Credit Facility").

[0000950170-24-032089:notes:284]
The First Amendment, provided for, among other things, a new $50.0 million delayed draw term loan (“DDTL”), which (subject to certain conditions) is available for borrowing in the event of the purchase by the Company of at least sixty percent (60.0%) of the outstanding shares of Adtran Networks SE that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks SE. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through August 9, 2024.

[0000950170-24-032089:notes:285]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-24-032089:notes:286]
On January 16, 2024, the Company entered into a Second Amendment to the Credit Agreement and First Amendment to the Collateral Agreement. The Second Amendment, among other things, provides the Company and its subsidiaries with additional covenant headroom for the fourth quarter of 2023 through the third quarter of 2024 (the "Covenant Relief Period") and adds certain other financial covenants which are described below. See Note 24 for additional information.

[0000950170-24-032089:notes:287]
On March 12, 2024, the Company entered into a Third Amendment to the Credit Agreement. The Third Amendment, among other things, amends the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024 and June 30, 2024. The Company is also currently in negotiations with the Administrative Agent regarding a potential further amendment to the Credit Agreement to address the addition of certain foreign subsidiary guarantors.

[0000950170-24-032089:notes:288]
As of December 31, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $195.0 million. As of December 31, 2023, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. In addition, we may issue up to $50.0 million in letters of credit against our $400.0 million total facility. As of December 31, 2023, we had a total of $2.3 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $202.7 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of December 31, 2023, the Company was in compliance with all material covenants.

[0000950170-24-032089:notes:289]
Revolving Line of Credit Interest Rate

[0000950170-24-032089:notes:290]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin) bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.15% per annum).

[0000950170-24-032089:notes:291]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.

[0000950170-24-032089:notes:292]
“Adjusted Term SOFR” means Term SOFR for the applicable interest period plus 0.10% per annum. Adjusted Term SOFR is subject to a floor of 0.00% per annum.

[0000950170-24-032089:notes:293]
All Euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.25% per annum).

[0000950170-24-032089:notes:294]
In addition, (x) if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-032089:notes:295]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

[0000950170-24-032089:notes:296]
The increases in the commitment fee and margin rates during the Covenant Relief Period (referenced above) continue until the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the “Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, the Company has repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the Company has reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) the Company is in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-24-032089:notes:297]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

[0000950170-24-032089:notes:298]
DDTL Interest Rate

[0000950170-24-032089:notes:299]
All U.S. dollar borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.90% to 1.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.40% per annum), or (B) Adjusted Term SOFR plus an applicable margin ranging from 1.90% to 2.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.40% per annum).

[0000950170-24-032089:notes:300]
In addition to paying interest on outstanding principal under the DDTL loan, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment.

[0000950170-24-032089:notes:301]
Default interest is 2.0%per annum in excess of the rate otherwise applicable.

[0000950170-24-032089:notes:302]
Nord/LB Revolving Line of Credit

[0000950170-24-032089:notes:303]
On March 29, 2023, Adtran Networks entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit had a perpetual term that could be terminated by the Company or Nord/LB at any time. As of December 31, 2023, the Company repaid the outstanding borrowing and terminated the line of credit.

[0000950170-24-032089:notes:304]
Prior Nord/LB Revolving Line of Credit

[0000950170-24-032089:notes:305]
On August 8, 2022, Adtran Networks entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and matured in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit and terminated the line of credit.

[0000950170-24-032089:notes:306]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-24-032089:notes:307]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company repaid the outstanding borrowings and terminated the syndicated credit agreement working capital line of credit.

[0000950170-24-032089:notes:308]
DZ Bank Revolving Line of Credit

[0000950170-24-032089:notes:309]
In the fourth quarter of 2022, Adtran Networks entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings and terminated the DZ Bank revolving line of credit.


## adtn:NotesPayableDisclosureTextBlock

[0000950170-24-032089:notes:310]
Note 13 – Notes Payable

[0000950170-24-032089:notes:311]
The carrying amounts of the Company's notes payable in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-24-032089:notes:312]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | December 31, 2023 |  |  | December 31, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement note payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |

[0000950170-24-032089:notes:313]
Syndicated Credit Agreement Note Payable

[0000950170-24-032089:notes:314]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. As of December 31, 2022, the amount outstanding under the note payable is $24.6 million. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement working capital line of credit. No amounts are available for future borrowings and terminated the Syndicated credit agreement note payable.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-032089:notes:315]
Note 14 – Income Taxes

[0000950170-24-032089:notes:316]
The components of income tax expense (benefit) for the years ended December 31, 2023, 2022 and 2021 are as follows:

[0000950170-24-032089:notes:317]
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Current |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 2,545 |  |  | $ | 4,572 |  |  | $ | 11 |  |
| State |  |  | 26 |  |  |  | 88 |  |  |  | (63 | ) |
| International |  |  | 10,004 |  |  |  | (4,347 | ) |  |  | 4,166 |  |
| Total Current |  |  | 12,575 |  |  |  | 313 |  |  |  | 4,114 |  |
| Deferred |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 46,252 |  |  |  | (47,429 | ) |  |  | — |  |
| State |  |  | 6,607 |  |  |  | (6,776 | ) |  |  | — |  |
| International |  |  | (37,301 | ) |  |  | (8,183 | ) |  |  | (1,784 | ) |
| Total Deferred |  |  | 15,558 |  |  |  | (62,388 | ) |  |  | (1,784 | ) |
| Total Income Tax Expense (Benefit) |  | $ | 28,133 |  |  | $ | (62,075 | ) |  | $ | 2,330 |  |

[0000950170-24-032089:notes:318]
The effective income tax rate differs from the federal statutory rate due to the following:

[0000950170-24-032089:notes:319]
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Tax provision computed at the federal statutory rate |  |  | 21.00 | % |  |  | 21.00 | % |  |  | 21.00 | % |
| State income tax provision, net of federal benefit |  |  | 1.34 |  |  |  | 2.60 |  |  |  | 13.33 |  |
| Federal research credits |  |  | 3.26 |  |  |  | 6.74 |  |  |  | 53.77 |  |
| Foreign taxes |  |  | 3.52 |  |  |  | 6.29 |  |  |  | (4.69 | ) |
| Tax-exempt income |  |  | 0.06 |  |  |  | 0.21 |  |  |  | 3.75 |  |
| Change in valuation allowance |  |  | (35.19 | ) |  |  | 63.92 |  |  |  | (75.26 | ) |
| Non-deductible transaction costs |  |  | — |  |  |  | (2.74 | ) |  |  | (39.48 | ) |
| Foreign tax credits |  |  | 2.45 |  |  |  | (0.40 | ) |  |  | 0.14 |  |
| Stock-based compensation |  |  | (0.57 | ) |  |  | (2.09 | ) |  |  | 10.74 |  |
| Withholding taxes |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.14 |  |
| Alabama law change |  |  | — |  |  |  | — |  |  |  | (25.39 | ) |
| Adtran Networks tax exempt income |  |  | 1.42 |  |  |  | — |  |  |  | — |  |
| Return to accrual |  |  | 0.62 |  |  |  | 0.24 |  |  |  | 9.48 |  |
| Global intangible low-taxed income ("GILTI") |  |  | (5.87 | ) |  |  | (8.08 | ) |  |  | (4.29 | ) |
| Adtran Networks Goodwill Impairment |  |  | (4.62 | ) |  |  | — |  |  |  | — |  |
| Other, net |  |  | 0.40 |  |  |  | (0.24 | ) |  |  | (0.19 | ) |
| Effective Tax Rate |  |  | (12.17 | )% |  |  | 87.48 | % |  |  | (36.95 | )% |

[0000950170-24-032089:notes:320]
Loss before expense (benefit) for income taxes for the years ended December 31, 2023, 2022 and 2021 is as follows:

[0000950170-24-032089:notes:321]
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| U.S. entities |  | $ | (113,951 | ) |  | $ | (33,720 | ) |  | $ | (14,982 | ) |
| International entities |  |  | (117,259 | ) |  |  | (37,243 | ) |  |  | 8,677 |  |
| Total |  | $ | (231,210 | ) |  | $ | (70,963 | ) |  | $ | (6,305 | ) |

[0000950170-24-032089:notes:322]
Loss before expense (benefit) for income taxes for international entities reflects loss based on statutory transfer pricing agreements. This amount does not correlate to consolidated international revenue, which occurs from our U.S. entity.

[0000950170-24-032089:notes:323]
Deferred income taxes on the Consolidated Balance Sheets result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The significant components of current and non-current deferred taxes as of December 31, 2023 and 2022 consist of the following:

[0000950170-24-032089:notes:324]
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Inventory |  | $ | 19,623 |  |  | $ | 5,818 |  |
| Accrued expenses |  |  | 3,533 |  |  |  | 7,865 |  |
| Deferred compensation |  |  | 6,284 |  |  |  | 5,792 |  |
| Stock-based compensation |  |  | 2,023 |  |  |  | 1,373 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 105 |  |  |  | 102 |  |
| Pensions |  |  | 8,607 |  |  |  | 5,952 |  |
| Foreign losses |  |  | 2,705 |  |  |  | 4,744 |  |
| State losses and credit carry-forwards |  |  | 4,259 |  |  |  | 3,516 |  |
| Federal loss and research carry-forwards |  |  | 78,450 |  |  |  | 64,995 |  |
| Lease liabilities |  |  | 7,701 |  |  |  | 4,093 |  |
| Capitalized research and development expenditures |  |  | 48,192 |  |  |  | 31,248 |  |
| Investments |  |  | — |  |  |  | 160 |  |
| Valuation allowance |  |  | (86,567 | ) |  |  | (5,201 | ) |
| Total Deferred Tax Assets |  |  | 94,915 |  |  |  | 130,457 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Property, plant and equipment |  |  | (9,093 | ) |  |  | (8,982 | ) |
| Intellectual property |  |  | (86,572 | ) |  |  | (108,671 | ) |
| Right of use lease assets |  |  | (8,424 | ) |  |  | (6,594 | ) |
| Investments |  |  | (694 | ) |  |  | — |  |
| Total Deferred Tax Liabilities |  |  | (104,783 | ) |  |  | (124,247 | ) |
| Net Deferred Tax (Liabilities) Assets |  | $ | (9,868 | ) |  | $ | 6,210 |  |

[0000950170-24-032089:notes:325]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was signed into law. Subsequently, the Internal Revenue Service (“IRS”) released its final GILTI regulations on July 9, 2020. The passage of the CARES Act and subsequent issuance of the GILTI final regulations together resulted in the Company’s recognition of a tax benefit in the amount of $10.8 million during 2020, $7.9 million of which related to the utilization of deferred tax assets which had previously been offset with a valuation allowance and $2.9 million primarily related to the tax rate differential on carrying back losses from 2018 and 2019 tax years to prior years in which the U.S. Corporate tax rate was 35% versus the current 21% federal tax rate.

[0000950170-24-032089:notes:326]
On February 12, 2021, the Alabama Business Tax Competitiveness Act (the "Alabama Act") was signed into law. As a result of the Alabama Act, we recognized an expense of $1.6 million in the three months ended March 31, 2021 related to the revaluation of our deferred tax assets, which was offset by changes in our valuation allowance previously recorded against our domestic deferred tax assets.

[0000950170-24-032089:notes:327]
During the three months ended September 30, 2021, Management decided to pursue a claim for refund related to the revocation of our IRC Section 59(e) election that was made on our originally filed 2018 U.S. federal tax return. The Company filed a related carryback claim of net operating losses generated in 2018 to prior years as allowed under the CARES Act that was passed in 2020. An IRS Section 59(e) election is generally non-revocable except in cases for which IRS Commissioner’s approval is given. Approval is granted only in rare and unusual circumstances. We filed a private letter ruling (“PLR”) request to revoke our election. During the three months ended December 31, 2021, a response to our PLR was published denying our request to revoke the previously made 59(e). As a result of these filings, and Management’s initial position was to pursue them through appeals; therefore, we have established a receivable in the amount of $15.2 million and a deferred tax asset related to additional research and development credit carryforward in the amount of $1.8 million that would be available if our revocation request is successful, offset with an uncertain tax liability of $17.0 million. As of the year ended December 31, 2023, management no longer wishes to pursue the appeals process; therefore, the receivable, the deferred tax asset and the offsetting uncertain tax liability have been released.

[0000950170-24-032089:notes:328]
As of December 31, 2023 and 2022, non-current deferred taxes reflected deferred taxes on net unrealized gains and losses on available-for-sale investments and deferred taxes on unrealized losses in our pension plan. The net change in non-current deferred taxes associated with these items, which resulted in a deferred tax benefit of $0.3 million and $2.0 million in 2023 and 2022, respectively, was recorded as an adjustment to other comprehensive income (loss), presented in the Consolidated Statements of Comprehensive Income (Loss).

[0000950170-24-032089:notes:329]
The Company continually reviews the adequacy of our valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes (ASC 740). Due to our recent decrease in revenue and profitability for 2023 and all other positive and negative objective evidence considered as part of our analysis, our ability to consider other subjective evidence such as projections for future growth is limited when evaluating whether our deferred tax assets will be realized. As such, the Company is no longer able to conclude that it is more likely than not that our domestic deferred tax assets will be realized and a valuation allowance against our domestic deferred tax assets was established in the fourth quarter of 2023. The amount of the deferred tax assets considered realizable, however, could be adjusted in future periods in the event sufficient evidence is present to support a conclusion that it is more likely than not that all or a portion of our domestic deferred tax assets will be realized.

[0000950170-24-032089:notes:330]
As of December 31, 2023 and 2022, the Company had gross deferred tax assets totaling $76.7 million offset by a valuation allowance totaling $86.6 million and gross deferred tax assets totaling $11.4 million offset by a valuation allowance of $5.2 million, respectively. Of the current valuation allowance, $84.8 million was established against our domestic deferred tax assets and the remaining $1.8 million is related to foreign net operating loss and research and development credit carryforwards where we lacked sufficient activity to realize those deferred tax assets. The change in our valuation allowance for the year ending December 31, 2023 was an increase of $81.4 million. The change in the valuation allowance was primarily related to the previously mentioned establishment of the valuation allowance in the fourth quarter of 2023. The large increase during the year in our international deferred tax liabilities was primarily related to purchase price accounting, partially offset with acquired deferred tax assets as a result of the Adtran Networks acquisition, that was completed in the third quarter of 2022.

[0000950170-24-032089:notes:331]
Supplemental balance sheet information related to deferred tax assets (liabilities) as of December 31, 2023 and 2022 were as follows:

[0000950170-24-032089:notes:332]
|  |  | December 31, 2023 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Assets (Liabilities), net |  |
| Domestic |  | $ | 101,120 |  |  | $ | (84,767 | ) |  | $ | 16,353 |  |
| International |  |  | (24,421 | ) |  |  | (1,800 | ) |  |  | (26,221 | ) |
| Total |  | $ | 76,699 |  |  | $ | (86,567 | ) |  | $ | (9,868 | ) |

[0000950170-24-032089:notes:333]
|  |  | December 31, 2022 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 61,726 |  |  | $ | (3,177 | ) |  | $ | 58,549 |  |
| International |  |  | (50,315 | ) |  |  | (2,024 | ) |  |  | (52,339 | ) |
| Total |  | $ | 11,411 |  |  | $ | (5,201 | ) |  | $ | 6,210 |  |

[0000950170-24-032089:notes:334]
As of December 31, 2023 and 2022, the deferred tax assets for foreign and domestic loss carry-forwards, research and development tax credits, unamortized research and development costs and state credit carry-forwards totaled $135.1 million and $104.5 million, respectively. As of December 31, 2023, $87.2 million of these deferred tax assets will expire at various times between 2024 and 2039. The remaining deferred tax assets will either amortize through 2039 or carryforward indefinitely.

[0000950170-24-032089:notes:335]
As of December 31, 2023 and 2022, respectively, our cash and cash equivalents were $87.2 million and $108.6 million and short-term investments were $0.0 million and $0.3 million, which provided available short-term liquidity of $87.2 million and $108.9 million. Of these amounts, our foreign subsidiaries held cash of $76.5 million and $86.3 million, respectively, representing approximately 88% and 79% of available short-term liquidity, which is used to fund ongoing liquidity needs of these subsidiaries. As part of our restructuring plan, the Company’s assertion on being indefinitely reinvested changed in a particular jurisdiction in a previous year. The Company has a withholding tax liability of $0.4 million and $0.4 million as of December 31, 2023 and 2022, respectively. The Company maintains its assertion in all other jurisdictions that it is indefinitely reinvesting its funds held in foreign jurisdictions outside of the U.S., except to the extent any of these funds can be repatriated without withholding tax. However, if all of these funds were repatriated to the U.S., or used for U.S. operations, certain amounts could be subject to tax. Due to the timing and circumstances of repatriation of such earnings, if any, it is not practicable to determine the amount of funds subject to unrecognized deferred tax liability.

[0000950170-24-032089:notes:336]
During 2023, 2022 and 2021, no income tax benefit or expense was recorded for stock options exercised as an adjustment to equity.

[0000950170-24-032089:notes:337]
The change in the unrecognized income tax benefits for the years ended December 31, 2023, 2022 and 2021 were as follows:

[0000950170-24-032089:notes:338]
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 17,885 |  |  | $ | 17,836 |  |  | $ | 1,078 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | — |  |  |  | 17,025 |  |
| Current year |  |  | 129 |  |  |  | 123 |  |  |  | 136 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | (17,025 | ) |  |  | (13 | ) |  |  | (27 | ) |
| Expiration of applicable statute of limitations |  |  | — |  |  |  | (61 | ) |  |  | (376 | ) |
| Balance at end of period |  | $ | 989 |  |  | $ | 17,885 |  |  | $ | 17,836 |  |

[0000950170-24-032089:notes:339]
As of December 31, 2023, 2022 and 2021, our total liability for unrecognized tax benefits was $1.0 million, $17.9 million and $17.8 million, respectively, of which $1.0 million, $17.9 million and $17.8 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of December 31, 2023, 2022 and 2021, the balances of accrued interest and penalties were $0.1 million, $0.1 million and $0.2 million, respectively.

[0000950170-24-032089:notes:340]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date, unless a resolution is reached regarding the appeal of our PLR denial noted above. We file income tax returns in the U.S. for federal and various state jurisdictions and several foreign jurisdictions. We are not currently under audit by the Internal Revenue Service. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2018.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-24-032089:notes:341]
Note 15 – Employee Benefit Plans

[0000950170-24-032089:notes:342]
Pension Benefit Plan

[0000950170-24-032089:notes:343]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Details regarding the pension plans are set forth below.

[0000950170-24-032089:notes:344]
•
In Germany, there is one defined benefit pension plan and one defined contribution plan. Both plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service and salary. The defined benefit plan is financed by contributions paid by the Company and the defined contribution plan is financed by contributions paid by the participants.

[0000950170-24-032089:notes:345]
•
In Switzerland, there are two defined benefit pension plans. Both plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service, salary and on a participant's old age account. The plans are financed by contributions paid by the participants and by the Company.

[0000950170-24-032089:notes:346]
•
In Italy, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis. Employees receive their pension payments as a function of salary, inflation and a notional account.

[0000950170-24-032089:notes:347]
•
In Israel, there is a defined benefit pension plan that provides benefits in the event of a participant being dismissed involuntarily, retirement or death. The plan's benefits are based on the higher of the severance benefit required by law or the cash surrender value of the severance benefit component of any qualifying insurance policy or long-term employee benefit fund that is registered in the participants name. The plan is financed by contributions paid by the Company.

[0000950170-24-032089:notes:348]
•
In India, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis.

[0000950170-24-032089:notes:349]
The pension benefit plan obligations and funded status as of December 31, 2023 and 2022, were as follows:

[0000950170-24-032089:notes:350]
| (In thousands) |  | 2023 |  |  | 2022 |  |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 59,344 |  |  | $ | 73,779 |  | (1) |
| Service cost |  |  | 1,579 |  |  |  | 1,426 |  |  |
| Interest cost |  |  | 1,851 |  |  |  | 1,168 |  |  |
| Actuarial loss (gain) - experience |  |  | 1,181 |  |  |  | (2,039 | ) |  |
| Actuarial loss (gain) - assumptions |  |  | 1,791 |  |  |  | (11,128 | ) |  |
| Benefit payments |  |  | (1,966 | ) |  |  | (1,400 | ) |  |
| Plan amendments |  |  | 966 |  |  |  | — |  |  |
| Effects of foreign currency exchange rate changes |  |  | 3,151 |  |  |  | (2,462 | ) |  |
| Projected benefit obligation at end of period |  |  | 67,897 |  |  |  | 59,344 |  |  |
| Change in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  |  | 48,720 |  |  |  | 55,084 |  | (1) |
| Actual gain (loss) on plan assets |  |  | 3,125 |  |  |  | (4,372 | ) |  |
| Contributions |  |  | 1,215 |  |  |  | 382 |  |  |
| Benefit payments |  |  | (231 | ) |  |  | — |  |  |
| Effects of foreign currency exchange rate changes |  |  | 2,389 |  |  |  | (2,374 | ) |  |
| Fair value of plan assets at end of period |  |  | 55,218 |  |  |  | 48,720 |  |  |
| Unfunded status at end of period |  | $ | (12,679 | ) |  | $ | (10,624 | ) |  |

[0000950170-24-032089:notes:351]
(1)
In connection with the Business Combination, we acquired $29.6 million of additional projected benefit obligations and $22.3 million of plan assets whose beginning of period measurement date is July 15, 2022.

[0000950170-24-032089:notes:352]
The accumulated benefit obligation was $67.1 million and $56.8 million as of December 31, 2023 and 2022, respectively. The decrease in the accumulated benefit obligation, projected benefit obligation and the actuarial loss was primarily attributable to an increase in the discount rate during 2023.

[0000950170-24-032089:notes:353]
The net amounts recognized in the Consolidated Balance Sheets for the unfunded pension liability as of December 31, 2023 and 2022 were as follows:

[0000950170-24-032089:notes:354]
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Current pension liability |  | $ | 136 |  |  | $ | — |  |
| Non-current pension liability |  |  | 12,543 |  |  |  | 10,624 |  |
| Total |  | $ | 12,679 |  |  | $ | 10,624 |  |

[0000950170-24-032089:notes:355]
The components of net periodic pension cost, other than the service cost component, are included in other income, net in the Consolidated Statements of Loss. The components of net periodic pension cost and amounts recognized in other comprehensive (loss) income for the years ended December 31, 2023, 2022 and 2021 were as follows:

[0000950170-24-032089:notes:356]
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,579 |  |  | $ | 1,426 |  |  | $ | 1,229 |  |
| Interest cost |  |  | 1,851 |  |  |  | 1,168 |  |  |  | 339 |  |
| Expected return on plan assets |  |  | (1,750 | ) |  |  | (2,129 | ) |  |  | (1,842 | ) |
| Amortization of actuarial losses |  |  | 26 |  |  |  | 355 |  |  |  | 1,088 |  |
| Net periodic benefit cost |  |  | 1,706 |  |  |  | 820 |  |  |  | 814 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Net actuarial loss (gain) |  |  | 2,304 |  |  |  | (6,549 | ) |  |  | (4,984 | ) |
| Amortization of actuarial losses |  |  | (145 | ) |  |  | (113 | ) |  |  | (825 | ) |
| Amount recognized in other comprehensive income (loss) |  |  | 2,159 |  |  |  | (6,662 | ) |  |  | (5,809 | ) |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) |  | $ | 3,865 |  |  | $ | (5,842 | ) |  | $ | (4,995 | ) |

[0000950170-24-032089:notes:357]
The amounts recognized in accumulated other comprehensive income as of December 31, 2023 and 2022 were as follows:

[0000950170-24-032089:notes:358]
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Net actuarial loss |  | $ | (3,231 | ) |  | $ | (1,073 | ) |

[0000950170-24-032089:notes:359]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our plan's assets is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in euro currency with durations close to the duration of our pension obligations.

[0000950170-24-032089:notes:360]
The weighted-average assumptions that were used to determine the net periodic benefit cost for the years ended December 31, 2023, 2022 and 2021 were as follows:

[0000950170-24-032089:notes:361]
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Discount rate |  |  | 2.84 | % |  |  | 3.24 | % |  |  | 1.16 | % |
| Rate of compensation increase |  |  | 2.22 | % |  |  | 2.17 | % |  |  | 2.00 | % |
| Expected long-term rates of return |  |  | 4.83 | % |  |  | 4.65 | % |  |  | 5.90 | % |

[0000950170-24-032089:notes:362]
The weighted-average assumptions that were used to determine the benefit obligation as of December 31, 2023 and 2022:

[0000950170-24-032089:notes:363]
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Discount rate |  |  | 3.17 | % |  |  | 3.10 | % |  |  | 1.16 | % |
| Rate of compensation increase |  |  | 2.22 | % |  |  | 2.17 | % |  |  | 2.00 | % |

[0000950170-24-032089:notes:364]
Actuarial gains and losses are recorded in accumulated other comprehensive income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants.

[0000950170-24-032089:notes:365]
The Company anticipates making approximately $2.2 million in contributions to the pension plans in 2024.

[0000950170-24-032089:notes:366]
The following pension benefit payments, which reflect expected future service, as appropriate, are expected to be paid to participants:

[0000950170-24-032089:notes:367]
| (In thousands) |  |  |  |
| 2024 |  | $ | 2,851 |  |
| 2025 |  |  | 3,725 |  |
| 2026 |  |  | 3,183 |  |
| 2027 |  |  | 3,683 |  |
| 2028 |  |  | 3,313 |  |
| 2029 - 2032 |  |  | 18,498 |  |
| Total |  | $ | 35,253 |  |

[0000950170-24-032089:notes:368]
•
Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-24-032089:notes:369]
We have categorized our cash equivalents and our investments held at fair value into this hierarchy as follows:

[0000950170-24-032089:notes:370]
|  |  | Fair Value Measurements at December 31, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash and cash equivalents |  | $ | 987 |  |  | $ | 987 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds |  |  | 20,155 |  |  |  | 18,840 |  |  |  | 1,315 |  |  |  | — |  |
| Equity funds |  |  | 21,525 |  |  |  | 21,288 |  |  |  | 237 |  |  |  | — |  |
| Other funds |  |  | 6,054 |  |  |  | 5,343 |  |  |  | 711 |  |  |  | — |  |
| Insuarance contracts |  |  | 353 |  |  |  | — |  |  |  | 353 |  |  |  | — |  |
| Real estate funds |  |  | 6,144 |  |  |  | 546 |  |  |  | 2,326 |  |  |  | 3,272 |  |
| Available-for-sale securities |  |  | 54,231 |  |  |  | 46,017 |  |  |  | 4,942 |  |  |  | 3,272 |  |
| Total |  | $ | 55,218 |  |  | $ | 47,004 |  |  | $ | 4,942 |  |  | $ | 3,272 |  |

[0000950170-24-032089:notes:371]
|  |  | Fair Value Measurements at December 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash and cash equivalents |  | $ | 1,423 |  |  | $ | 1,423 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,256 |  |  |  | 11,667 |  |  |  | 1,590 |  |  |  | — |  |
| Government bonds |  |  | 5,490 |  |  |  | 5,490 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Global equity |  |  | 15,452 |  |  |  | 15,150 |  |  |  | 301 |  |  |  | — |  |
| Balanced fund |  |  | 5,190 |  |  |  | 4,148 |  |  |  | 1,042 |  |  |  | — |  |
| Emerging markets |  |  | 1,707 |  |  |  | 1,707 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 194 |  |  |  | 194 |  |  |  | — |  |  |  | — |  |
| Global real estate fund |  |  | 6,008 |  |  |  | 742 |  |  |  | 1,577 |  |  |  | 3,689 |  |
| Available-for-sale securities |  |  | 47,297 |  |  |  | 39,098 |  |  |  | 4,510 |  |  |  | 3,689 |  |
| Total |  | $ | 48,720 |  |  | $ | 40,521 |  |  | $ | 4,510 |  |  | $ | 3,689 |  |

[0000950170-24-032089:notes:372]
Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies.

[0000950170-24-032089:notes:373]
The investment policy is periodically reviewed by the Company and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations.

[0000950170-24-032089:notes:374]
401(k) Savings Plans

[0000950170-24-032089:notes:375]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan and the Adtran Networks SE 401(k) Retirement Plan (the “Savings Plans”) for the benefit of eligible employees. The Savings Plans are intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (the “Code”), and is intended to be a “safe harbor” 401(k) plan under Code Section 401(k)(12). The Savings Plans allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plans also requires us to contribute a “safe harbor” amount each year. In our legacy ADTRAN, Inc. plan, we match up to 4% of employee contributions (100% of an employee’s first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s one-year anniversary date. All matching contributions under the legacy ADTRAN, Inc. Savings Plan vest immediately. In our legacy ADTRAN Networks, plan, we match up to 1.5% of employee contributions (25% of an employee's first 6% of contributions). All matching contributions under the legacy ADTRAN Networks Savings Plan vest ratably over five years beginning on the employee's one-year anniversary date. In addition, under the legacy ADTRAN Networks plan, an annual matching employer contribution is made which is based on the Company's achievement against a yearly relative Pro-forma EBIT target which can range from no additional match up to an additional 50% match. In calculating our matching contributions, compensation up to the statutory maximum under the Code is used ($330,000 for 2023). Employer contribution expense and plan administration costs for both Savings Plan amounted to approximately $4.2 million, $4.1 million and $3.9 million in 2023, 2022 and 2021, respectively.

[0000950170-24-032089:notes:376]
Deferred Compensation Plans

[0000950170-24-032089:notes:377]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors.

[0000950170-24-032089:notes:378]
The ADTRAN, Inc. Deferred Compensation Program for Employees is offered as a supplement to our tax-qualified 401(k) plan and is available to certain executive management employees who have been designated by our Board of Directors. This deferred compensation plan allows participants to defer all or a portion of certain specified bonuses and up to 25% of remaining cash compensation and permits us to make matching contributions on a discretionary basis without the limitations that apply to the 401(k) plan. To date, we have not made any matching contributions under this plan. We also maintain the ADTRAN, Inc. Equity Deferral Program for Employees. Under this plan, participants may elect to defer all or a portion of their vested PSUs and RSUs to the plan. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the participant.

[0000950170-24-032089:notes:379]
For our Board of Directors, we maintain the ADTRAN, Inc. Deferred Compensation Program for Directors. This program allows our Board of Directors to defer all or a portion of monetary remuneration paid to the Director, including, but not limited to, meeting fees and annual retainers. We also maintain the ADTRAN, Inc. Equity Deferral Program for Directors. Under this plan, participants may elect to defer all or a portion of their vested restricted stock awards. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the director.

[0000950170-24-032089:notes:380]
We have set aside the plan assets for all plans in a rabbi trust (the “Trust”) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant and the participant’s bookkeeping account is credited with the earnings and losses attributable to those investments. Benefits are scheduled to be distributed six months after termination of employment in a single lump sum payment or annual installments paid over a three or ten-year term based on the participant’s election. Distributions will be made on a pro-rata basis from each of the hypothetical investments of the participant’s account in cash. Any whole shares of ADTRAN, Inc. common stock that are distributed will be distributed in-kind.

[0000950170-24-032089:notes:381]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging from equities to money market instruments. These mutual funds are publicly quoted and reported at fair value. The fair value of the assets held by the Trust and the amounts payable to the plan participants as of December 31, 2023 and 2022 were as follows:

[0000950170-24-032089:notes:382]
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |
| Long-term investments |  | $ | 26,838 |  |  | $ | 22,943 |  |
| Total Fair Value of Plan Assets |  | $ | 26,838 |  |  | $ | 22,943 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |
| Deferred compensation liability |  | $ | 29,039 |  |  | $ | 26,668 |  |
| Total Amounts Payable to Plan Participants |  | $ | 29,039 |  |  | $ | 26,668 |  |

[0000950170-24-032089:notes:383]
The Trust held $2.2 million and $3.7 million of common stock in the Company as of December 31, 2023 and 2022, respectively. Shares of the Company held by the Trust are recorded at cost and classified as treasury stock on the Consolidated Balance Sheet.

[0000950170-24-032089:notes:384]
Interest and dividend income of the Trust are included in interest and dividend income in the accompanying 2023, 2022 and 2021 Consolidated Statements of Loss. Changes in the fair value of the plan assets held by the Trust have been included in other income, net  in the accompanying 2023, 2022 and 2021 Consolidated Statements of Loss. Changes in the fair value of the deferred compensation liability are included as selling, general and administrative expense in the accompanying 2023, 2022 and 2021 Consolidated Statements of Loss. Based on the changes in the total fair value of the Trust’s assets, the Company recorded deferred compensation income in 2023, 2022 and 2021 of $3.0 million, $6.3 million and $0.9 million, respectively.

[0000950170-24-032089:notes:385]
Retiree Medical Coverage

[0000950170-24-032089:notes:386]
Medical, dental and prescription drug coverage is provided to certain spouses and former spouses of current and former officers on the same terms as provided to our active officers for up to 30 years. As of December 31, 2023 and 2022, this liability totaled $0.3 million and $0.2 million, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-24-032089:notes:387]
Note 16 – Equity

[0000950170-24-032089:notes:388]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by components of accumulated other comprehensive income (loss) for the years ended December 31, 2023, 2022 and 2021:

[0000950170-24-032089:notes:389]
| (In thousands) |  | UnrealizedGains (Losses)on Available-for-SaleSecurities |  |  | DefinedBenefit PlanAdjustments |  |  | ForeignCurrencyAdjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| Balance as of December 31, 2020 |  | $ | 32 |  |  | $ | (9,621 | ) |  | $ | (2,435 | ) |  | $ | 385 |  |  | $ | (11,639 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (705 | ) |  |  | 3,439 |  |  |  | (3,699 | ) |  |  | — |  |  |  | (965 | ) |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | 121 |  |  |  | 569 |  |  |  | — |  |  |  | — |  |  |  | 690 |  |
| Balance as of December 31, 2021 |  |  | (552 | ) |  |  | (5,613 | ) |  |  | (6,134 | ) |  |  | 385 |  |  |  | (11,914 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (41 | ) |  |  | 4,519 |  |  |  | 53,396 |  |  |  | — |  |  |  | 57,874 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (243 | ) |  |  | 78 |  |  |  | — |  |  |  | — |  |  |  | (165 | ) |
| Net current period other comprehensive (loss) income |  |  | (284 | ) |  |  | 4,597 |  |  |  | 53,396 |  |  |  | — |  |  |  | 57,709 |  |
| Less: Other comprehensive income attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | 19,669 |  |  |  | — |  |  |  | 19,669 |  |
| Balance as of December 31, 2022 |  |  | (836 | ) |  |  | (1,016 | ) |  |  | 27,593 |  |  |  | 385 |  |  |  | 26,126 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 734 |  |  |  | (1,590 | ) |  |  | 22,753 |  |  |  | — |  |  |  | 21,897 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (280 | ) |  |  | 100 |  |  |  | — |  |  |  | — |  |  |  | (180 | ) |
| Net current period other comprehensive income (loss) |  |  | 454 |  |  |  | (1,490 | ) |  |  | 22,753 |  |  |  | — |  |  |  | 21,717 |  |
| Less: Other comprehensive income attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | 382 |  |  |  | — |  |  |  | 382 |  |
| Balance as of December 31, 2023 |  | $ | (382 | ) |  | $ | (2,506 | ) |  | $ | 49,964 |  |  | $ | 385 |  |  | $ | 47,461 |  |

[0000950170-24-032089:notes:390]
(1)
With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings.

[0000950170-24-032089:notes:391]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the years ended December 31, 2023, 2022 and 2021:

[0000950170-24-032089:notes:392]
| (In thousands) |  | For the year ended December 31, |  |  |  |
| Details about Accumulated Other Comprehensive (Loss)Income Components |  | 2023 |  |  | 2022 |  |  | 2021 |  |  | Affected Line Item in theStatement Where Net (Loss) Income Is Presented |
| Unrealized (loss) gains on available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | 378 |  |  | $ | 328 |  |  | $ | (164 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (145 | ) |  |  | (113 | ) |  |  | (825 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 233 |  |  |  | 215 |  |  |  | (989 | ) |  |  |
| Tax (benefit) expense |  |  | (53 | ) |  |  | (50 | ) |  |  | 299 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 180 |  |  | $ | 165 |  |  | $ | (690 | ) |  |  |

[0000950170-24-032089:notes:393]
(1)
Included in the computation of net periodic pension cost. See Note 15 for additional information.

[0000950170-24-032089:notes:394]
The following tables present the tax effects related to the change in each component of other comprehensive income (loss) for the years ended December 31, 2023, 2022 and 2021:

[0000950170-24-032089:notes:395]
|  |  | 2023 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 992 |  |  | $ | (258 | ) |  | $ | 734 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) income |  |  | (378 | ) |  |  | 98 |  |  |  | (280 | ) |
| Defined benefit plan adjustments |  |  | (2,304 | ) |  |  | 714 |  |  |  | (1,590 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) income |  |  | 145 |  |  |  | (45 | ) |  |  | 100 |  |
| Foreign currency translation adjustment |  |  | 22,753 |  |  |  | — |  |  |  | 22,753 |  |
| Total Other Comprehensive Income |  | $ | 21,208 |  |  | $ | 509 |  |  | $ | 21,717 |  |

[0000950170-24-032089:notes:396]
|  |  | 2022 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized (losses) gains on available-for-sale securities |  | $ | (55 | ) |  | $ | 14 |  |  | $ | (41 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) income |  |  | (328 | ) |  |  | 85 |  |  |  | (243 | ) |
| Defined benefit plan adjustments |  |  | 6,549 |  |  |  | (2,030 | ) |  |  | 4,519 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 113 |  |  |  | (35 | ) |  |  | 78 |  |
| Foreign currency translation adjustment |  |  | 53,396 |  |  |  | — |  |  |  | 53,396 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 59,675 |  |  | $ | (1,966 | ) |  | $ | 57,709 |  |

[0000950170-24-032089:notes:397]
|  |  | 2021 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized (losses) gains on available-for-sale securities |  | $ | (953 | ) |  | $ | 248 |  |  | $ | (705 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 164 |  |  |  | (43 | ) |  |  | 121 |  |
| Defined benefit plan adjustments |  |  | 4,984 |  |  |  | (1,545 | ) |  |  | 3,439 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 825 |  |  |  | (256 | ) |  |  | 569 |  |
| Foreign currency translation adjustment |  |  | (3,699 | ) |  |  | — |  |  |  | (3,699 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 1,321 |  |  | $ | (1,596 | ) |  | $ | (275 | ) |


## us-gaap:RedeemableNoncontrollingInterestTableTextBlock

[0000950170-24-032089:notes:398]
The following table summarizes the redeemable non-controlling interest activity for the year ended December 31, 2023:

[0000950170-24-032089:notes:399]
|  |  | For the Year Ended |  |
| (In thousands) |  | December 31, 2023 |  |
| Balance at beginning of period |  | $ | — |  |
| Reclassification of non-controlling interests |  |  | 443,757 |  |
| Fair value on redemption of redeemable non-controlling interests |  |  | (1,657 | ) |
| Net income attributable to redeemable non-controlling interests |  |  | 11,525 |  |
| Annual recurring compensation earned |  |  | (11,525 | ) |
| Translation adjustment |  |  | 9,604 |  |
| Adtran Networks stock option exercises |  |  | 52 |  |
| Balance as of December 31, 2023 |  | $ | 451,756 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-032089:notes:400]
Note 18 – Segment Information and Major Customers

[0000950170-24-032089:notes:401]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support.

[0000950170-24-032089:notes:402]
The Network Solutions segment includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions. The Company's cloud-managed Wi-Fi gateways, virtualization software, and switches provide a mix of wired and wireless connectivity at the customer premises. In addition, its Carrier Ethernet products support a variety of applications at the network edge ranging from mobile backhaul to connecting enterprise customers (“Subscriber Solutions"). The Company's portfolio includes products for multi-gigabit service delivery over fiber or alternative media to homes and businesses.

[0000950170-24-032089:notes:403]
The Services & Support segment offers a comprehensive portfolio of network design, implementation, maintenance and cloud-hosted services supporting its Subscriber, Access and Aggregation, and Optical Networking Solutions. These services assist operators in the deployment of multi-vendor networks while reducing their cost to maintain these networks. The cloud-hosted services include a suite of SaaS applications under the Company's Mosaic One platform that manages end-to-end network and service optimization for both fiber access infrastructure and mesh Wi-Fi connectivity. The Company backs these services with a global support organization that offers on-site and off-site support services with varying SLAs.

[0000950170-24-032089:notes:404]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income, net and income tax (expense) benefit are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-24-032089:notes:405]
The following table presents information about revenue and gross profit of our reportable segments for each of the years ended December 31, 2023, 2022 and 2021:

[0000950170-24-032089:notes:406]
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 974,389 |  |  | $ | 227,494 |  |  | $ | 916,793 |  |  | $ | 269,688 |  |  | $ | 498,834 |  |  | $ | 190,993 |  |
| Services & Support |  |  | 174,711 |  |  |  | 105,569 |  |  |  | 108,743 |  |  |  | 57,564 |  |  |  | 64,170 |  |  |  | 27,384 |  |
| Total |  | $ | 1,149,100 |  |  | $ | 333,063 |  |  | $ | 1,025,536 |  |  | $ | 327,252 |  |  | $ | 563,004 |  |  | $ | 218,377 |  |

[0000950170-24-032089:notes:407]
For the years ended December 31, 2023, 2022 and 2021, $6.5 million, $3.2 million and $1.2 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the years ended December 31, 2023, 2022 and 2021, $20 thousand, $10 thousand and $14 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0000950170-24-032089:notes:408]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN, Inc. reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, the Company has recast these revenues such that ADTRAN, Inc’s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions was added as a new revenue category to represent a meaningful portion of Adtran Networks' portfolio.

[0000950170-24-032089:notes:409]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at customers' premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

[0000950170-24-032089:notes:410]
The following tables disaggregate our revenue by category for the years ended December 31, 2023, 2022 and 2021:

[0000950170-24-032089:notes:411]
|  |  | 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 263,192 |  |  | $ | 34,516 |  |  | $ | 297,708 |  |
| Access & Aggregation Solutions |  |  | 304,074 |  |  |  | 54,344 |  |  |  | 358,418 |  |
| Optical Networking Solutions |  |  | 407,123 |  |  |  | 85,851 |  |  |  | 492,974 |  |
| Total |  | $ | 974,389 |  |  | $ | 174,711 |  |  | $ | 1,149,100 |  |

[0000950170-24-032089:notes:412]
|  |  | 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 364,238 |  |  | $ | 26,216 |  |  | $ | 390,454 |  |
| Access & Aggregation Solutions |  |  | 326,934 |  |  |  | 47,068 |  |  |  | 374,002 |  |
| Optical Networking Solutions |  |  | 225,621 |  |  |  | 35,459 |  |  |  | 261,080 |  |
| Total |  | $ | 916,793 |  |  | $ | 108,743 |  |  | $ | 1,025,536 |  |

[0000950170-24-032089:notes:413]
|  |  | 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 189,825 |  |  | $ | 16,385 |  |  | $ | 206,210 |  |
| Access & Aggregation Solutions |  |  | 309,009 |  |  |  | 47,785 |  |  |  | 356,794 |  |
| Optical Networking Solutions |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 498,834 |  |  | $ | 64,170 |  |  | $ | 563,004 |  |

[0000950170-24-032089:notes:414]
Additional Information

[0000950170-24-032089:notes:415]
The following table presents revenue information by geographic area for the years ended December 31, 2023, 2022 and 2021:

[0000950170-24-032089:notes:416]
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| United States |  | $ | 460,985 |  |  | $ | 517,433 |  |  | $ | 374,600 |  |
| United Kingdom |  |  | 214,655 |  |  |  | 189,685 |  |  |  | 56,355 |  |
| Germany |  |  | 230,922 |  |  |  | 146,797 |  |  |  | 65,229 |  |
| Other international |  |  | 242,538 |  |  |  | 171,621 |  |  |  | 66,820 |  |
| Total |  | $ | 1,149,100 |  |  | $ | 1,025,536 |  |  | $ | 563,004 |  |

[0000950170-24-032089:notes:417]
Customers comprising more than 10% of revenue can change from year to year. The Company had one customer comprising more than 10% of revenue in 2023 at 11.0% and was included in both our Network Solutions and Services & Support segments. Single customers comprising more than 10% of revenue in 2022 included one customer at 10.4% and was included in both our Network Solutions and Services & Support segments. Single customers comprising more than 10% of revenue in 2021 included one customer at 18% and was included in both our Network Solutions and Services & Support segments. Other than those with more than 10% of revenue disclosed above, our next five largest customers can change, and have historically changed, from year-to-year. The next five largest customers combined represented 28%, 33% and 38% of total revenue in 2023, 2022 and 2021, respectively.

[0000950170-24-032089:notes:418]
As of December 31, 2023, property, plant and equipment, net totaled $123.0 million, which included $56.8 million held in the U.S. and $66.2 million held outside the U.S. As of December 31, 2022, property, plant and equipment, net totaled $110.7 million, which included

[0000950170-24-032089:notes:419]
$56.2 million held in the U.S. and $54.5 million held outside the U.S. Property, plant and equipment, net is reported on a Company-wide, functional basis only.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-24-032089:notes:420]
Note 19 – Liability for Warranty Returns

[0000950170-24-032089:notes:421]
The liability for warranty obligations totaled $6.4 million and $7.2 million as of December 31, 2023 and 2022, respectively. These liabilities are included in accrued expenses and other liabilities and other non-current liabilities in the accompanying Consolidated Balance Sheets.

[0000950170-24-032089:notes:422]
A summary of warranty expense and write-off activity for the years ended December 31, 2023, 2022 and 2021 is as follows:

[0000950170-24-032089:notes:423]
|  |  | Year Ended December 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 7,196 |  |  | $ | 5,403 |  |  | $ | 7,146 |  |
| Plus: Adtran Networks acquisition |  |  | — |  |  |  | 3,756 |  |  |  | — |  |
| Plus: Amounts charged to cost and expenses |  |  | 2,952 |  |  |  | 3,104 |  |  |  | 855 |  |
| Plus: Foreign currency translation adjustments |  |  | 82 |  |  |  | 334 |  |  |  | — |  |
| Less: Deductions |  |  | (3,784 | ) |  |  | (5,401 | ) |  |  | (2,598 | ) |
| Balance at end of period |  | $ | 6,445 |  |  | $ | 7,196 |  |  | $ | 5,403 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-032089:notes:424]
Note 20 – Commitments and Contingencies

[0000950170-24-032089:notes:425]
Legal Matters

[0000950170-24-032089:notes:426]
From time to time the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

[0000950170-24-032089:notes:427]
Adtran Networks Legal Matter

[0000950170-24-032089:notes:428]
On May 8, 2023, Adtran Networks SE and its subsidiary, ADVA Optical Networking North America, Inc. (together, “Adtran Networks”), filed a lawsuit in the U.S District Court for the Eastern District of Texas (“EDTX”) against Huawei Technologies Co. Ltd (“Huawei”) seeking a declaration from the court that Huawei violated its commitments to negotiate in good faith and to license standard essential patents (“SEPs”), to the extent any SEPs are practiced by Adtran Networks, on Fair, Reasonable and Non-Discriminatory (“FRAND”) terms and conditions. The case also sought to obtain a ruling by the EDTX that Adtran Networks has complied with its own commitments and requested that the Court establish FRAND terms and conditions for obtaining a FRAND license on any SEPs to the extent they are practiced by Adtran Networks. The lawsuit further sought to enjoin Huawei from enforcing certain Huawei patents that Adtran Networks considers invalid and/or not practiced, and Adtran Networks alleged that Huawei had infringed upon an Adtran Networks patent. On July 20, 2023, Adtran Networks SE was served with a complaint filed by Huawei against Adtran Networks SE in the District Court München I, Germany, alleging that certain of its products infringe upon one of Huawei’s patents. On August 22, 2023, Adtran Networks entered into a settlement agreement with Huawei pursuant to which the parties agreed to, among other things, dismiss the lawsuits described above.

[0000950170-24-032089:notes:429]
DPLTA Exit and Recurring Compensation Costs

[0000950170-24-032089:notes:430]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.7 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the year ended December 31, 2023, we accrued $11.5 million in Annual Recurring Compensation, which was reflected as an increase to retained (deficit) earnings.

[0000950170-24-032089:notes:431]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the year ended December 31, 2023, 67 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €1.2 million, respectively, or approximately $1.3 million based on an exchange rate as of December 31, 2023, were paid to Adtran Networks shareholders.

[0000950170-24-032089:notes:432]
Performance Bonds

[0000950170-24-032089:notes:433]
Certain contracts, customers and jurisdictions in which the Company do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2023 and December 31, 2022, the Company had commitments related to these bonds totaling $10.8 million and $22.0 million, respectively, which expire at various dates through April 2031. In general the Company would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which the Company believes is remote.

[0000950170-24-032089:notes:434]
Purchase Obligations

[0000950170-24-032089:notes:435]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for short-term product manufacturing requirements, as well as for obligations to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of December 31, 2023, purchase obligations totaled $252.5 million.


## us-gaap:CreditLossFinancialInstrumentTextBlock

[0000950170-24-032089:notes:436]
Note 21 – Current Expected Credit Losses

[0000950170-24-032089:notes:437]
Under ASC 326 – Financial Instruments – Credit Losses, the Company estimates credit losses for the contractual life of assets that are measured at amortized cost and are within the scope of this guidance, which includes accounts receivable, net investment in sales-type leases, contract assets under the revenue recognition model and outstanding notes receivable. Where appropriate, the Company pools assets if similar risk characteristics exist. Additionally, the Company analyzes its available-for-sale debt securities for impairment and records a credit loss allowance as needed.

[0000950170-24-032089:notes:438]
Assets Measured at Amortized Cost

[0000950170-24-032089:notes:439]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. Accounts receivable balances are considered past due when payment has not been received by the date indicated on the relevant invoice or based on agreed upon terms between the customer and the Company.

[0000950170-24-032089:notes:440]
As of December 31, 2023 and 2022, the Company’s net outstanding accounts receivable balance was $216.4 million and $279.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The Company’s historical losses related to accounts receivable have been immaterial as evidenced by its historical allowance and write-offs due to collectability. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0000950170-24-032089:notes:441]
Credit losses totaling $0.4 million and less than $0.1 million were recorded for the years ended December 31, 2023 and 2022 respectively, related to accounts receivable. No credit losses were recorded for the year ended December 31, 2021 related to accounts receivable.

[0000950170-24-032089:notes:442]
Contract Assets

[0000950170-24-032089:notes:443]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of December 31, 2023 and 2022, the Company’s outstanding contract asset balance was $0.7 million and $1.9 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0000950170-24-032089:notes:444]
No allowance for credit losses was recorded for the years ended December 31, 2023 and 2022 related to contract assets.

[0000950170-24-032089:notes:445]
Off-Balance Sheet Arrangements

[0000950170-24-032089:notes:446]
We have exposure to credit losses from off-balance sheet exposures, to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of December 31, 2023 and 2022, respectively. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 20 of the Notes to Condensed Consolidated Financial Statements, included in Part II, Item 8 of this report for additional information.

[0000950170-24-032089:notes:447]
Available-for-Sale Debt Securities

[0000950170-24-032089:notes:448]
As of December 31, 2023 the Company had sold all available-for-sale debt securities. As of December 31, 2022 the Company’s available-for-sale debt securities totaled $9.3 million. These securities were analyzed at the individual investment level, by Committee on Uniform Securities Identification Procedures (“CUSIP”), to limit credit losses, if applicable, to reflect only the amount by which the fair value of the security was less than its amortized cost. The Company noted that, as of December 31, 2022, there was no intent to sell any of its available-for-sale debt securities before maturity, and, therefore, the Company assessed the need for an allowance for each of its available-for-sale debt securities in which the fair value was less than its amortized cost as of December 31, 2022. Accrued interest receivable on available-for-sale debt securities, which is included in other receivables on the Consolidated Balance Sheets as of December 31, 2022 totaled less than $0.1 million and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election. Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Consolidated Statements of Loss.

[0000950170-24-032089:notes:449]
The Company had 99 positions in available-for-sale debt securities that were in an unrealized loss position as of December 31, 2022. See Note 5 for additional information.

[0000950170-24-032089:notes:450]
For those available-for-sale debt securities whose fair value was less than its amortized cost basis, the Company analyzed additional criteria such as adverse conditions specifically related to the security, an industry or geographic area, failure of the issuer of the security to make scheduled interest or principal payments, if applicable, and any changes to the rating of the security by a rating agency to determine if a credit loss existed. The Company used information provided by its investment manager to determine if any scheduled interest or principal payments had not been received and used a third party to determine if any changes to credit ratings had occurred. Principal and interest payments are considered past due when payment has not been received based on scheduled terms of each debt security. The Company ceases to accrue interest on debt securities on a case by case basis. As of December 31, 2023, the Company noted that all principal and interest payments had been received as scheduled and that there had been no changes in credit ratings year-over-year or period-over-period that warranted further review.

[0000950170-24-032089:notes:451]
No allowance for credit losses was recorded for the year ended December 31, 2022 related to the Company’s available-for-sale debt securities.


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-032089:notes:452]
Note 22 – Loss per Share

[0000950170-24-032089:notes:453]
The calculations of basic and diluted loss per share for the years ended December 31, 2023, 2022 and 2021 are as follows:

[0000950170-24-032089:notes:454]
| (In thousands, except for per share amounts) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Numerator |  |  |  |  |  |  |  |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (267,688 | ) |  | $ | (2,037 | ) |  | $ | (8,635 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 78,416 |  |  |  | 62,346 |  |  |  | 48,582 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 78,416 |  |  |  | 62,346 |  |  |  | 48,582 |  |
| Loss per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (3.41 | ) |  | $ | (0.03 | ) |  | $ | (0.18 | ) |
| Loss per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (3.41 | ) |  | $ | (0.03 | ) |  | $ | (0.18 | ) |

[0000950170-24-032089:notes:455]
For each of the years ended December 31, 2023, 2022 and 2021, less than 0.5 million, 0.1 million and 0.1 million shares of unvested or unearned, as applicable, PSUs, RSUs and restricted stock were excluded from the calculation of diluted loss per share due to their anti-dilutive effect.

[0000950170-24-032089:notes:456]
For the years ended December 31, 2023, 2022 and 2021, 1.8 million, 0.2 million and 0.3 million stock options, respectively, were outstanding but were not included in the computation of diluted loss per share due to their exercise prices being greater than the average market price of the common shares during the quarter, making them anti-dilutive under the treasury stock method.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-032089:notes:457]
Note 23 – Restructuring

[0000950170-24-032089:notes:458]
During the fourth quarter of 2022, the Company initiated a restructuring program designed to optimize the assets, business processes, and information technology systems of the Company in relation to the Business Combination with Adtran Networks. The restructuring program is expected to maximize cost synergies by realizing operation scale, combining sales channels, streamlining corporate and general and administrative functions, including human capital resources and combining sourcing and production costs. This restructuring program is expected to be completed in late 2024 and includes expenses specifically associated with achieving run-rate synergies as well as Business Efficiency Program expenses described below.

[0000950170-24-032089:notes:459]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (the “Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expands upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment. Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). Additionally, on October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze.

[0000950170-24-032089:notes:460]
During the year ended December 31, 2023, we recognized $25.1 million of costs relating to the Business Efficiency Program. We expect costs in the first quarter 2024 and thereafter relating to the Business Efficiency Program to range between $22.2 million and $35.2 million. Management expects these planned costs to include severance costs ranging from $12.2 million to $18.9 million in connection with an early retirement program and reductions in workforce, inventory write downs from product discontinuances ranging from $7.6 million to $10.3 million, and site consolidation transaction expenses (primarily brokers fees) ranging from $2.4 million to $6.0 million. Future cash payments include: severance costs and outplacement fees that are anticipated to be in the range of $12.2 million to $18.9 million, payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $2.4 million to $6.0 million, and potential cash payments of $3.6 million to $6.3 million for anticipated product discontinuances. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures.  However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing. If required, we will amend this disclosure at such time as management is able in good faith to estimate the amount, or range of amounts, of these charges.

[0000950170-24-032089:notes:461]
For the years ended December 31, 2023 and 2022, we recognized $21.5 million and $1.6 million of restructuring costs relating to the Business Combination under the multi-year integration program and synergy realization, respectively, that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss.

[0000950170-24-032089:notes:462]
In February 2019, the Company announced the restructuring of a certain portion of its workforce predominantly in Germany, which included the closure of the Company’s office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. Voluntary early retirement was offered to certain other employees and was announced in March 2019 and again in August 2020. This plan was completed in 2021 and all amounts paid in 2022.

[0000950170-24-032089:notes:463]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Consolidated Balance Sheets as of December 31, 2023 and 2022, is as follows:

[0000950170-24-032089:notes:464]
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 159 |  |  | $ | 1,514 |  |
| Plus: Amounts charged to cost and expense |  |  | 22,241 |  |  |  | 1,629 |  |
| Less: Amounts paid |  |  | (14,091 | ) |  |  | (2,984 | ) |
| Balance at end of period |  | $ | 8,309 |  |  | $ | 159 |  |

[0000950170-24-032089:notes:465]
Restructuring expenses included in the Consolidated Statements of Loss are for the years ended December 31, 2023, 2022 and 2021:

[0000950170-24-032089:notes:466]
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Network solutions - cost of revenue |  | $ | 2,910 |  |  | $ | 8 |  |  | $ | 13 |  |
| Network solutions - inventory write-down |  |  | 24,313 |  |  |  | — |  |  |  | — |  |
| Services & support - cost of revenue |  |  | — |  |  |  | — |  |  |  | 3 |  |
| Cost of revenue |  | $ | 27,223 |  |  | $ | 8 |  |  | $ | 16 |  |
| Selling, general and administrative expenses |  |  | 11,603 |  |  |  | 117 |  |  |  | 221 |  |
| Research and development expenses |  |  | 7,728 |  |  |  | 1,504 |  |  |  | 174 |  |
| Total restructuring expenses |  | $ | 46,554 |  |  | $ | 1,629 |  |  | $ | 411 |  |

[0000950170-24-032089:notes:467]
The following table represents the components of restructuring expense by geographic area for the years ended December 31, 2023, 2022 and 2021:

[0000950170-24-032089:notes:468]
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| United States |  | $ | 34,629 |  |  | $ | 2 |  |  | $ | 289 |  |
| International |  |  | 11,925 |  |  |  | 1,627 |  |  |  | 122 |  |
| Total restructuring expenses |  | $ | 46,554 |  |  | $ | 1,629 |  |  | $ | 411 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-24-032089:notes:469]
Note 24 – Subsequent Events

[0000950170-24-032089:notes:470]
Third Amendment to Wells Fargo Credit Agreement

[0000950170-24-032089:notes:471]
On March 12, 2024, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc. (the “Borrower”), the lenders party thereto and Wells Fargo Bank, National Association, as administrative agent (the “Administrative Agent”), entered into a Third Amendment to Credit Agreement (the “Third Amendment”), which amends that certain Credit Agreement, dated as of July 18, 2022 (as amended or otherwise modified, including by the Third Amendment, the “Credit Agreement”), by and among the Borrower, the Company, the lenders party thereto and the Administrative Agent.

[0000950170-24-032089:notes:472]
The Third Amendment, among other things, amends the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024 and June 30, 2024.

[0000950170-24-032089:notes:473]
Second Amendment to Wells Fargo Credit Agreement

[0000950170-24-032089:notes:474]
On January 16, 2024, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc. (the “Borrower”), the lenders party thereto and Wells Fargo Bank, National Association, as administrative agent (the “Administrative Agent”), entered into a Second Amendment to Credit Agreement and First Amendment to Collateral Agreement (the “Second Amendment”), which amends (i) that certain Credit Agreement, dated as of July 18, 2022 (as amended or otherwise modified, including by the Second Amendment, the “Credit Agreement”), by and among the Borrower, the Company, the lenders party thereto and the Administrative Agent and (ii) that certain Collateral Agreement, dated as of July 18, 2022, by and among the Borrower, the Company and the Administrative Agent. Capitalized terms used in this Note 24 and not otherwise defined herein have the meanings assigned to them in the Second Amendment or the Credit Agreement, as applicable. The Second Amendment, among other things, provides the Company and its subsidiaries with additional covenant headroom from (and including) the fourth quarter of 2023 through and including the third quarter of 2024 (the “Covenant Relief Period”) and revises and/or adds certain other financial covenants. The full set of financial covenants includes the following:

[0000950170-24-032089:notes:475]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Total Net Leverage Ratio may not exceed 5.00x.

[0000950170-24-032089:notes:476]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

[0000950170-24-032089:notes:477]
•
In the event of the purchase by the Company of at least sixty percent (60%) of the outstanding shares of Adtran Networks SE not owned by the Company as of August 9, 2023 that have been tendered (such event, a “Springing Covenant Event” and the fiscal quarter in which the Springing Covenant Event Occurs and the three consecutive quarterly test periods thereafter, the “Springing Covenant Period”), the following covenant levels:

[0000950170-24-032089:notes:478]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

[0000950170-24-032089:notes:479]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

[0000950170-24-032089:notes:480]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

[0000950170-24-032089:notes:481]
•
If the Company or any of its subsidiaries incurs certain unsecured Indebtedness in excess of $50,000,000 in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

[0000950170-24-032089:notes:482]
•
If a Springing Covenant Period is not in effect, the following covenant levels:

[0000950170-24-032089:notes:483]
•
From December 31, 2023 through and including March 31, 2024: 3.25x.

[0000950170-24-032089:notes:484]
•
From April 1, 2024 through and including June 30, 2024: 3.50x.

[0000950170-24-032089:notes:485]
•
From July 1, 2024 and thereafter: 3.25x.

[0000950170-24-032089:notes:486]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not exceed 1.25x.

[0000950170-24-032089:notes:487]
•
During the Covenant Relief Period or a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million.

[0000950170-24-032089:notes:488]
The Credit Agreement is guaranteed by certain domestic subsidiaries of the Company, and the Company is also required to add certain additional domestic and international subsidiaries as guarantors under the Credit Agreement (such existing and new guarantors, collectively, the “Guarantors”). In addition to the guarantees provided by the Guarantors, the Guarantors have granted (or will grant) security interests in favor of the Administrative Agent over substantially all tangible and intangible assets, and the Borrower will grant mortgages in favor of the Administrative Agent over certain owned real estate assets.

[0000950170-24-032089:notes:489]
The Credit Agreement continues to provide for revolving borrowings of up to $400.0 million in aggregate principal amount, as well as an additional $50.0 million delayed draw term loan tranche that would be available upon a Springing Covenant Event. It also continues to permit the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement subject to certain limitations and minimum payment thresholds.

[0000950170-24-032089:notes:490]
During the Covenant Relief Period, the Company is not permitted to make certain dividend payments to the Company's Stockholders or certain other Restricted Payments. However, the Company is permitted to make the Recurring Compensation Payment to each Adtran Networks shareholder (other than the Company), pursuant to the terms of the DPLTA. See Note 20 for additional information.

[0000950170-24-032089:notes:491]
Furthermore, the Credit Agreement continues to contain customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts; however, certain of the exceptions and carveouts are not permitted to be used during the Covenant Relief Period. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.

[0000950170-24-032089:notes:492]
Upon the effective date of the Second Amendment, (A) the applicable commitment fee increased to 0.25% per annum, (B) for any revolving credit loan that is a Term SOFR Loan, the applicable margin rate increased to 3.15% per annum, (C) for any revolving credit loan that is a Eurocurrency Rate Loan, the applicable margin rate increased to 3.25% per annum, (D) for any revolving credit loan that is a Base Rate Loan (including any Swingline Loan), the applicable margin rate increased to 2.15% per annum, (E) for any Delayed Draw Term Loan that is a Term SOFR Loan, the applicable margin rate increased to 3.40% per annum and (F)_for any Delayed Draw Term Loan that is a Base Rate Loan, the applicable margin rate increased to 2.40% per annum. The aforementioned increases in the commitment fee and margin rates continues to the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the “Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, we have repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) we have reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) we are in compliance with all financial covenants based on the financial statements for the most recently completed reference period.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000950170-24-032089:notes:493]
SCHEDULE II

[0000950170-24-032089:notes:494]
VALUATION AND QUALIFYING ACCOUNTS

[0000950170-24-032089:notes:495]
| (In thousands) |  | Balance atBeginningof Period |  |  | Charged toCosts &Expenses |  |  | Deductions |  |  | Balance atEnd ofPeriod |  |
| Year ended December 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 49 |  |  |  | 351 |  |  |  | — |  |  | $ | 400 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 5,201 |  |  |  | 81,590 |  |  |  | 224 |  |  | $ | 86,567 |  |
| Year ended December 31, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | — |  |  |  | 49 |  |  |  | — |  |  | $ | 49 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 50,564 |  |  |  | — |  |  |  | 45,363 |  |  | $ | 5,201 |  |
| Year ended December 31, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 38 |  |  |  | (38 | ) |  |  | — |  |  | $ | — |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 45,818 |  |  |  | 6,347 |  |  |  | 1,601 |  |  | $ | 50,564 |  |
