# ADTN 8-K — 0001564590-17-013609 filed 2017-07-19

## item codes, every 8-K on or before 2017-08-04

- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2017-08-04

- none on or before 2017-08-04

## item 2.02 — earnings release, exhibit 99.1

[0001564590-17-013609:8k_2_02:1]
EX-99.1
2
adtn-ex991_6.htm
EX-99.1

[0001564590-17-013609:8k_2_02:2]
adtn-ex991_6.htm

[0001564590-17-013609:8k_2_02:3]
EXHIBIT 99.1

[0001564590-17-013609:8k_2_02:4]
ADTRAN, Inc. Reports Record Results for the Second Quarter 2017 and Declares Quarterly Cash Dividend

[0001564590-17-013609:8k_2_02:5]
HUNTSVILLE, Ala.--(BUSINESS WIRE)—July 18, 2017-- ADTRAN, Inc. (NASDAQ:ADTN) reported results for the second quarter 2017. For the quarter, sales were $184.7 million compared to $162.7 million for the second quarter of 2016. Net income was $12.4 million compared to $10.2 million for the second quarter of 2016. Earnings per share, assuming dilution, were $0.26 compared to $0.21 for the second quarter of 2016. Non-GAAP earnings per share were $0.30 compared to $0.25 for the second quarter of 2016. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001564590-17-013609:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “The company’s performance continues on pace with record sales for the second quarter and the first half of 2017.  Our record revenue was driven by increasing momentum with our ultra-broadband solutions, where we saw significant year-over-year growth both in the US and Europe. We continue to be at the forefront of several inflection points of innovation in the market, including next generation optical access, services transformation and Software Defined Access (SD-Access). Our services combined with market leading access and software solutions have enabled us to expand our range and reach into new opportunities that show promise for both short and long-term growth. We are pleased with our progress and the market reception to ADTRAN Mosaic and our SD-Access portfolio as Tier 1 operators around the world prepare for the transition to SDN.  With our focus on software innovation and domain expertise, ADTRAN is uniquely positioned to enable internet service providers of all types to meet increasing customer demand and decrease their time to market for next generation services.”

[0001564590-17-013609:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the second quarter of 2017. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on August 3, 2017. The ex-dividend date is August 1, 2017, and the payment date is August 17, 2017.

[0001564590-17-013609:8k_2_02:8]
The Company confirmed that its second quarter conference call will be held Wednesday, July 19, 2017, at 9:30 a.m. Central Time. This conference call will be web cast live through the Q4 Inc. webcasting service. To listen, simply visit the Investor Relations site at www.adtran.com/investor approximately 10 minutes prior to the start of the call and click on the conference call link provided.

[0001564590-17-013609:8k_2_02:9]
An online replay of the conference call, as well as the text of the Company's earnings release, will be available on the Investor Relations site for at least 12 months following the call.

[0001564590-17-013609:8k_2_02:10]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit www.adtran.com.

[0001564590-17-013609:8k_2_02:11]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001564590-17-013609:8k_2_02:12]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2016. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-17-013609:8k_2_02:13]
Condensed Consolidated Balance Sheet

[0001564590-17-013609:8k_2_02:14]
(Unaudited)

[0001564590-17-013609:8k_2_02:15]
(In thousands)

[0001564590-17-013609:8k_2_02:16]
|  | June 30, |  |  | December 31, |  |
|  | 2017 |  |  | 2016 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 88,798 |  |  | $ | 79,895 |  |
| Short-term investments |  | 47,331 |  |  |  | 43,188 |  |
| Accounts receivable, net |  | 79,891 |  |  |  | 92,346 |  |
| Other receivables |  | 14,561 |  |  |  | 15,137 |  |
| Income tax receivable, net |  | — |  |  |  | 760 |  |
| Inventory, net |  | 113,995 |  |  |  | 105,117 |  |
| Prepaid expenses and other current assets |  | 23,556 |  |  |  | 16,459 |  |
| Total Current Assets |  | 368,132 |  |  |  | 352,902 |  |
| Property, plant and equipment, net |  | 84,122 |  |  |  | 84,469 |  |
| Deferred tax assets, net |  | 40,296 |  |  |  | 38,036 |  |
| Goodwill |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  | 13,305 |  |  |  | 12,234 |  |
| Long-term investments |  | 159,634 |  |  |  | 176,102 |  |
| Total Assets | $ | 668,981 |  |  | $ | 667,235 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 66,161 |  |  | $ | 77,342 |  |
| Unearned revenue |  | 15,449 |  |  |  | 16,326 |  |
| Accrued expenses |  | 13,433 |  |  |  | 12,434 |  |
| Accrued wages and benefits |  | 16,303 |  |  |  | 20,433 |  |
| Income tax payable, net |  | 9,594 |  |  |  | — |  |
| Total Current Liabilities |  | 120,940 |  |  |  | 126,535 |  |
| Non-current unearned revenue |  | 5,351 |  |  |  | 6,333 |  |
| Other non-current liabilities |  | 32,527 |  |  |  | 28,050 |  |
| Bonds payable |  | 26,800 |  |  |  | 26,800 |  |
| Total Liabilities |  | 185,618 |  |  |  | 187,718 |  |
| Stockholders' Equity |  | 483,363 |  |  |  | 479,517 |  |
| Total Liabilities and Stockholders' Equity | $ | 668,981 |  |  | $ | 667,235 |  |

[0001564590-17-013609:8k_2_02:17]
Consolidated Statements of Income

[0001564590-17-013609:8k_2_02:18]
(Unaudited)

[0001564590-17-013609:8k_2_02:19]
(In thousands, except per share data)

[0001564590-17-013609:8k_2_02:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 155,543 |  |  | $ | 138,549 |  |  | $ | 299,140 |  |  | $ | 262,432 |  |
| Services |  |  | 29,130 |  |  |  | 24,152 |  |  |  | 55,812 |  |  |  | 42,473 |  |
| Total Sales |  |  | 184,673 |  |  |  | 162,701 |  |  |  | 354,952 |  |  |  | 304,905 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 79,658 |  |  |  | 67,844 |  |  |  | 156,317 |  |  |  | 131,917 |  |
| Services |  |  | 20,383 |  |  |  | 15,902 |  |  |  | 40,288 |  |  |  | 28,239 |  |
| Total Cost of Sales |  |  | 100,041 |  |  |  | 83,746 |  |  |  | 196,605 |  |  |  | 160,156 |  |
| Gross Profit |  |  | 84,632 |  |  |  | 78,955 |  |  |  | 158,347 |  |  |  | 144,749 |  |
| Selling, general and administrative expenses |  |  | 34,683 |  |  |  | 32,866 |  |  |  | 69,450 |  |  |  | 63,651 |  |
| Research and development expenses |  |  | 33,501 |  |  |  | 31,277 |  |  |  | 65,417 |  |  |  | 60,765 |  |
| Operating Income |  |  | 16,448 |  |  |  | 14,812 |  |  |  | 23,480 |  |  |  | 20,333 |  |
| Interest and dividend income |  |  | 972 |  |  |  | 927 |  |  |  | 1,905 |  |  |  | 1,782 |  |
| Interest expense |  |  | (137 | ) |  |  | (142 | ) |  |  | (278 | ) |  |  | (287 | ) |
| Net realized investment gain |  |  | 1,390 |  |  |  | 1,110 |  |  |  | 1,860 |  |  |  | 2,838 |  |
| Other expense, net |  |  | (804 | ) |  |  | (251 | ) |  |  | (753 | ) |  |  | (132 | ) |
| Income before provision for income taxes |  |  | 17,869 |  |  |  | 16,456 |  |  |  | 26,214 |  |  |  | 24,534 |  |
| Provision for income taxes |  |  | (5,468 | ) |  |  | (6,228 | ) |  |  | (7,162 | ) |  |  | (9,292 | ) |
| Net Income |  | $ | 12,401 |  |  | $ | 10,228 |  |  | $ | 19,052 |  |  | $ | 15,242 |  |
| Weighted average shares outstanding - basic |  |  | 48,036 |  |  |  | 48,831 |  |  |  | 48,232 |  |  |  | 49,026 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 48,413 |  |  |  | 49,048 |  |  |  | 48,675 |  |  |  | 49,218 |  |
| Earnings per common share - basic |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.40 |  |  | $ | 0.31 |  |
| Earnings per common share - diluted (1) |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.39 |  |  | $ | 0.31 |  |

[0001564590-17-013609:8k_2_02:21]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-17-013609:8k_2_02:22]
Consolidated Statements of Comprehensive Income

[0001564590-17-013609:8k_2_02:23]
(Unaudited)

[0001564590-17-013609:8k_2_02:24]
(In thousands)

[0001564590-17-013609:8k_2_02:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net Income |  | $ | 12,401 |  |  | $ | 10,228 |  |  | $ | 19,052 |  |  | $ | 15,242 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net unrealized gains (losses) on available-for-sale securities |  |  | 373 |  |  |  | (165 | ) |  |  | 1,708 |  |  |  | (420 | ) |
| Net unrealized losses on cash flow hedges |  |  | (417 | ) |  |  | — |  |  |  | (338 | ) |  |  | — |  |
| Defined benefit plan adjustments |  |  | 86 |  |  |  | 22 |  |  |  | 141 |  |  |  | 67 |  |
| Foreign currency translation |  |  | 2,619 |  |  |  | (601 | ) |  |  | 3,861 |  |  |  | 627 |  |
| Other Comprehensive Income (Loss), net of tax |  |  | 2,661 |  |  |  | (744 | ) |  |  | 5,372 |  |  |  | 274 |  |
| Comprehensive Income, net of tax |  | $ | 15,062 |  |  | $ | 9,484 |  |  | $ | 24,424 |  |  | $ | 15,516 |  |

[0001564590-17-013609:8k_2_02:26]
Consolidated Statements of Cash Flows

[0001564590-17-013609:8k_2_02:27]
(Unaudited)

[0001564590-17-013609:8k_2_02:28]
(In thousands)

[0001564590-17-013609:8k_2_02:29]
|  |  | Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 19,052 |  |  | $ | 15,242 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 5,156 |  |  |  | 6,689 |  |
| Amortization of net premium on available-for-sale investments |  |  | 238 |  |  |  | 376 |  |
| Net realized gain on long-term investments |  |  | (1,860 | ) |  |  | (2,838 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | (11 | ) |  |  | 5 |  |
| Stock-based compensation expense |  |  | 3,739 |  |  |  | 3,109 |  |
| Deferred income taxes |  |  | (2,772 | ) |  |  | (354 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 13,911 |  |  |  | (17,192 | ) |
| Other receivables |  |  | 571 |  |  |  | 7,876 |  |
| Inventory |  |  | (7,547 | ) |  |  | 4,938 |  |
| Prepaid expenses and other assets |  |  | (6,632 | ) |  |  | (4,263 | ) |
| Accounts payable |  |  | (10,910 | ) |  |  | 10,354 |  |
| Accrued expenses and other liabilities |  |  | (2,629 | ) |  |  | 1,474 |  |
| Income tax payable/receivable, net |  |  | 10,273 |  |  |  | (4,799 | ) |
| Net cash provided by operating activities |  |  | 20,579 |  |  |  | 20,617 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (7,509 | ) |  |  | (6,679 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 16 |  |  |  | — |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 81,891 |  |  |  | 109,993 |  |
| Purchases of available-for-sale investments |  |  | (65,140 | ) |  |  | (112,903 | ) |
| Net cash provided by (used in) investing activities |  |  | 9,258 |  |  |  | (9,589 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 1,722 |  |  |  | 541 |  |
| Purchases of treasury stock |  |  | (17,311 | ) |  |  | (16,579 | ) |
| Dividend payments |  |  | (8,719 | ) |  |  | (8,860 | ) |
| Net cash used in financing activities |  |  | (24,308 | ) |  |  | (24,898 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 5,529 |  |  |  | (13,870 | ) |
| Effect of exchange rate changes |  |  | 3,374 |  |  |  | 234 |  |
| Cash and cash equivalents, beginning of period |  |  | 79,895 |  |  |  | 84,550 |  |
| Cash and cash equivalents, end of period |  | $ | 88,798 |  |  | $ | 70,914 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 454 |  |  | $ | 554 |  |

[0001564590-17-013609:8k_2_02:30]
Supplemental Information

[0001564590-17-013609:8k_2_02:31]
Acquisition Related Expenses, Amortizations and Adjustments

[0001564590-17-013609:8k_2_02:32]
(Unaudited)

[0001564590-17-013609:8k_2_02:33]
(In thousands)

[0001564590-17-013609:8k_2_02:34]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc., on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA), and on September 13, 2016, we closed on the acquisition of CommScope’s active fiber business (CommScope). Acquisition related expenses, amortizations and adjustments for the three and six months ended June 30, 2017 and 2016 for all three transactions are as follows:

[0001564590-17-013609:8k_2_02:35]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 158 |  |  | $ | 173 |  |  | $ | 316 |  |  | $ | 346 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 129 |  |  |  | 228 |  |  |  | 337 |  |  |  | 455 |  |
| Amortization of other purchase accounting adjustments |  |  | 10 |  |  |  | 44 |  |  |  | 38 |  |  |  | 80 |  |
| Subtotal - NSN BBA acquisition |  |  | 139 |  |  |  | 272 |  |  |  | 375 |  |  |  | 535 |  |
| CommScope acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 608 |  |  |  | — |  |  |  | 1,294 |  |  |  | — |  |
| Amortization of other purchase accounting adjustments |  |  | 31 |  |  |  | — |  |  |  | 81 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | — |  |  |  | 8 |  |  |  | — |  |
| Subtotal - CommScope acquisition |  |  | 639 |  |  |  | — |  |  |  | 1,383 |  |  |  | — |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 936 |  |  |  | 445 |  |  |  | 2,074 |  |  |  | 881 |  |
| Provision for income taxes |  |  | (354 | ) |  |  | (152 | ) |  |  | (779 | ) |  |  | (301 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 582 |  |  | $ | 293 |  |  | $ | 1,295 |  |  | $ | 580 |  |

[0001564590-17-013609:8k_2_02:36]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and six months ended June 30, 2017 and 2016:

[0001564590-17-013609:8k_2_02:37]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Cost of goods sold |  | $ | 31 |  |  | $ | 13 |  |  | $ | 81 |  |  | $ | 20 |  |
| Selling, general and administrative expenses |  |  | 52 |  |  |  | 4 |  |  |  | 114 |  |  |  | 7 |  |
| Research and development expenses |  |  | 853 |  |  |  | 428 |  |  |  | 1,879 |  |  |  | 854 |  |
| Total acquisition related expenses, amortizations and adjustments included in operating expenses |  |  | 905 |  |  |  | 432 |  |  |  | 1,993 |  |  |  | 861 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 936 |  |  |  | 445 |  |  |  | 2,074 |  |  |  | 881 |  |
| Provision for income taxes |  |  | (354 | ) |  |  | (152 | ) |  |  | (779 | ) |  |  | (301 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 582 |  |  | $ | 293 |  |  | $ | 1,295 |  |  | $ | 580 |  |

[0001564590-17-013609:8k_2_02:38]
Supplemental Information

[0001564590-17-013609:8k_2_02:39]
Stock-based Compensation Expense

[0001564590-17-013609:8k_2_02:40]
(Unaudited)

[0001564590-17-013609:8k_2_02:41]
(In thousands)

[0001564590-17-013609:8k_2_02:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 93 |  |  | $ | 95 |  |  | $ | 184 |  |  | $ | 194 |  |
| Selling, general and administrative expense |  |  | 1,008 |  |  |  | 788 |  |  |  | 2,024 |  |  |  | 1,557 |  |
| Research and development expense |  |  | 755 |  |  |  | 668 |  |  |  | 1,531 |  |  |  | 1,358 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,763 |  |  |  | 1,456 |  |  |  | 3,555 |  |  |  | 2,915 |  |
| Total stock-based compensation expense |  |  | 1,856 |  |  |  | 1,551 |  |  |  | 3,739 |  |  |  | 3,109 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (433 | ) |  |  | (213 | ) |  |  | (813 | ) |  |  | (425 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,423 |  |  | $ | 1,338 |  |  | $ | 2,926 |  |  | $ | 2,684 |  |

[0001564590-17-013609:8k_2_02:43]
Reconciliation of GAAP net income per share, diluted, to

[0001564590-17-013609:8k_2_02:44]
Non-GAAP net income per share, diluted

[0001564590-17-013609:8k_2_02:45]
(Unaudited)

[0001564590-17-013609:8k_2_02:46]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| GAAP earnings per common share - diluted |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.39 |  |  | $ | 0.31 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.01 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.06 |  |  |  | 0.05 |  |
| Non-GAAP earnings per common share - diluted |  | $ | 0.30 |  |  | $ | 0.25 |  |  | $ | 0.48 |  |  | $ | 0.37 |  |
