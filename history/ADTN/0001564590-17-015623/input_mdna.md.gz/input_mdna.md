# ADTN MD&A — 0001564590-17-015623


## mdna

[0001564590-17-015623:mdna:1]
[same as prior period, unchanged from 0001564590-17-008397:mdna:1]

[0001564590-17-015623:mdna:2]
[same as prior period, unchanged from 0001564590-17-008397:mdna:2]

[0001564590-17-015623:mdna:3]
[same as prior period, unchanged from 0001564590-17-008397:mdna:3]

[0001564590-17-015623:mdna:4]
[same as prior period, unchanged from 0001564590-17-008397:mdna:4]

[0001564590-17-015623:mdna:5]
[same as prior period, unchanged from 0001564590-17-008397:mdna:5]

[0001564590-17-015623:mdna:6]
[same as prior period, unchanged from 0001564590-17-008397:mdna:6]

[0001564590-17-015623:mdna:7]
[same as prior period, unchanged from 0001564590-17-008397:mdna:7]

[0001564590-17-015623:mdna:8]
[same as prior period, unchanged from 0001564590-17-008397:mdna:8]

[0001564590-17-015623:mdna:9]
[same as prior period, unchanged from 0001564590-17-008397:mdna:9]

[0001564590-17-015623:mdna:10]
[same as prior period, unchanged from 0001564590-17-008397:mdna:10]

[0001564590-17-015623:mdna:11]
|  | • | Fiber to the Distribution Point (FTTdp) G.fast Optical Network Units (ONU) |

[0001564590-17-015623:mdna:12]
[same as prior period, unchanged from 0001564590-17-008397:mdna:12]

[0001564590-17-015623:mdna:13]
[same as prior period, unchanged from 0001564590-17-008397:mdna:13]

[0001564590-17-015623:mdna:14]
[same as prior period, unchanged from 0001564590-17-008397:mdna:14]

[0001564590-17-015623:mdna:15]
[same as prior period, unchanged from 0001564590-17-008397:mdna:15]

[0001564590-17-015623:mdna:16]
[same as prior period, unchanged from 0001564590-17-008397:mdna:16]

[0001564590-17-015623:mdna:17]
[same as prior period, unchanged from 0001564590-17-008397:mdna:17]

[0001564590-17-015623:mdna:18]
[same as prior period, unchanged from 0001564590-17-008397:mdna:18]

[0001564590-17-015623:mdna:19]
[same as prior period, unchanged from 0001564590-17-008397:mdna:19]

[0001564590-17-015623:mdna:20]
[same as prior period, unchanged from 0001564590-17-008397:mdna:20]

[0001564590-17-015623:mdna:21]
[same as prior period, unchanged from 0001564590-17-008397:mdna:21]

[0001564590-17-015623:mdna:22]
[same as prior period, unchanged from 0001564590-17-008397:mdna:22]

[0001564590-17-015623:mdna:23]
[same as prior period, unchanged from 0001564590-17-008397:mdna:23]

[0001564590-17-015623:mdna:24]
[same as prior period, unchanged from 0001564590-17-008397:mdna:24]

[0001564590-17-015623:mdna:25]
[same as prior period, unchanged from 0001564590-17-008397:mdna:25]

[0001564590-17-015623:mdna:26]
[same as prior period, unchanged from 0001564590-17-008397:mdna:26]

[0001564590-17-015623:mdna:27]
[same as prior period, unchanged from 0001564590-17-008397:mdna:27]

[0001564590-17-015623:mdna:28]
[same as prior period, unchanged from 0001564590-17-008397:mdna:28]

[0001564590-17-015623:mdna:29]
[same as prior period, unchanged from 0001564590-17-008397:mdna:29]

[0001564590-17-015623:mdna:30]
[same as prior period, unchanged from 0001564590-17-008397:mdna:30]

[0001564590-17-015623:mdna:31]
[same as prior period, unchanged from 0001564590-17-008397:mdna:31]

[0001564590-17-015623:mdna:32]
[same as prior period, unchanged from 0001564590-17-008397:mdna:32]

[0001564590-17-015623:mdna:33]
[same as prior period, unchanged from 0001564590-17-008397:mdna:33]

[0001564590-17-015623:mdna:34]
[same as prior period, unchanged from 0001564590-17-008397:mdna:34]

[0001564590-17-015623:mdna:35]
[same as prior period, unchanged from 0001564590-17-008397:mdna:35]

[0001564590-17-015623:mdna:36]
[same as prior period, unchanged from 0001564590-17-008397:mdna:36]

[0001564590-17-015623:mdna:37]
[same as prior period, unchanged from 0001564590-17-008397:mdna:37]

[0001564590-17-015623:mdna:38]
[same as prior period, unchanged from 0001564590-17-008397:mdna:38]

[0001564590-17-015623:mdna:39]
[same as prior period, unchanged from 0001564590-17-008397:mdna:39]

[0001564590-17-015623:mdna:40]
Sales were $184.7 million and $355.0 million for the three and six months ended June 30, 2017, compared to $162.7 million and $304.9 million for the three and six months ended June 30, 2016. Our gross margin decreased to 45.8% and 44.6% for the three and six months ended June 30, 2017, from 48.5% and 47.5% for the three and six months ended June 30, 2016. Our operating income margin decreased to 8.9% and 6.6% for the three and six months ended June 30, 2017, from 9.1% and 6.7% for the three and six months ended June 30, 2016. Net income was $12.4 million and $19.1 million for the three and six months ended June 30, 2017, compared to $10.2 million and $15.2 million for the three and six months ended June 30, 2016. Our effective tax rate decreased to 30.6% and 27.3% for the three and six months ended June 30, 2017, from 37.8% and 37.9% for the three and six months ended June 30, 2016.  Earnings per share, assuming dilution, were $0.26 and $0.39 for the three and six months ended June 30, 2017, compared to $0.21 and $0.31 for the three and six months ended June 30, 2016.

[0001564590-17-015623:mdna:41]
[same as prior period, unchanged from 0001564590-17-008397:mdna:41]

[0001564590-17-015623:mdna:42]
[same as prior period, unchanged from 0001564590-17-008397:mdna:42]

[0001564590-17-015623:mdna:43]
[same as prior period, unchanged from 0001564590-17-008397:mdna:43]

[0001564590-17-015623:mdna:44]
[same as prior period, unchanged from 0001564590-17-008397:mdna:44]

[0001564590-17-015623:mdna:45]
[same as prior period, unchanged from 0001564590-17-008397:mdna:45]

[0001564590-17-015623:mdna:46]
[same as prior period, unchanged from 0001564590-17-008397:mdna:46]

[0001564590-17-015623:mdna:47]
[same as prior period, unchanged from 0001564590-17-008397:mdna:47]

[0001564590-17-015623:mdna:48]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2017 COMPARED TO THREE AND SIX MONTHS ENDED JUNE 30, 2016

[0001564590-17-015623:mdna:49]
[same as prior period, unchanged from 0001564590-17-008397:mdna:49]

[0001564590-17-015623:mdna:50]
Our sales increased 13.5% from $162.7 million in the three months ended June 30, 2016 to $184.7 million in the three months ended June 30, 2017, and increased 16.4% from $304.9 million in the six months ended June 30, 2016 to $355.0 million in the six months ended June 30, 2017. The increase in sales for the three months ended June 30, 2017 is primarily attributable to a $36.4 million increase in sales of our Access & Aggregation products, partially offset by a $7.4 million decrease in sales of our Traditional & Other Products and a $7.0 million decrease in sales of our Customer Devices products. The increase in sales for the six months ended June 30, 2017 is primarily attributable to a $62.7 million increase in sales of our Access & Aggregation products, partially offset by a $9.5 million decrease in sales of our Traditional & Other Products and a $3.1 million decrease in sales of our Customer Devices products.

[0001564590-17-015623:mdna:51]
Network Solutions sales increased 12.3% from $138.5 million in the three months ended June 30, 2016 to $155.5 million in the three months ended June 30, 2017, and increased 14.0% from $262.4 million in the six months ended June 30, 2016 to $299.1 million in the six months ended June 30, 2017. The increase in sales for the three and six months ended June 30, 2017 is primarily attributable to an increase in sales of Access & Aggregation products, partially offset by a decrease in sales of Customer Devices products and Traditional & Other Products. The increase in sales of our Access & Aggregation products for the three and six months ended June 30, 2017 is primarily attributable to increased VDSL2 vectoring product sales in the U.S. and European carrier markets. The decrease in sales of our Customer Devices products is primarily attributable to decreased EFM NTE product sales, which were primarily impacted by an accelerated Ethernet infrastructure build that occurred in the second quarter of 2016. While we expect that revenues from Traditional & Other Products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-17-015623:mdna:52]
Services & Support sales increased 20.6% from $24.2 million in the three months ended June 30, 2016 to $29.1 million in the three months ended June 30, 2017, and increased 31.4% from $42.5 million in the six months ended June 30, 2016 to $55.8 million in the six months ended June 30, 2017. The increase in sales for the three and six months ended June 30, 2017 is primarily attributable to an increase in network installation services for Access & Aggregation products.

[0001564590-17-015623:mdna:53]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, increased 30.5% from $29.1 million in the three months ended June 30, 2016 to $38.0 million in the three months ended June 30, 2017, and increased 62.0% from $54.9 million in the six months ended June 30, 2016 to $89.0 million in the six months ended June 30, 2017. International sales, as a percentage of total sales, increased from 17.9% and 18.0% for the three and six months ended June 30, 2016, to 20.6% and 25.1% for the three and six months ended June 30, 2017. Our international revenues are affected to a great extent by the timing of network upgrade projects at our larger European customers and by changes in foreign exchange rates in territories in which we sell our products and services. In first quarter 2017, international network upgrades resumed; whereas, in 2016 our largest European customer focused on completing network upgrade activities in regions outside of our footprint with them.

[0001564590-17-015623:mdna:54]
[same as prior period, unchanged from 0001564590-17-008397:mdna:54]

[0001564590-17-015623:mdna:55]
As a percentage of sales, cost of sales increased from 51.5% in the three months ended June 30, 2016 to 54.2% in the three months ended June 30, 2017, and increased from 52.5% in the six months ended June 30, 2016 to 55.4% in the six months ended June 30, 2017. The increase in cost of sales as a percentage of sales for the three months ended June 30, 2017 is primarily attributable to a regional revenue shift, customer and product mix, services and support mix and an increase in warranty expense. The increase in cost of sales as a percentage of sales for the six months ended June 30, 2017 is primarily attributable to a regional revenue shift, customer and product mix and services and support mix.

[0001564590-17-015623:mdna:56]
Network Solutions cost of sales, as a percent of that segment’s sales, increased from 49.0% in the three months ended June 30, 2016 to 51.2% in the three months ended June 30, 2017, and increased from 50.3% in the six months ended June 30, 2016 to 52.3% in the six months ended June 30, 2017. The increase in cost of sales as a percentage of sales for the three months ended June 30, 2017 is primarily attributable to a regional revenue shift, customer and product mix and an increase in warranty expense. The increase in cost of sales as a percentage of sales for the six months ended June 30, 2017 is primarily attributable to a regional revenue shift and customer and product mix.

[0001564590-17-015623:mdna:57]
Services & Support cost of sales, as a percent of that segment’s sales, increased from 65.8% in the three months ended June 30, 2016 to 70.0% in the three months ended June 30, 2017, and increased from 66.5% in the six months ended June 30, 2016 to 72.2% in the six months ended June 30, 2017. The increase in cost of sales as a percentage of sales for the three and six months ended June 30, 2017 is primarily attributable to an increase in network installation services during 2017, which have higher costs, as opposed to a greater mix of maintenance and support services, which have lower costs.

[0001564590-17-015623:mdna:58]
[same as prior period, unchanged from 0001564590-17-008397:mdna:58]

[0001564590-17-015623:mdna:59]
[same as prior period, unchanged from 0001564590-17-008397:mdna:59]

[0001564590-17-015623:mdna:60]
Selling, general and administrative expenses increased 5.5% from $32.9 million in the three months ended June 30, 2016 to $34.7 million in the three months ended June 30, 2017, and increased 9.1% from $63.7 million in the six months ended June 30, 2016 to $69.5 million in the six months ended June 30, 2017. The increase in selling, general and administrative expenses for the three months ended June 30, 2017 is primarily attributable to increases in deferred compensation expense and ERP implementation expenses. The increase in selling, general and administrative expenses for the six months ended June 30, 2017 is primarily attributable to increases in ERP implementation expenses, deferred compensation expense, travel expense and performance and equity-based compensation expense, partially offset by a decrease in commission expense.

[0001564590-17-015623:mdna:61]
As a percentage of sales, selling, general and administrative expenses decreased from 20.2% in the three months ended June 30, 2016 to 18.8% in the three months ended June 30, 2017, and decreased from 20.9% in the six months ended June 30, 2016 to 19.6% in the six months ended June 30, 2017. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-17-015623:mdna:62]
[same as prior period, unchanged from 0001564590-17-008397:mdna:62]

[0001564590-17-015623:mdna:63]
Research and development expenses increased 7.1% from $31.3 million in the three months ended June 30, 2016 to $33.5 million in the three months ended June 30, 2017, and increased 7.7% from $60.8 million in the six months ended June 30, 2016 to $65.4 million in the six month ended June 30, 2017. The increase in research and development expenses for the three months ended June 30, 2017 is primarily attributable to an increase in labor and engineering materials related to customer specific projects and amortization of intangibles acquired in the third quarter of 2016. The increase in research and development expenses for the six months ended June 30, 2017 is primarily attributable to an increase in amortization of intangibles acquired in the third quarter of 2016, labor and engineering materials cost related to customer specific projects and contract services.

[0001564590-17-015623:mdna:64]
As a percentage of sales, research and development expenses decreased from 19.2% in the three months ended June 30, 2016 to 18.1% in the three months ended June 30, 2017, and decreased from 19.9% in the six months ended June 30, 2016 to 18.4% in the six months ended June 30, 2017. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001564590-17-015623:mdna:65]
[same as prior period, unchanged from 0001564590-17-008397:mdna:65]

[0001564590-17-015623:mdna:66]
[same as prior period, unchanged from 0001564590-17-008397:mdna:66]

[0001564590-17-015623:mdna:67]
Interest and dividend income increased 4.9% from $0.9 million in the three months ended June 30, 2016 to $1.0 million in the three months ended June 30, 2017, and increased 6.9% from $1.8 million in the six months ended June 30, 2016 to $1.9 million in the six months ended June 30, 2017. The increase in interest and dividend income for the three and six months ended June 30, 2017 is primarily attributable to an increase in the rate of return on fixed income investments.

[0001564590-17-015623:mdna:68]
[same as prior period, unchanged from 0001564590-17-008397:mdna:68]

[0001564590-17-015623:mdna:69]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended June 30, 2016 and 2017, and $0.3 million in the six months ended June 30, 2016 and 2017, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-17-015623:mdna:70]
[same as prior period, unchanged from 0001564590-17-008397:mdna:70]

[0001564590-17-015623:mdna:71]
Net realized investment gains increased 25.2% from $1.1 million in the three months ended June 30, 2016 to $1.4 million in the three months ended June 30, 2017, and decreased 34.5% from $2.8 million in the six months ended June 30, 2016 to $1.9 million in the six months ended June 30, 2017. The increase in realized investment gains for the three months ended June 30, 2017 is primarily attributable to increased gains on our deferred compensation plans, partially offset by decreased gains from the sale of equity securities. The decrease in realized investment gains for the six months ended June 30, 2017 is primarily attributable to decreased gains from the sale of equity securities, partially offset by increased gains on our deferred compensation plans. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-17-015623:mdna:72]
[same as prior period, unchanged from 0001564590-17-008397:mdna:72]

[0001564590-17-015623:mdna:73]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, gains and losses on foreign exchange forward contracts, investment account management fees, and scrap raw material sales, increased 220.3% from $0.3 million of expense in the three months ended June 30, 2016 to $0.8 million of expense in the three months ended June 30, 2017, and increased 470.5% from $0.1 million of expense in the six months ended June 30, 2016 to $0.8 million of expense in the six months ended June 30, 2017. The increase in other expense for the three and six months ended June 30, 2017 is primarily attributable to increased losses on our foreign exchange contracts.

[0001564590-17-015623:mdna:74]
[same as prior period, unchanged from 0001564590-17-008397:mdna:74]

[0001564590-17-015623:mdna:75]
Our effective tax rate decreased from 37.9% in the six months ended June 30, 2016 to 27.3% in the six months ended June 30, 2017. The decrease in the effective tax rate between the two periods is primarily attributable to a 6.3% effective rate reduction due to a greater mix of international revenues and a 3.2% effective rate reduction for a provision-to-return adjustment related to the assignment of research and development expenditures to specific company engineering locations.

[0001564590-17-015623:mdna:76]
[same as prior period, unchanged from 0001564590-17-008397:mdna:76]

[0001564590-17-015623:mdna:77]
As a result of the above factors, net income increased $2.2 million from $10.2 million in the three months ended June 30, 2016 to $12.4 million in the three months ended June 30, 2017, and increased $3.8 million from $15.2 million in the six month ended June 30, 2016 to $19.1 million in the six months ended June 30, 2017.

[0001564590-17-015623:mdna:78]
As a percentage of sales, net income increased from 6.3% in the three months ended June 30, 2016 to 6.7% in the three months ended June 30, 2017, and increased from 5.0% in the six months ended June 30, 2016 to 5.4% in the six months ended June 30, 2017.

[0001564590-17-015623:mdna:79]
[same as prior period, unchanged from 0001564590-17-008397:mdna:79]

[0001564590-17-015623:mdna:80]
[same as prior period, unchanged from 0001564590-17-008397:mdna:80]

[0001564590-17-015623:mdna:81]
[same as prior period, unchanged from 0001564590-17-008397:mdna:81]

[0001564590-17-015623:mdna:82]
At June 30, 2017, cash on hand was $88.8 million and short-term investments were $47.3 million, which resulted in available short-term liquidity of $136.1 million, of which $56.9 million was held by our foreign subsidiaries. At December 31, 2016, cash on hand was $79.9 million and short-term investments were $43.2 million, which resulted in available short-term liquidity of $123.1 million, of which $42.1 million was held by our foreign subsidiaries. We intend to permanently reinvest these funds outside the U.S. and our current business plans do not indicate a need to repatriate to fund domestic operations. The increase in short-term liquidity from December 31, 2016 to June 30, 2017 is primarily attributable to shifts among available investment option tenures to provide funds for our short-term cash needs.

[0001564590-17-015623:mdna:83]
[same as prior period, unchanged from 0001564590-17-008397:mdna:83]

[0001564590-17-015623:mdna:84]
Our working capital, which consists of current assets less current liabilities, increased 9.2% from $226.4 million as of December 31, 2016 to $247.2 million as of June 30, 2017, and our current ratio, defined as current assets divided by current liabilities, increased from 2.79 as of December 31, 2016 to 3.04 as of June 30, 2017. The increase in our working capital and current ratio is primarily attributable to an increase in inventory and prepaid expenses and other current assets and a decrease in accounts payable and accrued wages and benefits, partially offset by a decrease in accounts receivable and an increase in income tax payable. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, increased from 1.70 as of December 31, 2016 to 1.79 as of June 30, 2017. The increase in the quick ratio is primarily attributable to a decrease in accounts payable and accrued wages and benefits, partially offset by an increase in income tax payable.

[0001564590-17-015623:mdna:85]
Accounts receivable decreased 13.5% from $92.3 million at December 31, 2016 to $79.9 million at June 30, 2017. We had no allowance for doubtful accounts at December 31, 2016 or June 30, 2017. Quarterly accounts receivable days sales outstanding (DSO) decreased from 52 days as of December 31, 2016 to 39 days as of June 30, 2017. The change in net accounts receivable is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than U.S. customers. Other receivables decreased from $15.1 million at December 31, 2016 to $14.6 million at June 30, 2017. The decrease in other receivables is primarily attributable to the timing of filing returns and collections of VAT receivables in our international subsidiaries. Other receivables will also fluctuate due to the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001564590-17-015623:mdna:86]
Quarterly inventory turnover decreased from 3.67 turns as of December 31, 2016 to 3.53 turns at June 30, 2017. Inventory increased 8.4% from December 31, 2016 to June 30, 2017. The increase in inventory at June 30, 2017 is primarily attributable to customer specific projects. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-17-015623:mdna:87]
Accounts payable decreased 14.5% from $77.3 million at December 31, 2016 to $66.2 million at June 30, 2017. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-17-015623:mdna:88]
[same as prior period, unchanged from 0001564590-17-008397:mdna:88]

[0001564590-17-015623:mdna:89]
Capital expenditures totaled approximately $7.5 million and $6.7 million for the six months ended June 30, 2017 and 2016, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-17-015623:mdna:90]
Our combined short-term and long-term investments decreased $12.3 million from $219.3 million at December 31, 2016 to $207.0 million at June 30, 2017. This decrease reflects our cash needs for capital expenditures, purchases of treasury stock, and shareholder dividends partially offset by funds available for investment provided by our operating activities and stock option exercises by our employees, as well as net realized and unrealized gains and losses and amortization of net premiums on our combined investments.

[0001564590-17-015623:mdna:91]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At June 30, 2017 these investments included corporate bonds of $73.0 million, municipal fixed-rate bonds of $7.6 million, asset-backed bonds of $13.3 million, mortgage/agency-backed bonds of $9.5 million, U.S. government bonds of $21.4 million, and foreign government bonds of $2.7 million. At December 31, 2016, these investments included corporate bonds of $66.4 million, municipal fixed-rate bonds of $11.8 million, asset-backed bonds of $10.2 million, mortgage/agency-backed bonds of $13.0 million, U.S. government bonds of $29.8 million, foreign government bonds of $3.7 million and variable rate demand notes of $11.9 million. As of June 30, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds were classified as available-for-sale and had a combined duration of 0.9 years with an average Standard & Poor’s credit rating of A+. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-17-015623:mdna:92]
Our long-term investments decreased 9.4% from $176.1 million at December 31, 2016 to $159.6 million at June 30, 2017. Long-term investments at June 30, 2017 and December 31, 2016 included an investment in a certificate of deposit of $27.8 million, which serves as collateral for our revenue bond. See “Debt” below for additional information. We have various equity investments included in long-term investments at a cost of $31.7 million and $30.6 million, and with a fair value of $33.0 million and $29.4 million, at June 30, 2017 and December 31, 2016, respectively.

[0001564590-17-015623:mdna:93]
Long-term investments at June 30, 2017 and December 31, 2016 also included $18.0 million and $14.6 million, respectively, related to our deferred compensation plans, and $0.7 million and $0.8 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001564590-17-015623:mdna:94]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and six months ended June 30, 2017 and 2016, other-than-temporary impairment charges were not significant.

[0001564590-17-015623:mdna:95]
[same as prior period, unchanged from 0001564590-17-008397:mdna:95]

[0001564590-17-015623:mdna:96]
[same as prior period, unchanged from 0001564590-17-008397:mdna:96]

[0001564590-17-015623:mdna:97]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the six months ended June 30, 2017, we paid dividends totaling $8.7 million.

[0001564590-17-015623:mdna:98]
[same as prior period, unchanged from 0001564590-17-008397:mdna:98]

[0001564590-17-015623:mdna:99]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $27.8 million at June 30, 2017 and December 31, 2016. At June 30, 2017, the estimated fair value of the Bond was approximately $28.0 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $27.8 million at June 30, 2017 and December 31, 2016, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.0 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at June 30, 2017.

[0001564590-17-015623:mdna:100]
[same as prior period, unchanged from 0001564590-17-008397:mdna:100]

[0001564590-17-015623:mdna:101]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2017, we repurchased 0.9 million shares of our common stock at an average price of $20.27 per share. As of June 30, 2017, we have the authority to purchase an additional 3.6 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-17-015623:mdna:102]
[same as prior period, unchanged from 0001564590-17-008397:mdna:102]

[0001564590-17-015623:mdna:103]
We issued 0.1 million shares of treasury stock during the six months ended June 30, 2017 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $23.02. We received proceeds totaling $1.7 million from the exercise of these stock options during the six months ended June 30, 2017.

[0001564590-17-015623:mdna:104]
[same as prior period, unchanged from 0001564590-17-008397:mdna:104]

[0001564590-17-015623:mdna:105]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the six months ended June 30, 2017, there have been no material changes in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2016 filed on February 24, 2017 with the SEC.

[0001564590-17-015623:mdna:106]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2017, of which $7.7 million has been applied to these commitments.

[0001564590-17-015623:mdna:107]
32
