# ADTN notes — 0001564590-17-015623


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-17-015623:notes:1]
[same as prior period, unchanged from 0001564590-17-008397:notes:1]

[0001564590-17-015623:notes:2]
[same as prior period, unchanged from 0001564590-17-008397:notes:2]

[0001564590-17-015623:notes:3]
[same as prior period, unchanged from 0001564590-17-008397:notes:3]

[0001564590-17-015623:notes:4]
[same as prior period, unchanged from 0001564590-17-008397:notes:4]

[0001564590-17-015623:notes:5]
[same as prior period, unchanged from 0001564590-17-008397:notes:5]

[0001564590-17-015623:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-17-015623:notes:7]
[same as prior period, unchanged from 0001564590-17-008397:notes:7]

[0001564590-17-015623:notes:8]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method. We are continuing to evaluate the potential impact of these ASUs, and we believe the most significant potential impact relates to our accounting for software license and installation services revenues. We do not believe there will be a significant impact to product or maintenance revenues.

[0001564590-17-015623:notes:9]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of ASU 2016-02 will have a material impact on our financial position; however, we do not believe adoption will have a material impact on our results of operations. We believe the most significant impact relates to our accounting for operating leases for office space and equipment.

[0001564590-17-015623:notes:10]
In January 2017, the FASB issued Accounting Standards Update No. 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04). ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material impact on our financial position, results of operations or cash flows.

[0001564590-17-015623:notes:11]
In March 2017, the FASB issued Accounting Standards Update No. 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost (ASU 2017-07). ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. ASU 2017-07 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted. We do not expect ASU 2017-07 will have a material impact on our financial position, results of operations or cash flows.

[0001564590-17-015623:notes:12]
During 2017, we adopted the following accounting standards, which had no material effect on our financial position, results of operations or cash flows:

[0001564590-17-015623:notes:13]
In July 2015, the FASB issued Accounting Standards Update No.  2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We adopted ASU 2015-11 in the first quarter of 2017, and there was no material impact on our financial position, results of operations or cash flows.

[0001564590-17-015623:notes:14]
In January 2017, we adopted ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. As a result, beginning in the first quarter of 2017, we began recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit as a discrete event. The treatment of forfeitures has changed as we have elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur. As a result, we recorded an increase in additional paid in capital of $0.1 million, a charge to beginning retained earnings of $0.1 million, and an increase in the deferred tax assets related to non-qualified stock options and RSUs of $10 thousand. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows within operating activities. We elected to retrospectively apply the changes in presentation to the statements of cash flows and no longer classify excess tax benefits as a financing activity, which had no effect on our cash flows for the six months ended June 30, 2016. There was no material impact on our financial position, results of operations or cash flows as a result of these changes.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-015623:notes:15]
[same as prior period, unchanged from 0001564590-17-008397:notes:15]

[0001564590-17-015623:notes:16]
[same as prior period, unchanged from 0001564590-17-008397:notes:16]

[0001564590-17-015623:notes:17]
We recorded a bargain purchase gain of $3.5 million during the third quarter of 2016, net of income taxes, subject to customary working capital adjustments between the parties. The bargain purchase gain of $3.5 million represents the excess fair value of the net assets acquired over the consideration exchanged. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and have concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-17-015623:notes:18]
[same as prior period, unchanged from 0001564590-17-008397:notes:18]

[0001564590-17-015623:notes:19]
[same as prior period, unchanged from 0001564590-17-008397:notes:19]

[0001564590-17-015623:notes:20]
[same as prior period, unchanged from 0001564590-17-008397:notes:20]

[0001564590-17-015623:notes:21]
[same as prior period, unchanged from 0001564590-17-008397:notes:21]

[0001564590-17-015623:notes:22]
[same as prior period, unchanged from 0001564590-17-008397:notes:22]

[0001564590-17-015623:notes:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Pro forma revenue |  | $ | 164,332 |  |  | $ | 160,562 |  |  | $ | 307,687 |  |  | $ | 304,542 |  |
| Pro forma net income |  | $ | 10,022 |  |  | $ | 1,983 |  |  | $ | 14,907 |  |  | $ | 8,405 |  |
| Pro forma earnings per share - basic |  | $ | 0.21 |  |  | $ | 0.04 |  |  | $ | 0.30 |  |  | $ | 0.16 |  |
| Pro forma earnings per share - diluted |  | $ | 0.20 |  |  | $ | 0.04 |  |  | $ | 0.30 |  |  | $ | 0.16 |  |

[0001564590-17-015623:notes:24]
For the three and six months ended June 30, 2017, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $0.6 million and $1.4 million, respectively, related to this acquisition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-015623:notes:25]
[same as prior period, unchanged from 0001564590-17-008397:notes:25]

[0001564590-17-015623:notes:26]
Our effective tax rate decreased from 37.9% in the six months ended June 30, 2016 to 27.3% in the six months ended June 30, 2017. The decrease in the effective tax rate between the two periods is primarily attributable to a 6.3% effective rate reduction due to a greater mix of international revenues and a 3.2% effective rate reduction for a provision-to-return adjustment related to the assignment of research and development expenditures to specific company engineering locations.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-17-015623:notes:27]
[same as prior period, unchanged from 0001564590-17-008397:notes:27]

[0001564590-17-015623:notes:28]
[same as prior period, unchanged from 0001564590-17-008397:notes:28]

[0001564590-17-015623:notes:29]
The following table summarizes the components of net periodic pension cost for the three and six months ended June 30, 2017 and 2016

[0001564590-17-015623:notes:30]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Service cost |  | $ | 306 |  |  | $ | 310 |  |  | $ | 603 |  |  | $ | 607 |  |
| Interest cost |  |  | 147 |  |  |  | 184 |  |  |  | 290 |  |  |  | 360 |  |
| Expected return on plan assets |  |  | (307 | ) |  |  | (271 | ) |  |  | (606 | ) |  |  | (530 | ) |
| Amortization of actuarial losses |  |  | 75 |  |  |  | 45 |  |  |  | 148 |  |  |  | 88 |  |
| Net periodic pension cost |  | $ | 221 |  |  | $ | 268 |  |  | $ | 435 |  |  | $ | 525 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-17-015623:notes:31]
[same as prior period, unchanged from 0001564590-17-008397:notes:31]

[0001564590-17-015623:notes:32]
The following table summarizes the stock-based compensation expense related to stock options, performance stock units (PSUs), restricted stock units (RSUs) and restricted stock for the three and six months ended June 30, 2017 and 2016, which was recognized as follows:

[0001564590-17-015623:notes:33]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 93 |  |  | $ | 95 |  |  | $ | 184 |  |  | $ | 194 |  |
| Selling, general and administrative expense |  |  | 1,008 |  |  |  | 788 |  |  |  | 2,024 |  |  |  | 1,557 |  |
| Research and development expense |  |  | 755 |  |  |  | 668 |  |  |  | 1,531 |  |  |  | 1,358 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,763 |  |  |  | 1,456 |  |  |  | 3,555 |  |  |  | 2,915 |  |
| Total stock-based compensation expense |  |  | 1,856 |  |  |  | 1,551 |  |  |  | 3,739 |  |  |  | 3,109 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (433 | ) |  |  | (213 | ) |  |  | (813 | ) |  |  | (425 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,423 |  |  | $ | 1,338 |  |  | $ | 2,926 |  |  | $ | 2,684 |  |

[0001564590-17-015623:notes:34]
[same as prior period, unchanged from 0001564590-17-008397:notes:34]

[0001564590-17-015623:notes:35]
The following table is a summary of our stock options outstanding as of December 31, 2016 and June 30, 2017 and the changes that occurred during the six months ended June 30, 2017:

[0001564590-17-015623:notes:36]
| (In thousands, except per share amounts) |  | Number of Stock Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Stock options outstanding, December 31, 2016 |  |  | 6,338 |  |  | $ | 22.14 |  |  |  | 5.63 |  |  | $ | 16,972 |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (103 | ) |  | $ | 16.78 |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (32 | ) |  | $ | 17.62 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (55 | ) |  | $ | 26.67 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, June 30, 2017 |  |  | 6,148 |  |  | $ | 22.21 |  |  |  | 5.14 |  |  | $ | 11,232 |  |
| Stock options vested and expected to vest, June 30, 2017 |  |  | 6,148 |  |  | $ | 22.21 |  |  |  | 5.14 |  |  | $ | 11,232 |  |
| Options exercisable, June 30, 2017 |  |  | 4,601 |  |  | $ | 23.78 |  |  |  | 4.23 |  |  | $ | 5,862 |  |

[0001564590-17-015623:notes:37]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between the closing price of our stock on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money stock options) that would have been received by the option holders had all option holders exercised their options on June 30, 2017. The aggregate intrinsic value will change based on the fair market value of our stock.

[0001564590-17-015623:notes:38]
The total pre-tax intrinsic value of options exercised during the three and six months ended June 30, 2017 was $0.1 million and $0.5, respectively.

[0001564590-17-015623:notes:39]
As of June 30, 2017, there was $5.2 million of unrecognized compensation expense related to unvested stock options, which is expected to be recognized over an average remaining recognition period of 1.8 years.

[0001564590-17-015623:notes:40]
[same as prior period, unchanged from 0001564590-17-008397:notes:40]

[0001564590-17-015623:notes:41]
There were no stock options granted during the three or six months ended June 30, 2017. The weighted-average assumptions and value of options granted during the three and six months ended June 30, 2016 were as follows:

[0001564590-17-015623:notes:42]
|  | Three and Six Months Ended |  |
|  | June 30, |  |
|  | 2016 |  |
| Expected volatility |  | 34.74 | % |
| Risk-free interest rate |  | 1.33 | % |
| Expected dividend yield |  | 1.91 | % |
| Expected life (in years) |  | 6.26 |  |
| Weighted-average estimated value | $ | 5.42 |  |

[0001564590-17-015623:notes:43]
[same as prior period, unchanged from 0001564590-17-008397:notes:42]

[0001564590-17-015623:notes:44]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2016 and the changes that occurred during the six months ended June 30, 2017:

[0001564590-17-015623:notes:45]
| (In thousands, except per share amounts) |  | Number of Shares |  |  | Weighted Avg. Grant Date Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2016 |  |  | 519 |  |  | $ | 20.51 |  |
| PSUs, RSUs and restricted stock granted |  |  | 520 |  |  | $ | 22.24 |  |
| PSUs, RSUs and restricted stock vested |  |  | (2 | ) |  | $ | 18.29 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (6 | ) |  | $ | 20.00 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, June 30, 2017 |  |  | 1,031 |  |  | $ | 21.39 |  |

[0001564590-17-015623:notes:46]
[same as prior period, unchanged from 0001564590-17-008397:notes:45]

[0001564590-17-015623:notes:47]
As of June 30, 2017, there was $7.9 million of unrecognized compensation expense related to unvested market-based PSUs, RSUs and restricted stock, which is expected to be recognized over an average remaining recognition period of 3.0 years. In addition, there was $11.5 million of unrecognized compensation expense related to unvested performance-based PSUs, which will be recognized over the requisite service period of three years as achievement of the performance objective becomes probable. For the three and six months ended June 30, 2017, no compensation expense was recognized related to these performance-based PSU awards.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-17-015623:notes:48]
6. INVESTMENTS

[0001564590-17-015623:notes:49]
At June 30, 2017, we held the following securities and investments, recorded at either fair value or cost:

[0001564590-17-015623:notes:50]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 15,662 |  |  | $ | 2,389 |  |  | $ | (23 | ) |  | $ | 18,028 |  |
| Corporate bonds |  |  | 72,954 |  |  |  | 132 |  |  |  | (107 | ) |  |  | 72,979 |  |
| Municipal fixed-rate bonds |  |  | 7,596 |  |  |  | 7 |  |  |  | (20 | ) |  |  | 7,583 |  |
| Asset-backed bonds |  |  | 13,313 |  |  |  | 11 |  |  |  | (16 | ) |  |  | 13,308 |  |
| Mortgage/Agency-backed bonds |  |  | 9,549 |  |  |  | 14 |  |  |  | (36 | ) |  |  | 9,527 |  |
| U.S. government bonds |  |  | 21,528 |  |  |  | 4 |  |  |  | (132 | ) |  |  | 21,400 |  |
| Foreign government bonds |  |  | 2,700 |  |  |  | 3 |  |  |  | (1 | ) |  |  | 2,702 |  |
| Marketable equity securities |  |  | 31,741 |  |  |  | 2,153 |  |  |  | (929 | ) |  |  | 32,965 |  |
| Available-for-sale securities held at fair value |  | $ | 175,043 |  |  | $ | 4,713 |  |  | $ | (1,264 | ) |  | $ | 178,492 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 673 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 206,965 |  |

[0001564590-17-015623:notes:51]
At December 31, 2016, we held the following securities and investments, recorded at either fair value or cost:

[0001564590-17-015623:notes:52]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 12,367 |  |  | $ | 2,271 |  |  | $ | (42 | ) |  | $ | 14,596 |  |
| Corporate bonds |  |  | 66,522 |  |  |  | 64 |  |  |  | (174 | ) |  |  | 66,412 |  |
| Municipal fixed-rate bonds |  |  | 11,799 |  |  |  | 12 |  |  |  | (37 | ) |  |  | 11,774 |  |
| Asset-backed bonds |  |  | 10,201 |  |  |  | 19 |  |  |  | (14 | ) |  |  | 10,206 |  |
| Mortgage/Agency-backed bonds |  |  | 13,080 |  |  |  | 15 |  |  |  | (91 | ) |  |  | 13,004 |  |
| U.S. government bonds |  |  | 30,022 |  |  |  | 15 |  |  |  | (270 | ) |  |  | 29,767 |  |
| Foreign government bonds |  |  | 3,729 |  |  |  | 2 |  |  |  | (1 | ) |  |  | 3,730 |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | — |  |  |  | 11,855 |  |
| Marketable equity securities |  |  | 30,571 |  |  |  | 311 |  |  |  | (1,503 | ) |  |  | 29,379 |  |
| Available-for-sale securities held at fair value |  | $ | 190,146 |  |  | $ | 2,709 |  |  | $ | (2,132 | ) |  | $ | 190,723 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 767 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 219,290 |  |

[0001564590-17-015623:notes:53]
As of June 30, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds and foreign government bonds had the following contractual maturities:

[0001564590-17-015623:notes:54]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 33,486 |  |  | $ | 4,101 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,919 |  |  | $ | 825 |  |
| One to two years |  |  | 16,124 |  |  |  | 1,536 |  |  |  | 850 |  |  |  | 493 |  |  |  | — |  |  |  | 600 |  |
| Two to three years |  |  | 21,421 |  |  |  | 775 |  |  |  | 5,185 |  |  |  | — |  |  |  | 8,367 |  |  |  | 1,277 |  |
| Three to five years |  |  | 1,948 |  |  |  | 1,171 |  |  |  | 5,836 |  |  |  | 415 |  |  |  | 4,114 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 508 |  |  |  | 1,340 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 929 |  |  |  | 7,279 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 72,979 |  |  | $ | 7,583 |  |  | $ | 13,308 |  |  | $ | 9,527 |  |  | $ | 21,400 |  |  | $ | 2,702 |  |

[0001564590-17-015623:notes:55]
Actual maturities may differ from contractual maturities because some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-17-015623:notes:56]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-17-015623:notes:57]
At June 30, 2017, we held a $27.8 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $27.8 million at June 30, 2017 and December 31, 2016. At June 30, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $28.0 million, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

[0001564590-17-015623:notes:58]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and six months ended June 30, 2017 and 2016, other-than-temporary impairment charges were not significant.

[0001564590-17-015623:notes:59]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments.

[0001564590-17-015623:notes:60]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Gross realized gains |  | $ | 1,512 |  |  | $ | 1,517 |  |  | $ | 2,230 |  |  | $ | 3,881 |  |
| Gross realized losses |  | $ | (122 | ) |  | $ | (407 | ) |  | $ | (370 | ) |  | $ | (1,043 | ) |

[0001564590-17-015623:notes:61]
As of June 30, 2017 and 2016, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.

[0001564590-17-015623:notes:62]
We have categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows:  Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-17-015623:notes:63]
|  |  | Fair Value Measurements at June 30, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,487 |  |  | $ | 6,487 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 5,497 |  |  |  | — |  |  |  | 5,497 |  |  |  | — |  |
| Cash equivalents |  |  | 11,984 |  |  |  | 6,487 |  |  |  | 5,497 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 18,028 |  |  |  | 18,028 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 72,979 |  |  |  | — |  |  |  | 72,979 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 7,583 |  |  |  | — |  |  |  | 7,583 |  |  |  | — |  |
| Asset-backed bonds |  |  | 13,308 |  |  |  | — |  |  |  | 13,308 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 9,527 |  |  |  | — |  |  |  | 9,527 |  |  |  | — |  |
| U.S. government bonds |  |  | 21,400 |  |  |  | 21,400 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 2,702 |  |  |  | — |  |  |  | 2,702 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 32,965 |  |  |  | 32,965 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 178,492 |  |  |  | 72,393 |  |  |  | 106,099 |  |  |  | — |  |
| Total |  | $ | 190,476 |  |  | $ | 78,880 |  |  | $ | 111,596 |  |  | $ | — |  |

[0001564590-17-015623:notes:64]
|  |  | Fair Value Measurements at December 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,878 |  |  | $ | 6,878 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 17,222 |  |  |  | — |  |  |  | 17,222 |  |  |  | — |  |
| Cash equivalents |  |  | 24,100 |  |  |  | 6,878 |  |  |  | 17,222 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 14,596 |  |  |  | 14,596 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 66,412 |  |  |  | — |  |  |  | 66,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 11,774 |  |  |  | — |  |  |  | 11,774 |  |  |  | — |  |
| Asset-backed bonds |  |  | 10,206 |  |  |  | — |  |  |  | 10,206 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 13,004 |  |  |  | — |  |  |  | 13,004 |  |  |  | — |  |
| U.S. government bonds |  |  | 29,767 |  |  |  | 29,767 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 3,730 |  |  |  | — |  |  |  | 3,730 |  |  |  | — |  |
| Variable Rate Demand Notes |  |  | 11,855 |  |  |  | — |  |  |  | 11,855 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 29,379 |  |  |  | 29,379 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 190,723 |  |  |  | 73,742 |  |  |  | 116,981 |  |  |  | — |  |
| Total |  | $ | 214,823 |  |  | $ | 80,620 |  |  | $ | 134,203 |  |  | $ | — |  |

[0001564590-17-015623:notes:65]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-17-015623:notes:66]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-015623:notes:67]
[same as prior period, unchanged from 0001564590-17-008397:notes:66]

[0001564590-17-015623:notes:68]
[same as prior period, unchanged from 0001564590-17-008397:notes:67]

[0001564590-17-015623:notes:69]
[same as prior period, unchanged from 0001564590-17-008397:notes:68]

[0001564590-17-015623:notes:70]
[same as prior period, unchanged from 0001564590-17-008397:notes:69]

[0001564590-17-015623:notes:71]
[same as prior period, unchanged from 0001564590-17-008397:notes:70]

[0001564590-17-015623:notes:72]
[same as prior period, unchanged from 0001564590-17-008397:notes:71]

[0001564590-17-015623:notes:73]
As of June 30, 2017, we had foreign exchange forward contracts outstanding with notional amounts totaling $20.0 million (€17.5 million), which hedge a portion of projected inventory purchases expected to be settled in the third and fourth quarters of 2017. We have determined that there was no hedge ineffectiveness for the quarter ended June 30, 2017 related to these contracts.

[0001564590-17-015623:notes:74]
[same as prior period, unchanged from 0001564590-17-008397:notes:73]

[0001564590-17-015623:notes:75]
The fair values of our derivative instruments recorded in the Consolidated Balance Sheet as of June 30, 2017 and December 31, 2016 were as follows:

[0001564590-17-015623:notes:76]
| (In thousands) |  | Balance Sheet Location |  | June 30, 2017 |  |  | December 31, 2016 |  |
| Derivatives Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  | $ | 610 |  |  | $ | — |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  |  | — |  |  |  | 159 |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  |  | 352 |  |  |  | — |  |
| Total derivatives |  |  |  | $ | 962 |  |  | $ | 159 |  |

[0001564590-17-015623:notes:77]
The change in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the three and six months ended June 30, 2017 and 2016 were as follows:

[0001564590-17-015623:notes:78]
|  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Income Statement |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | Location |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | (451 | ) |  | $ | 237 |  |  | $ | (485 | ) |  | $ | 190 |  |

[0001564590-17-015623:notes:79]
The change in our derivatives designated as hedging instruments recorded in other comprehensive income (OCI) and reclassified to income during the three and six months ended June 30, 2017 and 2016 were as follows:

[0001564590-17-015623:notes:80]
|  |  | Amount of Gains (Losses) Recognized in |  |  |  |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  |  |  | from AOCI into Income |  |
|  |  | Three Months Ended |  |  | Location of Gains |  | Three Months Ended |  |
|  |  | June 30, |  |  | (Losses) Reclassified |  | June 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | from AOCI into Income |  | 2017 |  |  | 2016 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (571 | ) |  | $ | — |  |  | Cost of Sales |  | $ | (154 | ) |  | $ | — |  |

[0001564590-17-015623:notes:81]
|  |  | Amount of Gains (Losses) Recognized in |  |  |  |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  |  |  | from AOCI into Income |  |
|  |  | Six Months Ended |  |  | Location of Gains |  | Six Months Ended |  |
|  |  | June 30, |  |  | (Losses) Reclassified |  | June 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | from AOCI into Income |  | 2017 |  |  | 2016 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (492 | ) |  | $ | — |  |  | Cost of Sales |  | $ | (154 | ) |  | $ | — |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-17-015623:notes:82]
[same as prior period, unchanged from 0001564590-17-008397:notes:80]

[0001564590-17-015623:notes:83]
At June 30, 2017 and December 31, 2016, inventory consisted of the following:

[0001564590-17-015623:notes:84]
|  |  | June 30, |  |  | December 31, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Raw materials |  | $ | 42,218 |  |  | $ | 40,461 |  |
| Work in process |  |  | 2,443 |  |  |  | 4,003 |  |
| Finished goods |  |  | 69,334 |  |  |  | 60,653 |  |
| Total |  | $ | 113,995 |  |  | $ | 105,117 |  |

[0001564590-17-015623:notes:85]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At June 30, 2017 and December 31, 2016, raw materials reserves totaled $15.2 million and $14.6 million, respectively, and finished goods inventory reserves totaled $12.7 million and $10.6 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-17-015623:notes:86]
[same as prior period, unchanged from 0001564590-17-008397:notes:84]

[0001564590-17-015623:notes:87]
Goodwill, all of which relates to our acquisition of Bluesocket, Inc., was $3.5 million at June 30, 2017 and December 31, 2016, of which $3.1 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-17-015623:notes:88]
[same as prior period, unchanged from 0001564590-17-008397:notes:86]

[0001564590-17-015623:notes:89]
Intangible assets are included in other assets in the accompanying Consolidated Balance Sheets and include intangibles acquired in conjunction with our acquisitions of Bluesocket, Inc. on August 4, 2011, the NSN BBA business on May 4, 2012, and CommScope’s active fiber access business on September 13, 2016.

[0001564590-17-015623:notes:90]
The following table presents our intangible assets as of June 30, 2017 and December 31, 2016:

[0001564590-17-015623:notes:91]
| (In thousands) |  | June 30, 2017 |  |  | December 31, 2016 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 7,249 |  |  | $ | (3,765 | ) |  | $ | 3,484 |  |  | $ | 6,899 |  |  | $ | (3,208 | ) |  | $ | 3,691 |  |
| Developed technology |  |  | 6,650 |  |  |  | (5,609 | ) |  |  | 1,041 |  |  |  | 6,444 |  |  |  | (5,061 | ) |  |  | 1,383 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (2,196 | ) |  |  | 144 |  |  |  | 2,340 |  |  |  | (2,129 | ) |  |  | 211 |  |
| Supply agreement |  |  | 1,400 |  |  |  | (1,400 | ) |  |  | — |  |  |  | 1,400 |  |  |  | (544 | ) |  |  | 856 |  |
| License |  |  | 500 |  |  |  | (306 | ) |  |  | 194 |  |  |  | 500 |  |  |  | (113 | ) |  |  | 387 |  |
| Patent |  |  | 500 |  |  |  | (54 | ) |  |  | 446 |  |  |  | 500 |  |  |  | (20 | ) |  |  | 480 |  |
| Trade names |  |  | 370 |  |  |  | (310 | ) |  |  | 60 |  |  |  | 370 |  |  |  | (285 | ) |  |  | 85 |  |
| Non-compete |  |  | 200 |  |  |  | (70 | ) |  |  | 130 |  |  |  | 200 |  |  |  | (26 | ) |  |  | 174 |  |
| Total |  | $ | 19,209 |  |  | $ | (13,710 | ) |  | $ | 5,499 |  |  | $ | 18,653 |  |  | $ | (11,386 | ) |  | $ | 7,267 |  |

[0001564590-17-015623:notes:92]
Amortization expense, all of which relates to business acquisitions, was $1.1 million and $0.4 million for the three months ended June 30, 2017 and 2016 $1.9 million and $0.9 million for the six months ended June 30, 2017 and 2016, respectively.

[0001564590-17-015623:notes:93]
As of June 30, 2017, the estimated future amortization expense of our intangible assets is as follows:

[0001564590-17-015623:notes:94]
| (In thousands) |  | Amount |  |
| Remainder of 2017 |  | $ | 940 |  |
| 2018 |  |  | 1,195 |  |
| 2019 |  |  | 680 |  |
| 2020 |  |  | 644 |  |
| 2021 |  |  | 590 |  |
| Thereafter |  |  | 1,450 |  |
| Total |  | $ | 5,499 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-17-015623:notes:95]
[same as prior period, unchanged from 0001564590-17-008397:notes:93]

[0001564590-17-015623:notes:96]
A summary of the changes in stockholders’ equity for the six months ended June 30, 2017 is as follows:

[0001564590-17-015623:notes:97]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2016 |  | $ | 479,517 |  |
| Net income |  |  | 19,052 |  |
| Dividend payments |  |  | (8,719 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (19 | ) |
| Net unrealized gains on available-for-sale securities (net of tax) |  |  | 1,708 |  |
| Net unrealized losses on cash flow hedges |  |  | (338 | ) |
| Defined benefit plan adjustments (net of tax) |  |  | 141 |  |
| Foreign currency translation adjustment |  |  | 3,861 |  |
| Proceeds from stock option exercises |  |  | 1,722 |  |
| Purchase of treasury stock |  |  | (17,311 | ) |
| ASU 2016-09 adoption |  |  | 10 |  |
| Stock-based compensation expense |  |  | 3,739 |  |
| Balance, June 30, 2017 |  | $ | 483,363 |  |

[0001564590-17-015623:notes:98]
[same as prior period, unchanged from 0001564590-17-008397:notes:96]

[0001564590-17-015623:notes:99]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2017, we repurchased 0.9 million shares of our common stock at an average price of $20.27 per share. As of June 30, 2017, we have the authority to purchase an additional 3.6 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-17-015623:notes:100]
[same as prior period, unchanged from 0001564590-17-008397:notes:98]

[0001564590-17-015623:notes:101]
We issued 0.1 million shares of treasury stock during the six months ended June 30, 2017 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $23.02. We received proceeds totaling $1.7 million from the exercise of these stock options during the six months ended June 30, 2017.

[0001564590-17-015623:notes:102]
[same as prior period, unchanged from 0001564590-17-008397:notes:100]

[0001564590-17-015623:notes:103]
During the six months ended June 30, 2017, we paid cash dividends as follows (in thousands except per share amounts):

[0001564590-17-015623:notes:104]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 2, 2017 |  | February 16, 2017 |  | $ | 0.09 |  |  | $ | 4,369 |  |
| May 4, 2017 |  | May 18, 2017 |  | $ | 0.09 |  |  | $ | 4,350 |  |

[0001564590-17-015623:notes:105]
[same as prior period, unchanged from 0001564590-17-008397:notes:103]

[0001564590-17-015623:notes:106]
Other comprehensive income consists of unrealized gains (losses) on available-for-sale securities, unrealized gains (losses) on cash flow hedges, reclassification adjustments for amounts included in net income related to impairments of available-for-sale securities, realized gains (losses) on available-for-sale securities, realized gains (losses) on cash flow hedges, and amortization of actuarial gains (losses) related to our defined benefit plan, defined benefit plan adjustments, and foreign currency translation adjustments.

[0001564590-17-015623:notes:107]
The following tables present the changes in accumulated other comprehensive income, net of tax, by component for the three months ended June 30, 2017 and 2016:

[0001564590-17-015623:notes:108]
|  |  | Three Months Ended June 30, 2017 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,739 |  |  | $ | 79 |  |  | $ | (4,962 | ) |  | $ | (6,333 | ) |  | $ | (9,477 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,222 |  |  |  | (571 | ) |  |  | — |  |  |  | 2,619 |  |  |  | 3,270 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (849 | ) |  |  | 154 |  |  |  | 86 |  |  |  | — |  |  |  | (609 | ) |
| Net current period other comprehensive income (loss) |  |  | 373 |  |  |  | (417 | ) |  |  | 86 |  |  |  | 2,619 |  |  |  | 2,661 |  |
| Ending balance |  | $ | 2,112 |  |  | $ | (338 | ) |  | $ | (4,876 | ) |  | $ | (3,714 | ) |  | $ | (6,816 | ) |

[0001564590-17-015623:notes:109]
|  |  | Three Months Ended June 30, 2016 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,677 |  |  | $ | (3,850 | ) |  | $ | (5,778 | ) |  | $ | (7,951 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 481 |  |  |  | — |  |  |  | (601 | ) |  |  | (120 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (646 | ) |  |  | 22 |  |  |  | — |  |  |  | (624 | ) |
| Net current period other comprehensive income (loss) |  |  | (165 | ) |  |  | 22 |  |  |  | (601 | ) |  |  | (744 | ) |
| Ending balance |  | $ | 1,512 |  |  | $ | (3,828 | ) |  | $ | (6,379 | ) |  | $ | (8,695 | ) |

[0001564590-17-015623:notes:110]
The following tables present the changes in accumulated other comprehensive income, net of tax, by component for the six months ended June 30, 2017 and 2016:

[0001564590-17-015623:notes:111]
|  |  | Six Months Ended June 30, 2017 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 404 |  |  | $ | — |  |  | $ | (5,017 | ) |  | $ | (7,575 | ) |  | $ | (12,188 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 2,842 |  |  |  | (492 | ) |  |  | — |  |  |  | 3,861 |  |  |  | 6,211 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,134 | ) |  |  | 154 |  |  |  | 141 |  |  |  | — |  |  |  | (839 | ) |
| Net current period other comprehensive income (loss) |  |  | 1,708 |  |  |  | (338 | ) |  |  | 141 |  |  |  | 3,861 |  |  |  | 5,372 |  |
| Ending balance |  | $ | 2,112 |  |  | $ | (338 | ) |  | $ | (4,876 | ) |  | $ | (3,714 | ) |  | $ | (6,816 | ) |

[0001564590-17-015623:notes:112]
|  |  | Six Months Ended June 30, 2016 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,932 |  |  | $ | (3,895 | ) |  | $ | (7,006 | ) |  | $ | (8,969 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,239 |  |  |  | — |  |  |  | 627 |  |  |  | 1,866 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,659 | ) |  |  | 67 |  |  |  | — |  |  |  | (1,592 | ) |
| Net current period other comprehensive income (loss) |  |  | (420 | ) |  |  | 67 |  |  |  | 627 |  |  |  | 274 |  |
| Ending balance |  | $ | 1,512 |  |  | $ | (3,828 | ) |  | $ | (6,379 | ) |  | $ | (8,695 | ) |

[0001564590-17-015623:notes:113]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the three months ended June 30, 2017 and 2016:

[0001564590-17-015623:notes:114]
| (In thousands) |  | Three Months Ended June 30, 2017 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,393 |  |  | Net realized investment gain |
| Impairment expense |  |  | (2 | ) |  | Net realized investment gain |
| Net losses on derivatives designated as hedging instruments |  |  | (154 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (124 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,113 |  |  |  |
| Tax (expense) benefit |  |  | (504 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 609 |  |  |  |

[0001564590-17-015623:notes:115]
[same as prior period, unchanged from 0001564590-17-008397:notes:110]

[0001564590-17-015623:notes:116]
| (In thousands) |  | Three Months Ended June 30, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,354 |  |  | Net realized investment gain |
| Impairment expense |  |  | (295 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (33 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,026 |  |  |  |
| Tax (expense) benefit |  |  | (402 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 624 |  |  |  |

[0001564590-17-015623:notes:117]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the six months ended June 30, 2017 and 2016:

[0001564590-17-015623:notes:118]
| (In thousands) |  | Six Months Ended June 30, 2017 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,965 |  |  | Net realized investment gain |
| Impairment expense |  |  | (105 | ) |  | Net realized investment gain |
| Net losses on derivatives designated as hedging instruments |  |  | (154 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (204 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,502 |  |  |  |
| Tax (expense) benefit |  |  | (663 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 839 |  |  |  |

[0001564590-17-015623:notes:119]
| (In thousands) |  | Six Months Ended June 30, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 3,115 |  |  | Net realized investment gain |
| Impairment expense |  |  | (395 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (98 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 2,622 |  |  |  |
| Tax (expense) benefit |  |  | (1,030 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,592 |  |  |  |

[0001564590-17-015623:notes:120]
The following table presents the tax effects related to the change in each component of other comprehensive income for the three months ended June 30, 2017 and 2016:

[0001564590-17-015623:notes:121]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 2,003 |  |  | $ | (781 | ) |  | $ | 1,222 |  |  | $ | 789 |  |  | $ | (308 | ) |  | $ | 481 |  |
| Unrealized gains (losses) on cash flow hedges |  |  | (571 | ) |  |  | — |  |  |  | (571 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (1,391 | ) |  |  | 542 |  |  |  | (849 | ) |  |  | (1,059 | ) |  |  | 413 |  |  |  | (646 | ) |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | 154 |  |  |  | — |  |  |  | 154 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 124 |  |  |  | (38 | ) |  |  | 86 |  |  |  | 33 |  |  |  | (11 | ) |  |  | 22 |  |
| Foreign currency translation adjustment |  |  | 2,619 |  |  |  | — |  |  |  | 2,619 |  |  |  | (601 | ) |  |  | — |  |  |  | (601 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 2,938 |  |  | $ | (277 | ) |  | $ | 2,661 |  |  | $ | (838 | ) |  | $ | 94 |  |  | $ | (744 | ) |

[0001564590-17-015623:notes:122]
The following table presents the tax effects related to the change in each component of other comprehensive income for the six months ended June 30, 2017 and 2016:

[0001564590-17-015623:notes:123]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 4,659 |  |  | $ | (1,817 | ) |  | $ | 2,842 |  |  | $ | 2,031 |  |  | $ | (792 | ) |  | $ | 1,239 |  |
| Unrealized gains (losses) on cash flow hedges |  |  | (492 | ) |  |  | — |  |  |  | (492 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (1,860 | ) |  |  | 726 |  |  |  | (1,134 | ) |  |  | (2,720 | ) |  |  | 1,061 |  |  |  | (1,659 | ) |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | 154 |  |  |  | — |  |  |  | 154 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 204 |  |  |  | (63 | ) |  |  | 141 |  |  |  | 98 |  |  |  | (31 | ) |  |  | 67 |  |
| Foreign currency translation adjustment |  |  | 3,861 |  |  |  | — |  |  |  | 3,861 |  |  |  | 627 |  |  |  | — |  |  |  | 627 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 6,526 |  |  | $ | (1,154 | ) |  | $ | 5,372 |  |  | $ | 36 |  |  | $ | 238 |  |  | $ | 274 |  |


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-015623:notes:124]
[same as prior period, unchanged from 0001564590-17-008397:notes:114]

[0001564590-17-015623:notes:125]
A summary of the calculation of basic and diluted earnings per share for the three and six months ended June 30, 2017 and 2016 is as follows:

[0001564590-17-015623:notes:126]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 12,401 |  |  | $ | 10,228 |  |  | $ | 19,052 |  |  | $ | 15,242 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,036 |  |  |  | 48,831 |  |  |  | 48,232 |  |  |  | 49,026 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 279 |  |  |  | 161 |  |  |  | 348 |  |  |  | 138 |  |
| PSUs, RSUs and restricted stock |  |  | 98 |  |  |  | 56 |  |  |  | 95 |  |  |  | 54 |  |
| Weighted average number of shares – diluted |  |  | 48,413 |  |  |  | 49,048 |  |  |  | 48,675 |  |  |  | 49,218 |  |
| Net income per share – basic |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.40 |  |  | $ | 0.31 |  |
| Net income per share – diluted |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.39 |  |  | $ | 0.31 |  |

[0001564590-17-015623:notes:127]
Anti-dilutive options to purchase common stock outstanding were excluded from the above calculations. Anti-dilutive options totaled 4.1 million and 5.6 million for the three months ended June 30, 2017 and 2016, respectively, and 4.1 million and 5.8 million for the six months ended June 30, 2017 and 2016, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-015623:notes:128]
[same as prior period, unchanged from 0001564590-17-008397:notes:118]

[0001564590-17-015623:notes:129]
[same as prior period, unchanged from 0001564590-17-008397:notes:119]

[0001564590-17-015623:notes:130]
[same as prior period, unchanged from 0001564590-17-008397:notes:120]

[0001564590-17-015623:notes:131]
The following table presents information about the reported sales and gross profit of our reportable segments for the three and six months ended June 30, 2017 and 2016. We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-17-015623:notes:132]
|  |  | Three Months Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 155,543 |  |  | $ | 75,885 |  |  | $ | 138,549 |  |  | $ | 70,705 |  |
| Services & Support |  |  | 29,130 |  |  |  | 8,747 |  |  |  | 24,152 |  |  |  | 8,250 |  |
| Total |  | $ | 184,673 |  |  | $ | 84,632 |  |  | $ | 162,701 |  |  | $ | 78,955 |  |

[0001564590-17-015623:notes:133]
|  |  | Six Months Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 299,140 |  |  | $ | 142,823 |  |  | $ | 262,432 |  |  | $ | 130,515 |  |
| Services & Support |  |  | 55,812 |  |  |  | 15,524 |  |  |  | 42,473 |  |  |  | 14,234 |  |
| Total |  | $ | 354,952 |  |  | $ | 158,347 |  |  | $ | 304,905 |  |  | $ | 144,749 |  |

[0001564590-17-015623:notes:134]
[same as prior period, unchanged from 0001564590-17-008397:notes:123]

[0001564590-17-015623:notes:135]
[same as prior period, unchanged from 0001564590-17-008397:notes:124]

[0001564590-17-015623:notes:136]
The table below presents sales information by category for the three and six months ended June 30, 2017 and 2016:

[0001564590-17-015623:notes:137]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Access & Aggregation |  | $ | 138,639 |  |  | $ | 102,232 |  |  | $ | 258,782 |  |  | $ | 196,087 |  |
| Customer Devices |  |  | 33,833 |  |  |  | 40,876 |  |  |  | 70,101 |  |  |  | 73,229 |  |
| Traditional & Other Products |  |  | 12,201 |  |  |  | 19,593 |  |  |  | 26,069 |  |  |  | 35,589 |  |
| Total |  | $ | 184,673 |  |  | $ | 162,701 |  |  | $ | 354,952 |  |  | $ | 304,905 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-17-015623:notes:138]
[same as prior period, unchanged from 0001564590-17-008397:notes:127]

[0001564590-17-015623:notes:139]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $9.2 million and $8.5 million at June 30, 2017 and December 31, 2016, respectively. During the three months ended March 31, 2017, we recorded a receivable and a reduction in warranty expense related to a settlement with a third party supplier for a defective component, the impact of which is reflected in the table below. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0001564590-17-015623:notes:140]
A summary of warranty expense and write-off activity for the three and six months ended June 30, 2017 and 2016 is as follows:

[0001564590-17-015623:notes:141]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 8,988 |  |  | $ | 9,042 |  |  | $ | 8,548 |  |  | $ | 8,739 |  |
| Plus: Amounts charged to cost and expenses |  |  | 3,055 |  |  |  | 1,431 |  |  |  | 2,314 |  |  |  | 2,329 |  |
| Less: Deductions |  |  | (2,863 | ) |  |  | (1,538 | ) |  |  | (1,682 | ) |  |  | (2,133 | ) |
| Balance at end of period |  | $ | 9,180 |  |  | $ | 8,935 |  |  | $ | 9,180 |  |  | $ | 8,935 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-015623:notes:142]
14. COMMITMENTS AND CONTINGENCIES

[0001564590-17-015623:notes:143]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-17-015623:notes:144]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2017, of which $7.7 million has been applied to these commitments.


## us-gaap:SubsequentEventsTextBlock

[0001564590-17-015623:notes:145]
15. SUBSEQUENT EVENTS

[0001564590-17-015623:notes:146]
On July 18, 2017, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on August 3, 2017. The payment date will be August 17, 2017. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
