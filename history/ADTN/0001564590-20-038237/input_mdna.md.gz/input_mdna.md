# ADTN MD&A — 0001564590-20-038237


## mdna

[0001564590-20-038237:mdna:1]
[same as prior period, unchanged from 0001564590-20-023537:mdna:1]

[0001564590-20-038237:mdna:2]
[same as prior period, unchanged from 0001564590-20-023537:mdna:2]

[0001564590-20-038237:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our condensed consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our condensed consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 3 of this report for a description of important factors that could cause actual results to differ from expected results.  See also Part I, Item 1A, Risk Factors, of the 2019 Form 10‑K and Part II, Item 1A, Risk Factors, of this Form 10-Q.

[0001564590-20-038237:mdna:4]
[same as prior period, unchanged from 0001564590-20-023537:mdna:4]

[0001564590-20-038237:mdna:5]
ADTRAN is a leading global provider of networking and communications solutions focused on the access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, cable/MSOs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. In order to service our customers and grow revenue, we are constantly conducting research and development of new products addressing customer needs and testing those products for the particular specifications of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have research and development facilities in strategic global locations.

[0001564590-20-038237:mdna:6]
An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek to be a high-quality and low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001564590-20-038237:mdna:7]
We ended the second quarter of 2020 with a decrease in revenue of 17.7% for the three months ended June 30, 2020 as compared to the three months ended June 30, 2019, mainly driven by the reduction in spending from a Tier-1 customer in Latin America and a slow-down in spending from a Tier-1 customer in Europe, partially offset by growth in the U.S. and the Asia Pacific region. Additionally, in the second quarter of 2020, we had two 10% revenue customers geographically diversified, with one in the U.S. and one in Europe. Our domestic revenue grew 12.2% during the three months ended June 30, 2020 compared to the same quarter in the prior year, which was driven by growth in both Tier-2 and Tier-3 carrier categories due to additional fiber access deployments in both access equipment and CPE. In Europe, our revenue was down 12.8% compared to the same quarter in the prior year, primarily driven by a slow-down in spending from a Tier-1 customer. In the Asia Pacific region, we experienced growth driven by the acceleration of access network builds. Additionally, fiber access continues to experience revenue growth, and, during the first half of 2020, we announced multiple long-term Tier-1 next-generation fiber access deals in Europe and the U.S., positioning us well for the next access network upgrade investment cycle.

[0001564590-20-038237:mdna:8]
During the first half of 2020, there was a downturn in the global financial markets followed by a gradual rebound and a slowdown in the global economy due to the COVID-19 pandemic. In March 2020, the World Health Organization declared the outbreak of COVID-19 a pandemic. COVID-19 continues to spread throughout the U.S. and the world and has resulted in authorities implementing numerous measures to contain the virus, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns. While we are unable to accurately predict the full impact that COVID-19 will have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time. We have experienced some impact to our supply chain, including a slowdown in supply chain deliveries, extended lead times on some key components and some raw material cost increases. In addition, we have experienced significant increases in freight-related costs. While throughout the pandemic, we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments, as well as COVID-19 related reductions in travel and infrastructure expenses, it is possible that we could experience some slowdown in demand and further supply chain issues as the pandemic continues.

[0001564590-20-038237:mdna:9]
Among our customers, we made progress with our fiber and fiber-extension solutions, including PON and Gfast, while also continuing to engage various Services & Support opportunities that we expect will contribute in 2020 and beyond. In addition, we believe that we are at the beginning of a significant investment cycle for fiber deployment driven by technology advancements and regulatory influences. The transition to next-generation network architectures is beginning, and we are seeing demand for our next-generation SD-Access solutions. In 2021, we anticipate that payments to service providers under government funding programs such as the FCC Rural Digital Opportunity Fund will begin.

[0001564590-20-038237:mdna:10]
[same as prior period, unchanged from 0001564590-20-023537:mdna:10]

[0001564590-20-038237:mdna:11]
[same as prior period, unchanged from 0001564590-20-023537:mdna:11]

[0001564590-20-038237:mdna:12]
[same as prior period, unchanged from 0001564590-20-023537:mdna:12]

[0001564590-20-038237:mdna:13]
[same as prior period, unchanged from 0001564590-20-023537:mdna:13]

[0001564590-20-038237:mdna:14]
[same as prior period, unchanged from 0001564590-20-023537:mdna:14]

[0001564590-20-038237:mdna:15]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that has resulted from the COVID-19 pandemic, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter. During 2019, the Company implemented restructuring plans to realign its expense structure with the reduction in revenue experienced in recent years and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and has implemented certain cost savings initiatives, where possible. We expect to continue to see a reduction in our operating expenses and cost of sales, both in the U.S. and internationally, as a result of our implementation of these restructuring plans.

[0001564590-20-038237:mdna:16]
Our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Part I, Item 1A of the 2019 Form 10-K and in Part II, Item 1A of this Form 10-Q.

[0001564590-20-038237:mdna:17]
[same as prior period, unchanged from 0001564590-20-023537:mdna:17]

[0001564590-20-038237:mdna:18]
[same as prior period, unchanged from 0001564590-20-023537:mdna:18]

[0001564590-20-038237:mdna:19]
[same as prior period, unchanged from 0001564590-20-023537:mdna:19]

[0001564590-20-038237:mdna:20]
[same as prior period, unchanged from 0001564590-20-023537:mdna:20]

[0001564590-20-038237:mdna:21]
39

[0001564590-20-038237:mdna:22]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2020 COMPARED TO THREE AND SIX MONTHS ENDED JUNE 30, 2019

[0001564590-20-038237:mdna:23]
[same as prior period, unchanged from 0001564590-20-023537:mdna:22]

[0001564590-20-038237:mdna:24]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 86.5 |  | % |  | 89.0 |  | % |  | 85.8 |  | % |  | 88.3 |  | % |
| Services & Support |  |  | 13.5 |  |  |  | 11.0 |  |  |  | 14.2 |  |  |  | 11.7 |  |  |
| Total Sales |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 49.8 |  |  |  | 51.3 |  |  |  | 47.6 |  |  |  | 50.3 |  |  |
| Services & Support |  |  | 8.7 |  |  |  | 7.2 |  |  |  | 9.2 |  |  |  | 7.9 |  |  |
| Total Cost of Sales |  |  | 58.5 |  |  |  | 58.4 |  |  |  | 56.8 |  |  |  | 58.1 |  |  |
| Gross Profit |  |  | 41.5 |  |  |  | 41.6 |  |  |  | 43.2 |  |  |  | 41.9 |  |  |
| Selling, general and administrative expenses |  |  | 23.9 |  |  |  | 21.5 |  |  |  | 23.6 |  |  |  | 22.9 |  |  |
| Research and development expenses |  |  | 22.3 |  |  |  | 20.5 |  |  |  | 24.1 |  |  |  | 21.2 |  |  |
| Gain on contingency |  |  | — |  |  |  | (0.8 | ) |  |  | — |  |  |  | (0.4 | ) |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Operating Income (Loss) |  |  | (4.7 | ) |  |  | 0.4 |  |  |  | (4.5 | ) |  |  | (1.9 | ) |  |
| Interest and dividend income |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 0.3 |  |  |  | 0.4 |  |  |
| Interest expense |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |  |
| Net investment gain (loss) |  |  | 7.7 |  |  |  | 1.6 |  |  |  | (0.4 | ) |  |  | 2.8 |  |  |
| Other income (expense), net |  |  | (1.4 | ) |  |  | (0.1 | ) |  |  | (0.3 | ) |  |  | 0.2 |  |  |
| Income (Loss) Before Income Taxes |  |  | 1.9 |  |  |  | 2.2 |  |  |  | (4.9 | ) |  |  | 1.5 |  |  |
| Income tax (expense) benefit |  |  | (1.3 | ) |  |  | 0.4 |  |  |  | 1.1 |  |  |  | 0.1 |  |  |
| Net Income (Loss) |  |  | 0.6 |  | % |  | 2.6 |  | % |  | (3.8 | ) | % |  | 1.6 |  | % |

[0001564590-20-038237:mdna:25]
[same as prior period, unchanged from 0001564590-20-023537:mdna:24]

[0001564590-20-038237:mdna:26]
Our sales decreased 17.7% from $156.4 million for the three months ended June 30, 2019 to $128.7 million for the three months ended June 30, 2020 and decreased 19.0% from $300.2 million for the six months ended June 30, 2019 to $243.2 million for the six months ended June 30, 2020. The decrease in sales for the three and six months ended June 30, 2020 was primarily attributable to a $26.6 million and $60.5 million decrease in Access & Aggregation sales, respectively, and a $0.9 million and $1.8 million decrease in the sales of our Traditional & Other Products, respectively. Additionally, there was a $0.1 million decrease in Subscriber Solutions & Experience sales for the three months ended June 30, 2020 and a $5.3 million increase in Subscriber Solutions & Experience sales for the six months ended June 30, 2020.

[0001564590-20-038237:mdna:27]
Network Solutions segment sales decreased 20.0% from $139.2 million for the three months ended June 30, 2019 to $111.3 million for the three months ended June 30, 2020 and decreased 21.2% from $265.0 million for the six months ended June 30, 2019 to $208.7 million for the six months ended June 30, 2020. The decrease in sales for the three and six months ended June 30, 2020 was primarily attributable to the slowdown in shipments to two Tier-1 customers. For the three months ended June 30, 2020, sales in the Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products categories decreased. For the six months ended June 30, 2020, sales in the Access & Aggregation and Traditional & Other Products categories decreased and were partially offset by an increase in Subscriber Solutions & Experience category sales. The decrease in Access & Aggregation sales for the three and six months ended June 30, 2020 was primarily attributable to decreased volume in sales of FTTN products.  The decrease in Subscriber Solutions & Experience sales for the three months ended June 30, 2020 was primarily attributable to a decreased volume of SP Business CPE and WiFi access points and infrastructure sales. The increase in Subscriber Solutions & Experience sales for the six months ended June 30, 2020 was primarily attributable to increased volume in sales of SP Business CPE, network termination and fiber CPE. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-20-038237:mdna:28]
Services & Support segment sales increased 1.0% from $17.2 million for the three months ended June 30, 2019 to $17.4 million for the three months ended June 30, 2020 and decreased 1.8% from $35.2 million for the six months ended June 30, 2019 to $34.5 million for the six months ended June 30, 2020. The increase in sales for the three months ended June 30, 2020 was primarily attributable to increased volume of maintenance services for Subscriber Solutions & Experience products. The decrease in sales for the six months ended June 30, 2019 was primarily attributable to decreased volume of maintenance services for Access & Aggregation products.

[0001564590-20-038237:mdna:29]
International sales, which are included in the amounts for both the Network Solutions and Services & Support segments discussed above, decreased 45.4% from $81.1 million for the three months ended June 30, 2019 to $44.3 million for the three months ended June 30, 2020 and decreased 47.6% from $152.4 million for the six months ended June 30, 2019 to $79.8 million for the six months ended June 30, 2020. International sales, as a percentage of total sales, decreased from 51.9% for the three months ended June 30, 2019 to 34.4% for the three months ended June 30, 2020 and decreased from 50.8% for the six months ended June 30, 2019 to 32.8% for the six months ended June 30, 2020. The decrease in sales for the three and six months ended June 30, 2020, was primarily attributable the reduction in shipments to two international Tier-1 customers.

[0001564590-20-038237:mdna:30]
[same as prior period, unchanged from 0001564590-20-023537:mdna:29]

[0001564590-20-038237:mdna:31]
[same as prior period, unchanged from 0001564590-20-023537:mdna:30]

[0001564590-20-038237:mdna:32]
As a percentage of sales, cost of sales increased slightly from 58.4% for the three months ended June 30, 2019 to 58.5% for the three months ended June 30, 2020 and decreased from 58.2% for the six months ended June 30, 2019 to 56.8% for the six months ended June 30, 2020. For the six months ended June 30, 2020, the decrease was primarily attributable to changes in customer and product mix, a regional revenue shift, changes in services and support mix and a decrease in fixed personnel costs as a result of our restructuring program initiated in 2019.

[0001564590-20-038237:mdna:33]
Network Solutions cost of sales, as a percentage of that segment’s sales, remained flat at 57.6% for the three months ended June 30, 2020 and 2019 and decreased from 57.0% for the six months ended June 30, 2019 to 55.4% for the six months ended June 30, 2020. The decrease in cost of sales as a percentage of sales for the six months ended June 30, 2020 was primarily attributable to changes in customer and product mix, a regional revenue shift and a decrease in fixed personnel costs as a result of our restructuring program initiated in 2019.

[0001564590-20-038237:mdna:34]
[same as prior period, unchanged from 0001564590-20-023537:mdna:33]

[0001564590-20-038237:mdna:35]
Services & Support cost of sales, as a percentage of that segment’s sales, decreased from 65.0% for the three months ended June 30, 2019 to 64.2% for the three months ended June 30, 2020 and decreased from 67.2% for the six months ended June 30, 2019 to 65.0% for the six months ended June 30, 2020. The decrease in cost of sales as a percentage of sales for the three and six months ended June 30, 2020 was primarily attributable to customer mix, changes in services and support mix and a decrease in fixed personnel costs as a result of our restructuring program initiated in 2019.

[0001564590-20-038237:mdna:36]
[same as prior period, unchanged from 0001564590-20-023537:mdna:35]

[0001564590-20-038237:mdna:37]
As our network planning and implementation revenue grew to become the largest component of our Services & Support segment business, our Services & Support segment gross margins decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support segment revenue comprising a larger percentage of our overall revenue, and because our Services & Support segment gross margins are generally below those of the Network Solutions segment, our overall corporate gross margins have declined as that business has continued to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter to quarter based on the mix of the services recognized.

[0001564590-20-038237:mdna:38]
[same as prior period, unchanged from 0001564590-20-023537:mdna:37]

[0001564590-20-038237:mdna:39]
As a percentage of sales, selling, general and administrative expenses increased from 21.5% for the three months ended June 30, 2019 to 23.9% for the three months ended June 30, 2020 and increased from 22.9% for the six months ended June 30, 2019 to 23.6% for the six months ended June 30, 2020. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0001564590-20-038237:mdna:40]
Selling, general and administrative expenses decreased 8.4% from $33.6 million for the three months ended June 30, 2019 to $30.8 million for the three months ended June 30, 2020 and decreased 16.5% from $68.8 million for the six months ended June 30, 2019 to $57.4 million for the six months ended June 30, 2020. The decrease in selling, general and administrative expenses for the three months ended June 30, 2020 was primarily attributable to lower travel-related expenses and lower labor expense partially due to our restructuring program initiated in 2019, partially offset by increases in costs for deferred compensation and contract services related to an enterprise resource planning implementation project. The decrease in selling, general and administrative expenses for the six months ended June 30, 2020 was primarily attributable to lower labor expense partially due to our restructuring program initiated in 2019, lower deferred compensation costs and reduced travel-related expenses, partially offset by increased contract services related to an enterprise resource planning implementation project.

[0001564590-20-038237:mdna:41]
[same as prior period, unchanged from 0001564590-20-023537:mdna:40]

[0001564590-20-038237:mdna:42]
As a percentage of sales, research and development expenses increased from 20.5% for the three months ended June 30, 2019 to 22.3% for the three months ended June 30, 2020 and increased from 21.2% for the six months ended June 30, 2019 to 24.1% for the six months ended June 30, 2020. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0001564590-20-038237:mdna:43]
Research and development expenses decreased 10.5% from $32.1 million for the three months ended June 30, 2019 to $28.7 million for the three months ended June 30, 2020 and decreased 8.1% from $63.7 million for the six months ended June 30, 2019 to $58.6 million for the six months ended June 30, 2020. The decrease in research and development expenses for the three and six months ended June 30, 2020 was primarily attributable to lower labor expense and other expenses which were mainly the result of our restructuring program initiated in 2019, partially offset by increased contract services costs.

[0001564590-20-038237:mdna:44]
We expect to continue to incur research and development expenses in connection with our new and existing products. We continually evaluate new product opportunities and engage in significant research and product development efforts, which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0001564590-20-038237:mdna:45]
GAIN ON CONTINGENCY

[0001564590-20-038237:mdna:46]
Gain on contingency, which was $1.2 million for the three and six months ended June 30, 2019, relates to the reversal of unearned contingent liabilities which were initially recognized upon the acquisition of SmartRG in the fourth quarter of 2018. There was no gain on contingency recognized during the six months ended June 30, 2020.

[0001564590-20-038237:mdna:47]
[same as prior period, unchanged from 0001564590-20-023537:mdna:44]

[0001564590-20-038237:mdna:48]
Asset impairments, which were $0.1 million for the six months ended June 30, 2020, relate to the abandonment of certain information technology projects in which we had previously capitalized costs. There were no asset impairments recognized during the six months ended June 30, 2019.

[0001564590-20-038237:mdna:49]
[same as prior period, unchanged from 0001564590-20-023537:mdna:46]

[0001564590-20-038237:mdna:50]
Interest and dividend income decreased 52.2% from $0.7 million for the three months ended June 30, 2019 to $0.3 million for the three months ended June 30, 2020 and decreased 46.5% from $1.3 million for the six months ended June 30, 2019 to $0.7 million for the six months ended June 30, 2020. The decrease in interest and dividend income was primarily attributable to a decrease in interest income as a result of a decline in our investment balances mainly due to the maturity of our certificate of deposit which served as collateral for our taxable revenue bonds. Our total investments decreased from $118.2 million as of June 30, 2019 to $93.4 million as of June 30, 2020.

[0001564590-20-038237:mdna:51]
[same as prior period, unchanged from 0001564590-20-023537:mdna:48]

[0001564590-20-038237:mdna:52]
Interest expense, which is primarily related to our taxable revenue bonds, decreased by $0.1 million in the three months ended June 30, 2020 compared to the three months ended June 30, 2019 and decreased by $0.3 million in the six months ended June 30, 2020 compared to the six months ended June 30, 2019. The decrease was due to the fact that the outstanding principal balance of the taxable revenue bonds was paid off upon maturity in January 2020. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-20-038237:mdna:53]
[same as prior period, unchanged from 0001564590-20-023537:mdna:50]

[0001564590-20-038237:mdna:54]
We recognized a net investment gain of $2.5 million and $9.9 million for the three months ended June 30, 2019 and June 30, 2020, respectively, a net investment gain of $8.4 million for the six months ended June 30, 2019 and a net investment loss of $1.0 million for the six months ended June 30, 2020. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. During the six months ended June 30, 2020, our investments were impacted by market conditions due to the COVID-19 pandemic, which resulted in a sharp downturn in the markets followed by a gradual rebound. We expect that any future market volatility, whether from COVID-19 or other factors, will result in continued volatility in our investment portfolio. See Note 7 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-20-038237:mdna:55]
OTHER INCOME (EXPENSE), NET

[0001564590-20-038237:mdna:56]
Other income (expense), net increased from expense of $0.2 million for the three months ended June 30, 2019 to expense of $1.8 million for the three months ended June 30, 2020 and decreased from income of $0.7 million for the six months ended June 30, 2019 to expense of $0.6 million for the six months ended June 30, 2020. For the three and six months ended June 30, 2020, other income, net consisted mainly of gains and losses on foreign currency transactions. For the three and six months ended June 30, 2019, other income, net consisted mainly of the receipt of insurance proceeds from a life insurance policy.

[0001564590-20-038237:mdna:57]
[same as prior period, unchanged from 0001564590-20-023537:mdna:54]

[0001564590-20-038237:mdna:58]
Our effective tax rate increased from a benefit of 17.3% for the three months ended June 30, 2019 to an expense of 68.5% for the three months ended June 30, 2020 and decreased from a benefit of 6.2% for the six months ended June 30, 2019 to a benefit of 22.9% for the six months ended June 30, 2020. The change in the effective tax rate for the three months ended June 30, 2020 was impacted by tax expense in our international operations and additional changes in the valuation allowance related to our domestic operations. The change in the effective tax rate for the six months ended June 30, 2020 was primarily driven by the impact recorded in the quarter ending March 31, 2020 from the Coronavirus Aid, Relief, and Economic Security (the “CARES Act”) Act signed into law on March 27, 2020, partially offset by tax expense in our international operations and changes in our valuation allowance related to our domestic operations. The change in the effective tax rate for the three and six months ended June 30, 2019 was primarily driven by the shift to profitability for the three and six months ended June 30, 2019, with tax expense being offset by a 29.1% rate reduction related to a transfer pricing study completed during the second quarter of 2019 that resulted in the assignment of operating expenditures to specific Company locations, and the effective income tax rates among the respective jurisdictions. See Note 4 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001564590-20-038237:mdna:59]
[same as prior period, unchanged from 0001564590-20-023537:mdna:56]

[0001564590-20-038237:mdna:60]
As a result of the above factors, net income (loss) decreased from net income of $4.0 million for the three months ended June 30, 2019 to net income of $0.8 million for the three months ended June 30, 2020, and decreased from net income of $4.8 million for the six months ended June 30, 2019 to a net loss of $9.2 million for the six months ended June 30, 2020.

[0001564590-20-038237:mdna:61]
[same as prior period, unchanged from 0001564590-20-023537:mdna:58]

[0001564590-20-038237:mdna:62]
[same as prior period, unchanged from 0001564590-20-023537:mdna:59]

[0001564590-20-038237:mdna:63]
We have historically financed, and we currently expect to continue to finance, our ongoing business with existing cash, investments and cash flow from operations. We have used, and expect to continue to use, existing cash, investments and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expansion of our sales and marketing activities and capital expenditures. We believe that our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-20-038237:mdna:64]
As of June 30, 2020, cash on hand was $69.1 million and short-term investments were $9.0 million, which resulted in available short-term liquidity of $78.1 million, of which $50.0 million was held by our foreign subsidiaries. As of December 31, 2019, cash on hand was $73.8 million and short-term investments were $33.2 million, which resulted in available short-term liquidity of $107.0 million, of which $52.3 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax. The decrease in short-term liquidity from December 31, 2019 to June 30, 2020 was primarily attributable to the maturity of a certificate of deposit of $25.6 million that served as collateral for our revenue bond, which matured in January 2020.

[0001564590-20-038237:mdna:65]
[same as prior period, unchanged from 0001564590-20-023537:mdna:62]

[0001564590-20-038237:mdna:66]
Our working capital, defined as current assets less current liabilities, remained flat at $207.6 million as of December 31, 2019 and $207.7 million as of June 30, 2020, and our current ratio, defined as current assets divided by current liabilities, increased from 2.84 as of December 31, 2019 to 2.94 as of June 30, 2020. The increase in our current ratio was primarily attributable to increases in other receivables, accounts payable, inventory and accounts receivable, partially offset by short-term investments, which consisted of a certificate of deposit related to our taxable revenue bond and the related bonds payable. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 1.75 as of December 31, 2019 to 1.62 as of June 30, 2020. The decrease in the quick ratio was primarily attributable to the payment of our bond payable upon maturity in January 2020, partially offset by a decrease in accounts receivable and cash and cash equivalents along with an increase in accounts payable.

[0001564590-20-038237:mdna:67]
Net accounts receivable increased 5.3% from $90.5 million as of December 31, 2019 to $95.3 million as of June 30, 2020. Our allowance for doubtful accounts was $38 thousand as of December 31, 2019 and June 30, 2020. The increase in net accounts receivable was due to an increase in sales volume in the second quarter of 2020 as compared to the fourth quarter of 2019. Quarterly accounts receivable DSO decreased from 72 days as of December 31, 2019 to 67 days as of June 30, 2020. The decrease in DSO was due to the timing of product shipments and customer mix.

[0001564590-20-038237:mdna:68]
Other receivables increased 57.1% from $16.6 million as of December 31, 2019 to $26.0 million as of June 30, 2020. The increase in other receivables was primarily attributable to increases in income tax receivables related to the CARES Act and purchasing shipments partially offset by a decrease in contract assets.

[0001564590-20-038237:mdna:69]
Quarterly inventory turnover increased from 2.7 turns as of December 31, 2019 to 2.9 turns as of June 30, 2020. Inventory increased 8.0% from $98.3 million as of December 31, 2019 to $106.1 million as of June 30, 2020. In addition to COVID-19 uncertainties related to supply chain and demand, we expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business and ensuring competitive lead times while managing the risk of inventory.

[0001564590-20-038237:mdna:70]
Accounts payable increased 39.2% from $44.9 million as of December 31, 2019 to $62.5 million as of June 30, 2020. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-20-038237:mdna:71]
[same as prior period, unchanged from 0001564590-20-023537:mdna:68]

[0001564590-20-038237:mdna:72]
Capital expenditures totaled approximately $3.1 million and $4.3 million for the six months ended June 30, 2020 and 2019, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and to finance building improvements.

[0001564590-20-038237:mdna:73]
Our combined short-term and long-term investments decreased $34.3 million from $127.7 million as of December 31, 2019 to $93.4 million as of June 30, 2020. This decrease reflects the maturity of a certificate deposit which served as collateral for our revenue bond and the impact of net realized and unrealized gains and losses on our investments.

[0001564590-20-038237:mdna:74]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 7 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information. As of June 30, 2020, our corporate bonds, municipal bonds, asset-backed bonds, mortgage/agency bonds, U.S. government bonds, other government bonds and variable-rate demand notes were classified as available-for-sale and had a combined duration of 1.54 years with an average Standard & Poor’s credit rating of AA. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-20-038237:mdna:75]
Our long-term investments decreased 10.7% from $94.5 million as of December 31, 2019 to $84.4 million as of June 30, 2020.  Our investments include various marketable equity securities classified as long-term investments with a fair market value of $26.1 million and $35.8 million as of June 30, 2020 and December 31, 2019, respectively. Long-term investments as of June 30, 2020 and December 31, 2019 also included $20.5 million and $21.7 million, respectively, related to our deferred compensation plans, and $0.3 million, for both years, of other investments, consisting of interests in a private equity fund.

[0001564590-20-038237:mdna:76]
[same as prior period, unchanged from 0001564590-20-023537:mdna:73]

[0001564590-20-038237:mdna:77]
[same as prior period, unchanged from 0001564590-20-023537:mdna:74]

[0001564590-20-038237:mdna:78]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the six months ended June 30, 2020 and 2019, we paid dividends totaling $8.7 million and $8.6 million, respectively. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0001564590-20-038237:mdna:79]
[same as prior period, unchanged from 0001564590-20-023537:mdna:76]

[0001564590-20-038237:mdna:80]
In conjunction with the 1995 expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, in January 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of these taxable revenue bonds to the Company. Further advances on the taxable revenue bonds were made by the Authority, bringing the total amount outstanding to $50.0 million. The bonds matured on January 1, 2020, and the outstanding balance of $24.6 million was repaid in full on January 2, 2020. The Company had no outstanding debt as of June 30, 2020.

[0001564590-20-038237:mdna:81]
[same as prior period, unchanged from 0001564590-20-023537:mdna:78]

[0001564590-20-038237:mdna:82]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized repurchases of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. We currently have authorization to repurchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares. During the six months ended June 30, 2020 there were no common stock repurchases. During the six months ended June 30, 2019, we repurchased 13,000 shares of our common stock for $0.2 million at an average price of $14.06 per share.

[0001564590-20-038237:mdna:83]
[same as prior period, unchanged from 0001564590-20-023537:mdna:80]

[0001564590-20-038237:mdna:84]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0001564590-20-038237:mdna:85]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2020 and December 31, 2019, we had commitments related to these bonds totaling $11.3 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001564590-20-038237:mdna:86]
In June of 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a customer. The letter of credit is secured by a pledge of collateral in the amount of $5.0 million, of which $1.2 million is included in restricted cash and $3.8 million is included in long-term investments on the Condensed Consolidated Balance Sheet as of June 30, 2020. Currently, the Company is required to maintain a minimum collateral value of approximately $5.0 million. The minimum collateral value will increase over time as the Company reaches certain milestones in the contract. The maximum collateral value required under the contract will be approximately $12.0 million, and this is expected to occur in February 2021. This minimum collateral value will increase further if the Company changes the mix of investments away from restricted cash and into other investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments or long-term investments. The obligations under the customer contract will be performed over multiple years. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of June 30, 2020, the Company was in compliance with all contractual requirements under the letter of credit.

[0001564590-20-038237:mdna:87]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund of which $4.9 million has been contributed as of June 30, 2020.

[0001564590-20-038237:mdna:88]
During the six months ended June 30, 2020, there have been no other material changes in contractual obligations and commercial commitments out of the normal course of business from those discussed in the 2019 Form 10-K.

[0001564590-20-038237:mdna:89]
46
