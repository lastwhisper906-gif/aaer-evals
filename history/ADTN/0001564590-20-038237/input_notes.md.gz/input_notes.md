# ADTN notes — 0001564590-20-038237


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-20-038237:notes:1]
[same as prior period, unchanged from 0001564590-20-023537:notes:1]

[0001564590-20-038237:notes:2]
[same as prior period, unchanged from 0001564590-20-023537:notes:2]

[0001564590-20-038237:notes:3]
[same as prior period, unchanged from 0001564590-20-023537:notes:3]

[0001564590-20-038237:notes:4]
[same as prior period, unchanged from 0001564590-20-023537:notes:4]

[0001564590-20-038237:notes:5]
[same as prior period, unchanged from 0001564590-20-023537:notes:5]

[0001564590-20-038237:notes:6]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multi-element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-20-038237:notes:7]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of June 30, 2020 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, current estimated credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the quarter ended June 30, 2020 resulting from these assessments, future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

[0001564590-20-038237:notes:8]
[same as prior period, unchanged from 0001564590-20-023537:notes:8]

[0001564590-20-038237:notes:9]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company corrected this misstatement in the Unaudited Condensed Consolidated Statement of Cash Flows for the six months ended June 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management determined that these misstatements were not material to any of its previously issued financial statements on both a quantitative and qualitative basis.

[0001564590-20-038237:notes:10]
During the first quarter of 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out-of-period adjustment in the three months ended March 31, 2020 by remeasuring the investment assets to their historical cost basis through the recording of a net investment gain of $1.5 million in the unaudited Condensed Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the long-term investment balance at its remeasured cost basis of $2.8 million to treasury stock in the unaudited Condensed Consolidated Balance Sheet as of March 31, 2020. Management has determined that this misstatement was not material to any of its previously issued financial statements and that correction of the misstatement is also not expected to be material to the 2020 annual financial results on either a quantitative or qualitative basis.

[0001564590-20-038237:notes:11]
Recently Adopted Accounting Pronouncements

[0001564590-20-038237:notes:12]
[same as prior period, unchanged from 0001564590-20-023537:notes:12]

[0001564590-20-038237:notes:13]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, which clarifies that receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the standard for leases. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification Improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as providing disclosure relief for accrued interest receivables. All of these ASUs were codified as part of ASC Topic 326 and were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard on January 1, 2020, using a modified-retrospective approach and, therefore, elected to carry forward legacy disclosures for comparative periods and did not adjust the comparative period financial information. Additionally, the Company made an accounting policy election, at the class of financing receivable, not to measure the allowance for credit losses for accrued interest receivables, as the Company writes off the uncollectable accrued interest receivable by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable). The adoption of this standard did not have a material effect on our consolidated financial statements. See Note 19 for additional information.

[0001564590-20-038237:notes:14]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities are required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 was effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019. The Company adopted ASU 2017-04 on January 1, 2020, and the amendments were applied prospectively. The adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-20-038237:notes:15]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. The Company adopted ASU 2018-13 on January 1, 2020, and the adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-20-038237:notes:16]
In August 2018, the FASB issued ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. The Company adopted ASU 2018-15 on January 1, 2020, retrospectively. The adoption of this standard resulted in a reclassification of $5.6 million from property, plant and equipment to other assets for certain previously capitalized costs related to information technology implementation projects that had not yet been placed in service on the Condensed Consolidated Balance Sheets as of June 30, 2020 and December 31, 2019. There was no impact to previously reported net cash provided by (used in) operations on the statement of cash flows and no impact to the statements of income (loss) as no portion of the capitalized asset was depreciated in prior periods.

[0001564590-20-038237:notes:17]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Balance Sheet as of December 31, 2019:

[0001564590-20-038237:notes:18]
[same as prior period, unchanged from 0001564590-20-023537:notes:18]

[0001564590-20-038237:notes:19]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Statement of Income for the three and six months ended June 30, 2019 and the Condensed Consolidated Statement of Cash Flows for six months ended June 30, 2019:

[0001564590-20-038237:notes:20]
|  |  | Three months ended June 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Income (Loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,995 |  |  | $ | — |  |  | $ | 3,995 |  |

[0001564590-20-038237:notes:21]
|  |  | Six months ended June 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Income (Loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 4,765 |  |  | $ | — |  |  | $ | 4,765 |  |
| Condensed Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 11,007 |  |  | $ | — |  |  | $ | 11,007 |  |

[0001564590-20-038237:notes:22]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which will be applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss), that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.

[0001564590-20-038237:notes:23]
[same as prior period, unchanged from 0001564590-20-023537:notes:21]

[0001564590-20-038237:notes:24]
In August 2018, the FASB issued ASU 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. The Company is currently evaluating the impact this guidance will have on its related disclosures.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001564590-20-038237:notes:25]
2. CASH, CASH EQUIVALENTS AND RESTRICTED CASH

[0001564590-20-038237:notes:26]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the consolidated balance sheet that sum to the total of the same such amounts shown in the consolidated statement of cash flows:

[0001564590-20-038237:notes:27]
| (In thousands) |  | June 30, 2020 |  |
| Cash and cash equivalents |  | $ | 69,059 |  |
| Restricted cash |  |  | 1,186 |  |
| Cash, cash equivalents and restricted cash |  | $ | 70,245 |  |

[0001564590-20-038237:notes:28]
The Company did not have any restricted cash as of June 30, 2019.

[0001564590-20-038237:notes:29]
See Note 18 for additional information regarding restricted cash.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-038237:notes:30]
3. REVENUE

[0001564590-20-038237:notes:31]
[same as prior period, unchanged from 0001564590-20-023537:notes:25]

[0001564590-20-038237:notes:32]
[same as prior period, unchanged from 0001564590-20-023537:notes:26]

[0001564590-20-038237:notes:33]
[same as prior period, unchanged from 0001564590-20-023537:notes:27]

[0001564590-20-038237:notes:34]
[same as prior period, unchanged from 0001564590-20-023537:notes:29]

[0001564590-20-038237:notes:35]
In addition to our reportable segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

[0001564590-20-038237:notes:36]
The following tables disaggregate revenue by reportable segment and revenue category for the three and six months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:37]
|  |  | Three Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,721 |  |  | $ | 13,055 |  |  | $ | 82,776 |  |  | $ | 96,262 |  |  | $ | 13,159 |  |  | $ | 109,421 |  |
| Subscriber Solutions & Experience |  |  | 38,081 |  |  |  | 2,312 |  |  |  | 40,393 |  |  |  | 38,444 |  |  |  | 2,058 |  |  |  | 40,502 |  |
| Traditional & Other Products |  |  | 3,521 |  |  |  | 2,025 |  |  |  | 5,546 |  |  |  | 4,461 |  |  |  | 2,007 |  |  |  | 6,468 |  |
| Total |  | $ | 111,323 |  |  | $ | 17,392 |  |  | $ | 128,715 |  |  | $ | 139,167 |  |  | $ | 17,224 |  |  | $ | 156,391 |  |

[0001564590-20-038237:notes:38]
|  |  | Six Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 122,776 |  |  | $ | 25,966 |  |  | $ | 148,742 |  |  | $ | 181,935 |  |  | $ | 27,264 |  |  | $ | 209,199 |  |
| Subscriber Solutions & Experience |  |  | 78,064 |  |  |  | 4,508 |  |  |  | 82,572 |  |  |  | 73,163 |  |  |  | 4,092 |  |  |  | 77,255 |  |
| Traditional & Other Products |  |  | 7,855 |  |  |  | 4,069 |  |  |  | 11,924 |  |  |  | 9,891 |  |  |  | 3,837 |  |  |  | 13,728 |  |
| Total |  | $ | 208,695 |  |  | $ | 34,543 |  |  | $ | 243,238 |  |  | $ | 264,989 |  |  | $ | 35,193 |  |  | $ | 300,182 |  |

[0001564590-20-038237:notes:39]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration of greater than one year. As of June 30, 2020, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $16.0 million and $13.6 million as of June 30, 2020 and December 31, 2019, respectively. The Company expects to recognize 62% of the $16.0 million as of June 30, 2020 over the next 12 months, with the remainder to be recognized thereafter.

[0001564590-20-038237:notes:40]
[same as prior period, unchanged from 0001564590-20-023537:notes:34]

[0001564590-20-038237:notes:41]
| (In thousands) |  | June 30, 2020 |  |  | December 31, 2019 |  |
| Accounts receivable, net |  | $ | 95,335 |  |  | $ | 90,531 |  |
| Contract assets(1) |  | $ | 1,028 |  |  | $ | 2,812 |  |
| Unearned revenue |  | $ | 12,090 |  |  | $ | 11,963 |  |
| Non-current unearned revenue |  | $ | 6,166 |  |  | $ | 6,012 |  |

[0001564590-20-038237:notes:42]
[same as prior period, unchanged from 0001564590-20-023537:notes:36]

[0001564590-20-038237:notes:43]
Of the outstanding unearned revenue balances as of December 31, 2019 and December 31, 2018, $2.4 million and $3.6 million were recognized as revenue during the three months ended June 30, 2020 and 2019, respectively, and $8.1 million and $10.5 million were recognized as revenue during the six months ended June 30, 2020 and 2019, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-20-038237:notes:44]
The table below presents sales information by category for the three and six months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Access & Aggregation |  | $ | 82,776 |  |  | $ | 109,421 |  |  | $ | 148,742 |  |  | $ | 209,199 |  |
| Subscriber Solutions & Experience |  |  | 40,393 |  |  |  | 40,502 |  |  |  | 82,572 |  |  |  | 77,255 |  |
| Traditional & Other Products |  |  | 5,546 |  |  |  | 6,468 |  |  |  | 11,924 |  |  |  | 13,728 |  |
| Total |  | $ | 128,715 |  |  | $ | 156,391 |  |  | $ | 243,238 |  |  | $ | 300,182 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-038237:notes:46]
4. INCOME TAXES

[0001564590-20-038237:notes:47]
Our effective tax rate increased from a benefit of 17.3% for the three months ended June 30, 2019 to an expense of 68.5% for the three months ended June 30, 2020 and decreased from a benefit of 6.2% for the six months ended June 30, 2019 to a benefit of 22.9% for the six months ended June 30, 2020. The change in the effective tax rate for the three months ended June 30, 2020 was impacted by tax expense in our international operations and additional changes in the valuation allowance related to our domestic operations. The change in the effective tax rate for the three and six months ended June 30, 2019 was primarily driven by the shift to profitability for the three and six months ended June 30, 2019, with tax expense being offset by a 29.1% rate reduction related to a transfer pricing study completed during the second quarter of 2019 that resulted in the assignment of operating expenditures to specific Company locations, and the effective income tax rates among the respective jurisdictions. The decrease in the effective tax rate for the six months ended June 30, 2020 was primarily driven by a tax benefit of $7.4 million recognized during the six months ended June 30, 2020 as a result of the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) signed into law on March 27, 2020, which allowed for the carryback of federal net operating losses, partially offset with tax expense in our international operations and changes in our valuation allowance related to our domestic operations. An increase in the valuation allowance against our domestic deferred tax assets was recorded in the amount of $3.6 million during the three and six months ended June 30, 2020.

[0001564590-20-038237:notes:48]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of June 30, 2020, the Company had deferred tax assets totaling $59.8 million, and a valuation allowance totaling $52.2 million had been established against those deferred tax assets. The remaining $7.6 million in deferred tax assets not offset by a valuation allowance is located in various foreign jurisdictions where the Company believes that it is more likely than not that we will realize these deferred tax assets. Our assessment of the realizability of our deferred tax assets includes the evaluation of evidence, some of which requires significant judgement, including historical operating results, the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and additional valuation allowance or a partial or full release of the valuation allowance is necessary, it could have a material effect on our consolidated financial statements.

[0001564590-20-038237:notes:49]
Supplemental balance sheet information related to deferred tax assets as of June 30, 2020 and December 31, 2019 is as follows:

[0001564590-20-038237:notes:50]
|  |  | June 30, 2020 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 50,164 |  |  | $ | (50,164 | ) |  | $ | — |  |
| International |  |  | 9,603 |  |  |  | (2,030 | ) |  |  | 7,573 |  |
| Total |  | $ | 59,767 |  |  | $ | (52,194 | ) |  | $ | 7,573 |  |

[0001564590-20-038237:notes:51]
[same as prior period, unchanged from 0001564590-20-023537:notes:45]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-20-038237:notes:52]
5. PENSION BENEFIT PLAN

[0001564590-20-038237:notes:53]
The following table summarizes the components of net periodic pension cost related to a defined benefit pension plan covering employees in certain foreign countries for the three and six months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:54]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Service cost |  | $ | 307 |  |  | $ | 368 |  |  | $ | 617 |  |  | $ | 743 |  |
| Interest cost |  |  | 108 |  |  |  | 159 |  |  |  | 216 |  |  |  | 321 |  |
| Expected return on plan assets |  |  | (407 | ) |  |  | (348 | ) |  |  | (817 | ) |  |  | (703 | ) |
| Amortization of actuarial losses |  |  | 235 |  |  |  | 199 |  |  |  | 472 |  |  |  | 402 |  |
| Net periodic pension cost |  | $ | 243 |  |  | $ | 378 |  |  | $ | 488 |  |  | $ | 763 |  |

[0001564590-20-038237:notes:55]
[same as prior period, unchanged from 0001564590-20-023537:notes:49]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-038237:notes:56]
6. STOCK-BASED COMPENSATION

[0001564590-20-038237:notes:57]
The following table summarizes stock-based compensation expense related to stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock for the three and six months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:58]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 87 |  |  | $ | 85 |  |  | $ | 202 |  |  | $ | 189 |  |
| Selling, general and administrative expense |  |  | 971 |  |  |  | 662 |  |  |  | 2,046 |  |  |  | 1,725 |  |
| Research and development expense |  |  | 597 |  |  |  | 707 |  |  |  | 1,198 |  |  |  | 1,399 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,568 |  |  |  | 1,369 |  |  |  | 3,244 |  |  |  | 3,124 |  |
| Total stock-based compensation expense |  |  | 1,655 |  |  |  | 1,454 |  |  |  | 3,446 |  |  |  | 3,313 |  |
| Tax benefit for expense associated with stock options, PSUs, RSUs and restricted stock |  |  | (394 | ) |  |  | (332 | ) |  |  | (821 | ) |  |  | (775 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,261 |  |  | $ | 1,122 |  |  | $ | 2,625 |  |  | $ | 2,538 |  |

[0001564590-20-038237:notes:59]
[same as prior period, unchanged from 0001564590-20-023537:notes:53]

[0001564590-20-038237:notes:60]
The following table summarizes PSUs, RSUs and restricted stock outstanding as of December 31, 2019 and June 30, 2020 and the changes that occurred during the six months ended June 30, 2020.

[0001564590-20-038237:notes:61]
|  |  | Number of Shares (in thousands) |  |  | Weighted Avg. Grant Date Fair Value (per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2019 |  |  | 1,891 |  |  | $ | 14.58 |  |
| PSUs, RSUs and restricted stock granted |  |  | 399 |  |  | $ | 8.21 |  |
| PSUs, RSUs and restricted stock vested |  |  | (13 | ) |  | $ | 12.32 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (518 | ) |  | $ | 19.27 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, June 30, 2020 |  |  | 1,759 |  |  | $ | 11.78 |  |

[0001564590-20-038237:notes:62]
During the six months ended June 30, 2020, the Company issued 0.3 million performance-based PSUs under the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (the “2015 Employee Plan”) to its executive officers and certain employees. The grant-date fair value of these performance-based awards is based on the closing price of the Company’s stock on the date of grant. Subject to the grantee’s continued employment, the grantee has the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of defined performance target at the end of a three-year period. If the Company achieves the performance target at the end of the first or second year during the performance period, the grantee will be entitled to the target number of performance shares, which will not be issued until the end of the three-year period. Equity-based compensation expense with respect to these awards will be adjusted over the vesting period to reflect the probability of achievement of the performance targets defined in the award agreements.

[0001564590-20-038237:notes:63]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the date of grant. The fair value of PSUs with market conditions is calculated using a Monte Carlo simulation valuation method.

[0001564590-20-038237:notes:64]
As of June 30, 2020, total unrecognized compensation expense related to non-vested market-based PSUs, RSUs and restricted stock was approximately $12.7 million, which will be recognized over the remaining weighted-average period of 2.5 years. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001564590-20-038237:notes:65]
At the annual meeting of stockholders held on May 13, 2020, the Company’s stockholders approved, upon recommendation of the Board of Directors, the adoption of the ADTRAN, Inc. 2020 Employee Stock Incentive Plan (the “2020 Employee Plan”) as well as the ADTRAN, Inc. 2020 Directors Stock Plan (the “2020 Directors Plan”). No additional awards will be granted under the 2015 Employee Plan or the 2010 Directors Stock Plan subsequent to the stockholders’ approval of these new stock plans. Outstanding awards granted under the 2015 Employee Plan and the 2010 Directors Stock Plan will remain subject to the terms of such plans, and shares underlying awards granted under such plans that are cancelled or forfeited will be available for issuance under the 2020 Employee Plan or the 2020 Directors Plan, as applicable.

[0001564590-20-038237:notes:66]
Under the 2020 Employee Plan, the Company is authorized to issue 2.8 million shares of common stock to certain employees, key service providers and advisors through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock, any of which may be subject to performance-based conditions. Options, RSUs and restricted stock granted under the 2020 Employee Plan reduce the shares authorized for issuance under the 2020 Employee Plan by one (1) share of common stock for each share underlying the award. Forfeitures, cancellations or expirations of awards granted under the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan, with forfeitures, cancellations or expirations of RSUs and restricted stock increasing the shares authorized for issuance by 2.5 shares of common stock for each share underlying the award. Forfeitures cancellations or expirations of options from the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan by one (1) share of common stock for each share underlying the award. RSUs and restricted stock granted under the 2020 Employee Plan will typically vest pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date. Options granted under the 2020 Employee Plan will typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term.

[0001564590-20-038237:notes:67]
Under the 2020 Directors Plan, the Company is authorized to issue 0.4 million shares of common stock. Under the 2020 Directors Plan, the Company may issue stock options, restricted stock and RSUs to our non-employee directors. Stock awards issued under the 2020 Directors Plan typically will become vested in full on the first anniversary of the grant date. Options issued under the 2020 Directors Plan will have a ten-year contractual term. Options, restricted stock and RSUs granted under the 2020 Directors Plan reduce the shares authorized for issuance under the 2020 Directors Plan by one (1) share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the 2010 Directors Stock Plan increase the shares authorized for issuance under the 2010 Directors Stock Plan or the 2020 Directors Plan by one (1) share of common stock for each share underlying the award.

[0001564590-20-038237:notes:68]
As of June 30, 2020, 3.4 million shares were available for issuance under stockholder-approved equity plans.

[0001564590-20-038237:notes:69]
[same as prior period, unchanged from 0001564590-20-023537:notes:60]

[0001564590-20-038237:notes:70]
The following table summarizes stock options outstanding as of December 31, 2019 and June 30, 2020 and the changes that occurred during the six months ended June 30, 2020:

[0001564590-20-038237:notes:71]
|  |  | Number of Stock Options (in thousands) |  |  | Weighted Avg. Exercise Price (per share) |  |  | Weighted Avg. Remaining Contractual Life (in years) |  |  | Aggregate Intrinsic Value (in thousands) |  |
| Stock options outstanding, December 31, 2019 |  |  | 3,572 |  |  | $ | 22.88 |  |  |  | 3.4 |  |  | $ | — |  |
| Stock options exercised |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (265 | ) |  | $ | 21.20 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, June 30, 2020 |  |  | 3,307 |  |  | $ | 22.93 |  |  |  | 2.9 |  |  | $ | — |  |
| Stock options exercisable, June 30, 2020 |  |  | 3,305 |  |  | $ | 22.93 |  |  |  | 2.9 |  |  | $ | — |  |

[0001564590-20-038237:notes:72]
As of June 30, 2020, total unrecognized compensation expense related to non-vested stock options was approximately $4 thousand, which will be recognized over the remaining weighted-average period of 0.3 years. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001564590-20-038237:notes:73]
There were no stock options granted during the three and six months ended June 30, 2020 and 2019. All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0001564590-20-038237:notes:74]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on June 30, 2020. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock and was zero as of June 30, 2020. The total pre-tax intrinsic value of options exercised during the six months ended June 30, 2020 was zero.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-20-038237:notes:75]
7. INVESTMENTS

[0001564590-20-038237:notes:76]
Debt Securities and Other Investments

[0001564590-20-038237:notes:77]
As of June 30, 2020, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

[0001564590-20-038237:notes:78]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 13,747 |  |  | $ | 168 |  |  | $ | (1 | ) |  | $ | 13,914 |  |
| Municipal fixed-rate bonds |  |  | 2,379 |  |  |  | 21 |  |  |  | — |  |  |  | 2,400 |  |
| Asset-backed bonds |  |  | 7,600 |  |  |  | 86 |  |  |  | (4 | ) |  |  | 7,682 |  |
| Mortgage/Agency-backed bonds |  |  | 7,944 |  |  |  | 152 |  |  |  | (12 | ) |  |  | 8,084 |  |
| U.S. government bonds |  |  | 7,935 |  |  |  | 211 |  |  |  | — |  |  |  | 8,146 |  |
| Foreign government bonds |  |  | 540 |  |  |  | — |  |  |  | — |  |  |  | 540 |  |
| Commercial paper |  |  | 1,120 |  |  |  | 4 |  |  |  | — |  |  |  | 1,124 |  |
| Variable-rate demand notes |  |  | 300 |  |  |  | — |  |  |  | — |  |  |  | 300 |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Available-for-sale debt securities held at fair value |  | $ | 42,007 |  |  | $ | 642 |  |  | $ | (17 | ) |  | $ | 42,632 |  |

[0001564590-20-038237:notes:79]
As of December 31, 2019, the following debt securities and other investments were included on the Condensed Consolidated Balance sheet and recorded at fair value:

[0001564590-20-038237:notes:80]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,304 |  |  | $ | 80 |  |  | $ | — |  |  | $ | 9,384 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | 930 |  |
| Asset-backed bonds |  |  | 6,867 |  |  |  | 26 |  |  |  | (3 | ) |  |  | 6,890 |  |
| Mortgage/Agency-backed bonds |  |  | 6,944 |  |  |  | 26 |  |  |  | (8 | ) |  |  | 6,962 |  |
| U.S. government bonds |  |  | 12,311 |  |  |  | 21 |  |  |  | (9 | ) |  |  | 12,323 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (1 | ) |  |  | 371 |  |
| Variable-rate demand notes |  |  | 800 |  |  |  | — |  |  |  | — |  |  |  | 800 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,528 |  |  | $ | 153 |  |  | $ | (21 | ) |  | $ | 37,660 |  |

[0001564590-20-038237:notes:81]
As of June 30, 2020, contractual maturities related to debt securities and other investments were as follows:

[0001564590-20-038237:notes:82]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage/ Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Commercial paper |  |  | Variable-rate demand notes |  |  | Other |  |
| Less than one year |  | $ | 5,441 |  |  | $ | 738 |  |  | $ | 465 |  |  | $ | 146 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,124 |  |  | $ | — |  |  | $ | 442 |  |
| One to two years |  |  | 2,926 |  |  |  | 528 |  |  |  | 465 |  |  |  | 603 |  |  |  | 1,638 |  |  |  | 75 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 5,547 |  |  |  | 757 |  |  |  | 1,141 |  |  |  | 1,528 |  |  |  | 6,065 |  |  |  | 465 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Three to five years |  |  | — |  |  |  | 377 |  |  |  | 3,932 |  |  |  | — |  |  |  | 443 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 982 |  |  |  | 1,890 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 697 |  |  |  | 3,917 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 300 |  |  |  | — |  |
| Total |  | $ | 13,914 |  |  | $ | 2,400 |  |  | $ | 7,682 |  |  | $ | 8,084 |  |  | $ | 8,146 |  |  | $ | 540 |  |  | $ | 1,124 |  |  | $ | 300 |  |  | $ | 442 |  |

[0001564590-20-038237:notes:83]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-20-038237:notes:84]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:

[0001564590-20-038237:notes:85]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Gross realized gains on debt securities |  | $ | 190 |  |  | $ | 8 |  |  | $ | 233 |  |  | $ | 49 |  |
| Gross realized losses on debt securities |  |  | (19 | ) |  |  | (14 | ) |  |  | (39 | ) |  |  | (33 | ) |
| Total gain recognized, net |  | $ | 171 |  |  | $ | (6 | ) |  | $ | 194 |  |  | $ | 16 |  |

[0001564590-20-038237:notes:86]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended June 30, 2020.

[0001564590-20-038237:notes:87]
Marketable Equity Securities

[0001564590-20-038237:notes:88]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost (where appropriate).

[0001564590-20-038237:notes:89]
During the three months ended March 31, 2019, an outstanding note receivable of $4.3 million was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment, which represented a non-cash investing activity. We elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. During the six months ended June 30, 2020, an impairment charge of $1.6 million was recorded related to this equity investment, which is included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $1.8 million as of June 30, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of June 30, 2020 and December 31, 2019, and represented a non-cash investing activity during the six months ended June 30, 2019. No impairment charge was recognized related to the note receivable as it is a secured loan.

[0001564590-20-038237:notes:90]
Realized and unrealized gains and losses related to marketable equity securities for the three and six months ended June 30, 2020 and 2019 were as follows:

[0001564590-20-038237:notes:91]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Realized gains (losses) on equity securities sold |  | $ | 328 |  |  | $ | (49 | ) |  | $ | (2,108 | ) |  | $ | (63 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 9,353 |  |  |  | 2,540 |  |  |  | 889 |  |  |  | 8,458 |  |
| Total gain (loss) recognized, net |  | $ | 9,681 |  |  | $ | 2,491 |  |  | $ | (1,219 | ) |  | $ | 8,395 |  |

[0001564590-20-038237:notes:92]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0001564590-20-038237:notes:93]
• Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0001564590-20-038237:notes:94]
• Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0001564590-20-038237:notes:95]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0001564590-20-038237:notes:96]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0001564590-20-038237:notes:97]
|  |  |  |  |  |  | Fair Value Measurements as of June 30, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,697 |  |  | $ | 1,697 |  |  | $ | — |  |  | $ | — |  |
| U.S. government securities |  |  | 1,250 |  |  |  | 1,250 |  |  |  | — |  |  |  | — |  |
| Commercial paper |  |  | 100 |  |  |  | — |  |  |  | 100 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,914 |  |  |  | — |  |  |  | 13,914 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,400 |  |  |  | — |  |  |  | 2,400 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,682 |  |  |  | — |  |  |  | 7,682 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,084 |  |  |  | — |  |  |  | 8,084 |  |  |  | — |  |
| U.S. government bonds |  |  | 8,146 |  |  |  | 8,146 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 540 |  |  |  | — |  |  |  | 540 |  |  |  | — |  |
| Commercial paper |  |  | 1,124 |  |  |  | — |  |  |  | 1,124 |  |  |  | — |  |
| Variable-rate demand notes |  |  | 300 |  |  |  | — |  |  |  | 300 |  |  |  | — |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,116 |  |  |  | 26,116 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,468 |  |  |  | 20,468 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,223 |  |  |  | 1,223 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 93,486 |  |  | $ | 58,900 |  |  | $ | 34,144 |  |  | $ | 442 |  |

[0001564590-20-038237:notes:98]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,309 |  |  | $ | 1,309 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,384 |  |  |  | — |  |  |  | 9,384 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,890 |  |  |  | — |  |  |  | 6,890 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 6,962 |  |  |  | — |  |  |  | 6,962 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,323 |  |  |  | 12,323 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 371 |  |  |  | — |  |  |  | 371 |  |  |  | — |  |
| Variable-rate demand notes |  |  | 800 |  |  |  | — |  |  |  | 800 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,501 |  |  |  | 35,501 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 298 |  |  |  | 298 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,698 |  |  |  | 21,698 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,442 |  |  |  | 2,442 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 98,908 |  |  | $ | 73,571 |  |  | $ | 25,337 |  |  | $ | — |  |

[0001564590-20-038237:notes:99]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-20-038237:notes:100]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consists of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.


## us-gaap:InventoryDisclosureTextBlock

[0001564590-20-038237:notes:101]
8. INVENTORY

[0001564590-20-038237:notes:102]
As of June 30, 2020 and December 31, 2019, inventory consisted of the following:

[0001564590-20-038237:notes:103]
|  |  | June 30, |  |  | December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Raw materials |  | $ | 37,057 |  |  | $ | 36,987 |  |
| Work in process |  |  | 610 |  |  |  | 1,085 |  |
| Finished goods |  |  | 68,464 |  |  |  | 60,233 |  |
| Total inventory |  | $ | 106,131 |  |  | $ | 98,305 |  |

[0001564590-20-038237:notes:104]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. As of June 30, 2020 and December 31, 2019, inventory reserves were $35.9 million and $34.1 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-20-038237:notes:105]
9. PROPERTY, PLANT AND EQUIPMENT

[0001564590-20-038237:notes:106]
At June 30, 2020 and December 31, 2019, property, plant and equipment consisted of the following:

[0001564590-20-038237:notes:107]
|  |  | June 30, |  |  | December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 34,897 |  |  |  | 34,797 |  |
| Building |  |  | 68,155 |  |  |  | 68,157 |  |
| Furniture and fixtures |  |  | 19,972 |  |  |  | 19,959 |  |
| Computer hardware and software |  |  | 69,564 |  |  |  | 68,777 |  |
| Engineering and other equipment |  |  | 131,785 |  |  |  | 130,430 |  |
| Total property, plant and equipment |  |  | 328,948 |  |  |  | 326,695 |  |
| Less: accumulated depreciation |  |  | (263,754 | ) |  |  | (258,609 | ) |
| Total property, plant and equipment, net |  | $ | 65,194 |  |  | $ | 68,086 |  |

[0001564590-20-038237:notes:108]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to long-lived assets during the second quarter of 2020. Based on this assessment, no triggers occurred to perform an impairment test, and no impairment losses of long-lived assets were recorded.

[0001564590-20-038237:notes:109]
Depreciation expense was $3.0 million and $3.1 million for the three months ended June 30, 2020 and 2019, respectively, and $6.0 million and $6.2 million for the six months ended June 30, 2020 and 2019, respectively, which is recorded in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-20-038237:notes:110]
10. GOODWILL

[0001564590-20-038237:notes:111]
Goodwill was $7.0 million as of June 30, 2020 and December 31, 2019, of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-20-038237:notes:112]
The Company evaluates the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that could more likely than not reduce the fair value of the reporting unit below its carrying amount. We assess qualitative factors to determine whether the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount and recognize an impairment charge for the amount by which the carrying value exceeds the fair value of the reporting unit. Due to the current economic environment, particularly related to COVID-19, the Company performed a triggering event assessment, in which no triggers were identified. Therefore, no interim impairment test of goodwill was performed as of June 30, 2020, and no impairment of goodwill was recorded.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-20-038237:notes:113]
11. INTANGIBLE ASSETS

[0001564590-20-038237:notes:114]
Intangible assets as of June 30, 2020 and December 31, 2019 consisted of the following:

[0001564590-20-038237:notes:115]
|  |  | June 30, 2020 |  |  | December 31, 2019 |  |
| (In thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | $ | 20,742 |  |  | $ | (6,690 | ) |  | $ | 14,052 |  |  | $ | 22,356 |  |  | $ | (7,233 | ) |  | $ | 15,123 |  |
| Developed technology |  |  | 8,200 |  |  |  | (1,977 | ) |  |  | 6,223 |  |  |  | 10,170 |  |  |  | (3,379 | ) |  |  | 6,791 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (1,503 | ) |  |  | 4,397 |  |  |  | 5,900 |  |  |  | (1,174 | ) |  |  | 4,726 |  |
| Supplier relationships |  |  | 2,800 |  |  |  | (2,800 | ) |  |  | — |  |  |  | 2,800 |  |  |  | (2,508 | ) |  |  | 292 |  |
| Licensing agreements |  |  | 560 |  |  |  | (116 | ) |  |  | 444 |  |  |  | 560 |  |  |  | (79 | ) |  |  | 481 |  |
| Patents |  |  | 500 |  |  |  | (260 | ) |  |  | 240 |  |  |  | 500 |  |  |  | (226 | ) |  |  | 274 |  |
| Trade names |  |  | 210 |  |  |  | (111 | ) |  |  | 99 |  |  |  | 310 |  |  |  | (176 | ) |  |  | 134 |  |
| Total |  | $ | 38,912 |  |  | $ | (13,457 | ) |  | $ | 25,455 |  |  | $ | 42,596 |  |  | $ | (14,775 | ) |  | $ | 27,821 |  |

[0001564590-20-038237:notes:116]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to intangible assets during the second quarter of 2020. Based on this assessment, no triggers occurred to perform an impairment test, and no impairment losses of intangible assets were recorded.

[0001564590-20-038237:notes:117]
Amortization expense was $1.0 million and $1.3 million for the three months ended June 30, 2020 and 2019, respectively, and $2.4 million and $2.7 million for the six months ended June 30, 2020 and 2019, respectively, and was included in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).

[0001564590-20-038237:notes:118]
As of June 30, 2020, estimated future amortization expense of intangible assets was as follows:

[0001564590-20-038237:notes:119]
| (In thousands) |  |  |  |  |
| 2020 |  | $ | 2,076 |  |
| 2021 |  |  | 4,095 |  |
| 2022 |  |  | 3,472 |  |
| 2023 |  |  | 3,320 |  |
| 2024 |  |  | 3,227 |  |
| Thereafter |  |  | 9,265 |  |
| Total |  | $ | 25,455 |  |


## adtn:LeasesDisclosureTextBlock

[0001564590-20-038237:notes:120]
12. LEASES

[0001564590-20-038237:notes:121]
[same as prior period, unchanged from 0001564590-20-023537:notes:112]

[0001564590-20-038237:notes:122]
Operating leases consist of office space, automobiles and various other equipment in the U.S. and in certain international locations in which we do business. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain any embedded leases. As of June 30, 2020, the operating leases had remaining lease terms of one month to five years, some of which include options to extend the leases for up to nine years, and some of which include options to terminate the leases within three months. As of June 30, 2020 and December 31, 2019, the Company’s operating lease assets and operating lease liabilities were as follows:

[0001564590-20-038237:notes:123]
| (In thousands) |  | Classification |  | June 30, 2020 |  |  | December 31, 2019 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |
| Operating lease asset |  | Other assets |  | $ | 5,973 |  |  | $ | 8,452 |  |
| Total lease asset |  |  |  | $ | 5,973 |  |  | $ | 8,452 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses |  | $ | 1,854 |  |  | $ | 2,676 |  |
| Non-current operating lease liability |  | Other non-current liabilities |  |  | 4,134 |  |  |  | 5,818 |  |
| Total lease liability |  |  |  | $ | 5,988 |  |  | $ | 8,494 |  |

[0001564590-20-038237:notes:124]
Lease expense related to short-term leases (initial term of less than 12 months) was $5 thousand and $0.1 million for the three months ended June 30, 2020 and 2019, respectively, and was $14 thousand and $0.3 million for the six months ended June 30, 2020 and 2019, respectively, and was included in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss). Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.1 million and $0.3 million for the three months ended June 30, 2020 and 2019, respectively and was $0.3 million and $0.4 million for the six months ended June 30, 2020 and 2019, respectively.

[0001564590-20-038237:notes:125]
Components of lease expense included in the Condensed Consolidated Statements of Income (Loss) for the three and six months ended June 30, 2020 and 2019 were as follows:

[0001564590-20-038237:notes:126]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Selling, general and administrative expenses |  | $ | 271 |  |  | $ | 349 |  |  | $ | 598 |  |  | $ | 698 |  |
| Research and development expenses |  |  | 251 |  |  |  | 430 |  |  |  | 676 |  |  |  | 884 |  |
| Cost of sales |  |  | 26 |  |  |  | 17 |  |  |  | 47 |  |  |  | 33 |  |
| Total operating lease expense |  | $ | 548 |  |  | $ | 796 |  |  | $ | 1,321 |  |  | $ | 1,615 |  |

[0001564590-20-038237:notes:127]
As of June 30, 2020 and December 31, 2019, operating lease liabilities included on the Condensed Consolidated Balance Sheets by future maturity were as follows:

[0001564590-20-038237:notes:128]
| (In thousands) |  | June 30, 2020 |  |  | December 31, 2019 |  |
| 2020 |  | $ | 1,048 |  |  | $ | 2,856 |  |
| 2021 |  |  | 1,815 |  |  |  | 2,412 |  |
| 2022 |  |  | 1,514 |  |  |  | 1,705 |  |
| 2023 |  |  | 1,110 |  |  |  | 1,160 |  |
| 2024 |  |  | 478 |  |  |  | 482 |  |
| Thereafter |  |  | 264 |  |  |  | 264 |  |
| Total lease payments |  |  | 6,229 |  |  |  | 8,879 |  |
| Less: Interest |  |  | (241 | ) |  |  | (385 | ) |
| Present value of lease liabilities |  | $ | 5,988 |  |  | $ | 8,494 |  |

[0001564590-20-038237:notes:129]
Future operating lease payments include $0.5 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0001564590-20-038237:notes:130]
An incremental borrowing rate is used based on information available at the commencement date in determining the present value of lease payments. The incremental borrowing rate was determined on a portfolio basis by grouping leases with similar terms as well as grouping leases based on a U.S. dollar or Euro functional currency.  The actual rate is then determined based on a credit spread over LIBOR as well as the Bloomberg Curve Matrix for the U.S. Communications section. The following table provides information about the weighted average lease terms and weighted average discount rates as of June 30, 2020:

[0001564590-20-038237:notes:131]
|  |  | As of June 30, 2020 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |
| Operating leases with USD functional currency |  |  | 2.5 |  |
| Operating leases with Euro functional currency |  |  | 4.0 |  |
| Weighted average discount rate |  |  |  |  |
| Operating leases with USD functional currency |  |  | 4.46 | % |
| Operating leases with Euro functional currency |  |  | 1.83 | % |

[0001564590-20-038237:notes:132]
[same as prior period, unchanged from 0001564590-20-023537:notes:123]

[0001564590-20-038237:notes:133]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Cash paid for amounts included in the measurement of operating lease assets / liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash used in operating activities related to operating leases |  | $ | 770 |  |  | $ | 797 |  |  | $ | 1,477 |  |  | $ | 1,608 |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 8 |  |  | $ | 9 |  |  | $ | 93 |  |  | $ | 10,396 |  |

[0001564590-20-038237:notes:134]
[same as prior period, unchanged from 0001564590-20-023537:notes:125]

[0001564590-20-038237:notes:135]
We are the lessor in sales-type lease arrangements for network equipment, which have initial terms of up to five years, and consisted of the following as of June 30, 2020 and December 31, 2019:

[0001564590-20-038237:notes:136]
| (In thousands) |  | June 30, 2020 |  |  | December 31, 2019 |  |
| Current minimum lease payments receivable(1) |  | $ | 923 |  |  | $ | 1,201 |  |
| Non-current minimum lease payments receivable(2) |  |  | 566 |  |  |  | 889 |  |
| Total minimum lease payments receivable |  |  | 1,489 |  |  |  | 2,090 |  |
| Less: Current unearned revenue |  |  | 265 |  |  |  | 365 |  |
| Less: Non-current unearned revenue |  |  | 92 |  |  |  | 163 |  |
| Net investment in sales-type leases |  | $ | 1,132 |  |  | $ | 1,562 |  |

[0001564590-20-038237:notes:137]
[same as prior period, unchanged from 0001564590-20-023537:notes:128]

[0001564590-20-038237:notes:138]
Components of gross profit related to sales-type leases recognized at the lease commencement date and interest and dividend income included in the Condensed Consolidated Statements of Income (Loss) for the three and six months ended June 30, 2020 and 2019 were as follows:

[0001564590-20-038237:notes:139]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Sales - Network Solutions |  | $ | 12 |  |  | $ | 109 |  |  | $ | 50 |  |  | $ | 1,621 |  |
| Less: Cost of sales - Network Solutions |  |  | 4 |  |  |  | 44 |  |  |  | 20 |  |  |  | 635 |  |
| Gross profit |  | $ | 8 |  |  | $ | 65 |  |  | $ | 30 |  |  | $ | 986 |  |
| Interest and dividend income |  | $ | 11 |  |  | $ | 99 |  |  | $ | 24 |  |  | $ | 186 |  |


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001564590-20-038237:notes:140]
13. ALABAMA STATE INDUSTRIAL DEVELOPMENT AUTHORITY FINANCING AND ECONOMIC INCENTIVES

[0001564590-20-038237:notes:141]
In conjunction with the 1995 expansion of our Huntsville, Alabama facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, in January 1995, the Authority issued $20.0 million of its taxable revenue bonds (the “Taxable Revenue Bonds”) and loaned the proceeds from the sale of the Taxable Revenue Bonds to the Company. Further advances on the Taxable Revenue Bonds were made by the Authority, bringing the total amount to $50.0 million. The Taxable Revenue Bonds bore interest, payable monthly with an interest rate of 2% per annum. The Taxable Revenue Bonds’ aggregate principal amount outstanding as of December 31, 2019 of $24.6 million matured on January 1, 2020 and was repaid in full on January 2, 2020, using the funds held in a certificate of deposit by the Company. This certificate of deposit, which totaled $25.6 million, was included in short-term investments on the Condensed Consolidated Balance Sheet as of December 31, 2019.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-20-038237:notes:142]
14. STOCKHOLDERS’ EQUITY

[0001564590-20-038237:notes:143]
[same as prior period, unchanged from 0001564590-20-023537:notes:134]

[0001564590-20-038237:notes:144]
Since 1997, the Company’s Board of Directors has approved multiple share repurchase programs that have authorized repurchases of its common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2020, we did not repurchase shares of our common stock. As of June 30, 2020, we had the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-20-038237:notes:145]
Accumulated Other Comprehensive Income (Loss)

[0001564590-20-038237:notes:146]
The following tables present the changes in accumulated other comprehensive loss, net of tax, by component for the three months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:147]
|  |  | Three Months Ended June 30, 2020 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| As of March 31, 2020 |  | $ | (167 | ) |  | $ | (9,085 | ) |  | $ | (8,942 | ) |  | $ | 385 |  |  | $ | (17,809 | ) |
| Other comprehensive income before reclassifications |  |  | 881 |  |  |  | — |  |  |  | 1,899 |  |  |  | — |  |  |  | 2,780 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (508 | ) |  |  | 191 |  |  |  | — |  |  |  | — |  |  |  | (317 | ) |
| Net current period other comprehensive income |  |  | 373 |  |  |  | 191 |  |  |  | 1,899 |  |  |  | — |  |  |  | 2,463 |  |
| As of June 30, 2020 |  | $ | 206 |  |  | $ | (8,894 | ) |  | $ | (7,043 | ) |  | $ | 385 |  |  | $ | (15,346 | ) |

[0001564590-20-038237:notes:148]
|  |  | Three Months Ended June 30, 2019 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| As of March 31, 2019 |  | $ | (378 | ) |  | $ | (7,920 | ) |  | $ | (6,972 | ) |  | $ | 385 |  |  | $ | (14,885 | ) |
| Other comprehensive income before reclassifications |  |  | 180 |  |  |  | — |  |  |  | 533 |  |  |  | — |  |  |  | 713 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (73 | ) |  |  | 150 |  |  |  | — |  |  |  | — |  |  |  | 77 |  |
| Net current period other comprehensive income |  |  | 107 |  |  |  | 150 |  |  |  | 533 |  |  |  | — |  |  |  | 790 |  |
| As of June 30, 2019 |  | $ | (271 | ) |  | $ | (7,770 | ) |  | $ | (6,439 | ) |  | $ | 385 |  |  | $ | (14,095 | ) |

[0001564590-20-038237:notes:149]
|  | (1) | With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings. |

[0001564590-20-038237:notes:150]
The following tables present the changes in accumulated other comprehensive loss, net of tax, by component for the six months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:151]
|  |  | Six Months Ended June 30, 2020 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption(1) |  |  | Total |  |
| As of December 31, 2019 |  | $ | (284 | ) |  | $ | (9,226 | ) |  | $ | (7,292 | ) |  | $ | 385 |  |  | $ | (16,417 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (50 | ) |  |  | — |  |  |  | 249 |  |  |  | — |  |  |  | 199 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | 540 |  |  |  | 332 |  |  |  | — |  |  |  | — |  |  |  | 872 |  |
| Net current period other comprehensive income |  |  | 490 |  |  |  | 332 |  |  |  | 249 |  |  |  | — |  |  |  | 1,071 |  |
| As of June 30, 2020 |  | $ | 206 |  |  | $ | (8,894 | ) |  | $ | (7,043 | ) |  | $ | 385 |  |  | $ | (15,346 | ) |

[0001564590-20-038237:notes:152]
|  |  | Six Months Ended June 30, 2019 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| As of December 31, 2018 |  | $ | (563 | ) |  | $ | (8,041 | ) |  | $ | (5,812 | ) |  | $ | — |  |  | $ | (14,416 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 411 |  |  |  | — |  |  |  | (627 | ) |  |  | — |  |  |  | (216 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (119 | ) |  |  | 271 |  |  |  | — |  |  |  | — |  |  |  | 152 |  |
| Amounts reclassified to retained earnings (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |  |  | 385 |  |
| Net current period other comprehensive income (loss) |  |  | 292 |  |  |  | 271 |  |  |  | (627 | ) |  |  | 385 |  |  |  | 321 |  |
| As of June 30, 2019 |  | $ | (271 | ) |  | $ | (7,770 | ) |  | $ | (6,439 | ) |  | $ | 385 |  |  | $ | (14,095 | ) |

[0001564590-20-038237:notes:153]
The following tables present the details of reclassifications out of accumulated other comprehensive loss for the three months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:154]
|  |  | Three Months Ended June 30, 2020 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 686 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (277 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 409 |  |  |  |
| Tax expense |  |  | (92 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 317 |  |  |  |

[0001564590-20-038237:notes:155]
|  | (1) | Included in the computation of net periodic pension cost. See Note 5. |

[0001564590-20-038237:notes:156]
|  |  | Three Months Ended June 30, 2019 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 99 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (217 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (118 | ) |  |  |
| Tax benefit |  |  | 41 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (77 | ) |  |  |

[0001564590-20-038237:notes:157]
The following tables present the details of reclassifications out of accumulated other comprehensive loss for the six months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:158]
|  |  | Six Months Ended June 30, 2020 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized losses on sales of securities |  | $ | (730 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (481 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (1,211 | ) |  |  |
| Tax benefit |  |  | 339 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (872 | ) |  |  |

[0001564590-20-038237:notes:159]
|  |  | Six Months Ended June 30, 2019 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 161 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (393 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (232 | ) |  |  |
| Tax benefit |  |  | 80 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (152 | ) |  |  |

[0001564590-20-038237:notes:160]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss) for the three months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:161]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain on available-for-sale securities |  | $ | 1,191 |  |  | $ | (310 | ) |  | $ | 881 |  |  | $ | 243 |  |  | $ | (63 | ) |  | $ | 180 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | (686 | ) |  |  | 178 |  |  |  | (508 | ) |  |  | (99 | ) |  |  | 26 |  |  |  | (73 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 277 |  |  |  | (86 | ) |  |  | 191 |  |  |  | 217 |  |  |  | (67 | ) |  |  | 150 |  |
| Foreign currency translation adjustment |  |  | 1,899 |  |  |  | — |  |  |  | 1,899 |  |  |  | 533 |  |  |  | — |  |  |  | 533 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 2,681 |  |  | $ | (218 | ) |  | $ | 2,463 |  |  | $ | 894 |  |  | $ | (104 | ) |  | $ | 790 |  |

[0001564590-20-038237:notes:162]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss) for the six months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:163]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | (68 | ) |  | $ | 18 |  |  | $ | (50 | ) |  | $ | 555 |  |  | $ | (144 | ) |  | $ | 411 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 730 |  |  |  | (190 | ) |  |  | 540 |  |  |  | (161 | ) |  |  | 42 |  |  |  | (119 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 481 |  |  |  | (149 | ) |  |  | 332 |  |  |  | 393 |  |  |  | (122 | ) |  |  | 271 |  |
| Foreign currency translation adjustment |  |  | 249 |  |  |  | — |  |  |  | 249 |  |  |  | (627 | ) |  |  | — |  |  |  | (627 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 1,392 |  |  | $ | (321 | ) |  | $ | 1,071 |  |  | $ | 160 |  |  | $ | (224 | ) |  | $ | (64 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-038237:notes:164]
15. EARNINGS (LOSS) PER SHARE

[0001564590-20-038237:notes:165]
A summary of the calculation of basic and diluted earnings (loss) per share for the three and six months ended June 30, 2020 and 2019 is as follows:

[0001564590-20-038237:notes:166]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 752 |  |  | $ | 3,995 |  |  | $ | (9,217 | ) |  | $ | 4,765 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,958 |  |  |  | 47,802 |  |  |  | 47,957 |  |  |  | 47,792 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  | 7 |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | 296 |  |  |  | 227 |  |  |  | — |  |  |  | 147 |  |
| Weighted average number of shares – diluted |  |  | 48,254 |  |  |  | 48,036 |  |  |  | 47,957 |  |  |  | 47,939 |  |
| Earnings (loss) per share – basic |  | $ | 0.02 |  |  | $ | 0.08 |  |  | $ | (0.19 | ) |  | $ | 0.10 |  |
| Earnings (loss) per share – diluted |  | $ | 0.02 |  |  | $ | 0.08 |  |  | $ | (0.19 | ) |  | $ | 0.10 |  |

[0001564590-20-038237:notes:167]
For the three months ended June 30, 2020 and 2019, 0.1 million and 15 thousand shares, respectively, and for the six months ended June 30, 2020 and 2019, 0.2 million and 0.1 million shares, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0001564590-20-038237:notes:168]
For the three months ended June 30, 2020 and 2019, 4.1 million and 1.9 million stock options, respectively, and for the six months ended June 30, 2020 and 2019, 4.9 million and 2.3 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the quarter, making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-038237:notes:169]
16. SEGMENT INFORMATION

[0001564590-20-038237:notes:170]
[same as prior period, unchanged from 0001564590-20-023537:notes:153]

[0001564590-20-038237:notes:171]
The performance of our segments is evaluated based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense) and (provision) benefit for income taxes are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0001564590-20-038237:notes:172]
The following tables present information about the sales and gross profit of our reportable segments for the three and six months ended June 30, 2020 and 2019.

[0001564590-20-038237:notes:173]
|  |  | Three Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 111,323 |  |  | $ | 47,252 |  |  | $ | 139,167 |  |  | $ | 58,992 |  |
| Services & Support |  |  | 17,392 |  |  |  | 6,220 |  |  |  | 17,224 |  |  |  | 6,023 |  |
| Total |  | $ | 128,715 |  |  | $ | 53,472 |  |  | $ | 156,391 |  |  | $ | 65,015 |  |

[0001564590-20-038237:notes:174]
|  |  | Six Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 208,695 |  |  | $ | 92,998 |  |  | $ | 264,989 |  |  | $ | 114,080 |  |
| Services & Support |  |  | 34,543 |  |  |  | 12,074 |  |  |  | 35,193 |  |  |  | 11,547 |  |
| Total |  | $ | 243,238 |  |  | $ | 105,072 |  |  | $ | 300,182 |  |  | $ | 125,627 |  |

[0001564590-20-038237:notes:175]
In addition to our reporting segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

[0001564590-20-038237:notes:176]
[same as prior period, unchanged from 0001564590-20-023537:notes:157]

[0001564590-20-038237:notes:177]
The following table presents sales information by geographic area for the three and six months ended June 30, 2020 and 2019:

[0001564590-20-038237:notes:178]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |  |
| United States |  | $ | 84,458 |  |  | $ | 75,288 |  |  | $ | 163,449 |  |  | $ | 147,816 |  |
| International |  |  | 44,257 |  |  |  | 81,103 |  |  |  | 79,789 |  |  |  | 152,366 |  |
| Total |  | $ | 128,715 |  |  | $ | 156,391 |  |  | $ | 243,238 |  |  | $ | 300,182 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-20-038237:notes:179]
17. LIABILITY FOR WARRANTY RETURNS

[0001564590-20-038237:notes:180]
Our products generally include warranties of 90 days to five years for product defects. Warranty returns are accrued at the time revenue is recognized based on an estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of products will cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should actual experience relative to these factors be worse than estimated, additional warranty expense will be incurred. Alternatively, if actual costs incurred are less than estimated, a portion of the warranty reserves will be reversed in future periods. The liability for warranty obligations totaled $7.3 million and $8.4 million as of June 30, 2020 and December 31, 2019, respectively, and are included in accrued expenses and other liabilities in the accompanying Condensed Consolidated Balance Sheets.

[0001564590-20-038237:notes:181]
A reconciliation of warranty expense and related write-off activity for the three and six months ended June 30, 2020 and 2019 is as follows:

[0001564590-20-038237:notes:182]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 7,635 |  |  | $ | 8,802 |  |  | $ | 8,394 |  |  | $ | 8,623 |  |
| Plus: Amounts charged to cost and expenses |  |  | 393 |  |  |  | 1,849 |  |  |  | 338 |  |  |  | 2,980 |  |
| Less: Deductions |  |  | (734 | ) |  |  | (1,679 | ) |  |  | (1,438 | ) |  |  | (2,631 | ) |
| Balance at end of period |  | $ | 7,294 |  |  | $ | 8,972 |  |  | $ | 7,294 |  |  | $ | 8,972 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-038237:notes:183]
18. COMMITMENTS AND CONTINGENCIES

[0001564590-20-038237:notes:184]
Securities Class Action Lawsuit

[0001564590-20-038237:notes:185]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The lawsuit was transferred to the U.S. District Court for the Northern District of Alabama on January 7, 2020, and co-lead plaintiffs have been appointed to represent the putative class. The plaintiffs filed an amended complaint on April 30, 2020. The defendants filed a motion to dismiss the amended complaint on June 17, 2020. The plaintiffs filed an opposition brief to the defendants’ motion to dismiss on July 17, 2020. The defendants intend to file a reply to the plaintiffs’ brief on August 17, 2020. We deny the allegations in the complaint, as amended, and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-20-038237:notes:186]
Shareholder Derivative Lawsuit

[0001564590-20-038237:notes:187]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, makes similar allegations as the shareholder class action and accuses the directors and officers of breaches of fiduciary duty in connection with those allegations. On June 7, 2020, the Court entered an order staying the derivative litigation pending resolution of the motion to dismiss in the securities class action. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-20-038237:notes:188]
Other Legal Matters

[0001564590-20-038237:notes:189]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001564590-20-038237:notes:190]
Performance Bonds

[0001564590-20-038237:notes:191]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2020 and December 31, 2019, we had commitments related to these bonds totaling $11.3 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001564590-20-038237:notes:192]
In June of 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a customer. The letter of credit is secured by a pledge of collateral in the amount of $5.0 million, of which $1.2 million is included in restricted cash and $3.8 million is included in long-term investments on the Condensed Consolidated Balance Sheet as of June 30, 2020. Currently, the Company is required to maintain a minimum collateral value of approximately $5.0 million. The minimum collateral value will increase over time as the Company reaches certain milestones in the contract. The maximum collateral value required under the contract will be approximately $12.0 million, and this is expected to occur in February 2021. This minimum collateral value will increase further if the Company changes the mix of investments away from restricted cash and into other investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments or long-term investments. The obligations under the customer contract will be performed over multiple years. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of June 30, 2020, the Company was in compliance with all contractual requirements under the letter of credit.

[0001564590-20-038237:notes:193]
Investment Commitment

[0001564590-20-038237:notes:194]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been contributed as of June 30, 2020.


## us-gaap:CreditLossFinancialInstrumentTextBlock

[0001564590-20-038237:notes:195]
19. CURRENT EXPECTED CREDIT LOSSES

[0001564590-20-038237:notes:196]
Under ASC 326 – Financial Instruments – Credit Losses, the Company estimates credit losses for the contractual life of assets that are measured at amortized cost and are within the scope of this guidance, which includes accounts receivable, net investment in sales-type leases, contract assets under the revenue recognition model and outstanding notes receivable. Where appropriate, the Company pools assets if similar risk characteristics exist. Additionally, the Company analyzes its available-for-sale debt securities for impairment and records a credit loss allowance as needed.

[0001564590-20-038237:notes:197]
[same as prior period, unchanged from 0001564590-20-023537:notes:177]

[0001564590-20-038237:notes:198]
[same as prior period, unchanged from 0001564590-20-023537:notes:178]

[0001564590-20-038237:notes:199]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. As of January 1, 2020 and June 30, 2020, the Company’s outstanding accounts receivable balance was $90.5 million and $95.3 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable as of June 30, 2020 and January 1, 2020 using the historical loss-rate method as well as assessing asset-specific risks. The Company’s historical losses related to accounts receivable have been immaterial as evidenced by its historical allowance and write-offs due to uncollectability. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0001564590-20-038237:notes:200]
[same as prior period, unchanged from 0001564590-20-023537:notes:180]

[0001564590-20-038237:notes:201]
No allowance for credit loss was recorded on January 1, 2020 (the “implementation date”) or during the three and six months ended June 30, 2020 related to accounts receivable. The Company’s allowance for credit losses related to accounts receivable was $38 thousand as of June 30, 2020 and December 31, 2019, all of which was expensed prior to January 1, 2020.

[0001564590-20-038237:notes:202]
[same as prior period, unchanged from 0001564590-20-023537:notes:182]

[0001564590-20-038237:notes:203]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of January 1, 2020 and June 30, 2020, the Company’s outstanding contract asset balance was $2.8 million and $1.0 million, respectively, which is included in other receivables on the Condensed Consolidated Balance Sheets as of December 31, 2019 and June 30, 2020. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets as of June 30, 2020 and January 1, 2020 using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to uncollectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0001564590-20-038237:notes:204]
No allowance for credit loss was recorded on the implementation date or during the three and six months ended June 30, 2020 related to contract assets.

[0001564590-20-038237:notes:205]
The Company is the lessor in sales-type lease arrangements for network equipment. As of January 1, 2020 and June 30, 2020, the Company’s outstanding net investment in sales-type leases was $1.6 million and $1.1 million, respectively, which is included in other receivables and other assets on the Condensed Consolidated Balance Sheets as of December 31, 2019 and June 30, 2020. The Company assessed the need for an allowance for credit losses related to future receivables under its outstanding sales-type leases as of June 30, 2020 and January 1, 2020 using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to uncollectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates.

[0001564590-20-038237:notes:206]
[same as prior period, unchanged from 0001564590-20-023537:notes:186]

[0001564590-20-038237:notes:207]
|  |  | Sales-Type Leases Amortized Cost Basis by Origination Year |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |  | 2017 |  |  | 2016 |  |  | Prior |  |  | Total |  |
| Payment performance |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Performing |  | $ | 43 |  |  | $ | 261 |  |  | $ | 500 |  |  | $ | 187 |  |  | $ | 127 |  |  | $ | 14 |  |  | $ | 1,132 |  |
| Non-performing |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 43 |  |  | $ | 261 |  |  | $ | 500 |  |  | $ | 187 |  |  | $ | 127 |  |  | $ | 14 |  |  | $ | 1,132 |  |

[0001564590-20-038237:notes:208]
Sales-type lease receivables are considered past due when payment has not been received based on agreed upon terms between the customer and the Company. No allowance for credit loss was recorded on the implementation date or during the three and six months ended June 30, 2020 related to sales-type leases.

[0001564590-20-038237:notes:209]
[same as prior period, unchanged from 0001564590-20-023537:notes:189]

[0001564590-20-038237:notes:210]
The Company has a secured loan receivable totaling $0.9 million as of June 30, 2020 and January 1, 2020, which originated in February 2019, and is included in long-term investments on the Condensed Consolidated Balance Sheets as of June 30, 2020 and December 31, 2019. The Company assessed the need for an allowance for credit loss related to its secured loan receivable as of June 30, 2020 and January 1, 2020 using the historical loss-rate method as well as asset-specific risks. There have been no historical losses related to this receivable. Asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect the customer’s ability to repay the loan upon maturity, such as the customer’s current financial condition, credit rating specific to the customer as determined by a third party and current overall economic conditions, as well as a Company valuation prepared by a third party which was based on reasonable and supportable forecasts as provided by management. Accrued interest receivable on the secured loan receivable, which is included in other receivables on the Condensed Consolidated Balance Sheets as of June 30, 2020 and December 31, 2019, totaled $24 thousand and $0 as of January 1, 2020 and June 30, 2020, respectively, and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election.

[0001564590-20-038237:notes:211]
No allowance for credit loss was recorded on the implementation date or during the three and six months ended June 30, 2020 related to the secured loan receivable.

[0001564590-20-038237:notes:212]
[same as prior period, unchanged from 0001564590-20-023537:notes:192]

[0001564590-20-038237:notes:213]
The Company did not have any off-balance sheet arrangements as of January 1, 2020 or June 30, 2020.

[0001564590-20-038237:notes:214]
[same as prior period, unchanged from 0001564590-20-023537:notes:194]

[0001564590-20-038237:notes:215]
As of January 1, 2020 and June 30, 2020, the Company’s available-for-sale debt securities totaled $37.7 million and $42.6 million, respectively. These securities were analyzed at the individual investment level, by CUSIP, to limit credit losses, if applicable, to reflect only the amount by which the fair value of the security was less than its amortized cost. The Company noted that, as of January 1, 2020 and June 30, 2020, there was no intent to sell any of its available-for-sale debt securities before maturity, and, therefore, the Company assessed the need for an allowance for each of its available-for-sale debt securities in which the fair value was less than its amortized cost as of January 1, 2020 and June 30, 2020. Accrued interest receivable on available-for-sale debt securities, which is included in other receivables on the Condensed Consolidated Balance Sheets as of June 30, 2020 and December 31, 2019, totaled $0.1 million as of January 1, 2020 and June 30, 2020, and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election. Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income (Loss).

[0001564590-20-038237:notes:216]
The Company had 43 positions in available-for-sale debt securities that were in an unrealized loss position as of June 30, 2020, which are presented in the table below:

[0001564590-20-038237:notes:217]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  |  | 865 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 865 |  |  |  | (1 | ) |
| Municipal fixed-rate bonds |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Asset-backed bonds |  |  | 331 |  |  |  | (4 | ) |  |  | — |  |  |  | — |  |  |  | 331 |  |  |  | (4 | ) |
| Mortgage/Agency-backed bonds |  |  | 1,017 |  |  |  | (12 | ) |  |  | — |  |  |  | — |  |  |  | 1,017 |  |  |  | (12 | ) |
| U.S. government bonds |  |  | 900 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 900 |  |  |  | — |  |
| Foreign government |  |  | 75 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 75 |  |  |  | — |  |
| Commercial paper |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 3,188 |  |  | $ | (17 | ) |  | $ | — |  |  | $ | — |  |  | $ | 3,188 |  |  | $ | (17 | ) |

[0001564590-20-038237:notes:218]
[same as prior period, unchanged from 0001564590-20-023537:notes:196]

[0001564590-20-038237:notes:219]
[same as prior period, unchanged from 0001564590-20-023537:notes:197]

[0001564590-20-038237:notes:220]
[same as prior period, unchanged from 0001564590-20-023537:notes:200]

[0001564590-20-038237:notes:221]
No allowance for credit loss was recorded on the implementation date or during the three and six months ended June 30, 2020 related to the Company’s available-for-sale debt securities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-038237:notes:222]
20. RESTRUCTURING

[0001564590-20-038237:notes:223]
[same as prior period, unchanged from 0001564590-20-023537:notes:203]

[0001564590-20-038237:notes:224]
In February 2019, the Company announced the restructuring of a certain portion of its workforce predominantly in Germany, which included the closure of the Company’s office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. Voluntary early retirement was offered to certain other employees, which was announced in March 2019.

[0001564590-20-038237:notes:225]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Condensed Consolidated Balance Sheets as of June 30, 2020 and December 31, 2019, is as follows:

[0001564590-20-038237:notes:226]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (In thousands) |  | June 30, 2020 |  |  | June 30, 2020 |  |
| Balance at beginning of period |  | $ | 133 |  |  | $ | 1,568 |  |
| Plus: Amounts charged to cost and expense |  |  | 1,192 |  |  |  | 1,745 |  |
| Less: Amounts paid |  |  | (967 | ) |  |  | (2,955 | ) |
| Balance as of June 30, 2020 |  | $ | 358 |  |  | $ | 358 |  |

[0001564590-20-038237:notes:227]
[same as prior period, unchanged from 0001564590-20-023537:notes:207]

[0001564590-20-038237:notes:228]
[same as prior period, unchanged from 0001564590-20-023537:notes:208]

[0001564590-20-038237:notes:229]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Selling, general and administrative expenses |  | $ | 489 |  |  | $ | 703 |  |  | $ | 572 |  |  | $ | 1,547 |  |
| Research and development expenses |  |  | 681 |  |  |  | 647 |  |  |  | 1,117 |  |  |  | 1,231 |  |
| Cost of sales |  |  | 22 |  |  |  | 50 |  |  |  | 56 |  |  |  | 685 |  |
| Total restructuring expenses |  | $ | 1,192 |  |  | $ | 1,400 |  |  | $ | 1,745 |  |  | $ | 3,463 |  |

[0001564590-20-038237:notes:230]
[same as prior period, unchanged from 0001564590-20-023537:notes:210]

[0001564590-20-038237:notes:231]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 1,192 |  |  | $ | 541 |  |  | $ | 1,743 |  |  | $ | 825 |  |
| International |  |  | — |  |  |  | 859 |  |  |  | 2 |  |  |  | 2,638 |  |
| Total restructuring expenses |  | $ | 1,192 |  |  | $ | 1,400 |  |  | $ | 1,745 |  |  | $ | 3,463 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-20-038237:notes:232]
21. SUBSEQUENT EVENTS

[0001564590-20-038237:notes:233]
On August 5, 2020, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 20, 2020. The payment date will be September 3, 2020 in the aggregate amount of approximately $4.3 million.
