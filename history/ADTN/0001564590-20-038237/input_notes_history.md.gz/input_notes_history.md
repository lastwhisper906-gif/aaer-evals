# ADTN note change history — 0001564590-20-023537 → 0001564590-20-038237


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-08-07):
[0001564590-20-038237:note_history:1]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The lawsuit was transferred to the U.S. District Court for the Northern District of Alabama on January 7, 2020, and co-lead plaintiffs have been appointed to represent the putative class. The plaintiffs filed an amended complaint on April 30, 2020. The defendants filed a motion to dismiss the amended complaint on June 17, 2020. The plaintiffs filed an opposition brief to the defendants’ motion to dismiss on July 17, 2020. The defendants intend to file a reply to the plaintiffs’ brief on August 17, 2020. We deny the allegations in the complaint, as amended, and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.
  (was, 2020-05-08, similarity 0.9072):
[0001564590-20-023537:note_history:1]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The lawsuit was transferred to the U.S. District Court for the Northern District of Alabama on January 7, 2020, and co-lead plaintiffs have been appointed to represent the putative class. The plaintiffs filed an amended complaint on April 30, 2020. The defendants intend to file a motion to dismiss the amended complaint. We deny the allegations in the complaint, as amended, and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

- added (2020-08-07):
[0001564590-20-038237:note_history:2]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, makes similar allegations as the shareholder class action and accuses the directors and officers of breaches of fiduciary duty in connection with those allegations. On June 7, 2020, the Court entered an order staying the derivative litigation pending resolution of the motion to dismiss in the securities class action. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

- changed (2020-08-07):
[0001564590-20-038237:note_history:3]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2020 and December 31, 2019, we had commitments related to these bonds totaling $11.3 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2020-05-08, similarity 0.9897):
[0001564590-20-023537:note_history:3]
Certain contracts, customers and/or jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2020 and December 31, 2019, we had commitments related to these bonds totaling $7.6 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- added (2020-08-07):
[0001564590-20-038237:note_history:4]
In June of 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a customer. The letter of credit is secured by a pledge of collateral in the amount of $5.0 million, of which $1.2 million is included in restricted cash and $3.8 million is included in long-term investments on the Condensed Consolidated Balance Sheet as of June 30, 2020. Currently, the Company is required to maintain a minimum collateral value of approximately $5.0 million. The minimum collateral value will increase over time as the Company reaches certain milestones in the contract. The maximum collateral value required under the contract will be approximately $12.0 million, and this is expected to occur in February 2021. This minimum collateral value will increase further if the Company changes the mix of investments away from restricted cash and into other investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments or long-term investments. The obligations under the customer contract will be performed over multiple years. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of June 30, 2020, the Company was in compliance with all contractual requirements under the letter of credit.

- changed (2020-08-07):
[0001564590-20-038237:note_history:5]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been contributed as of June 30, 2020.
  (was, 2020-05-08, similarity 0.9085):
[0001564590-20-023537:note_history:5]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied as of March 31, 2020

- removed (2020-08-07):
[0001564590-20-023537:note_history:6]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, makes similar allegations as the shareholder class action and accuses the directors and officers of breaches of fiduciary duty in connection with those allegations. The Company expects that the derivative lawsuit will be stayed by the Court pending resolution of the class action. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-07):
[0001564590-20-038237:note_history:7]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multi-element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.
  (was, 2020-05-08, similarity 0.997):
[0001564590-20-023537:note_history:7]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

- changed (2020-08-07):
[0001564590-20-038237:note_history:8]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of June 30, 2020 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, current estimated credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the quarter ended June 30, 2020 resulting from these assessments, future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.
  (was, 2020-05-08, similarity 0.9343):
[0001564590-20-023537:note_history:8]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of March 31, 2020 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the quarter ended March 31, 2020 resulting from these assessments, future assessments of our current expectations at that time of the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

- added (2020-08-07):
[0001564590-20-038237:note_history:9]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company corrected this misstatement in the Unaudited Condensed Consolidated Statement of Cash Flows for the six months ended June 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management determined that these misstatements were not material to any of its previously issued financial statements on both a quantitative and qualitative basis.

- changed (2020-08-07):
[0001564590-20-038237:note_history:10]
During the first quarter of 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out-of-period adjustment in the three months ended March 31, 2020 by remeasuring the investment assets to their historical cost basis through the recording of a net investment gain of $1.5 million in the unaudited Condensed Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the long-term investment balance at its remeasured cost basis of $2.8 million to treasury stock in the unaudited Condensed Consolidated Balance Sheet as of March 31, 2020. Management has determined that this misstatement was not material to any of its previously issued financial statements and that correction of the misstatement is also not expected to be material to the 2020 annual financial results on either a quantitative or qualitative basis.
  (was, 2020-05-08, similarity 0.9794):
[0001564590-20-023537:note_history:10]
During the three months ended March 31, 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as Long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as Treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out of period adjustment in the three months ended March 31, 2020 by remeasuring the investment assets to their historical cost basis through the recording of a Net investment gain of $1.5 million in the unaudited Condensed Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the Long-term investment balance at its remeasured cost basis of $2.8 million to Treasury stock in the unaudited Condensed Consolidated Balance Sheet as of March 31, 2020. Management has determined that this misstatement was not material to any of its previously issued financial statements and that correction of the misstatement is also not expected to be material to the 2020 annual financial results on either a quantitative or qualitative basis.

- changed (2020-08-07):
[0001564590-20-038237:note_history:11]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, which clarifies that receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the standard for leases. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification Improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as providing disclosure relief for accrued interest receivables. All of these ASUs were codified as part of ASC Topic 326 and were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard on January 1, 2020, using a modified-retrospective approach and, therefore, elected to carry forward legacy disclosures for comparative periods and did not adjust the comparative period financial information. Additionally, the Company made an accounting policy election, at the class of financing receivable, not to measure the allowance for credit losses for accrued interest receivables, as the Company writes off the uncollectable accrued interest receivable by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable). The adoption of this standard did not have a material effect on our consolidated financial statements. See Note 19 for additional information.
  (was, 2020-05-08, similarity 0.9937):
[0001564590-20-023537:note_history:11]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the standard for leases. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as providing disclosure relief for accrued interest receivables. All of these ASUs were codified as part of ASC Topic 326 and were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard on January 1, 2020, using a modified-retrospective approach and, therefore, elected to carry forward legacy disclosures for comparative periods and did not adjust the comparative period financial information. Additionally, the Company made an accounting policy election, at the class of financing receivable, not to measure the allowance for credit losses for accrued interest receivables, as the Company writes off the uncollectable accrued interest receivable by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable). The adoption of this standard did not have a material effect on our consolidated financial statements. See Note 18 for additional information.

- changed (2020-08-07):
[0001564590-20-038237:note_history:12]
In August 2018, the FASB issued ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. The Company adopted ASU 2018-15 on January 1, 2020, retrospectively. The adoption of this standard resulted in a reclassification of $5.6 million from property, plant and equipment to other assets for certain previously capitalized costs related to information technology implementation projects that had not yet been placed in service on the Condensed Consolidated Balance Sheets as of June 30, 2020 and December 31, 2019. There was no impact to previously reported net cash provided by (used in) operations on the statement of cash flows and no impact to the statements of income (loss) as no portion of the capitalized asset was depreciated in prior periods.
  (was, 2020-05-08, similarity 0.9591):
[0001564590-20-023537:note_history:12]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal – Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. The Company adopted ASU 2018-15 on January 1, 2020, retrospectively. The adoption of this standard resulted in a reclassification of $5.6 million from property, plant and equipment to other assets for certain previously capitalized costs related to information technology implementation projects that had not yet been placed in service on the consolidated balance sheet as of March 31, 2020 and December 31, 2019. There was minimal impact to previously reported net cash provided by (used in) operations on the statement of cash flows and no impact to the statements of income (loss) as no portion of the capitalized asset was depreciated in prior periods.

- changed (2020-08-07):
[0001564590-20-038237:note_history:13]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Statement of Income for the three and six months ended June 30, 2019 and the Condensed Consolidated Statement of Cash Flows for six months ended June 30, 2019:
  (was, 2020-05-08, similarity 0.7706):
[0001564590-20-023537:note_history:13]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Statement of Income and Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019:

- added (2020-08-07):
[0001564590-20-038237:note_history:14]
|  |  | Three months ended June 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Income (Loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,995 |  |  | $ | — |  |  | $ | 3,995 |  |

- changed (2020-08-07):
[0001564590-20-038237:note_history:15]
|  |  | Six months ended June 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Income (Loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 4,765 |  |  | $ | — |  |  | $ | 4,765 |  |
| Condensed Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 11,007 |  |  | $ | — |  |  | $ | 11,007 |  |
  (was, 2020-05-08, similarity 0.8914):
[0001564590-20-023537:note_history:15]
|  |  | Three Months Ended March 31, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Income |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 770 |  |  | $ | — |  |  | $ | 770 |  |
| Condensed Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 9,712 |  |  | $ | — |  |  | $ | 9,712 |  |

- added (2020-08-07):
[0001564590-20-038237:note_history:16]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which will be applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss), that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.

- changed (2020-08-07):
[0001564590-20-038237:note_history:17]
In August 2018, the FASB issued ASU 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. The Company is currently evaluating the impact this guidance will have on its related disclosures.
  (was, 2020-05-08, similarity 0.9983):
[0001564590-20-023537:note_history:17]
In August 2018, the FASB issued ASU 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. The Company is currently evaluating the impact this guidance will have on its related disclosures.

- removed (2020-08-07):
[0001564590-20-023537:note_history:18]
During the three months ended June 30, 2019, it was determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company corrected this misstatement in the unaudited Condensed Consolidated Statement of Cash Flows as an out of period adjustment as of and for the six months ended June 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management had previously determined that this misstatement was not material to any of its previously issued financial statements on either a quantitative or qualitative basis.

- removed (2020-08-07):
[0001564590-20-023537:note_history:19]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. ASU 2019-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020, with early adoption permitted. The Company is currently evaluating the impact of this new standard on its consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-07):
[0001564590-20-038237:note_history:20]
As of June 30, 2020, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:
  (was, 2020-05-08, similarity 0.9705):
[0001564590-20-023537:note_history:20]
As of March 31, 2020, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

- changed (2020-08-07):
[0001564590-20-038237:note_history:21]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 13,747 |  |  | $ | 168 |  |  | $ | (1 | ) |  | $ | 13,914 |  |
| Municipal fixed-rate bonds |  |  | 2,379 |  |  |  | 21 |  |  |  | — |  |  |  | 2,400 |  |
| Asset-backed bonds |  |  | 7,600 |  |  |  | 86 |  |  |  | (4 | ) |  |  | 7,682 |  |
| Mortgage/Agency-backed bonds |  |  | 7,944 |  |  |  | 152 |  |  |  | (12 | ) |  |  | 8,084 |  |
| U.S. government bonds |  |  | 7,935 |  |  |  | 211 |  |  |  | — |  |  |  | 8,146 |  |
| Foreign government bonds |  |  | 540 |  |  |  | — |  |  |  | — |  |  |  | 540 |  |
| Commercial paper |  |  | 1,120 |  |  |  | 4 |  |  |  | — |  |  |  | 1,124 |  |
| Variable-rate demand notes |  |  | 300 |  |  |  | — |  |  |  | — |  |  |  | 300 |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Available-for-sale debt securities held at fair value |  | $ | 42,007 |  |  | $ | 642 |  |  | $ | (17 | ) |  | $ | 42,632 |  |
  (was, 2020-05-08, similarity 0.8564):
[0001564590-20-023537:note_history:21]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 8,967 |  |  | $ | 43 |  |  | $ | (87 | ) |  | $ | 8,923 |  |
| Municipal fixed-rate bonds |  |  | 931 |  |  |  | 3 |  |  |  | — |  |  |  | 934 |  |
| Asset-backed bonds |  |  | 6,052 |  |  |  | 17 |  |  |  | (76 | ) |  |  | 5,993 |  |
| Mortgage/Agency-backed bonds |  |  | 8,389 |  |  |  | 140 |  |  |  | (62 | ) |  |  | 8,467 |  |
| U.S. government bonds |  |  | 12,788 |  |  |  | 319 |  |  |  | (6 | ) |  |  | 13,101 |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,569 |  |  | $ | 522 |  |  | $ | (231 | ) |  | $ | 37,860 |  |

- changed (2020-08-07):
[0001564590-20-038237:note_history:22]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,304 |  |  | $ | 80 |  |  | $ | — |  |  | $ | 9,384 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | 930 |  |
| Asset-backed bonds |  |  | 6,867 |  |  |  | 26 |  |  |  | (3 | ) |  |  | 6,890 |  |
| Mortgage/Agency-backed bonds |  |  | 6,944 |  |  |  | 26 |  |  |  | (8 | ) |  |  | 6,962 |  |
| U.S. government bonds |  |  | 12,311 |  |  |  | 21 |  |  |  | (9 | ) |  |  | 12,323 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (1 | ) |  |  | 371 |  |
| Variable-rate demand notes |  |  | 800 |  |  |  | — |  |  |  | — |  |  |  | 800 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,528 |  |  | $ | 153 |  |  | $ | (21 | ) |  | $ | 37,660 |  |
  (was, 2020-05-08, similarity 0.9986):
[0001564590-20-023537:note_history:22]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,304 |  |  | $ | 80 |  |  | $ | — |  |  | $ | 9,384 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | 930 |  |
| Asset-backed bonds |  |  | 6,867 |  |  |  | 26 |  |  |  | (3 | ) |  |  | 6,890 |  |
| Mortgage/Agency-backed bonds |  |  | 6,944 |  |  |  | 26 |  |  |  | (8 | ) |  |  | 6,962 |  |
| U.S. government bonds |  |  | 12,311 |  |  |  | 21 |  |  |  | (9 | ) |  |  | 12,323 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (1 | ) |  |  | 371 |  |
| Variable rate demand notes |  |  | 800 |  |  |  | — |  |  |  | — |  |  |  | 800 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,528 |  |  | $ | 153 |  |  | $ | (21 | ) |  | $ | 37,660 |  |

- changed (2020-08-07):
[0001564590-20-038237:note_history:23]
As of June 30, 2020, contractual maturities related to debt securities and other investments were as follows:
  (was, 2020-05-08, similarity 0.9565):
[0001564590-20-023537:note_history:23]
As of March 31, 2020, contractual maturities related to debt securities and other investments were as follows:

- added (2020-08-07):
[0001564590-20-038237:note_history:24]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage/ Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Commercial paper |  |  | Variable-rate demand notes |  |  | Other |  |
| Less than one year |  | $ | 5,441 |  |  | $ | 738 |  |  | $ | 465 |  |  | $ | 146 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,124 |  |  | $ | — |  |  | $ | 442 |  |
| One to two years |  |  | 2,926 |  |  |  | 528 |  |  |  | 465 |  |  |  | 603 |  |  |  | 1,638 |  |  |  | 75 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 5,547 |  |  |  | 757 |  |  |  | 1,141 |  |  |  | 1,528 |  |  |  | 6,065 |  |  |  | 465 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Three to five years |  |  | — |  |  |  | 377 |  |  |  | 3,932 |  |  |  | — |  |  |  | 443 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 982 |  |  |  | 1,890 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 697 |  |  |  | 3,917 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 300 |  |  |  | — |  |
| Total |  | $ | 13,914 |  |  | $ | 2,400 |  |  | $ | 7,682 |  |  | $ | 8,084 |  |  | $ | 8,146 |  |  | $ | 540 |  |  | $ | 1,124 |  |  | $ | 300 |  |  | $ | 442 |  |

- added (2020-08-07):
[0001564590-20-038237:note_history:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Gross realized gains on debt securities |  | $ | 190 |  |  | $ | 8 |  |  | $ | 233 |  |  | $ | 49 |  |
| Gross realized losses on debt securities |  |  | (19 | ) |  |  | (14 | ) |  |  | (39 | ) |  |  | (33 | ) |
| Total gain recognized, net |  | $ | 171 |  |  | $ | (6 | ) |  | $ | 194 |  |  | $ | 16 |  |

- changed (2020-08-07):
[0001564590-20-038237:note_history:26]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended June 30, 2020.
  (was, 2020-05-08, similarity 0.987):
[0001564590-20-023537:note_history:26]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2020.

- changed (2020-08-07):
[0001564590-20-038237:note_history:27]
During the three months ended March 31, 2019, an outstanding note receivable of $4.3 million was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment, which represented a non-cash investing activity. We elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. During the six months ended June 30, 2020, an impairment charge of $1.6 million was recorded related to this equity investment, which is included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $1.8 million as of June 30, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of June 30, 2020 and December 31, 2019, and represented a non-cash investing activity during the six months ended June 30, 2019. No impairment charge was recognized related to the note receivable as it is a secured loan.
  (was, 2020-05-08, similarity 0.9596):
[0001564590-20-023537:note_history:27]
During the three months ended March 31, 2019, an outstanding note receivable of $4.3 million was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment, which represented a non-cash investing activity. We elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. During the three months ended March 31, 2020, an impairment charge of $1.6 million was recorded related to this equity investment, which is included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $1.8 million as of March 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of March 31, 2020 and December 31, 2019, and represented a non-cash operating activity during the three months ended March 31, 2019. No impairment charge was recognized related to the note receivable as it is a secured loan.

- changed (2020-08-07):
[0001564590-20-038237:note_history:28]
Realized and unrealized gains and losses related to marketable equity securities for the three and six months ended June 30, 2020 and 2019 were as follows:
  (was, 2020-05-08, similarity 0.9408):
[0001564590-20-023537:note_history:28]
Realized and unrealized gains and losses related to marketable equity securities for the three months ended March 31, 2020 and 2019 were as follows:

- added (2020-08-07):
[0001564590-20-038237:note_history:29]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Realized gains (losses) on equity securities sold |  | $ | 328 |  |  | $ | (49 | ) |  | $ | (2,108 | ) |  | $ | (63 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 9,353 |  |  |  | 2,540 |  |  |  | 889 |  |  |  | 8,458 |  |
| Total gain (loss) recognized, net |  | $ | 9,681 |  |  | $ | 2,491 |  |  | $ | (1,219 | ) |  | $ | 8,395 |  |

- changed (2020-08-07):
[0001564590-20-038237:note_history:30]
|  |  |  |  |  |  | Fair Value Measurements as of June 30, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,697 |  |  | $ | 1,697 |  |  | $ | — |  |  | $ | — |  |
| U.S. government securities |  |  | 1,250 |  |  |  | 1,250 |  |  |  | — |  |  |  | — |  |
| Commercial paper |  |  | 100 |  |  |  | — |  |  |  | 100 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,914 |  |  |  | — |  |  |  | 13,914 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,400 |  |  |  | — |  |  |  | 2,400 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,682 |  |  |  | — |  |  |  | 7,682 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,084 |  |  |  | — |  |  |  | 8,084 |  |  |  | — |  |
| U.S. government bonds |  |  | 8,146 |  |  |  | 8,146 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 540 |  |  |  | — |  |  |  | 540 |  |  |  | — |  |
| Commercial paper |  |  | 1,124 |  |  |  | — |  |  |  | 1,124 |  |  |  | — |  |
| Variable-rate demand notes |  |  | 300 |  |  |  | — |  |  |  | 300 |  |  |  | — |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,116 |  |  |  | 26,116 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,468 |  |  |  | 20,468 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,223 |  |  |  | 1,223 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 93,486 |  |  | $ | 58,900 |  |  | $ | 34,144 |  |  | $ | 442 |  |
  (was, 2020-05-08, similarity 0.6881):
[0001564590-20-023537:note_history:30]
|  |  |  |  |  |  | Fair Value Measurements as of March 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,826 |  |  | $ | 4,826 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 500 |  |  |  | — |  |  |  | 500 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 8,923 |  |  |  | — |  |  |  | 8,923 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 934 |  |  |  | — |  |  |  | 934 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,993 |  |  |  | — |  |  |  | 5,993 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,467 |  |  |  | — |  |  |  | 8,467 |  |  |  | — |  |
| U.S. government bonds |  |  | 13,101 |  |  |  | 13,101 |  |  |  | — |  |  |  | — |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 24,823 |  |  |  | 24,823 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 17,349 |  |  |  | 17,349 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,106 |  |  |  | 2,106 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 87,464 |  |  | $ | 62,205 |  |  | $ | 24,817 |  |  | $ | 442 |  |

- changed (2020-08-07):
[0001564590-20-038237:note_history:31]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,309 |  |  | $ | 1,309 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,384 |  |  |  | — |  |  |  | 9,384 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,890 |  |  |  | — |  |  |  | 6,890 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 6,962 |  |  |  | — |  |  |  | 6,962 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,323 |  |  |  | 12,323 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 371 |  |  |  | — |  |  |  | 371 |  |  |  | — |  |
| Variable-rate demand notes |  |  | 800 |  |  |  | — |  |  |  | 800 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,501 |  |  |  | 35,501 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 298 |  |  |  | 298 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,698 |  |  |  | 21,698 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,442 |  |  |  | 2,442 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 98,908 |  |  | $ | 73,571 |  |  | $ | 25,337 |  |  | $ | — |  |
  (was, 2020-05-08, similarity 0.9993):
[0001564590-20-023537:note_history:31]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,309 |  |  | $ | 1,309 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,384 |  |  |  | — |  |  |  | 9,384 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,890 |  |  |  | — |  |  |  | 6,890 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 6,962 |  |  |  | — |  |  |  | 6,962 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,323 |  |  |  | 12,323 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 371 |  |  |  | — |  |  |  | 371 |  |  |  | — |  |
| Variable rate demand notes |  |  | 800 |  |  |  | — |  |  |  | 800 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,501 |  |  |  | 35,501 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 298 |  |  |  | 298 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,698 |  |  |  | 21,698 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,442 |  |  |  | 2,442 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 98,908 |  |  | $ | 73,571 |  |  | $ | 25,337 |  |  | $ | — |  |

- removed (2020-08-07):
[0001564590-20-023537:note_history:32]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Other |  |
| Less than one year |  | $ | 3,274 |  |  | $ | — |  |  | $ | 101 |  |  | $ | — |  |  | $ | 61 |  |  | $ | 442 |  |
| One to two years |  |  | 3,702 |  |  |  | 934 |  |  |  | 389 |  |  |  | 584 |  |  |  | 5,376 |  |  |  | — |  |
| Two to three years |  |  | 1,947 |  |  |  | — |  |  |  | 1,559 |  |  |  | 1,769 |  |  |  | 7,285 |  |  |  | — |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 2,174 |  |  |  | 107 |  |  |  | 379 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,505 |  |  |  | 1,655 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 265 |  |  |  | 4,352 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 8,923 |  |  | $ | 934 |  |  | $ | 5,993 |  |  | $ | 8,467 |  |  | $ | 13,101 |  |  | $ | 442 |  |

- removed (2020-08-07):
[0001564590-20-023537:note_history:33]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Gross realized gains on debt securities |  | $ | 43 |  |  | $ | 41 |  |
| Gross realized losses on debt securities |  |  | (20 | ) |  |  | (19 | ) |
| Total gain recognized, net |  | $ | 23 |  |  | $ | 22 |  |

- removed (2020-08-07):
[0001564590-20-023537:note_history:34]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Realized losses on equity securities sold |  | $ | (2,436 | ) |  | $ | (14 | ) |
| Unrealized gains (losses) on equity securities held |  |  | (8,464 | ) |  |  | 5,918 |  |
| Total gain (loss) recognized, net |  | $ | (10,900 | ) |  | $ | 5,904 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-07):
[0001564590-20-038237:note_history:35]
The following tables disaggregate revenue by reportable segment and revenue category for the three and six months ended June 30, 2020 and 2019:
  (was, 2020-05-08, similarity 0.9278):
[0001564590-20-023537:note_history:35]
The following table disaggregates revenue by reportable segment and revenue category for the three months ended March 31, 2020 and 2019:

- changed (2020-08-07):
[0001564590-20-038237:note_history:36]
|  |  | Three Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,721 |  |  | $ | 13,055 |  |  | $ | 82,776 |  |  | $ | 96,262 |  |  | $ | 13,159 |  |  | $ | 109,421 |  |
| Subscriber Solutions & Experience |  |  | 38,081 |  |  |  | 2,312 |  |  |  | 40,393 |  |  |  | 38,444 |  |  |  | 2,058 |  |  |  | 40,502 |  |
| Traditional & Other Products |  |  | 3,521 |  |  |  | 2,025 |  |  |  | 5,546 |  |  |  | 4,461 |  |  |  | 2,007 |  |  |  | 6,468 |  |
| Total |  | $ | 111,323 |  |  | $ | 17,392 |  |  | $ | 128,715 |  |  | $ | 139,167 |  |  | $ | 17,224 |  |  | $ | 156,391 |  |
  (was, 2020-05-08, similarity 0.9652):
[0001564590-20-023537:note_history:36]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 53,055 |  |  | $ | 12,911 |  |  | $ | 65,966 |  |  | $ | 85,673 |  |  | $ | 14,105 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience |  |  | 39,983 |  |  |  | 2,196 |  |  |  | 42,179 |  |  |  | 34,719 |  |  |  | 2,034 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 4,334 |  |  |  | 2,044 |  |  |  | 6,378 |  |  |  | 5,430 |  |  |  | 1,830 |  |  |  | 7,260 |  |
| Total |  | $ | 97,372 |  |  | $ | 17,151 |  |  | $ | 114,523 |  |  | $ | 125,822 |  |  | $ | 17,969 |  |  | $ | 143,791 |  |

- changed (2020-08-07):
[0001564590-20-038237:note_history:37]
|  |  | Six Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 122,776 |  |  | $ | 25,966 |  |  | $ | 148,742 |  |  | $ | 181,935 |  |  | $ | 27,264 |  |  | $ | 209,199 |  |
| Subscriber Solutions & Experience |  |  | 78,064 |  |  |  | 4,508 |  |  |  | 82,572 |  |  |  | 73,163 |  |  |  | 4,092 |  |  |  | 77,255 |  |
| Traditional & Other Products |  |  | 7,855 |  |  |  | 4,069 |  |  |  | 11,924 |  |  |  | 9,891 |  |  |  | 3,837 |  |  |  | 13,728 |  |
| Total |  | $ | 208,695 |  |  | $ | 34,543 |  |  | $ | 243,238 |  |  | $ | 264,989 |  |  | $ | 35,193 |  |  | $ | 300,182 |  |
  (was, 2020-05-08, similarity 0.6052):
[0001564590-20-023537:note_history:37]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Access & Aggregation |  | $ | 65,966 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience |  |  | 42,179 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 6,378 |  |  |  | 7,260 |  |
| Total |  | $ | 114,523 |  |  | $ | 143,791 |  |

- changed (2020-08-07):
[0001564590-20-038237:note_history:38]
The table below presents sales information by category for the three and six months ended June 30, 2020 and 2019:
  (was, 2020-05-08, similarity 0.9163):
[0001564590-20-023537:note_history:38]
The table below presents sales information by category for the three months ended March 31, 2020 and 2019:

- added (2020-08-07):
[0001564590-20-038237:note_history:39]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Access & Aggregation |  | $ | 82,776 |  |  | $ | 109,421 |  |  | $ | 148,742 |  |  | $ | 209,199 |  |
| Subscriber Solutions & Experience |  |  | 40,393 |  |  |  | 40,502 |  |  |  | 82,572 |  |  |  | 77,255 |  |
| Traditional & Other Products |  |  | 5,546 |  |  |  | 6,468 |  |  |  | 11,924 |  |  |  | 13,728 |  |
| Total |  | $ | 128,715 |  |  | $ | 156,391 |  |  | $ | 243,238 |  |  | $ | 300,182 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-07):
[0001564590-20-038237:note_history:40]
In addition to our reportable segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.
  (was, 2020-05-08, similarity 0.9816):
[0001564590-20-023537:note_history:40]
In addition to our reporting segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

- changed (2020-08-07):
[0001564590-20-038237:note_history:41]
The following tables disaggregate revenue by reportable segment and revenue category for the three and six months ended June 30, 2020 and 2019:
  (was, 2020-05-08, similarity 0.9278):
[0001564590-20-023537:note_history:41]
The following table disaggregates revenue by reportable segment and revenue category for the three months ended March 31, 2020 and 2019:

- changed (2020-08-07):
[0001564590-20-038237:note_history:42]
|  |  | Three Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,721 |  |  | $ | 13,055 |  |  | $ | 82,776 |  |  | $ | 96,262 |  |  | $ | 13,159 |  |  | $ | 109,421 |  |
| Subscriber Solutions & Experience |  |  | 38,081 |  |  |  | 2,312 |  |  |  | 40,393 |  |  |  | 38,444 |  |  |  | 2,058 |  |  |  | 40,502 |  |
| Traditional & Other Products |  |  | 3,521 |  |  |  | 2,025 |  |  |  | 5,546 |  |  |  | 4,461 |  |  |  | 2,007 |  |  |  | 6,468 |  |
| Total |  | $ | 111,323 |  |  | $ | 17,392 |  |  | $ | 128,715 |  |  | $ | 139,167 |  |  | $ | 17,224 |  |  | $ | 156,391 |  |
  (was, 2020-05-08, similarity 0.9652):
[0001564590-20-023537:note_history:42]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 53,055 |  |  | $ | 12,911 |  |  | $ | 65,966 |  |  | $ | 85,673 |  |  | $ | 14,105 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience |  |  | 39,983 |  |  |  | 2,196 |  |  |  | 42,179 |  |  |  | 34,719 |  |  |  | 2,034 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 4,334 |  |  |  | 2,044 |  |  |  | 6,378 |  |  |  | 5,430 |  |  |  | 1,830 |  |  |  | 7,260 |  |
| Total |  | $ | 97,372 |  |  | $ | 17,151 |  |  | $ | 114,523 |  |  | $ | 125,822 |  |  | $ | 17,969 |  |  | $ | 143,791 |  |

- added (2020-08-07):
[0001564590-20-038237:note_history:43]
|  |  | Six Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 122,776 |  |  | $ | 25,966 |  |  | $ | 148,742 |  |  | $ | 181,935 |  |  | $ | 27,264 |  |  | $ | 209,199 |  |
| Subscriber Solutions & Experience |  |  | 78,064 |  |  |  | 4,508 |  |  |  | 82,572 |  |  |  | 73,163 |  |  |  | 4,092 |  |  |  | 77,255 |  |
| Traditional & Other Products |  |  | 7,855 |  |  |  | 4,069 |  |  |  | 11,924 |  |  |  | 9,891 |  |  |  | 3,837 |  |  |  | 13,728 |  |
| Total |  | $ | 208,695 |  |  | $ | 34,543 |  |  | $ | 243,238 |  |  | $ | 264,989 |  |  | $ | 35,193 |  |  | $ | 300,182 |  |

- changed (2020-08-07):
[0001564590-20-038237:note_history:44]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration of greater than one year. As of June 30, 2020, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $16.0 million and $13.6 million as of June 30, 2020 and December 31, 2019, respectively. The Company expects to recognize 62% of the $16.0 million as of June 30, 2020 over the next 12 months, with the remainder to be recognized thereafter.
  (was, 2020-05-08, similarity 0.9786):
[0001564590-20-023537:note_history:44]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration greater than one year. As of March 31, 2020, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts we are entitled to invoice which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $14.3 million and $13.6 million as of March 31, 2020 and December 31, 2019, respectively. The Company expects to recognize 69% of the $14.3 million as of March 31, 2020 over the next 12 months with the remainder to be recognized thereafter.

- changed (2020-08-07):
[0001564590-20-038237:note_history:45]
| (In thousands) |  | June 30, 2020 |  |  | December 31, 2019 |  |
| Accounts receivable, net |  | $ | 95,335 |  |  | $ | 90,531 |  |
| Contract assets(1) |  | $ | 1,028 |  |  | $ | 2,812 |  |
| Unearned revenue |  | $ | 12,090 |  |  | $ | 11,963 |  |
| Non-current unearned revenue |  | $ | 6,166 |  |  | $ | 6,012 |  |
  (was, 2020-05-08, similarity 0.9823):
[0001564590-20-023537:note_history:45]
| (In thousands) |  | March 31, 2020 |  |  | December 31, 2019 |  |
| Accounts receivable, net |  | $ | 86,465 |  |  | $ | 90,531 |  |
| Contract assets(1) |  | $ | 1,354 |  |  | $ | 2,812 |  |
| Unearned revenue |  | $ | 12,465 |  |  | $ | 11,963 |  |
| Non-current unearned revenue |  | $ | 4,476 |  |  | $ | 6,012 |  |

- changed (2020-08-07):
[0001564590-20-038237:note_history:46]
Of the outstanding unearned revenue balances as of December 31, 2019 and December 31, 2018, $2.4 million and $3.6 million were recognized as revenue during the three months ended June 30, 2020 and 2019, respectively, and $8.1 million and $10.5 million were recognized as revenue during the six months ended June 30, 2020 and 2019, respectively.
  (was, 2020-05-08, similarity 0.6996):
[0001564590-20-023537:note_history:46]
Of the outstanding unearned revenue balances as of December 31, 2019 and December 31, 2018, $5.7 million and $6.9 million was recognized as revenue during the three months ended March 31, 2020 and March 31, 2019, respectively.

- removed (2020-08-07):
[0001564590-20-023537:note_history:47]
See Note 15 for additional information on reportable segments.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-08-07):
[0001564590-20-038237:note_history:48]
On August 5, 2020, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 20, 2020. The payment date will be September 3, 2020 in the aggregate amount of approximately $4.3 million.
  (was, 2020-05-08, similarity 0.9468):
[0001564590-20-023537:note_history:48]
On May 6, 2020, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 21, 2020. The payment date will be June 4, 2020 in the aggregate amount of approximately $4.3 million.
