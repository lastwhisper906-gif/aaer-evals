# ADTN 8-K — 0001564590-20-037168 filed 2020-08-06

## item codes, every 8-K on or before 2020-08-07

- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2020-08-07

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-037168:8k_2_02:1]
EX-99.1
2
adtn-ex991_6.htm
EX-99.1

[0001564590-20-037168:8k_2_02:2]
adtn-ex991_6.htm

[0001564590-20-037168:8k_2_02:3]
EXHIBIT 99.1

[0001564590-20-037168:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the Second Quarter of 2020 and Declares Quarterly Cash Dividend

[0001564590-20-037168:8k_2_02:5]
August 5, 2020

[0001564590-20-037168:8k_2_02:6]
HUNTSVILLE, Ala. — (BUSINESS WIRE) — August 5, 2020 -- ADTRAN, Inc. (NASDAQ:ADTN) (“ADTRAN” or the “Company”) today announced financial results for the second quarter of 2020. For the quarter, revenue was $128.7 million.  Net income for the second quarter of 2020 was $0.8 million and earnings per share, assuming dilution, was $0.02 per share. Non-GAAP net income was $1.6 million and non-GAAP earnings per share, assuming dilution, was $0.04 per share. Non-GAAP net income and non-GAAP earnings per share exclude stock-based compensation expense, acquisition-related expenses, amortizations and adjustments, restructuring expenses, amortization of pension actuarial losses, valuation allowance related to our deferred tax assets, non-cash deferred compensation, and other one-time adjustments. The reconciliations between GAAP net income and earnings per share to non-GAAP net income and non-GAAP earnings per share are set forth in the table provided below.

[0001564590-20-037168:8k_2_02:7]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “The world has changed dramatically since the start of 2020, altering the way that we live and work. As we adapt to this new environment, it has increased the importance of remote working, virtual classrooms and telemedicine. This has clearly defined the necessity for a robust, high-capacity fiber broadband network across all geographies and social demographics. During the quarter, these factors contributed to strong revenue growth from Tier 2 and Tier 3 service providers in the US. We also saw strength internationally from the Asia-Pacific region. We added 33 new customers and announced major awards with multiple Tier 1 operators for our next generation fiber access solutions and our Mosaic Cloud Platform. Our overall performance for the quarter was in line with our expectations and we are well-positioned to lead the paradigm shift to the software-defined next generation fiber access platform of the future.”

[0001564590-20-037168:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash dividend for the second quarter of 2020. The quarterly cash dividend is $0.09 per common share, to be paid to the Company’s stockholders of record as of the close of business on August 20, 2020. The payment date will be September 3, 2020.

[0001564590-20-037168:8k_2_02:9]
The Company confirmed that it will hold a conference call to discuss its second quarter results on Thursday, August 6, 2020, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, simply visit ADTRAN’s Investor Relations site at www.adtran.com/investor approximately 10 minutes prior to the start of the call, click on the event “ADTRAN releases 2nd Quarter Financial Results and Conference Call”, and click on the Webcast link.

[0001564590-20-037168:8k_2_02:10]
An online replay of the Company’s conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or email at investor.relations@adtran.com.

[0001564590-20-037168:8k_2_02:11]
At ADTRAN, we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help communications service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking. Find more at ADTRAN.com, LinkedIn and Twitter.

[0001564590-20-037168:8k_2_02:12]
This press release contains forward-looking statements, generally identified by the use of words such as “believe,” “expect,” “intend,” “estimate,” “anticipate,” “will,” “may,” “could” and similar expressions, which forward-looking statements reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including: (i) those risks and uncertainties related to the continued spread and extent of the impact of the COVID-19 global pandemic, including the speed, depth, geographic reach and duration of the spread, which could lead to a decrease in demand for the Company’s products and services, and which has disrupted, and could lead to further disruptions in, the Company’s supply chain, adversely impacting the operations and financial condition of the Company and its customers; actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for employees, which may delay the timing of some orders and expected deliveries and which may impact the Company’s ability to mitigate inefficiencies, delays and additional costs in the Company’s product development, sales, marketing and customer service efforts; the legal, regulatory and administrative developments that occur at the federal, state and local levels and in foreign jurisdictions in response to the pandemic, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns; potential disruptions, breaches, or other incidents affecting the proper operation, availability or security of the Company’s or its partners’ information systems; declines in revenues due to declining customer demand and deteriorating macroeconomic conditions; potential

[0001564590-20-037168:8k_2_02:13]
increased expenses related to labor, raw materials, freight or other expenditures; the impact of the COVID-19 pandemic on the Company’s liquidity, as well as risks associated with disruptions in the financial markets and the business of financial institutions as a result of the COVID-19 pandemic which could impact the Company from a financial perspective; (ii) those risks and uncertainties related to evolving U.S. and foreign laws and regulations regarding privacy, data protection and other matters, including uncertainty and potential additional compliance obligations arising from the Court of Justice of the European Union’s recent issuance of a decision that invalidated the EU-U.S. Privacy Shield framework as a basis for transfers of personal data from the EU to the U.S.; and (iii) the other risks detailed in the Company’s Annual Report on Form 10-K for the year ended December 31, 2019 and in the Company’s Quarterly Report on Form 10-Q for the quarter ended March 31, 2020. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-20-037168:8k_2_02:14]
To provide additional transparency, we have disclosed in the table below non-GAAP operating income, which has been reconciled to operating income (loss), and non-GAAP net income and non-GAAP earnings per share - basic and diluted, which have been reconciled to net income and earnings per share - basic and diluted, in each case as reported based on Generally Accepted Accounting Principles in the United States (“U.S. GAAP”). These non-GAAP financial measures exclude certain items which management believes are not reflective of the ongoing operating performance of the business. We believe this information is useful in providing period-to-period comparisons of the results of our ongoing operations. Additionally, these measures are used by management in our ongoing planning and annual budgeting processes. The presentation of non-GAAP operating income, non-GAAP net income and non-GAAP earnings per share - basic and diluted, when combined with the U.S. GAAP presentation of operating income (loss), net income and earnings per share - basic and diluted, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0001564590-20-037168:8k_2_02:15]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, U.S. GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under U.S. GAAP. Additionally, our calculation of non-GAAP operating income, non-GAAP net income and non-GAAP earnings per share - basic and diluted, may not be comparable to similar measures calculated by other companies.

[0001564590-20-037168:8k_2_02:16]
Condensed Consolidated Balance Sheets

[0001564590-20-037168:8k_2_02:17]
(Unaudited)

[0001564590-20-037168:8k_2_02:18]
(In thousands)

[0001564590-20-037168:8k_2_02:19]
|  | June 30, |  |  | December 31, |  |
|  | 2020 |  |  | 2019 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 69,059 |  |  | $ | 73,773 |  |
| Restricted cash |  | 1,186 |  |  |  | — |  |
| Short-term investments |  | 9,033 |  |  |  | 33,243 |  |
| Accounts receivable, net |  | 95,335 |  |  |  | 90,531 |  |
| Other receivables |  | 26,026 |  |  |  | 16,566 |  |
| Inventory |  | 106,131 |  |  |  | 98,305 |  |
| Prepaid expenses and other current assets |  | 8,104 |  |  |  | 7,892 |  |
| Total Current Assets |  | 314,874 |  |  |  | 320,310 |  |
| Property, plant and equipment, net |  | 65,194 |  |  |  | 68,086 |  |
| Deferred tax assets, net |  | 7,573 |  |  |  | 7,561 |  |
| Goodwill |  | 6,968 |  |  |  | 6,968 |  |
| Intangibles, net |  | 25,455 |  |  |  | 27,821 |  |
| Other assets |  | 18,225 |  |  |  | 19,883 |  |
| Long-term investments |  | 84,383 |  |  |  | 94,489 |  |
| Total Assets | $ | 522,672 |  |  | $ | 545,118 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 62,465 |  |  | $ | 44,870 |  |
| Bonds payable |  | — |  |  |  | 24,600 |  |
| Unearned revenue |  | 12,090 |  |  |  | 11,963 |  |
| Accrued expenses and other liabilities |  | 12,466 |  |  |  | 13,876 |  |
| Accrued wages and benefits |  | 17,683 |  |  |  | 13,890 |  |
| Income tax payable, net |  | 2,450 |  |  |  | 3,512 |  |
| Total Current Liabilities |  | 107,154 |  |  |  | 112,711 |  |
| Non-current unearned revenue |  | 6,166 |  |  |  | 6,012 |  |
| Pension liability |  | 15,649 |  |  |  | 15,886 |  |
| Deferred compensation liability |  | 21,908 |  |  |  | 21,698 |  |
| Other non-current liabilities |  | 7,601 |  |  |  | 8,385 |  |
| Total Liabilities |  | 158,478 |  |  |  | 164,692 |  |
| Stockholders' Equity |  | 364,194 |  |  |  | 380,426 |  |
| Total Liabilities and Stockholders' Equity | $ | 522,672 |  |  | $ | 545,118 |  |

[0001564590-20-037168:8k_2_02:20]
Condensed Consolidated Statements of Income (Loss)

[0001564590-20-037168:8k_2_02:21]
(Unaudited)

[0001564590-20-037168:8k_2_02:22]
(In thousands, except per share data)

[0001564590-20-037168:8k_2_02:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 111,323 |  |  | $ | 139,167 |  |  | $ | 208,695 |  |  | $ | 264,989 |  |  |
| Services & Support |  |  | 17,392 |  |  |  | 17,224 |  |  |  | 34,543 |  |  |  | 35,193 |  |  |
| Total Sales |  |  | 128,715 |  |  |  | 156,391 |  |  |  | 243,238 |  |  |  | 300,182 |  |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 64,071 |  |  |  | 80,175 |  |  |  | 115,697 |  |  |  | 150,909 |  |  |
| Services & Support |  |  | 11,172 |  |  |  | 11,201 |  |  |  | 22,469 |  |  |  | 23,646 |  |  |
| Total Cost of Sales |  |  | 75,243 |  |  |  | 91,376 |  |  |  | 138,166 |  |  |  | 174,555 |  |  |
| Gross Profit |  |  | 53,472 |  |  |  | 65,015 |  |  |  | 105,072 |  |  |  | 125,627 |  |  |
| Selling, general and administrative expenses |  |  | 30,799 |  |  |  | 33,619 |  |  |  | 57,419 |  |  |  | 68,751 |  |  |
| Research and development expenses |  |  | 28,712 |  |  |  | 32,064 |  |  |  | 58,571 |  |  |  | 63,711 |  |  |
| Gain on contingency |  |  | — |  |  |  | (1,230 | ) |  |  | — |  |  |  | (1,230 | ) |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  | 65 |  |  |  | — |  |  |
| Operating Income (Loss) |  |  | (6,039 | ) |  |  | 562 |  |  |  | (10,983 | ) |  |  | (5,605 | ) |  |
| Interest and dividend income |  |  | 331 |  |  |  | 692 |  |  |  | 687 |  |  |  | 1,283 |  |  |
| Interest expense |  |  | — |  |  |  | (127 | ) |  |  | (1 | ) |  |  | (254 | ) |  |
| Net investment gain (loss) |  |  | 9,852 |  |  |  | 2,485 |  |  |  | (1,025 | ) |  |  | 8,411 |  |  |
| Other income (expense), net |  |  | (1,757 | ) |  |  | (205 | ) |  |  | (628 | ) |  |  | 650 |  |  |
| Income (Loss) Before Income Taxes |  |  | 2,387 |  |  |  | 3,407 |  |  |  | (11,950 | ) |  |  | 4,485 |  |  |
| Income tax (expense) benefit |  |  | (1,635 | ) |  |  | 588 |  |  |  | 2,733 |  |  |  | 280 |  |  |
| Net Income (Loss) |  | $ | 752 |  |  | $ | 3,995 |  |  | $ | (9,217 | ) |  | $ | 4,765 |  |  |
| Weighted average shares outstanding – basic |  |  | 47,958 |  |  |  | 47,802 |  |  |  | 47,957 |  |  |  | 47,792 |  |  |
| Weighted average shares outstanding – diluted |  |  | 48,254 |  | (1) |  | 48,036 |  | (1) |  | 47,957 |  |  |  | 47,939 |  | (1) |
| Earnings (loss) per common share – basic |  | $ | 0.02 |  |  | $ | 0.08 |  |  | $ | (0.19 | ) |  | $ | 0.10 |  |  |
| Earnings (loss) per common share – diluted |  | $ | 0.02 |  | (1) | $ | 0.08 |  | (1) | $ | (0.19 | ) |  | $ | 0.10 |  | (1) |

[0001564590-20-037168:8k_2_02:24]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-20-037168:8k_2_02:25]
Condensed Consolidated Statements of Cash Flows

[0001564590-20-037168:8k_2_02:26]
(Unaudited)

[0001564590-20-037168:8k_2_02:27]
(In thousands)

[0001564590-20-037168:8k_2_02:28]
|  |  | Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (9,217 | ) |  | $ | 4,765 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 8,404 |  |  |  | 8,913 |  |
| Asset impairments |  |  | 65 |  |  |  | — |  |
| Amortization of net premium on available-for-sale investments |  |  | 86 |  |  |  | (57 | ) |
| Net (gain) loss on long-term investments |  |  | 1,025 |  |  |  | (8,411 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 52 |  |  |  | 58 |  |
| Gain on contingency |  |  | — |  |  |  | (1,230 | ) |
| Gain on life insurance proceeds |  |  | — |  |  |  | (1,000 | ) |
| Stock-based compensation expense |  |  | 3,446 |  |  |  | 3,313 |  |
| Deferred income taxes |  |  | (5 | ) |  |  | (1,880 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (4,727 | ) |  |  | (17,288 | ) |
| Other receivables |  |  | (9,468 | ) |  |  | 11,678 |  |
| Inventory |  |  | (7,878 | ) |  |  | 4,612 |  |
| Prepaid expenses and other assets |  |  | 1,444 |  |  |  | 4,715 |  |
| Accounts payable, net |  |  | 17,389 |  |  |  | 5,009 |  |
| Accrued expenses and other liabilities |  |  | 2,097 |  |  |  | 640 |  |
| Income taxes payable |  |  | (1,032 | ) |  |  | (2,830 | ) |
| Net cash provided by operating activities |  |  | 1,681 |  |  |  | 11,007 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (3,148 | ) |  |  | (4,307 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 63,318 |  |  |  | 24,306 |  |
| Purchases of available-for-sale investments |  |  | (31,897 | ) |  |  | (21,544 | ) |
| Acquisition of note receivable |  |  | (523 | ) |  |  | — |  |
| Life insurance proceeds received |  |  | — |  |  |  | 1,000 |  |
| Acquisition of business |  |  | — |  |  |  | 13 |  |
| Net cash provided by (used in) investing activities |  |  | 27,750 |  |  |  | (532 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | — |  |  |  | 526 |  |
| Purchases of treasury stock |  |  | — |  |  |  | (184 | ) |
| Dividend payments |  |  | (8,665 | ) |  |  | (8,604 | ) |
| Repayment of bonds payable |  |  | (24,600 | ) |  |  | — |  |
| Net cash used in financing activities |  |  | (33,265 | ) |  |  | (8,262 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | (3,834 | ) |  |  | 2,213 |  |
| Effect of exchange rate changes |  |  | 306 |  |  |  | (900 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  |  | 73,773 |  |  |  | 105,504 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 70,245 |  |  | $ | 106,817 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 198 |  |  | $ | 205 |  |

[0001564590-20-037168:8k_2_02:29]
Supplemental Information

[0001564590-20-037168:8k_2_02:30]
Reconciliation of Operating Income (Loss) to Non-GAAP Operating Income (Loss)

[0001564590-20-037168:8k_2_02:31]
(Unaudited)

[0001564590-20-037168:8k_2_02:32]
|  |  | Three Months Ended June 30, |  |  |  | Six Months ended June 30, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |  | 2020 |  |  | 2019 |  |  |
| Operating Income (Loss) |  | $ | (6,039 | ) |  | $ | 562 |  |  |  | $ | (10,983 | ) |  | $ | (5,605 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,100 |  | (1) |  | 1,506 |  | (5) |  |  | 2,457 |  | (10) |  | 3,003 |  | (14) |
| Stock-based compensation expense |  |  | 1,655 |  | (2) |  | 1,454 |  | (6) |  |  | 3,446 |  | (11) |  | 3,313 |  | (15) |
| Restructuring expenses |  |  | 1,192 |  | (3) |  | 1,400 |  | (7) |  |  | 1,745 |  | (12) |  | 3,463 |  | (16) |
| Deferred compensation adjustments |  |  | 3,433 |  | (4) |  | 683 |  | (4) |  |  | (26 | ) | (4) |  | 2,807 |  | (4) |
| Asset impairments |  |  | — |  |  |  | — |  |  |  |  | 65 |  | (13) |  | — |  |  |
| Gain on contingency |  |  | — |  |  |  | (1,230 | ) | (8) |  |  | — |  |  |  | (1,230 | ) | (8) |
| Settlement income |  |  | — |  |  |  | (746 | ) | (9) |  |  | — |  |  |  | (746 | ) | (9) |
| Non-GAAP Operating Income (Loss) |  | $ | 1,341 |  |  | $ | 3,629 |  |  |  | $ | (3,296 | ) |  | $ | 5,005 |  |  |

[0001564590-20-037168:8k_2_02:33]
(1) $0.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-037168:8k_2_02:34]
(2) $0.1 million is included in total cost of sales, $1.0 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-037168:8k_2_02:35]
(3) $0.5 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-037168:8k_2_02:36]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN, Inc. Deferred Compensation Program for Employees per ASU 2016-01, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of income.

[0001564590-20-037168:8k_2_02:37]
(5) $0.4 million is included in total cost of sales, $0.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-037168:8k_2_02:38]
(6) $0.1 million is included in total cost of sales, $0.7 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-037168:8k_2_02:39]
(7) $0.1 million is included in total cost of sales, $0.7 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-037168:8k_2_02:40]
(8) Includes gain related to unearned contingent liabilities recognized upon the acquisition of a business in November 2018.

[0001564590-20-037168:8k_2_02:41]
(9) Includes income related to certain freight forwarder claim settlements which were received during the three months ended June 30, 2019, all of which is included in total cost of sales on the consolidated statements of income.

[0001564590-20-037168:8k_2_02:42]
(10) $0.3 million is included in total cost of sales, $1.2 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-037168:8k_2_02:43]
(11) $0.2 million is included in total cost of sales, $2.0 million is included in selling, general and administrative expenses and $1.2 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-037168:8k_2_02:44]
(12) $0.1 million is included in total cost of sales, $0.5 million is included in selling, general and administrative expenses and $1.1 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-037168:8k_2_02:45]
(13) Includes abandonment of certain information technology projects.

[0001564590-20-037168:8k_2_02:46]
(14) $0.9 million is included in total cost of sales, $1.1 million is included in selling, general and administrative expenses and $1.0 is included in research and development expenses on the consolidated statements of income.

[0001564590-20-037168:8k_2_02:47]
(15) $0.2 million is included in total cost of sales, $1.7 million is included in selling, general and administrative expenses and $1.4 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-037168:8k_2_02:48]
(16) $0.7 million is included in total cost of sales, $1.5 million is included in selling, general and administrative expenses and $1.2 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-037168:8k_2_02:49]
Supplemental Information

[0001564590-20-037168:8k_2_02:50]
Reconciliation of Net Income (Loss) and Earnings (Loss) per Common Share – Basic and Diluted to Non-GAAP

[0001564590-20-037168:8k_2_02:51]
Net Income (Loss) and Non-GAAP Earnings (Loss) per Common Share – Basic and Diluted

[0001564590-20-037168:8k_2_02:52]
(Unaudited)

[0001564590-20-037168:8k_2_02:53]
|  |  | Three Months Ended June 30, |  |  |  | Six Months ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  |  | 2020 |  |  |  |  | 2019 |  |
| Net Income (Loss) |  | $ | 752 |  |  | $ | 3,995 |  |  |  | $ | (9,217 | ) |  |  |  | $ | 4,765 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,100 |  |  |  | 1,506 |  |  |  |  | 2,457 |  |  |  |  |  | 3,003 |  |
| Stock-based compensation expense |  |  | 1,655 |  |  |  | 1,454 |  |  |  |  | 3,446 |  |  |  |  |  | 3,313 |  |
| Restructuring expenses |  |  | 1,192 |  |  |  | 1,400 |  |  |  |  | 1,745 |  |  |  |  |  | 3,463 |  |
| Pension expense(1) |  |  | 235 |  |  |  | 199 |  |  |  |  | 472 |  |  |  |  |  | 402 |  |
| Deferred compensation adjustments |  |  | 445 |  |  |  | — |  |  |  |  | (1,342 | ) |  | (2) |  |  | — |  |
| Valuation allowance |  |  | (2,512 | ) |  |  | — |  |  |  |  | 3,578 |  |  |  |  |  | — |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  |  | 65 |  |  |  |  |  | — |  |
| Gain on contingency |  |  | — |  |  |  | (1,230 | ) |  |  |  | — |  |  |  |  |  | (1,230 | ) |
| Settlement income |  |  | — |  |  |  | (746 | ) |  |  |  | — |  |  |  |  |  | (746 | ) |
| Tax effect of adjustments to net income (loss) |  |  | (1,233 | ) |  |  | (714 | ) |  |  |  | (1,810 | ) |  |  |  |  | (2,238 | ) |
| Non-GAAP Net Income (Loss) |  | $ | 1,634 |  |  | $ | 5,864 |  |  |  | $ | (606 | ) |  |  |  | $ | 10,732 |  |
| Weighted average shares outstanding – basic |  |  | 47,958 |  |  |  | 47,802 |  |  |  |  | 47,957 |  |  |  |  |  | 47,792 |  |
| Weighted average shares outstanding – diluted |  |  | 48,254 |  |  |  | 48,036 |  |  |  |  | 47,957 |  |  |  |  |  | 47,939 |  |
| Earnings (loss) per common share - basic |  | $ | 0.02 |  |  | $ | 0.08 |  |  |  | $ | (0.19 | ) |  |  |  | $ | 0.10 |  |
| Earnings (loss) per common share - diluted |  | $ | 0.02 |  |  | $ | 0.08 |  |  |  | $ | (0.19 | ) |  |  |  | $ | 0.10 |  |
| Non-GAAP earnings (loss) per common share - basic |  | $ | 0.04 |  |  | $ | 0.12 |  |  |  | $ | (0.01 | ) |  |  |  | $ | 0.22 |  |
| Non-GAAP earnings (loss) per common share - diluted |  | $ | 0.04 |  |  | $ | 0.12 |  |  |  | $ | (0.01 | ) |  |  |  | $ | 0.22 |  |

[0001564590-20-037168:8k_2_02:54]
(1) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0001564590-20-037168:8k_2_02:55]
(2) Includes a non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees and a net investment gain of $1.5 million related to the out of period remeasurement to historical cost basis of certain long-term investments held in the Company's stock as part of one of these deferred compensation plans.
