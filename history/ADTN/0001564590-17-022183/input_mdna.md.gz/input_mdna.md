# ADTN MD&A — 0001564590-17-022183


## mdna

[0001564590-17-022183:mdna:1]
[same as prior period, unchanged from 0001564590-17-015623:mdna:1]

[0001564590-17-022183:mdna:2]
[same as prior period, unchanged from 0001564590-17-015623:mdna:2]

[0001564590-17-022183:mdna:3]
[same as prior period, unchanged from 0001564590-17-015623:mdna:3]

[0001564590-17-022183:mdna:4]
[same as prior period, unchanged from 0001564590-17-015623:mdna:4]

[0001564590-17-022183:mdna:5]
[same as prior period, unchanged from 0001564590-17-015623:mdna:5]

[0001564590-17-022183:mdna:6]
[same as prior period, unchanged from 0001564590-17-015623:mdna:6]

[0001564590-17-022183:mdna:7]
[same as prior period, unchanged from 0001564590-17-015623:mdna:7]

[0001564590-17-022183:mdna:8]
[same as prior period, unchanged from 0001564590-17-015623:mdna:8]

[0001564590-17-022183:mdna:9]
[same as prior period, unchanged from 0001564590-17-015623:mdna:9]

[0001564590-17-022183:mdna:10]
[same as prior period, unchanged from 0001564590-17-015623:mdna:10]

[0001564590-17-022183:mdna:11]
[same as prior period, unchanged from 0001564590-17-015623:mdna:11]

[0001564590-17-022183:mdna:12]
[same as prior period, unchanged from 0001564590-17-015623:mdna:12]

[0001564590-17-022183:mdna:13]
[same as prior period, unchanged from 0001564590-17-015623:mdna:13]

[0001564590-17-022183:mdna:14]
[same as prior period, unchanged from 0001564590-17-015623:mdna:14]

[0001564590-17-022183:mdna:15]
[same as prior period, unchanged from 0001564590-17-015623:mdna:15]

[0001564590-17-022183:mdna:16]
[same as prior period, unchanged from 0001564590-17-015623:mdna:16]

[0001564590-17-022183:mdna:17]
[same as prior period, unchanged from 0001564590-17-015623:mdna:17]

[0001564590-17-022183:mdna:18]
[same as prior period, unchanged from 0001564590-17-015623:mdna:18]

[0001564590-17-022183:mdna:19]
[same as prior period, unchanged from 0001564590-17-015623:mdna:19]

[0001564590-17-022183:mdna:20]
[same as prior period, unchanged from 0001564590-17-015623:mdna:20]

[0001564590-17-022183:mdna:21]
[same as prior period, unchanged from 0001564590-17-015623:mdna:21]

[0001564590-17-022183:mdna:22]
[same as prior period, unchanged from 0001564590-17-015623:mdna:22]

[0001564590-17-022183:mdna:23]
[same as prior period, unchanged from 0001564590-17-015623:mdna:23]

[0001564590-17-022183:mdna:24]
[same as prior period, unchanged from 0001564590-17-015623:mdna:24]

[0001564590-17-022183:mdna:25]
[same as prior period, unchanged from 0001564590-17-015623:mdna:25]

[0001564590-17-022183:mdna:26]
[same as prior period, unchanged from 0001564590-17-015623:mdna:26]

[0001564590-17-022183:mdna:27]
[same as prior period, unchanged from 0001564590-17-015623:mdna:27]

[0001564590-17-022183:mdna:28]
[same as prior period, unchanged from 0001564590-17-015623:mdna:28]

[0001564590-17-022183:mdna:29]
[same as prior period, unchanged from 0001564590-17-015623:mdna:29]

[0001564590-17-022183:mdna:30]
[same as prior period, unchanged from 0001564590-17-015623:mdna:30]

[0001564590-17-022183:mdna:31]
[same as prior period, unchanged from 0001564590-17-015623:mdna:31]

[0001564590-17-022183:mdna:32]
[same as prior period, unchanged from 0001564590-17-015623:mdna:32]

[0001564590-17-022183:mdna:33]
[same as prior period, unchanged from 0001564590-17-015623:mdna:33]

[0001564590-17-022183:mdna:34]
[same as prior period, unchanged from 0001564590-17-015623:mdna:34]

[0001564590-17-022183:mdna:35]
[same as prior period, unchanged from 0001564590-17-015623:mdna:35]

[0001564590-17-022183:mdna:36]
[same as prior period, unchanged from 0001564590-17-015623:mdna:36]

[0001564590-17-022183:mdna:37]
[same as prior period, unchanged from 0001564590-17-015623:mdna:37]

[0001564590-17-022183:mdna:38]
[same as prior period, unchanged from 0001564590-17-015623:mdna:38]

[0001564590-17-022183:mdna:39]
[same as prior period, unchanged from 0001564590-17-015623:mdna:39]

[0001564590-17-022183:mdna:40]
Sales were $185.1 million and $540.1 million for the three and nine months ended September 30, 2017, compared to $168.9 million and $473.8 million for the three and nine months ended September 30, 2016. Our gross margin increased to 46.7% in the three months ended September 30, 2017 from 44.9% in the three months ended September 30, 2016, and decreased to 45.3% in the nine months ended September 30, 2017 from 46.6% in the nine months ended September 30, 2016. Our operating income margin increased to 9.9% and 7.7% for the three and nine months ended September 30, 2017, from 6.0% and 6.4% for the three and nine months ended September 30, 2016. Net income was $15.9 million and $35.0 million for the three and nine months ended September 30, 2017, compared to $12.4 million and $27.7 million for the three and nine months ended September 30, 2016. Our effective tax rate, excluding the effect of the bargain purchase gain in 2016, decreased to 17.2% and 23.1% for the three and nine months ended September 30, 2017, from 25.9% and 34.0% for the three and nine months ended September 30, 2016.  Earnings per share, assuming dilution, were $0.33 and $0.72 for the three and nine months ended September 30, 2017, compared to $0.26 and $0.56 for the three and nine months ended September 30, 2016.

[0001564590-17-022183:mdna:41]
[same as prior period, unchanged from 0001564590-17-015623:mdna:41]

[0001564590-17-022183:mdna:42]
[same as prior period, unchanged from 0001564590-17-015623:mdna:42]

[0001564590-17-022183:mdna:43]
[same as prior period, unchanged from 0001564590-17-015623:mdna:43]

[0001564590-17-022183:mdna:44]
[same as prior period, unchanged from 0001564590-17-015623:mdna:44]

[0001564590-17-022183:mdna:45]
[same as prior period, unchanged from 0001564590-17-015623:mdna:45]

[0001564590-17-022183:mdna:46]
[same as prior period, unchanged from 0001564590-17-015623:mdna:46]

[0001564590-17-022183:mdna:47]
[same as prior period, unchanged from 0001564590-17-015623:mdna:47]

[0001564590-17-022183:mdna:48]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2017 COMPARED TO THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2016

[0001564590-17-022183:mdna:49]
[same as prior period, unchanged from 0001564590-17-015623:mdna:49]

[0001564590-17-022183:mdna:50]
Our sales increased 9.6% from $168.9 million in the three months ended September 30, 2016 to $185.1 million in the three months ended September 30, 2017, and increased 14.0% from $473.8 million in the nine months ended September 30, 2016 to $540.1 million in the nine months ended September 30, 2017. The increase in sales for the three months ended September 30, 2017 is primarily attributable to a $15.3 million increase in sales of our Access & Aggregation products, a $2.6 million increase in sales of our Customer Devices products, partially offset by a $1.7 million decrease in sales of our Traditional & Other Products. The increase in sales for the nine months ended September 30, 2017 is primarily attributable to a $78.0 million increase in sales of our Access & Aggregation products, partially offset by an $11.2 million decrease in sales of our Traditional & Other Products.

[0001564590-17-022183:mdna:51]
Network Solutions sales increased 6.7% from $136.3 million in the three months ended September 30, 2016 to $145.5 million in the three months ended September 30, 2017, and increased 11.5% from $398.7 million in the nine months ended September 30, 2016 to $444.6 million in the nine months ended September 30, 2017. The increase in sales for the three months ended September 30, 2017 is primarily attributable to an increase in sales of Access & Aggregation products and Customer Devices products, partially offset by a decrease in sales of Traditional & Other Products. The increase in sales for the nine months ended September 30, 2017 is primarily attributable to an increase in Access & Aggregation product sales, partially offset by a decrease in sales of Traditional & Other Products. The increase in sales of our Access & Aggregation products for the three and nine months ended September 30, 2017 is primarily attributable to increased VDSL2 vectoring product sales in the U.S. and European carrier markets. The increase in sales of our Customer Devices products for the three months ended September 30, 2017 is primarily attributable to increased sales of GPON ONTs. While we expect that revenues from Traditional & Other Products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-17-022183:mdna:52]
Services & Support sales increased 21.6% from $32.6 million in the three months ended September 30, 2016 to $39.6 million in the three months ended September 30, 2017, and increased 27.1% from $75.1 million in the nine months ended September 30, 2016 to $95.5 million in the nine months ended September 30, 2017. The increase in sales for the three and nine months ended September 30, 2017 is primarily attributable to an increase in network installation services for Access & Aggregation products.

[0001564590-17-022183:mdna:53]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, decreased 9.7% from $41.2 million in the three months ended September 30, 2016 to $37.2 million in the three months ended September 30, 2017, and increased 31.2% from $96.2 million in the nine months ended September 30, 2016 to $126.2 million in the nine months ended September 30, 2017. International sales, as a percentage of total sales, decreased from 24.4.% for the three months ended September 30, 2016 to 20.1%  for the three months ended September 30, 2017, and increased from 20.3% for the nine months ended September 30, 2016 to 23.4% for the nine months ended September 30, 2017. The decrease in sales for the three months ended September 30, 2017 is primarily attributable to a decrease in sales in EMEA and Latin America. The increase in sales for the nine months ended September 30, 2017 is primarily attributable to an increase in sales in EMEA, partially offset by a decrease in sales in Latin America. In the first quarter of 2017, our largest European customer resumed network upgrades, whereas, in 2016, they focused on completing network upgrades activities in regions outside of our footprint with them.

[0001564590-17-022183:mdna:54]
Our international revenues are largely focused on broadband infrastructure and are impacted by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. For example, the European Commission launched a Gigabit Society initiative, and before that, the Digital Agenda, which has provided a favorable market environment for the deployment of ultra-broadband and Gigabit network solutions. Although the overall environment and market demand for broadband service deployment in the European Union has improved, some new broadband technologies are still being reviewed for regulatory and standards completion, which may affect the timing of those technologies. In Mexico, regulatory changes have created uncertainty for customers, which has resulted in slowdowns in network buying patterns. The competitive landscape in certain international markets is also impacted by the increased presence of Asian manufacturers that seek to compete aggressively on price. A strengthening U.S. dollar can also negatively impact our revenues in regions such as Latin America, where our products are traditionally priced in U.S. dollars, while in regions where our products are sold in local currency, such as Europe, a stronger U.S. dollar can negatively impact operating income. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue to create expanded market opportunities for us, the factors described above may result in pressure on revenues and operating income. However, we do not presently foresee a significant negative impact to our financial condition based on our strong liquidity and the generally positive environment described above.

[0001564590-17-022183:mdna:55]
We recognized a positive impact to our revenues in the first half of 2017 due to our being awarded a network expansion program by a large European tier-1 customer. We anticipate that as our European and Latin American customers resume their network upgrade projects, we may experience further enhancement to our revenues. We have recently announced receipt of a new nationwide award in the Pacific region, as well as additional awards based on new ADTRAN technologies in the EMEA region that we believe will likely result in a positive impact to our revenues. Further, we expect that a resolution of the regulatory changes in Mexico may result in business with our major customer in that region returning to a more normal level.

[0001564590-17-022183:mdna:56]
[same as prior period, unchanged from 0001564590-17-015623:mdna:54]

[0001564590-17-022183:mdna:57]
As a percentage of sales, cost of sales decreased from 55.1% in the three months ended September 30, 2016 to 53.3% in the three months ended September 30, 2017, and increased from 53.4% in the nine months ended September 30, 2016 to 54.7% in the nine months ended September 30, 2017. The decrease in cost of sales as a percentage of sales for the three months ended September 30, 2017 is primarily attributable to the customer and product mix, services and support mix and a decrease in warranty expense. The increase in cost of sales as a percentage of sales for the nine months ended September 30, 2017 is primarily attributable to a regional revenue shift, customer and product mix, and services and support mix.

[0001564590-17-022183:mdna:58]
Network Solutions cost of sales, as a percent of that segment’s sales, decreased from 52.1% in the three months ended September 30, 2016 to 50.5% in the three months ended September 30, 2017, and increased from 50.9% in the nine months ended September 30, 2016 to 51.7% in the nine months ended September 30, 2017. The decrease in cost of sales as a percentage of sales for the three months ended September 30, 2017 is primarily attributable to a decrease in warranty expense. The increase in cost of sales as a percentage of sales for the nine months ended September 30, 2017 is primarily attributable to customer and product mix.

[0001564590-17-022183:mdna:59]
[same as prior period, unchanged from 0001564590-17-015623:mdna:58]

[0001564590-17-022183:mdna:60]
Services & Support cost of sales, as a percent of that segment’s sales, decreased from 67.7% in the three months ended September 30, 2016 to 63.3% in the three months ended September 30, 2017, and increased from 67.0% in the nine months ended September 30, 2016 to 68.5% in the nine months ended September 30, 2017. The decrease in cost of sales as a percentage of sales for the three months ended September 30, 2017 is primarily attributable to services and support mix. The increase in cost of sales as a percentage of sales for the nine months ended September 30, 2017 is primarily attributable to an increase in network installation services during 2017, which have higher costs, as opposed to a greater mix of maintenance and support services, which have lower costs.

[0001564590-17-022183:mdna:61]
Our Services business has experienced significant growth since 2015 as competitive pressures to expand broadband access and speeds have strained carriers’ ability to respond to customer demand. Our Services & Support revenues are comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component. Compared to our other services such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor intensive services inherently result in lower average gross margins as compared to maintenance and support services.

[0001564590-17-022183:mdna:62]
As our network planning and implementation revenues have grown and are now the largest component of our Services & Support business, our Services & Support segment gross margins have decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support revenues comprising a larger percentage of our overall revenues, and because our Services & Support gross margins are below those of the Network Solutions segment, our overall corporate gross margins have declined as that business has continued to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-17-022183:mdna:63]
[same as prior period, unchanged from 0001564590-17-015623:mdna:59]

[0001564590-17-022183:mdna:64]
Selling, general and administrative expenses increased 2.8% from $33.7 million in the three months ended September 30, 2016 to $34.7 million in the three months ended September 30, 2017, and increased 6.9% from $97.4 million in the nine months ended September 30, 2016 to $104.1 million in the nine months ended September 30, 2017. The increase in selling, general and administrative expenses for the three months ended September 30, 2017 is primarily attributable to increases in ERP implementation expenses, performance and equity-based compensation expense, and deferred compensation expense. The increase in selling, general and administrative expenses for the nine months ended September 30, 2017 is primarily attributable to increases in performance and equity-based compensation expense, deferred compensation expense, ERP implementation expense, and travel expenses.

[0001564590-17-022183:mdna:65]
As a percentage of sales, selling, general and administrative expenses decreased from 20.0% in the three months ended September 30, 2016 to 18.7% in the three months ended September 30, 2017, and decreased from 20.6% in the nine months ended September 30, 2016 to 19.3% in the nine months ended September 30, 2017. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-17-022183:mdna:66]
[same as prior period, unchanged from 0001564590-17-015623:mdna:62]

[0001564590-17-022183:mdna:67]
Research and development expenses increased 4.9% from $32.0 million in the three months ended September 30, 2016 to $33.5 million in the three months ended September 30, 2017, and increased 6.7% from $92.7 million in the nine months ended September 30, 2016 to $98.9 million in the nine month ended September 30, 2017. The increase in research and development expenses for the three months ended September 30, 2017 is primarily attributable to an increase in labor and engineering materials related to customer specific projects. The increase in research and development expenses for the nine months ended September 30, 2017 is primarily attributable to an increase in labor and engineering materials related to customer specific projects and amortization of intangibles acquired in the third quarter of 2016.

[0001564590-17-022183:mdna:68]
As a percentage of sales, research and development expenses decreased from 18.9% in the three months ended September 30, 2016 to 18.1% in the three months ended September 30, 2017, and decreased from 19.6% in the nine months ended September 30, 2016 to 18.3% in the nine months ended September 30, 2017. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001564590-17-022183:mdna:69]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts, which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001564590-17-022183:mdna:70]
[same as prior period, unchanged from 0001564590-17-015623:mdna:66]

[0001564590-17-022183:mdna:71]
Interest and dividend income increased 4.6% from $0.9 million in the three months ended September 30, 2016 to $1.0 million in the three months ended September 30, 2017, and increased 6.1% from $2.7 million in the nine months ended September 30, 2016 to $2.9 million in the nine months ended September 30, 2017. The increase in interest and dividend income for the three and nine months ended September 30, 2017 is primarily attributable to an increase in the rate of return on fixed income investments.

[0001564590-17-022183:mdna:72]
[same as prior period, unchanged from 0001564590-17-015623:mdna:68]

[0001564590-17-022183:mdna:73]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended September 30, 2016 and 2017, and $0.4 million in the nine months ended September 30, 2016 and 2017, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-17-022183:mdna:74]
[same as prior period, unchanged from 0001564590-17-015623:mdna:70]

[0001564590-17-022183:mdna:75]
Net realized investment gains decreased 23.3% from $1.3 million in the three months ended September 30, 2016 to $1.0 million in the three months ended September 30, 2017, and decreased 30.9% from $4.2 million in the nine months ended September 30, 2016 to $2.9 million in the nine months ended September 30, 2017. The decrease in net realized investment gains for the three and nine months ended September 30, 2017 is primarily attributable to decreased gains from the sale of equity securities, partially offset by increased investment gains on our deferred compensation plans. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-17-022183:mdna:76]
OTHER EXPENSE, NET

[0001564590-17-022183:mdna:77]
Other expense, net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, gains and losses on foreign exchange forward contracts, investment account management fees, and scrap raw material sales, increased 279.3% from $0.2 million of expense in the three months ended September 30, 2016 to $0.9 million of expense in the three months ended September 30, 2017, and increased 346.0% from $0.4 million of expense in the nine months ended September 30, 2016 to $1.7 million of expense in the nine months ended September 30, 2017. The increase in other expense for the three and nine months ended September 30, 2017 is primarily attributable to increased losses on our foreign exchange contracts.

[0001564590-17-022183:mdna:78]
GAIN ON BARGAIN PURCHASE OF A BUSINESS

[0001564590-17-022183:mdna:79]
Gain on bargain purchase of a business is related to our acquisition of key fiber access products, technologies and service relationships from a third party on September 13, 2016. See note 2 of Notes to Consolidated Financial Statements for additional information.

[0001564590-17-022183:mdna:80]
[same as prior period, unchanged from 0001564590-17-015623:mdna:74]

[0001564590-17-022183:mdna:81]
Our effective tax rate decreased from 34.0%, excluding the tax impact of the bargain purchase gain, in the nine months ended September 30, 2016 to 23.1% in the nine months ended September 30, 2017. The decrease in the effective tax rate between the periods is primarily attributable to additional R&D tax credits being recognized in the current quarter, an increase in stock option exercises and a greater mix of international income.

[0001564590-17-022183:mdna:82]
[same as prior period, unchanged from 0001564590-17-015623:mdna:76]

[0001564590-17-022183:mdna:83]
As a result of the above factors, net income increased $3.5 million from $12.4 million in the three months ended September 30, 2016 to $15.9 million in the three months ended September 30, 2017, and increased $7.3 million from $27.7 million in the nine months ended September 30, 2016 to $35.0 million in the nine months ended September 30, 2017.

[0001564590-17-022183:mdna:84]
As a percentage of sales, net income increased from 7.4% in the three months ended September 30, 2016 to 8.6% in the three months ended September 30, 2017, and increased from 5.8% in the nine months ended September 30, 2016 to 6.5% in the nine months ended September 30, 2017.

[0001564590-17-022183:mdna:85]
[same as prior period, unchanged from 0001564590-17-015623:mdna:79]

[0001564590-17-022183:mdna:86]
[same as prior period, unchanged from 0001564590-17-015623:mdna:80]

[0001564590-17-022183:mdna:87]
[same as prior period, unchanged from 0001564590-17-015623:mdna:81]

[0001564590-17-022183:mdna:88]
At September 30, 2017, cash on hand was $128.3 million and short-term investments were $31.4 million, which resulted in available short-term liquidity of $159.6 million, of which $63.9 million was held by our foreign subsidiaries. At December 31, 2016, cash on hand was $79.9 million and short-term investments were $43.2 million, which resulted in available short-term liquidity of $123.1 million, of which $42.1 million was held by our foreign subsidiaries. We intend to permanently reinvest these funds outside the U.S. and our current business plans do not indicate a need to repatriate these funds to finance domestic operations. The increase in short-term liquidity from December 31, 2016 to September 30, 2017 is primarily attributable to shifts among available investment option tenures to provide funds for our short-term cash needs.

[0001564590-17-022183:mdna:89]
[same as prior period, unchanged from 0001564590-17-015623:mdna:83]

[0001564590-17-022183:mdna:90]
Our working capital, which consists of current assets less current liabilities, increased 30.0% from $226.4 million as of December 31, 2016 to $294.2 million as of September 30, 2017, and our current ratio, defined as current assets divided by current liabilities, increased from 2.79 as of December 31, 2016 to 3.36 as of September 30, 2017. The increase in our working capital and current ratio is primarily attributable to an increase in cash and cash equivalents, inventory, accounts receivable, and prepaid expenses and other current assets, partially offset by an increase in income tax payable. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, increased from 1.70 as of December 31, 2016 to 2.09 as of September 30, 2017. The increase in the quick ratio is primarily attributable to an increase in cash and cash equivalents, short-term investments, and accounts receivable.

[0001564590-17-022183:mdna:91]
Accounts receivable increased 10.0% from $92.3 million at December 31, 2016 to $101.6 million at September 30, 2017. We had no allowance for doubtful accounts at December 31, 2016 or September 30, 2017. Quarterly accounts receivable days sales outstanding (DSO) decreased from 52 days as of December 31, 2016 to 51 days as of September 30, 2017. The change in net accounts receivable is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than U.S. customers. Other receivables increased 22.5% from $15.1 million at December 31, 2016 to $18.5 million at September 30, 2017. The increase in other receivables is primarily attributable to an increase in lease receivables, partially offset by the timing of filing returns and collections of VAT receivables in our international subsidiaries and the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001564590-17-022183:mdna:92]
Quarterly inventory turnover decreased from 3.67 turns as of December 31, 2016 to 3.43 turns at September 30, 2017. Inventory increased 10.6% from $105.1 million at December 31, 2016 to $116.2 million at September 30, 2017. The increase in inventory at September 30, 2017 is primarily attributable to customer specific projects. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-17-022183:mdna:93]
Prepaid expense and other current assets increased 40.5% from $16.5 million at December 31, 2016 to $23.1 million at September 30, 2017. The increase in prepaid expenses and other current assets is primarily attributable to deferred costs related to incomplete network installation services.

[0001564590-17-022183:mdna:94]
Accounts payable decreased 5.4% from $77.3 million at December 31, 2016 to $73.1 million at September 30, 2017. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-17-022183:mdna:95]
[same as prior period, unchanged from 0001564590-17-015623:mdna:88]

[0001564590-17-022183:mdna:96]
Capital expenditures totaled approximately $12.3 million and $12.7 million for the nine months ended September 30, 2017 and 2016, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-17-022183:mdna:97]
Our combined short-term and long-term investments decreased $50.9 million from $219.3 million at December 31, 2016 to $168.4 million at September 30, 2017. This decrease reflects our cash needs for capital expenditures, purchases of treasury stock, and shareholder dividends partially offset by funds available for investment provided by our operating activities and stock option exercises by our employees, as well as net realized and unrealized gains and losses and amortization of net premiums on our combined investments.

[0001564590-17-022183:mdna:98]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At September 30, 2017 these investments included corporate bonds of $45.2 million, municipal fixed-rate bonds of $4.9 million, asset-backed bonds of $7.8 million, mortgage/agency-backed bonds of $7.3 million, U.S. government bonds of $20.9 million, and foreign government bonds of $0.7 million. At December 31, 2016, these investments included corporate bonds of $66.4 million, municipal fixed-rate bonds of $11.8 million, asset-backed bonds of $10.2 million, mortgage/agency-backed bonds of $13.0 million, U.S. government bonds of $29.8 million, foreign government bonds of $3.7 million and variable rate demand notes of $11.9 million. As of September 30, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds were classified as available-for-sale and had a combined duration of 0.8 years with an average Standard & Poor’s credit rating of A+. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-17-022183:mdna:99]
Our long-term investments decreased 22.2% from $176.1 million at December 31, 2016 to $137.0 million at September 30, 2017. Long-term investments at September 30, 2017 and December 31, 2016 included an investment in a certificate of deposit of $27.8 million, which serves as collateral for our revenue bond. See “Debt” below for additional information. We have various equity investments included in long-term investments at a cost of $32.4 million and $30.6 million, and with a fair value of $34.1 million and $29.4 million, at September 30, 2017 and December 31, 2016, respectively.

[0001564590-17-022183:mdna:100]
Long-term investments at September 30, 2017 and December 31, 2016 also included $19.1 million and $14.6 million, respectively, related to our deferred compensation plans, and $0.5 million and $0.8 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001564590-17-022183:mdna:101]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and nine months ended September 30, 2017 and 2016, other-than-temporary impairment charges were not significant.

[0001564590-17-022183:mdna:102]
[same as prior period, unchanged from 0001564590-17-015623:mdna:95]

[0001564590-17-022183:mdna:103]
[same as prior period, unchanged from 0001564590-17-015623:mdna:96]

[0001564590-17-022183:mdna:104]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the nine months ended September 30, 2017, we paid dividends totaling $13.0 million.

[0001564590-17-022183:mdna:105]
[same as prior period, unchanged from 0001564590-17-015623:mdna:98]

[0001564590-17-022183:mdna:106]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $27.8 million at September 30, 2017 and December 31, 2016. At September 30, 2017, the estimated fair value of the Bond was approximately $28.0 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $27.8 million at September 30, 2017 and December 31, 2016, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.0 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at September 30, 2017.

[0001564590-17-022183:mdna:107]
[same as prior period, unchanged from 0001564590-17-015623:mdna:100]

[0001564590-17-022183:mdna:108]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the nine months ended September 30, 2017, we repurchased 0.9 million shares of our common stock at an average price of $20.27 per share. As of September 30, 2017, we have the authority to purchase an additional 3.6 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-17-022183:mdna:109]
[same as prior period, unchanged from 0001564590-17-015623:mdna:102]

[0001564590-17-022183:mdna:110]
We issued 0.4 million shares of treasury stock during the nine months ended September 30, 2017 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $23.64. We received proceeds totaling $6.6 million from the exercise of these stock options during the nine months ended September 30, 2017.

[0001564590-17-022183:mdna:111]
[same as prior period, unchanged from 0001564590-17-015623:mdna:104]

[0001564590-17-022183:mdna:112]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the nine months ended September 30, 2017, there have been no material changes in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2016 filed on February 24, 2017 with the SEC.

[0001564590-17-022183:mdna:113]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2017, of which $7.7 million has been applied to these commitments.

[0001564590-17-022183:mdna:114]
34
