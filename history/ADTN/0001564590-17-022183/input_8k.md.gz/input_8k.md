# ADTN 8-K — 0001564590-17-019582 filed 2017-10-18

## item codes, every 8-K on or before 2017-11-07

- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2017-11-07

- none on or before 2017-11-07

## item 2.02 — earnings release, exhibit 99.1

[0001564590-17-019582:8k_2_02:1]
EX-99.1
2
adtn-ex991_6.htm
EX-99.1

[0001564590-17-019582:8k_2_02:2]
adtn-ex991_6.htm

[0001564590-17-019582:8k_2_02:3]
EXHIBIT 99.1

[0001564590-17-019582:8k_2_02:4]
ADTRAN, Inc. Reports 28% Increase in Earnings for the Third Quarter 2017 and Declares Quarterly Cash Dividend

[0001564590-17-019582:8k_2_02:5]
Earnings per share increases 27% versus Q3 2016, and the company reports record Services revenues

[0001564590-17-019582:8k_2_02:6]
HUNTSVILLE, Ala.--(BUSINESS WIRE)—October 17, 2017-- ADTRAN, Inc. (NASDAQ:ADTN) reported results for the third quarter 2017. For the quarter, sales were $185.1 million compared to $168.9 million for the third quarter of 2016. Net income was $15.9 million compared to $12.4 million for the third quarter of 2016. Earnings per share, assuming dilution, were $0.33 compared to $0.26 for the third quarter of 2016. Non-GAAP earnings per share were $0.37 compared to $0.26 for the third quarter of 2016, an increase of 42%. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001564590-17-019582:8k_2_02:7]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “We are very pleased with the company’s performance in the third quarter as we continued to see strong sales in our domestic ultra-broadband solutions and services, which have more than doubled from the same period last year. Total company revenues grew by 10% compared to the same period last year as a result of strength in both our Network Solutions segment and a record performance in our services revenues, which again grew at a double-digit pace. We were also pleased to see growth in our Customer Devices category in the quarter. Our customers are increasingly relying on ADTRAN to help them plan, provision and deploy network assets to the best effect, ensuring the network is prepared for the emergence of exciting applications and mission critical services.”

[0001564590-17-019582:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash dividend for the third quarter of 2017. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on November 1, 2017. The ex-dividend date is October 31, 2017, and the payment date is November 15, 2017.

[0001564590-17-019582:8k_2_02:9]
The Company confirmed that its third quarter conference call will be held Wednesday, October 18, 2017, at 9:30 a.m. Central Time. ADTRAN will webcast this conference. To listen, simply visit the Investor Relations site at www.investors.adtran.com  approximately 10 minutes prior to the start of the call and click on the conference call link provided.

[0001564590-17-019582:8k_2_02:10]
An online replay of the conference call, as well as the text of the Company's earnings release, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months.

[0001564590-17-019582:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit www.adtran.com.

[0001564590-17-019582:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at investor.relations@adtran.com. On the Web, visit www.adtran.com.

[0001564590-17-019582:8k_2_02:13]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2016. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-17-019582:8k_2_02:14]
Condensed Consolidated Balance Sheet

[0001564590-17-019582:8k_2_02:15]
(Unaudited)

[0001564590-17-019582:8k_2_02:16]
(In thousands)

[0001564590-17-019582:8k_2_02:17]
|  | September 30, |  |  | December 31, |  |
|  | 2017 |  |  | 2016 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 128,253 |  |  | $ | 79,895 |  |
| Short-term investments |  | 31,385 |  |  |  | 43,188 |  |
| Accounts receivable, net |  | 101,613 |  |  |  | 92,346 |  |
| Other receivables |  | 18,541 |  |  |  | 15,137 |  |
| Income tax receivable, net |  | — |  |  |  | 760 |  |
| Inventory, net |  | 116,230 |  |  |  | 105,117 |  |
| Prepaid expenses and other current assets |  | 23,127 |  |  |  | 16,459 |  |
| Total Current Assets |  | 419,149 |  |  |  | 352,902 |  |
| Property, plant and equipment, net |  | 85,665 |  |  |  | 84,469 |  |
| Deferred tax assets, net |  | 37,130 |  |  |  | 38,036 |  |
| Goodwill |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  | 13,135 |  |  |  | 12,234 |  |
| Long-term investments |  | 136,987 |  |  |  | 176,102 |  |
| Total Assets | $ | 695,558 |  |  | $ | 667,235 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 73,127 |  |  | $ | 77,342 |  |
| Unearned revenue |  | 13,651 |  |  |  | 16,326 |  |
| Accrued expenses |  | 15,099 |  |  |  | 12,434 |  |
| Accrued wages and benefits |  | 15,345 |  |  |  | 20,433 |  |
| Income tax payable, net |  | 7,696 |  |  |  | — |  |
| Total Current Liabilities |  | 124,918 |  |  |  | 126,535 |  |
| Non-current unearned revenue |  | 4,918 |  |  |  | 6,333 |  |
| Other non-current liabilities |  | 34,756 |  |  |  | 28,050 |  |
| Bonds payable |  | 26,800 |  |  |  | 26,800 |  |
| Total Liabilities |  | 191,392 |  |  |  | 187,718 |  |
| Stockholders' Equity |  | 504,166 |  |  |  | 479,517 |  |
| Total Liabilities and Stockholders' Equity | $ | 695,558 |  |  | $ | 667,235 |  |

[0001564590-17-019582:8k_2_02:18]
Consolidated Statements of Income

[0001564590-17-019582:8k_2_02:19]
(Unaudited)

[0001564590-17-019582:8k_2_02:20]
(In thousands, except per share data)

[0001564590-17-019582:8k_2_02:21]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 145,467 |  |  | $ | 136,277 |  |  | $ | 444,607 |  |  | $ | 398,709 |  |
| Services |  |  | 39,645 |  |  |  | 32,613 |  |  |  | 95,457 |  |  |  | 75,086 |  |
| Total Sales |  |  | 185,112 |  |  |  | 168,890 |  |  |  | 540,064 |  |  |  | 473,795 |  |
| Cost of sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 73,528 |  |  |  | 70,988 |  |  |  | 229,845 |  |  |  | 202,905 |  |
| Services |  |  | 25,086 |  |  |  | 22,094 |  |  |  | 65,374 |  |  |  | 50,333 |  |
| Total Cost of Sales |  |  | 98,614 |  |  |  | 93,082 |  |  |  | 295,219 |  |  |  | 253,238 |  |
| Gross Profit |  |  | 86,498 |  |  |  | 75,808 |  |  |  | 244,845 |  |  |  | 220,557 |  |
| Selling, general and administrative expenses |  |  | 34,652 |  |  |  | 33,716 |  |  |  | 104,102 |  |  |  | 97,367 |  |
| Research and development expenses |  |  | 33,528 |  |  |  | 31,962 |  |  |  | 98,945 |  |  |  | 92,727 |  |
| Operating Income |  |  | 18,318 |  |  |  | 10,130 |  |  |  | 41,798 |  |  |  | 30,463 |  |
| Interest and dividend income |  |  | 952 |  |  |  | 910 |  |  |  | 2,857 |  |  |  | 2,692 |  |
| Interest expense |  |  | (139 | ) |  |  | (143 | ) |  |  | (417 | ) |  |  | (430 | ) |
| Net realized investment gain |  |  | 1,009 |  |  |  | 1,316 |  |  |  | 2,869 |  |  |  | 4,154 |  |
| Other expense, net |  |  | (933 | ) |  |  | (246 | ) |  |  | (1,686 | ) |  |  | (378 | ) |
| Gain on bargain purchase of a business |  |  | — |  |  |  | 3,550 |  |  |  | — |  |  |  | 3,550 |  |
| Income before provision for income taxes |  |  | 19,207 |  |  |  | 15,517 |  |  |  | 45,421 |  |  |  | 40,051 |  |
| Provision for income taxes |  |  | (3,309 | ) |  |  | (3,102 | ) |  |  | (10,471 | ) |  |  | (12,394 | ) |
| Net Income |  | $ | 15,898 |  |  | $ | 12,415 |  |  | $ | 34,950 |  |  | $ | 27,657 |  |
| Weighted average shares outstanding – basic |  |  | 47,870 |  |  |  | 48,470 |  |  |  | 48,110 |  |  |  | 48,839 |  |
| Weighted average shares outstanding – diluted |  |  | 48,531 |  |  |  | 48,678 |  |  |  | 48,618 |  |  |  | 49,036 |  |
| Earnings per common share – basic |  | $ | 0.33 |  |  | $ | 0.26 |  |  | $ | 0.73 |  |  | $ | 0.57 |  |
| Earnings per common share – diluted |  | $ | 0.33 |  |  | $ | 0.26 |  |  | $ | 0.72 |  |  | $ | 0.56 |  |

[0001564590-17-019582:8k_2_02:22]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-17-019582:8k_2_02:23]
Consolidated Statements of Comprehensive Income

[0001564590-17-019582:8k_2_02:24]
(Unaudited)

[0001564590-17-019582:8k_2_02:25]
(In thousands)

[0001564590-17-019582:8k_2_02:26]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net Income |  | $ | 15,898 |  |  | $ | 12,415 |  |  | $ | 34,950 |  |  | $ | 27,657 |  |
| Other Comprehensive Income, net of tax |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net unrealized gains (losses) on available-for-sale securities |  |  | 804 |  |  |  | 258 |  |  |  | 2,512 |  |  |  | (162 | ) |
| Net unrealized gains (losses) on cash flow hedges |  |  | 142 |  |  |  | — |  |  |  | (196 | ) |  |  | — |  |
| Defined benefit plan adjustments |  |  | 73 |  |  |  | 36 |  |  |  | 214 |  |  |  | 103 |  |
| Foreign currency translation |  |  | 1,541 |  |  |  | 575 |  |  |  | 5,402 |  |  |  | 1,202 |  |
| Other Comprehensive Income, net of tax |  |  | 2,560 |  |  |  | 869 |  |  |  | 7,932 |  |  |  | 1,143 |  |
| Comprehensive Income, net of tax |  | $ | 18,458 |  |  | $ | 13,284 |  |  | $ | 42,882 |  |  | $ | 28,800 |  |

[0001564590-17-019582:8k_2_02:27]
Consolidated Statements of Cash Flows

[0001564590-17-019582:8k_2_02:28]
(Unaudited)

[0001564590-17-019582:8k_2_02:29]
(In thousands)

[0001564590-17-019582:8k_2_02:30]
|  |  | Nine Months Ended |  |
|  |  | September 30, |  |
|  |  | 2017 |  |  | 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 34,950 |  |  | $ | 27,657 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 12,034 |  |  |  | 10,260 |  |
| Amortization of net premium on available-for-sale investments |  |  | 352 |  |  |  | 489 |  |
| Net realized gain on long-term investments |  |  | (2,869 | ) |  |  | (4,154 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | (10 | ) |  |  | 21 |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | (3,550 | ) |
| Stock-based compensation expense |  |  | 5,573 |  |  |  | 4,601 |  |
| Deferred income taxes |  |  | — |  |  |  | (463 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (6,975 | ) |  |  | (29,370 | ) |
| Other receivables |  |  | (2,924 | ) |  |  | 7,475 |  |
| Inventory |  |  | (9,483 | ) |  |  | (683 | ) |
| Prepaid expenses and other assets |  |  | (9,647 | ) |  |  | (5,180 | ) |
| Accounts payable |  |  | (4,727 | ) |  |  | 16,363 |  |
| Accrued expenses and other liabilities |  |  | (2,820 | ) |  |  | 7,307 |  |
| Income tax payable/receivable, net |  |  | 8,571 |  |  |  | (2,941 | ) |
| Net cash provided by operating activities |  |  | 22,025 |  |  |  | 27,832 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (12,304 | ) |  |  | (12,684 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 16 |  |  |  | — |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 137,272 |  |  |  | 141,103 |  |
| Purchases of available-for-sale investments |  |  | (79,713 | ) |  |  | (139,181 | ) |
| Acquisition of business |  |  | — |  |  |  | (943 | ) |
| Net cash provided by (used in) investing activities |  |  | 45,271 |  |  |  | (11,705 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 6,606 |  |  |  | 1,076 |  |
| Purchases of treasury stock |  |  | (17,348 | ) |  |  | (22,917 | ) |
| Dividend payments |  |  | (13,031 | ) |  |  | (13,230 | ) |
| Net cash used in financing activities |  |  | (23,773 | ) |  |  | (35,071 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 43,523 |  |  |  | (18,944 | ) |
| Effect of exchange rate changes |  |  | 4,835 |  |  |  | 686 |  |
| Cash and cash equivalents, beginning of period |  |  | 79,895 |  |  |  | 84,550 |  |
| Cash and cash equivalents, end of period |  | $ | 128,253 |  |  | $ | 66,292 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 272 |  |  | $ | 1,174 |  |

[0001564590-17-019582:8k_2_02:31]
Supplemental Information

[0001564590-17-019582:8k_2_02:32]
Restructuring Expenses

[0001564590-17-019582:8k_2_02:33]
(Unaudited)

[0001564590-17-019582:8k_2_02:34]
(In thousands)

[0001564590-17-019582:8k_2_02:35]
Restructuring expense was recorded in the following Consolidated Statements of Income categories for the three and nine months ended September 30, 2017 and 2016:

[0001564590-17-019582:8k_2_02:36]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Restructuring expense included in cost of sales |  | $ | — |  |  | $ | 1,307 |  |  | $ | — |  |  | $ | 1,307 |  |
| Selling, general and administrative expense |  |  | 93 |  |  |  | 637 |  |  |  | 93 |  |  |  | 637 |  |
| Research and development expense |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | — |  |
| Restructuring expense included in operating expenses |  |  | 215 |  |  |  | 637 |  |  |  | 215 |  |  |  | 637 |  |
| Total restructuring expense |  |  | 215 |  |  |  | 1,944 |  |  |  | 215 |  |  |  | 1,944 |  |
| Provision for income taxes |  |  | (84 | ) |  |  | (603 | ) |  |  | (84 | ) |  |  | (603 | ) |
| Total restructuring expense, net of tax |  | $ | 131 |  |  | $ | 1,341 |  |  | $ | 131 |  |  | $ | 1,341 |  |

[0001564590-17-019582:8k_2_02:37]
Supplemental Information

[0001564590-17-019582:8k_2_02:38]
Acquisition Related Expenses, Amortizations and Adjustments

[0001564590-17-019582:8k_2_02:39]
(Unaudited)

[0001564590-17-019582:8k_2_02:40]
(In thousands)

[0001564590-17-019582:8k_2_02:41]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc., on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA), and on September 13, 2016, we closed on the acquisition of CommScope’s active fiber business (CommScope). Acquisition related expenses, amortizations and adjustments for the three and nine months ended September 30, 2017 and 2016 for all three transactions are as follows:

[0001564590-17-019582:8k_2_02:42]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 158 |  |  | $ | 158 |  |  | $ | 474 |  |  | $ | 504 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 95 |  |  |  | 225 |  |  |  | 432 |  |  |  | 680 |  |
| Amortization of other purchase accounting adjustments |  |  | 1 |  |  |  | 114 |  |  |  | 39 |  |  |  | 194 |  |
| Subtotal - NSN BBA acquisition |  |  | 96 |  |  |  | 339 |  |  |  | 471 |  |  |  | 874 |  |
| CommScope acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 219 |  |  |  | 112 |  |  |  | 1,513 |  |  |  | 112 |  |
| Amortization of other purchase accounting adjustments |  |  | 4 |  |  |  | 84 |  |  |  | 85 |  |  |  | 84 |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | 45 |  |  |  | 8 |  |  |  | 45 |  |
| Subtotal - CommScope acquisition |  |  | 223 |  |  |  | 241 |  |  |  | 1,606 |  |  |  | 241 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 477 |  |  |  | 738 |  |  |  | 2,551 |  |  |  | 1,619 |  |
| Provision for income taxes |  |  | (178 | ) |  |  | (261 | ) |  |  | (957 | ) |  |  | (562 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 299 |  |  | $ | 477 |  |  | $ | 1,594 |  |  | $ | 1,057 |  |

[0001564590-17-019582:8k_2_02:43]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and nine months ended September 30, 2017 and 2016:

[0001564590-17-019582:8k_2_02:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Cost of goods sold |  | $ | 5 |  |  | $ | 169 |  |  | $ | 86 |  |  | $ | 189 |  |
| Selling, general and administrative expenses |  |  | 50 |  |  |  | 54 |  |  |  | 164 |  |  |  | 61 |  |
| Research and development expenses |  |  | 422 |  |  |  | 515 |  |  |  | 2,301 |  |  |  | 1,369 |  |
| Total acquisition related expenses, amortizations and adjustments included in operating expenses |  |  | 472 |  |  |  | 569 |  |  |  | 2,465 |  |  |  | 1,430 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 477 |  |  |  | 738 |  |  |  | 2,551 |  |  |  | 1,619 |  |
| Provision for income taxes |  |  | (178 | ) |  |  | (261 | ) |  |  | (957 | ) |  |  | (562 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 299 |  |  | $ | 477 |  |  | $ | 1,594 |  |  | $ | 1,057 |  |

[0001564590-17-019582:8k_2_02:45]
Supplemental Information

[0001564590-17-019582:8k_2_02:46]
Stock-based Compensation Expense

[0001564590-17-019582:8k_2_02:47]
(Unaudited)

[0001564590-17-019582:8k_2_02:48]
(In thousands)

[0001564590-17-019582:8k_2_02:49]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 97 |  |  | $ | 88 |  |  | $ | 281 |  |  | $ | 282 |  |
| Selling, general and administrative expense |  |  | 994 |  |  |  | 765 |  |  |  | 3,018 |  |  |  | 2,322 |  |
| Research and development expense |  |  | 743 |  |  |  | 639 |  |  |  | 2,274 |  |  |  | 1,997 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,737 |  |  |  | 1,404 |  |  |  | 5,292 |  |  |  | 4,319 |  |
| Total stock-based compensation expense |  |  | 1,834 |  |  |  | 1,492 |  |  |  | 5,573 |  |  |  | 4,601 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (402 | ) |  |  | (218 | ) |  |  | (1,215 | ) |  |  | (643 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,432 |  |  | $ | 1,274 |  |  | $ | 4,358 |  |  | $ | 3,958 |  |

[0001564590-17-019582:8k_2_02:50]
Reconciliation of GAAP net income per share, diluted, to

[0001564590-17-019582:8k_2_02:51]
Non-GAAP net income per share, diluted

[0001564590-17-019582:8k_2_02:52]
(Unaudited)

[0001564590-17-019582:8k_2_02:53]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| GAAP earnings per common share - diluted |  | $ | 0.33 |  |  | $ | 0.26 |  |  | $ | 0.72 |  |  | $ | 0.56 |  |
| Restructuring expense |  |  | — |  |  |  | 0.03 |  |  |  | — |  |  |  | 0.03 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.02 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.09 |  |  |  | 0.08 |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | (0.07 | ) |  |  | — |  |  |  | (0.07 | ) |
| Non-GAAP earnings per common share - diluted |  | $ | 0.37 |  |  | $ | 0.26 |  |  | $ | 0.84 |  |  | $ | 0.62 |  |
