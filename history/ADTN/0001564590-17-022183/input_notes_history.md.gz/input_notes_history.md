# ADTN note change history — 0001564590-17-015623 → 0001564590-17-022183


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001564590-17-022183:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2017, of which $7.7 million has been applied to these commitments.
  (was, 2017-08-04, similarity 0.9726):
[0001564590-17-015623:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2017, of which $7.7 million has been applied to these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001564590-17-022183:note_history:2]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method. We are continuing to evaluate and assess the potential impacts of these ASUs through an analysis of revenue streams, contract reviews, and our control environment.
  (was, 2017-08-04, similarity 0.9159):
[0001564590-17-015623:note_history:2]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method. We are continuing to evaluate the potential impact of these ASUs, and we believe the most significant potential impact relates to our accounting for software license and installation services revenues. We do not believe there will be a significant impact to product or maintenance revenues.

- added (2017-11-07):
[0001564590-17-022183:note_history:3]
We are finalizing our assessment of the proper method of measuring progress toward satisfaction of each respective contract performance obligation for our network installation services revenues. At this time, we believe the output method will be used to measure network installation services progress. We believe the primary impact will be accelerated revenue recognition for certain performance obligations related to revenue arrangements that are currently deferred until customer acceptance.

- added (2017-11-07):
[0001564590-17-022183:note_history:4]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we will also adopt ASC 340-40, Other Assets and Deferred Costs - Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract may need to be capitalized, including sales commissions, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. We believe the primary impact will be capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and costs associated with our capital lease arrangements that are billed monthly, and amortization of those costs over the period that the related revenue is recognized.

- added (2017-11-07):
[0001564590-17-022183:note_history:5]
We do not believe there will be a significant impact to product or maintenance revenues.  However, we are still assessing the impact of the allocation of revenue between deliverables with multiple performance obligations and timing of revenue recognition.

- added (2017-11-07):
[0001564590-17-022183:note_history:6]
In August 2017, the FASB issued Accounting Standards Update No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (ASU 2017-12). ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating the impact ASU 2017-12 will have on our financial position, results of operations and cash flows.

- changed (2017-11-07):
[0001564590-17-022183:note_history:7]
In January 2017, we adopted ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. As a result, beginning in the first quarter of 2017, we began recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit as a discrete event. The treatment of forfeitures has changed as we have elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur. As a result, we recorded an increase in additional paid in capital of $0.1 million, a charge to beginning retained earnings of $0.1 million, and an increase in the deferred tax assets related to non-qualified stock options and RSUs of $10 thousand. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows within operating activities. We elected to retrospectively apply the changes in presentation to the statements of cash flows and no longer classify excess tax benefits as a financing activity, which had an immaterial impact on our cash flows for the nine months ended September 30, 2016. There was no material impact on our financial position, results of operations or cash flows as a result of these changes.
  (was, 2017-08-04, similarity 0.9482):
[0001564590-17-015623:note_history:7]
In January 2017, we adopted ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. As a result, beginning in the first quarter of 2017, we began recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit as a discrete event. The treatment of forfeitures has changed as we have elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur. As a result, we recorded an increase in additional paid in capital of $0.1 million, a charge to beginning retained earnings of $0.1 million, and an increase in the deferred tax assets related to non-qualified stock options and RSUs of $10 thousand. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows within operating activities. We elected to retrospectively apply the changes in presentation to the statements of cash flows and no longer classify excess tax benefits as a financing activity, which had no effect on our cash flows for the six months ended June 30, 2016. There was no material impact on our financial position, results of operations or cash flows as a result of these changes.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001564590-17-022183:note_history:8]
At September 30, 2017, we held the following securities and investments, recorded at either fair value or cost:
  (was, 2017-08-04, similarity 0.9463):
[0001564590-17-015623:note_history:8]
At June 30, 2017, we held the following securities and investments, recorded at either fair value or cost:

- changed (2017-11-07):
[0001564590-17-022183:note_history:9]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 15,898 |  |  | $ | 3,230 |  |  | $ | (15 | ) |  | $ | 19,113 |  |
| Corporate bonds |  |  | 45,223 |  |  |  | 75 |  |  |  | (79 | ) |  |  | 45,219 |  |
| Municipal fixed-rate bonds |  |  | 4,887 |  |  |  | 4 |  |  |  | (17 | ) |  |  | 4,874 |  |
| Asset-backed bonds |  |  | 7,791 |  |  |  | 5 |  |  |  | (11 | ) |  |  | 7,785 |  |
| Mortgage/Agency-backed bonds |  |  | 7,364 |  |  |  | 7 |  |  |  | (41 | ) |  |  | 7,330 |  |
| U.S. government bonds |  |  | 21,000 |  |  |  | 3 |  |  |  | (109 | ) |  |  | 20,894 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 3 |  |  | — |  |  |  | 728 |  |
| Marketable equity securities |  |  | 32,394 |  |  |  | 2,649 |  |  |  | (961 | ) |  |  | 34,082 |  |
| Available-for-sale securities held at fair value |  | $ | 135,282 |  |  | $ | 5,976 |  |  | $ | (1,233 | ) |  | $ | 140,025 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 168,372 |  |
  (was, 2017-08-04, similarity 0.9947):
[0001564590-17-015623:note_history:9]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 15,662 |  |  | $ | 2,389 |  |  | $ | (23 | ) |  | $ | 18,028 |  |
| Corporate bonds |  |  | 72,954 |  |  |  | 132 |  |  |  | (107 | ) |  |  | 72,979 |  |
| Municipal fixed-rate bonds |  |  | 7,596 |  |  |  | 7 |  |  |  | (20 | ) |  |  | 7,583 |  |
| Asset-backed bonds |  |  | 13,313 |  |  |  | 11 |  |  |  | (16 | ) |  |  | 13,308 |  |
| Mortgage/Agency-backed bonds |  |  | 9,549 |  |  |  | 14 |  |  |  | (36 | ) |  |  | 9,527 |  |
| U.S. government bonds |  |  | 21,528 |  |  |  | 4 |  |  |  | (132 | ) |  |  | 21,400 |  |
| Foreign government bonds |  |  | 2,700 |  |  |  | 3 |  |  |  | (1 | ) |  |  | 2,702 |  |
| Marketable equity securities |  |  | 31,741 |  |  |  | 2,153 |  |  |  | (929 | ) |  |  | 32,965 |  |
| Available-for-sale securities held at fair value |  | $ | 175,043 |  |  | $ | 4,713 |  |  | $ | (1,264 | ) |  | $ | 178,492 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 673 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 206,965 |  |

- changed (2017-11-07):
[0001564590-17-022183:note_history:10]
As of September 30, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds and foreign government bonds had the following contractual maturities:
  (was, 2017-08-04, similarity 0.9688):
[0001564590-17-015623:note_history:10]
As of June 30, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds and foreign government bonds had the following contractual maturities:

- changed (2017-11-07):
[0001564590-17-022183:note_history:11]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 20,232 |  |  | $ | 2,250 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,903 |  |  | $ | — |  |
| One to two years |  |  | 11,678 |  |  |  | 724 |  |  | $ | 2,638 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 10,029 |  |  |  | 730 |  |  |  | 2,235 |  |  |  | — |  |  |  | 10,413 |  |  |  | 728 |  |
| Three to five years |  |  | 3,280 |  |  |  | 1,170 |  |  |  | 1,550 |  |  |  | 917 |  |  |  | 1,578 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 450 |  |  |  | 1,348 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 912 |  |  |  | 5,065 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 45,219 |  |  | $ | 4,874 |  |  | $ | 7,785 |  |  | $ | 7,330 |  |  | $ | 20,894 |  |  | $ | 728 |  |
  (was, 2017-08-04, similarity 0.9556):
[0001564590-17-015623:note_history:11]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 33,486 |  |  | $ | 4,101 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,919 |  |  | $ | 825 |  |
| One to two years |  |  | 16,124 |  |  |  | 1,536 |  |  |  | 850 |  |  |  | 493 |  |  |  | — |  |  |  | 600 |  |
| Two to three years |  |  | 21,421 |  |  |  | 775 |  |  |  | 5,185 |  |  |  | — |  |  |  | 8,367 |  |  |  | 1,277 |  |
| Three to five years |  |  | 1,948 |  |  |  | 1,171 |  |  |  | 5,836 |  |  |  | 415 |  |  |  | 4,114 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 508 |  |  |  | 1,340 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 929 |  |  |  | 7,279 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 72,979 |  |  | $ | 7,583 |  |  | $ | 13,308 |  |  | $ | 9,527 |  |  | $ | 21,400 |  |  | $ | 2,702 |  |

- changed (2017-11-07):
[0001564590-17-022183:note_history:12]
At September 30, 2017, we held a $27.8 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $27.8 million at September 30, 2017 and December 31, 2016. At September 30, 2017 and December 31, 2016, the estimated fair value of the Bond using a level 2 valuation technique was approximately $28.0 million and $28.1 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.
  (was, 2017-08-04, similarity 0.9483):
[0001564590-17-015623:note_history:12]
At June 30, 2017, we held a $27.8 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $27.8 million at June 30, 2017 and December 31, 2016. At June 30, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $28.0 million, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

- changed (2017-11-07):
[0001564590-17-022183:note_history:13]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and nine months ended September 30, 2017 and 2016, other-than-temporary impairment charges were not significant.
  (was, 2017-08-04, similarity 0.979):
[0001564590-17-015623:note_history:13]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and six months ended June 30, 2017 and 2016, other-than-temporary impairment charges were not significant.

- changed (2017-11-07):
[0001564590-17-022183:note_history:14]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments:
  (was, 2017-08-04, similarity 0.9948):
[0001564590-17-015623:note_history:14]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments.

- changed (2017-11-07):
[0001564590-17-022183:note_history:15]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Gross realized gains |  | $ | 1,094 |  |  | $ | 1,346 |  |  | $ | 3,324 |  |  | $ | 5,226 |  |
| Gross realized losses |  | $ | (85 | ) |  | $ | (30 | ) |  | $ | (455 | ) |  | $ | (1,072 | ) |
  (was, 2017-08-04, similarity 0.86):
[0001564590-17-015623:note_history:15]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Gross realized gains |  | $ | 1,512 |  |  | $ | 1,517 |  |  | $ | 2,230 |  |  | $ | 3,881 |  |
| Gross realized losses |  | $ | (122 | ) |  | $ | (407 | ) |  | $ | (370 | ) |  | $ | (1,043 | ) |

- changed (2017-11-07):
[0001564590-17-022183:note_history:16]
As of September 30, 2017 and 2016, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.
  (was, 2017-08-04, similarity 0.9644):
[0001564590-17-015623:note_history:16]
As of June 30, 2017 and 2016, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.

- changed (2017-11-07):
[0001564590-17-022183:note_history:17]
|  |  | Fair Value Measurements at September 30, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 8,115 |  |  | $ | 8,115 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 35,436 |  |  |  | — |  |  |  | 35,436 |  |  |  | — |  |
| Cash equivalents |  |  | 43,551 |  |  |  | 8,115 |  |  |  | 35,436 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 19,113 |  |  |  | 19,113 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 45,219 |  |  |  | — |  |  |  | 45,219 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 4,874 |  |  |  | — |  |  |  | 4,874 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,785 |  |  |  | — |  |  |  | 7,785 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 7,330 |  |  |  | — |  |  |  | 7,330 |  |  |  | — |  |
| U.S. government bonds |  |  | 20,894 |  |  |  | 20,894 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 728 |  |  |  | — |  |  |  | 728 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 34,082 |  |  |  | 34,082 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 140,025 |  |  |  | 74,089 |  |  |  | 65,936 |  |  |  | — |  |
| Total |  | $ | 183,576 |  |  | $ | 82,204 |  |  | $ | 101,372 |  |  | $ | — |  |
  (was, 2017-08-04, similarity 0.9955):
[0001564590-17-015623:note_history:17]
|  |  | Fair Value Measurements at June 30, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,487 |  |  | $ | 6,487 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 5,497 |  |  |  | — |  |  |  | 5,497 |  |  |  | — |  |
| Cash equivalents |  |  | 11,984 |  |  |  | 6,487 |  |  |  | 5,497 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 18,028 |  |  |  | 18,028 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 72,979 |  |  |  | — |  |  |  | 72,979 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 7,583 |  |  |  | — |  |  |  | 7,583 |  |  |  | — |  |
| Asset-backed bonds |  |  | 13,308 |  |  |  | — |  |  |  | 13,308 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 9,527 |  |  |  | — |  |  |  | 9,527 |  |  |  | — |  |
| U.S. government bonds |  |  | 21,400 |  |  |  | 21,400 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 2,702 |  |  |  | — |  |  |  | 2,702 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 32,965 |  |  |  | 32,965 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 178,492 |  |  |  | 72,393 |  |  |  | 106,099 |  |  |  | — |  |
| Total |  | $ | 190,476 |  |  | $ | 78,880 |  |  | $ | 111,596 |  |  | $ | — |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-11-07):
[0001564590-17-022183:note_history:18]
On October 17, 2017, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on November 1, 2017. The payment date will be November 15, 2017. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

- removed (2017-11-07):
[0001564590-17-015623:note_history:19]
On July 18, 2017, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on August 3, 2017. The payment date will be August 17, 2017. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
