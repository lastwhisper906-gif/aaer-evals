# ADTN notes — 0001564590-17-022183


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-17-022183:notes:1]
[same as prior period, unchanged from 0001564590-17-015623:notes:1]

[0001564590-17-022183:notes:2]
[same as prior period, unchanged from 0001564590-17-015623:notes:2]

[0001564590-17-022183:notes:3]
[same as prior period, unchanged from 0001564590-17-015623:notes:3]

[0001564590-17-022183:notes:4]
[same as prior period, unchanged from 0001564590-17-015623:notes:4]

[0001564590-17-022183:notes:5]
[same as prior period, unchanged from 0001564590-17-015623:notes:5]

[0001564590-17-022183:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-17-022183:notes:7]
[same as prior period, unchanged from 0001564590-17-015623:notes:7]

[0001564590-17-022183:notes:8]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method. We are continuing to evaluate and assess the potential impacts of these ASUs through an analysis of revenue streams, contract reviews, and our control environment.

[0001564590-17-022183:notes:9]
We are finalizing our assessment of the proper method of measuring progress toward satisfaction of each respective contract performance obligation for our network installation services revenues. At this time, we believe the output method will be used to measure network installation services progress. We believe the primary impact will be accelerated revenue recognition for certain performance obligations related to revenue arrangements that are currently deferred until customer acceptance.

[0001564590-17-022183:notes:10]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we will also adopt ASC 340-40, Other Assets and Deferred Costs - Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract may need to be capitalized, including sales commissions, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. We believe the primary impact will be capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and costs associated with our capital lease arrangements that are billed monthly, and amortization of those costs over the period that the related revenue is recognized.

[0001564590-17-022183:notes:11]
We do not believe there will be a significant impact to product or maintenance revenues.  However, we are still assessing the impact of the allocation of revenue between deliverables with multiple performance obligations and timing of revenue recognition.

[0001564590-17-022183:notes:12]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of ASU 2016-02 will have a material impact on our financial position; however, we do not believe adoption will have a material impact on our results of operations. We believe the most significant impact relates to our accounting for operating leases for office space and equipment.

[0001564590-17-022183:notes:13]
In January 2017, the FASB issued Accounting Standards Update No. 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04). ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material impact on our financial position, results of operations or cash flows.

[0001564590-17-022183:notes:14]
In March 2017, the FASB issued Accounting Standards Update No. 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost (ASU 2017-07). ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. ASU 2017-07 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted. We do not expect ASU 2017-07 will have a material impact on our financial position, results of operations or cash flows.

[0001564590-17-022183:notes:15]
In August 2017, the FASB issued Accounting Standards Update No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (ASU 2017-12). ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating the impact ASU 2017-12 will have on our financial position, results of operations and cash flows.

[0001564590-17-022183:notes:16]
[same as prior period, unchanged from 0001564590-17-015623:notes:12]

[0001564590-17-022183:notes:17]
In July 2015, the FASB issued Accounting Standards Update No.  2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We adopted ASU 2015-11 in the first quarter of 2017, and there was no material impact on our financial position, results of operations or cash flows.

[0001564590-17-022183:notes:18]
In January 2017, we adopted ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. As a result, beginning in the first quarter of 2017, we began recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit as a discrete event. The treatment of forfeitures has changed as we have elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur. As a result, we recorded an increase in additional paid in capital of $0.1 million, a charge to beginning retained earnings of $0.1 million, and an increase in the deferred tax assets related to non-qualified stock options and RSUs of $10 thousand. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows within operating activities. We elected to retrospectively apply the changes in presentation to the statements of cash flows and no longer classify excess tax benefits as a financing activity, which had an immaterial impact on our cash flows for the nine months ended September 30, 2016. There was no material impact on our financial position, results of operations or cash flows as a result of these changes.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-022183:notes:19]
[same as prior period, unchanged from 0001564590-17-015623:notes:15]

[0001564590-17-022183:notes:20]
[same as prior period, unchanged from 0001564590-17-015623:notes:16]

[0001564590-17-022183:notes:21]
We recorded a bargain purchase gain of $3.5 million during the third quarter of 2016, net of income taxes, which was subject to customary working capital adjustments between the parties. The bargain purchase gain of $3.5 million represents the excess fair value of the net assets acquired over the consideration exchanged. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and have concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-17-022183:notes:22]
Working capital adjustments were recorded in the fourth quarter of 2016 and resulted in an immaterial reduction in the inventory acquired, accounts payable assumed, deferred income taxes and bargain purchase gain. If these adjustments had been recorded on the date of acquisition, the bargain purchase gain would have been reduced by $8 thousand for the three months ended September 30, 2016. The final allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date is as follows:

[0001564590-17-022183:notes:23]
[same as prior period, unchanged from 0001564590-17-015623:notes:19]

[0001564590-17-022183:notes:24]
[same as prior period, unchanged from 0001564590-17-015623:notes:20]

[0001564590-17-022183:notes:25]
[same as prior period, unchanged from 0001564590-17-015623:notes:21]

[0001564590-17-022183:notes:26]
[same as prior period, unchanged from 0001564590-17-015623:notes:22]

[0001564590-17-022183:notes:27]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Pro forma revenue |  | $ | 170,498 |  |  | $ | 159,375 |  |  | $ | 478,184 |  |  | $ | 463,916 |  |
| Pro forma net income |  | $ | 9,495 |  |  | $ | 6,691 |  |  | $ | 24,761 |  |  | $ | 15,071 |  |
| Pro forma earnings per share - basic |  | $ | 0.20 |  |  | $ | 0.13 |  |  | $ | 0.51 |  |  | $ | 0.29 |  |
| Pro forma earnings per share - diluted |  | $ | 0.20 |  |  | $ | 0.13 |  |  | $ | 0.50 |  |  | $ | 0.29 |  |

[0001564590-17-022183:notes:28]
For the three and nine months ended September 30, 2017, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $0.2 million and $1.6 million, respectively, related to this acquisition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-022183:notes:29]
[same as prior period, unchanged from 0001564590-17-015623:notes:25]

[0001564590-17-022183:notes:30]
Our effective tax rate decreased from 34.0%, excluding the tax impact of the bargain purchase gain, in the nine months ended September 30, 2016, to 23.1% in the nine months ended September 30, 2017. The decrease in the effective tax rate between the periods is primarily attributable to additional research and development tax credits being recognized in the current quarter, an increase in stock option exercises and a greater mix of international income.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-17-022183:notes:31]
[same as prior period, unchanged from 0001564590-17-015623:notes:27]

[0001564590-17-022183:notes:32]
[same as prior period, unchanged from 0001564590-17-015623:notes:28]

[0001564590-17-022183:notes:33]
The following table summarizes the components of net periodic pension cost for the three and nine months ended September 30, 2017 and 2016:

[0001564590-17-022183:notes:34]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Service cost |  | $ | 327 |  |  | $ | 305 |  |  | $ | 930 |  |  | $ | 912 |  |
| Interest cost |  |  | 158 |  |  |  | 182 |  |  |  | 448 |  |  |  | 542 |  |
| Expected return on plan assets |  |  | (329 | ) |  |  | (266 | ) |  |  | (935 | ) |  |  | (796 | ) |
| Amortization of actuarial losses |  |  | 80 |  |  |  | 44 |  |  |  | 228 |  |  |  | 132 |  |
| Net periodic pension cost |  | $ | 236 |  |  | $ | 265 |  |  | $ | 671 |  |  | $ | 790 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-17-022183:notes:35]
[same as prior period, unchanged from 0001564590-17-015623:notes:31]

[0001564590-17-022183:notes:36]
The following table summarizes the stock-based compensation expense related to stock options, performance stock units (PSUs), restricted stock units (RSUs) and restricted stock for the three and nine months ended September 30, 2017 and 2016, which was recognized as follows:

[0001564590-17-022183:notes:37]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 97 |  |  | $ | 88 |  |  | $ | 281 |  |  | $ | 282 |  |
| Selling, general and administrative expense |  |  | 994 |  |  |  | 765 |  |  |  | 3,018 |  |  |  | 2,322 |  |
| Research and development expense |  |  | 743 |  |  |  | 639 |  |  |  | 2,274 |  |  |  | 1,997 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,737 |  |  |  | 1,404 |  |  |  | 5,292 |  |  |  | 4,319 |  |
| Total stock-based compensation expense |  |  | 1,834 |  |  |  | 1,492 |  |  |  | 5,573 |  |  |  | 4,601 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (402 | ) |  |  | (218 | ) |  |  | (1,215 | ) |  |  | (643 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,432 |  |  | $ | 1,274 |  |  | $ | 4,358 |  |  | $ | 3,958 |  |

[0001564590-17-022183:notes:38]
[same as prior period, unchanged from 0001564590-17-015623:notes:34]

[0001564590-17-022183:notes:39]
The following table is a summary of our stock options outstanding as of December 31, 2016 and September 30, 2017 and the changes that occurred during the nine months ended September 30, 2017:

[0001564590-17-022183:notes:40]
| (In thousands, except per share amounts) |  | Number of Stock Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Stock options outstanding, December 31, 2016 |  |  | 6,338 |  |  | $ | 22.14 |  |  |  | 5.63 |  |  | $ | 16,972 |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (358 | ) |  | $ | 18.44 |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (54 | ) |  | $ | 17.49 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (90 | ) |  | $ | 27.31 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, September 30, 2017 |  |  | 5,836 |  |  | $ | 22.33 |  |  |  | 4.92 |  |  | $ | 20,669 |  |
| Stock options vested and expected to vest, September 30, 2017 |  |  | 5,836 |  |  | $ | 22.33 |  |  |  | 4.92 |  |  | $ | 20,669 |  |
| Stock options exercisable, September 30, 2017 |  |  | 4,311 |  |  | $ | 24.02 |  |  |  | 3.99 |  |  | $ | 10,845 |  |

[0001564590-17-022183:notes:41]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between the closing price of our stock on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money stock options) that would have been received by the option holders had all option holders exercised their options on September 30, 2017. The aggregate intrinsic value will change based on the fair market value of our stock.

[0001564590-17-022183:notes:42]
The total pre-tax intrinsic value of options exercised during the three and nine months ended September 30, 2017 was $1.1 million and $1.6 million, respectively.

[0001564590-17-022183:notes:43]
As of September 30, 2017, there was $4.0 million of unrecognized compensation expense related to unvested stock options, which is expected to be recognized over an average remaining recognition period of 1.7 years.

[0001564590-17-022183:notes:44]
The fair value of our stock options is estimated using the Black-Scholes model. The determination of the fair value of stock options on the date of grant using the Black-Scholes model is affected by our stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate.

[0001564590-17-022183:notes:45]
There were no stock options granted during the three or nine months ended September 30, 2017. The weighted-average assumptions and value of options granted during the three and nine months ended September 30, 2016 were as follows:

[0001564590-17-022183:notes:46]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2016 |  |  | 2016 |  |
| Expected volatility |  |  | 34.55 | % |  |  | 34.66 | % |
| Risk-free interest rate |  |  | 1.20 | % |  |  | 1.28 | % |
| Expected dividend yield |  |  | 1.83 | % |  |  | 1.88 | % |
| Expected life (in years) |  |  | 6.21 |  |  |  | 6.24 |  |
| Weighted-average estimated value |  | $ | 5.64 |  |  | $ | 5.50 |  |

[0001564590-17-022183:notes:47]
[same as prior period, unchanged from 0001564590-17-015623:notes:43]

[0001564590-17-022183:notes:48]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2016 and the changes that occurred during the nine months ended September 30, 2017:

[0001564590-17-022183:notes:49]
| (In thousands, except per share amounts) |  | Number of Shares |  |  | Weighted Avg. Grant Date Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2016 |  |  | 519 |  |  | $ | 20.51 |  |
| PSUs, RSUs and restricted stock granted |  |  | 526 |  |  | $ | 22.23 |  |
| PSUs, RSUs and restricted stock vested |  |  | (4 | ) |  | $ | 18.00 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (21 | ) |  | $ | 20.88 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, September 30, 2017 |  |  | 1,020 |  |  | $ | 21.40 |  |

[0001564590-17-022183:notes:50]
[same as prior period, unchanged from 0001564590-17-015623:notes:46]

[0001564590-17-022183:notes:51]
As of September 30, 2017, there was $7.1 million of unrecognized compensation expense related to unvested market-based PSUs, RSUs and restricted stock, which is expected to be recognized over an average remaining recognition period of 2.8 years. In addition, there was $11.5 million of unrecognized compensation expense related to unvested performance-based PSUs, which will be recognized over the requisite service period of three years as achievement of the performance objective becomes probable. For the three and nine months ended September 30, 2017, no compensation expense was recognized related to these performance-based PSU awards.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-17-022183:notes:52]
6. INVESTMENTS

[0001564590-17-022183:notes:53]
At September 30, 2017, we held the following securities and investments, recorded at either fair value or cost:

[0001564590-17-022183:notes:54]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 15,898 |  |  | $ | 3,230 |  |  | $ | (15 | ) |  | $ | 19,113 |  |
| Corporate bonds |  |  | 45,223 |  |  |  | 75 |  |  |  | (79 | ) |  |  | 45,219 |  |
| Municipal fixed-rate bonds |  |  | 4,887 |  |  |  | 4 |  |  |  | (17 | ) |  |  | 4,874 |  |
| Asset-backed bonds |  |  | 7,791 |  |  |  | 5 |  |  |  | (11 | ) |  |  | 7,785 |  |
| Mortgage/Agency-backed bonds |  |  | 7,364 |  |  |  | 7 |  |  |  | (41 | ) |  |  | 7,330 |  |
| U.S. government bonds |  |  | 21,000 |  |  |  | 3 |  |  |  | (109 | ) |  |  | 20,894 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 3 |  |  | — |  |  |  | 728 |  |
| Marketable equity securities |  |  | 32,394 |  |  |  | 2,649 |  |  |  | (961 | ) |  |  | 34,082 |  |
| Available-for-sale securities held at fair value |  | $ | 135,282 |  |  | $ | 5,976 |  |  | $ | (1,233 | ) |  | $ | 140,025 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 168,372 |  |

[0001564590-17-022183:notes:55]
At December 31, 2016, we held the following securities and investments, recorded at either fair value or cost:

[0001564590-17-022183:notes:56]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 12,367 |  |  | $ | 2,271 |  |  | $ | (42 | ) |  | $ | 14,596 |  |
| Corporate bonds |  |  | 66,522 |  |  |  | 64 |  |  |  | (174 | ) |  |  | 66,412 |  |
| Municipal fixed-rate bonds |  |  | 11,799 |  |  |  | 12 |  |  |  | (37 | ) |  |  | 11,774 |  |
| Asset-backed bonds |  |  | 10,201 |  |  |  | 19 |  |  |  | (14 | ) |  |  | 10,206 |  |
| Mortgage/Agency-backed bonds |  |  | 13,080 |  |  |  | 15 |  |  |  | (91 | ) |  |  | 13,004 |  |
| U.S. government bonds |  |  | 30,022 |  |  |  | 15 |  |  |  | (270 | ) |  |  | 29,767 |  |
| Foreign government bonds |  |  | 3,729 |  |  |  | 2 |  |  |  | (1 | ) |  |  | 3,730 |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | — |  |  |  | 11,855 |  |
| Marketable equity securities |  |  | 30,571 |  |  |  | 311 |  |  |  | (1,503 | ) |  |  | 29,379 |  |
| Available-for-sale securities held at fair value |  | $ | 190,146 |  |  | $ | 2,709 |  |  | $ | (2,132 | ) |  | $ | 190,723 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 767 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 219,290 |  |

[0001564590-17-022183:notes:57]
As of September 30, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds and foreign government bonds had the following contractual maturities:

[0001564590-17-022183:notes:58]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 20,232 |  |  | $ | 2,250 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,903 |  |  | $ | — |  |
| One to two years |  |  | 11,678 |  |  |  | 724 |  |  | $ | 2,638 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 10,029 |  |  |  | 730 |  |  |  | 2,235 |  |  |  | — |  |  |  | 10,413 |  |  |  | 728 |  |
| Three to five years |  |  | 3,280 |  |  |  | 1,170 |  |  |  | 1,550 |  |  |  | 917 |  |  |  | 1,578 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 450 |  |  |  | 1,348 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 912 |  |  |  | 5,065 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 45,219 |  |  | $ | 4,874 |  |  | $ | 7,785 |  |  | $ | 7,330 |  |  | $ | 20,894 |  |  | $ | 728 |  |

[0001564590-17-022183:notes:59]
Actual maturities may differ from contractual maturities because some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-17-022183:notes:60]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-17-022183:notes:61]
At September 30, 2017, we held a $27.8 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $27.8 million at September 30, 2017 and December 31, 2016. At September 30, 2017 and December 31, 2016, the estimated fair value of the Bond using a level 2 valuation technique was approximately $28.0 million and $28.1 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

[0001564590-17-022183:notes:62]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and nine months ended September 30, 2017 and 2016, other-than-temporary impairment charges were not significant.

[0001564590-17-022183:notes:63]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments:

[0001564590-17-022183:notes:64]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Gross realized gains |  | $ | 1,094 |  |  | $ | 1,346 |  |  | $ | 3,324 |  |  | $ | 5,226 |  |
| Gross realized losses |  | $ | (85 | ) |  | $ | (30 | ) |  | $ | (455 | ) |  | $ | (1,072 | ) |

[0001564590-17-022183:notes:65]
As of September 30, 2017 and 2016, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.

[0001564590-17-022183:notes:66]
We have categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows:  Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-17-022183:notes:67]
|  |  | Fair Value Measurements at September 30, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 8,115 |  |  | $ | 8,115 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 35,436 |  |  |  | — |  |  |  | 35,436 |  |  |  | — |  |
| Cash equivalents |  |  | 43,551 |  |  |  | 8,115 |  |  |  | 35,436 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 19,113 |  |  |  | 19,113 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 45,219 |  |  |  | — |  |  |  | 45,219 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 4,874 |  |  |  | — |  |  |  | 4,874 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,785 |  |  |  | — |  |  |  | 7,785 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 7,330 |  |  |  | — |  |  |  | 7,330 |  |  |  | — |  |
| U.S. government bonds |  |  | 20,894 |  |  |  | 20,894 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 728 |  |  |  | — |  |  |  | 728 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 34,082 |  |  |  | 34,082 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 140,025 |  |  |  | 74,089 |  |  |  | 65,936 |  |  |  | — |  |
| Total |  | $ | 183,576 |  |  | $ | 82,204 |  |  | $ | 101,372 |  |  | $ | — |  |

[0001564590-17-022183:notes:68]
|  |  | Fair Value Measurements at December 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,878 |  |  | $ | 6,878 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 17,222 |  |  |  | — |  |  |  | 17,222 |  |  |  | — |  |
| Cash equivalents |  |  | 24,100 |  |  |  | 6,878 |  |  |  | 17,222 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 14,596 |  |  |  | 14,596 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 66,412 |  |  |  | — |  |  |  | 66,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 11,774 |  |  |  | — |  |  |  | 11,774 |  |  |  | — |  |
| Asset-backed bonds |  |  | 10,206 |  |  |  | — |  |  |  | 10,206 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 13,004 |  |  |  | — |  |  |  | 13,004 |  |  |  | — |  |
| U.S. government bonds |  |  | 29,767 |  |  |  | 29,767 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 3,730 |  |  |  | — |  |  |  | 3,730 |  |  |  | — |  |
| Variable Rate Demand Notes |  |  | 11,855 |  |  |  | — |  |  |  | 11,855 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 29,379 |  |  |  | 29,379 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 190,723 |  |  |  | 73,742 |  |  |  | 116,981 |  |  |  | — |  |
| Total |  | $ | 214,823 |  |  | $ | 80,620 |  |  | $ | 134,203 |  |  | $ | — |  |

[0001564590-17-022183:notes:69]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-17-022183:notes:70]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-022183:notes:71]
[same as prior period, unchanged from 0001564590-17-015623:notes:67]

[0001564590-17-022183:notes:72]
[same as prior period, unchanged from 0001564590-17-015623:notes:68]

[0001564590-17-022183:notes:73]
[same as prior period, unchanged from 0001564590-17-015623:notes:69]

[0001564590-17-022183:notes:74]
[same as prior period, unchanged from 0001564590-17-015623:notes:70]

[0001564590-17-022183:notes:75]
[same as prior period, unchanged from 0001564590-17-015623:notes:71]

[0001564590-17-022183:notes:76]
[same as prior period, unchanged from 0001564590-17-015623:notes:72]

[0001564590-17-022183:notes:77]
As of September 30, 2017, we had foreign exchange forward contracts outstanding with notional amounts totaling $7.0 million (€5.9 million), which hedge a portion of projected inventory purchases expected to be settled in the fourth quarter of 2017. We have determined that there was no hedge ineffectiveness for the quarter ended September 30, 2017 related to these contracts.

[0001564590-17-022183:notes:78]
[same as prior period, unchanged from 0001564590-17-015623:notes:74]

[0001564590-17-022183:notes:79]
The fair values of our derivative instruments recorded in the Consolidated Balance Sheet as of September 30, 2017 and December 31, 2016 were as follows:

[0001564590-17-022183:notes:80]
| (In thousands) |  | Balance Sheet Location |  | September 30, 2017 |  |  | December 31, 2016 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  | $ | — |  |  | $ | 159 |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  |  | (402 | ) |  |  | — |  |
| Total derivatives |  |  |  | $ | (402 | ) |  | $ | 159 |  |

[0001564590-17-022183:notes:81]
The change in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the three and nine months ended September 30, 2017 and 2016 were as follows:

[0001564590-17-022183:notes:82]
|  |  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Income Statement |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | Location |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | (334 | ) |  | $ | (37 | ) |  | $ | (819 | ) |  | $ | 153 |  |

[0001564590-17-022183:notes:83]
The change in our derivatives designated as hedging instruments recorded in other comprehensive income (OCI) and reclassified to income, net of tax, during the three and nine months ended September 30, 2017 and 2016 were as follows:

[0001564590-17-022183:notes:84]
|  |  | Amount of Gains (Losses) Recognized in |  |  |  |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  |  |  | from AOCI into Income |  |
|  |  | Three Months Ended |  |  | Location of Gains |  | Three Months Ended |  |
|  |  | September 30, |  |  | (Losses) Reclassified |  | September 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | from AOCI into Income |  | 2017 |  |  | 2016 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (127 | ) |  | $ | — |  |  | Cost of Sales |  | $ | (269 | ) |  | $ | — |  |

[0001564590-17-022183:notes:85]
|  |  | Amount of Gains (Losses) Recognized in |  |  |  |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  |  |  | from AOCI into Income |  |
|  |  | Nine Months Ended |  |  | Location of Gains |  | Nine Months Ended |  |
|  |  | September 30, |  |  | (Losses) Reclassified |  | September 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | from AOCI into Income |  | 2017 |  |  | 2016 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (619 | ) |  | $ | — |  |  | Cost of Sales |  | $ | (423 | ) |  | $ | — |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-17-022183:notes:86]
[same as prior period, unchanged from 0001564590-17-015623:notes:82]

[0001564590-17-022183:notes:87]
At September 30, 2017 and December 31, 2016, inventory consisted of the following:

[0001564590-17-022183:notes:88]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Raw materials |  | $ | 44,002 |  |  | $ | 40,461 |  |
| Work in process |  |  | 4,859 |  |  |  | 4,003 |  |
| Finished goods |  |  | 67,369 |  |  |  | 60,653 |  |
| Total |  | $ | 116,230 |  |  | $ | 105,117 |  |

[0001564590-17-022183:notes:89]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At September 30, 2017 and December 31, 2016, raw materials reserves totaled $16.8 million and $14.6 million, respectively, and finished goods inventory reserves totaled $12.9 million and $10.6 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-17-022183:notes:90]
[same as prior period, unchanged from 0001564590-17-015623:notes:86]

[0001564590-17-022183:notes:91]
Goodwill, all of which relates to our acquisition of Bluesocket, Inc., was $3.5 million at September 30, 2017 and December 31, 2016, of which $3.1 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-17-022183:notes:92]
[same as prior period, unchanged from 0001564590-17-015623:notes:88]

[0001564590-17-022183:notes:93]
[same as prior period, unchanged from 0001564590-17-015623:notes:89]

[0001564590-17-022183:notes:94]
The following table presents our intangible assets as of September 30, 2017 and December 31, 2016:

[0001564590-17-022183:notes:95]
| (In thousands) |  | September 30, 2017 |  |  | December 31, 2016 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 7,400 |  |  | $ | (4,042 | ) |  | $ | 3,358 |  |  | $ | 6,899 |  |  | $ | (3,208 | ) |  | $ | 3,691 |  |
| Developed technology |  |  | 6,740 |  |  |  | (5,789 | ) |  |  | 951 |  |  |  | 6,444 |  |  |  | (5,061 | ) |  |  | 1,383 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (2,229 | ) |  |  | 111 |  |  |  | 2,340 |  |  |  | (2,129 | ) |  |  | 211 |  |
| Supply agreement |  |  | 1,400 |  |  |  | (1,400 | ) |  |  | — |  |  |  | 1,400 |  |  |  | (544 | ) |  |  | 856 |  |
| License |  |  | 500 |  |  |  | (403 | ) |  |  | 97 |  |  |  | 500 |  |  |  | (113 | ) |  |  | 387 |  |
| Patent |  |  | 500 |  |  |  | (71 | ) |  |  | 429 |  |  |  | 500 |  |  |  | (20 | ) |  |  | 480 |  |
| Trade names |  |  | 370 |  |  |  | (322 | ) |  |  | 48 |  |  |  | 370 |  |  |  | (285 | ) |  |  | 85 |  |
| Non-compete |  |  | 200 |  |  |  | (93 | ) |  |  | 107 |  |  |  | 200 |  |  |  | (26 | ) |  |  | 174 |  |
| Total |  | $ | 19,450 |  |  | $ | (14,349 | ) |  | $ | 5,101 |  |  | $ | 18,653 |  |  | $ | (11,386 | ) |  | $ | 7,267 |  |

[0001564590-17-022183:notes:96]
Amortization expense, all of which relates to business acquisitions, was $0.5 million for the three months ended September 30, 2017 and 2016, and $2.4 million and $1.4 million for the nine months ended September 30, 2017 and 2016, respectively.

[0001564590-17-022183:notes:97]
As of September 30, 2017, the estimated future amortization expense of our intangible assets is as follows:

[0001564590-17-022183:notes:98]
| (In thousands) |  | Amount |  |
| Remainder of 2017 |  | $ | 473 |  |
| 2018 |  |  | 1,207 |  |
| 2019 |  |  | 691 |  |
| 2020 |  |  | 654 |  |
| 2021 |  |  | 599 |  |
| Thereafter |  |  | 1,477 |  |
| Total |  | $ | 5,101 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-17-022183:notes:99]
[same as prior period, unchanged from 0001564590-17-015623:notes:95]

[0001564590-17-022183:notes:100]
A summary of the changes in stockholders’ equity for the nine months ended September 30, 2017 is as follows:

[0001564590-17-022183:notes:101]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2016 |  | $ | 479,517 |  |
| Net income |  |  | 34,950 |  |
| Dividend payments |  |  | (13,031 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (43 | ) |
| Net unrealized gains on available-for-sale securities (net of tax) |  |  | 2,512 |  |
| Net unrealized losses on cash flow hedges (net of tax) |  |  | (196 | ) |
| Defined benefit plan adjustments (net of tax) |  |  | 214 |  |
| Foreign currency translation adjustment |  |  | 5,402 |  |
| Proceeds from stock option exercises |  |  | 6,606 |  |
| Purchase of treasury stock |  |  | (17,348 | ) |
| ASU 2016-09 adoption |  |  | 10 |  |
| Stock-based compensation expense |  |  | 5,573 |  |
| Balance, September 30, 2017 |  | $ | 504,166 |  |

[0001564590-17-022183:notes:102]
[same as prior period, unchanged from 0001564590-17-015623:notes:98]

[0001564590-17-022183:notes:103]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the nine months ended September 30, 2017, we repurchased 0.9 million shares of our common stock at an average price of $20.27 per share. As of September 30, 2017, we have the authority to purchase an additional 3.6 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-17-022183:notes:104]
[same as prior period, unchanged from 0001564590-17-015623:notes:100]

[0001564590-17-022183:notes:105]
We issued 0.4 million shares of treasury stock during the nine months ended September 30, 2017 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $23.64. We received proceeds totaling $6.6 million from the exercise of these stock options during the nine months ended September 30, 2017.

[0001564590-17-022183:notes:106]
[same as prior period, unchanged from 0001564590-17-015623:notes:102]

[0001564590-17-022183:notes:107]
During the nine months ended September 30, 2017, we paid cash dividends as follows (in thousands except per share amounts):

[0001564590-17-022183:notes:108]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 2, 2017 |  | February 16, 2017 |  | $ | 0.09 |  |  | $ | 4,369 |  |
| May 4, 2017 |  | May 18, 2017 |  | $ | 0.09 |  |  | $ | 4,350 |  |
| August 3, 2017 |  | August 17, 2017 |  | $ | 0.09 |  |  | $ | 4,312 |  |

[0001564590-17-022183:notes:109]
[same as prior period, unchanged from 0001564590-17-015623:notes:105]

[0001564590-17-022183:notes:110]
Other comprehensive income consists of unrealized gains (losses) on available-for-sale securities; unrealized gains (losses) on cash flow hedges; reclassification adjustments for amounts included in net income related to impairments of available-for-sale securities, realized gains (losses) on available-for-sale securities, realized gains (losses) on cash flow hedges, and amortization of actuarial gains (losses) related to our defined benefit plan; defined benefit plan adjustments; and foreign currency translation adjustments.

[0001564590-17-022183:notes:111]
The following tables present the changes in accumulated other comprehensive income, net of tax, by component for the three months ended September 30, 2017 and 2016:

[0001564590-17-022183:notes:112]
|  |  | Three Months Ended September 30, 2017 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 2,112 |  |  | $ | (338 | ) |  | $ | (4,876 | ) |  | $ | (3,714 | ) |  | $ | (6,816 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,420 |  |  |  | (127 | ) |  |  | — |  |  |  | 1,541 |  |  |  | 2,834 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (616 | ) |  |  | 269 |  |  |  | 73 |  |  |  | — |  |  |  | (274 | ) |
| Net current period other comprehensive income (loss) |  |  | 804 |  |  |  | 142 |  |  |  | 73 |  |  |  | 1,541 |  |  |  | 2,560 |  |
| Ending balance |  | $ | 2,916 |  |  | $ | (196 | ) |  | $ | (4,803 | ) |  | $ | (2,173 | ) |  | $ | (4,256 | ) |

[0001564590-17-022183:notes:113]
|  |  | Three Months Ended September 30, 2016 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,512 |  |  | $ | (3,828 | ) |  | $ | (6,379 | ) |  | $ | (8,695 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,028 |  |  |  | — |  |  |  | 575 |  |  |  | 1,603 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (770 | ) |  |  | 36 |  |  |  | — |  |  |  | (734 | ) |
| Net current period other comprehensive income (loss) |  |  | 258 |  |  |  | 36 |  |  |  | 575 |  |  |  | 869 |  |
| Ending balance |  | $ | 1,770 |  |  | $ | (3,792 | ) |  | $ | (5,804 | ) |  | $ | (7,826 | ) |

[0001564590-17-022183:notes:114]
The following tables present the changes in accumulated other comprehensive income, net of tax, by component for the nine months ended September 30, 2017 and 2016:

[0001564590-17-022183:notes:115]
|  |  | Nine Months Ended September 30, 2017 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 404 |  |  | $ | — |  |  | $ | (5,017 | ) |  | $ | (7,575 | ) |  | $ | (12,188 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 4,262 |  |  |  | (619 | ) |  |  | — |  |  |  | 5,402 |  |  |  | 9,045 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,750 | ) |  |  | 423 |  |  |  | 214 |  |  |  | — |  |  |  | (1,113 | ) |
| Net current period other comprehensive income (loss) |  |  | 2,512 |  |  |  | (196 | ) |  |  | 214 |  |  |  | 5,402 |  |  |  | 7,932 |  |
| Ending balance |  | $ | 2,916 |  |  | $ | (196 | ) |  | $ | (4,803 | ) |  | $ | (2,173 | ) |  | $ | (4,256 | ) |

[0001564590-17-022183:notes:116]
|  |  | Nine Months Ended September 30, 2016 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,932 |  |  | $ | (3,895 | ) |  | $ | (7,006 | ) |  | $ | (8,969 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 2,267 |  |  |  | — |  |  |  | 1,202 |  |  |  | 3,469 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,429 | ) |  |  | 103 |  |  |  | — |  |  |  | (2,326 | ) |
| Net current period other comprehensive income (loss) |  |  | (162 | ) |  |  | 103 |  |  |  | 1,202 |  |  |  | 1,143 |  |
| Ending balance |  | $ | 1,770 |  |  | $ | (3,792 | ) |  | $ | (5,804 | ) |  | $ | (7,826 | ) |

[0001564590-17-022183:notes:117]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the three months ended September 30, 2017 and 2016:

[0001564590-17-022183:notes:118]
| (In thousands) |  | Three Months Ended September 30, 2017 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,066 |  |  | Net realized investment gain |
| Impairment expense |  |  | (57 | ) |  | Net realized investment gain |
| Net losses on derivatives designated as hedging instruments |  |  | (385 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (106 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 518 |  |  |  |
| Tax (expense) benefit |  |  | (244 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 274 |  |  |  |

[0001564590-17-022183:notes:119]
[same as prior period, unchanged from 0001564590-17-015623:notes:115]

[0001564590-17-022183:notes:120]
| (In thousands) |  | Three Months Ended September 30, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,268 |  |  | Net realized investment gain |
| Impairment expense |  |  | (6 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (51 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,211 |  |  |  |
| Tax (expense) benefit |  |  | (477 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 734 |  |  |  |

[0001564590-17-022183:notes:121]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the nine months ended September 30, 2017 and 2016:

[0001564590-17-022183:notes:122]
| (In thousands) |  | Nine Months Ended September 30, 2017 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 3,031 |  |  | Net realized investment gain |
| Impairment expense |  |  | (162 | ) |  | Net realized investment gain |
| Net losses on derivatives designated as hedging instruments |  |  | (539 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (310 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 2,020 |  |  |  |
| Tax (expense) benefit |  |  | (907 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,113 |  |  |  |

[0001564590-17-022183:notes:123]
| (In thousands) |  | Nine Months Ended September 30, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 4,383 |  |  | Net realized investment gain |
| Impairment expense |  |  | (401 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (149 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 3,833 |  |  |  |
| Tax (expense) benefit |  |  | (1,507 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,326 |  |  |  |

[0001564590-17-022183:notes:124]
The following table presents the tax effects related to the change in each component of other comprehensive income for the three months ended September 30, 2017 and 2016:

[0001564590-17-022183:notes:125]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 2,328 |  |  | $ | (908 | ) |  | $ | 1,420 |  |  | $ | 1,685 |  |  | $ | (657 | ) |  | $ | 1,028 |  |
| Unrealized gains (losses) on cash flow hedges |  |  | (184 | ) |  |  | 57 |  |  |  | (127 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (1,009 | ) |  |  | 393 |  |  |  | (616 | ) |  |  | (1,262 | ) |  |  | 492 |  |  |  | (770 | ) |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | 385 |  |  |  | (116 | ) |  |  | 269 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 106 |  |  |  | (33 | ) |  |  | 73 |  |  |  | 51 |  |  |  | (15 | ) |  |  | 36 |  |
| Foreign currency translation adjustment |  |  | 1,541 |  |  |  | — |  |  |  | 1,541 |  |  |  | 575 |  |  |  | — |  |  |  | 575 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 3,167 |  |  | $ | (607 | ) |  | $ | 2,560 |  |  | $ | 1,049 |  |  | $ | (180 | ) |  | $ | 869 |  |

[0001564590-17-022183:notes:126]
The following table presents the tax effects related to the change in each component of other comprehensive income for the nine months ended September 30, 2017 and 2016:

[0001564590-17-022183:notes:127]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 6,987 |  |  | $ | (2,725 | ) |  | $ | 4,262 |  |  | $ | 3,716 |  |  | $ | (1,449 | ) |  | $ | 2,267 |  |
| Unrealized gains (losses) on cash flow hedges |  |  | (897 | ) |  |  | 278 |  |  |  | (619 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (2,869 | ) |  |  | 1,119 |  |  |  | (1,750 | ) |  |  | (3,982 | ) |  |  | 1,553 |  |  |  | (2,429 | ) |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | 539 |  |  |  | (116 | ) |  |  | 423 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 310 |  |  |  | (96 | ) |  |  | 214 |  |  |  | 149 |  |  |  | (46 | ) |  |  | 103 |  |
| Foreign currency translation adjustment |  |  | 5,402 |  |  |  | — |  |  |  | 5,402 |  |  |  | 1,202 |  |  |  | — |  |  |  | 1,202 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 9,472 |  |  | $ | (1,540 | ) |  | $ | 7,932 |  |  | $ | 1,085 |  |  | $ | 58 |  |  | $ | 1,143 |  |


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-022183:notes:128]
[same as prior period, unchanged from 0001564590-17-015623:notes:124]

[0001564590-17-022183:notes:129]
A summary of the calculation of basic and diluted earnings per share for the three and nine months ended September 30, 2017 and 2016 is as follows:

[0001564590-17-022183:notes:130]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 15,898 |  |  | $ | 12,415 |  |  | $ | 34,950 |  |  | $ | 27,657 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,870 |  |  |  | 48,470 |  |  |  | 48,110 |  |  |  | 48,839 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 487 |  |  |  | 137 |  |  |  | 385 |  |  |  | 137 |  |
| PSUs, RSUs and restricted stock |  |  | 174 |  |  |  | 71 |  |  |  | 123 |  |  |  | 60 |  |
| Weighted average number of shares – diluted |  |  | 48,531 |  |  |  | 48,678 |  |  |  | 48,618 |  |  |  | 49,036 |  |
| Net income per share – basic |  | $ | 0.33 |  |  | $ | 0.26 |  |  | $ | 0.73 |  |  | $ | 0.57 |  |
| Net income per share – diluted |  | $ | 0.33 |  |  | $ | 0.26 |  |  | $ | 0.72 |  |  | $ | 0.56 |  |

[0001564590-17-022183:notes:131]
Anti-dilutive options to purchase common stock outstanding were excluded from the above calculations. Anti-dilutive options totaled 3.2 million and 5.6 million for the three months ended September 30, 2017 and 2016, respectively, and 3.9 million and 5.7 million for the nine months ended September 30, 2017 and 2016, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-022183:notes:132]
[same as prior period, unchanged from 0001564590-17-015623:notes:128]

[0001564590-17-022183:notes:133]
[same as prior period, unchanged from 0001564590-17-015623:notes:129]

[0001564590-17-022183:notes:134]
[same as prior period, unchanged from 0001564590-17-015623:notes:130]

[0001564590-17-022183:notes:135]
The following table presents information about the reported sales and gross profit of our reportable segments for the three and nine months ended September 30, 2017 and 2016. We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-17-022183:notes:136]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 145,467 |  |  | $ | 71,939 |  |  | $ | 136,277 |  |  | $ | 65,289 |  |
| Services & Support |  |  | 39,645 |  |  |  | 14,559 |  |  |  | 32,613 |  |  |  | 10,519 |  |
| Total |  | $ | 185,112 |  |  | $ | 86,498 |  |  | $ | 168,890 |  |  | $ | 75,808 |  |

[0001564590-17-022183:notes:137]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 444,607 |  |  | $ | 214,762 |  |  | $ | 398,709 |  |  | $ | 195,804 |  |
| Services & Support |  |  | 95,457 |  |  |  | 30,083 |  |  |  | 75,086 |  |  |  | 24,753 |  |
| Total |  | $ | 540,064 |  |  | $ | 244,845 |  |  | $ | 473,795 |  |  | $ | 220,557 |  |

[0001564590-17-022183:notes:138]
[same as prior period, unchanged from 0001564590-17-015623:notes:134]

[0001564590-17-022183:notes:139]
[same as prior period, unchanged from 0001564590-17-015623:notes:135]

[0001564590-17-022183:notes:140]
The table below presents sales information by category for the three and nine months ended September 30, 2017 and 2016:

[0001564590-17-022183:notes:141]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Access & Aggregation |  | $ | 135,959 |  |  | $ | 120,618 |  |  | $ | 394,741 |  |  | $ | 316,705 |  |
| Customer Devices |  |  | 35,582 |  |  |  | 32,984 |  |  |  | 105,683 |  |  |  | 106,213 |  |
| Traditional & Other Products |  |  | 13,571 |  |  |  | 15,288 |  |  |  | 39,640 |  |  |  | 50,877 |  |
| Total |  | $ | 185,112 |  |  | $ | 168,890 |  |  | $ | 540,064 |  |  | $ | 473,795 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-17-022183:notes:142]
[same as prior period, unchanged from 0001564590-17-015623:notes:138]

[0001564590-17-022183:notes:143]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $10.9 million and $8.5 million at September 30, 2017 and December 31, 2016 respectively. During the three months ended March 31, 2017, we recorded a receivable and a reduction in warranty expense related to a settlement with a third party supplier for a defective component, the impact of which is reflected in the table below. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0001564590-17-022183:notes:144]
A summary of warranty expense and write-off activity for the three and nine months ended September 30, 2017 and 2016 is as follows:

[0001564590-17-022183:notes:145]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 9,180 |  |  | $ | 8,935 |  |  | $ | 8,548 |  |  | $ | 8,739 |  |
| Plus: Amounts charged to cost and expenses |  |  | 4,087 |  |  |  | 4,012 |  |  |  | 6,401 |  |  |  | 6,341 |  |
| Less: Deductions |  |  | (2,328 | ) |  |  | (4,195 | ) |  |  | (4,010 | ) |  |  | (6,328 | ) |
| Balance at end of period |  | $ | 10,939 |  |  | $ | 8,752 |  |  | $ | 10,939 |  |  | $ | 8,752 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-022183:notes:146]
14. COMMITMENTS AND CONTINGENCIES

[0001564590-17-022183:notes:147]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-17-022183:notes:148]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2017, of which $7.7 million has been applied to these commitments.


## us-gaap:SubsequentEventsTextBlock

[0001564590-17-022183:notes:149]
15. SUBSEQUENT EVENTS

[0001564590-17-022183:notes:150]
On October 17, 2017, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on November 1, 2017. The payment date will be November 15, 2017. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
