# ADTN notes — 0001193125-12-220696


## adtn:ComprehensiveIncomePolicyTextBlock

[0001193125-12-220696:notes:1]
In June 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2011-05, Presentation of Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to present the components of net income and other comprehensive income either as one continuous statement or as two consecutive statements. ASU 2011-05 eliminates the option to present the components of other comprehensive income as part of the statement of changes in stockholders' equity. While ASU 2011-05 changes the presentation of comprehensive income, it does not change the components that are recognized in net income or comprehensive income under current accounting guidance. This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption permitted. We adopted this amendment during the three months ended March 31, 2012, and we have provided the disclosures required for the three months ended March 31, 2012 and 2011.

[0001193125-12-220696:notes:2]
In December 2011, the FASB issued Accounting Standards Update No. 2011-12, Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other Comprehensive Income in Accounting Standards Update No. 2011-05 (ASU 2011-12). ASU 2011-12 defers the effective date for certain presentation requirements that relate to reclassification adjustments and the effect of those reclassification adjustments on the financial statements. This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption permitted. We adopted this amendment during the three months ended March 31, 2012. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the three months ended March 31, 2012.


## adtn:ScheduleOfCashDividendsPaidTableTextBlock

[0001193125-12-220696:notes:3]
| Record Date |  | Payment Date |  |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 2, 2012 |  |  | February 16, 2012 |  |  | $ | 0.09 |  |  | $ | 5,739 |  |


## adtn:ScheduleOfEntityWideInformationRevenueFromExternalCustomersBySubcategoryProductsAndServicesTableTextBlock

[0001193125-12-220696:notes:4]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |
| Core Products |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 49,482 |  |  | $ | 51,782 |  |
| Optical (included in Carrier Systems) |  |  | 14,255 |  |  |  | 20,916 |  |
| Internetworking (NetVanta & Multi-service Access Gateways) (included in Business Networking) |  |  | 40,974 |  |  |  | 32,883 |  |
| Subtotal |  |  | 104,711 |  |  |  | 105,581 |  |
| Legacy Products |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 18,959 |  |  |  | 40,945 |  |
| Other products (excluding HDSL) |  |  | 11,065 |  |  |  | 18,996 |  |
| Subtotal |  |  | 30,024 |  |  |  | 59,941 |  |
| Total |  | $ | 134,735 |  |  | $ | 165,522 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-12-220696:notes:5]
[same as prior period, unchanged from 0000950123-11-094914:notes:16]

[0001193125-12-220696:notes:6]
On August 4, 2011, we acquired all of the outstanding stock of Bluesocket, Inc., a provider of wireless network solutions with virtual control, for $23.7 million in cash. The acquisition provides us with IEEE802.11N enterprise class wireless LAN expertise, technology, and products to address the growing transition within small-medium enterprises and large enterprises to wireless networks and mobile devices. We have included the financial results of Bluesocket in our consolidated financial statements since the date of acquisition. Pro forma results of operations prior to the closing date for the acquisition have not been presented because the effect of the acquisition was not material to our financial results. The allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date is as follows:

[0001193125-12-220696:notes:7]
| (In Thousands) |  |  |  |
| Cash |  | $ | 1,027 |  |
| Accounts receivable |  |  | 298 |  |
| Inventory |  |  | 792 |  |
| Prepaid expenses |  |  | 357 |  |
| Property, plant and equipment |  |  | 173 |  |
| Deferred tax assets, net |  |  | 12,962 |  |
| Accounts payable |  |  | (441 | ) |
| Unearned revenue |  |  | (600 | ) |
| Accrued expenses |  |  | (332 | ) |
| Net assets acquired |  |  | 14,236 |  |
| Customer relationships |  |  | 1,530 |  |
| Developed technology |  |  | 3,230 |  |
| Intellectual property |  |  | 930 |  |
| Trade names |  |  | 270 |  |
| Goodwill |  |  | 3,492 |  |
| Total purchase price |  | $ | 23,688 |  |

[0001193125-12-220696:notes:8]
During the fourth quarter of 2011, the purchase price and purchase price allocation were adjusted for our final valuations. The adjustments resulted in a decrease to the goodwill recognized in the transaction.

[0001193125-12-220696:notes:9]
The net deferred tax assets acquired are primarily related to net operating losses and previously capitalized and unamortized research and development expense for tax deduction purposes.

[0001193125-12-220696:notes:10]
The fair value of the customer relationships, developed technology and intellectual property acquired was calculated using an income approach (excess earnings method) and is being amortized using the straight-line method. The customer relationships and intellectual property are being amortized over an estimated useful life of 7 years and the developed technology is being amortized over an average estimated useful life of 4.5 years.

[0001193125-12-220696:notes:11]
The fair value of the trade names acquired was calculated using an income approach (relief from royalty method) and is being amortized using the straight-line method over the estimate useful life of 4.5 years.

[0001193125-12-220696:notes:12]
The goodwill of $3.5 million generated from this acquisition is primarily related to expected synergies and was assigned to our Enterprise Networks division. The goodwill will not be deductible for U.S. federal income tax purposes.

[0001193125-12-220696:notes:13]
For the three months ended March 31, 2012, we incurred acquisition related adjustments and amortization of acquired intangibles of $0.5 million related to this acquisition.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-220696:notes:14]
13. COMMITMENTS AND CONTINGENCIES

[0001193125-12-220696:notes:15]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001193125-12-220696:notes:16]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2012, of which $7.7 million has been applied to these commitments.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-12-220696:notes:17]
Basis of Presentation

[0001193125-12-220696:notes:18]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (ADTRAN) have been prepared pursuant to the rules and regulations for reporting on Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles for complete financial statements are not included herein. The December 31, 2011 Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.

[0001193125-12-220696:notes:19]
In the opinion of management, all adjustments necessary for a fair presentation of these interim statements have been included and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim statements should be read in conjunction with the financial statements and notes thereto included in ADTRAN's Annual Report on Form 10-K for the year ended December 31, 2011, filed on February 29, 2012 with the SEC.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-220696:notes:20]
[same as prior period, unchanged from 0000950123-11-094914:notes:27]

[0001193125-12-220696:notes:21]
The following table summarizes the stock-based compensation expense related to stock options, restricted stock units (RSUs) and restricted stock for the three months ended March 31, 2012 and 2011, which was recognized as follows:

[0001193125-12-220696:notes:22]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 101 |  |  | $ | 91 |  |
| Selling, general and administrative expense |  |  | 1,051 |  |  |  | 1,007 |  |
| Research and development expense |  |  | 1,069 |  |  |  | 991 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,120 |  |  |  | 1,998 |  |
| Total stock-based compensation expense |  |  | 2,221 |  |  |  | 2,089 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (301 | ) |  |  | (440 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,920 |  |  | $ | 1,649 |  |

[0001193125-12-220696:notes:23]
The fair value of our stock options was estimated using the Black-Scholes model. The determination of the fair value of stock options on the date of grant using the Black-Scholes model is affected by our stock price as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. There were no stock options granted during the three months ended March 31, 2012 or 2011.

[0001193125-12-220696:notes:24]
The fair value of our RSUs is calculated using a Monte Carlo Simulation valuation method. There were no RSU grants during the three months ended March 31, 2012 or 2011.

[0001193125-12-220696:notes:25]
The fair value of restricted stock is equal to the closing price of our stock on the date of grant. There were no restricted stock grants during the three months ended March 31, 2012 or 2011.

[0001193125-12-220696:notes:26]
Stock-based compensation expense recognized in our Consolidated Statements of Income for the three months ended March 31, 2012 and 2011 is based on stock options, RSUs and restricted stock ultimately expected to vest, and has been reduced for estimated forfeitures. Estimated forfeitures for stock options were based upon historical experience and approximate 1.6% annually. We estimated a 0% forfeiture rate for our RSUs and restricted stock due to the limited number of recipients and historical experience for these awards.

[0001193125-12-220696:notes:27]
As of March 31, 2012, total compensation expense related to non-vested stock options, RSUs and restricted stock not yet recognized was approximately $19.6 million, which is expected to be recognized over an average remaining recognition period of 2.7 years.

[0001193125-12-220696:notes:28]
The following table is a summary of our stock options outstanding as of December 31, 2011 and March 31, 2012 and the changes that occurred during the three months ended March 31, 2012:

[0001193125-12-220696:notes:29]
| In thousands, except per share amounts) |  | Number ofOptions |  |  | Weighted Avg.Exercise Price |  |  | Weighted Avg.RemainingContractualLife In Years |  |  | AggregateIntrinsicValue |  |
| Options outstanding, December 31, 2011 |  |  | 5,400 |  |  | $ | 25.66 |  |  |  | 6.78 |  |  | $ | 27,270 |  |
| Options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (16 | ) |  | $ | 27.59 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (180 | ) |  | $ | 19.71 |  |  |  |  |  |  |  |  |  |
| Options outstanding, March 31, 2012 |  |  | 5,204 |  |  | $ | 25.86 |  |  |  | 6.59 |  |  | $ | 30,189 |  |
| Options exercisable, March 31, 2012 |  |  | 2,878 |  |  | $ | 23.72 |  |  |  | 4.98 |  |  | $ | 22,332 |  |

[0001193125-12-220696:notes:30]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between ADTRAN's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on March 31, 2012. The aggregate intrinsic value will change based on the fair market value of ADTRAN's stock.

[0001193125-12-220696:notes:31]
The total pre-tax intrinsic value of options exercised during the three months ended March 31, 2012 was $3.0 million.

[0001193125-12-220696:notes:32]
The following table is a summary of our RSUs and restricted stock outstanding as of December 31, 2011 and March 31, 2012 and the changes that occurred during the three months ended March 31, 2012:

[0001193125-12-220696:notes:33]
| (In thousands, except per share amounts) |  | Numberofshares |  |  | WeightedAverageGrant DateFair Value |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2011 |  |  | 90 |  |  | $ | 34.21 |  |
| RSUs and restricted stock granted |  |  | — |  |  |  | — |  |
| RSUs and restricted stock vested |  |  | — |  |  |  | — |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  |  | — |  |
| Unvested RSUs and restricted stock, March 31, 2012 |  |  | 90 |  |  | $ | 34.21 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-220696:notes:34]
[same as prior period, unchanged from 0000950123-11-094914:notes:89]

[0001193125-12-220696:notes:35]
A summary of the calculation of basic and diluted earnings per share for the three months ended March 31, 2012 and 2011 is as follows:

[0001193125-12-220696:notes:36]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2012 |  |  | 2011 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 12,960 |  |  | $ | 34,258 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 63,809 |  |  |  | 64,189 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| Stock options |  |  | 1,008 |  |  |  | 1,711 |  |
| Restricted stock and restricted stock units |  |  | 32 |  |  |  | 57 |  |
| Weighted average number of shares – diluted |  |  | 64,849 |  |  |  | 65,957 |  |
| Net income per share – basic |  | $ | 0.20 |  |  | $ | 0.53 |  |
| Net income per share – diluted |  | $ | 0.20 |  |  | $ | 0.52 |  |

[0001193125-12-220696:notes:37]
Anti-dilutive options to purchase common stock outstanding were excluded from the above calculations. Anti-dilutive options totaled 1.9 million and 0.9 million for the three months ended March 31, 2012 and 2011, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-12-220696:notes:38]
|  |  | Fair Value Measurements at March 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket forIdenticalAssets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 10,988 |  |  | $ | 10,988 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,216 |  |  |  | 11,216 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 183,392 |  |  |  | — |  |  |  | 183,392 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 193,294 |  |  |  | — |  |  |  | 193,294 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 47,920 |  |  |  | — |  |  |  | 47,920 |  |  |  | — |  |
| Fixed income bond fund |  |  | 746 |  |  |  | 746 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 25,773 |  |  |  | 25,773 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 16,302 |  |  |  | 16,302 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 478,643 |  |  |  | 54,037 |  |  |  | 424,606 |  |  |  | — |  |
| Total |  | $ | 489,631 |  |  | $ | 65,025 |  |  | $ | 424,606 |  |  | $ | — |  |

[0001193125-12-220696:notes:39]
|  |  | Fair Value Measurements at December 31, 2011 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket forIdenticalAssets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 13,696 |  |  | $ | 13,696 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 7,712 |  |  |  | 7,712 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 156,753 |  |  |  | — |  |  |  | 156,753 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 174,826 |  |  |  | — |  |  |  | 174,826 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | 69,660 |  |  |  | — |  |
| Fixed income bond fund |  |  | 721 |  |  |  | 721 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 18,743 |  |  |  | 18,743 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 12,567 |  |  |  | 12,567 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 440,982 |  |  |  | 39,743 |  |  |  | 401,239 |  |  |  | — |  |
| Total |  | $ | 454,678 |  |  | $ | 53,439 |  |  | $ | 401,239 |  |  | $ | — |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-12-220696:notes:40]
[same as prior period, unchanged from 0000950123-11-094914:notes:66]

[0001193125-12-220696:notes:41]
The changes in the carrying value of goodwill, all of which is included in our Enterprise Networks division, for the three months ended March 31, 2012 are as follows:

[0001193125-12-220696:notes:42]
| (In thousands) |  |  |  |
| Balance, December 31, 2011 |  | $ | 3,492 |  |
| Acquisitions |  |  | — |  |
| Impairment losses |  |  | — |  |
| Balance, March 31, 2012 |  | $ | 3,492 |  |
| Balance as of March 31, 2012 |  |  |  |  |
| Goodwill |  | $ | 3,492 |  |
| Accumulated impairment losses |  |  | — |  |
| Total goodwill |  | $ | 3,492 |  |

[0001193125-12-220696:notes:43]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. When evaluating whether goodwill is impaired, we first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If we determine that the two-step quantitative test is necessary , then we compare the fair value of the reporting unit to which the goodwill is assigned to the reporting unit's carrying amount, including goodwill. If the carrying amount of the reporting unit exceeds its fair value, then the amount of the impairment loss is measured. There were no impairment losses during the three months ended March 31, 2012.

[0001193125-12-220696:notes:44]
The following table presents our intangible assets as of March 31, 2012 and December 31, 2011. Intangible assets are included in other assets in the accompanying Consolidated Balance Sheets and include intangibles acquired in conjunction with our acquisition of Objectworld Communications Corporation on September 15, 2009 and Bluesocket, Inc. on August 4, 2011.

[0001193125-12-220696:notes:45]
| (In thousands) |  | March 31, 2012 |  |  | December 31, 2011 |  |
|  |  | GrossValue |  |  | AccumulatedAmortization |  |  | NetValue |  |  | GrossValue |  |  | AccumulatedAmortization |  |  | NetValue |  |
| Customer relationships |  | $ | 1,623 |  |  | $ | (239 | ) |  | $ | 1,384 |  |  | $ | 1,623 |  |  | $ | (194 | ) |  | $ | 1,429 |  |
| Developed technology |  |  | 3,230 |  |  |  | (439 | ) |  |  | 2,791 |  |  |  | 3,230 |  |  |  | (303 | ) |  |  | 2,927 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (600 | ) |  |  | 1,740 |  |  |  | 2,340 |  |  |  | (525 | ) |  |  | 1,815 |  |
| Trade names |  |  | 270 |  |  |  | (40 | ) |  |  | 230 |  |  |  | 270 |  |  |  | (28 | ) |  |  | 242 |  |
| Total |  | $ | 7,463 |  |  | $ | (1,318 | ) |  | $ | 6,145 |  |  | $ | 7,463 |  |  | $ | (1,050 | ) |  | $ | 6,413 |  |

[0001193125-12-220696:notes:46]
Amortization expense was $0.3 million and $0.1 million for the three months ended March 31, 2012 and 2011, respectively.

[0001193125-12-220696:notes:47]
As of March 31, 2012, the estimated future amortization expense of our intangible assets is as follows:

[0001193125-12-220696:notes:48]
| (In thousands) |  | Amount |  |
| Remainder of 2012 |  | $ | 953 |  |
| 2013 |  |  | 1,271 |  |
| 2014 |  |  | 1,120 |  |
| 2015 |  |  | 1,018 |  |
| 2016 |  |  | 781 |  |
| Thereafter |  |  | 1,002 |  |
| Total |  | $ | 6,145 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-220696:notes:49]
[same as prior period, unchanged from 0000950123-11-094914:notes:24]

[0001193125-12-220696:notes:50]
Our effective tax rate increased from 30.7% in the three months ended March 31, 2011 to 35.4% in the three months ended March 31, 2012. The tax provision rate in the first quarter of 2012 did not include the benefit of the research tax credit, which expired on December 31, 2011. The exclusion of this benefit in the first quarter of 2012 resulted in a 2.2 percentage point increase in our effective tax rate. Also, decreased benefits from a lower volume of stock option exercises in the first quarter of 2012 resulted in a 3.1 percentage point increase in our effective tax rate.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-220696:notes:51]
[same as prior period, unchanged from 0000950123-11-094914:notes:62]

[0001193125-12-220696:notes:52]
At March 31, 2012 and December 31, 2011, inventory consisted of the following:

[0001193125-12-220696:notes:53]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |
| Raw materials |  | $ | 44,758 |  |  | $ | 44,588 |  |
| Work in process |  |  | 5,081 |  |  |  | 3,954 |  |
| Finished goods |  |  | 45,966 |  |  |  | 39,258 |  |
| Total |  | $ | 95,805 |  |  | $ | 87,800 |  |

[0001193125-12-220696:notes:54]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At March 31, 2012 and December 31, 2011, raw materials reserves totaled $8.2 million and $7.9 million, respectively, and finished goods inventory reserves totaled $1.5 million.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-12-220696:notes:55]
| (In thousands) |  | Corporatebonds |  |  | Municipalfixed-rate bonds |  |
| Less than one year |  | $ | 24,172 |  |  | $ | 89,443 |  |
| One to two years |  |  | 112,900 |  |  |  | 50,570 |  |
| Two to three years |  |  | 44,163 |  |  |  | 16,576 |  |
| Three to four years |  |  | 2,157 |  |  |  | 36,705 |  |
| Total |  | $ | 183,392 |  |  | $ | 193,294 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-12-220696:notes:56]
5. INVESTMENTS

[0001193125-12-220696:notes:57]
At March 31, 2012, we held the following securities and investments, recorded at either fair value or cost.

[0001193125-12-220696:notes:58]
| (In thousands) |  | AmortizedCost |  |  | Gross Unrealized |  |  | CarryingValue |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,627 |  |  | $ | 663 |  |  | $ | (74 | ) |  | $ | 11,216 |  |
| Corporate bonds |  |  | 183,193 |  |  |  | 748 |  |  |  | (549 | ) |  |  | 183,392 |  |
| Municipal fixed-rate bonds |  |  | 192,853 |  |  |  | 588 |  |  |  | (147 | ) |  |  | 193,294 |  |
| Municipal variable rate demand notes |  |  | 47,920 |  |  |  | — |  |  |  | — |  |  |  | 47,920 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 219 |  |  |  | — |  |  |  | 746 |  |
| Marketable equity securities |  |  | 15,786 |  |  |  | 26,505 |  |  |  | (215 | ) |  |  | 42,076 |  |
| Available-for-sale securities held at fair value |  | $ | 450,906 |  |  | $ | 28,723 |  |  | $ | (985 | ) |  | $ | 478,644 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,115 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 529,009 |  |

[0001193125-12-220696:notes:59]
At December 31, 2011, we held the following securities and investments, recorded at either fair value or cost.

[0001193125-12-220696:notes:60]
| (In thousands) |  | AmortizedCost |  |  | Gross Unrealized |  |  | CarryingValue |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 7,994 |  |  | $ | 119 |  |  | $ | (401 | ) |  | $ | 7,712 |  |
| Corporate bonds |  |  | 159,077 |  |  |  | 181 |  |  |  | (2,505 | ) |  |  | 156,753 |  |
| Municipal fixed-rate bonds |  |  | 174,300 |  |  |  | 579 |  |  |  | (53 | ) |  |  | 174,826 |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | — |  |  |  | 69,660 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 194 |  |  |  | — |  |  |  | 721 |  |
| Marketable equity securities |  |  | 12,771 |  |  |  | 19,098 |  |  |  | (559 | ) |  |  | 31,310 |  |
| Available-for-sale securities held at fair value |  | $ | 424,329 |  |  | $ | 20,171 |  |  | $ | (3,518 | ) |  | $ | 440,982 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,123 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 491,355 |  |

[0001193125-12-220696:notes:61]
As of March 31, 2012, our corporate bonds and municipal fixed-rate bonds had the following contractual maturities:

[0001193125-12-220696:notes:62]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001193125-12-220696:notes:63]
We review our investment portfolio for potential "other-than-temporary" declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $33 thousand during the three months ended March 31, 2012 related to seven marketable equity securities. For the three months ended March 31, 2011, we recorded an other-than-temporary impairment charge of $4 thousand related to one marketable equity security.

[0001193125-12-220696:notes:64]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments.

[0001193125-12-220696:notes:65]
| Three Months Ended March 31, |  |  |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |
| Gross realized gains |  | $ | 2,669 |  |  | $ | 2,864 |  |
| Gross realized losses |  | $ | (202 | ) |  | $ | (97 | ) |

[0001193125-12-220696:notes:66]
As of March 31, 2012 and 2011, gross unrealized losses related to individual securities that had been in a continuous loss position for 12 months or longer were not significant.

[0001193125-12-220696:notes:67]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 – Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 – Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 – Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001193125-12-220696:notes:68]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001193125-12-220696:notes:69]
Our municipal variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-12-220696:notes:70]
1. SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001193125-12-220696:notes:71]
Use of Estimates

[0001193125-12-220696:notes:72]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the allowance for doubtful accounts, obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales returns, determination of the deferred revenue components of multiple element sales agreements, estimated income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001193125-12-220696:notes:73]
Recent Accounting Pronouncements

[0001193125-12-220696:notes:74]
During the first quarter of 2012, we adopted the following accounting standards, which had no material effect on our consolidated results of operations or financial condition:

[0001193125-12-220696:notes:75]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to Achieve Common Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IRFSs (ASU 2011-04). ASU 2011-04 is intended to improve the comparability of fair value measurements presented and disclosed in financial statements prepared in accordance with U.S. GAAP and IFRS. The amendments are of two types: (i) those that clarify the Board's intent about the application of existing fair value measurement and disclosure requirements and (ii) those that change a particular principle or requirement for measuring fair value or for disclosing information about fair value measurements. This update is effective for annual periods beginning after December 15, 2011. We adopted this amendment during the three months ended March 31, 2012. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the three months ended March 31, 2012.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-12-220696:notes:76]
[same as prior period, unchanged from 0000950123-11-094914:notes:111]

[0001193125-12-220696:notes:77]
Our products generally include warranties of 90 days to ten years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to systems products. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $4.7 million at March 31, 2012 and $4.1 million at December 31, 2011. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0001193125-12-220696:notes:78]
A summary of warranty expense and write-off activity for the three months ended March 31, 2012 and 2011 is as follows:

[0001193125-12-220696:notes:79]
| Three Months Ended March 31, |  | 2012 |  |  | 2011 |  |
| (In thousands) |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 4,118 |  |  | $ | 3,304 |  |
| Plus: Amounts charged to cost and expenses |  |  | 1,181 |  |  |  | 835 |  |
| Less: Deductions |  |  | (568 | ) |  |  | (620 | ) |
| Balance at end of period |  | $ | 4,731 |  |  | $ | 3,519 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-12-220696:notes:80]
12. RELATED PARTY TRANSACTIONS

[0001193125-12-220696:notes:81]
We employ the law firm of our director emeritus for legal services. All bills for services rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that the fees for such services are comparable to those charged by other firms for services rendered to us. For the three months ended March 31, 2012 and 2011, we incurred fees of $10 thousand per month for these legal services.


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0001193125-12-220696:notes:82]
|  |  | Three Months Ended March 31, 2012 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Net change in unrealized gains (losses) related to marketable securities |  | $ | 11,073 |  |  | $ | (4,318 | ) |  | $ | 6,755 |  |
| Reclassification adjustment for amounts included in net income |  |  | 3 |  |  |  | (1 | ) |  |  | 2 |  |
| Foreign currency translation adjustment |  |  | 153 |  |  |  | — |  |  |  | 153 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 11,229 |  |  | $ | (4,319 | ) |  | $ | 6,910 |  |

[0001193125-12-220696:notes:83]
The components of other comprehensive income for the three months ended March 31, 2011 are as follows:

[0001193125-12-220696:notes:84]
|  |  | Three Months Ended March 31, 2011 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Net change in unrealized gains (losses) related to marketable securities |  | $ | (3,324 | ) |  | $ | 673 |  |  | $ | (2,651 | ) |
| Reclassification adjustment for amounts included in net income |  |  | (202 | ) |  |  | 43 |  |  |  | (159 | ) |
| Foreign currency translation adjustment |  |  | 87 |  |  |  | — |  |  |  | 87 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (3,439 | ) |  | $ | 716 |  |  | $ | (2,723 | ) |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001193125-12-220696:notes:85]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |
| Carrier Systems |  | $ | 71,258 |  |  | $ | 86,750 |  |
| Business Networking |  |  | 43,142 |  |  |  | 36,363 |  |
| Loop Access |  |  | 20,335 |  |  |  | 42,409 |  |
| Total |  | $ | 134,735 |  |  | $ | 165,522 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-12-220696:notes:86]
|  |  | Three Months Ended |  |
| (In thousands) |  | March 31,2012 |  |  | March 31,2011 |  |
| United States |  | $ | 116,443 |  |  | $ | 153,113 |  |
| International |  |  | 18,292 |  |  |  | 12,409 |  |
| Total |  | $ | 134,735 |  |  | $ | 165,522 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001193125-12-220696:notes:87]
|  |  | Three Months Ended |  |
|  |  | March 31, 2012 |  |  | March 31, 2011 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 96,654 |  |  | $ | 52,883 |  |  | $ | 132,360 |  |  | $ | 79,498 |  |
| Enterprise Networks |  |  | 38,081 |  |  |  | 21,204 |  |  |  | 33,162 |  |  |  | 19,297 |  |
| Total |  | $ | 134,735 |  |  | $ | 74,087 |  |  | $ | 165,522 |  |  | $ | 98,795 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-12-220696:notes:88]
| (In thousands) |  | Stockholders'Equity |  |
| Balance, December 31, 2011 |  | $ | 692,131 |  |
| Net income |  |  | 12,960 |  |
| Dividend payments |  |  | (5,739 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (4 | ) |
| Net change in unrealized gains and losses on marketable securities (net of deferred taxes) |  |  | 6,755 |  |
| Reclassification adjustment for amounts included in net income (net of deferred taxes) |  |  | 2 |  |
| Foreign currency translation adjustment |  |  | 153 |  |
| Proceeds from stock option exercises |  |  | 3,560 |  |
| Tax benefits from stock option exercises |  |  | 1,492 |  |
| Stock-based compensation expense |  |  | 2,221 |  |
| Balance, March 31, 2012 |  | $ | 713,531 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-220696:notes:89]
[same as prior period, unchanged from 0000950123-11-094914:notes:93]

[0001193125-12-220696:notes:90]
We operate in two reportable segments: (1) the Carrier Networks Division and (2) the Enterprise Networks Division. We evaluate the performance of our segments based on gross profit; therefore, selling, general and administrative expense, research and development expenses, interest income and dividend income, interest expense, net realized investment gain/loss, other income/expense and provision for taxes are reported on an entity-wide basis only. There are no inter-segment revenues.

[0001193125-12-220696:notes:91]
The following table presents information about the reported sales and gross profit of our reportable segments for the three months ended March 31, 2012 and 2011. Asset information by reportable segment is not reported, since we do not produce such information internally.

[0001193125-12-220696:notes:92]
[same as prior period, unchanged from 0000950123-11-094914:notes:98]

[0001193125-12-220696:notes:93]
Our three major product categories are Carrier Systems, Business Networking and Loop Access.

[0001193125-12-220696:notes:94]
Carrier Systems products are used by communications service providers to provide data, voice and video services to consumers and enterprises. The Carrier Systems category includes our broadband access products comprised of Total Access® 5000 multi-service access and aggregation platform products, Total Access 1100/1200 Series Fiber-To-The-Node (FTTN) products, Ultra Broadband Ethernet (UBE) and Digital Subscriber Line Access Multiplexer (DSLAM) products. Our broadband access products are used by service providers to deliver high-speed Internet access, Voice over Internet Protocol (VoIP), IP Television (IPTV), and/or Ethernet services from the central office or remote terminal locations to customer premises. The Carrier Systems category also includes our optical products. These products consist of optical multiplexers and transceivers including those used in our Optical Networking Edge (ONE) products, NetVanta 8000 series products, and our family of OPTI products. Optical products are used to deliver higher bandwidth services, aggregate large numbers of low bandwidth services, or transport wavelength services across a fiber optic infrastructure. Total Access 1500 products, 303 concentrator products, M13 multiplexer products, and a number of mobile backhaul products are also included in the Carrier Systems product category.

[0001193125-12-220696:notes:95]
Business Networking products provide access to telecommunication services, facilitating the delivery of converged services and Unified Communications to the small and mid-sized enterprises (SME) market. The Business Networking category includes Internetworking products and Integrated Access Devices (IADs). Internetworking products consist of our Total Access IP Business Gateways, Optical Network Terminals (ONTs), Virtual Wireless LAN products and NetVanta product lines. NetVanta products include multi-service routers, managed Ethernet switches, IP Private Branch Exchange (PBX) products, IP phone products, Unified Communications solutions, Unified Threat Management (UTM) solutions, and Carrier Ethernet Network Terminating Equipment (NTE). IAD products consist of our Total Access 600 Series and the Total Access 850.

[0001193125-12-220696:notes:96]
Loop Access products are used by carrier and enterprise customers for access to copper-based telecommunications networks. The Loop Access category includes products such as: Digital Data Service (DDS) and Integrated Services Digital Network (Total Reach) products, High bit-rate Digital Subscriber Line (HDSL) products including Total Access 3000 HDSL and Time Division Multiplexed-Symmetrical HDSL (TDM-SHDSL) products, T1/E1/T3, Channel Service Units/Data Service Units, and TRACER fixed wireless products.

[0001193125-12-220696:notes:97]
The table below presents sales information by product category for the three months ended March 31, 2012 and 2011.

[0001193125-12-220696:notes:98]
In addition, we identify subcategories of product revenues, which we divide into our core products and legacy products. Our core products consist of Broadband Access and Optical products (included in Carrier Systems) and Internetworking products (included in Business Networking) and our legacy products include HDSL products (included in Loop Access) and other products not included in the aforementioned core products.

[0001193125-12-220696:notes:99]
[same as prior period, unchanged from 0000950123-11-094914:notes:106]

[0001193125-12-220696:notes:100]
[same as prior period, unchanged from 0000950123-11-094914:notes:108]

[0001193125-12-220696:notes:101]
The table below presents sales information by geographic area for the three months ended March 31, 2012 and 2011. International sales correlate to shipments with a non-U.S. destination.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-12-220696:notes:102]
8. STOCKHOLDERS' EQUITY

[0001193125-12-220696:notes:103]
A summary of the changes in stockholders' equity for the three months ended March 31, 2012 is as follows:

[0001193125-12-220696:notes:104]
[same as prior period, unchanged from 0000950123-11-094914:notes:78]

[0001193125-12-220696:notes:105]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 35 million shares of our common stock. During the three months ended March 31, 2012, we did not repurchase any shares of our common stock. We have the authority to purchase an additional 5.9 million shares of our common stock under plans approved by the Board of Directors on April 14, 2008 and October 11, 2011.

[0001193125-12-220696:notes:106]
[same as prior period, unchanged from 0000950123-11-094914:notes:81]

[0001193125-12-220696:notes:107]
We issued 0.2 million shares of treasury stock during the three months ended March 31, 2012 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $8.70 to $33.70. We received proceeds totaling $3.6 million from the exercise of these stock options during the three months ended March 31, 2012.

[0001193125-12-220696:notes:108]
[same as prior period, unchanged from 0000950123-11-094914:notes:83]

[0001193125-12-220696:notes:109]
During the three months ended March 31, 2012, we paid cash dividends as follows (in thousands except per share amount):

[0001193125-12-220696:notes:110]
Other Comprehensive Income

[0001193125-12-220696:notes:111]
Other comprehensive income consists of the net change in unrealized gains and losses on marketable securities, reclassification adjustments for amounts included in net income related to realized gains on previously impaired marketable securities and foreign currency translation adjustments.

[0001193125-12-220696:notes:112]
The components of other comprehensive income for the three months ended March 31, 2012 are as follows:


## us-gaap:SubsequentEventsTextBlock

[0001193125-12-220696:notes:113]
14. SUBSEQUENT EVENTS

[0001193125-12-220696:notes:114]
On April 10, 2012, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on April 26, 2012. The payment date will be May 10, 2012. The quarterly dividend payment will be approximately $5.7 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001193125-12-220696:notes:115]
On May 4, 2012, we closed on the acquisition of Nokia Siemens Networks Broadband Access Business. This acquisition provides us with an established customer base in key markets and complementary products. The net consideration exchanged between Nokia Siemens Networks and Adtran was not material. The final net consideration is subject to post-closing adjustments. This acquisition will be accounted for as a business combination. Due to the timing of the closing, we have not completed the purchase accounting associated with this acquisition as of the date of this report.

[0001193125-12-220696:notes:116]
During the second quarter of 2012 and as of May 9, 2012, we repurchased 0.3 million shares of our common stock through open market purchases at an average cost of $29.63 per share. We have the authority to purchase an additional 5.5 million shares of our common stock under plans approved by the Board of Directors on April 14, 2008 and October 11, 2011.
