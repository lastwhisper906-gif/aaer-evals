# ADTN 8-K — 0001157523-12-001772 filed 2012-04-11

## item codes, every 8-K on or before 2012-05-09

- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2012-05-09

- none on or before 2012-05-09

## item 2.02 — earnings release, exhibit 99.1

[0001157523-12-001772:8k_2_02:1]
EX-99.1
2
a50234315ex99_1.htm
EXHIBIT 99.1

[0001157523-12-001772:8k_2_02:2]
Exhibit 99.1

[0001157523-12-001772:8k_2_02:3]
ADTRAN,
      Inc. Reports Results for the First Quarter 2012 and Declares Quarterly
      Cash Dividend

[0001157523-12-001772:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--April 10, 2012--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the first quarter 2012. For the
      quarter, sales were $134,735,000 compared to $165,522,000 for the first
      quarter of 2011. Net income was $12,960,000 for the quarter compared to
      $34,258,000 for the first quarter of 2011. Earnings per share, assuming
      dilution, were $0.20 for the quarter compared to $0.52 for the first
      quarter of 2011. Non-GAAP earnings per share for the quarter were $0.25
      compared to $0.55 for the first quarter of 2011. Non-GAAP earnings per
      share exclude the effect of acquisition related expenses, amortizations
      and adjustments related to the acquisition of Bluesocket, Inc. and the
      planned acquisition of the NSN Broadband Access business, and stock
      compensation expense. The reconciliation between GAAP earnings per
      share, diluted, and non-GAAP earnings per share, diluted, is in the
      table provided.

[0001157523-12-001772:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “As expected, we saw
      an improvement late in the quarter after a slower than normal start in
      carrier spending. As a result of this slow start, Broadband Access
      revenues for the quarter were $49.5 million, in range with the same
      period last year. Our Internetworking category saw another strong
      performance with revenues of $41.0 million, an increase of 25% from the
      same period last year. Revenues for our core product areas in total for
      the quarter were $104.7 million, basically flat compared to the same
      period last year. Although the quarter did not meet our initial
      expectations, we believe the issues relate to timing, not market
      positioning, and that our strategic areas of focus are well aligned with
      global market trends and will provide long term growth for our company.”

[0001157523-12-001772:8k_2_02:6]
The Company also announced that its Board of Directors declared a cash
      dividend for the first quarter of 2012. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on April 26, 2012. The ex-dividend date is April 24, 2012 and
      the payment date is May 10, 2012.

[0001157523-12-001772:8k_2_02:7]
The Company confirmed that its first quarter conference call will be
      held Wednesday, April 11, 2012 at 9:30 a.m. Central Time. This
      conference call will be web cast live through StreetEvents.com. To
      listen, simply visit the Investor Relations site at http://www.adtran.com
      or http://streetevents.com approximately 10 minutes prior to the
      start of the call and click on the conference call link provided.

[0001157523-12-001772:8k_2_02:8]
An online replay of the conference call will be available for seven days
      at http://streetevents.com. In addition, an online replay of the
      conference call, as well as the text of the Company's earnings release,
      will be available on the Investor Relations site at http://www.adtran.com
      for at least 12 months following the call.

[0001157523-12-001772:8k_2_02:9]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment, with a portfolio of more than 1,700 solutions.
      ADTRAN’s products enable voice, data, video, and Internet communications
      across a variety of network infrastructures. ADTRAN solutions are
      currently in use by service providers, private enterprises, government
      organizations, and millions of individual users worldwide.

[0001157523-12-001772:8k_2_02:10]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-12-001772:8k_2_02:11]
To supplement our consolidated financial statements presented on a GAAP
      basis, ADTRAN, Inc. uses non-GAAP measures of net income per share,
      which are adjusted to exclude certain costs and expenses we believe
      appropriate to enhance an overall understanding of our past financial
      performance. The presentation of this additional information is not
      meant to be considered in isolation or as a substitute for diluted net
      income per share prepared in accordance with generally accepted
      accounting principles in the United States.

[0001157523-12-001772:8k_2_02:12]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2011. These risks and uncertainties could cause actual results to
      differ materially from those in the forward-looking statements included
      in this press release.

[0001157523-12-001772:8k_2_02:13]
| Condensed Consolidated Balance Sheet Unaudited (In thousands) |
|  |  | March 31,2012 |  | December 31,2011 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 36,539 |  | $ | 42,979 |
| Short-term investments |  |  | 161,535 |  |  | 159,347 |
| Accounts receivable, net |  |  | 74,796 |  |  | 76,130 |
| Other receivables |  |  | 8,037 |  |  | 9,743 |
| Inventory |  |  | 95,805 |  |  | 87,800 |
| Prepaid expenses |  |  | 3,861 |  |  | 3,119 |
| Deferred tax assets, net |  |  | 12,548 |  |  | 12,125 |
| Total Current Assets |  |  | 393,121 |  |  | 391,243 |
| Property, plant and equipment, net |  |  | 76,502 |  |  | 75,295 |
| Deferred tax assets, net |  |  | 5,633 |  |  | 8,345 |
| Goodwill |  |  | 3,492 |  |  | 3,492 |
| Other assets |  |  | 6,831 |  |  | 7,131 |
| Long-term investments |  |  | 367,474 |  |  | 332,008 |
| Total Assets |  | $ | 853,053 |  | $ | 817,514 |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Accounts payable |  | $ | 31,235 |  | $ | 29,404 |
| Unearned revenue |  |  | 11,376 |  |  | 9,965 |
| Accrued expenses |  |  | 6,479 |  |  | 5,876 |
| Accrued wages and benefits |  |  | 12,158 |  |  | 13,518 |
| Income tax payable, net |  |  | 10,186 |  |  | 3,169 |
| Total Current Liabilities |  |  | 71,434 |  |  | 61,932 |
| Other non-current liabilities |  |  | 21,588 |  |  | 16,951 |
| Bonds payable |  |  | 46,500 |  |  | 46,500 |
| Total Liabilities |  |  | 139,522 |  |  | 125,383 |
| Stockholders' Equity |  |  | 713,531 |  |  | 692,131 |
| Total Liabilities and Stockholders' Equity |  | $ | 853,053 |  | $ | 817,514 |

[0001157523-12-001772:8k_2_02:14]
| Consolidated Statements of Income Unaudited (In thousands, except per share data) |
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  | 2012 |  | 2011 |
| Sales |  | $ | 134,735 |  |  | $ | 165,522 |  |
| Cost of sales |  |  | 60,648 |  |  |  | 66,727 |  |
| Gross Profit |  |  | 74,087 |  |  |  | 98,795 |  |
| Selling, general and administrative expenses |  |  | 33,111 |  |  |  | 29,552 |  |
| Research and development expenses |  |  | 24,795 |  |  |  | 23,637 |  |
| Operating Income |  |  | 16,181 |  |  |  | 45,606 |  |
| Interest and dividend income |  |  | 1,861 |  |  |  | 1,789 |  |
| Interest expense |  |  | (588 | ) |  |  | (602 | ) |
| Net realized investment gain |  |  | 2,467 |  |  |  | 2,767 |  |
| Other income (expense), net |  |  | 141 |  |  |  | (125 | ) |
| Income before provision for income taxes |  |  | 20,062 |  |  |  | 49,435 |  |
| Provision for income taxes |  |  | (7,102 | ) |  |  | (15,177 | ) |
| Net Income |  | $ | 12,960 |  |  | $ | 34,258 |  |
| Weighted average shares outstanding - basic |  |  | 63,809 |  |  |  | 64,189 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 64,849 |  |  |  | 65,957 |  |
| Earnings per common share - basic |  | $ | 0.20 |  |  | $ | 0.53 |  |
| Earnings per common share - diluted (1) |  | $ | 0.20 |  |  | $ | 0.52 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001157523-12-001772:8k_2_02:15]
| Consolidated Statements of Comprehensive Income Unaudited (In thousands) |
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  |  | 2012 |  |  | 2011 |  |
| Net income |  | $ | 12,960 |  | $ | 34,258 |  |
| Other comprehensive income, net of tax |  |  |  |  |
| Net change in unrealized gains (losses) on marketable securities |  |  | 6,755 |  |  | (2,651 | ) |
| Reclassification adjustment for amounts included in net income |  |  | 2 |  |  | (159 | ) |
| Foreign currency translation |  |  | 153 |  |  | 87 |  |
| Other comprehensive income (loss), net of tax |  |  | 6,910 |  |  | (2,723 | ) |
| Comprehensive income |  | $ | 19,870 |  | $ | 31,535 |  |

[0001157523-12-001772:8k_2_02:16]
| Supplemental InformationAcquisition Related Expenses, Amortizations and AdjustmentsUnaudited (In thousands) |

[0001157523-12-001772:8k_2_02:17]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and
      on December 12, 2011, we announced the planned acquisition of the Nokia
      Siemens Networks Broadband Access business (NSN BBA). Acquisition
      related expenses, amortizations and adjustments for the three months
      ended March 31, 2012 for both transactions are as follows:

[0001157523-12-001772:8k_2_02:18]
|  |  |  | Three Months EndedMarch 31, 2012 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 218 |  |
| Amortization and adjustments of other acquisition related non-cash items |  |  | 266 |  |
| Subtotal |  | $ | 484 |  |
| Planned NSN BBA acquisition |  |  |  |  |
| Acquisition related professional fees, travel and other expenses |  |  | 1,580 |  |
| Total acquisition related expenses, amortizations and adjustments |  | $ | 2,064 |  |
| Tax effect |  |  | (803 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,261 |  |

[0001157523-12-001772:8k_2_02:19]
The acquisition related expenses, amortizations and adjustments above
      were recorded in the following Consolidated Statements of Income
      categories for the three months ended March 31, 2012:

[0001157523-12-001772:8k_2_02:20]
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 146 |  |
| Cost of goods sold |  |  | 137 |  |
| Subtotal |  | $ | 283 |  |
| Selling, general and administrative expenses |  |  | 1,561 |  |
| Research and development expenses |  |  | 220 |  |
| Subtotal |  | $ | 1,781 |  |
| Total acquisition related expenses, amortizations and adjustments |  | $ | 2,064 |  |
| Tax effect |  |  | (803 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,261 |  |

[0001157523-12-001772:8k_2_02:21]
| Supplemental Information Stock-based Compensation Expense Unaudited (In thousands) |
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  | 2012 |  | 2011 |
| Stock-based compensation expense included in cost of sales |  | $ | 101 |  |  | $ | 91 |  |
| Selling, general and administrative expense |  |  | 1,051 |  |  |  | 1,007 |  |
| Research and development expense |  |  | 1,069 |  |  |  | 991 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,120 |  |  |  | 1,998 |  |
| Total stock-based compensation expense |  |  | 2,221 |  |  |  | 2,089 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (301 | ) |  |  | (440 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,920 |  |  | $ | 1,649 |  |

[0001157523-12-001772:8k_2_02:22]
| Reconciliation of GAAP net income per share, diluted, to Non-GAAP net income per share, diluted (Unaudited) |
|  |  | Three Months Ended |
|  |  | March, 31, |
|  |  | 2012 |  | 2011 |
| GAAP earnings per common share - diluted |  | $ | 0.20 |  | $ | 0.52 |
| Acquisition-related costs |  |  | 0.02 |  |  | - |
| Stock-based compensation expense |  |  | 0.03 |  |  | 0.03 |
| Non-GAAP earnings per common share - diluted |  | $ | 0 .25 |  | $ | 0.55 |

[0001157523-12-001772:8k_2_02:23]
| Consolidated Statements of Cash Flows Unaudited (In thousands) |
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  | 2012 |  | 2011 |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 12,960 |  |  | $ | 34,258 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 3,095 |  |  |  | 2,724 |  |
| Amortization of net premium on available-for-sale investments |  |  | 2,171 |  |  |  | 1,299 |  |
| Net realized gain on long-term investments |  |  | (2,467 | ) |  |  | (2,767 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | (214 | ) |  |  | 12 |  |
| Stock-based compensation expense |  |  | 2,221 |  |  |  | 2,089 |  |
| Deferred income taxes |  |  | (2,030 | ) |  |  | 877 |  |
| Tax benefit from stock option exercises |  |  | 1,492 |  |  |  | 9,942 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (1,153 | ) |  |  | (8,847 | ) |
| Change in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | 1,334 |  |  |  | (13,562 | ) |
| Other receivables |  |  | 1,706 |  |  |  | (8,725 | ) |
| Income tax receivable, net |  |  | - |  |  |  | 2,741 |  |
| Inventory |  |  | (8,005 | ) |  |  | (4,760 | ) |
| Prepaid expenses and other assets |  |  | (710 | ) |  |  | (216 | ) |
| Accounts payable |  |  | 1,831 |  |  |  | 10,117 |  |
| Accrued expenses and other liabilities |  |  | 5,287 |  |  |  | 9,606 |  |
| Income tax payable, net |  |  | 7,017 |  |  |  | 1,699 |  |
| Net cash provided by operating activities |  |  | 24,535 |  |  |  | 36,487 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (4,086 | ) |  |  | (3,045 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 266 |  |  |  | - |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 69,364 |  |  |  | 161,687 |  |
| Purchases of available-for-sale investments |  |  | (95,646 | ) |  |  | (224,459 | ) |
| Net cash used in investing activities |  |  | (30,102 | ) |  |  | (65,817 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from stock option exercises |  |  | 3,560 |  |  |  | 31,815 |  |
| Dividend payments |  |  | (5,739 | ) |  |  | (5,775 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | 1,153 |  |  |  | 8,847 |  |
| Net cash provided by (used in) financing activities |  |  | (1,026 | ) |  |  | 34,887 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (6,593 | ) |  |  | 5,557 |  |
| Effect of exchange rate changes |  |  | 153 |  |  |  | 87 |  |
| Cash and cash equivalents, beginning of period |  |  | 42,979 |  |  |  | 31,677 |  |
| Cash and cash equivalents, end of period |  | $ | 36,539 |  |  | $ | 37,321 |  |

[0001157523-12-001772:8k_2_02:24]
CONTACT:
ADTRAN, Inc.
Jim Matthews, 256-963-8775
Senior Vice
      President/CFO
or
INVESTOR SERVICES/ASSISTANCE:
Gayle
      Ellis, 256-963-8220
