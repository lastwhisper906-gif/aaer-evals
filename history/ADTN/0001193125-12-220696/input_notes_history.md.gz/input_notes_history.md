# ADTN note change history — 0000950123-11-094914 → 0001193125-12-220696


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-05-09):
[0001193125-12-220696:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2012, of which $7.7 million has been applied to these commitments.
  (was, 2011-11-03, similarity 0.7967):
[0000950123-11-094914:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.4 million as of September 30, 2011, of which $7.7 million has been applied to
   these commitments. See Note 5 of Notes to Consolidated Financial Statements for additional
   information.


## adtn:BasisOfPresentationPolicyTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2012-05-09):
[0000950123-11-094914:note_history:2]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its
   subsidiaries (ADTRAN) have been prepared pursuant to the rules and regulations for reporting on
   Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally
   accepted accounting principles for complete financial statements are not included herein. The
   December 31, 2010 Consolidated Balance Sheet is derived from audited financial statements, but does
   not include all disclosures required by accounting principles generally accepted in the United
   States.

- removed (2012-05-09):
[0000950123-11-094914:note_history:3]
In the opinion of management, all adjustments necessary for a fair presentation of these interim
   statements have been included and are of a normal and recurring nature. The results of operations
   for an interim period are not necessarily indicative of the results for the full year. The interim
   statements should be read in conjunction with the financial statements and notes thereto included
   in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2010, filed on February 25,
   2011 with the SEC.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: title_similarity, score: 1.0

- changed (2012-05-09):
[0001193125-12-220696:note_history:4]
In the opinion of management, all adjustments necessary for a fair presentation of these interim statements have been included and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim statements should be read in conjunction with the financial statements and notes thereto included in ADTRAN's Annual Report on Form 10-K for the year ended December 31, 2011, filed on February 29, 2012 with the SEC.
  (was, 2011-11-03, similarity 0.998):
[0000950123-11-094914:note_history:4]
In the opinion of management, all adjustments necessary for a fair presentation of these interim
   statements have been included and are of a normal and recurring nature. The results of operations
   for an interim period are not necessarily indicative of the results for the full year. The interim
   statements should be read in conjunction with the financial statements and notes thereto included
   in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2010, filed on February 25,
   2011 with the SEC.

- changed (2012-05-09):
[0001193125-12-220696:note_history:5]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the allowance for doubtful accounts, obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales returns, determination of the deferred revenue components of multiple element sales agreements, estimated income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.
  (was, 2011-11-03, similarity 0.7783):
[0000950123-11-094914:note_history:5]
The preparation of financial statements in conformity with accounting principles generally accepted
   in the United States of America requires management to make estimates and assumptions that affect
   the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities
   at the date of the financial statements, and the reported amounts of revenue and expense during the
   reporting period. Our more significant estimates include the allowance for doubtful accounts,
   obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales
   returns, estimated income tax contingencies, the fair value of stock-based compensation, and the
   evaluation of other-than-temporary declines in the value of investments. Actual amounts could
   differ significantly from these estimates.

- changed (2012-05-09):
[0001193125-12-220696:note_history:6]
During the first quarter of 2012, we adopted the following accounting standards, which had no material effect on our consolidated results of operations or financial condition:
  (was, 2011-11-03, similarity 0.907):
[0000950123-11-094914:note_history:6]
During the nine months ended September 30, 2011, we adopted the following accounting standards,
   which had no material effect on our consolidated results of operations or financial condition:

- changed (2012-05-09):
[0001193125-12-220696:note_history:7]
In June 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2011-05, Presentation of Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to present the components of net income and other comprehensive income either as one continuous statement or as two consecutive statements. ASU 2011-05 eliminates the option to present the components of other comprehensive income as part of the statement of changes in stockholders' equity. While ASU 2011-05 changes the presentation of comprehensive income, it does not change the components that are recognized in net income or comprehensive income under current accounting guidance. This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption permitted. We adopted this amendment during the three months ended March 31, 2012, and we have provided the disclosures required for the three months ended March 31, 2012 and 2011.
  (was, 2011-11-03, similarity 0.8342):
[0000950123-11-094914:note_history:7]
In June 2011, the FASB issued Accounting Standards Update No. 2011-05, Presentation of
   Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to present the components of
   net income and other comprehensive income either as one continuous statement or as two consecutive
   statements. ASU 2011-05 eliminates the option to present the components of other comprehensive
   income as part of the statement of changes in stockholders’ equity. While ASU 2011-05 changes the
   presentation of comprehensive income, it does not change the components that are recognized in net
   income or comprehensive income under current accounting guidance. This update is effective for
   fiscal years, and interim periods within those years, ending after December 15, 2011, with early
   adoption permitted. We plan to adopt this amendment during the first quarter of 2012. Since ASU
   2011-05 affects presentation only, it will have no effect on our consolidated results of operations
   or financial condition.

- added (2012-05-09):
[0001193125-12-220696:note_history:8]
In December 2011, the FASB issued Accounting Standards Update No. 2011-12, Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other Comprehensive Income in Accounting Standards Update No. 2011-05 (ASU 2011-12). ASU 2011-12 defers the effective date for certain presentation requirements that relate to reclassification adjustments and the effect of those reclassification adjustments on the financial statements. This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption permitted. We adopted this amendment during the three months ended March 31, 2012. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the three months ended March 31, 2012.

- changed (2012-05-09):
[0001193125-12-220696:note_history:9]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to Achieve Common Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IRFSs (ASU 2011-04). ASU 2011-04 is intended to improve the comparability of fair value measurements presented and disclosed in financial statements prepared in accordance with U.S. GAAP and IFRS. The amendments are of two types: (i) those that clarify the Board's intent about the application of existing fair value measurement and disclosure requirements and (ii) those that change a particular principle or requirement for measuring fair value or for disclosing information about fair value measurements. This update is effective for annual periods beginning after December 15, 2011. We adopted this amendment during the three months ended March 31, 2012. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the three months ended March 31, 2012.
  (was, 2011-11-03, similarity 0.8051):
[0000950123-11-094914:note_history:9]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to Achieve Common
   Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IFRSs (ASU 2011-04). ASU
   2011-04 is intended to improve the comparability of fair value measurements presented and disclosed
   in financial statements prepared in
   accordance with U.S. GAAP and IFRS. The amendments are of two types: (i) those that clarify the
   Board’s intent about the application of existing fair value measurement and disclosure requirements
   and (ii) those that change a particular principle or requirement for measuring fair value or for
   disclosing information about fair value measurements. This update is effective for annual periods
   beginning after December 15, 2011. We do not expect the adoption of this amendment will have a
   material impact on our consolidated results of operations or financial condition.

- removed (2012-05-09):
[0000950123-11-094914:note_history:10]
In September 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards
   Update No. 2011-08, Testing Goodwill for Impairment (ASU 2011-08). Existing accounting guidance
   requires that an entity perform a test for goodwill impairment, on at least an annual basis, by
   first comparing the fair value of a reporting unit with its carrying amount, including goodwill.
   If the fair value of a reporting unit is less than its carrying amount, then the second step of the
   test is to be performed to measure the amount of impairment loss, if any. ASU 2011-08 will allow
   an entity to first assess qualitative factors to determine whether it is necessary to perform the
   two-step quantitative goodwill impairment test. An entity will no longer be required to calculate
   the fair value of a reporting unit unless the entity determines, based on a qualitative assessment,
   that it is more likely than not that its fair value is less than its carrying amount. This update
   is effective for annual and interim goodwill impairment tests performed for fiscal years beginning
   after December 15, 2011, with early adoption permitted. We plan to adopt this amendment during the
   fourth quarter. We do not expect the adoption of this amendment will have a material impact on our
   consolidated results of operations or financial condition.

- removed (2012-05-09):
[0000950123-11-094914:note_history:11]
In October 2009, the FASB issued Accounting Standards Update No. 2009-13, Multiple-Deliverable
   Revenue Arrangements (ASU 2009-13). ASU 2009-13 provides amendments to the criteria in Subtopic
   605-25 of the ASC for separating consideration in multiple-deliverable arrangements. As a result
   of those amendments, multiple-deliverable arrangements are separated in more circumstances than
   under previously existing U.S. GAAP. ASU 2009-13 established a selling price hierarchy for
   determining the selling price of a deliverable and replaced the term fair value in the revenue
   allocation guidance with selling price to clarify that the allocation of revenue is based on
   entity-specific assumptions rather than assumptions of a marketplace participant. ASU 2009 -13
   also eliminated the residual method of allocation and required that arrangement consideration be
   allocated at the inception of the arrangement to all deliverables using the relative selling price
   method and required that a vendor determine its best estimate of selling price in a manner that is
   consistent with that used to determine the price to sell the deliverable on a standalone basis.

- removed (2012-05-09):
[0000950123-11-094914:note_history:12]
We generally sell our products and services separately, but in some circumstances products and
   services may be sold in bundles that contain multiple deliverables. A sale that includes multiple
   deliverables is evaluated to determine the units of accounting, and the revenue from the
   arrangement is allocated to each item requiring separate revenue recognition based on the relative
   selling price and corresponding terms of the contract. We strive to use vendor-specific objective
   evidence of selling price. When this evidence is not available, we are generally not able to
   determine third-party evidence of selling price because of the extent of customization among
   competing products or services from other companies. In these cases, estimated selling price is
   determined based on the particular circumstances of the arrangement and is used to allocate
   revenues to each unit of accounting. Revenue is recognized incrementally as the necessary criteria
   for each item is met.

- removed (2012-05-09):
[0000950123-11-094914:note_history:13]
We adopted this amendment during the first quarter of 2011. The adoption of this amendment had no
   effect on our consolidated results of operations and financial condition for the three or nine
   months ended September 30, 2011.

- removed (2012-05-09):
[0000950123-11-094914:note_history:14]
In October 2009, the FASB issued Accounting Standards Update No. 2009-14, Certain Revenue
   Arrangements that Include Software Arrangements. ASU 2009-14 changed the accounting model for
   revenue arrangements that include both tangible products and software elements. Tangible products
   containing software components and non-software components that function together to deliver the
   tangible product’s essential functionality are no longer within the scope of the software revenue
   guidance in Subtopic 985-605 of the ASC. In addition, ASU 2009-14 requires that hardware
   components of a tangible product containing software components always be excluded from the
   software revenue guidance. In that regard, ASU 2009-14 provides additional guidance on how to
   determine which software, if any, relating to the tangible product also would be excluded from the
   scope of the software revenue guidance. ASU 2009-14 also provides guidance on how a vendor should
   allocate arrangement consideration to deliverables in an arrangement that includes both tangible
   products and software. ASU 2009-14 also provides further guidance on how to allocate arrangement
   consideration when an arrangement includes deliverables both included and excluded from the scope
   of the software revenue guidance. We adopted this amendment during the first quarter of 2011. The
   adoption of this amendment had no effect on our consolidated results of operations and financial
   condition for the three or nine months ended September 30, 2011.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2012-05-09):
[0001193125-12-220696:note_history:15]
At March 31, 2012, we held the following securities and investments, recorded at either fair value or cost.
  (was, 2011-11-03, similarity 0.9463):
[0000950123-11-094914:note_history:15]
At December 31, 2010, we held the following securities and investments, recorded at either fair
   value or cost:

- changed (2012-05-09):
[0001193125-12-220696:note_history:16]
| (In thousands) |  | AmortizedCost |  |  | Gross Unrealized |  |  | CarryingValue |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,627 |  |  | $ | 663 |  |  | $ | (74 | ) |  | $ | 11,216 |  |
| Corporate bonds |  |  | 183,193 |  |  |  | 748 |  |  |  | (549 | ) |  |  | 183,392 |  |
| Municipal fixed-rate bonds |  |  | 192,853 |  |  |  | 588 |  |  |  | (147 | ) |  |  | 193,294 |  |
| Municipal variable rate demand notes |  |  | 47,920 |  |  |  | — |  |  |  | — |  |  |  | 47,920 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 219 |  |  |  | — |  |  |  | 746 |  |
| Marketable equity securities |  |  | 15,786 |  |  |  | 26,505 |  |  |  | (215 | ) |  |  | 42,076 |  |
| Available-for-sale securities held at fair value |  | $ | 450,906 |  |  | $ | 28,723 |  |  | $ | (985 | ) |  | $ | 478,644 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,115 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 529,009 |  |
  (was, 2011-11-03, similarity 0.9164):
[0000950123-11-094914:note_history:16]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 6,636 |  |  | $ | 113 |  |  | $ | (635 | ) |  | $ | 6,114 |  |
| Corporate bonds |  |  | 178,560 |  |  |  | 316 |  |  |  | (2,219 | ) |  |  | 176,657 |  |
| Municipal fixed-rate bonds |  |  | 140,405 |  |  |  | 578 |  |  |  | (37 | ) |  |  | 140,946 |  |
| Municipal variable rate demand notes |  |  | 60,705 |  |  |  | — |  |  |  | — |  |  |  | 60,705 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 165 |  |  |  | — |  |  |  | 691 |  |
| Marketable equity securities |  |  | 12,662 |  |  |  | 22,391 |  |  |  | (1,076 | ) |  |  | 33,977 |  |
| Available-for-sale securities held at fair value |  | $ | 399,494 |  |  | $ | 23,563 |  |  | $ | (3,967 | ) |  | $ | 419,090 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,152 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 469,492 |  |

- changed (2012-05-09):
[0001193125-12-220696:note_history:17]
At December 31, 2011, we held the following securities and investments, recorded at either fair value or cost.
  (was, 2011-11-03, similarity 0.9665):
[0000950123-11-094914:note_history:17]
At September 30, 2011, we held the following securities and investments, recorded at either fair
   value or cost:

- changed (2012-05-09):
[0001193125-12-220696:note_history:18]
| (In thousands) |  | AmortizedCost |  |  | Gross Unrealized |  |  | CarryingValue |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 7,994 |  |  | $ | 119 |  |  | $ | (401 | ) |  | $ | 7,712 |  |
| Corporate bonds |  |  | 159,077 |  |  |  | 181 |  |  |  | (2,505 | ) |  |  | 156,753 |  |
| Municipal fixed-rate bonds |  |  | 174,300 |  |  |  | 579 |  |  |  | (53 | ) |  |  | 174,826 |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | — |  |  |  | 69,660 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 194 |  |  |  | — |  |  |  | 721 |  |
| Marketable equity securities |  |  | 12,771 |  |  |  | 19,098 |  |  |  | (559 | ) |  |  | 31,310 |  |
| Available-for-sale securities held at fair value |  | $ | 424,329 |  |  | $ | 20,171 |  |  | $ | (3,518 | ) |  | $ | 440,982 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,123 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 491,355 |  |
  (was, 2011-11-03, similarity 0.9164):
[0000950123-11-094914:note_history:18]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 3,483 |  |  | $ | 770 |  |  | $ | (7 | ) |  | $ | 4,246 |  |
| Corporate bonds |  |  | 126,671 |  |  |  | 630 |  |  |  | (229 | ) |  |  | 127,072 |  |
| Municipal fixed-rate bonds |  |  | 71,212 |  |  |  | 268 |  |  |  | (13 | ) |  |  | 71,467 |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | — |  |  |  | 116,745 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 220 |  |  |  | — |  |  |  | 746 |  |
| Marketable equity securities |  |  | 11,486 |  |  |  | 36,657 |  |  |  | (133 | ) |  |  | 48,010 |  |
| Available-for-sale securities held at fair value |  | $ | 330,123 |  |  | $ | 38,545 |  |  | $ | (382 | ) |  | $ | 368,286 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,103 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 418,639 |  |

- added (2012-05-09):
[0001193125-12-220696:note_history:19]
As of March 31, 2012, our corporate bonds and municipal fixed-rate bonds had the following contractual maturities:

- added (2012-05-09):
[0001193125-12-220696:note_history:20]
| (In thousands) |  | Corporatebonds |  |  | Municipalfixed-rate bonds |  |
| Less than one year |  | $ | 24,172 |  |  | $ | 89,443 |  |
| One to two years |  |  | 112,900 |  |  |  | 50,570 |  |
| Two to three years |  |  | 44,163 |  |  |  | 16,576 |  |
| Three to four years |  |  | 2,157 |  |  |  | 36,705 |  |
| Total |  | $ | 183,392 |  |  | $ | 193,294 |  |

- added (2012-05-09):
[0001193125-12-220696:note_history:21]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

- changed (2012-05-09):
[0001193125-12-220696:note_history:22]
We review our investment portfolio for potential "other-than-temporary" declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $33 thousand during the three months ended March 31, 2012 related to seven marketable equity securities. For the three months ended March 31, 2011, we recorded an other-than-temporary impairment charge of $4 thousand related to one marketable equity security.
  (was, 2011-11-03, similarity 0.9579):
[0000950123-11-094914:note_history:22]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $32 thousand during the nine
   months ended September 30, 2011 related to
   seven marketable equity securities. For the nine months ended September 30, 2010, we recorded an
   other-than-temporary impairment charge of $43 thousand related to five marketable equity
   securities.

- added (2012-05-09):
[0001193125-12-220696:note_history:23]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments.

- added (2012-05-09):
[0001193125-12-220696:note_history:24]
| Three Months Ended March 31, |  |  |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |
| Gross realized gains |  | $ | 2,669 |  |  | $ | 2,864 |  |
| Gross realized losses |  | $ | (202 | ) |  | $ | (97 | ) |

- added (2012-05-09):
[0001193125-12-220696:note_history:25]
As of March 31, 2012 and 2011, gross unrealized losses related to individual securities that had been in a continuous loss position for 12 months or longer were not significant.

- changed (2012-05-09):
[0001193125-12-220696:note_history:26]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 – Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 – Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 – Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.
  (was, 2011-11-03, similarity 0.9963):
[0000950123-11-094914:note_history:26]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have
   categorized our cash equivalents held in money market funds and our investments held at fair value
   into a three-level fair value hierarchy based on the priority of the inputs to the valuation
   technique for the cash equivalents and investments as follows: Level 1 — Values based on
   unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 — Values
   based on quoted prices in markets that are not active or model inputs that are observable either
   directly or indirectly; Level 3 — Values based on prices or valuation techniques that require
   inputs that are both unobservable and significant to the overall fair value measurement. These
   inputs include information supplied by investees.

- changed (2012-05-09):
[0001193125-12-220696:note_history:27]
|  |  | Fair Value Measurements at March 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket forIdenticalAssets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 10,988 |  |  | $ | 10,988 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,216 |  |  |  | 11,216 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 183,392 |  |  |  | — |  |  |  | 183,392 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 193,294 |  |  |  | — |  |  |  | 193,294 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 47,920 |  |  |  | — |  |  |  | 47,920 |  |  |  | — |  |
| Fixed income bond fund |  |  | 746 |  |  |  | 746 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 25,773 |  |  |  | 25,773 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 16,302 |  |  |  | 16,302 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 478,643 |  |  |  | 54,037 |  |  |  | 424,606 |  |  |  | — |  |
| Total |  | $ | 489,631 |  |  | $ | 65,025 |  |  | $ | 424,606 |  |  | $ | — |  |
  (was, 2011-11-03, similarity 0.8338):
[0000950123-11-094914:note_history:27]
|  |  | Fair Value Measurements at December 31, 2010 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 14,532 |  |  | $ | 14,532 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 4,246 |  |  |  | 4,246 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 127,072 |  |  |  | — |  |  |  | 127,072 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 71,467 |  |  |  | — |  |  |  | 71,467 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | 116,745 |  |  |  | — |  |
| Fixed income bond fund |  |  | 746 |  |  |  | 746 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 35,596 |  |  |  | 35,596 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 12,414 |  |  |  | 12,414 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 368,286 |  |  |  | 53,002 |  |  |  | 315,284 |  |  |  | — |  |
| Total |  | $ | 382,818 |  |  | $ | 67,534 |  |  | $ | 315,284 |  |  | $ | — |  |

- changed (2012-05-09):
[0001193125-12-220696:note_history:28]
|  |  | Fair Value Measurements at December 31, 2011 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket forIdenticalAssets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 13,696 |  |  | $ | 13,696 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 7,712 |  |  |  | 7,712 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 156,753 |  |  |  | — |  |  |  | 156,753 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 174,826 |  |  |  | — |  |  |  | 174,826 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | 69,660 |  |  |  | — |  |
| Fixed income bond fund |  |  | 721 |  |  |  | 721 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 18,743 |  |  |  | 18,743 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 12,567 |  |  |  | 12,567 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 440,982 |  |  |  | 39,743 |  |  |  | 401,239 |  |  |  | — |  |
| Total |  | $ | 454,678 |  |  | $ | 53,439 |  |  | $ | 401,239 |  |  | $ | — |  |
  (was, 2011-11-03, similarity 0.8416):
[0000950123-11-094914:note_history:28]
|  |  | Fair Value Measurements at September 30, 2011 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 7,898 |  |  | $ | 7,898 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 6,114 |  |  |  | 6,114 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 176,657 |  |  |  | — |  |  |  | 176,657 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 140,946 |  |  |  | — |  |  |  | 140,946 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 60,705 |  |  |  | — |  |  |  | 60,705 |  |  |  | — |  |
| Fixed income bond fund |  |  | 691 |  |  |  | 691 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 22,701 |  |  |  | 22,701 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 11,276 |  |  |  | 11,276 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 419,090 |  |  |  | 40,782 |  |  |  | 378,308 |  |  |  | — |  |
| Total |  | $ | 426,988 |  |  | $ | 48,680 |  |  | $ | 378,308 |  |  | $ | — |  |

- changed (2012-05-09):
[0001193125-12-220696:note_history:29]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.
  (was, 2011-11-03, similarity 0.7662):
[0000950123-11-094914:note_history:29]
As of September 30, 2011 and December 31, 2010, the fair value of the investments in
   available-for-sale Level 2 corporate bonds and municipal fixed-rate bonds was $317.6 million and
   $198.5 million, respectively. The fair value of these securities is calculated using a weighted
   average market price for each security. Market prices are obtained from a variety of industry
   standard data providers, security master files from large financial institutions, and other
   third-party sources. These multiple market prices are used as inputs into a
   distribution-curve-based algorithm to determine the daily market value of each security.

- changed (2012-05-09):
[0001193125-12-220696:note_history:30]
Our municipal variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.
  (was, 2011-11-03, similarity 0.6475):
[0000950123-11-094914:note_history:30]
As of September 30, 2011 and December 31, 2010, the fair value of the investments in
   available-for-sale Level 2 municipal variable rate demand notes was $60.7 million and $116.7
   million, respectively. These securities have a structure that implies a standard expected market
   price. The frequent interest rate resets make it reasonable to expect the price to stay at par.
   These securities are priced at the expected market price.

- removed (2012-05-09):
[0000950123-11-094914:note_history:31]
At September 30, 2011, we held $6.1 million of deferred compensation plan assets, carried at fair
   value.

- removed (2012-05-09):
[0000950123-11-094914:note_history:32]
At September 30, 2011, we held $176.7 million of corporate bonds. These bonds are classified as
   available-for-sale and had an average duration of 0.9 years at September 30, 2011. At September
   30, 2011, approximately 1% of our corporate bond portfolio had a credit rating of AAA, 13% had a
   credit rating of AA, 48% had a credit rating of A, and 38% had a credit rating of BBB. Because our
   bond portfolio has a high quality rating and contractual maturities of a short duration, we are
   able to obtain prices for these bonds derived from observable market inputs, or for similar
   securities traded in an active market, on a daily basis.

- removed (2012-05-09):
[0000950123-11-094914:note_history:33]
At September 30, 2011, we held $140.9 million of municipal fixed-rate bonds. These bonds are
   classified as available-for-sale and had an average duration of 1.1 years at September 30, 2011.
   At September 30, 2011, approximately 16% of our municipal fixed-rate bond portfolio had a credit
   rating of AAA, 66% had a credit rating of AA, and 18% had a credit rating of A. Because our bond
   portfolio has a high quality rating and contractual maturities of a short duration, we are able to
   obtain prices for these bonds derived from observable market inputs, or for similar securities
   traded in an active market, on a daily basis.

- removed (2012-05-09):
[0000950123-11-094914:note_history:34]
At September 30, 2011, we held $60.7 million of municipal variable rate demand notes, all of which
   were classified as available-for-sale. At September 30, 2011, 14% of our municipal variable rate
   demand notes had a credit rating of AAA,
   72% had a credit rating of AA, 14% had a credit rating of A, and all contained put options of seven
   days. Despite the long-term nature of their stated contractual maturities, we routinely buy and
   sell these securities and we believe that we have the ability to quickly liquidate them. Our
   investments in these securities are recorded at fair value, and the interest rates reset every
   seven days. We believe we have the ability to sell our variable rate demand notes to the
   remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide
   to liquidate our investment in a particular variable rate demand note. At September 30, 2011,
   approximately 40% of our variable rate demand notes were supported by letters of credit from banks
   that we believe to be in good financial condition. The remaining 60% of our variable rate demand
   notes were supported by standby purchase agreements. As a result of these factors, we had no
   cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from these
   investments. All income generated from these investments was recorded as interest income. We have
   not recorded any losses relating to municipal variable rate demand notes.

- removed (2012-05-09):
[0000950123-11-094914:note_history:35]
At September 30, 2011, we held $0.7 million of a fixed income bond fund.

- removed (2012-05-09):
[0000950123-11-094914:note_history:36]
At September 30, 2011, we held $34.0 million of marketable equity securities, including a single
   security, of which we held 1.2 million shares, carried at a fair value of $21.3 million. We sold
   0.3 million shares of this security during the nine months ended September 30, 2011. The sale of
   this security resulted in proceeds of $6.1 million and a realized gain of $6.0 million. This
   single security traded an average of approximately 0.9 million shares per day in the first nine
   months of 2011 in an active market on a European stock exchange. This single security comprises
   $20.9 million of the gross unrealized gains included in the fair value of our marketable equity
   securities at September 30, 2011. The remaining $1.5 million of gross unrealized gains and $1.1
   million of gross unrealized losses at September 30, 2011 were spread amongst more than 400 equity
   securities.

- removed (2012-05-09):
[0000950123-11-094914:note_history:37]
At September 30, 2011, we held a $48.3 million restricted certificate of deposit, which is carried
   at cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At September 30, 2011, the estimated fair value of the Bond was approximately
   $48.3 million, based on a debt security with a comparable interest rate and maturity and a Standard
   and Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.

- removed (2012-05-09):
[0000950123-11-094914:note_history:38]
At September 30, 2011, we held $2.2 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.4 million at September 30, 2011, based on unobservable inputs including information supplied by
   the company and the fund managers. We have committed to invest up to an aggregate of $7.9 million
   in the two private equity funds, and we have contributed $8.4 million as of September 30, 2011, of
   which $7.7 million has been applied toward these commitments. As of September 30, 2011, we have
   received distributions related to these two private equity funds of $8.5 million, of which $2.0
   million was recorded as investment income. These investments are carried at cost, net of
   distributions, with distributions in excess of our investment recorded as investment income. The
   remaining commitment under the funds is $0.2 million, which expires in 2013. We have not been
   required to record any impairment losses related to these investments during the nine months ended
   September 30, 2011.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2012-05-09):
[0001193125-12-220696:note_history:39]
We employ the law firm of our director emeritus for legal services. All bills for services rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that the fees for such services are comparable to those charged by other firms for services rendered to us. For the three months ended March 31, 2012 and 2011, we incurred fees of $10 thousand per month for these legal services.
  (was, 2011-11-03, similarity 0.9317):
[0000950123-11-094914:note_history:39]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three and nine month periods ended September 30, 2011 and 2010, we incurred fees of
   $10 thousand per month for these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2012-05-09):
[0001193125-12-220696:note_history:40]
On April 10, 2012, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on April 26, 2012. The payment date will be May 10, 2012. The quarterly dividend payment will be approximately $5.7 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
  (was, 2011-11-03, similarity 0.963):
[0000950123-11-094914:note_history:40]
On October 11, 2011, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on October 27,
   2011. The payment date will be November 10, 2011. The quarterly dividend payment will be
   approximately $5.7 million. In July 2003, our Board of Directors elected to begin declaring
   quarterly dividends on our common stock considering the tax treatment of dividends and adequate
   levels of Company liquidity.

- added (2012-05-09):
[0001193125-12-220696:note_history:41]
On May 4, 2012, we closed on the acquisition of Nokia Siemens Networks Broadband Access Business. This acquisition provides us with an established customer base in key markets and complementary products. The net consideration exchanged between Nokia Siemens Networks and Adtran was not material. The final net consideration is subject to post-closing adjustments. This acquisition will be accounted for as a business combination. Due to the timing of the closing, we have not completed the purchase accounting associated with this acquisition as of the date of this report.

- added (2012-05-09):
[0001193125-12-220696:note_history:42]
During the second quarter of 2012 and as of May 9, 2012, we repurchased 0.3 million shares of our common stock through open market purchases at an average cost of $29.63 per share. We have the authority to purchase an additional 5.5 million shares of our common stock under plans approved by the Board of Directors on April 14, 2008 and October 11, 2011.

- removed (2012-05-09):
[0000950123-11-094914:note_history:43]
On October 11, 2011, we announced that our Board of Directors had authorized the repurchase of an
   additional 5.0 million shares of our common stock to commence upon completion of the repurchase
   plan announced on April 14, 2008. Upon completion of the current plan, under which we have the
   remaining authority to purchase 0.9 million shares, the new plan to repurchase 5.0 million shares
   will be implemented through open market or private purchases from time to time as conditions
   warrant.
