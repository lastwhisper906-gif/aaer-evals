# ADTN MD&A — 0001193125-12-220696


## mdna

[0001193125-12-220696:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION
AND RESULTS OF OPERATIONS

[0001193125-12-220696:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and the
related notes that appear elsewhere in this document.

[0001193125-12-220696:mdna:3]
[same as prior period, unchanged from 0000950123-11-094914:mdna:3]

[0001193125-12-220696:mdna:4]
ADTRAN, Inc. designs, manufactures and markets solutions and provides services and support for communications networks. Our solutions are widely deployed by providers of communications services (serviced
by our Carrier Networks Division), and small and mid-sized enterprises (SMEs) (serviced by our Enterprise Networks Division), and enable voice, data, video and Internet communications across wireline and wireless networks. Many of these solutions
are currently in use by every major United States and many global service providers, as well as by many public, private and governmental organizations worldwide.

[0001193125-12-220696:mdna:5]
Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased
functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price
based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek in most instances to be a high-quality, low-cost provider of products in our markets. Our success to date is
attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy
enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001193125-12-220696:mdna:6]
Our three major product categories are Carrier Systems, Business Networking and Loop Access. Carrier Systems products are used by communications service providers to provide data, voice and video services
to consumers and enterprises. Business Networking products provide access to telecommunication services, facilitating the delivery of converged services and Unified Communications to the SME market. Loop Access products are used by carrier and
enterprise customers for access to copper-based telecommunications networks.

[0001193125-12-220696:mdna:7]
In addition, we identify subcategories of product revenues,
which we divide into our core products and legacy products. Our core products consist of Broadband Access and Optical products (included in Carrier Systems) and Internetworking products (included in Business Networking) and our legacy products
include HDSL products (included in Loop Access) and other products not included in the aforementioned core products. Many of our customers are migrating their networks to deliver higher bandwidth services by utilizing newer technologies. We believe
that products and services offered in our core product areas position us well for this migration. Despite occasional increases, we anticipate that revenues of many of our legacy products, including HDSL, will decline over time; however, revenues
from these products may continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-12-220696:mdna:8]
See Note 10 of
Notes to Consolidated Financial Statements in this report for further information regarding these product categories.

[0001193125-12-220696:mdna:9]
Sales were $134.7
million for the three months ended March 31, 2012 compared to $165.5 million for the three months ended March 31, 2011. Product revenues for our core areas, Broadband Access, Optical and Internetworking, were $104.7 million for the three
months ended March 31, 2012 compared to $105.6 million for the three months ended March 31, 2011. Our gross margin decreased to 55.0% for the three months ended March 31, 2012 from 59.7% for the three months ended March 31, 2011.
Our operating income margin decreased to 12.0% for the three months ended March 31, 2012 from 27.6% for the three months ended March 31, 2011. Net income was $13.0 million for the three months ended March 31, 2012 compared to $34.3
million for the three months ended March 31, 2011. Our effective tax rate increased to 35.4% for the three months ended March 31, 2012 from 30.7% for the three months ended March 31, 2011. Earnings per share, assuming dilution, were
$0.20 for the three months ended March 31, 2012 compared to $0.52 for the three months ended March 31, 2011.

[0001193125-12-220696:mdna:10]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future
periods due to a number of factors, including customer order activity and backlog. Backlog levels vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Many of our customers require
prompt delivery of products. This requires us to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our
financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001193125-12-220696:mdna:11]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions,
increased competition, customer order patterns, changes in product mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs and announcements of new products by us or our competitors.
Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on
our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating
results in a given quarter.

[0001193125-12-220696:mdna:12]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results,
and, in general, management expects that our financial results may vary from period to period. A list of factors that could materially affect our business, financial condition or operating results is included under “Factors That Could Affect
Our Future Results” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this report. These factors have also been discussed in more detail in
Item 1A of Part I in our most recent Annual Report on Form 10-K for the year ended December 31, 2011, filed on February 29, 2012 with the SEC.

[0001193125-12-220696:mdna:13]
[same as prior period, unchanged from 0000950123-11-094914:mdna:13]

[0001193125-12-220696:mdna:14]
Our critical accounting policies and estimates
have not changed significantly from those detailed in our most recent Annual Report on Form 10-K for the year ended December 31, 2011, filed on February 29, 2012 with the SEC.

[0001193125-12-220696:mdna:15]
[same as prior period, unchanged from 0000950123-11-094914:mdna:15]

[0001193125-12-220696:mdna:16]
See Note 1 of Notes to Consolidated Financial
Statements in Item 1 of this Form 10-Q for a full description of recent accounting pronouncements, including the expected dates of adoption and estimated effects on results of operations and financial condition, which is incorporated herein by
reference.

[0001193125-12-220696:mdna:17]
ACQUISITION EXPENSES

[0001193125-12-220696:mdna:18]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on December 12, 2011, we announced the planned acquisition of the Nokia Siemens Networks Broadband Access business (NSN
BBA). Acquisition related expenses, amortizations and adjustments for the three months ended March 31, 2012 for both transactions are as follows:

[0001193125-12-220696:mdna:19]
|  |  | ThreeMonths EndedMarch 31, 2012 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 218 |  |
| Amortization and adjustments of other acquisition related non-cash items |  |  | 266 |  |
| Subtotal |  | $ | 484 |  |
| Planned NSN BBA acquisition |  |  |  |  |
| Acquisition related professional fees, travel and other expenses |  |  | 1,580 |  |
| Total acquisition related expenses, amortizations and adjustments |  | $ | 2,064 |  |
| Tax effect |  |  | (803 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,261 |  |

[0001193125-12-220696:mdna:20]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated
Statements of Income categories for the three months ended March 31, 2012:

[0001193125-12-220696:mdna:21]
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 146 |  |
| Cost of goods sold |  |  | 137 |  |
| Subtotal |  | $ | 283 |  |
| Selling, general and administrative expenses |  |  | 1,561 |  |
| Research and development expenses |  |  | 220 |  |
| Subtotal |  | $ | 1,781 |  |
| Total acquisition related expenses, amortizations and adjustments |  | $ | 2,064 |  |
| Tax effect |  |  | (803 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,261 |  |

[0001193125-12-220696:mdna:22]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2012 COMPARED TO THREE MONTHS ENDED MARCH 31, 2011

[0001193125-12-220696:mdna:23]
[same as prior period, unchanged from 0000950123-11-094914:mdna:18]

[0001193125-12-220696:mdna:24]
ADTRAN’s sales decreased 18.6% from $165.5 million in the three months ended March 31, 2011 to $134.7 million in the three months ended
March 31, 2012. The decrease in sales is primarily attributable to a $29.9 million decrease in sales of our HDSL and other legacy products, a $6.7 million decrease in sales of our Optical products, and a $2.3 million decrease in sales of our
Broadband Access products, partially offset by an $8.1 million increase in sales of our Internetworking products.

[0001193125-12-220696:mdna:25]
Carrier Networks sales decreased 27.0% from $132.4 million in the three months ended March 31, 2011 to
$96.7 million in the three months ended March 31, 2012. The decrease is primarily attributable to decreases in sales of our Broadband Access products, Optical products, and HDSL and other legacy products, partially offset by an increase in
sales of our Internetworking NTE products. The decrease in Carrier Networks sales is primarily attributable to a slower-than-normal start to the seasonal buying pattern at our larger carrier customers and a delay in both the start and ramp-up of
orders from one of these customers due to a new systems implementation.

[0001193125-12-220696:mdna:26]
Enterprise Networks sales increased 14.8% from $33.2 million in the
three months ended March 31, 2011 to $38.1 million in the three months ended March 31, 2012. The increase is primarily attributable to an increase in sales of our Internetworking products, partially offset by a decrease in sales of our
legacy products. Internetworking product sales attributable to Enterprise Networks were 91.2% of the division’s sales in the three months ended March 31, 2012, compared to 85.0% in the three months ended March 31, 2011. Legacy
products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales increased from 20.0% for the three months ended March 31, 2011 to 28.3% for the three months ended March 31,
2012.

[0001193125-12-220696:mdna:27]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, increased 47.4% from
$12.4 million in the three months ended March 31, 2011 to $18.3 million in the three months ended March 31, 2012. International sales, as a percentage of total sales, increased from 7.5% for the three months ended March 31, 2011 to
13.6% for the three months ended March 31, 2012. International sales increased in the three months ended March 31, 2012 compared to the three months ended March 31, 2011 primarily due to an increase in sales in Latin America and the
Asia-Pacific region.

[0001193125-12-220696:mdna:28]
Carrier System product sales decreased $15.5 million in the three months ended March 31, 2012 compared to the three
months ended March 31, 2011 primarily due to a $6.7 million decrease in Optical product sales, a $6.5 million decrease in legacy product sales, and a $2.3 million decrease in Broadband Access product sales. The decrease in Carrier System
product sales is primarily attributable to a slower-than-normal start to the seasonal buying pattern at our larger carrier customers and a delay in both the start and ramp-up of orders from one of these customers due to a new systems implementation.

[0001193125-12-220696:mdna:29]
Business Networking product sales increased $6.8 million in the three months ended March 31, 2012 compared to the three months ended
March 31, 2011, primarily due to a $8.1 million increase in Internetworking product sales across both divisions, partially offset by a $1.3 million decrease in legacy product sales. The decrease in sales of legacy products is a result of
customers shifting to newer technologies. Many of these newer technologies are integral to our Internetworking product area.

[0001193125-12-220696:mdna:30]
Loop Access
product sales decreased $22.1 million in the three months ended March 31, 2012 compared to the three months ended March 31, 2011 primarily due to a $22.0 million decrease in HDSL product sales.

[0001193125-12-220696:mdna:31]
[same as prior period, unchanged from 0000950123-11-094914:mdna:26]

[0001193125-12-220696:mdna:32]
As a percentage of
sales, cost of sales increased from 40.3% in the three months ended March 31, 2011 to 45.0% in the three months ended March 31, 2012. The increase in cost of sales as a percentage of sales is primarily attributable to lower cost absorption
due to the lower production volumes and higher cost product mix.

[0001193125-12-220696:mdna:33]
Carrier Networks cost of sales, as a percent of division sales, increased
from 39.9% in the three months ended March 31, 2011 to 45.3% in the three months ended March 31, 2012. The increase in Carrier Networks cost of sales as a percentage of sales is primarily attributable to lower cost absorption due to lower
production volumes.

[0001193125-12-220696:mdna:34]
Enterprise Networks cost of sales, as a percent of division sales, increased from 41.8% in the three months ended
March 31, 2011 to 44.3% in the three months ended March 31, 2012. The increase in Enterprise Networks cost of sales as a percentage of sales is primarily attributable to the impact of changes in the cost elements discussed above.

[0001193125-12-220696:mdna:35]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s
price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-12-220696:mdna:36]
[same as prior period, unchanged from 0000950123-11-094914:mdna:31]

[0001193125-12-220696:mdna:37]
Selling, general and administrative expenses increased 12.0% from $29.6 million in the three months ended March 31, 2011 to $33.1 million in the
three months ended March 31, 2012. The increase in selling, general and administrative expenses is primarily related to increases in staffing and fringe benefit costs due to increased headcount, including expenses and increased headcount
related to Bluesocket, Inc., which was acquired on August 4, 2011, professional services, legal services, and travel expenses. The increases in professional services, legal services and travel expenses were primarily attributable to the planned
acquisition of Nokia Siemens Networks Broadband Access business.

[0001193125-12-220696:mdna:38]
Selling, general and administrative expenses as a percentage of sales
increased from 17.9% in the three months ended March 31, 2011 to 24.6% in the three months ended March 31, 2012. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant
fluctuation in revenues for the periods being compared.

[0001193125-12-220696:mdna:39]
[same as prior period, unchanged from 0000950123-11-094914:mdna:34]

[0001193125-12-220696:mdna:40]
Research and development expenses increased 4.9% from $23.6 million in the three months ended March 31, 2011 to $24.8 million in the three months
ended March 31, 2012. The increase in research and development expenses is primarily related to increases in staffing and fringe benefit costs due to increased headcount, including expenses and increased headcount related to Bluesocket Inc.,
which was acquired on August 4, 2011, and amortization of intangibles related to the Bluesocket acquisition.

[0001193125-12-220696:mdna:41]
Research and development
expenses as a percentage of sales increased from 14.3% in the three months ended March 31, 2011 to 18.4% in the three months ended March 31, 2012. Research and development expenses as a percentage of sales will fluctuate whenever there are
incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-12-220696:mdna:42]
We expect to continue to
incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts
which provide for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-12-220696:mdna:43]
[same as prior period, unchanged from 0000950123-11-094914:mdna:38]

[0001193125-12-220696:mdna:44]
Interest and dividend income increased 4.0% from $1.8 million in the three months ended March 31, 2011 to $1.9 million in the three months ended
March 31, 2012. This increase is primarily related to a 22.1% increase in our average investment balance, partially offset by an 11.1% reduction in the average rate of return on these investments as a result of lower interest rates.

[0001193125-12-220696:mdna:45]
[same as prior period, unchanged from 0000950123-11-094914:mdna:40]

[0001193125-12-220696:mdna:46]
Interest
expense, which is primarily related to our taxable revenue bond, remained constant at $0.6 million in each of the three months ended March 31, 2012 and 2011. See “Liquidity and Capital Resources” below for additional information on
our revenue bond.

[0001193125-12-220696:mdna:47]
[same as prior period, unchanged from 0000950123-11-094914:mdna:42]

[0001193125-12-220696:mdna:48]
Net realized investment gain decreased from $2.8 million in the three months ended March 31, 2011 to $2.5 million in the three months ended March 31, 2012. The higher amount of realized gains in
the period ended March 31, 2011 is primarily driven by the sale of previously impaired assets in the deferred compensation plans. See “Investing Activities” in “Liquidity and Capital Resources” below for additional
information.

[0001193125-12-220696:mdna:49]
OTHER INCOME (EXPENSE), NET

[0001193125-12-220696:mdna:50]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, scrap raw material sales, and gains and
losses on the disposal of property, plant and equipment occurring in the normal course of business, changed from $0.1 million of expense in the three months ended March 31, 2011 to $0.1 million of income in the three months ended March 31,
2012.

[0001193125-12-220696:mdna:51]
[same as prior period, unchanged from 0000950123-11-094914:mdna:46]

[0001193125-12-220696:mdna:52]
Our effective tax rate increased from 30.7% in the three months ended March 31, 2011 to 35.4% in the three months ended March 31, 2012. The tax provision rate in the first quarter of 2012 did
not include the benefit of the research tax credit, which expired on December 31, 2011. The exclusion of this benefit in the first quarter of 2012 resulted in a 2.2 percentage point increase in our effective tax rate. Also, decreased
benefits from a lower volume of stock option exercises in the first quarter of 2012 resulted in a 3.1 percentage point increase in our effective tax rate.

[0001193125-12-220696:mdna:53]
[same as prior period, unchanged from 0000950123-11-094914:mdna:49]

[0001193125-12-220696:mdna:54]
As a result of the above factors, net income decreased $21.3 million
from $34.3 million in the three months ended March 31, 2011 to $13.0 million in the three months ended March 31, 2012.

[0001193125-12-220696:mdna:55]
As a
percentage of sales, net income decreased from 20.7% in the three months ended March 31, 2011 to 9.6% in the three months ended March 31, 2012.

[0001193125-12-220696:mdna:56]
[same as prior period, unchanged from 0000950123-11-094914:mdna:52]

[0001193125-12-220696:mdna:57]
[same as prior period, unchanged from 0000950123-11-094914:mdna:53]

[0001193125-12-220696:mdna:58]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for
working capital, purchases of treasury stock, dividend payments, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and
marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for the foreseeable future.

[0001193125-12-220696:mdna:59]
At March 31, 2012, cash on hand was $36.5 million and short-term investments were $161.5 million, which resulted in available short-term liquidity
of $198.1 million. At December 31, 2011, our cash on hand of $43.0 million and short-term investments of $159.3 million resulted in available short-term liquidity of $202.3 million. The decrease in short-term liquidity from December 31,
2011 to March 31, 2012 primarily reflects an increase in the purchase of long-term investments, equipment acquisitions and dividends, offset by funds provided by our operating activities and proceeds from stock option exercises.

[0001193125-12-220696:mdna:60]
[same as prior period, unchanged from 0000950123-11-094914:mdna:56]

[0001193125-12-220696:mdna:61]
Our working
capital, which consists of current assets less current liabilities, decreased 2.3% from $329.3 million as of December 31, 2011 to $321.7 million as of March 31, 2012. The quick ratio, defined as cash, cash equivalents, short-term
investments, and net accounts receivable, divided by current liabilities, decreased from 4.50 as of December 31, 2011 to 3.82 as of March 31, 2012. The current ratio, defined as current assets divided by current liabilities, decreased from
6.32 as of December 31, 2011 to 5.50 as of March 31, 2012. Our working capital, quick ratio, and current ratio decreased due to a $7.0 million increase in income tax payable, a $1.8 million increase in accounts payable, and a $1.4 million
increase in unearned revenue. Generally, the change in accounts payable is due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases. Generally, fluctuations in unearned
revenue result from variations in the timing of customer payments received in advance of revenue recognition and our revenue recognition under contract terms for hardware acceptance, installation services and post-sale support and maintenance
services.

[0001193125-12-220696:mdna:62]
Net accounts receivable decreased 1.8% from $76.1 million at December 31, 2011 to $74.8 million at March 31, 2012. Our
allowance for doubtful accounts was $8 thousand at December 31, 2011 and $42 thousand at March 31, 2012. Quarterly accounts receivable days sales outstanding (DSO) increased from 40 days as of December 31, 2011 to 51 days as of
March 31, 2012. DSO increased for the quarter ended March 31, 2012 due to the timing of sales and collections during the quarter. Other receivables decreased from $9.7 million at December 31, 2011 to $8.0 million at March 31,
2012. Generally, the change in other receivables is due to the timing of shipments and payments received for raw materials supplied to our contract manufacturers.

[0001193125-12-220696:mdna:63]
Quarterly inventory turnover decreased from 3.5 turns as of December 31, 2011 to 2.6 turns as of March 31, 2012. Inventory increased 9.1% from December 31, 2011 to March 31, 2012.
Inventory increased during the first quarter of 2012 due to a delay in both the start and ramp-up of orders from a large carrier customer due to a new systems implementation. We expect inventory levels to fluctuate as we attempt to maintain
sufficient inventory in response to seasonal cycles of our business; ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-12-220696:mdna:64]
Accounts payable increased 6.2% from $29.4 million at December 31, 2011 to $31.2 million at
March 31, 2012. Generally, the change in accounts payable is due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-12-220696:mdna:65]
[same as prior period, unchanged from 0000950123-11-094914:mdna:61]

[0001193125-12-220696:mdna:66]
Capital
expenditures totaled approximately $4.1 million and $3.0 million for the three months ended March 31, 2012 and 2011, respectively. These expenditures were primarily used to purchase manufacturing and test equipment and computer software and
hardware.

[0001193125-12-220696:mdna:67]
Our combined short-term and long-term investments increased $37.7 million from $491.4 million at December 31, 2011 to $529.0
million at March 31, 2012. This increase reflects the impact of additional funds available for investment provided by our operating activities and stock option exercises by our employees, reduced by our cash needs for equipment acquisitions and
dividends, as well as net realized and unrealized losses and amortization of net premiums on our combined investments.

[0001193125-12-220696:mdna:68]
We invest all
available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At March 31, 2012 these investments included municipal variable rate demand notes of $47.9 million, municipal
fixed-rate bonds of $193.3 million and corporate bonds of $183.4 million. At December 31, 2011, these investments included municipal variable rate demand notes of $69.7 million, municipal fixed-rate bonds of $174.8 million and corporate bonds
of $156.8 million. As of March 31, 2012, our corporate bonds, municipal fixed-rate bonds, and municipal variable rate demand notes were classified as available-for-sale and had a combined duration of 1.0 years with an average credit rating of
AA-. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a
daily basis.

[0001193125-12-220696:mdna:69]
Our long-term investments increased 10.7% from $332.0 million at December 31, 2011 to $367.5 million at March 31,
2012. The primary reason for the increase in our long-term investments during the first quarter of 2012 was cash generated from operations. Long-term investments at March 31, 2012 and December 31, 2011 included an investment in a
certificate of deposit of $48.3 million, which serves as collateral for our revenue bonds, as discussed below. We have various equity investments included in long-term investments at a cost of $15.8 million and $12.8 million, and with a fair value
of $42.1 million and $31.3 million, at March 31, 2012 and December 31, 2011, respectively.

[0001193125-12-220696:mdna:70]
Long-term investments at March 31,
2012 also include $11.2 million related to our deferred compensation plans; $2.1 million of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment
manufacturer; and $0.7 million of a fixed income bond fund.

[0001193125-12-220696:mdna:71]
We review our investment portfolio for potential “other-than-temporary”
declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the
carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices,
credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined
from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our
review, we recorded an other-than-temporary impairment charge of $33 thousand during the three months ended March 31, 2012 related to seven marketable equity securities. For the three months ended March 31, 2011, we recorded an
other-than-temporary impairment charge of $4 thousand related to one marketable equity security.

[0001193125-12-220696:mdna:72]
[same as prior period, unchanged from 0000950123-11-094914:mdna:72]

[0001193125-12-220696:mdna:73]
[same as prior period, unchanged from 0000950123-11-094914:mdna:73]

[0001193125-12-220696:mdna:74]
In July 2003, our Board of Directors elected to begin declaring quarterly
dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the three months ended March 31, 2012, we paid dividends totaling $5.7 million.

[0001193125-12-220696:mdna:75]
[same as prior period, unchanged from 0000950123-11-094914:mdna:75]

[0001193125-12-220696:mdna:76]
We have amounts outstanding
under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $47.0 million at March 31, 2012 and December 31, 2011. At March 31, 2012, the estimated fair value of
the Bond was approximately $48.3 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of A+. Included in long-term investments are restricted funds in the amount
of $48.3 million at March 31, 2012 and December 31, 2011, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the
balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 5% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that
reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program.

[0001193125-12-220696:mdna:77]
We are required to make payments in the amounts necessary to pay the principal and interest on the amounts currently outstanding. Based on positive
cash flow from operating activities, we have decided to continue early partial redemptions of the Bond. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $0.5
million of the Bond debt has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at March 31, 2012.

[0001193125-12-220696:mdna:78]
[same as prior period, unchanged from 0000950123-11-094914:mdna:78]

[0001193125-12-220696:mdna:79]
Since 1997, our Board of Directors has approved multiple share
repurchase programs that have authorized open market repurchase transactions of up to 35 million shares of our common stock. During the three months ended March 31, 2012, we did not repurchase any shares of our common stock. We have the
authority to purchase an additional 5.9 million shares of our common stock under plans approved by the Board of Directors on April 14, 2008 and October 11, 2011.

[0001193125-12-220696:mdna:80]
Stock Option Exercises

[0001193125-12-220696:mdna:81]
To accommodate employee stock option exercises, we issued
0.2 million shares of treasury stock for $3.6 million during the three months ended March 31, 2012. During the three months ended March 31, 2011, we issued 1.7 million shares of treasury stock for $31.8 million.

[0001193125-12-220696:mdna:82]
[same as prior period, unchanged from 0000950123-11-094914:mdna:82]

[0001193125-12-220696:mdna:83]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to
materially affect liquidity or the availability of or requirements for capital resources. During the three months ended March 31, 2012, there have been no material changes in contractual obligations and commercial commitments from those
discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2011 filed on February 29, 2012 with the SEC.

[0001193125-12-220696:mdna:84]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31,
2012, of which $7.7 million has been applied to these commitments.

[0001193125-12-220696:mdna:85]
[same as prior period, unchanged from 0000950123-11-094914:mdna:85]

[0001193125-12-220696:mdna:86]
The following are some of the risks that could affect our financial performance or could cause actual results to differ materially from those expressed or
implied in our forward-looking statements:

[0001193125-12-220696:mdna:87]
|  | • |  | Our operating results may fluctuate in future periods, which may adversely affect our stock price. |

[0001193125-12-220696:mdna:88]
|  | • |  | Our revenue for a particular period can be difficult to predict, and a shortfall in revenue may harm our operating results. |

[0001193125-12-220696:mdna:89]
|  | • |  | The failure to complete the integration of the Nokia Siemens Networks fixed line Broadband Access business as soon as we expect or the failure to realize benefits from this acquisition as significant as we expect may affect our future results of operations and financial condition, and could affect our stock price. |

[0001193125-12-220696:mdna:90]
|  | • |  | General economic conditions may reduce our revenues and harm our operating results. |

[0001193125-12-220696:mdna:91]
|  | • |  | Our exposure to the credit risks of our customers and distributors may make it difficult to collect accounts receivable and could adversely affect our operating results and financial condition. |

[0001193125-12-220696:mdna:92]
|  | • |  | We expect gross margin to vary over time, and our level of product gross margin may not be sustainable. |

[0001193125-12-220696:mdna:93]
|  | • |  | We must continue to update and improve our products and develop new products in order to compete and to keep pace with improvements in telecommunications technology. |

[0001193125-12-220696:mdna:94]
|  | • |  | Our products may not continue to comply with the regulations governing their sale, which may harm our business. |

[0001193125-12-220696:mdna:95]
|  | • |  | Our failure or the failure of our contract manufacturers to comply with applicable environmental regulations could adversely impact our results of operations. |

[0001193125-12-220696:mdna:96]
|  | • |  | If our products do not interoperate with our customers’ networks, installations may be delayed or cancelled, which could harm our business. |

[0001193125-12-220696:mdna:97]
|  | • |  | The lengthy approval process required by major and other service providers for new products could result in fluctuations in our revenue. |

[0001193125-12-220696:mdna:98]
|  | • |  | We engage in research and development activities to improve the application of developed technologies, and as a consequence may miss certain market opportunities enjoyed by larger companies with substantially greater research and development efforts who may focus on more leading edge development. |

[0001193125-12-220696:mdna:99]
|  | • |  | We depend heavily on sales to certain customers; the loss of any of these customers would significantly reduce our revenues and net income. |

[0001193125-12-220696:mdna:100]
|  | • |  | Our strategy of outsourcing a portion of our manufacturing requirements to subcontractors located in Asia or other international regions may result in us not meeting our cost, quality or performance standards. |

[0001193125-12-220696:mdna:101]
|  | • |  | Our dependence on a limited number of suppliers may prevent us from delivering our products on a timely basis, which could have a material adverse effect on customer relations and operating results. |

[0001193125-12-220696:mdna:102]
|  | • |  | We compete in markets that have become increasingly competitive, which may result in reduced gross profit margins and market share. |

[0001193125-12-220696:mdna:103]
|  | • |  | Our estimates regarding future warranty obligations may change due to product failure rates, shipment volumes, field service obligations and other rework costs incurred in correcting product failures. If our estimates change, the liability for warranty obligations may be increased or decreased, impacting future cost of goods sold. |

[0001193125-12-220696:mdna:104]
|  | • |  | Managing our inventory is complex and may include write-downs of excess or obsolete inventory. |

[0001193125-12-220696:mdna:105]
|  | • |  | The anticipated growth of our international operations could expose us to additional risks, increase our costs and adversely affect our operating results and financial condition. |

[0001193125-12-220696:mdna:106]
|  | • |  | We may be adversely affected by fluctuations in currency exchange rates. |

[0001193125-12-220696:mdna:107]
|  | • |  | Our success depends on our ability to reduce the selling prices of succeeding generations of our products. |

[0001193125-12-220696:mdna:108]
|  | • |  | Our failure to maintain rights to intellectual property used in our business could adversely affect the development, functionality, and commercial value of our products. |

[0001193125-12-220696:mdna:109]
|  | • |  | Software under license from third parties for use in certain of our products may not continue to be available to us on commercially reasonable terms. |

[0001193125-12-220696:mdna:110]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-12-220696:mdna:111]
|  | • |  | Consolidation and deterioration in the competitive service provider market could result in a significant decrease in our revenue. |

[0001193125-12-220696:mdna:112]
|  | • |  | We depend on distributors who maintain inventories of our products. If the distributors reduce their inventories of these products, our sales could be adversely affected. |

[0001193125-12-220696:mdna:113]
|  | • |  | If we are unable to successfully develop relationships with system integrators, service providers, and enterprise value added resellers, our sales may be negatively affected. |

[0001193125-12-220696:mdna:114]
|  | • |  | If we fail to manage our exposure to worldwide financial and securities markets successfully, our operating results and financial statements could be materially impacted. |

[0001193125-12-220696:mdna:115]
|  | • |  | Changes in our effective tax rate or assessments arising from tax audits may have an adverse impact on our results. |

[0001193125-12-220696:mdna:116]
|  | • |  | We are required to periodically evaluate the value of our long-lived assets, including the value of intangibles acquired and goodwill resulting from business acquisitions. Any future impairment charges required may adversely affect our operating results. |

[0001193125-12-220696:mdna:117]
29

[0001193125-12-220696:mdna:118]
|  | • |  | Our success depends on attracting and retaining key personnel. |

[0001193125-12-220696:mdna:119]
|  | • |  | Regulatory and potential physical impacts of climate change and other natural events may affect our customers and our production operations, resulting in adverse effects on our operating results. |

[0001193125-12-220696:mdna:120]
|  | • |  | While we believe our internal control over financial reporting is adequate, a failure to maintain effective internal control over financial reporting as our business expands could result in a loss of investor confidence in our financial reports and have an adverse effect on our stock price. |

[0001193125-12-220696:mdna:121]
|  | • |  | The price of our common stock has been volatile and may continue to fluctuate significantly. |

[0001193125-12-220696:mdna:122]
The foregoing list of risks is not exclusive. For a more detailed description of the risk factors associated with our business, see Item 1A of our
Annual Report on Form 10-K for the year ended December 31, 2011, filed on February 
29, 2012 with the SEC.
