# ADTN note change history — 0001193125-13-207088 → 0001193125-13-312256


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-07-31):
[0001193125-13-312256:note_history:1]
| 15. | COMMITMENTS AND CONTINGENCIES |
  (was, 2013-05-08, similarity 0.9118):
[0001193125-13-207088:note_history:1]
15. COMMITMENTS AND
CONTINGENCIES

- changed (2013-07-31):
[0001193125-13-312256:note_history:2]
We have committed to invest
up to an aggregate of $7.9 million in two private equity funds, and
we have contributed $8.4 million as of June 30, 2013, of which
$7.7 million has been applied to these commitments.
  (was, 2013-05-08, similarity 0.9773):
[0001193125-13-207088:note_history:2]
We have committed to invest
up to an aggregate of $7.9 million in two private equity funds, and
we have contributed $8.4 million as of March 31, 2013, of
which $7.7 million has been applied to these
commitments.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-07-31):
[0001193125-13-312256:note_history:3]
| 1. | SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES |
  (was, 2013-05-08, similarity 0.9362):
[0001193125-13-207088:note_history:3]
1. SUMMARY OF
SIGNIFICANT ACCOUNTING POLICIES

- changed (2013-07-31):
[0001193125-13-312256:note_history:4]
The
preparation of financial statements in conformity with accounting
principles generally accepted in the United States of America
requires management to make estimates and assumptions that affect
the reported amounts of assets and liabilities, the disclosure of
contingent assets and liabilities at the date of the financial
statements, and the reported amounts of revenue and expense during
the reporting period. Our more significant estimates include the
allowance for doubtful accounts, obsolete and excess inventory
reserves, warranty reserves, customer rebates, allowance for sales
returns, determination of the deferred revenue components of
multiple element sales agreements, estimated costs to complete
obligations associated with deferred revenues, estimated income tax
contingencies, the fair value of stock-based compensation,
impairment of goodwill, valuation and estimated lives of intangible
assets, estimated working capital adjustments under negotiation
related to the Nokia Siemens Networks Broadband Access business
acquisition, and the evaluation of other-than-temporary declines in
the value of investments. Actual amounts could differ significantly
from these estimates.
  (was, 2013-05-08, similarity 0.9975):
[0001193125-13-207088:note_history:4]
The preparation of
financial statements in conformity with accounting principles
generally accepted in the United States of America requires
management to make estimates and assumptions that affect the
reported amounts of assets and liabilities, the disclosure of
contingent assets and liabilities at the date of the financial
statements, and the reported amounts of revenue and expense during
the reporting period. Our more significant estimates include the
allowance for doubtful accounts, obsolete and excess inventory
reserves, warranty reserves, customer rebates, allowance for sales
returns, determination of the deferred revenue components of
multiple element sales agreements, estimated costs to complete
obligations associated with deferred revenues, estimated income tax
contingencies, the fair value of stock-based compensation,
impairment of goodwill, value and estimated lives of intangible
assets, estimated working capital adjustments under negotiation
related to the Nokia Siemens Networks Broadband Access business
acquisition, and the evaluation of other-than-temporary declines in
the value of investments. Actual amounts could differ significantly
from these estimates.

- changed (2013-07-31):
[0001193125-13-312256:note_history:5]
During the
six months ended June 30, 2013, we adopted the following
accounting standard, which had no material effect on our
consolidated results of operations or financial
condition:
  (was, 2013-05-08, similarity 0.9524):
[0001193125-13-207088:note_history:5]
During the three months
ended March 31, 2013, we adopted the following accounting
standard, which had no material effect on our consolidated results
of operations or financial condition:

- changed (2013-07-31):
[0001193125-13-312256:note_history:6]
In February
2013, the FASB issued Accounting Standards Update No. 2013-02,
Reporting of Amounts Reclassified Out of Accumulated Other
Comprehensive Income (ASU 2013-02). ASU 2013-02 requires entities
to provide information about the amounts reclassified out of
accumulated other comprehensive income by component either on the
face of the financial statements or in the footnotes. ASU 2013-02
does not change the current requirements for reporting net income
or other comprehensive income in the financial statements. This
update is effective prospectively for reporting periods beginning
after December 15, 2012. We adopted this amendment during the
first quarter of 2013, and we have provided the disclosures
required for the periods ended June 30, 2013 and 2012 in Note
10 of Notes to Consolidated Financial Statements.
  (was, 2013-05-08, similarity 0.9782):
[0001193125-13-207088:note_history:6]
In February 2013, the FASB
issued Accounting Standards Update No. 2013-02, Reporting of
Amounts Reclassified Out of Accumulated Other Comprehensive Income
(ASU 2013-02). ASU 2013-02 requires entities to provide information
about the amounts reclassified out of accumulated other
comprehensive income by component either on the face of the
financial statements or in the footnotes. ASU 2013-02 does not
change the current requirements for reporting net income or other
comprehensive income in the financial statements. This update is
effective prospectively for reporting periods beginning after
December 15, 2012. We adopted this amendment during the first
quarter of 2013, and we have provided the disclosures required for
the period ended March 31, 2013 in Note 10 of Notes to
Consolidated Financial Statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-07-31):
[0001193125-13-312256:note_history:7]
| 6. | INVESTMENTS |
  (was, 2013-05-08, similarity 0.8125):
[0001193125-13-207088:note_history:7]
6.
INVESTMENTS

- changed (2013-07-31):
[0001193125-13-312256:note_history:8]
At
June 30, 2013, we held the following securities and
investments, recorded at either fair value or cost.
  (was, 2013-05-08, similarity 0.9552):
[0001193125-13-207088:note_history:8]
At March 31, 2013, we
held the following securities and investments, recorded at either
fair value or cost.

- changed (2013-07-31):
[0001193125-13-312256:note_history:9]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,819 |  |  | $ | 1,983 |  |  | $ | (10 | ) |  | $ | 12,792 |  |
| Corporate bonds |  |  | 187,723 |  |  |  | 446 |  |  |  | (239 | ) |  |  | 187,930 |  |
| Municipal fixed-rate bonds |  |  | 155,451 |  |  |  | 319 |  |  |  | (289 | ) |  |  | 155,481 |  |
| Municipal variable rate demand notes |  |  | 7,120 |  |  |  | — |  |  |  | — |  |  |  | 7,120 |  |
| Marketable equity securities |  |  | 22,656 |  |  |  | 9,620 |  |  |  | (426 | ) |  |  | 31,850 |  |
| Available-for-sale securities held at fair value |  | $ | 383,769 |  |  | $ | 12,368 |  |  | $ | (964 | ) |  | $ | 395,173 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,818 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 445,241 |  |
  (was, 2013-05-08, similarity 0.9395):
[0001193125-13-207088:note_history:9]
|  |  |  |  |  | Gross Unrealized |  |  |  |  |
| (In thousands) |  | Amortized Cost |  |  | Gains |  |  | Losses |  |  | Carrying Value |  |
| Deferred compensation plan assets |  | $ | 10,907 |  |  | $ | 1,448 |  |  | $ | (5 | ) |  | $ | 12,350 |  |
| Corporate bonds |  |  | 190,540 |  |  |  | 783 |  |  |  | (18 | ) |  |  | 191,305 |  |
| Municipal fixed-rate bonds |  |  | 171,282 |  |  |  | 849 |  |  |  | (10 | ) |  |  | 172,121 |  |
| Municipal variable rate demand notes |  |  | 40,780 |  |  |  | — |  |  |  | — |  |  |  | 40,780 |  |
| Marketable equity securities |  |  | 22,226 |  |  |  | 11,179 |  |  |  | (309 | ) |  |  | 33,096 |  |
| Available-for-sale securities held at fair value |  | $ | 435,735 |  |  | $ | 14,259 |  |  | $ | (342 | ) |  | $ | 449,652 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,818 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 499,720 |  |

- changed (2013-07-31):
[0001193125-13-312256:note_history:10]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,688 |  |  | $ | 846 |  |  | $ | (7 | ) |  | $ | 11,527 |  |
| Corporate bonds |  |  | 185,464 |  |  |  | 966 |  |  |  | (18 | ) |  |  | 186,412 |  |
| Municipal fixed-rate bonds |  |  | 174,530 |  |  |  | 627 |  |  |  | (73 | ) |  |  | 175,084 |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | — |  |  |  | 34,375 |  |
| Fixed income bond fund |  |  | 444 |  |  |  | 12 |  |  |  | — |  |  |  | 456 |  |
| Marketable equity securities |  |  | 20,966 |  |  |  | 14,630 |  |  |  | (392 | ) |  |  | 35,204 |  |
| Available-for-sale securities held at fair value |  | $ | 426,467 |  |  | $ | 17,081 |  |  | $ | (490 | ) |  | $ | 443,058 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,902 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 493,210 |  |
  (was, 2013-05-08, similarity 0.944):
[0001193125-13-207088:note_history:10]
|  |  |  |  |  | Gross Unrealized |  |  |  |  |
| (In thousands) |  | Amortized Cost |  |  | Gains |  |  | Losses |  |  | Carrying Value |  |
| Deferred compensation plan assets |  | $ | 10,688 |  |  | $ | 846 |  |  | $ | (7 | ) |  | $ | 11,527 |  |
| Corporate bonds |  |  | 185,464 |  |  |  | 966 |  |  |  | (18 | ) |  |  | 186,412 |  |
| Municipal fixed-rate bonds |  |  | 174,530 |  |  |  | 627 |  |  |  | (73 | ) |  |  | 175,084 |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | — |  |  |  | 34,375 |  |
| Fixed income bond fund |  |  | 444 |  |  |  | 12 |  |  |  | — |  |  |  | 456 |  |
| Marketable equity securities |  |  | 20,966 |  |  |  | 14,630 |  |  |  | (392 | ) |  |  | 35,204 |  |
| Available-for-sale securities held at fair value |  | $ | 426,467 |  |  | $ | 17,081 |  |  | $ | (490 | ) |  | $ | 443,058 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,902 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 493,210 |  |

- changed (2013-07-31):
[0001193125-13-312256:note_history:11]
As of
June 30, 2013, our corporate bonds and municipal fixed-rate
bonds had the following contractual maturities:
  (was, 2013-05-08, similarity 0.9581):
[0001193125-13-207088:note_history:11]
As of March 31, 2013,
our corporate bonds and municipal fixed-rate bonds had the
following contractual maturities:

- changed (2013-07-31):
[0001193125-13-312256:note_history:12]
At
June 30, 2013, we held a $48.3 million restricted certificate
of deposit, which is carried at cost. This investment serves as a
collateral deposit against the principal amount outstanding under
loans made to ADTRAN pursuant to an Alabama State Industrial
Development Authority revenue bond (the Bond). At June 30,
2013, the estimated fair value of the Bond was approximately $46.3
million, based on a debt security with a comparable interest rate
and maturity and a Standard and Poor’s credit rating of A-.
For more information on the Bond, see “Debt” under
“Liquidity and Capital Resources” in the
“Management’s Discussion and Analysis of Financial
Condition and Results of Operations” contained in Item 2
of Part I of this report.
  (was, 2013-05-08, similarity 0.9875):
[0001193125-13-207088:note_history:12]
At March 31, 2013, we
held a $48.3 million restricted certificate of deposit, which is
carried at cost. This investment serves as a collateral deposit
against the principal amount outstanding under loans made to ADTRAN
pursuant to an Alabama State Industrial Development Authority
revenue bond (the Bond). At March 31, 2013, the estimated fair
value of the Bond was approximately $47.9 million, based on a debt
security with a comparable interest rate and maturity and a
Standard and Poor’s credit rating of A-. For more information
on the Bond, see “Debt” under “Liquidity and
Capital Resources” in the “Management’s
Discussion and Analysis of Financial Condition and Results of
Operations” contained in Item 2 of Part I of this
report.

- changed (2013-07-31):
[0001193125-13-312256:note_history:13]
We review our
investment portfolio for potential
“other-than-temporary” declines in value on an
individual investment basis. We assess, on a quarterly basis,
significant declines in value which may be considered
other-than-temporary and, if necessary, recognize and record the
appropriate charge to write-down the carrying value of such
investments. In making this assessment, we take into consideration
qualitative and quantitative information, including but not limited
to the following: the magnitude and duration of historical declines
in market prices, credit rating activity, assessments of liquidity,
public filings, and statements made by the issuer. We generally
begin our identification of potential other-than-temporary
impairments by reviewing any security with a fair value that has
declined from its original or adjusted cost basis by 25% or more
for six or more consecutive months. We then evaluate the individual
security based on the previously identified factors to determine
the amount of the write-down, if any. As a result of our review, we
recorded an other-than-temporary impairment charge of $4 thousand
during the six months ended June 30, 2013 related to one
marketable security. For the six months ended June 30, 2012,
we recorded an other-than-temporary impairment charge of $33
thousand related to eight marketable equity securities.
  (was, 2013-05-08, similarity 0.9605):
[0001193125-13-207088:note_history:13]
We review our investment
portfolio for potential “other-than-temporary” declines
in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be
considered other-than-temporary and, if necessary, recognize and
record the appropriate charge to write-down the carrying value of
such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including
but not limited to the following: the magnitude and duration of
historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by
the issuer. We generally begin our identification of potential
other-than-temporary impairments by reviewing any security with a
fair value that has declined from its original or adjusted cost
basis by 25% or more for six or more consecutive months. We then
evaluate the individual security based on the previously identified
factors to determine the amount of the write-down, if any. As a
result of our review, we recorded an other-than-temporary
impairment charge of $4 thousand during the three months ended
March 31, 2013 related to one marketable equity security. For
the three months ended March 31, 2012, we recorded an
other-than-temporary impairment charge of $33 thousand related to
seven marketable equity securities.

- changed (2013-07-31):
[0001193125-13-312256:note_history:14]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 1,728 |  |  | $ | 2,631 |  |  | $ | 5,455 |  |  | $ | 5,300 |  |
| Gross realized losses |  | $ | (175 | ) |  | $ | (275 | ) |  | $ | (257 | ) |  | $ | (477 | ) |
  (was, 2013-05-08, similarity 0.7589):
[0001193125-13-207088:note_history:14]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 3,727 |  |  | $ | 2,669 |  |
| Gross realized losses |  | $ | (82 | ) |  | $ | (202 | ) |

- changed (2013-07-31):
[0001193125-13-312256:note_history:15]
As of
June 30, 2013 and 2012, gross unrealized losses related to
individual securities in a continuous loss position for 12 months
or longer were not significant.
  (was, 2013-05-08, similarity 0.9279):
[0001193125-13-207088:note_history:15]
As of March 31, 2013
and 2012, gross unrealized losses related to individual securities
that had been in a continuous loss position for 12 months or longer
were not significant.

- changed (2013-07-31):
[0001193125-13-312256:note_history:16]
We have
categorized our cash equivalents held in money market funds and our
investments held at fair value into a three-level fair value
hierarchy based on the priority of the inputs to the valuation
technique for the cash equivalents and investments as follows:
Level 1 – Values based on unadjusted, quoted prices in active
markets for identical assets or liabilities; Level 2 – Values
based on inputs other than quoted prices included within Level 1
that are directly or indirectly observable for the asset or
liability; Level 3 – Values based on unobservable inputs for
the asset or liability. These inputs include information supplied
by investees.
  (was, 2013-05-08, similarity 0.6196):
[0001193125-13-207088:note_history:16]
We have categorized our
cash equivalents held in money market funds and our investments
held at fair value into a three-level fair value hierarchy based on
the priority of the inputs to the valuation technique for the cash
equivalents and investments as follows: Level 1 – Values
based on unadjusted quoted prices for identical assets or
liabilities in an active market; Level 2 – Values based on
quoted prices in markets that are not active or model inputs that
are observable either directly or indirectly; Level 3 –
Values based on prices or valuation techniques that require inputs
that are both unobservable and significant to the overall fair
value measurement. These inputs include information supplied by
investees.

- changed (2013-07-31):
[0001193125-13-312256:note_history:17]
|  |  | Fair Value Measurements at June 30, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,339 |  |  | $ | 1,339 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,792 |  |  |  | 12,792 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 187,930 |  |  |  | — |  |  |  | 187,930 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 155,481 |  |  |  | — |  |  |  | 155,481 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 7,120 |  |  |  | — |  |  |  | 7,120 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 7,818 |  |  |  | 7,818 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 24,032 |  |  |  | 24,032 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 395,173 |  |  |  | 44,642 |  |  |  | 350,531 |  |  |  | — |  |
| Total |  | $ | 396,512 |  |  | $ | 45,981 |  |  | $ | 350,531 |  |  | $ | — |  |
  (was, 2013-05-08, similarity 0.6509):
[0001193125-13-207088:note_history:17]
|  |  | Fair Value Measurements at March 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 19,140 |  |  | $ | 19,140 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,350 |  |  |  | 12,350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 191,305 |  |  |  | — |  |  |  | 191,305 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 172,121 |  |  |  | — |  |  |  | 172,121 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 40,780 |  |  |  | — |  |  |  | 40,780 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 9,307 |  |  |  | 9,307 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 23,789 |  |  |  | 23,789 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 449,652 |  |  |  | 45,446 |  |  |  | 404,206 |  |  |  | — |  |
| Total |  | $ | 468,792 |  |  | $ | 64,586 |  |  | $ | 404,206 |  |  | $ | — |  |
|  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 28,071 |  |  | $ | 28,071 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,527 |  |  |  | 11,527 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 186,412 |  |  |  | — |  |  |  | 186,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 175,084 |  |  |  | — |  |  |  | 175,084 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | 34,375 |  |  |  | — |  |
| Fixed income bond fund |  |  | 456 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 21,105 |  |  |  | 21,105 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 443,058 |  |  |  | 47,187 |  |  |  | 395,871 |  |  |  | — |  |
| Total |  | $ | 471,129 |  |  | $ | 75,258 |  |  | $ | 395,871 |  |  | $ | — |  |

- added (2013-07-31):
[0001193125-13-312256:note_history:18]
|  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 28,071 |  |  | $ | 28,071 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,527 |  |  |  | 11,527 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 186,412 |  |  |  | — |  |  |  | 186,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 175,084 |  |  |  | — |  |  |  | 175,084 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | 34,375 |  |  |  | — |  |
| Fixed income bond fund |  |  | 456 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 21,105 |  |  |  | 21,105 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 443,058 |  |  |  | 47,187 |  |  |  | 395,871 |  |  |  | — |  |
| Total |  | $ | 471,129 |  |  | $ | 75,258 |  |  | $ | 395,871 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2013-07-31):
[0001193125-13-312256:note_history:19]
| 14. | RELATED PARTY TRANSACTIONS |
  (was, 2013-05-08, similarity 0.9032):
[0001193125-13-207088:note_history:19]
14. RELATED PARTY
TRANSACTIONS

- changed (2013-07-31):
[0001193125-13-312256:note_history:20]
We employ the law firm of
our director emeritus for legal services. All bills for services
rendered by this firm are reviewed and approved by our Chief
Financial Officer. We believe that the fees for such services are
comparable to those charged by other firms for services rendered to
us. For the three and six month periods ended June 30, 2013
and 2012, we incurred fees of $10 thousand per month for these
legal services.
  (was, 2013-05-08, similarity 0.9306):
[0001193125-13-207088:note_history:20]
We employ the law firm of
our director emeritus for legal services. All bills for services
rendered by this firm are reviewed and approved by our Chief
Financial Officer. We believe that the fees for such services are
comparable to those charged by other firms for services rendered to
us. For the three month periods ended March 31, 2013 and 2012,
we incurred fees of $10 thousand per month for these legal
services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2013-07-31):
[0001193125-13-312256:note_history:21]
| 16. | SUBSEQUENT EVENTS |
  (was, 2013-05-08, similarity 0.8636):
[0001193125-13-207088:note_history:21]
16. SUBSEQUENT
EVENTS

- added (2013-07-31):
[0001193125-13-312256:note_history:22]
On
July 9, 2013, we announced that our Board of Directors
declared a quarterly cash dividend of $0.09 per common share to be
paid to stockholders of record at the close of business on
July 25, 2013. The payment date will be August 8, 2013.
The quarterly dividend payment will be approximately $5.2 million.
In July 2003, our Board of Directors elected to begin declaring
quarterly dividends on our common stock considering the tax
treatment of dividends and adequate levels of Company
liquidity.

- removed (2013-07-31):
[0001193125-13-207088:note_history:23]
On April 9, 2013, we
announced that our Board of Directors declared a quarterly cash
dividend of $0.09 per common share to be paid to stockholders of
record at the close of business on April 25, 2013. The payment
date will be May 9, 2013. The quarterly dividend payment will
be approximately $5.3 million. In July 2003, our Board of Directors
elected to begin declaring quarterly dividends on our common stock
considering the tax treatment of dividends and adequate levels of
Company liquidity.

- removed (2013-07-31):
[0001193125-13-207088:note_history:24]
During the second quarter
of 2013 and as of May 8, 2013, we repurchased 2.7 million
shares of our common stock through open market purchases at an
average cost of $21.03 per share. We currently have the authority
to purchase an additional 0.3 million shares of our common
stock under the current plan approved by the Board of
Directors.

- removed (2013-07-31):
[0001193125-13-207088:note_history:25]
On May 1, 2013, we
announced that our Board of Directors authorized the repurchase of
an additional 5.0 million shares of our common stock to
commence upon completion of the repurchase plan announced on
October 11, 2011. This new authorization will be implemented
through open market or private purchases from time to time as
conditions warrant.
