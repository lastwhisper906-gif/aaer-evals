# ADTN MD&A — 0001193125-13-312256


## mdna

[0001193125-13-312256:mdna:1]
[same as prior period, unchanged from 0001193125-13-207088:mdna:1]

[0001193125-13-312256:mdna:2]
[same as prior period, unchanged from 0001193125-13-207088:mdna:2]

[0001193125-13-312256:mdna:3]
[same as prior period, unchanged from 0001193125-13-207088:mdna:3]

[0001193125-13-312256:mdna:4]
[same as prior period, unchanged from 0001193125-13-207088:mdna:4]

[0001193125-13-312256:mdna:5]
[same as prior period, unchanged from 0001193125-13-207088:mdna:5]

[0001193125-13-312256:mdna:6]
[same as prior period, unchanged from 0001193125-13-207088:mdna:6]

[0001193125-13-312256:mdna:7]
[same as prior period, unchanged from 0001193125-13-207088:mdna:7]

[0001193125-13-312256:mdna:8]
[same as prior period, unchanged from 0001193125-13-207088:mdna:8]

[0001193125-13-312256:mdna:9]
[same as prior period, unchanged from 0001193125-13-207088:mdna:9]

[0001193125-13-312256:mdna:10]
[same as prior period, unchanged from 0001193125-13-207088:mdna:10]

[0001193125-13-312256:mdna:11]
[same as prior period, unchanged from 0001193125-13-207088:mdna:11]

[0001193125-13-312256:mdna:12]
[same as prior period, unchanged from 0001193125-13-207088:mdna:12]

[0001193125-13-312256:mdna:13]
[same as prior period, unchanged from 0001193125-13-207088:mdna:13]

[0001193125-13-312256:mdna:14]
[same as prior period, unchanged from 0001193125-13-207088:mdna:14]

[0001193125-13-312256:mdna:15]
[same as prior period, unchanged from 0001193125-13-207088:mdna:15]

[0001193125-13-312256:mdna:16]
[same as prior period, unchanged from 0001193125-13-207088:mdna:16]

[0001193125-13-312256:mdna:17]
[same as prior period, unchanged from 0001193125-13-207088:mdna:17]

[0001193125-13-312256:mdna:18]
[same as prior period, unchanged from 0001193125-13-207088:mdna:18]

[0001193125-13-312256:mdna:19]
[same as prior period, unchanged from 0001193125-13-207088:mdna:19]

[0001193125-13-312256:mdna:20]
[same as prior period, unchanged from 0001193125-13-207088:mdna:20]

[0001193125-13-312256:mdna:21]
[same as prior period, unchanged from 0001193125-13-207088:mdna:21]

[0001193125-13-312256:mdna:22]
[same as prior period, unchanged from 0001193125-13-207088:mdna:22]

[0001193125-13-312256:mdna:23]
[same as prior period, unchanged from 0001193125-13-207088:mdna:23]

[0001193125-13-312256:mdna:24]
[same as prior period, unchanged from 0001193125-13-207088:mdna:24]

[0001193125-13-312256:mdna:25]
[same as prior period, unchanged from 0001193125-13-207088:mdna:25]

[0001193125-13-312256:mdna:26]
[same as prior period, unchanged from 0001193125-13-207088:mdna:26]

[0001193125-13-312256:mdna:27]
[same as prior period, unchanged from 0001193125-13-207088:mdna:27]

[0001193125-13-312256:mdna:28]
[same as prior period, unchanged from 0001193125-13-207088:mdna:28]

[0001193125-13-312256:mdna:29]
[same as prior period, unchanged from 0001193125-13-207088:mdna:29]

[0001193125-13-312256:mdna:30]
[same as prior period, unchanged from 0001193125-13-207088:mdna:30]

[0001193125-13-312256:mdna:31]
[same as prior period, unchanged from 0001193125-13-207088:mdna:31]

[0001193125-13-312256:mdna:32]
[same as prior period, unchanged from 0001193125-13-207088:mdna:32]

[0001193125-13-312256:mdna:33]
[same as prior period, unchanged from 0001193125-13-207088:mdna:33]

[0001193125-13-312256:mdna:34]
[same as prior period, unchanged from 0001193125-13-207088:mdna:34]

[0001193125-13-312256:mdna:35]
[same as prior period, unchanged from 0001193125-13-207088:mdna:35]

[0001193125-13-312256:mdna:36]
[same as prior period, unchanged from 0001193125-13-207088:mdna:36]

[0001193125-13-312256:mdna:37]
[same as prior period, unchanged from 0001193125-13-207088:mdna:37]

[0001193125-13-312256:mdna:38]
[same as prior period, unchanged from 0001193125-13-207088:mdna:38]

[0001193125-13-312256:mdna:39]
[same as prior period, unchanged from 0001193125-13-207088:mdna:39]

[0001193125-13-312256:mdna:40]
[same as prior period, unchanged from 0001193125-13-207088:mdna:40]

[0001193125-13-312256:mdna:41]
[same as prior period, unchanged from 0001193125-13-207088:mdna:41]

[0001193125-13-312256:mdna:42]
Sales were $162.2 million and $305.2 million for the three and six months ended June 30, 2013 compared to $184.0 million and $318.7 million for the
three and six months ended June 30, 2012. Product revenues for our three core areas, Broadband Access, Optical and Internetworking, were $141.5 million and $259.6 million for the three and six months ended June 30, 2013 compared to $155.0
million and $259.7 million for the three and six months ended June 30, 2012. Our gross margin decreased to 49.2% and 49.0% for the three and six months ended June 30, 2013 from 51.7% and 53.1% for the three and six months ended
June 30, 2012. Our operating income margin decreased to 8.7% and 6.8% for the three and six months ended June 30, 2013 from 14.6% and 13.5% for the three and six months ended June 30, 2012. Net income was $9.9 million and $17.7
million for the three and six months ended June 30, 2013 compared to $21.1 million and $34.0 million for the three and six months ended June 30, 2012. Our effective tax rate increased to 41.4% for the three months ended June 30, 2013
from 35.7% for the three months ended June 30, 2012 and decreased to 33.2% for the six months ended June 30, 2013 from 35.6% for the six months ended June 30, 2012. Earnings per share, assuming dilution, were $0.17 and $0.29 for the
three and six months ended June 30, 2013 compared to $0.33 and $0.53 for the three and six months ended June 30, 2012.

[0001193125-13-312256:mdna:43]
27

[0001193125-13-312256:mdna:44]
[same as prior period, unchanged from 0001193125-13-207088:mdna:44]

[0001193125-13-312256:mdna:45]
[same as prior period, unchanged from 0001193125-13-207088:mdna:45]

[0001193125-13-312256:mdna:46]
[same as prior period, unchanged from 0001193125-13-207088:mdna:46]

[0001193125-13-312256:mdna:47]
[same as prior period, unchanged from 0001193125-13-207088:mdna:47]

[0001193125-13-312256:mdna:48]
[same as prior period, unchanged from 0001193125-13-207088:mdna:48]

[0001193125-13-312256:mdna:49]
[same as prior period, unchanged from 0001193125-13-207088:mdna:49]

[0001193125-13-312256:mdna:50]
[same as prior period, unchanged from 0001193125-13-207088:mdna:50]

[0001193125-13-312256:mdna:51]
[same as prior period, unchanged from 0001193125-13-207088:mdna:51]

[0001193125-13-312256:mdna:52]
On May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and six
months ended June 30, 2013 and 2012 for that transaction is as follows:

[0001193125-13-312256:mdna:53]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Amortization of acquired intangible assets |  | $ | 288 |  |  | $ | 172 |  |  | $ | 582 |  |  | $ | 172 |  |
| Amortization of other purchase accounting adjustments |  |  | 342 |  |  |  | 1,052 |  |  |  | 752 |  |  |  | 1,052 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 82 |  |  |  | 2,705 |  |  |  | 236 |  |  |  | 4,285 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 712 |  |  |  | 3,929 |  |  |  | 1,570 |  |  |  | 5,509 |  |
| Provision for income taxes |  |  | (221 | ) |  |  | (1,224 | ) |  |  | (487 | ) |  |  | (1,739 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 491 |  |  | $ | 2,705 |  |  | $ | 1,083 |  |  | $ | 3,770 |  |

[0001193125-13-312256:mdna:54]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated
Statements of Income categories for the three and six months ended June 30, 2013 and 2012:

[0001193125-13-312256:mdna:55]
|  |  | ThreeMonths Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 216 |  |  | $ | 416 |  |  | $ | 452 |  |  | $ | 416 |  |
| Cost of goods sold |  |  | 64 |  |  |  | 650 |  |  |  | 151 |  |  |  | 667 |  |
| Subtotal |  |  | 280 |  |  |  | 1,066 |  |  |  | 603 |  |  |  | 1,083 |  |
| Selling, general and administrative expenses |  |  | 113 |  |  |  | 2,361 |  |  |  | 274 |  |  |  | 3,922 |  |
| Research and development expenses |  |  | 319 |  |  |  | 502 |  |  |  | 693 |  |  |  | 504 |  |
| Subtotal |  |  | 432 |  |  |  | 2,863 |  |  |  | 967 |  |  |  | 4,426 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 712 |  |  |  | 3,929 |  |  |  | 1,570 |  |  |  | 5,509 |  |
| Provision for income taxes |  |  | (221 | ) |  |  | (1,224 | ) |  |  | (487 | ) |  |  | (1,739 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 491 |  |  | $ | 2,705 |  |  | $ | 1,083 |  |  | $ | 3,770 |  |

[0001193125-13-312256:mdna:56]
[same as prior period, unchanged from 0001193125-13-207088:mdna:56]

[0001193125-13-312256:mdna:57]
29

[0001193125-13-312256:mdna:58]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2013 COMPARED TO THREE AND SIX MONTHS
ENDED JUNE 30, 2012

[0001193125-13-312256:mdna:59]
[same as prior period, unchanged from 0001193125-13-207088:mdna:59]

[0001193125-13-312256:mdna:60]
ADTRAN’s sales decreased 11.8% from $184.0 million in the three months ended June 30, 2012 to $162.2 million in the three months ended June 30, 2013, and decreased 4.2% from $318.7 million
in the six months ended June 30, 2012 to $305.2 million in the six months ended June 30, 2013. The decrease in sales for the three months ended June 30, 2013 is primarily attributable to a $24.4 million decrease in sales of our
Broadband Access products and an $8.3 million decrease in sales of our HDSL and other legacy products, partially offset by a $9.0 million increase in sales of our Internetworking products and a $2.0 million increase in sales of our Optical products.
The decrease in sales for the six months ended June 30, 2013 is primarily attributable to a $13.4 million decrease in sales of our HDSL and other legacy products, a $3.4 million decrease in sales of our Optical products, and a $1.7 million
decrease in sales of our Broadband Access products, partially offset by a $4.9 million increase in sales of our Internetworking products.

[0001193125-13-312256:mdna:61]
Carrier Networks sales decreased 19.2% from $152.7 million in the three months ended June 30, 2012 to $123.3 million in the three months ended
June 30, 2013, and decreased 6.5% from $249.4 million in the six months ended June 30, 2012 to $233.2 million in the six months ended June 30, 2013. The decrease in sales for the three months ended June 30, 2013 is primarily
attributable to decreases in sales of our Broadband Access products and HDSL and other legacy products, partially offset by increases in sales of our Optical products and ONT products. The decrease in sales of our Broadband Access products is
primarily attributable to fluctuations in project installation activities at a Latin American carrier. The decrease in sales of HDSL and other legacy products has been expected as customers continue to upgrade their networks to deliver higher
bandwidth services by migrating to newer technologies, including to our core products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to
decline over time, these revenues may continue for years because of the time required for our customers to transition to newer technologies. The change in sales of our Optical products is primarily attributable to a technology shift from Time
Division Multiplexed (TDM) and SONET/SDH architectures to Ethernet-based packet networks. We offer Ethernet-based solutions within our Optical products that address this technology change, and we expect sales of our Optical products will increase
over time due to this transition. The increase in sales of our Internetworking products was primarily attributable to an improved spending environment and reflected an increase in sales to both carriers and value added resellers. The decrease in
sales for the six months ended June 30, 2013 is primarily attributable to decreases in sales of our HDSL and other legacy products, Optical products, and Broadband Access products, partially offset by an increase in sales of our ONT products.
The decrease in sales for the six months ended June 30, 2013 is primarily attributable to the factors discussed above.

[0001193125-13-312256:mdna:62]
Enterprise
Networks sales increased 24.3% from $31.3 million in the three months ended June 30, 2012 to $38.9 million in the three months ended June 30, 2013, and increased 3.8% from $69.4 million in the six months ended June 30, 2012 to $72.0
million in the six months ended June 30, 2013. The increase in sales for the three and six months ended June 30, 2013 is primarily attributable to increases in sales of our Internetworking products, partially offset by decreases in sales
of our legacy products. The increase in sales of our Internetworking products was primarily attributable to an improved spending environment and reflected an increase in sales to both carriers and value added resellers. The decrease in legacy
products was expected and discussed further above. Internetworking product sales attributable to Enterprise Networks were 93.4% and 93.7% of the division’s sales in the three and six months ended June 30, 2013, compared to 91.1% in the
three and six months ended June 30, 2012. Legacy products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales increased from 17.0% for the three months ended June 30, 2012
to 24.0% for the three months ended June 30, 2013, and increased from 21.8% for the six months ended June 30, 2012 to 23.6% for the six months ended June 30, 2013.

[0001193125-13-312256:mdna:63]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, decreased 35.2% from $53.6 million in the three months ended June 30, 2012 to $34.7
million in the three months ended June 30, 2013, and decreased 3.1% from $71.9 million in the six months ended June 30, 2012 to $69.7 million in the six months ended June 30, 2013. International sales, as a percentage of total sales,
decreased from 29.1% for the three months ended June 30, 2012 to 21.4% for the three months ended June 30, 2013, and increased from 22.6% for the six months ended June 30, 2012 to 22.8% for the six months ended June 30, 2013.
International sales decreased in the three and six months ended June 30, 2013 compared to the three and six months ended June 30, 2012 primarily due to a decrease in sales in Latin America and the Asia-Pacific region, partially offset by
an increase in sales in the EMEA region.

[0001193125-13-312256:mdna:64]
Carrier System product sales decreased $21.2 million in the three months ended June 30, 2013 and
increased $0.3 million in the six months ended June 30, 2013 compared to the three and six months ended June 30, 2012. The decrease for the three months ended June 30, 2013 is primarily due to a $24.4 million decrease in Broadband
Access product sales, partially offset by a $2.0 million increase in Optical product sales and a $1.2 million increase in legacy product sales. The increase for the six months ended June 30, 2013 is primarily due to a $5.4 million increase in
legacy product sales, partially offset by a $3.4 million decrease in Optical product sales and a $1.7 million decrease in Broadband Access product sales. The changes for the three and six months ended June 30, 2013 are primarily attributable to
the factors discussed above.

[0001193125-13-312256:mdna:65]
Business Networking product sales increased $8.8 million and $3.7 million in the three and six months ended
June 30, 2013 compared to the three and six months ended June 30, 2012. The increase for the three and six months ended June 30, 2013 is primarily due to a $9.0 million and $4.9 million increase in Internetworking product sales across
both divisions, respectively, partially offset by decreases in legacy product sales of $0.2 million and $1.2 million, respectively. The increase in sales of our Internetworking products was primarily attributable to an improved spending environment
and reflected an increase in sales to both carriers and value added resellers. The decrease in legacy products was expected and is discussed further above.

[0001193125-13-312256:mdna:66]
Loop Access product sales decreased $9.3 million and $17.5 million in the three and six months ended June 30, 2013 compared to the three and six months ended June 30, 2012. The decrease for the
three and six months ended June 30, 2013 is primarily due to a $9.2 million and $16.7 million decrease, respectively, in HDSL product sales, which was discussed further above.

[0001193125-13-312256:mdna:67]
[same as prior period, unchanged from 0001193125-13-207088:mdna:67]

[0001193125-13-312256:mdna:68]
As a percentage of sales, cost of sales increased from 48.3% in the
three months ended June 30, 2012 to 50.8% in the three months ended June 30, 2013 and increased from 46.9% in the six months ended June 30, 2012 to 51.0% in the six months ended June 30, 2013. This increase is primarily
attributable to lower gross margins related to the acquired broadband access business, lower cost absorption due to lower production volumes on the organic business, customer price movements to achieve market share position and shifts in customer
mix.

[0001193125-13-312256:mdna:69]
Carrier Networks cost of sales, as a percent of division sales, increased from 48.4% in the three months ended June 30, 2012 to
53.0% in the three months ended June 30, 2013 and increased from 47.2% in the six months ended June 30, 2012 to 53.0% in the six months ended June 30, 2013. The increase in Carrier Networks cost of sales as a percentage of sales
is primarily attributable to the factors outlined above.

[0001193125-13-312256:mdna:70]
Enterprise Networks cost of sales, as a percent of division sales, decreased from
47.4% in the three months ended June 30, 2012 to 43.7% in the three months ended June 30, 2013 and decreased from 45.7% in the six months ended June 30, 2012 to 44.5% in the six months ended June 30, 2013. The decrease is
primarily attributable to higher cost absorption due to higher production volumes.

[0001193125-13-312256:mdna:71]
An important part of our strategy is to reduce the product
cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions
and the lowering of product selling prices.

[0001193125-13-312256:mdna:72]
[same as prior period, unchanged from 0001193125-13-207088:mdna:72]

[0001193125-13-312256:mdna:73]
Selling, general and administrative expenses decreased 9.0% from $35.9 million in the three months ended June 30, 2012 to $32.7 million in the three
months ended June 30, 2013 and decreased 8.3% from $69.0 million in the six months ended June 30, 2012 to $63.3 million in the six months ended June 30, 2013. The decrease in selling, general and administrative expenses for the three
and six months ended June 30, 2013 is primarily related to decreases in professional services, legal services and travel expense, which were higher in 2012 due to pre-acquisition activities related to the acquired broadband access business.

[0001193125-13-312256:mdna:74]
Selling, general and administrative expenses as a percentage of sales increased from 19.5% in the three
months ended June 30, 2012 to 20.1% in the three months ended June 30, 2013 and decreased from 21.7% in the six months ended June 30, 2012 to 20.7% in the six months ended June 30, 2013. Selling, general and administrative
expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-13-312256:mdna:75]
[same as prior period, unchanged from 0001193125-13-207088:mdna:75]

[0001193125-13-312256:mdna:76]
Research and development expenses increased 1.9% from $32.5 million in the three months ended June 30, 2012 to $33.1 million in the three months
ended June 30, 2013 and increased 14.5% from $57.3 million in the six months ended June 30, 2012 to $65.6 million in the six months ended June 30, 2013. The increase in research and development expenses for the three and six months
ended June 30, 2013 is primarily related to increases in staffing and fringe benefit costs due to increased headcount related to the broadband access business acquired on May 4, 2012, and increases in amortization of acquired intangible
assets, partially offset by a decrease in independent contractor expense.

[0001193125-13-312256:mdna:77]
As a percentage of sales, research and development expenses
increased from 17.6% in the three months ended June 30, 2012 to 20.4% in the three months ended June 30, 2013 and increased from 18.0% in the six months ended June 30, 2012 to 21.5% in the six months ended June 30, 2013. Research
and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-13-312256:mdna:78]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international
markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products and product cost reductions. We may incur
significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-13-312256:mdna:79]
INTEREST AND DIVIDEND
INCOME

[0001193125-13-312256:mdna:80]
Interest and dividend income remained consistent at $1.9 million and $1.7 million in the three months ended June 30, 2012
and 2013, respectively, and remained consistent at $3.8 million and $3.4 million in the six months ended June 30, 2012 and 2013, respectively, as we had no substantial change in interest-bearing investment balances or interest rates.

[0001193125-13-312256:mdna:81]
[same as prior period, unchanged from 0001193125-13-207088:mdna:81]

[0001193125-13-312256:mdna:82]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.6 million in each of the three months ended
June 30, 2012 and 2013, and $1.2 million in each of the six months ended June 30, 2012 and 2013, respectively, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for
additional information on our revenue bond.

[0001193125-13-312256:mdna:83]
NET REALIZED INVESTMENT GAIN

[0001193125-13-312256:mdna:84]
Net realized investment gain decreased 34.1% from $2.4 million in the three months ended June 30, 2012 to $1.6 million in the three months ended
June 30, 2013 and increased 7.8% from $4.8 million in the six months ended June 30, 2012 to $5.2 million in the six months ended June 30, 2013. The lower amount of realized gains in the three-month period ended June 30, 2013 is
primarily driven by lower gains from the sale of equity securities compared to the same period in 2012. The higher amount of realized gains in the six-month period ended June 30, 2013 is primarily driven by higher sales of equity securities and
rebalancing of the marketable equity security portfolio. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-13-312256:mdna:85]
OTHER INCOME (EXPENSE), NET

[0001193125-13-312256:mdna:86]
Other income (expense), net, comprised primarily of
miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, scrap raw material sales, and gains and losses on the disposal of property, plant and equipment occurring in the normal course of business,
decreased from $0.5 million of income in the three months ended June 30, 2012 to $0.1 million of income in the three months ended June 30, 2013 and changed from $0.6 million of income in the six months ended June 30, 2012 to $1.5
million of expense in the six months ended June 30, 2013. The change in the six months ended June 30, 2013 was primarily attributable to losses on foreign currency transactions during the first quarter of 2013.

[0001193125-13-312256:mdna:87]
[same as prior period, unchanged from 0001193125-13-207088:mdna:87]

[0001193125-13-312256:mdna:88]
Our effective tax rate decreased from 35.6% in the six months ended June 30, 2012 to 33.2% in the six months ended June 30, 2013. The decrease in the effective tax rate between the two
periods is primarily attributable to the net effect of recording the benefit for the research tax credit for the 2012 tax year in January 2013 pursuant to the American Taxpayer Relief Act of 2012, the inclusion of the benefit of the estimated 2013
research tax credit in the estimated annual effective rate for 2013, and foreign subsidiary losses for which no tax benefits are recorded.

[0001193125-13-312256:mdna:89]
[same as prior period, unchanged from 0001193125-13-207088:mdna:89]

[0001193125-13-312256:mdna:90]
As a result of the
above factors, net income decreased $11.2 million from $21.1 million in the three months ended June 30, 2012 to $9.9 million in the three months ended June 30, 2013 and decreased $16.3 million from $34.0 million in the six months ended
June 30, 2012 to $17.7 million in the six months ended June 30, 2013.

[0001193125-13-312256:mdna:91]
As a percentage of sales, net income decreased from 11.5% in
the three months ended June 30, 2012 to 6.1% in the three months ended June 30, 2013 and decreased from 10.7% in the six months ended June 30, 2012 to 5.8% in the six months ended June 30, 2013.

[0001193125-13-312256:mdna:92]
[same as prior period, unchanged from 0001193125-13-207088:mdna:92]

[0001193125-13-312256:mdna:93]
[same as prior period, unchanged from 0001193125-13-207088:mdna:93]

[0001193125-13-312256:mdna:94]
[same as prior period, unchanged from 0001193125-13-207088:mdna:94]

[0001193125-13-312256:mdna:95]
At June 30, 2013, cash on hand was $37.6 million and
short-term investments were $152.6 million, which resulted in available short-term liquidity of $190.1 million. At December 31, 2012, our cash on hand of $68.5 million and short-term investments of $160.5 million resulted in available
short-term liquidity of $228.9 million. The decrease in short-term liquidity from December 31, 2012 to June 30, 2013 primarily reflects funds used for equipment acquisitions, share repurchases and dividends, partially offset by funds
provided by our operating activities.

[0001193125-13-312256:mdna:96]
[same as prior period, unchanged from 0001193125-13-207088:mdna:96]

[0001193125-13-312256:mdna:97]
Our working capital, which consists of current assets less current liabilities, decreased 11.0% from $339.4 million as of December 31, 2012 to $302.0 million as of June 30, 2013. The quick
ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.90 as of December 31, 2012 to 2.52 as of June 30, 2013. The current ratio, defined as current
assets divided by current liabilities, decreased from 4.18 as of December 31, 2012 to 3.60 as of June 30, 2013. The decreases in our working capital, the quick ratio and the current ratio is primarily attributable to a decrease in cash and
short-term investments, which was used to fund treasury stock repurchases during the six months ended June 30, 2013.

[0001193125-13-312256:mdna:98]
Net accounts
receivable increased 27.5% from $81.2 million at December 31, 2012 to $103.5 million at June 30, 2013. Our allowance for doubtful accounts was $6 thousand at December 31, 2012 and $15 thousand at June 30, 2013. Quarterly accounts
receivable days sales outstanding (DSO) increased from 53 days as of December 31, 2012 to 58 days as of June 30, 2013. The change in net accounts receivable and DSO is due to the timing of sales and collections during the quarter and
customer mix. Many of our international customers have longer payment terms than our U.S. customers.

[0001193125-13-312256:mdna:99]
Quarterly inventory turnover increased
from 2.8 turns as of December 31, 2012 to 3.6 turns as of June 30, 2013. Inventory decreased 14.4% from December 31, 2012 to June 30, 2013. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in
response to seasonal cycles of our business ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-13-312256:mdna:100]
Accounts payable increased 47.2% from $42.2 million at December 31, 2012 to $62.1 million at June 30, 2013. Accounts payable will fluctuate due
to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-13-312256:mdna:101]
[same as prior period, unchanged from 0001193125-13-207088:mdna:101]

[0001193125-13-312256:mdna:102]
Capital expenditures totaled approximately $7.8 million and $3.7 million for the six months ended June 30, 2012 and 2013, respectively. These expenditures were primarily used to purchase
manufacturing and test equipment and computer software and hardware.

[0001193125-13-312256:mdna:103]
Our combined short-term and long-term investments decreased $48.0
million from $493.2 million at December 31, 2012 to $445.2 million at June 30, 2013. This decrease reflects the impact of our cash needs for equipment acquisitions, share repurchases and dividends, as well as net realized and unrealized
losses and amortization of net premiums on our combined investments, partially offset by additional funds available for investment provided by our operating activities and stock option exercises by our employees.

[0001193125-13-312256:mdna:104]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At
June 30, 2013 these investments included corporate bonds of $187.9 million, municipal fixed-rate bonds of $155.5 million and municipal variable rate demand notes of $7.1 million. At December 31, 2012, these investments included corporate
bonds of $186.4 million, municipal fixed-rate bonds of $175.1 million and municipal variable rate demand notes of $34.4 million. As of June 30, 2013, our corporate bonds, municipal fixed-rate bonds, and municipal variable rate demand notes were
classified as available-for-sale and had a combined duration of 1.0 years with an average credit rating of A+. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for
these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-13-312256:mdna:105]
Our long-term
investments decreased 12.0% from $332.7 million at December 31, 2012 to $292.7 million at June 30, 2013. The primary reason for the decrease in our long-term investments during 2013 was the movement of certain long-term corporate bonds and
long-term municipal bonds to short-term classification. Long-term investments at June 30, 2013 and December 31, 2012 included an investment in a certificate of deposit of $48.3 million, which serves as collateral for our revenue bonds, as
discussed below. We have various equity investments included in long-term investments at a cost of $22.7 million and $21.0 million, and with a fair value of $31.9 million and $35.2 million, at June 30, 2013 and December 31, 2012,
respectively.

[0001193125-13-312256:mdna:106]
Long-term investments at June 30, 2013 also includes $12.8 million related to our deferred compensation plans and $1.8
million of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001193125-13-312256:mdna:107]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which
may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative
information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our
identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual
security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $4 thousand during the six months ended June 30, 2013
related to one marketable security. For the six months ended June 30, 2012, we recorded an other-than-temporary impairment charge of $33 thousand related to eight marketable equity securities.

[0001193125-13-312256:mdna:108]
[same as prior period, unchanged from 0001193125-13-207088:mdna:108]

[0001193125-13-312256:mdna:109]
[same as prior period, unchanged from 0001193125-13-207088:mdna:109]

[0001193125-13-312256:mdna:110]
In July 2003, our Board of Directors elected to begin declaring quarterly
dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the six months ended June 30, 2013, we paid dividends totaling $11.0 million.

[0001193125-13-312256:mdna:111]
[same as prior period, unchanged from 0001193125-13-207088:mdna:111]

[0001193125-13-312256:mdna:112]
We have amounts outstanding
under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $46.5 million at June 30, 2013 and December 31, 2012. At June 30, 2013, the estimated fair value of
the Bond was approximately $46.3 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of A-. Included in long-term investments are restricted funds in the amount
of $48.3 million at June 30, 2013 and December 31, 2012, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the
balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 5% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that
reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program.

[0001193125-13-312256:mdna:113]
We are required to make payments in the amounts necessary to pay the principal and interest on the amounts currently outstanding. Based on positive
cash flow from operating activities, we have decided to continue early partial redemptions of the Bond. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $0.5
million of the Bond debt has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at June 30, 2013.

[0001193125-13-312256:mdna:114]
[same as prior period, unchanged from 0001193125-13-207088:mdna:114]

[0001193125-13-312256:mdna:115]
Since 1997,
our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 35 million shares of our common stock. On May 1, 2013, our Board of Directors authorized the
repurchase of an additional 5.0 million shares of our common stock, which commenced upon completion of the repurchase plan announced on October 11, 2011. This new authorization is being implemented through open market or private purchases
from time to time as conditions warrant.

[0001193125-13-312256:mdna:116]
During the six months ended June 30, 2013, we repurchased 4.2 million shares of our common
stock at an average price of $21.49 per share. We currently have the authority to purchase an additional 4.9 million shares of our common stock under the current plan approved by the Board of Directors.

[0001193125-13-312256:mdna:117]
Stock Option Exercises

[0001193125-13-312256:mdna:118]
To accommodate
employee stock option exercises, we issued 45 thousand shares of treasury stock for $0.8 million during the six months ended June 30, 2013. During the six months ended June 30, 2012, we issued 0.2 million shares of treasury stock
for $4.3 million.

[0001193125-13-312256:mdna:119]
[same as prior period, unchanged from 0001193125-13-207088:mdna:118]

[0001193125-13-312256:mdna:120]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to
materially affect liquidity or the availability of or requirements for capital resources. During the six months ended June 30, 2013, there have been no material changes in contractual obligations and commercial commitments from those discussed
in our most recent Annual Report on Form 10-K for the year ended December 31, 2012 filed on February 28, 2013 with the SEC.

[0001193125-13-312256:mdna:121]
We have
committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2013, of which $7.7 million has been applied to these commitments.

[0001193125-13-312256:mdna:122]
[same as prior period, unchanged from 0001193125-13-207088:mdna:121]

[0001193125-13-312256:mdna:123]
The following are some of the risks that could affect our financial performance or could cause actual results to differ materially from those expressed or implied in our forward-looking statements:

[0001193125-13-312256:mdna:124]
|  | • |  | Our operating results may fluctuate in future periods, which may adversely affect our stock price. |

[0001193125-13-312256:mdna:125]
|  | • |  | Our revenue for a particular period can be difficult to predict, and a shortfall in revenue may harm our operating results. |

[0001193125-13-312256:mdna:126]
|  | • |  | The failure to realize future benefits from the acquisition of the NSN BBA business as significant as we expect may affect our future results of operations and financial condition, and could affect our stock price. |

[0001193125-13-312256:mdna:127]
|  | • |  | General economic conditions may reduce our revenues and harm our operating results. |

[0001193125-13-312256:mdna:128]
|  | • |  | Our exposure to the credit risks of our customers and distributors may make it difficult to collect accounts receivable and could adversely affect our operating results and financial condition. |

[0001193125-13-312256:mdna:129]
|  | • |  | We expect gross margin to vary over time, and our level of product gross margin may not be sustainable. |

[0001193125-13-312256:mdna:130]
|  | • |  | We must continue to update and improve our products and develop new products in order to compete and to keep pace with improvements in communications technology. |

[0001193125-13-312256:mdna:131]
|  | • |  | Our products may not continue to comply with the regulations governing their sale, which may harm our business. |

[0001193125-13-312256:mdna:132]
|  | • |  | Our failure or the failure of our contract manufacturers to comply with applicable environmental regulations could adversely impact our results of operations. |

[0001193125-13-312256:mdna:133]
|  | • |  | If our products do not interoperate with our customers’ networks, installations may be delayed or cancelled, which could harm our business. |

[0001193125-13-312256:mdna:134]
|  | • |  | The lengthy approval process required by major and other service providers for new products could result in fluctuations in our revenue. |

[0001193125-13-312256:mdna:135]
|  | • |  | We engage in research and development activities to improve the application of developed technologies, and as a consequence may miss certain market opportunities enjoyed by larger companies with substantially greater research and development efforts who may focus on more leading edge development. |

[0001193125-13-312256:mdna:136]
|  | • |  | We depend heavily on sales to certain customers; the loss of any of these customers would significantly reduce our revenues and net income. |

[0001193125-13-312256:mdna:137]
|  | • |  | Our strategy of outsourcing a portion of our manufacturing requirements to subcontractors located in Asia or other international regions may result in us not meeting our cost, quality or performance standards. |

[0001193125-13-312256:mdna:138]
|  | • |  | Our dependence on a limited number of suppliers may prevent us from delivering our products on a timely basis, which could have a material adverse effect on customer relations and operating results. |

[0001193125-13-312256:mdna:139]
|  | • |  | We compete in markets that have become increasingly competitive, which may result in reduced gross profit margins and market share. |

[0001193125-13-312256:mdna:140]
|  | • |  | Our estimates regarding future warranty obligations may change due to product failure rates, shipment volumes, field service obligations and other rework costs incurred in correcting product failures. If our estimates change, the liability for warranty obligations may be increased or decreased, impacting future cost of goods sold. |

[0001193125-13-312256:mdna:141]
|  | • |  | Managing our inventory is complex and may include write-downs of excess or obsolete inventory. |

[0001193125-13-312256:mdna:142]
|  | • |  | The continuing growth of our international operations could expose us to additional risks, increase our costs and adversely affect our operating results and financial condition. |

[0001193125-13-312256:mdna:143]
|  | • |  | We may be adversely affected by fluctuations in currency exchange rates. |

[0001193125-13-312256:mdna:144]
|  | • |  | Our success depends on our ability to reduce the selling prices of succeeding generations of our products. |

[0001193125-13-312256:mdna:145]
|  | • |  | Our failure to maintain rights to intellectual property used in our business could adversely affect the development, functionality, and commercial value of our products. |

[0001193125-13-312256:mdna:146]
|  | • |  | Software under license from third parties for use in certain of our products may not continue to be available to us on commercially reasonable terms. |

[0001193125-13-312256:mdna:147]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-13-312256:mdna:148]
|  | • |  | Consolidation and deterioration in the competitive service provider market could result in a significant decrease in our revenue. |

[0001193125-13-312256:mdna:149]
|  | • |  | We depend on distributors who maintain inventories of our products. If the distributors reduce their inventories of these products, our sales could be adversely affected. |

[0001193125-13-312256:mdna:150]
36

[0001193125-13-312256:mdna:151]
|  | • |  | If we are unable to successfully develop relationships with system integrators, service providers, and enterprise value added resellers, our sales may be negatively affected. |

[0001193125-13-312256:mdna:152]
|  | • |  | If we fail to manage our exposure to worldwide financial and securities markets successfully, our operating results and financial statements could be materially impacted. |

[0001193125-13-312256:mdna:153]
|  | • |  | Changes in our effective tax rate or assessments arising from tax audits may have an adverse impact on our results. |

[0001193125-13-312256:mdna:154]
|  | • |  | We are required to periodically evaluate the value of our long-lived assets, including the value of intangibles acquired and goodwill resulting from business acquisitions. Any future impairment charges required may adversely affect our operating results. |

[0001193125-13-312256:mdna:155]
|  | • |  | Our success depends on attracting and retaining key personnel. |

[0001193125-13-312256:mdna:156]
|  | • |  | Regulatory and potential physical impacts of climate change and other natural events may affect our customers and our production operations, resulting in adverse effects on our operating results. |

[0001193125-13-312256:mdna:157]
|  | • |  | While we believe our internal control over financial reporting is adequate, a failure to maintain effective internal control over financial reporting as our business expands could result in a loss of investor confidence in our financial reports and have an adverse effect on our stock price. |

[0001193125-13-312256:mdna:158]
|  | • |  | The price of our common stock has been volatile and may continue to fluctuate significantly. |

[0001193125-13-312256:mdna:159]
The foregoing list of risks is not exclusive. For a more detailed description of the risk factors associated with our business, see Item 1A of our
Annual Report on Form 10-K for the year ended December 31, 2012, filed on February 
28, 2013 with the SEC.
