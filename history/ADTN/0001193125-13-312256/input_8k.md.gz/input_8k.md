# ADTN 8-K — 0001157523-13-003290 filed 2013-07-10

## item codes, every 8-K on or before 2013-07-31

- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2013-07-31

- none on or before 2013-07-31

## item 2.02 — earnings release, exhibit 99.1

[0001157523-13-003290:8k_2_02:1]
EX-99.1
2
a50667220ex99_1.htm
EXHIBIT 99.1

[0001157523-13-003290:8k_2_02:2]
Exhibit 99.1

[0001157523-13-003290:8k_2_02:3]
ADTRAN,
      Inc. Reports Results for the Second Quarter 2013 and Declares Quarterly
      Cash Dividend

[0001157523-13-003290:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--July 9, 2013--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the second quarter 2013. For the
      quarter, sales were $162,233,000 compared to $183,998,000 for the second
      quarter of 2012. Net income was $9,859,000 for the quarter compared to
      $21,070,000 for the second quarter of 2012. Earnings per share, assuming
      dilution, were $0.17 for the quarter compared to $0.33 for the second
      quarter of 2012. Non-GAAP earnings per share for the quarter were $0.21
      compared to $0.38 for the second quarter of 2012. The reconciliation
      between GAAP earnings per share, diluted, and non-GAAP earnings per
      share, diluted, is in the table provided.

[0001157523-13-003290:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “Continuing
      improvement in our Internetworking and Broadband Access product areas
      led revenues which exceeded estimates for the quarter. During the
      quarter we benefited from market share gains, the geographic expansion
      we began last year and an improved spending environment.”

[0001157523-13-003290:8k_2_02:6]
The Company also announced that its Board of Directors declared a cash
      dividend for the second quarter of 2013. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on July 25, 2013. The ex-dividend date is July 23, 2013 and the
      payment date is August 8, 2013.

[0001157523-13-003290:8k_2_02:7]
The Company confirmed that its second quarter conference call will be
      held Wednesday, July 10, 2013 at 9:30 a.m. Central Time. This conference
      call will be web cast live through StreetEvents.com. To listen, simply
      visit the Investor Relations site at www.adtran.com or www.streetevents.com
      approximately 10 minutes prior to the start of the call and click on the
      conference call link provided.

[0001157523-13-003290:8k_2_02:8]
An online replay of the conference call will be available for seven days
      at www.streetevents.com. In addition, an online replay of the
      conference call, as well as the text of the Company's earnings release,
      will be available on the Investor Relations site at www.adtran.com
      for at least 12 months following the call.

[0001157523-13-003290:8k_2_02:9]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment. ADTRAN’s products enable voice, data, video
      and Internet communications across a variety of network infrastructures.
      ADTRAN solutions are currently in use by service providers, private
      enterprises, government organizations, and millions of individual users
      worldwide. For more information, please visit www.adtran.com.

[0001157523-13-003290:8k_2_02:10]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-13-003290:8k_2_02:11]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2012 and on Form 10-Q for the quarter ended March 31, 2013. These
      risks and uncertainties could cause actual results to differ materially
      from those in the forward-looking statements included in this press
      release.

[0001157523-13-003290:8k_2_02:12]
| Condensed Consolidated Balance Sheet(Unaudited)(In thousands) |
|  |  | June 30, 2013 |  | December 31,2012 |
| Assets |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ |  |  |  |  |  | 37,559 |  | $ | 68,457 |
| Short-term investments |  |  |  |  |  |  |  |  | 152,581 |  |  | 160,481 |
| Accounts receivable, net |  |  |  |  |  |  |  |  | 103,516 |  |  | 81,194 |
| Other receivables |  |  |  |  |  |  |  |  | 18,820 |  |  | 16,253 |
| Inventory |  |  |  |  |  |  |  |  | 87,773 |  |  | 102,583 |
| Prepaid expenses |  |  |  |  |  |  |  |  | 4,926 |  |  | 4,148 |
| Deferred tax assets, net |  |  |  |  |  |  |  |  | 13,114 |  |  | 13,055 |
| Total Current Assets |  |  |  |  |  |  |  |  | 418,289 |  |  | 446,171 |
| Property, plant and equipment, net |  |  |  |  |  |  |  |  | 77,670 |  |  | 80,246 |
| Deferred tax assets, net |  |  |  |  |  |  |  |  | 12,171 |  |  | 10,261 |
| Goodwill |  |  |  |  |  |  |  |  | 3,492 |  |  | 3,492 |
| Other assets |  |  |  |  |  |  |  |  | 12,046 |  |  | 13,482 |
| Long-term investments |  |  |  |  |  |  |  |  | 292,660 |  |  | 332,729 |
| Total Assets |  |  | $ |  |  |  |  |  | 816,328 |  | $ | 886,381 |
| Liabilities and Stockholders' Equity |  |  |  |  |  |
| Accounts payable |  |  | $ |  |  |  |  |  | 62,097 |  | $ | 42,173 |
| Unearned revenue |  |  |  |  |  |  |  |  | 25,808 |  |  | 38,051 |
| Accrued expenses |  |  |  |  |  |  |  |  | 12,020 |  |  | 10,309 |
| Accrued wages and benefits |  |  |  |  |  |  |  |  | 14,093 |  |  | 15,022 |
| Income tax payable, net |  |  |  |  |  |  |  |  | 2,317 |  |  | 1,211 |
| Total Current Liabilities |  |  |  |  |  |  |  |  | 116,335 |  |  | 106,766 |
| Non-current unearned revenue |  |  |  |  |  |  |  |  | 25,266 |  |  | 23,803 |
| Other non-current liabilities |  |  |  |  |  |  |  |  | 19,042 |  |  | 17,406 |
| Bonds payable |  |  |  |  |  |  |  |  | 46,000 |  |  | 46,000 |
| Total Liabilities |  |  |  |  |  |  |  |  | 206,643 |  |  | 193,975 |
| Stockholders' Equity |  |  |  |  |  |  |  |  | 609,685 |  |  | 692,406 |
| Total Liabilities and Stockholders' Equity |  |  | $ |  |  |  |  |  | 816,328 |  | $ | 886,381 |

[0001157523-13-003290:8k_2_02:13]
| Consolidated Statements of Income(Unaudited)(In thousands, except per share data) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Sales |  | $ | 162,233 |  |  | $ | 183,998 |  |  | $ | 305,246 |  |  | $ | 318,733 |  |
| Cost of sales |  |  | 82,435 |  |  |  | 88,797 |  |  |  | 155,771 |  |  |  | 149,445 |  |
| Gross Profit |  |  | 79,798 |  |  |  | 95,201 |  |  |  | 149,475 |  |  |  | 169,288 |  |
| Selling, general and administrative expenses |  |  | 32,685 |  |  |  | 35,905 |  |  |  | 63,288 |  |  |  | 69,017 |  |
| Research and development expenses |  |  | 33,060 |  |  |  | 32,458 |  |  |  | 65,571 |  |  |  | 57,252 |  |
| Operating Income |  |  | 14,053 |  |  |  | 26,838 |  |  |  | 20,616 |  |  |  | 43,019 |  |
| Interest and dividend income |  |  | 1,674 |  |  |  | 1,926 |  |  |  | 3,442 |  |  |  | 3,787 |  |
| Interest expense |  |  | (575 | ) |  |  | (581 | ) |  |  | (1,156 | ) |  |  | (1,168 | ) |
| Net realized investment gain |  |  | 1,553 |  |  |  | 2,356 |  |  |  | 5,198 |  |  |  | 4,823 |  |
| Other income (expense), net |  |  | 129 |  |  |  | 492 |  |  |  | (1,543 | ) |  |  | 633 |  |
| Gain on bargain purchase of a business |  |  | - |  |  |  | 1,753 |  |  |  | - |  |  |  | 1,753 |  |
| Income before provision for income taxes |  |  | 16,834 |  |  |  | 32,784 |  |  |  | 26,557 |  |  |  | 52,847 |  |
| Provision for income taxes |  |  | (6,975 | ) |  |  | (11,714 | ) |  |  | (8,808 | ) |  |  | (18,816 | ) |
| Net Income |  | $ | 9,859 |  |  | $ | 21,070 |  |  | $ | 17,749 |  |  | $ | 34,031 |  |
| Weighted average shares outstanding - basic |  |  | 59,056 |  |  |  | 63,619 |  |  |  | 60,443 |  |  |  | 63,720 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 59,311 |  |  |  | 64,393 |  |  |  | 60,660 |  |  |  | 64,628 |  |
| Earnings per common share - basic |  | $ | 0.17 |  |  | $ | 0.33 |  |  | $ | 0.29 |  |  | $ | 0.53 |  |
| Earnings per common share - diluted (1) |  | $ | 0.17 |  |  | $ | 0.33 |  |  | $ | 0.29 |  |  | $ | 0.53 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001157523-13-003290:8k_2_02:14]
| Consolidated Statements of Comprehensive Income(Unaudited)(In thousands) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net Income |  | $ | 9,859 |  |  | $ | 21,070 |  |  | $ | 17,749 |  |  | $ | 34,031 |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | (1,698 | ) |  |  | (5,235 | ) |  |  | (3,342 | ) |  |  | 1,522 |
| Foreign currency translation |  |  | (1,713 | ) |  |  | (96 | ) |  |  | (1,390 | ) |  |  | 58 |
| Other Comprehensive Income (Loss), net of tax |  |  | (3,411 | ) |  |  | (5,331 | ) |  |  | (4,732 | ) |  |  | 1,580 |
| Comprehensive Income (Loss), net of tax |  | $ | 6,448 |  |  | $ | 15,739 |  |  | $ | 13,017 |  |  | $ | 35,611 |

[0001157523-13-003290:8k_2_02:15]
| Consolidated Statements of Cash Flows(Unaudited)(In thousands) |
|  |  | Six Months Ended |
|  |  | June 30, |
|  |  | 2013 |  | 2012 |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 17,749 |  |  | $ | 34,031 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 7,373 |  |  |  | 6,615 |  |
| Amortization of net premium on available-for-sale investments |  |  | 3,315 |  |  |  | 4,330 |  |
| Net realized gain on long-term investments |  |  | (5,198 | ) |  |  | (4,823 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | 17 |  |  |  | (204 | ) |
| Gain on bargain purchase of a business |  |  | - |  |  |  | (1,753 | ) |
| Stock-based compensation expense |  |  | 4,340 |  |  |  | 4,432 |  |
| Deferred income taxes |  |  | 150 |  |  |  | (2,427 | ) |
| Tax benefit from stock option exercises |  |  | 21 |  |  |  | 1,701 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (21 | ) |  |  | (1,346 | ) |
| Change in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | (23,018 | ) |  |  | (43,062 | ) |
| Other receivables |  |  | (2,727 | ) |  |  | 1,997 |  |
| Inventory |  |  | 13,336 |  |  |  | 5,548 |  |
| Prepaid expenses and other assets |  |  | (665 | ) |  |  | (1,527 | ) |
| Accounts payable |  |  | 20,252 |  |  |  | 12,877 |  |
| Accrued expenses and other liabilities |  |  | (6,587 | ) |  |  | 13,099 |  |
| Income tax payable, net |  |  | 1,094 |  |  |  | 7,508 |  |
| Net cash provided by operating activities |  |  | 29,431 |  |  |  | 36,996 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (3,667 | ) |  |  | (7,787 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | - |  |  |  | 266 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 224,163 |  |  |  | 138,307 |  |
| Purchases of available-for-sale investments |  |  | (179,730 | ) |  |  | (161,849 | ) |
| Acquisition of business |  |  | - |  |  |  | 7,496 |  |
| Net cash provided by (used in) investing activities |  |  | 40,766 |  |  |  | (23,567 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from stock option exercises |  |  | 819 |  |  |  | 4,328 |  |
| Purchases of treasury stock |  |  | (89,917 | ) |  |  | (13,432 | ) |
| Dividend payments |  |  | (10,982 | ) |  |  | (11,476 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | 21 |  |  |  | 1,346 |  |
| Net cash used in financing activities |  |  | (100,059 | ) |  |  | (19,234 | ) |
| Net decrease in cash and cash equivalents |  |  | (29,862 | ) |  |  | (5,805 | ) |
| Effect of exchange rate changes |  |  | (1,036 | ) |  |  | (206 | ) |
| Cash and cash equivalents, beginning of period |  |  | 68,457 |  |  |  | 42,979 |  |
| Cash and cash equivalents, end of period |  | $ | 37,559 |  |  | $ | 36,968 |  |

[0001157523-13-003290:8k_2_02:16]
| Supplemental InformationAcquisition Related Expenses, Amortizations and Adjustments(Unaudited)(In thousands) |
| On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and six months ended June 30, 2013 and 2012 for both transactions are as follows: |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 287 |  |  | $ | 378 |  |  | $ | 580 |  |  | $ | 862 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 288 |  |  |  | 172 |  |  |  | 582 |  |  |  | 172 |  |
| Amortization of other purchase accounting adjustments |  |  | 342 |  |  |  | 1,052 |  |  |  | 752 |  |  |  | 1,052 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 82 |  |  |  | 2,705 |  |  |  | 236 |  |  |  | 4,285 |  |
| Subtotal |  |  | 712 |  |  |  | 3,929 |  |  |  | 1,570 |  |  |  | 5,509 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 999 |  |  |  | 4,307 |  |  |  | 2,150 |  |  |  | 6,371 |  |
| Provision for income taxes |  |  | (333 | ) |  |  | (1,361 | ) |  |  | (713 | ) |  |  | (2,039 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 666 |  |  | $ | 2,946 |  |  | $ | 1,437 |  |  | $ | 4,332 |  |
| The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and six months ended June 30, 2013 and 2012: |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 235 |  |  | $ | 508 |  |  | $ | 497 |  |  | $ | 654 |  |
| Cost of goods sold |  |  | 64 |  |  |  | 669 |  |  |  | 151 |  |  |  | 806 |  |
| Subtotal |  |  | 299 |  |  |  | 1,177 |  |  |  | 648 |  |  |  | 1,460 |  |
| Selling, general and administrative expenses |  |  | 113 |  |  |  | 2,361 |  |  |  | 274 |  |  |  | 3,922 |  |
| Research and development expenses |  |  | 587 |  |  |  | 769 |  |  |  | 1,228 |  |  |  | 989 |  |
| Subtotal |  |  | 700 |  |  |  | 3,130 |  |  |  | 1,502 |  |  |  | 4,911 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 999 |  |  |  | 4,307 |  |  |  | 2,150 |  |  |  | 6,371 |  |
| Provision for income taxes |  |  | (333 | ) |  |  | (1,361 | ) |  |  | (713 | ) |  |  | (2,039 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 666 |  |  | $ | 2,946 |  |  | $ | 1,437 |  |  | $ | 4,332 |  |

[0001157523-13-003290:8k_2_02:17]
| Supplemental InformationStock-based Compensation Expense(Unaudited)(In thousands) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Stock-based compensation expense included in cost of sales |  | $ | 110 |  |  | $ | 97 |  |  | $ | 216 |  |  | $ | 198 |  |
| Selling, general and administrative expense |  |  | 1,042 |  |  |  | 1,047 |  |  |  | 2,105 |  |  |  | 2,098 |  |
| Research and development expense |  |  | 956 |  |  |  | 1,067 |  |  |  | 2,019 |  |  |  | 2,136 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,998 |  |  |  | 2,114 |  |  |  | 4,124 |  |  |  | 4,234 |  |
| Total stock-based compensation expense |  |  | 2,108 |  |  |  | 2,211 |  |  |  | 4,340 |  |  |  | 4,432 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (310 | ) |  |  | (302 | ) |  |  | (617 | ) |  |  | (603 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,798 |  |  | $ | 1,909 |  |  | $ | 3,723 |  |  | $ | 3,829 |  |

[0001157523-13-003290:8k_2_02:18]
| Reconciliation of GAAP net income per share, diluted, toNon-GAAP net income per share, diluted(Unaudited) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| GAAP earnings per common share – diluted |  | $ | 0.17 |  | $ | 0.33 |  |  | $ | 0.29 |  | $ | 0.53 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  | 0.05 |  |  |  | 0.02 |  |  | 0.07 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  | 0.03 |  |  |  | 0.06 |  |  | 0.06 |  |
| Gain on bargain purchase of business |  | - |  |  | (0.03 | ) |  | - |  |  | (0.03 | ) |
| Non-GAAP earnings per common share – diluted |  | $ | 0.21 |  | $ | 0.38 |  |  | $ | 0.37 |  | $ | 0.63 |  |

[0001157523-13-003290:8k_2_02:19]
CONTACT:
ADTRAN, Inc.
Jim Matthews, Senior Vice President/CFO,
      256-963-8775
or
Investor Services/Assistance:
Gayle Ellis,
      256-963-8220
