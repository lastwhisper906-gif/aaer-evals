# ADTN notes — 0001193125-13-312256


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-13-312256:notes:1]
| 5. | STOCK-BASED COMPENSATION |

[0001193125-13-312256:notes:2]
The following table
summarizes the stock-based compensation expense related to stock
options, restricted stock units (RSUs) and restricted stock for the
three and six months ended June 30, 2013 and 2012, which was
recognized as follows:

[0001193125-13-312256:notes:3]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 110 |  |  | $ | 97 |  |  | $ | 216 |  |  | $ | 198 |  |
| Selling, general and administrative expense |  |  | 1,042 |  |  |  | 1,047 |  |  |  | 2,105 |  |  |  | 2,098 |  |
| Research and development expense |  |  | 956 |  |  |  | 1,067 |  |  |  | 2,019 |  |  |  | 2,136 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,998 |  |  |  | 2,114 |  |  |  | 4,124 |  |  |  | 4,234 |  |
| Total stock-based compensation expense |  |  | 2,108 |  |  |  | 2,211 |  |  |  | 4,340 |  |  |  | 4,432 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (310 | ) |  |  | (302 | ) |  |  | (617 | ) |  |  | (603 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,798 |  |  | $ | 1,909 |  |  | $ | 3,723 |  |  | $ | 3,829 |  |

[0001193125-13-312256:notes:4]
[same as prior period, unchanged from 0001193125-13-207088:notes:85]

[0001193125-13-312256:notes:5]
There were no options
granted during the three and six months ended June 30, 2013 or
2012.

[0001193125-13-312256:notes:6]
The fair value of our RSUs
is calculated using a Monte Carlo Simulation valuation method.
There were no RSU grants during the three and six months ended
June 30, 2013 or 2012.

[0001193125-13-312256:notes:7]
The fair value of restricted
stock is equal to the closing price of our stock on the date of
grant. There were no restricted stock grants during the three and
six months ended June 30, 2013 or 2012.

[0001193125-13-312256:notes:8]
Stock-based compensation
expense recognized in our Consolidated Statements of Income for the
three and six months ended June 30, 2013 and 2012 is based on
options, RSUs and restricted stock ultimately expected to vest, and
has been reduced for estimated forfeitures. Estimated forfeitures
for stock options were based upon historical experience and
approximate 1.6% annually. We estimated a 0% forfeiture rate for
our RSUs and restricted stock due to the limited number of
recipients and historical experience for these awards.

[0001193125-13-312256:notes:9]
As of June 30, 2013,
total compensation expense related to non-vested stock options,
RSUs and restricted stock not yet recognized was approximately
$14.3 million, which is expected to be recognized over an average
remaining recognition period of 2.2 years.

[0001193125-13-312256:notes:10]
The following table is a
summary of our stock options outstanding as of December 31,
2012 and June 30, 2013 and the changes that occurred during
the six months ended June 30, 2013:

[0001193125-13-312256:notes:11]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2012 |  |  | 6,035 |  |  | $ | 24.81 |  |  |  | 6.69 |  |  | $ | 5,154 |  |
| Options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (112 | ) |  | $ | 26.28 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (45 | ) |  | $ | 18.06 |  |  |  |  |  |  |  |  |  |
| Options outstanding, June 30, 2013 |  |  | 5,878 |  |  | $ | 24.83 |  |  |  | 6.20 |  |  | $ | 15,808 |  |
| Options exercisable, June 30, 2013 |  |  | 3,481 |  |  | $ | 24.88 |  |  |  | 4.70 |  |  | $ | 8,112 |  |

[0001193125-13-312256:notes:12]
The aggregate intrinsic
values in the table above represent the total pre-tax intrinsic
value (the difference between ADTRAN’s closing stock price on
the last trading day of the quarter and the exercise price,
multiplied by the number of in-the-money options) that would have
been received by the option holders had all option holders
exercised their options on June 30, 2013. The aggregate
intrinsic value will change based on the fair market value of
ADTRAN’s stock.

[0001193125-13-312256:notes:13]
The total pre-tax intrinsic
value of options exercised during the three and six month period
ended June 30, 2013 was $0.2 million.

[0001193125-13-312256:notes:14]
The following table is a
summary of our RSUs and restricted stock outstanding as of
December 31, 2012 and June 30, 2013 and the changes that
occurred during the six months ended June 30, 2013:

[0001193125-13-312256:notes:15]
| (In thousands, except per share amounts) |  | Number of Shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2012 |  |  | 103 |  |  | $ | 29.25 |  |
| RSUs and restricted stock granted |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock vested |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  | $ | — |  |
| Unvested RSUs and restricted stock, June 30, 2013 |  |  | 103 |  |  | $ | 29.25 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-13-312256:notes:16]
| 13. | LIABILITY FOR WARRANTY RETURNS |

[0001193125-13-312256:notes:17]
Our products
generally include warranties of 90 days to ten years for product
defects. We accrue for warranty returns at the time revenue is
recognized based on our estimate of the cost to repair or replace
the defective products. We engage in extensive product quality
programs and processes, including actively monitoring and
evaluating the quality of our component suppliers. Our products
continue to become more complex in both size and functionality as
many of our product offerings migrate from line card applications
to systems products. The increasing complexity of our products will
cause warranty incidences, when they arise, to be more costly. Our
estimates regarding future warranty obligations may change due to
product failure rates, material usage, and other rework costs
incurred in correcting a product failure. In addition, from time to
time, specific warranty accruals may be recorded if unforeseen
problems arise. Should our actual experience relative to these
factors be worse than our estimates, we will be required to record
additional warranty expense. Alternatively, if we provide for more
reserves than we require, we will reverse a portion of such
provisions in future periods. The liability for warranty
obligations totaled $7.9 million at June 30, 2013 and $9.7
million at December 31, 2012. These liabilities are included
in accrued expenses in the accompanying Consolidated Balance
Sheets.

[0001193125-13-312256:notes:18]
A summary of
warranty expense and write-off activity for the six months ended
June 30, 2013 and 2012 is as follows:

[0001193125-13-312256:notes:19]
| Six Months Ended June 30, |  | 2013 |  |  | 2012 |  |
| (In thousands) |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 9,653 |  |  | $ | 4,118 |  |
| Plus: |  | Amounts charged to cost and expenses |  |  | 470 |  |  |  | 3,313 |  |
|  |  | Amounts assumed on acquisition |  |  | — |  |  |  | 1,932 |  |
| Less: |  | Deductions |  |  | (2,182 | ) |  |  | (2,137 | ) |
| Balance at end of period |  | $ | 7,941 |  |  | $ | 7,226 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-13-312256:notes:20]
Recent
Accounting Pronouncements

[0001193125-13-312256:notes:21]
During the
six months ended June 30, 2013, we adopted the following
accounting standard, which had no material effect on our
consolidated results of operations or financial
condition:

[0001193125-13-312256:notes:22]
In February
2013, the FASB issued Accounting Standards Update No. 2013-02,
Reporting of Amounts Reclassified Out of Accumulated Other
Comprehensive Income (ASU 2013-02). ASU 2013-02 requires entities
to provide information about the amounts reclassified out of
accumulated other comprehensive income by component either on the
face of the financial statements or in the footnotes. ASU 2013-02
does not change the current requirements for reporting net income
or other comprehensive income in the financial statements. This
update is effective prospectively for reporting periods beginning
after December 15, 2012. We adopted this amendment during the
first quarter of 2013, and we have provided the disclosures
required for the periods ended June 30, 2013 and 2012 in Note
10 of Notes to Consolidated Financial Statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-13-312256:notes:23]
| 12. | SEGMENT INFORMATION |

[0001193125-13-312256:notes:24]
We operate in
two reportable segments: (1) the Carrier Networks Division and
(2) the Enterprise Networks Division. We evaluate the
performance of our segments based on gross profit; therefore,
selling, general and administrative expense, research and
development expenses, interest income and dividend income, interest
expense, net realized investment gain/loss, other income/expense
and provision for taxes are reported on an entity-wide basis only.
There are no inter-segment revenues.

[0001193125-13-312256:notes:25]
The following
table presents information about the reported sales and gross
profit of our reportable segments for the three and six months
ended June 30, 2013 and 2012. Asset information by reportable
segment is not reported, since we do not produce such information
internally.

[0001193125-13-312256:notes:26]
|  |  | Three Months Ended |  |
|  |  | June 30, 2013 |  |  | June 30, 2012 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 123,333 |  |  | $ | 57,913 |  |  | $ | 152,707 |  |  | $ | 78,738 |  |
| Enterprise Networks |  |  | 38,900 |  |  |  | 21,885 |  |  |  | 31,291 |  |  |  | 16,463 |  |
| Total |  | $ | 162,233 |  |  | $ | 79,798 |  |  | $ | 183,998 |  |  | $ | 95,201 |  |

[0001193125-13-312256:notes:27]
|  |  | Six Months Ended |  |
|  |  | June 30, 2013 |  |  | June 30, 2012 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 233,220 |  |  | $ | 109,504 |  |  | $ | 249,361 |  |  | $ | 131,621 |  |
| Enterprise Networks |  |  | 72,026 |  |  |  | 39,971 |  |  |  | 69,372 |  |  |  | 37,667 |  |
| Total |  | $ | 305,246 |  |  | $ | 149,475 |  |  | $ | 318,733 |  |  | $ | 169,288 |  |

[0001193125-13-312256:notes:28]
[same as prior period, unchanged from 0001193125-13-207088:notes:104]

[0001193125-13-312256:notes:29]
Our three
major product categories are Carrier Systems, Business Networking
and Loop Access.

[0001193125-13-312256:notes:30]
Carrier
Systems products are used by
communications service providers to provide data, voice and video
services to consumers and enterprises. This category includes the
following product areas and related services:

[0001193125-13-312256:notes:31]
[same as prior period, unchanged from 0001193125-13-207088:notes:107]

[0001193125-13-312256:notes:32]
[same as prior period, unchanged from 0001193125-13-207088:notes:108]

[0001193125-13-312256:notes:33]
[same as prior period, unchanged from 0001193125-13-207088:notes:109]

[0001193125-13-312256:notes:34]
[same as prior period, unchanged from 0001193125-13-207088:notes:110]

[0001193125-13-312256:notes:35]
[same as prior period, unchanged from 0001193125-13-207088:notes:111]

[0001193125-13-312256:notes:36]
[same as prior period, unchanged from 0001193125-13-207088:notes:112]

[0001193125-13-312256:notes:37]
[same as prior period, unchanged from 0001193125-13-207088:notes:113]

[0001193125-13-312256:notes:38]
[same as prior period, unchanged from 0001193125-13-207088:notes:114]

[0001193125-13-312256:notes:39]
[same as prior period, unchanged from 0001193125-13-207088:notes:115]

[0001193125-13-312256:notes:40]
[same as prior period, unchanged from 0001193125-13-207088:notes:116]

[0001193125-13-312256:notes:41]
[same as prior period, unchanged from 0001193125-13-207088:notes:117]

[0001193125-13-312256:notes:42]
[same as prior period, unchanged from 0001193125-13-207088:notes:118]

[0001193125-13-312256:notes:43]
[same as prior period, unchanged from 0001193125-13-207088:notes:119]

[0001193125-13-312256:notes:44]
Business
Networking products provide access to
telecommunication services and facilitate the delivery of cloud
connectivity, enterprise communications and virtual mobility to the
small and mid-sized enterprise (SME) market. This category includes
the following product areas and related services:

[0001193125-13-312256:notes:45]
[same as prior period, unchanged from 0001193125-13-207088:notes:121]

[0001193125-13-312256:notes:46]
[same as prior period, unchanged from 0001193125-13-207088:notes:122]

[0001193125-13-312256:notes:47]
[same as prior period, unchanged from 0001193125-13-207088:notes:123]

[0001193125-13-312256:notes:48]
[same as prior period, unchanged from 0001193125-13-207088:notes:124]

[0001193125-13-312256:notes:49]
[same as prior period, unchanged from 0001193125-13-207088:notes:125]

[0001193125-13-312256:notes:50]
[same as prior period, unchanged from 0001193125-13-207088:notes:126]

[0001193125-13-312256:notes:51]
[same as prior period, unchanged from 0001193125-13-207088:notes:127]

[0001193125-13-312256:notes:52]
[same as prior period, unchanged from 0001193125-13-207088:notes:128]

[0001193125-13-312256:notes:53]
[same as prior period, unchanged from 0001193125-13-207088:notes:129]

[0001193125-13-312256:notes:54]
[same as prior period, unchanged from 0001193125-13-207088:notes:130]

[0001193125-13-312256:notes:55]
[same as prior period, unchanged from 0001193125-13-207088:notes:131]

[0001193125-13-312256:notes:56]
Loop
Access products
are used by carrier and enterprise customers for access to
copper-based telecommunications networks. The Loop Access category
includes the following product areas:

[0001193125-13-312256:notes:57]
[same as prior period, unchanged from 0001193125-13-207088:notes:133]

[0001193125-13-312256:notes:58]
[same as prior period, unchanged from 0001193125-13-207088:notes:134]

[0001193125-13-312256:notes:59]
[same as prior period, unchanged from 0001193125-13-207088:notes:135]

[0001193125-13-312256:notes:60]
[same as prior period, unchanged from 0001193125-13-207088:notes:136]

[0001193125-13-312256:notes:61]
[same as prior period, unchanged from 0001193125-13-207088:notes:137]

[0001193125-13-312256:notes:62]
The table
below presents sales information by product category for the three
and six months ended June 30, 2013 and 2012:

[0001193125-13-312256:notes:63]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Carrier Systems |  | $ | 105,537 |  |  | $ | 126,755 |  |  | $ | 198,341 |  |  | $ | 198,013 |  |
| Business Networking |  |  | 45,379 |  |  |  | 36,590 |  |  |  | 83,455 |  |  |  | 79,732 |  |
| Loop Access |  |  | 11,317 |  |  |  | 20,653 |  |  |  | 23,450 |  |  |  | 40,988 |  |
| Total |  | $ | 162,233 |  |  | $ | 183,998 |  |  | $ | 305,246 |  |  | $ | 318,733 |  |

[0001193125-13-312256:notes:64]
In addition,
we identify subcategories of product revenues, which we divide into
our core products and legacy products. Our core products consist of
Broadband Access and Optical products (included in Carrier Systems)
and Internetworking products (included in Business Networking). Our
legacy products include HDSL products (included in Loop Access) and
other products not included in the aforementioned core
products.

[0001193125-13-312256:notes:65]
The table
below presents subcategory revenues for the three and six months
ended June 30, 2013 and 2012:

[0001193125-13-312256:notes:66]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 81,628 |  |  | $ | 106,042 |  |  | $ | 153,862 |  |  | $ | 155,524 |  |
| Optical (included in Carrier Systems) |  |  | 15,986 |  |  |  | 14,003 |  |  |  | 24,860 |  |  |  | 28,258 |  |
| Internetworking (included in Business Networking) |  |  | 43,922 |  |  |  | 34,935 |  |  |  | 80,834 |  |  |  | 75,909 |  |
| Subtotal |  |  | 141,536 |  |  |  | 154,980 |  |  |  | 259,556 |  |  |  | 259,691 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 10,289 |  |  |  | 19,465 |  |  |  | 21,696 |  |  |  | 38,424 |  |
| Other products (excluding HDSL) |  |  | 10,408 |  |  |  | 9,553 |  |  |  | 23,994 |  |  |  | 20,618 |  |
| Subtotal |  |  | 20,697 |  |  |  | 29,018 |  |  |  | 45,690 |  |  |  | 59,042 |  |
| Total |  | $ | 162,233 |  |  | $ | 183,998 |  |  | $ | 305,246 |  |  | $ | 318,733 |  |

[0001193125-13-312256:notes:67]
The following
table presents sales information by geographic area for the three
and six months ended June 30, 2013 and 2012. International
sales correlate to shipments with a non-U.S.
destination.

[0001193125-13-312256:notes:68]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (In thousands) |  | June 30, |  |  | June 30, |  |
|  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| United States |  | $ | 127,487 |  |  | $ | 130,389 |  |  | $ | 235,593 |  |  | $ | 246,832 |  |
| International |  |  | 34,746 |  |  |  | 53,609 |  |  |  | 69,653 |  |  |  | 71,901 |  |
| Total |  | $ | 162,233 |  |  | $ | 183,998 |  |  | $ | 305,246 |  |  | $ | 318,733 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-13-312256:notes:69]
| 15. | COMMITMENTS AND CONTINGENCIES |

[0001193125-13-312256:notes:70]
In the ordinary course of
business, we may be subject to various legal proceedings and
claims, including employment disputes, patent claims, disputes over
contract agreements and other commercial disputes. In some cases,
claimants seek damages or other relief, such as royalty payments
related to patents, which, if granted, could require significant
expenditures. Although the outcome of any claim or litigation can
never be certain, it is our opinion that the outcome of all
contingencies of which we are currently aware will not materially
affect our business, operations, financial condition or cash
flows.

[0001193125-13-312256:notes:71]
We have committed to invest
up to an aggregate of $7.9 million in two private equity funds, and
we have contributed $8.4 million as of June 30, 2013, of which
$7.7 million has been applied to these commitments.


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-13-312256:notes:72]
The fair values of our
derivative instruments recorded in the Consolidated Balance Sheet
as of June 30, 2013 were as follows:

[0001193125-13-312256:notes:73]
|  |  | June 30, 2013 |  |
| (In thousands) |  | Balance Sheet Location |  | Fair Value |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 101 |  |
| Foreign exchange contracts – liability derivatives |  | Accounts payable |  | $ | (115 | ) |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-13-312256:notes:74]
The following
tables present changes in accumulated other comprehensive income,
net of tax, by component for the three months ended June 30,
2013 and 2012:

[0001193125-13-312256:notes:75]
|  |  | Three Months Ended June 30, 2013 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 8,464 |  |  | $ | (1,952 | ) |  | $ | 3,435 |  |  | $ | 9,947 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (802 | ) |  |  | — |  |  |  | (1,713 | ) |  |  | (2,515 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (896 | ) |  |  | — |  |  |  | — |  |  |  | (896 | ) |
| Net current period other comprehensive (loss) |  |  | (1,698 | ) |  |  | — |  |  |  | (1,713 | ) |  |  | (3,411 | ) |
| Ending balance |  | $ | 6,766 |  |  | $ | (1,952 | ) |  | $ | 1,722 |  |  | $ | 6,536 |  |

[0001193125-13-312256:notes:76]
|  |  | Three Months Ended June 30, 2012 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 16,917 |  |  | $ | 3,096 |  |  | $ | 20,013 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (3,880 | ) |  |  | (96 | ) |  |  | (3,976 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,355 | ) |  |  | — |  |  |  | (1,355 | ) |
| Net current period other comprehensive (loss) |  |  | (5,235 | ) |  |  | (96 | ) |  |  | (5,331 | ) |
| Ending balance |  | $ | 11,682 |  |  | $ | 3,000 |  |  | $ | 14,682 |  |

[0001193125-13-312256:notes:77]
The following
tables present changes in accumulated other comprehensive income,
net of tax, by component for the six months ended June 30,
2013 and 2012:

[0001193125-13-312256:notes:78]
|  |  | Six Months Ended June 30, 2013 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,108 |  |  | $ | (1,952 | ) |  | $ | 3,112 |  |  | $ | 11,268 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (348 | ) |  |  | — |  |  |  | (1,390 | ) |  |  | (1,738 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,994 | ) |  |  | — |  |  |  | — |  |  |  | (2,994 | ) |
| Net current period other comprehensive (loss) |  |  | (3,342 | ) |  |  | — |  |  |  | (1,390 | ) |  |  | (4,732 | ) |
| Ending balance |  | $ | 6,766 |  |  | $ | (1,952 | ) |  | $ | 1,722 |  |  | $ | 6,536 |  |

[0001193125-13-312256:notes:79]
|  |  | Six Months Ended June 30, 2012 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,160 |  |  | $ | 2,942 |  |  | $ | 13,102 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 4,325 |  |  |  | 58 |  |  |  | 4,383 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,803 | ) |  |  | — |  |  |  | (2,803 | ) |
| Net current period other comprehensive income |  |  | 1,522 |  |  |  | 58 |  |  |  | 1,580 |  |
| Ending balance |  | $ | 11,682 |  |  | $ | 3,000 |  |  | $ | 14,682 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-13-312256:notes:80]
As of June 30, 2013,
the estimated future amortization expense of our intangible assets
is as follows:

[0001193125-13-312256:notes:81]
| (In thousands) |  | Amount |  |
| Remainder of 2013 |  | $ | 1,211 |  |
| 2014 |  |  | 2,268 |  |
| 2015 |  |  | 2,133 |  |
| 2016 |  |  | 1,861 |  |
| 2017 |  |  | 1,265 |  |
| Thereafter |  |  | 2,676 |  |
| Total |  | $ | 11,414 |  |


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0001193125-13-312256:notes:82]
The
allocation of the purchase price to the estimated fair value of the
assets acquired and liabilities assumed at the acquisition date is
as follows:

[0001193125-13-312256:notes:83]
| (In Thousands) |  |  |  |
| Other receivables |  | $ | 9,486 |  |
| Inventory |  |  | 21,068 |  |
| Property, plant and equipment |  |  | 5,035 |  |
| Accounts payable |  |  | (5,194 | ) |
| Unearned revenue |  |  | (18,203 | ) |
| Accrued expenses |  |  | (1,931 | ) |
| Accrued wages and benefits |  |  | (2,251 | ) |
| Deferred tax liability |  |  | (788 | ) |
| Non-current unearned revenue |  |  | (21,316 | ) |
| Net liabilities assumed |  |  | (14,094 | ) |
| Customer relationships |  |  | 5,162 |  |
| Developed technology |  |  | 3,176 |  |
| Other |  |  | 13 |  |
| Gain on bargain purchase of a business, net of tax |  |  | (1,753 | ) |
| Net consideration received from seller |  | $ | (7,496 | ) |


## us-gaap:ScheduleOfCostsOfRetirementPlansTableTextBlock

[0001193125-13-312256:notes:84]
The following
table summarizes the components of net periodic pension cost for
the three and six months ended June 30, 2013 and the period
May 4, 2012 to June 30, 2012:

[0001193125-13-312256:notes:85]
|  |  | Three Months Ended |  |  | May 4, 2012 to |  |  | Six Months Ended |  |
| (In thousands) |  | June 30, 2013 |  |  | June 30, 2012 |  |  | June 30, 2013 |  |
| Service cost |  | $ | 294 |  |  | $ | 190 |  |  | $ | 594 |  |
| Interest cost |  |  | 182 |  |  |  | 127 |  |  |  | 369 |  |
| Expected return on plan assets |  |  | (248 | ) |  |  | (165 | ) |  |  | (501 | ) |
| Net periodic pension cost |  | $ | 228 |  |  | $ | 152 |  |  | $ | 462 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-13-312256:notes:86]
We have categorized our
cash equivalents held in money market funds and our investments
held at fair value into a three-level fair value hierarchy based on
the priority of the inputs to the valuation technique for the cash
equivalents and investments as follows: Level 1 – Values
based on unadjusted, quoted prices in active markets for identical
assets or liabilities; Level 2 – Values based on inputs other
than quoted prices included within Level 1 that are directly or
indirectly observable for the asset or liability; Level 3 –
Values based on unobservable inputs for the asset or liability.
These inputs include information supplied by investees.

[0001193125-13-312256:notes:87]
|  |  | Fair Value Measurements at June 30, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,339 |  |  | $ | 1,339 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,792 |  |  |  | 12,792 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 187,930 |  |  |  | — |  |  |  | 187,930 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 155,481 |  |  |  | — |  |  |  | 155,481 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 7,120 |  |  |  | — |  |  |  | 7,120 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 7,818 |  |  |  | 7,818 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 24,032 |  |  |  | 24,032 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 395,173 |  |  |  | 44,642 |  |  |  | 350,531 |  |  |  | — |  |
| Total |  | $ | 396,512 |  |  | $ | 45,981 |  |  | $ | 350,531 |  |  | $ | — |  |
|  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 28,071 |  |  | $ | 28,071 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,527 |  |  |  | 11,527 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 186,412 |  |  |  | — |  |  |  | 186,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 175,084 |  |  |  | — |  |  |  | 175,084 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | 34,375 |  |  |  | — |  |
| Fixed income bond fund |  |  | 456 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 21,105 |  |  |  | 21,105 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 443,058 |  |  |  | 47,187 |  |  |  | 395,871 |  |  |  | — |  |
| Total |  | $ | 471,129 |  |  | $ | 75,258 |  |  | $ | 395,871 |  |  | $ | — |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-13-312256:notes:88]
A summary of
the changes in stockholders’ equity for the six months ended
June 30, 2013 is as follows:

[0001193125-13-312256:notes:89]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2012 |  | $ | 692,406 |  |
| Net income |  |  | 17,749 |  |
| Dividend payments |  |  | (10,982 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (19 | ) |
| Net unrealized gains (losses) on available-for-sale securities (net of tax) |  |  | (3,342 | ) |
| Foreign currency translation adjustment |  |  | (1,390 | ) |
| Proceeds from stock option exercises |  |  | 819 |  |
| Purchase of treasury stock |  |  | (89,917 | ) |
| Income tax benefit from exercise of stock options |  |  | 21 |  |
| Stock-based compensation expense |  |  | 4,340 |  |
| Balance, June 30, 2013 |  | $ | 609,685 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-13-312256:notes:90]
[same as prior period, unchanged from 0001193125-13-207088:notes:29]

[0001193125-13-312256:notes:91]
[same as prior period, unchanged from 0001193125-13-207088:notes:30]

[0001193125-13-312256:notes:92]
[same as prior period, unchanged from 0001193125-13-207088:notes:31]


## us-gaap:InventoryDisclosureTextBlock

[0001193125-13-312256:notes:93]
| 8. | INVENTORY |

[0001193125-13-312256:notes:94]
At
June 30, 2013 and December 31, 2012, inventory consisted
of the following:

[0001193125-13-312256:notes:95]
| (In thousands) |  | June 30, 2013 |  |  | December 31, 2012 |  |
| Raw materials |  | $ | 40,696 |  |  | $ | 47,054 |  |
| Work in process |  |  | 5,503 |  |  |  | 3,262 |  |
| Finished goods |  |  | 41,574 |  |  |  | 52,267 |  |
| Total |  | $ | 87,773 |  |  | $ | 102,583 |  |

[0001193125-13-312256:notes:96]
We establish
reserves for estimated excess, obsolete, or unmarketable inventory
equal to the difference between the cost of the inventory and the
estimated fair value of the inventory based upon assumptions about
future demand and market conditions. At June 30, 2013 and
December 31, 2012, raw materials reserves totaled $14.9
million and $9.9 million, respectively, and finished goods
inventory reserves totaled $3.7 million and $2.1 million,
respectively.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-13-312256:notes:97]
A summary of
the calculation of basic and diluted earnings per share for the
three and six months ended June 30, 2013 and 2012 is as
follows:

[0001193125-13-312256:notes:98]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 9,859 |  |  | $ | 21,070 |  |  | $ | 17,749 |  |  | $ | 34,031 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 59,056 |  |  |  | 63,619 |  |  |  | 60,443 |  |  |  | 63,720 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 209 |  |  |  | 720 |  |  |  | 177 |  |  |  | 865 |  |
| Restricted stock and restricted stock units |  |  | 46 |  |  |  | 54 |  |  |  | 40 |  |  |  | 43 |  |
| Weighted average number of shares – diluted |  |  | 59,311 |  |  |  | 64,393 |  |  |  | 60,660 |  |  |  | 64,628 |  |
| Net income per share – basic |  | $ | 0.17 |  |  | $ | 0.33 |  |  | $ | 0.29 |  |  | $ | 0.53 |  |
| Net income per share – diluted |  | $ | 0.17 |  |  | $ | 0.33 |  |  | $ | 0.29 |  |  | $ | 0.53 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-13-312256:notes:99]
| 10. | STOCKHOLDERS’ EQUITY |

[0001193125-13-312256:notes:100]
Stock
Repurchase Program

[0001193125-13-312256:notes:101]
Since 1997,
our Board of Directors has approved multiple share repurchase
programs that have authorized open market repurchase transactions
of up to 35 million shares of our common stock. On May 1,
2013, our Board of Directors authorized the repurchase of an
additional 5.0 million shares of our common stock, which
commenced upon completion of the repurchase plan announced on
October 11, 2011. This new authorization is being implemented
through open market or private purchases from time to time as
conditions warrant.

[0001193125-13-312256:notes:102]
During the
six months ended June 30, 2013, we repurchased
4.2 million shares of our common stock at an average price of
$21.49 per share. We currently have the authority to purchase an
additional 4.9 million shares of our common stock under the
current plan approved by the Board of Directors.

[0001193125-13-312256:notes:103]
Stock
Option Exercises

[0001193125-13-312256:notes:104]
We issued
45 thousand shares of treasury stock during the six months
ended June 30, 2013 to accommodate employee stock option
exercises. The stock options had exercise prices ranging from
$15.29 to $23.46. We received proceeds totaling $0.8 million from
the exercise of these stock options during the six months ended
June 30, 2013.

[0001193125-13-312256:notes:105]
[same as prior period, unchanged from 0001193125-13-207088:notes:41]

[0001193125-13-312256:notes:106]
During the
six months ended June 30, 2013, we paid cash dividends as
follows (in thousands except per share amount):

[0001193125-13-312256:notes:107]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 7, 2013 |  | February 21, 2013 |  | $ | 0.09 |  |  | $ | 5,586 |  |
| April 25, 2013 |  | May 9, 2013 |  | $ | 0.09 |  |  | $ | 5,396 |  |

[0001193125-13-312256:notes:108]
Other
Comprehensive Income

[0001193125-13-312256:notes:109]
Other
comprehensive income consists of unrealized gains (losses) on
available-for-sale securities, reclassification adjustments for
amounts included in net income related to impairments of
available-for-sale securities and realized gains (losses) on
available-for-sale securities, defined benefit plan adjustments and
foreign currency translation adjustments.

[0001193125-13-312256:notes:110]
The following
tables present the details of reclassifications out of accumulated
other comprehensive income for the three months ended June 30,
2013 and 2012:

[0001193125-13-312256:notes:111]
| (In thousands) |  | Three Months Ended June 30, 2013 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities, before tax |  | $ | 1,469 |  |  | Net realized investment gain |
| Tax (expense) benefit |  |  | (573 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 896 |  |  |  |

[0001193125-13-312256:notes:112]
| (In thousands) |  | Three Months Ended June 30, 2012 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities, before tax |  | $ | 2,222 |  |  | Net realized investment gain |
| Tax (expense) benefit |  |  | (867 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,355 |  |  |  |

[0001193125-13-312256:notes:113]
The following
tables present the details of reclassifications out of accumulated
other comprehensive income for the six months ended June 30,
2013 and 2012:

[0001193125-13-312256:notes:114]
| (In thousands) |  | Six Months Ended June 30, 2013 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 4,913 |  |  | Net realized investment gain |
| Impairment expense |  |  | (4 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 4,909 |  |  |  |
| Tax (expense) benefit |  |  | (1,915 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,994 |  |  |  |

[0001193125-13-312256:notes:115]
| (In thousands) |  | Six Months Ended June 30, 2012 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 4,628 |  |  | Net realized investment gain |
| Impairment expense |  |  | (33 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 4,595 |  |  |  |
| Tax (expense) benefit |  |  | (1,792 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,803 |  |  |  |

[0001193125-13-312256:notes:116]
The following
table presents the tax effects related to the change in each
component of other comprehensive income for the three months ended
June 30, 2013 and 2012:

[0001193125-13-312256:notes:117]
|  |  | Three Months Ended June 30, 2013 |  |  | Three Months Ended June 30, 2012 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (1,315 | ) |  | $ | 513 |  |  | $ | (802 | ) |  | $ | (6,361 | ) |  | $ | 2,481 |  |  | $ | (3,880 | ) |
| Reclassification adjustment for amounts included in net income |  |  | (1,469 | ) |  |  | 573 |  |  |  | (896 | ) |  |  | (2,222 | ) |  |  | 867 |  |  |  | (1,355 | ) |
| Foreign currency translation adjustment |  |  | (1,713 | ) |  |  | — |  |  |  | (1,713 | ) |  |  | (96 | ) |  |  | — |  |  |  | (96 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (4,497 | ) |  | $ | 1,086 |  |  | $ | (3,411 | ) |  | $ | (8,679 | ) |  | $ | 3,348 |  |  | $ | (5,331 | ) |

[0001193125-13-312256:notes:118]
The following
table presents the tax effects related to the change in each
component of other comprehensive income for the six months ended
June 30, 2013 and 2012:

[0001193125-13-312256:notes:119]
|  |  | Six Months Ended June 30, 2013 |  |  | Six Months Ended June 30, 2012 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (571 | ) |  | $ | 223 |  |  | $ | (348 | ) |  | $ | 7,088 |  |  | $ | (2,763 | ) |  | $ | 4,325 |  |
| Reclassification adjustment for amounts included in net income |  |  | (4,909 | ) |  |  | 1,915 |  |  |  | (2,994 | ) |  |  | (4,595 | ) |  |  | 1,792 |  |  |  | (2,803 | ) |
| Foreign currency translation adjustment |  |  | (1,390 | ) |  |  | — |  |  |  | (1,390 | ) |  |  | 58 |  |  |  | — |  |  |  | 58 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (6,870 | ) |  | $ | 2,138 |  |  | $ | (4,732 | ) |  | $ | 2,551 |  |  | $ | (971 | ) |  | $ | 1,580 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-13-312256:notes:120]
At June 30, 2013 and
December 31, 2012, inventory consisted of the
following:

[0001193125-13-312256:notes:121]
|  |  | June 30, |  |  | December 31, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Raw materials |  | $ | 40,696 |  |  | $ | 47,054 |  |
| Work in process |  |  | 5,503 |  |  |  | 3,262 |  |
| Finished goods |  |  | 41,574 |  |  |  | 52,267 |  |
| Total |  | $ | 87,773 |  |  | $ | 102,583 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-13-312256:notes:122]
As of June 30, 2013,
our corporate bonds and municipal fixed-rate bonds had the
following contractual maturities:

[0001193125-13-312256:notes:123]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 76,233 |  |  | $ | 67,918 |  |
| One to two years |  |  | 42,747 |  |  |  | 14,143 |  |
| Two to three years |  |  | 65,785 |  |  |  | 50,355 |  |
| Three to five years |  |  | 3,165 |  |  |  | 23,065 |  |
| Total |  | $ | 187,930 |  |  | $ | 155,481 |  |


## us-gaap:ScheduleOfRealizedGainLossTableTextBlock

[0001193125-13-312256:notes:124]
[same as prior period, unchanged from 0001193125-13-207088:notes:57]

[0001193125-13-312256:notes:125]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 1,728 |  |  | $ | 2,631 |  |  | $ | 5,455 |  |  | $ | 5,300 |  |
| Gross realized losses |  | $ | (175 | ) |  | $ | (275 | ) |  | $ | (257 | ) |  | $ | (477 | ) |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-13-312256:notes:126]
| 7. | DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES |

[0001193125-13-312256:notes:127]
We have
certain international customers who are billed in their local
currency. Changes in the monetary exchange rates may adversely
affect our results of operations and financial condition. When
appropriate, we enter into various derivative transactions to
enhance our ability to manage the volatility relating to these
typical business exposures. We do not hold or issue derivative
instruments for trading or other speculative purposes. Our
derivative instruments are recorded in the Consolidated Balance
Sheets at their fair values. Our derivative instruments do not
qualify for hedge accounting, and accordingly, all changes in the
fair value of the instruments are recognized as other income
(expense) in the Consolidated Statements of Income. The maximum
time frame for our derivatives is currently less than twelve
months. Our derivative instruments are not subject to master
netting arrangements and are not offset in the Consolidated Balance
Sheets.

[0001193125-13-312256:notes:128]
As of
June 30, 2013, we had forward contracts and swaps outstanding
with notional amounts totaling €20.7 million ($26.9
million) and €0.3 million ($0.4 million), respectively,
which mature through 2013.

[0001193125-13-312256:notes:129]
The fair
values of our derivative instruments recorded in the Consolidated
Balance Sheet as of June 30, 2013 were as follows:

[0001193125-13-312256:notes:130]
The change in
the fair values of our derivative instruments recorded in the
Consolidated Statements of Income during the three and six months
ended June 30, 2013 were as follows:

[0001193125-13-312256:notes:131]
|  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
| (In thousands) |  | Income Statement Location |  | June 30, 2013 |  |  | June 30, 2013 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | 138 |  |  | $ | (86 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-13-312256:notes:132]
| 2. | BUSINESS COMBINATIONS |

[0001193125-13-312256:notes:133]
On
May 4, 2012, we acquired the Nokia Siemens Networks Broadband
Access business (NSN BBA business). This acquisition provides us
with an established customer base in key markets and complementary,
market-focused products and was accounted for as a business
combination. We have included the financial results of the NSN BBA
business in our consolidated financial statements since the date of
acquisition. These revenues are included in the Carrier Networks
division in the Broadband Access subcategory.

[0001193125-13-312256:notes:134]
We received a
cash payment of $7.5 million from NSN and recorded a bargain
purchase gain of $1.8 million, net of income taxes, in the second
quarter of 2012, subject to customary working capital adjustments
between the parties as defined in the purchase agreement. As of
June 30, 2013, the parties were in the process of resolving
the working capital adjustments. We adjusted the purchase price
allocation during the fourth quarter of 2012 to record additional
estimated liabilities and an estimated receivable from NSN related
to working capital adjustments under negotiation. The bargain
purchase gain of $1.8 million represents the excess of the
consideration exchanged over the fair value of the assets acquired
and liabilities assumed. We have assessed the recognition and
measurements of the assets acquired and liabilities assumed based
on historical and pro forma data for future periods and have
concluded that our valuation procedures and resulting measures were
appropriate.

[0001193125-13-312256:notes:135]
The fair
value of the customer relationships acquired was calculated using a
discounted cash flow method (excess earnings) and is being
amortized using a declining balance method derived from projected
customer revenue over an average estimated useful life of 13 years.
The fair value of the developed technology acquired was calculated
using a discounted cash flow method (relief from royalty) and is
being amortized using the straight-line method over an estimated
useful life of five years.

[0001193125-13-312256:notes:136]
The following
supplemental pro forma information presents the financial results
of the acquired NSN BBA business for the three and six months ended
June 30, 2012. The pro forma results for the period
January 1, 2012 to May 4, 2012 are not included in our
consolidated financial statements.

[0001193125-13-312256:notes:137]
This
supplemental pro forma information does not purport to be
indicative of what would have occurred had the acquisition of the
NSN BBA business been completed on January 1, 2012, nor are
they indicative of any future results.

[0001193125-13-312256:notes:138]
|  |  | Three Months Ended |  | Six Months Ended |
| (In thousands) |  | June 30, 2012 |  | June 30, 2012 |
| Pro forma revenue |  | $40,164 |  | $74,070 |
| Pro forma pre-tax loss |  | $(3,813) |  | $(15,458) |
| Weighted average exchange rate during the period (EURO/USD) |  | €1.00/$1.29 |  | €1.00/$1.30 |

[0001193125-13-312256:notes:139]
For the three
and six months ended June 30, 2013, we incurred acquisition
and integration related expenses and amortization of acquired
intangibles of $0.7 and $1.6 million related to this
acquisition.


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-13-312256:notes:140]
The change in the carrying
value of goodwill, all of which is included in our Enterprise
Networks division, for the six months ended June 30, 2013 is
as follows:

[0001193125-13-312256:notes:141]
| (In thousands) |  |  |  |
| Balance, December 31, 2012 |  | $ | 3,492 |  |
| Acquisitions |  |  | — |  |
| Impairment losses |  |  | — |  |
| Balance, June 30, 2013 |  | $ | 3,492 |  |
| Balance as of June 30, 2013 |  |  |  |  |
| Goodwill |  | $ | 3,492 |  |
| Accumulated impairment losses |  |  | — |  |
| Total goodwill |  | $ | 3,492 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-13-312256:notes:142]
| 16. | SUBSEQUENT EVENTS |

[0001193125-13-312256:notes:143]
On
July 9, 2013, we announced that our Board of Directors
declared a quarterly cash dividend of $0.09 per common share to be
paid to stockholders of record at the close of business on
July 25, 2013. The payment date will be August 8, 2013.
The quarterly dividend payment will be approximately $5.2 million.
In July 2003, our Board of Directors elected to begin declaring
quarterly dividends on our common stock considering the tax
treatment of dividends and adequate levels of Company
liquidity.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-13-312256:notes:144]
| 3. | INCOME TAXES |

[0001193125-13-312256:notes:145]
Our effective
tax rate decreased from 35.6% in the six months ended June 30,
2012 to 33.2% in the six months ended June 30, 2013. The
decrease in the effective tax rate between the two periods is
primarily attributable to the net effect of recording the benefit
for the research tax credit for the 2012 tax year in January 2013
pursuant to the American Taxpayer Relief Act of 2012, the inclusion
of the benefit of the estimated 2013 research tax credit in the
estimated annual effective rate for 2013, and foreign subsidiary
losses for which no tax benefits are recorded.


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-13-312256:notes:146]
At June 30, 2013, we
held the following securities and investments, recorded at either
fair value or cost.

[0001193125-13-312256:notes:147]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,819 |  |  | $ | 1,983 |  |  | $ | (10 | ) |  | $ | 12,792 |  |
| Corporate bonds |  |  | 187,723 |  |  |  | 446 |  |  |  | (239 | ) |  |  | 187,930 |  |
| Municipal fixed-rate bonds |  |  | 155,451 |  |  |  | 319 |  |  |  | (289 | ) |  |  | 155,481 |  |
| Municipal variable rate demand notes |  |  | 7,120 |  |  |  | — |  |  |  | — |  |  |  | 7,120 |  |
| Marketable equity securities |  |  | 22,656 |  |  |  | 9,620 |  |  |  | (426 | ) |  |  | 31,850 |  |
| Available-for-sale securities held at fair value |  | $ | 383,769 |  |  | $ | 12,368 |  |  | $ | (964 | ) |  | $ | 395,173 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,818 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 445,241 |  |

[0001193125-13-312256:notes:148]
[same as prior period, unchanged from 0001193125-13-207088:notes:15]

[0001193125-13-312256:notes:149]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,688 |  |  | $ | 846 |  |  | $ | (7 | ) |  | $ | 11,527 |  |
| Corporate bonds |  |  | 185,464 |  |  |  | 966 |  |  |  | (18 | ) |  |  | 186,412 |  |
| Municipal fixed-rate bonds |  |  | 174,530 |  |  |  | 627 |  |  |  | (73 | ) |  |  | 175,084 |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | — |  |  |  | 34,375 |  |
| Fixed income bond fund |  |  | 444 |  |  |  | 12 |  |  |  | — |  |  |  | 456 |  |
| Marketable equity securities |  |  | 20,966 |  |  |  | 14,630 |  |  |  | (392 | ) |  |  | 35,204 |  |
| Available-for-sale securities held at fair value |  | $ | 426,467 |  |  | $ | 17,081 |  |  | $ | (490 | ) |  | $ | 443,058 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,902 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 493,210 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-13-312256:notes:150]
| 4. | PENSION BENEFIT PLAN |

[0001193125-13-312256:notes:151]
As a result
of our acquisition of the NSN BBA business, we assumed a defined
benefit obligation of $17.0 million as of May 4, 2012. We
established a Contribution Trust Arrangement (CTA) to hold the
pension assets, and NSN transferred assets to us equal to the
defined benefit obligation.


## us-gaap:EarningsPerShareTextBlock

[0001193125-13-312256:notes:152]
| 11. | EARNINGS PER SHARE |

[0001193125-13-312256:notes:153]
Anti-dilutive
options to purchase common stock outstanding were excluded from the
above calculations. Anti-dilutive options totaled
4.3 million and 2.5 million for the three months ended
June 30, 2013 and 2012, respectively, and 5.1 million and
2.1 million for the six months ended June 30, 2013 and
2012, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-13-312256:notes:154]
| 14. | RELATED PARTY TRANSACTIONS |

[0001193125-13-312256:notes:155]
We employ the law firm of
our director emeritus for legal services. All bills for services
rendered by this firm are reviewed and approved by our Chief
Financial Officer. We believe that the fees for such services are
comparable to those charged by other firms for services rendered to
us. For the three and six month periods ended June 30, 2013
and 2012, we incurred fees of $10 thousand per month for these
legal services.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001193125-13-312256:notes:156]
The following
table presents our intangible assets as of June 30, 2013 and
December 31, 2012:

[0001193125-13-312256:notes:157]
| (In thousands) |  | June 30, 2013 |  |  | December 31, 2012 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,698 |  |  | $ | (1,132 | ) |  | $ | 5,566 |  |  | $ | 6,769 |  |  | $ | (766 | ) |  | $ | 6,003 |  |
| Developed technology |  |  | 6,353 |  |  |  | (1,990 | ) |  |  | 4,363 |  |  |  | 6,397 |  |  |  | (1,354 | ) |  |  | 5,043 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,018 | ) |  |  | 1,322 |  |  |  | 2,340 |  |  |  | (851 | ) |  |  | 1,489 |  |
| Trade names |  |  | 270 |  |  |  | (115 | ) |  |  | 155 |  |  |  | 270 |  |  |  | (85 | ) |  |  | 185 |  |
| Other |  |  | 13 |  |  |  | (5 | ) |  |  | 8 |  |  |  | 13 |  |  |  | (3 | ) |  |  | 10 |  |
| Total |  | $ | 15,674 |  |  | $ | (4,260 | ) |  | $ | 11,414 |  |  | $ | 15,789 |  |  | $ | (3,059 | ) |  | $ | 12,730 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-13-312256:notes:158]
| 1. | SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES |

[0001193125-13-312256:notes:159]
In the
opinion of management, all adjustments necessary for a fair
presentation of these interim statements have been included and are
of a normal and recurring nature. The results of operations for an
interim period are not necessarily indicative of the results for
the full year. The interim statements should be read in conjunction
with the financial statements and notes thereto included in
ADTRAN’s Annual Report on Form 10-K for the year ended
December 31, 2012, filed on February 28, 2013 with the
SEC.

[0001193125-13-312256:notes:160]
[same as prior period, unchanged from 0001193125-13-207088:notes:142]

[0001193125-13-312256:notes:161]
Certain
changes in classifications have been made to the prior period
balances in other comprehensive income to conform to the current
period’s presentation as a result of our adoption of
Accounting Standards Update No. 2013-02, Reporting of Amounts
Reclassified Out of Accumulated Comprehensive Income.

[0001193125-13-312256:notes:162]
[same as prior period, unchanged from 0001193125-13-207088:notes:144]

[0001193125-13-312256:notes:163]
The
preparation of financial statements in conformity with accounting
principles generally accepted in the United States of America
requires management to make estimates and assumptions that affect
the reported amounts of assets and liabilities, the disclosure of
contingent assets and liabilities at the date of the financial
statements, and the reported amounts of revenue and expense during
the reporting period. Our more significant estimates include the
allowance for doubtful accounts, obsolete and excess inventory
reserves, warranty reserves, customer rebates, allowance for sales
returns, determination of the deferred revenue components of
multiple element sales agreements, estimated costs to complete
obligations associated with deferred revenues, estimated income tax
contingencies, the fair value of stock-based compensation,
impairment of goodwill, valuation and estimated lives of intangible
assets, estimated working capital adjustments under negotiation
related to the Nokia Siemens Networks Broadband Access business
acquisition, and the evaluation of other-than-temporary declines in
the value of investments. Actual amounts could differ significantly
from these estimates.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-13-312256:notes:164]
| 6. | INVESTMENTS |

[0001193125-13-312256:notes:165]
At
June 30, 2013, we held the following securities and
investments, recorded at either fair value or cost.

[0001193125-13-312256:notes:166]
At
December 31, 2012, we held the following securities and
investments, recorded at either fair value or cost.

[0001193125-13-312256:notes:167]
As of
June 30, 2013, our corporate bonds and municipal fixed-rate
bonds had the following contractual maturities:

[0001193125-13-312256:notes:168]
Our
investment policy provides limitations for issuer concentration,
which limits, at the time of purchase, the concentration in any one
issuer to 5% of the market value of our total investment
portfolio.

[0001193125-13-312256:notes:169]
At
June 30, 2013, we held a $48.3 million restricted certificate
of deposit, which is carried at cost. This investment serves as a
collateral deposit against the principal amount outstanding under
loans made to ADTRAN pursuant to an Alabama State Industrial
Development Authority revenue bond (the Bond). At June 30,
2013, the estimated fair value of the Bond was approximately $46.3
million, based on a debt security with a comparable interest rate
and maturity and a Standard and Poor’s credit rating of A-.
For more information on the Bond, see “Debt” under
“Liquidity and Capital Resources” in the
“Management’s Discussion and Analysis of Financial
Condition and Results of Operations” contained in Item 2
of Part I of this report.

[0001193125-13-312256:notes:170]
We review our
investment portfolio for potential
“other-than-temporary” declines in value on an
individual investment basis. We assess, on a quarterly basis,
significant declines in value which may be considered
other-than-temporary and, if necessary, recognize and record the
appropriate charge to write-down the carrying value of such
investments. In making this assessment, we take into consideration
qualitative and quantitative information, including but not limited
to the following: the magnitude and duration of historical declines
in market prices, credit rating activity, assessments of liquidity,
public filings, and statements made by the issuer. We generally
begin our identification of potential other-than-temporary
impairments by reviewing any security with a fair value that has
declined from its original or adjusted cost basis by 25% or more
for six or more consecutive months. We then evaluate the individual
security based on the previously identified factors to determine
the amount of the write-down, if any. As a result of our review, we
recorded an other-than-temporary impairment charge of $4 thousand
during the six months ended June 30, 2013 related to one
marketable security. For the six months ended June 30, 2012,
we recorded an other-than-temporary impairment charge of $33
thousand related to eight marketable equity securities.

[0001193125-13-312256:notes:171]
Realized
gains and losses on sales of securities are computed under the
specific identification method. The following table presents gross
realized gains and losses related to our investments.

[0001193125-13-312256:notes:172]
As of
June 30, 2013 and 2012, gross unrealized losses related to
individual securities in a continuous loss position for 12 months
or longer were not significant.

[0001193125-13-312256:notes:173]
We have
categorized our cash equivalents held in money market funds and our
investments held at fair value into a three-level fair value
hierarchy based on the priority of the inputs to the valuation
technique for the cash equivalents and investments as follows:
Level 1 – Values based on unadjusted, quoted prices in active
markets for identical assets or liabilities; Level 2 – Values
based on inputs other than quoted prices included within Level 1
that are directly or indirectly observable for the asset or
liability; Level 3 – Values based on unobservable inputs for
the asset or liability. These inputs include information supplied
by investees.

[0001193125-13-312256:notes:174]
|  |  | Fair Value Measurements at June 30, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,339 |  |  | $ | 1,339 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,792 |  |  |  | 12,792 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 187,930 |  |  |  | — |  |  |  | 187,930 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 155,481 |  |  |  | — |  |  |  | 155,481 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 7,120 |  |  |  | — |  |  |  | 7,120 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 7,818 |  |  |  | 7,818 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 24,032 |  |  |  | 24,032 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 395,173 |  |  |  | 44,642 |  |  |  | 350,531 |  |  |  | — |  |
| Total |  | $ | 396,512 |  |  | $ | 45,981 |  |  | $ | 350,531 |  |  | $ | — |  |

[0001193125-13-312256:notes:175]
|  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 28,071 |  |  | $ | 28,071 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,527 |  |  |  | 11,527 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 186,412 |  |  |  | — |  |  |  | 186,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 175,084 |  |  |  | — |  |  |  | 175,084 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | 34,375 |  |  |  | — |  |
| Fixed income bond fund |  |  | 456 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 21,105 |  |  |  | 21,105 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 443,058 |  |  |  | 47,187 |  |  |  | 395,871 |  |  |  | — |  |
| Total |  | $ | 471,129 |  |  | $ | 75,258 |  |  | $ | 395,871 |  |  | $ | — |  |

[0001193125-13-312256:notes:176]
The fair
value of our Level 2 securities is calculated using a weighted
average market price for each security. Market prices are obtained
from a variety of industry standard data providers, security master
files from large financial institutions, and other third-party
sources. These multiple market prices are used as inputs into a
distribution-curve-based algorithm to determine the daily market
value of each security.

[0001193125-13-312256:notes:177]
Our municipal
variable rate demand notes have a structure that implies a standard
expected market price. The frequent interest rate resets make it
reasonable to expect the price to stay at par. These securities are
priced at the expected market price.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-13-312256:notes:178]
| 9. | GOODWILL AND INTANGIBLE ASSETS |

[0001193125-13-312256:notes:179]
The change in
the carrying value of goodwill, all of which is included in our
Enterprise Networks division, for the six months ended
June 30, 2013 is as follows:

[0001193125-13-312256:notes:180]
We evaluate
the carrying value of goodwill during the fourth quarter of each
year and between annual evaluations if events occur or
circumstances change that would more likely than not reduce the
fair value of the reporting unit below its carrying amount. When
evaluating whether goodwill is impaired, we first assess
qualitative factors to determine whether it is necessary to perform
the two-step quantitative goodwill impairment test. If we determine
that the two-step quantitative test is necessary, then we compare
the fair value of the reporting unit to which the goodwill is
assigned to the reporting unit’s carrying amount, including
goodwill. If the carrying amount of the reporting unit exceeds its
fair value, then the amount of the impairment loss is measured.
There were no impairment losses recorded during the six months
ended June 30, 2013 or 2012.

[0001193125-13-312256:notes:181]
Intangible
assets are included in other assets in the accompanying
Consolidated Balance Sheets and include intangibles acquired in
conjunction with our acquisition of Objectworld Communications
Corporation on September 15, 2009, Bluesocket, Inc. on
August 4, 2011, and the NSN BBA business on May 4,
2012.

[0001193125-13-312256:notes:182]
Amortization
expense, all of which relates to business acquisitions, was $0.6
million and $0.5 million for the three months ended June 30,
2013 and 2012, respectively, and $1.2 million and $0.8 million for
the six months ended June 30, 2013 and 2012,
respectively.

[0001193125-13-312256:notes:183]
As of
June 30, 2013, the estimated future amortization expense of
our intangible assets is as follows:
