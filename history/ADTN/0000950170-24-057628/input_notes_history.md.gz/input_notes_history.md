# ADTN note change history — 0000950170-23-062173 → 0000950170-24-057628


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-10):
[0000950170-24-057628:note_history:1]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of March 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.9 million or approximately $365.7 million, based on an exchange rate as of March 31, 2024 and reflecting interest accrued through March 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).
  (was, 2023-11-09, similarity 0.9876):
[0000950170-23-062173:note_history:1]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.12% as of September 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €325.3 million or approximately $344.2 million, based on an exchange rate as of September 30, 2023 and reflecting interest accrued through September 30, 2023 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- changed (2024-05-10):
[0000950170-24-057628:note_history:2]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.5 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2024 and 2023, we accrued $2.9 million and $2.8 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit. With respect to the year ended December 31, 2023, we are obligated to pay $11.5 million in Annual Recurring Compensation on the third banking day following the 2024 ordinary general shareholders’ meeting of Adtran Networks, which is expected to occur on June 28, 2024 (but in any event within eight months following December 31, 2023).
  (was, 2023-11-09, similarity 0.661):
[0000950170-23-062173:note_history:2]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.2 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and nine months ended September 30, 2023, we accrued $2.9 million and $8.6 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively.

- changed (2024-05-10):
[0000950170-24-057628:note_history:3]
For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or
  (was, 2023-11-09, similarity 0.6309):
[0000950170-23-062173:note_history:3]
For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, were paid to Adtran Networks shareholders.

- added (2024-05-10):
[0000950170-24-057628:note_history:4]
approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders.

- changed (2024-05-10):
[0000950170-24-057628:note_history:5]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2024 and December 31, 2023, we had commitments related to these bonds totaling $10.6 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2023-11-09, similarity 0.9865):
[0000950170-23-062173:note_history:5]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2023 and December 31, 2022, we had commitments related to these bonds totaling $11.8 million and $22.0 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2024-05-10):
[0000950170-24-057628:note_history:6]
Purchase Obligations
  (was, 2023-11-09, similarity 0.7):
[0000950170-23-062173:note_history:6]
Purchase Commitments

- added (2024-05-10):
[0000950170-24-057628:note_history:7]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for short-term product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of March 31, 2024, purchase obligations totaled $238.0 million.

- removed (2024-05-10):
[0000950170-23-062173:note_history:8]
Adtran Networks Legal Matter

- removed (2024-05-10):
[0000950170-23-062173:note_history:9]
On May 8, 2023, Adtran Networks SE and its subsidiary, ADVA Optical Networking North America, Inc. (together, “Adtran Networks”), filed a lawsuit in the U.S District Court for the Eastern District of Texas (“EDTX”) against Huawei Technologies Co. Ltd (“Huawei”) seeking a declaration from the court that Huawei violated its commitments to negotiate in good faith and to license standard essential patents (“SEPs”), to the extent any SEPs are practiced by Adtran Networks, on Fair, Reasonable and Non-Discriminatory (“FRAND”) terms and conditions. The case also sought to obtain a ruling by the EDTX that Adtran Networks has complied with its own commitments and requested that the Court establish FRAND terms and conditions for obtaining a FRAND license on any SEPs to the extent they are practiced by Adtran Networks. The lawsuit further sought to enjoin Huawei from enforcing certain Huawei patents that Adtran Networks considers invalid and/or not practiced, and Adtran Networks alleged that Huawei had infringed upon an Adtran Networks patent. On July 20, 2023, Adtran Networks SE was served with a complaint filed by Huawei against Adtran Networks SE in the District Court München I, Germany, alleging that certain of its products infringe upon one of Huawei’s patents. On August 22, 2023, Adtran Networks entered into a settlement agreement with Huawei pursuant to which the parties agreed to, among other things, dismiss the lawsuits described above.

- removed (2024-05-10):
[0000950170-23-062173:note_history:10]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2023, purchase commitments totaled $308.4 million.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-05-10):
[0000950170-24-057628:note_history:11]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer and in particular upon the convergence of solutions at the network edge.

- changed (2024-05-10):
[0000950170-24-057628:note_history:12]
Liquidity, Domination and Profit and Loss Transfer Agreement and Credit Facility
  (was, 2023-11-09, similarity 0.7597):
[0000950170-23-062173:note_history:12]
Domination and Profit and Loss Transfer Agreement

- changed (2024-05-10):
[0000950170-24-057628:note_history:13]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE ("Adtran Networks"), as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).
  (was, 2023-11-09, similarity 0.9707):
[0000950170-23-062173:note_history:13]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE, as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

- changed (2024-05-10):
[0000950170-24-057628:note_history:14]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally
  (was, 2023-11-09, similarity 0.6672):
[0000950170-23-062173:note_history:14]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of Adtran Networks to transfer its annual profit to the Company applies for the first time to the profit, if any, generated in the Adtran Networks fiscal year 2023. The obligation of the Company to absorb Adtran Networks annual net loss applies for the first time to the loss, if any, generated in the Adtran Networks fiscal year 2023.

- added (2024-05-10):
[0000950170-24-057628:note_history:15]
absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated in 2023.

- changed (2024-05-10):
[0000950170-24-057628:note_history:16]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of March 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.9 million or approximately $365.7 million, based on an exchange rate as of March 31, 2024 and reflecting interest accrued through March 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).
  (was, 2023-11-09, similarity 0.9876):
[0000950170-23-062173:note_history:16]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.12% as of September 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €325.3 million or approximately $344.2 million, based on an exchange rate as of September 30, 2023 and reflecting interest accrued through September 30, 2023 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- changed (2024-05-10):
[0000950170-24-057628:note_history:17]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.5 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2024 and 2023, we accrued $2.9 million and $2.8 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit. With respect to the year ended December 31, 2023, we are obligated to pay $11.5 million in Annual Recurring Compensation on the third banking day following the 2024 ordinary general shareholders’ meeting of Adtran Networks, which is expected to occur on June 28, 2024 (but in any event within eight months following December 31, 2023).
  (was, 2023-11-09, similarity 0.6983):
[0000950170-23-062173:note_history:17]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.2 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and nine months ended September 30, 2023, we accrued $2.9 million and $8.6 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively.

- changed (2024-05-10):
[0000950170-24-057628:note_history:18]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders.
  (was, 2023-11-09, similarity 0.8509):
[0000950170-23-062173:note_history:18]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, were paid to Adtran Networks shareholders.

- added (2024-05-10):
[0000950170-24-057628:note_history:19]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”), which has since been amended three times. Pursuant to the terms of the Credit Agreement, as amended, the Company, ADTRAN, Inc., and the subsidiary guarantors (together, the “Credit Parties”) are subject to a liquidity covenant, which provides that, during the fourth quarter of 2023 through and including the third quarter of 2024 (the “Covenant Relief Period”) or a Springing Covenant Period (i.e., the period beginning upon the purchase by the Company of at least 60% of the outstanding shares of Adtran Networks not owned by the Company as of August 9, 2023 and the three consecutive quarterly test periods after such date), as of the last day of any fiscal quarter, the cash and cash equivalents of the Credit Parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million, limiting our ability to pay the obligations under the DPLTA. The Company had access to $203.0 million on its Credit Facility for future borrowings; however, as of March 31, 2024, the Company was limited to additional borrowings of $22.7 million based on debt covenant compliance metrics. See Note 11, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

- changed (2024-05-10):
[0000950170-24-057628:note_history:20]
As of March 31, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-32 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks shares.
  (was, 2023-11-09, similarity 0.7131):
[0000950170-23-062173:note_history:20]
As of September 30, 2023, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation assuming a substantial majority of Adtran Networks shareholders elect such option in the current period. We believe the probability that a substantial majority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-36 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks SE shares.

- added (2024-05-10):
[0000950170-24-057628:note_history:21]
The Company experienced revenue declines in the year ended December 31, 2023 and during the three months ended March 31, 2024. To the extent that the Company is further impacted by the uncertain macroeconomic environment related to continued elevated interest rates and ongoing inflationary pressures, the Company has established plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a business efficiency program, which includes, but is not limited to planned reductions in operating expenses and a site consolidation plan. In connection with

- added (2024-05-10):
[0000950170-24-057628:note_history:22]
the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

- added (2024-05-10):
[0000950170-24-057628:note_history:23]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility, including (i) the additional funding provided for under the First Amendment to the Wells Fargo Credit Facility that was signed on August 9, 2023, (ii) the additional covenant headroom during the Covenant Relief Period provided for under the Second Amendment to Wells Fargo Credit Facility, and (iii) the exclusion of the Factoring Agreement as debt for purposes of the Credit Facility’s financial covenants as provided for under the Third Amendment to the Wells Fargo Credit Facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and ability to continue to comply with our debt covenants under the Credit Facility, for at least the next twelve months, from the issuance of these financial statements. See Note 11, Revolving Credit Agreements, for additional information regarding the terms of the First, Second and Third Amendments of the Wells Fargo Credit agreement.

- changed (2024-05-10):
[0000950170-24-057628:note_history:24]
The accompanying unaudited Condensed Consolidated Financial Statements of ADTRAN Holdings, Inc. and its subsidiaries have been prepared pursuant to the rules and regulations of the SEC applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2023 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP for annual financial statements.
  (was, 2023-11-09, similarity 0.9738):
[0000950170-23-062173:note_history:24]
The accompanying unaudited Condensed Consolidated Financial Statements of ADTRAN Holdings, Inc. and its subsidiaries have been prepared pursuant to the rules and regulations of the SEC applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2022 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

- changed (2024-05-10):
[0000950170-24-057628:note_history:25]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on March 15, 2024.
  (was, 2023-11-09, similarity 0.9679):
[0000950170-23-062173:note_history:25]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in Amendment No. 1 to the ADTRAN Holdings, Inc. Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on August 14, 2023.

- changed (2024-05-10):
[0000950170-24-057628:note_history:26]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, the energy crisis, currency fluctuations and political tensions as of March 31, 2024, and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to ongoing inflationary pressures, the energy crisis, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.
  (was, 2023-11-09, similarity 0.7559):
[0000950170-23-062173:note_history:26]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of September 30, 2023, and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to supply chain constraints, inflationary pressures, the energy crisis, rising interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.

- added (2024-05-10):
[0000950170-24-057628:note_history:27]
Accounts Receivable Factoring

- added (2024-05-10):
[0000950170-24-057628:note_history:28]
New Accounts Receivable Factoring Agreement

- added (2024-05-10):
[0000950170-24-057628:note_history:29]
On December 19, 2023, the Company entered into a new factoring agreement with a third-party financial institution to replace the Company’s prior accounts receivable purchase agreement, to sell on a revolving basis, undivided interests in the Company’s accounts receivable. The new factoring agreement qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company is considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retains a residual claim on reserves related to the factored receivables. Within the Condensed Consolidated Balance Sheets, the receivables factored continue to be carried in accounts receivable, less allowance for credit losses, and the secured borrowings are carried as a current liability within accounts payable. The proceeds and repayments of secured borrowings are reflected as cash flows provided by (used in) financing activities within the Condensed Consolidated Statements of Cash Flows, and program fees are recorded as interest expense in the Consolidated Statements of Loss. The short-term liability classification of the secured borrowings is based on the estimated timing of the collection of the accounts receivable which are expected to be received within 12 months. See Note 2 for additional information.

- added (2024-05-10):
[0000950170-24-057628:note_history:30]
Previous Accounts Receivable Factoring Agreement

- added (2024-05-10):
[0000950170-24-057628:note_history:31]
The Company had previously entered into a factoring agreement to sell certain receivables to an unrelated third-party financial institution on a non-recourse basis. These transactions were accounted for in accordance with ASC Topic 860 and resulted in a reduction in accounts receivable because the agreement transferred effective control over and risk related to the receivables to the buyers. Trade accounts receivables balances sold were removed from the Condensed Consolidated Balance Sheets and cash received was reflected as cash flows provided by (used in) operating activities in the Condensed Consolidated Statements of Cash Flow. Factoring related interest expense was recorded to interest expense on the Condensed Consolidated Statements of Loss. On each sale date, the financial institution retained from the sale price a default reserve, up to a required balance, which was held by the financial institution in a reserve account and pledged to the Company. The financial institution was entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account was included in other assets on the Condensed Consolidated Balance Sheets.

- changed (2024-05-10):
[0000950170-24-057628:note_history:32]
As of March 31, 2024 and December 31, 2023, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.7% for each period.
  (was, 2023-11-09, similarity 0.898):
[0000950170-23-062173:note_history:32]
As of September 30, 2023 and December 31, 2022, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.6% and 34.7%, respectively.

- changed (2024-05-10):
[0000950170-24-057628:note_history:33]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. However, the RNCI will be remeasured using the current exchange rate at each reporting date as long as the RNCI is currently redeemable. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Condensed Consolidated Balance Sheets. See Note 14 for additional information on RNCI.
  (was, 2023-11-09, similarity 0.9564):
[0000950170-23-062173:note_history:33]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. However, the RNCI will be remeasured using the current exchange rate at each reporting date as long as the RNCI is currently redeemable. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Condensed Consolidated Balance Sheets.

- added (2024-05-10):
[0000950170-24-057628:note_history:34]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2023-09 will have on our disclosures.

- added (2024-05-10):
[0000950170-24-057628:note_history:35]
In November 2023, the FASB issued ASU 2023-7, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures", which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses, allowing financial statement users to better understand the components of a segment's profit or loss to assess potential future cash flows for each reportable segment and the entity as a whole. The amendments expand a public entity's segment disclosures by requiring disclosure of significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), clarifying when an entity may report one or more additional measures to assess segment performance, requiring enhanced interim disclosures, providing new disclosure requirements for entities with a single reportable segment, and requiring other new disclosures. The amendments are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, and early adoption is permitted. The Company expect to adopt the new disclosures as required for the year ended December 31, 2024. The Company is currently evaluating the impact on the related disclosures.

- added (2024-05-10):
[0000950170-24-057628:note_history:36]
Recent Final Rules Not Yet Adopted

- added (2024-05-10):
[0000950170-24-057628:note_history:37]
In March 2024, the SEC adopted final rules under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, which requires registrants to provide certain climate-related information in their registration statements and annual reports. The rules require information about a registrant's climate-related risks that are reasonably likely to have a material impact on its business, results of operations, or financial condition. The required information about climate-related risks will also include disclosure of a registrant's greenhouse gas emissions. In addition, the rules will require registrants to present certain climate-related financial metrics in their audited financial statements. These requirements are effective for the Company in various fiscal years, starting with its fiscal year beginning January 1, 2025. Disclosures will be required prospectively, with information for prior periods required only to the extent it was previously disclosed in an SEC filing. The Company is currently evaluating the impact of these final rules on its consolidated financial statements and disclosures. On April 12, 2024, the final rules were indefinitely delayed pending the completion of judicial review in consolidated proceedings in the U.S. Court of Appeals, Eighth Circuit.

- changed (2024-05-10):
[0000950170-24-057628:note_history:38]
There are currently no recently adopted accounting pronouncements that are expected to have a material effect on the Condensed Consolidated Financial Statements.
  (was, 2023-11-09, similarity 0.8972):
[0000950170-23-062173:note_history:38]
There are currently no accounting pronouncements not yet adopted that are expected to have a material effect on the Condensed Consolidated Financial Statements.

- removed (2024-05-10):
[0000950170-23-062173:note_history:39]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge.

- removed (2024-05-10):
[0000950170-23-062173:note_history:40]
Therefore, we believe that our cash and cash equivalents, investments, working capital management initiatives and access to funds under the Wells Fargo credit facility, including additional funding provided for under the First Amendment to the Wells Fargo credit facility that was signed on August 9, 2023, (described below) will be adequate to meet our operating and capital needs and our obligations under the DPLTA, including potential Exit Compensation, for at least the next 12 months, from the issuance of these financial statements, although we have suspended dividend payments and are implementing a business efficiency program, which includes, but is not limited to, planned reductions in our operating expenses and a site consolidation plan. In connection with the site consolidation plan, we are also exploring a potential sale of our headquarters in Huntsville. We may also need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet such needs and obligations. See Note 22, Subsequent Events, for additional information regarding  the suspension of the quarterly dividend.

- removed (2024-05-10):
[0000950170-23-062173:note_history:41]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100.0 million in aggregate principal amount, but the borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.

- removed (2024-05-10):
[0000950170-23-062173:note_history:42]
On August 9, 2023, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and, together with the Credit Agreement, the “Credit Facility”). The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. See Note 12, Revolving Credit Agreements, for additional information regarding the terms of the Credit Facility.

- removed (2024-05-10):
[0000950170-23-062173:note_history:43]
See Note 16 for additional information on RNCI.

- removed (2024-05-10):
[0000950170-23-062173:note_history:44]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. The Company early adopted ASU 2021-08 on July 1, 2022 and the standard was applied retrospectively beginning with January 1, 2022.


## adtn:NotesPayableDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2024-05-10):
[0000950170-23-062173:note_history:45]
13. NOTES PAYABLE

- removed (2024-05-10):
[0000950170-23-062173:note_history:46]
The carrying amounts of the Company's notes payable in its Condensed Consolidated Balance Sheets were as follows:

- removed (2024-05-10):
[0000950170-23-062173:note_history:47]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | September 30, 2023 |  |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |

- removed (2024-05-10):
[0000950170-23-062173:note_history:48]
Syndicated Credit Agreement Note Payable

- removed (2024-05-10):
[0000950170-23-062173:note_history:49]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement note payable. No amounts are available for future borrowings.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-10):
[0000950170-24-057628:note_history:50]
The carrying amounts of the Company's non-current revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:
  (was, 2023-11-09, similarity 0.9586):
[0000950170-23-062173:note_history:50]
The carrying amounts of the Company's current and non-current revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:

- changed (2024-05-10):
[0000950170-24-057628:note_history:51]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Wells Fargo credit agreement |  | $ | 195,000 |  |  | $ | 195,000 |  |
| Total non-current revolving credit agreement |  | $ | 195,000 |  |  | $ | 195,000 |  |
  (was, 2023-11-09, similarity 0.9014):
[0000950170-23-062173:note_history:51]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Wells Fargo credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |
| Total non-current revolving credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |

- changed (2024-05-10):
[0000950170-24-057628:note_history:52]
As of March 31, 2024, the weighted average interest rate on our revolving credit agreements was 8.46%.
  (was, 2023-11-09, similarity 0.9474):
[0000950170-23-062173:note_history:52]
As of September 30, 2023, the weighted average interest rate on our revolving credit agreements was 7.11%.

- changed (2024-05-10):
[0000950170-24-057628:note_history:53]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount, as well as the $50.0 million delayed draw term loan facility described below.
  (was, 2023-11-09, similarity 0.659):
[0000950170-23-062173:note_history:53]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement initially allowed for borrowings of up to $100.0 million in aggregate principal amount, but the permitted borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.

- changed (2024-05-10):
[0000950170-24-057628:note_history:54]
On August 9, 2023, (the "First Amendment Effective Date") the Company, its wholly-owned direct subsidiary, ADTRAN, Inc. and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and together with the Credit Agreement, the "Credit Facility").
  (was, 2023-11-09, similarity 0.9548):
[0000950170-23-062173:note_history:54]
On August 9, 2023, (the "First Amendment Effective Date") the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and together with the Credit Agreement, the "Credit Facility").

- changed (2024-05-10):
[0000950170-24-057628:note_history:55]
The First Amendment, provided for, among other things, a new $50.0 million delayed draw term loan (“DDTL”), which (subject to certain conditions) is available for borrowing in the event of the purchase by the Company of at least sixty percent (60.0%) of the outstanding shares of Adtran Networks SE that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks SE. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through August 9, 2024.
  (was, 2023-11-09, similarity 0.8931):
[0000950170-23-062173:note_history:55]
The First Amendment, provides for, among other things, a new $50.0 million delayed draw term loan (“DDTL”), which is available for borrowing in the event of the purchase by the Company of at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company as of the First Amendment Effective Date (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through the period that is three consecutive fiscal quarters thereafter.

- added (2024-05-10):
[0000950170-24-057628:note_history:56]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

- added (2024-05-10):
[0000950170-24-057628:note_history:57]
On January 16, 2024, the Company entered into a Second Amendment to the Credit Agreement and First Amendment to the Collateral Agreement. The Second Amendment, among other things, provides the Company and its subsidiaries with additional covenant headroom for the fourth quarter of 2023 through the third quarter of 2024 (the "Covenant Relief Period") and adds certain other financial covenants which are described below.

- added (2024-05-10):
[0000950170-24-057628:note_history:58]
On March 12, 2024, the Company entered into a Third Amendment to the Credit Agreement. The Third Amendment, among other things, amends the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024 and June 30, 2024.

- changed (2024-05-10):
[0000950170-24-057628:note_history:59]
As of March 31, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $195.0 million. As of March 31, 2024, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. In addition, we may issue up to $50.0 million in letters of credit against our $400.0 million total facility. As of March 31, 2024, we had a total of $2.0 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $203.0 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of March 31, 2024, the Company was in compliance with all covenants.
  (was, 2023-11-09, similarity 0.7873):
[0000950170-23-062173:note_history:59]
As of September 30, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $200.0 million. As of September 30, 2023, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million total facility. As of September 30, 2023, we had a total of $2.2 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $197.8 million available for future borrowings. Any future credit extensions

- added (2024-05-10):
[0000950170-24-057628:note_history:60]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin) bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.15% per annum).

- changed (2024-05-10):
[0000950170-24-057628:note_history:61]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.
  (was, 2023-11-09, similarity 0.6559):
[0000950170-23-062173:note_history:61]
All U.S. borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.9% to 2.9%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”) or (B) the sum of the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%, plus (ii) the applicable rate, ranging from 0.9% to 1.9%. The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.0% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

- added (2024-05-10):
[0000950170-24-057628:note_history:62]
“Adjusted Term SOFR” means Term SOFR for the applicable interest period plus 0.10% per annum. Adjusted Term SOFR is subject to a floor of 0.00% per annum.

- added (2024-05-10):
[0000950170-24-057628:note_history:63]
All Euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.25% per annum).

- added (2024-05-10):
[0000950170-24-057628:note_history:64]
In addition, (x) if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

- added (2024-05-10):
[0000950170-24-057628:note_history:65]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

- added (2024-05-10):
[0000950170-24-057628:note_history:66]
The increases in the commitment fee and margin rates during the Covenant Relief Period (referenced above) continue until the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the “Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, the Company has repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the Company has reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) the Company is in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

- added (2024-05-10):
[0000950170-24-057628:note_history:67]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

- added (2024-05-10):
[0000950170-24-057628:note_history:68]
All U.S. dollar borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.90% to 1.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.40% per annum), or (B) Adjusted Term SOFR plus an applicable margin ranging from 1.90% to 2.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.40% per annum).

- added (2024-05-10):
[0000950170-24-057628:note_history:69]
In addition, (x) if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

- changed (2024-05-10):
[0000950170-24-057628:note_history:70]
In addition to paying interest on outstanding principal under the DDTL loan, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment.
  (was, 2023-11-09, similarity 0.7831):
[0000950170-23-062173:note_history:70]
In addition to paying interest on outstanding principal under the DDTL loan, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment until the earliest of (i) the delayed draw funding date, (ii) the delayed draw funding deadline and (iii) the termination in full of the DDTL commitments.

- added (2024-05-10):
[0000950170-24-057628:note_history:71]
The increases in the commitment fee and margin rates during the Covenant Relief Period (referenced above) continue until the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the “Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, the Company has repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the Company has reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) the Company is in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

- added (2024-05-10):
[0000950170-24-057628:note_history:72]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

- added (2024-05-10):
[0000950170-24-057628:note_history:73]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable)::

- added (2024-05-10):
[0000950170-24-057628:note_history:74]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Total Net Leverage Ratio may not exceed 5.00x.

- added (2024-05-10):
[0000950170-24-057628:note_history:75]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

- added (2024-05-10):
[0000950170-24-057628:note_history:76]
•
In the event of the purchase by the Company of at least sixty percent (60%) of the outstanding shares of Adtran Networks SE not owned by the Company as of August 9, 2023 that have been tendered (such event, a “Springing Covenant Event” and the fiscal quarter in which the Springing Covenant Event Occurs and the three consecutive quarterly test periods thereafter, the “Springing Covenant Period”), the following covenant levels:

- added (2024-05-10):
[0000950170-24-057628:note_history:77]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

- added (2024-05-10):
[0000950170-24-057628:note_history:78]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

- added (2024-05-10):
[0000950170-24-057628:note_history:79]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

- added (2024-05-10):
[0000950170-24-057628:note_history:80]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50,000,000 in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

- added (2024-05-10):
[0000950170-24-057628:note_history:81]
•
If a Springing Covenant Period is not in effect, the following covenant levels:

- added (2024-05-10):
[0000950170-24-057628:note_history:82]
•
From December 31, 2023 through and including March 31, 2024: 3.25x.

- added (2024-05-10):
[0000950170-24-057628:note_history:83]
•
From April 1, 2024 through and including June 30, 2024: 3.50x.

- added (2024-05-10):
[0000950170-24-057628:note_history:84]
•
From July 1, 2024 and thereafter: 3.25x.

- added (2024-05-10):
[0000950170-24-057628:note_history:85]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not exceed 1.25x.

- added (2024-05-10):
[0000950170-24-057628:note_history:86]
•
During the Covenant Relief Period or a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million.

- added (2024-05-10):
[0000950170-24-057628:note_history:87]
The Credit Agreement is guaranteed by certain domestic subsidiaries of the Company, and the Company is also required to add certain additional domestic and international subsidiaries as guarantors under the Credit Agreement (such existing and new guarantors, collectively, the “Guarantors”). In addition to the guarantees provided by the Guarantors, the Guarantors have granted (or will grant) security interests in favor of the Administrative Agent over substantially all tangible and intangible assets, and the Borrower will grant mortgages in favor of the Administrative Agent over certain owned real estate assets. The Company is currently in negotiations with the Administrative Agent regarding a potential further amendment to the Credit Agreement to address the addition of certain foreign subsidiary guarantors.

- added (2024-05-10):
[0000950170-24-057628:note_history:88]
The Credit Agreement provides for revolving borrowings of up to $400.0 million in aggregate principal amount, as well as an additional $50.0 million delayed draw term loan tranche that would be available upon a Springing Covenant Event. It also continues to permit the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement subject to certain limitations and minimum payment thresholds.

- added (2024-05-10):
[0000950170-24-057628:note_history:89]
During the Covenant Relief Period, the Company is not permitted to make certain dividend payments to the Company's Stockholders or certain other Restricted Payments. However, the Company is permitted to make the Recurring Compensation Payment to each Adtran Networks shareholder (other than the Company), pursuant to the terms of the DPLTA.

- added (2024-05-10):
[0000950170-24-057628:note_history:90]
Furthermore, the Credit Agreement, as amended, contain customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts; however, certain of the exceptions and carveouts are not permitted to be used during the Covenant Relief Period. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.

- removed (2024-05-10):
[0000950170-23-062173:note_history:91]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| New Nord/LB revolving line of credit |  | $ | 10,580 |  |  | $ | — |  |
| Nord/LB revolving line of credit |  |  | — |  |  |  | 16,091 |  |
| Syndicated credit agreement working capital line of credit |  |  | — |  |  |  | 10,727 |  |
| DZ bank revolving line of credit |  |  | — |  |  |  | 9,118 |  |
| Total current revolving credit agreements |  | $ | 10,580 |  |  | $ | 35,936 |  |

- removed (2024-05-10):
[0000950170-23-062173:note_history:92]
The First Amendment further added additional financial flexibility by amending the $30.0 million external debt capped basket to be an unlimited amount and permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must be incurred in pro forma compliance with the financial covenants in the Credit Agreement, unsecured and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

- removed (2024-05-10):
[0000950170-23-062173:note_history:93]
under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

- removed (2024-05-10):
[0000950170-23-062173:note_history:94]
All U.S. borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below)) bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%, plus (ii) the applicable rate, ranging from 0.65% to 1.65% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.65% to 2.65%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.75% to 2.75%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.0% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

- removed (2024-05-10):
[0000950170-23-062173:note_history:95]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate ranging from 0.20% to 0.25% per annum on the average daily unused portion of the revolving credit commitment of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for SOFR Loans.

- removed (2024-05-10):
[0000950170-23-062173:note_history:96]
The First Amendment permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the First Amendment without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The First Amendment contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds).

- removed (2024-05-10):
[0000950170-23-062173:note_history:97]
The First Amendment further included the following revised financial covenants; (i) the addition of an automatic step up in the consolidated total net leverage ratio to 5.00:1.00 from 3.25:1.00 upon the occurrence of a Springing Covenant Event and continuing for the fiscal quarter in which the Springing Covenant Event occurs and the next three consecutive fiscal quarters thereafter (such period, a “Springing Covenant Period”) and (ii) the addition of a consolidated senior secured net leverage ratio covenant to be tested quarterly during a Springing Covenant Period and sized at 4.00:1.00 during the first quarter ending after a Springing Covenant Event, 3.75:1.00 during the second quarter ending after a Springing Covenant Event and 3.50:1.00 during the third and fourth quarters ending after a Springing Covenant Event. Further, if the Company or any of its subsidiaries incurs unsecured indebtedness under the uncapped general indebtedness basket or permitted convertible indebtedness basket of the Credit Agreement in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, then the maximum consolidated senior secured net leverage ratio shall be, or shall automatically step down to, 3.50:1.00 at the time of such incurrence.

- removed (2024-05-10):
[0000950170-23-062173:note_history:98]
The First Amendment also requires that the consolidated interest coverage ratio (as defined in the First Amendment) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of September 30, 2023, the Company was in compliance with all material covenants.

- removed (2024-05-10):
[0000950170-23-062173:note_history:99]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the First Amendment are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the First Amendment pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

- removed (2024-05-10):
[0000950170-23-062173:note_history:100]
Nord/LB Revolving Line of Credit

- removed (2024-05-10):
[0000950170-23-062173:note_history:101]
On March 29, 2023, Adtran Networks entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of September 30, 2023, Adtran Networks borrowed $10.6 million under this facility.

- removed (2024-05-10):
[0000950170-23-062173:note_history:102]
Prior Nord/LB Revolving Line of Credit

- removed (2024-05-10):
[0000950170-23-062173:note_history:103]
On August 8, 2022, Adtran Networks entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and matured in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit. No amounts are available for future borrowings.

- removed (2024-05-10):
[0000950170-23-062173:note_history:104]
Syndicated Credit Agreement Working Capital Line of Credit

- removed (2024-05-10):
[0000950170-23-062173:note_history:105]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement working capital line of credit. No amounts are available for future borrowings.

- removed (2024-05-10):
[0000950170-23-062173:note_history:106]
DZ Bank Revolving Line of Credit

- removed (2024-05-10):
[0000950170-23-062173:note_history:107]
In the fourth quarter of 2022, Adtran Networks entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings under the DZ Bank revolving line of credit. No amounts are available for future borrowings.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-10):
[0000950170-24-057628:note_history:108]
The Company did not have any debt securities and other investments as of March 31, 2024.
  (was, 2023-11-09, similarity 0.9405):
[0000950170-23-062173:note_history:108]
The Company did not have any debt securities and other investments as of September 30, 2023.

- changed (2024-05-10):
[0000950170-24-057628:note_history:109]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | 4 |  |
| Gross realized loss on debt securities |  |  | — |  |  |  | (11 | ) |
| Total loss recognized, net |  | $ | — |  |  | $ | (7 | ) |
  (was, 2023-11-09, similarity 0.6329):
[0000950170-23-062173:note_history:109]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Gross realized gain on debt securities |  | $ | 5 |  |  | $ | 1 |  |  | $ | 9 |  |  | $ | 14 |  |
| Gross realized loss on debt securities |  |  | (317 | ) |  |  | (116 | ) |  |  | (355 | ) |  |  | (242 | ) |
| Total loss recognized, net |  | $ | (312 | ) |  | $ | (115 | ) |  | $ | (346 | ) |  | $ | (228 | ) |

- added (2024-05-10):
[0000950170-24-057628:note_history:110]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Realized gain on equity securities sold |  | $ | 123 |  |  | $ | 13 |  |
| Unrealized gain on equity securities held |  |  | 2,130 |  |  |  | 1,246 |  |
| Total gain recognized, net |  | $ | 2,253 |  |  | $ | 1,259 |  |

- added (2024-05-10):
[0000950170-24-057628:note_history:111]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,375 |  |  | $ | 5,375 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 987 |  |  |  | 987 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 28,265 |  |  |  | 28,265 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 34,627 |  |  | $ | 34,627 |  |  | $ | — |  |  | $ | — |  |

- changed (2024-05-10):
[0000950170-24-057628:note_history:112]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,302 |  |  | $ | 5,302 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 905 |  |  |  | 905 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,838 |  |  |  | 26,838 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,045 |  |  | $ | 33,045 |  |  | $ | — |  |  | $ | — |  |
  (was, 2023-11-09, similarity 0.6214):
[0000950170-23-062173:note_history:112]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,462 |  |  | $ | — |  |  | $ | 2,462 |  |  | $ | — |  |
| Municipal fixed-rate bonds |  |  | 180 |  |  |  | — |  |  |  | 180 |  |  |  | — |  |
| Asset-backed bonds |  |  | 795 |  |  |  | — |  |  |  | 795 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,748 |  |  |  | — |  |  |  | 1,748 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,685 |  |  |  | 3,685 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 383 |  |  |  | — |  |  |  | 383 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 810 |  |  |  | 810 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,942 |  |  |  | 22,942 |  |  |  | — |  |  |  | — |  |
| Total short-term and long-term investments |  | $ | 33,005 |  |  | $ | 27,437 |  |  | $ | 5,568 |  |  | $ | - |  |
| Total |  | $ | 33,233 |  |  | $ | 27,665 |  |  | $ | 5,568 |  |  | $ | — |  |

- changed (2024-05-10):
[0000950170-24-057628:note_history:113]
Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.
  (was, 2023-11-09, similarity 0.8343):
[0000950170-23-062173:note_history:113]
The fair value of its Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

- removed (2024-05-10):
[0000950170-23-062173:note_history:114]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value as of December 31, 2022:

- removed (2024-05-10):
[0000950170-23-062173:note_history:115]
|  |  | As of December 31, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,538 |  |  | $ | 5 |  |  | $ | (81 | ) |  | $ | 2,462 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (5 | ) |  |  | 180 |  |
| Asset-backed bonds |  |  | 818 |  |  |  | 1 |  |  |  | (24 | ) |  |  | 795 |  |
| Mortgage/Agency-backed bonds |  |  | 1,853 |  |  |  | — |  |  |  | (105 | ) |  |  | 1,748 |  |
| U.S. government bonds |  |  | 3,870 |  |  |  | 3 |  |  |  | (188 | ) |  |  | 3,685 |  |
| Foreign government bonds |  |  | 407 |  |  |  | — |  |  |  | (24 | ) |  |  | 383 |  |
| Available-for-sale debt securities held at fair value |  | $ | 9,671 |  |  | $ | 9 |  |  | $ | (427 | ) |  | $ | 9,253 |  |

- removed (2024-05-10):
[0000950170-23-062173:note_history:116]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. No allowance for credit losses was recorded for the nine months ended September 30, 2023 and 2022 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5.0% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the nine months ended September 30, 2023.

- removed (2024-05-10):
[0000950170-23-062173:note_history:117]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Unrealized gain (loss) on equity securities held |  | $ | (1,130 | ) |  | $ | (1,217 | ) |  | $ | 1,404 |  |  | $ | (8,849 | ) |
| Realized gain (loss) on equity securities sold |  |  | (1 | ) |  |  | (1,358 | ) |  |  | 13 |  |  |  | (1,675 | ) |
| Total gain (loss) recognized, net |  | $ | (1,131 | ) |  | $ | (2,575 | ) |  | $ | 1,417 |  |  | $ | (10,524 | ) |

- removed (2024-05-10):
[0000950170-23-062173:note_history:118]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Money market funds |  |  | 5,245 |  |  |  | 5,245 |  |  |  | — |  |  |  | — |  |
| Commercial paper |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total cash equivalents |  | $ | 5,245 |  |  | $ | 5,245 |  |  | $ | - |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 815 |  |  |  | 815 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 24,364 |  |  |  | 24,364 |  |  |  | — |  |  |  | — |  |
| Total long-term investments |  | $ | 25,179 |  |  | $ | 25,179 |  |  | $ | — |  |  | $ | — |  |
| Total |  | $ | 30,424 |  |  | $ | 30,424 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2024-05-10):
[0000950170-23-062173:note_history:119]
The carrying amounts of the Company's notes payable in its Condensed Consolidated Balance Sheets were as follows:

- removed (2024-05-10):
[0000950170-23-062173:note_history:120]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | September 30, 2023 |  |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-05-10):
[0000950170-24-057628:note_history:121]
The following table disaggregates revenue by reportable segment and revenue category:

- added (2024-05-10):
[0000950170-24-057628:note_history:122]
|  |  | Three Months Ended |  |
|  |  | March 31, 2024 |  |  | March 31, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 60,369 |  |  | $ | 9,399 |  |  | $ | 69,767 |  |  | $ | 70,287 |  |  | $ | 9,049 |  |  | $ | 79,336 |  |
| Access & Aggregation Solutions |  |  | 67,777 |  |  |  | 13,535 |  |  |  | 81,312 |  |  |  | 84,554 |  |  |  | 12,266 |  |  |  | 96,820 |  |
| Optical Networking Solutions |  |  | 53,127 |  |  |  | 21,966 |  |  |  | 75,094 |  |  |  | 127,577 |  |  |  | 20,179 |  |  |  | 147,756 |  |
| Total |  | $ | 181,273 |  |  | $ | 44,900 |  |  | $ | 226,173 |  |  | $ | 282,418 |  |  | $ | 41,494 |  |  | $ | 323,912 |  |

- removed (2024-05-10):
[0000950170-23-062173:note_history:123]
The following tables disaggregate revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

- removed (2024-05-10):
[0000950170-23-062173:note_history:124]
|  |  | Three Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 94,592 |  |  | $ | 21,608 |  |  | $ | 116,200 |  |  | $ | 103,011 |  |  | $ | 15,834 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 81,051 |  |  |  | 13,595 |  |  |  | 94,646 |  |  |  | 76,591 |  |  |  | 11,598 |  |  |  | 88,189 |  |
| Subscriber Solutions |  |  | 52,921 |  |  |  | 8,564 |  |  |  | 61,485 |  |  |  | 125,338 |  |  |  | 8,337 |  |  |  | 133,675 |  |
| Total |  | $ | 228,564 |  |  | $ | 43,767 |  |  | $ | 272,331 |  |  | $ | 304,940 |  |  | $ | 35,769 |  |  | $ | 340,709 |  |

- removed (2024-05-10):
[0000950170-23-062173:note_history:125]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 342,390 |  |  | $ | 64,562 |  |  | $ | 406,952 |  |  | $ | 103,011 |  |  | $ | 15,834 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 254,868 |  |  |  | 39,315 |  |  |  | 294,183 |  |  |  | 243,396 |  |  |  | 34,877 |  |  |  | 278,273 |  |
| Subscriber Solutions |  |  | 196,726 |  |  |  | 25,760 |  |  |  | 222,486 |  |  |  | 252,899 |  |  |  | 17,248 |  |  |  | 270,147 |  |
| Total |  | $ | 793,984 |  |  | $ | 129,637 |  |  | $ | 923,621 |  |  | $ | 599,306 |  |  | $ | 67,959 |  |  | $ | 667,265 |  |

- removed (2024-05-10):
[0000950170-23-062173:note_history:126]
The table below presents revenue information by category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

- removed (2024-05-10):
[0000950170-23-062173:note_history:127]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Optical Networking Solutions |  | $ | 116,200 |  |  | $ | 118,845 |  |  | $ | 406,952 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 94,646 |  |  |  | 88,189 |  |  |  | 294,183 |  |  |  | 278,273 |  |
| Subscriber Solutions |  |  | 61,485 |  |  |  | 133,675 |  |  |  | 222,486 |  |  |  | 270,147 |  |
| Total |  | $ | 272,331 |  |  | $ | 340,709 |  |  | $ | 923,621 |  |  | $ | 667,265 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-05-10):
[0000950170-24-057628:note_history:128]
The following table disaggregates revenue by reportable segment and revenue category:

- added (2024-05-10):
[0000950170-24-057628:note_history:129]
|  |  | Three Months Ended |  |
|  |  | March 31, 2024 |  |  | March 31, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 60,369 |  |  | $ | 9,399 |  |  | $ | 69,767 |  |  | $ | 70,287 |  |  | $ | 9,049 |  |  | $ | 79,336 |  |
| Access & Aggregation Solutions |  |  | 67,777 |  |  |  | 13,535 |  |  |  | 81,312 |  |  |  | 84,554 |  |  |  | 12,266 |  |  |  | 96,820 |  |
| Optical Networking Solutions |  |  | 53,127 |  |  |  | 21,966 |  |  |  | 75,094 |  |  |  | 127,577 |  |  |  | 20,179 |  |  |  | 147,756 |  |
| Total |  | $ | 181,273 |  |  | $ | 44,900 |  |  | $ | 226,173 |  |  | $ | 282,418 |  |  | $ | 41,494 |  |  | $ | 323,912 |  |

- changed (2024-05-10):
[0000950170-24-057628:note_history:130]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2024 and December 31, 2023 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $346.9 million and $314.8 million, respectively. As of March 31, 2024, approximately 61.0% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of March 31, 2024 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.
  (was, 2023-11-09, similarity 0.98):
[0000950170-23-062173:note_history:130]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of September 30, 2023 and December 31, 2022 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $314.0 million and $277.2 million, respectively. As of September 30, 2023, approximately 68.6% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of September 30, 2023 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2024-05-10):
[0000950170-24-057628:note_history:131]
The following table provides information about accounts receivable, contract assets and unearned revenue from contracts with customers:
  (was, 2023-11-09, similarity 0.9618):
[0000950170-23-062173:note_history:131]
The following table provides information about receivables, contract assets and unearned revenue from contracts with customers:

- changed (2024-05-10):
[0000950170-24-057628:note_history:132]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Accounts receivable, net |  | $ | 187,554 |  |  | $ | 216,445 |  |
| Contract assets(1) |  | $ | 815 |  |  | $ | 691 |  |
| Unearned revenue |  | $ | 55,124 |  |  | $ | 46,731 |  |
| Non-current unearned revenue |  | $ | 22,884 |  |  | $ | 25,109 |  |
  (was, 2023-11-09, similarity 0.9263):
[0000950170-23-062173:note_history:132]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Accounts receivable, net |  | $ | 229,333 |  |  | $ | 279,435 |  |
| Contract assets(1) |  | $ | 888 |  |  | $ | 1,852 |  |
| Unearned revenue |  | $ | 49,832 |  |  | $ | 41,193 |  |
| Non-current unearned revenue |  | $ | 23,501 |  |  | $ | 19,239 |  |

- changed (2024-05-10):
[0000950170-24-057628:note_history:133]
The allowance for credit losses was $0.4 million as of March 31, 2024 and December 31, 2023, related to accounts receivable.
  (was, 2023-11-09, similarity 0.8016):
[0000950170-23-062173:note_history:133]
The allowance for credit losses was $15 thousand and $49 thousand as of September 30, 2023 and December 31, 2022, respectively, related to accounts receivable.

- changed (2024-05-10):
[0000950170-24-057628:note_history:134]
No allowance for credit losses was recorded for the three months ended March 31, 2024 and 2023 related to contract assets.
  (was, 2023-11-09, similarity 0.9569):
[0000950170-23-062173:note_history:134]
No allowance for credit losses was recorded for the three months ended September 30, 2023 and 2022 related to contract assets.

- added (2024-05-10):
[0000950170-24-057628:note_history:135]
Receivables Purchase Agreement

- added (2024-05-10):
[0000950170-24-057628:note_history:136]
The Company was party to a receivable purchase agreement with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. As of December 31, 2023 no accounts receivable were factored under the agreement or held in the reserve account. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months ended March 31, 2023.

- added (2024-05-10):
[0000950170-24-057628:note_history:137]
On December 19, 2023, the agreement with the Factor was terminated and the Company, entered into a receivables purchase agreement with a third-party financial institution (the “New Factor”) to replace the Company’s prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The New Factor provides for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The New Factor qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. Total secured borrowings under the agreement were $12.6 million and $14.3 million as of March 31, 2024 and December 31, 2023, respectively, leaving $27.2 million and $25.4 million available for future borrowings as of March 31, 2024 and December 31, 2023, respectively. Accounts receivable pledged as collateral related to the secured borrowings were $16.4 million and $16.8 million as of March 31, 2024 and December 31, 2023, respectively. For the three months ended March 31, 2024, the Company incurred program fee expenses of $0.3 million. As of March 31, 2024, the program fee rate was 6.88% percent.

- added (2024-05-10):
[0000950170-24-057628:note_history:138]
Of the outstanding unearned revenue balances as of December 31, 2023, $19.7 million were recognized as revenue during the three months ended March 31, 2024. Of the $60.4 million of outstanding unearned revenue balances as of December 31, 2022, $25.6 million were recognized as revenue during the three months ended March 31, 2023.

- removed (2024-05-10):
[0000950170-23-062173:note_history:139]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks SE solutions to create Access & Aggregation Solutions; ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions; and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of Adtran Networks' portfolio.

- removed (2024-05-10):
[0000950170-23-062173:note_history:140]
The following tables disaggregate revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

- removed (2024-05-10):
[0000950170-23-062173:note_history:141]
|  |  | Three Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 94,592 |  |  | $ | 21,608 |  |  | $ | 116,200 |  |  | $ | 103,011 |  |  | $ | 15,834 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 81,051 |  |  |  | 13,595 |  |  |  | 94,646 |  |  |  | 76,591 |  |  |  | 11,598 |  |  |  | 88,189 |  |
| Subscriber Solutions |  |  | 52,921 |  |  |  | 8,564 |  |  |  | 61,485 |  |  |  | 125,338 |  |  |  | 8,337 |  |  |  | 133,675 |  |
| Total |  | $ | 228,564 |  |  | $ | 43,767 |  |  | $ | 272,331 |  |  | $ | 304,940 |  |  | $ | 35,769 |  |  | $ | 340,709 |  |

- removed (2024-05-10):
[0000950170-23-062173:note_history:142]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 342,390 |  |  | $ | 64,562 |  |  | $ | 406,952 |  |  | $ | 103,011 |  |  | $ | 15,834 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 254,868 |  |  |  | 39,315 |  |  |  | 294,183 |  |  |  | 243,396 |  |  |  | 34,877 |  |  |  | 278,273 |  |
| Subscriber Solutions |  |  | 196,726 |  |  |  | 25,760 |  |  |  | 222,486 |  |  |  | 252,899 |  |  |  | 17,248 |  |  |  | 270,147 |  |
| Total |  | $ | 793,984 |  |  | $ | 129,637 |  |  | $ | 923,621 |  |  | $ | 599,306 |  |  | $ | 67,959 |  |  | $ | 667,265 |  |

- removed (2024-05-10):
[0000950170-23-062173:note_history:143]
The Company is party to a receivables purchase agreement with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables sold for the nine months ended September 30, 2023 and the twelve months ended December 31, 2022, totaled $17.8 million and $14.9 million, respectively, of which $1.4 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of September 30, 2023 and December 31, 2022, the Company had an allowance for credit losses related to factored accounts receivable totaling less than $0.1 million. The cost of the receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million and $0.9 million for the three and nine months ended September 30, 2023, respectively.

- removed (2024-05-10):
[0000950170-23-062173:note_history:144]
Of the outstanding unearned revenue balances as of December 31, 2022, $6.1 million and $31.3 million were recognized as revenue during the three and nine months ended September 30, 2023, respectively. Of the $17.7 million of outstanding unearned revenue balances as of December 31, 2021, $2.8 million and $12.3 million were recognized as revenue during the three and nine months ended September 30, 2022, respectively.

- removed (2024-05-10):
[0000950170-23-062173:note_history:145]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. Accounts receivable balances are considered past due when payment has not been received by the date indicated on the relevant invoice or based on agreed upon terms between the customer and the Company.

- removed (2024-05-10):
[0000950170-23-062173:note_history:146]
As of September 30, 2023 and December 31, 2022, the Company’s outstanding accounts receivable balance was $229.3 million and $279.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method, as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

- removed (2024-05-10):
[0000950170-23-062173:note_history:147]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of September 30, 2023 and December 31, 2022, the Company’s outstanding contract asset balance was $0.9 million and $1.9 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method, as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-05-10):
[0000950170-24-057628:note_history:148]
Facility Closure

- added (2024-05-10):
[0000950170-24-057628:note_history:149]
In connection with the Business Efficiency Program, management of the Company determined on April 11, 2024 to close the Company’s facility in Greifswald, Germany. The closure of the facility is expected to be substantially completed by June 30, 2024.

- removed (2024-05-10):
[0000950170-23-062173:note_history:150]
Dividend Suspension

- removed (2024-05-10):
[0000950170-23-062173:note_history:151]
On November 6, 2023, the Board of Directors suspended the Company’s quarterly cash dividend which will be redirected to reduce debt and interest expense and support the Company's capital efficiency program. The payment of any future dividends will be at the discretion of the Board of Directors and will depend on the Company’s financial condition, results of operations, capital requirements, and any other factors deemed relevant by the Board of Directors.

- removed (2024-05-10):
[0000950170-23-062173:note_history:152]
Business Efficiency Program

- removed (2024-05-10):
[0000950170-23-062173:note_history:153]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management determined to implement a comprehensive business efficiency program, which includes (i) a cost efficiency program targeting the reduction of ongoing operating expenses, and (ii) a capital efficiency program, which includes a site consolidation plan exploring the partial sale of owned real estate and the suspension of the quarterly dividend. See Part II, Item 5 (a) of this report for additional information regarding the business efficiency program.
