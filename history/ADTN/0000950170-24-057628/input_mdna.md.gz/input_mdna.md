# ADTN MD&A — 0000950170-24-057628


## mdna

[0000950170-24-057628:mdna:1]
[same as prior period, unchanged from 0000950170-23-062173:mdna:1]

[0000950170-24-057628:mdna:2]
The following discussion should be read in conjunction with the Condensed Consolidated Financial Statements and the related notes that appear in Part I, Item 1 of this document. In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2023, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, and Part I, Item 1A, Risk Factors, included in our Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on March 15, 2024.

[0000950170-24-057628:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our Condensed Consolidated Financial Statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our Condensed Consolidated Financial Statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 4 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part 1, Item 1A, Risk Factors, of the 2023 Form 10‑K and Part II, Item 1A, Risk Factors of this Form 10-Q.

[0000950170-24-057628:mdna:4]
Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to "ADTRAN", the “Company,” “we,” “us” and “our” refer to ADTRAN Holdings, Inc. and its consolidated subsidiaries. Furthermore, unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to “Adtran Networks” refer to Adtran Networks SE (formerly ADVA Optical Networking SE).

[0000950170-24-057628:mdna:5]
[same as prior period, unchanged from 0000950170-23-062173:mdna:5]

[0000950170-24-057628:mdna:6]
The Company is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Large, Medium and Small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies.

[0000950170-24-057628:mdna:7]
Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-24-057628:mdna:8]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end customer, especially upon the convergence of solutions at the network edge.

[0000950170-24-057628:mdna:9]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. In addition to operating under two reportable segments, the Company also reports revenue across three categories – Subscriber Solutions, Access & Aggregation Solutions and Optical Networking Solutions.

[0000950170-24-057628:mdna:10]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at customers' premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include our Mosaic One SaaS applications, fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers and cloud software solutions covering a mix of subscriber types.

[0000950170-24-057628:mdna:11]
[same as prior period, unchanged from 0000950170-23-062173:mdna:11]

[0000950170-24-057628:mdna:12]
[same as prior period, unchanged from 0000950170-23-062173:mdna:12]

[0000950170-24-057628:mdna:13]
[same as prior period, unchanged from 0000950170-23-062173:mdna:13]

[0000950170-24-057628:mdna:14]
[same as prior period, unchanged from 0000950170-23-062173:mdna:14]

[0000950170-24-057628:mdna:15]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is
entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated in 2023.

[0000950170-24-057628:mdna:16]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest (the "Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.59 (€0.52 net under the current tax regime) per share for each full fiscal year of Adtran Networks (the “Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component that was 3.62% as of March 31, 2024. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year, which is expected to occur on June 28, 2024 (but in any event within eight months following expiration of the fiscal year), and it will be payable for the first time after the ordinary general shareholders’ meeting of Adtran Networks in 2024 for the fiscal year ended December 31, 2023. The adequacy of both forms of compensation has been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

[0000950170-24-057628:mdna:17]
The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders.

[0000950170-24-057628:mdna:18]
In addition to our cash and cash equivalents and the credit facility, we may fund a portion or all of the Exit Compensation through the sale of securities or additional alternative funding sources, if available. There can be no assurances that we would be successful in effecting these actions on commercially reasonable terms or at all. If we cannot raise additional funds as needed, it could have a material adverse impact on our financial results and financial condition.

[0000950170-24-057628:mdna:19]
We currently hold 33,957,538 no-par value bearer shares of Adtran Networks, representing 65.32% of Adtran Networks outstanding shares as of March 31, 2024.

[0000950170-24-057628:mdna:20]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which incorporated by reference to Exhibit 10.7 included in our Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on March 15, 2024.

[0000950170-24-057628:mdna:21]
Multi-Year Integration Program

[0000950170-24-057628:mdna:22]
During the fourth quarter of 2022, the Company initiated a multi-year integration program designed to optimize the assets, business processes, and information technology systems of the Company. During the three months ended March 31, 2023, we recognized $2.4 million of integration costs related to the Business Combination, of restructuring costs relating to the Business Combination under the multi-year integration program that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss. We did not incur any costs related to our multi-year integration program in the three months ended March 31, 2024. The Company does not anticipate additional material expenses to be incurred in connection with this integration program. See Note 19 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-057628:mdna:23]
Business Efficiency Program

[0000950170-24-057628:mdna:24]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (the “Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expands upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment. Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). On October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze. Additionally, on April 11, 2024, management determined to close a facility in Greifswald, Germany. The closure of the facility is expected to be substantially completed by June 30, 2024.

[0000950170-24-057628:mdna:25]
During the three months ended March 31, 2024, we recognized $17.1 million of costs related to the Business Efficiency Program. The costs recognized during the three months ended March 31, 2024, included charges of $8.8 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.0 million relates to inventory write-downs and $4.8 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss. Since the inception of the Business Efficiency Program, we recognized $42.2 million of costs. We expect costs in the second quarter 2024 and thereafter relating to the Business Efficiency Program to range between $20.6 million and $35.8 million. Management expects these planned costs to include severance costs ranging from $17.3 million to $28.3 million in connection with an early retirement program and reductions in workforce and site consolidation transaction expenses (primarily brokers fees and Greifswald exit costs) ranging from $3.3 million to $7.5 million. Future cash payments include: severance costs and outplacement fees that are anticipated to be in the range of $18.1 million to $29.1 million and payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $3.1 million to $7.3 million. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures.  However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing. If required, we will amend this disclosure at such time as management is able in good faith to estimate the amount, or range of amounts, of these charges.

[0000950170-24-057628:mdna:26]
Business Combination Integration Costs

[0000950170-24-057628:mdna:27]
During the three months ended March 31, 2024 and 2023, we recognized $0.5 million and $0.8 million of integration costs related to the Business Combination, respectively, that are included in selling, general and administrative expenses, research & development expenses and cost of revenue in the Condensed Consolidated Statement of Loss. We expect to incur additional integration costs and expenses associated with the implementation of the DPLTA throughout 2024 and such costs are expected to be material. These costs are separate and apart from the costs associated with the integration program discussed above.

[0000950170-24-057628:mdna:28]
[same as prior period, unchanged from 0000950170-23-062173:mdna:30]

[0000950170-24-057628:mdna:29]
We ended the first quarter of 2024 with a year-over-year revenue decreased 30.2% as compared to the three months ended March 31, 2023, driven by decreased volume of sales activity due to customers' focus on reducing inventory levels and the continued macroeconomic environment impacting the spending behavior of our customers. During the first quarter of 2024, we had two customers with revenues greater than 10.0%, which were both international Service Provider customers and our five largest customers comprised 38.7% of our revenue. Our year-over-year domestic revenue decreased by 36.6% and continued to be impacted by macroeconomic factors and elevated inventory levels. Internationally, our year-over-year revenue decreased by 25.8%, primarily driven by the unfavorable impact on revenue as a result of the strengthened U.S. dollar and decreased shipments to two Large network operators and one alternative network operator in Europe.

[0000950170-24-057628:mdna:30]
The continuing macroeconomic environment and excess inventory in our industry impacted revenue in the first quarter of 2024. Access & Aggregation and Optical Networking revenue categories experienced a general slowdown in revenue as a result of reduced spending by our Service Provider customers as they continue to reduce inventory levels and monitor uncertain macroeconomic conditions related to continued elevated interest rates and ongoing inflationary pressures. Despite these challenges, we have maintained our emphasis on product development to enable us to respond to rapidly changing technology and evolving industry standards. For example, we expect public funding through projects such as IPCEI ME/CT to further our research and development for new communication technologies. Additionally, public funding through the Broadband Equity, Access and Deployment Program is expected to commence in late 2024 through 2026, which provides a positive outlook for the future. In Europe, we continue to see increased activity from high-risk vendor replacement and broadband subsidy programs.

[0000950170-24-057628:mdna:31]
Our operating results have fluctuated and may continue to fluctuate on a quarterly basis due to several factors, including customer order activity, prior supply chain constraints, component availability, and the Company's consolidation and integration with Adtran Networks. Further, a significant percentage of orders require delivery within a few days requiring us to maintain higher inventory levels. These factors may result in limited order flow visibility. For example, although, expedite fees and lead times for semiconductor chips and other key components began to ease during 2023 following shortages in the industry, we continued to be negatively impacted by price increases, which could continue to have a material adverse effect on customer relations and our financial condition. We have taken decisive steps to transform our business into a leaner, more efficient and more profitable company, including through the implementation of a Business Efficiency Program, which includes a significant cost efficiency program targeting a reduction of ongoing operating expenses and a capital efficiency program inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. Nevertheless, our operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues has and may again in the future significantly impact our financial results in a given quarter.

[0000950170-24-057628:mdna:32]
Our operating results have significantly fluctuated and may do so in the future as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, inflation, regional conflicts, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. In recent years, inflationary pressures on input costs, such as raw materials and labor, and distribution costs had a negative impact on our operating results. However, inflationary pressures on our supply chain have eased somewhat, which has led to reductions in cost premiums on raw material costs and freight. We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors, and customers to address and to limit the disruption to our operations and order fulfillment. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an additional adverse effect on our business and operating results beyond the effects of the most recent inventory write-downs. Also, not maintaining sufficient inventory levels to ensure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results.

[0000950170-24-057628:mdna:33]
[same as prior period, unchanged from 0000950170-23-062173:mdna:37]

[0000950170-24-057628:mdna:34]
The Company’s policy is to assess the realizability of assets (long-lived assets, intangibles and goodwill) held within our reporting units and to evaluate such assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. During the third quarter of 2023, the Company identified a triggering event due to a decrease in its market capitalization and changes in projections (decrease in estimated cash flows). While the quantitative impairment analysis indicated that there was no impairment of Network Solutions goodwill, the Company determined a $37.9 million non-cash impairment charge for goodwill was warranted for the Services & Support reporting unit. During the fourth quarter of 2023, the Company completed its annual impairment test. There were no significant market changes or changes to cash flow projections, as such no triggering event was identified during the fourth quarter of 2023. During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of the Network Solutions reporting unit using a combination of an income approach and a market based peer group analysis. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit during the three months ended March 31, 2024. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the three months ended March 31, 2024.

[0000950170-24-057628:mdna:35]
Our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Part I, Item 1A of the 2023 Form 10-K and Part II, Item 1A of this Form 10-Q.

[0000950170-24-057628:mdna:36]
[same as prior period, unchanged from 0000950170-23-062173:mdna:40]

[0000950170-24-057628:mdna:37]
[same as prior period, unchanged from 0000950170-23-062173:mdna:41]

[0000950170-24-057628:mdna:38]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2024 COMPARED TO THE THREE MONTHS ENDED MARCH 31, 2023

[0000950170-24-057628:mdna:39]
[same as prior period, unchanged from 0000950170-23-062173:mdna:44]

[0000950170-24-057628:mdna:40]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2024 |  |  | 2023 |  |  |
| Revenue |  |  |  |  |  |  |  |
| Network Solutions |  |  | 80.1 |  | % |  | 87.2 |  | % |
| Services & Support |  |  | 19.9 |  |  |  | 12.8 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |
| Network Solutions |  |  | 55.9 |  |  |  | 67.7 |  |  |
| Network Solutions - inventory write-down and other charges |  |  | 3.9 |  |  |  | — |  |  |
| Services & Support |  |  | 8.3 |  |  |  | 5.2 |  |  |
| Total Cost of Revenue |  |  | 68.1 |  |  |  | 72.9 |  |  |
| Gross Profit |  |  | 31.9 |  |  |  | 27.1 |  |  |
| Selling, general and administrative expenses |  |  | 26.1 |  |  |  | 20.8 |  |  |
| Research and development expenses |  |  | 26.6 |  |  |  | 21.7 |  |  |
| Goodwill impairment |  |  | 129.4 |  |  |  | — |  |  |
| Operating Loss |  |  | (150.2 | ) |  |  | (15.4 | ) |  |
| Interest and dividend income |  |  | 0.2 |  |  |  | 0.1 |  |  |
| Interest expense |  |  | (2.0 | ) |  |  | (1.0 | ) |  |
| Net investment gain |  |  | 1.0 |  |  |  | 0.4 |  |  |
| Other income (expense), net |  |  | 0.6 |  |  |  | (0.1 | ) |  |
| Loss Before Income Taxes |  |  | (150.5 | ) |  |  | (16.0 | ) |  |
| Income tax benefit |  |  | 8.2 |  |  |  | 3.5 |  |  |
| Net Loss |  |  | (142.2 | ) | % |  | (12.5 | ) | % |
| Less: Net Income (loss) attributable to non-controlling interest |  |  | 1.3 |  |  |  | (0.1 | ) |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | (143.5 | ) | % |  | (12.4 | ) | % |

[0000950170-24-057628:mdna:41]
[same as prior period, unchanged from 0000950170-23-062173:mdna:46]

[0000950170-24-057628:mdna:42]
Our revenue decreased 30.2% from $323.9 million for the three months ended March 31, 2023 to $226.2 million for the three months ended March 31, 2024. The decrease in revenue for the three months ended March 31, 2024 is primarily driven by decrease in volume of sales activity due to customers’ focus on reducing inventory levels and the completion of significant customer projects. The decrease in revenue by category for the three months ended March 31, 2024 was primarily attributable to a $72.7 million decrease in Optical Networking Solutions products, a $15.5 million decrease in Access & Aggregation revenue and a $9.6 million decrease in Subscriber Solutions products. Continued customer concerns over inventory stocking levels have affected our revenue in the first quarter in our Optical Networking Solutions category, Access & Aggregation category and our Subscriber Solutions category. We believe that the over-supply of CPE products will continue into the second quarter of 2024.

[0000950170-24-057628:mdna:43]
Network Solutions segment revenue decreased 35.8% from $282.4 million for the three months ended March 31, 2023 to $181.3 million for the three months ended March 31, 2024. The decrease in Network Solutions revenue for the three months ended March 31, 2024 was due to a decrease of $74.5 million in volume of sales activity in Optical Networking products, a decrease of $16.8 million in volume of sales activity in Access & Aggregation products and a decrease of $9.9 million in volume of sales activity in Subscriber Solutions products.

[0000950170-24-057628:mdna:44]
Services & Support segment revenue increased 8.2% from $41.5 million for the three months ended March 31, 2023 to $44.9 million for the three months ended March 31, 2024. The increase in revenue for the three months ended March 31, 2024 was primarily attributable a $1.8 million increase in revenue for Optical Networking products, a $1.3 million increase in revenue for Access & Aggregation revenue and a $0.3 million increase in revenue for Subscriber Solutions services. More specifically, the increase in revenue for the three months ended March 31, 2024 of our ADTRAN, Inc. operations was primarily due to higher volume of sales of our software services and business solutions services.

[0000950170-24-057628:mdna:45]
Domestic revenue decreased by 36.6% from $131.5 million for the three months ended March 31, 2023 to $83.3 million for the three months ended March 31, 2024. The decrease in domestic revenue for the three months ended March 31, 2024 was primarily due to lower volume of sales of our residential solutions products as a result of customers focus on reducing inventory levels across all revenue categories.

[0000950170-24-057628:mdna:46]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., decreased by 25.8% from $192.4 million for the three months ended March 31, 2023 to $142.9 million for the three months ended March 31, 2024. International revenue, as a percentage of total revenue, increased from 59.4% for the three months ended March 31, 2023 to 63.2% for the three months ended March 31, 2024. The decrease in international revenue for the three months ended March 31, 2024 was primarily due to the conclusion of specific customer projects and customer concerns over inventory stocking levels. While international revenue has increased to approximately 63.2% of total revenues for the three months ended March 31, 2024, the mix of our Network Solutions and Services & Support segments as a percentage of total international revenue remains relatively linear. For the three months ended March 31, 2024 as compared to the three months ended March 31, 2023, changes in foreign currencies relative to the U.S. dollar increased our net revenue by approximately $2.2 million.

[0000950170-24-057628:mdna:47]
Our ADTRAN, Inc. international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and, in some instances, regionally – whether of a multi-country region or a more local region within a country. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above have resulted in and may continue to result in pressure on revenue and operating income. Our Adtran Networks international revenue is largely focused on the manufacture and selling of networking solutions that are based on three core areas of expertise: fiber-optic transmission technology (cloud interconnect), cloud access technology for rapid creation of innovative services around the network edge and solutions for precise timing and synchronization of networks. In addition, Adtran Networks international operations offers a comprehensive portfolio of network design, implementation and maintenance services to assist operators in the deployment of market-leading networks while reducing costs to maintain these networks.

[0000950170-24-057628:mdna:48]
[same as prior period, unchanged from 0000950170-23-062173:mdna:56]

[0000950170-24-057628:mdna:49]
As a percentage of revenue, cost of revenue decreased from 72.9% for the three months ended March 31, 2023 to 68.1% for the three months ended March 31, 2024. The decrease for the three months ended March 31, 2024 was attributable to a 4.9% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, and a 5.0% decrease in expense as a percentage of revenue related to decreased acquisition costs, partially offset by a 5.0% increase in expense as a percentage of revenue in connection with our Business Efficiency Program, which resulted in an inventory write down and other charges of $8.8 million incurred as a result of a strategy shift which included discontinuance of certain product lines. For the three months ended March 31, 2024 as compared to the three months ended March 31, 2023, changes in foreign currencies relative to the U.S. dollar increased our cost of revenue by approximately $0.5 million.

[0000950170-24-057628:mdna:50]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, decreased from 77.6% for the three months ended March 31, 2023 to 74.5% for the three months ended March 31, 2024. The decrease in cost of revenue as a percentage of revenue for the three months ended March 31, 2024 was attributable to a 6.1% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks and a 6.2% decrease in expense as a percentage of revenue related to decreased acquisition costs, partially offset by a 6.1% increase in expense as a percentage of revenue in connection with our Business Efficiency Program, which resulted in an inventory write down and other charges of $8.8 million incurred as a result of a strategy shift which included discontinuance of certain product lines and a 3.2% increase in expense as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-24-057628:mdna:51]
Services & Support cost of revenue, as a percentage of that segment’s revenue, increased from 40.9% for the three months ended March 31, 2023 to 41.9% for the three months ended March 31, 2024. The increase in cost of revenue as a percentage of revenue for the three months ended March 31, 2024 was primarily attributable to changes in customer and product mix.

[0000950170-24-057628:mdna:52]
[same as prior period, unchanged from 0000950170-23-062173:mdna:60]

[0000950170-24-057628:mdna:53]
[same as prior period, unchanged from 0000950170-23-062173:mdna:61]

[0000950170-24-057628:mdna:54]
As a percentage of revenue, gross profit increased from 27.1% for the three months ended March 31, 2023 to 31.9% for the three months ended March 31, 2024. The increase for the three months ended March 31, 2024 was attributable to a 4.9% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, and a 5.0% increase in gross profit as a percentage of revenue related to decreased acquisition costs, partially offset by a 5.0% decrease in gross profit as a percentage of revenue in connection with increased expenses with our Business Efficiency Program, which resulted in an inventory

[0000950170-24-057628:mdna:55]
write down and other charges of $8.8 million incurred as a result of a strategy shift which included discontinuance of certain product lines.

[0000950170-24-057628:mdna:56]
As a percentage of that segment's revenue, Network Solutions gross profit increased from 22.4% for the three months ended March 31, 2023 to 25.5% for the three months ended March 31, 2024. The increase was attributable to a 6.1% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks and a 6.2% increase in gross profit as a percentage of revenue related to decreased acquisition costs, partially offset by a 6.1% decrease in gross profit as a percentage of revenue in connection with increased expenses with our Business Efficiency Program, which resulted in an inventory write down and other charges of $8.8 million incurred as a result of a strategy shift which included discontinuance of certain product lines and a 3.1% decrease in gross profit as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-24-057628:mdna:57]
As a percentage of that segment's revenue, Services & Support gross profit decreased from 59.1% for the three months ended March 31, 2023 to 58.1% for the three months ended March 31, 2024. The decrease was primarily attributable to changes in customer and product mix.

[0000950170-24-057628:mdna:58]
[same as prior period, unchanged from 0000950170-23-062173:mdna:65]

[0000950170-24-057628:mdna:59]
As a percentage of revenue, selling, general and administrative expenses increased from 20.8% for the three months ended March 31, 2023 to 26.1% for the three months ended March 31, 2024. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared. We are still in the process of implementing our Business Efficiency Program, which we expect will lower selling, general and administrative expense as a percentage of revenue over time.

[0000950170-24-057628:mdna:60]
Selling, general and administrative expenses decreased 12.3% from $67.4 million for the three months ended March 31, 2023 to $59.1 million for the three months ended March 31, 2024. Selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The decrease in selling, general and administrative expenses for the three months ended March 31, 2024 was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $6.8 million, travel expenses by $1.4 million, and depreciation of property, plant and equipment by $0.4 million. For the three months ended March 31, 2024 as compared to the three months ended March 31, 2023, changes in foreign currencies relative to the U.S dollar increased our selling, general and administrative expenses by approximately $0.5 million.

[0000950170-24-057628:mdna:61]
[same as prior period, unchanged from 0000950170-23-062173:mdna:68]

[0000950170-24-057628:mdna:62]
As a percentage of revenue, research and development expenses increased from 21.7% for the three months ended March 31, 2023 to 26.6% for the three months ended March 31, 2024. Research and development expenses as a percentage of revenue will generally fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared. We are still in the process of implementing our Business Efficiency Program, which we expect will lower research and development expense as a percentage of revenue over time

[0000950170-24-057628:mdna:63]
Research and development expenses decreased 14.1% from $70.1 million for the three months ended March 31, 2023 to $60.3 million for the three months ended March 31, 2024. The decrease in research and development expenses was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $1.6 million and contract services by $2.7 million. For the three months ended March 31, 2024 as compared to the three months ended March 31, 2023, changes in foreign currencies relative to the U.S. dollar increased our research and development expenses by approximately $0.6 million.

[0000950170-24-057628:mdna:64]
Adtran Networks has arrangements with governmental entities for the purpose of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the three months ended March 31, 2024 and 2023, the Company recognized $1.9 million and $0.6 million as a reduction of research and development expense, respectively.

[0000950170-24-057628:mdna:65]
[same as prior period, unchanged from 0000950170-23-062173:mdna:72]

[0000950170-24-057628:mdna:66]
[same as prior period, unchanged from 0000950170-23-062173:mdna:73]

[0000950170-24-057628:mdna:67]
The Company’s policy is to assess the realizability of assets (long-lived assets, intangibles and goodwill) held within our reporting units and to evaluate such assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer focus on inventory adjustments, triggered a

[0000950170-24-057628:mdna:68]
quantitative impairment assessment for our reporting units. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit. No impairment of goodwill was recorded for our Services & Support reporting unit during the three months ended March 31, 2024. No impairment of goodwill was recorded for either reporting unit during the three months ended March 31, 2023.

[0000950170-24-057628:mdna:69]
[same as prior period, unchanged from 0000950170-23-062173:mdna:77]

[0000950170-24-057628:mdna:70]
Interest and dividend income increased from $0.3 million for the three months ended March 31, 2023 to $0.4 million for the three months ended March 31, 2024. The increase in interest and dividend income is primarily attributable to fluctuations in investment balances and an increase in the rate of return on those investments due to interest rate movements.

[0000950170-24-057628:mdna:71]
[same as prior period, unchanged from 0000950170-23-062173:mdna:79]

[0000950170-24-057628:mdna:72]
Interest expense increased from $3.3 million for the three months ended March 31, 2023 to $4.6 million for the three months ended March 31, 2024. The increase in interest expense during the three months ended March 31, 2024 was primarily driven by higher average borrowings outstanding versus the three months ending March 31, 2023 and the amortization of debt issuance costs. See Note 11 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-24-057628:mdna:73]
NET INVESTMENT GAIN

[0000950170-24-057628:mdna:74]
We recognized a net investment gain of $1.3 million and $2.3 million for the three months ended March 31, 2023 and 2024, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See Note 5 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-24-057628:mdna:75]
OTHER (EXPENSE) INCOME, NET

[0000950170-24-057628:mdna:76]
Other (expense) income, net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, increased from an expense of $0.3 million for the three months ended March 31, 2023 to income of $1.3 million for the three months ended March 31, 2024.

[0000950170-24-057628:mdna:77]
[same as prior period, unchanged from 0000950170-23-062173:mdna:85]

[0000950170-24-057628:mdna:78]
The Company's effective tax rate changed from a benefit of 21.9% of pre-tax loss for the three months ended March 31, 2023, to a benefit of 5.5% of pre-tax loss for the three months ended March 31, 2024. The change in the effective tax rate for the three months ended March 31, 2024, was driven primarily by a loss jurisdiction for which no tax benefits were recognized on the Company’s pre-tax losses during the first quarter of 2024.

[0000950170-24-057628:mdna:79]
[same as prior period, unchanged from 0000950170-23-062173:mdna:88]

[0000950170-24-057628:mdna:80]
As a result of the above factors, net loss attributable to ADTRAN Holdings, Inc. increased from net loss of $40.1 million for the three months ended March 31, 2023 to a net loss of $324.6 million for the three months ended March 31, 2024.

[0000950170-24-057628:mdna:81]
[same as prior period, unchanged from 0000950170-23-062173:mdna:90]

[0000950170-24-057628:mdna:82]
We have historically financed our ongoing business with existing cash, investments and cash flow from operations. We had a net operating cash inflow in the three months ended March 31, 2024. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures. In addition, we have increasingly relied upon our credit arrangements to manage our working capital needs.

[0000950170-24-057628:mdna:83]
As of March 31, 2024, our cash on hand was $106.8 million of which $86.7 million was held by our foreign subsidiaries. The Company had access to $203.0 million on its Credit Facility for future borrowings; however, as of March 31, 2024, the Company was limited to additional borrowings of $22.7 million based on debt covenant compliance metrics. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax. As of December 31, 2023, our cash on hand was $87.2 million, of which $73.0 million was held by our foreign subsidiaries.

[0000950170-24-057628:mdna:84]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of March 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.9 million or approximately $365.7 million, based on an exchange rate as of March 31, 2024 and reflecting interest accrued through March 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-057628:mdna:85]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.5 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2024 and 2023, we accrued $2.9 million and $2.8 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit with the offset in other non-current liability and accrued expenses and other liabilities, respectively, in our Condensed Consolidated Balance Sheets. With respect to the year ended December 31, 2023, we are obligated to pay $11.5 million in Annual Recurring Compensation on the third banking day following the 2024 ordinary general shareholders’ meeting of Adtran Networks, which is expected to occur on June 28, 2024 (but in any event within eight months following December 31, 2023).

[0000950170-24-057628:mdna:86]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”), which has since been amended three times. Pursuant to the terms of the Credit Agreement, as amended, the Company, ADTRAN, Inc., and the subsidiary guarantors (together, the “Credit Parties”) are subject to a liquidity covenant, which provides that, during the fourth quarter of 2023 through and including the third quarter of 2024 (the "Covenant Relief Period") or a Springing Covenant Period, (i.e., the period beginning upon the purchase by the Company of at least 60% of the outstanding shares of Adtran Networks not owned by the Company as of August 9, 2023 and the three consecutive quarterly test periods after such date), as of the last day of any fiscal quarter, the cash and cash equivalents of the Credit Parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million, limiting our ability to pay the obligations under the DPLTA. See below, as well as Note 11 of Notes to Condensed Consolidated Financial Statements included in Part I, Item, 1 for additional information regarding the terms of each amendment to the Wells Fargo Credit Agreement.

[0000950170-24-057628:mdna:87]
As of March 31, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-32 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks shares.

[0000950170-24-057628:mdna:88]
The Company experienced revenue declines in the year ended December 31, 2023 and during the three months ended March 31, 2024. To the extent that the Company is further impacted by the uncertain macroeconomic environment related to continued elevated interest rates and ongoing inflationary pressures, the Company has established plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a Business Efficiency Program, which includes, but is not limited to planned reductions in operating expenses and a site consolidation plan. In connection with the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

[0000950170-24-057628:mdna:89]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo Credit Facility (described below), including (i) the additional funding provided for under the First Amendment to the Wells Fargo Credit Facility that was signed on August 9, 2023, (ii) the additional covenant headroom

[0000950170-24-057628:mdna:90]
44

[0000950170-24-057628:mdna:91]
during the Covenant Relief Period provided for under the Second Amendment to Wells Fargo Credit Facility, and (iii) the exclusion of the Factoring Agreement as debt for purposes of the Credit Facility’s financial covenants as provided for under the Third Amendment to Wells Fargo Credit Facility (each as described below), will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and ability to continue to comply with our debt covenants under the Credit Facility for at least the next twelve months, from the issuance of these financial statements. See Note 11, Revolving Credit Agreements, for additional information regarding the terms of the First, Second and Third Amendments of the Wells Fargo Credit agreement and Notes to Condensed Consolidated Financial Statements included in Part I, Item, 1 for additional information regarding the terms of the Wells Fargo Credit Agreement, as amended.

[0000950170-24-057628:mdna:92]
Wells Fargo Credit Facility

[0000950170-24-057628:mdna:93]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount, as well as the $50.0 million delayed draw term loan facility described below.

[0000950170-24-057628:mdna:94]
On August 9, 2023, (the "First Amendment Effective Date") the Company, its wholly-owned direct subsidiary, ADTRAN, Inc. and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and together with the Credit Agreement, the "Credit Facility").

[0000950170-24-057628:mdna:95]
The First Amendment, provided for, among other things, a new $50.0 million delayed draw term loan (“DDTL”), which (subject to certain conditions) is available for borrowing in the event of the purchase by the Company of at least sixty percent (60.0%) of the outstanding shares of Adtran Networks SE that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks SE. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through August 9, 2024.

[0000950170-24-057628:mdna:96]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-24-057628:mdna:97]
On January 16, 2024, the Company entered into a Second Amendment to the Credit Agreement and First Amendment to the Collateral Agreement. The Second Amendment, among other things, provided the Company and its subsidiaries with additional covenant headroom for the fourth quarter of 2023 through the third quarter of 2024 (the "Covenant Relief Period") and added certain other financial covenants which are described below.

[0000950170-24-057628:mdna:98]
On March 12, 2024, the Company entered into a Third Amendment to the Credit Agreement. The Third Amendment, among other things, amends the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024 and June 30, 2024.

[0000950170-24-057628:mdna:99]
As of March 31, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $195.0 million. As of March 31, 2024, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. In addition, we may issue up to $50.0 million in letters of credit against our $400.0 million total facility. As of March 31, 2024, we had a total of $2.0 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $203.0 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of March 31, 2024, the Company was in compliance with all covenants.

[0000950170-24-057628:mdna:100]
[same as prior period, unchanged from 0000950170-23-062173:mdna:102]

[0000950170-24-057628:mdna:101]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin) bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.15% per annum).

[0000950170-24-057628:mdna:102]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.

[0000950170-24-057628:mdna:103]
“Adjusted Term SOFR” means Term SOFR for the applicable interest period plus 0.10% per annum. Adjusted Term SOFR is subject to a floor of 0.00% per annum.

[0000950170-24-057628:mdna:104]
All Euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.25% per annum).

[0000950170-24-057628:mdna:105]
In addition, (x) if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-057628:mdna:106]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

[0000950170-24-057628:mdna:107]
The increases in the commitment fee and margin rates during the Covenant Relief Period (referenced above) continue until the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the (“Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, the Company has repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the Company has reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) the Company is in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-24-057628:mdna:108]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

[0000950170-24-057628:mdna:109]
[same as prior period, unchanged from 0000950170-23-062173:mdna:105]

[0000950170-24-057628:mdna:110]
All U.S. dollar borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.90% to 1.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.40% per annum), or (B) Adjusted Term SOFR plus an applicable margin ranging from 1.90% to 2.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.40% per annum).

[0000950170-24-057628:mdna:111]
In addition, (x) if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-057628:mdna:112]
In addition to paying interest on outstanding principal under the DDTL loan, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment.

[0000950170-24-057628:mdna:113]
The increases in the commitment fee and margin rates during the Covenant Relief Period (referenced above) continue until the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the (“Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, the Company has repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the Company has reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) the Company is in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-24-057628:mdna:114]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

[0000950170-24-057628:mdna:115]
Covenants Under the Credit Agreement

[0000950170-24-057628:mdna:116]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable):

[0000950170-24-057628:mdna:117]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Total Net Leverage Ratio may not exceed 5.00x.

[0000950170-24-057628:mdna:118]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

[0000950170-24-057628:mdna:119]
•
In the event of the purchase by the Company of at least sixty percent (60%) of the outstanding shares of Adtran Networks SE not owned by the Company as of August 9, 2023 that have been tendered (such event, a “Springing Covenant Event” and the fiscal quarter in which the Springing Covenant Event Occurs and the three consecutive quarterly test periods thereafter, the “Springing Covenant Period”), the following covenant levels:

[0000950170-24-057628:mdna:120]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

[0000950170-24-057628:mdna:121]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

[0000950170-24-057628:mdna:122]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

[0000950170-24-057628:mdna:123]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50,000,000 in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

[0000950170-24-057628:mdna:124]
•
If a Springing Covenant Period is not in effect, the following covenant levels:

[0000950170-24-057628:mdna:125]
•
From December 31, 2023 through and including March 31, 2024: 3.25x.

[0000950170-24-057628:mdna:126]
•
From April 1, 2024 through and including June 30, 2024: 3.50x.

[0000950170-24-057628:mdna:127]
•
From July 1, 2024 and thereafter: 3.25x.

[0000950170-24-057628:mdna:128]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not exceed 1.25x.

[0000950170-24-057628:mdna:129]
•
During the Covenant Relief Period or a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million.

[0000950170-24-057628:mdna:130]
The Credit Agreement is guaranteed by certain domestic subsidiaries of the Company, and the Company is also required to add certain additional domestic and international subsidiaries as guarantors under the Credit Agreement (such existing and new guarantors, collectively, the “Guarantors”). In addition to the guarantees provided by the Guarantors, the Guarantors have granted (or will grant) security interests in favor of the Administrative Agent over substantially all tangible and intangible assets, and the Borrower will grant mortgages in favor of the Administrative Agent over certain owned real estate assets. The Company is currently in negotiations with the Administrative Agent regarding a potential further amendment to the Credit Agreement to address the addition of certain foreign subsidiary guarantors.

[0000950170-24-057628:mdna:131]
The Credit Agreement provides for revolving borrowings of up to $400.0 million in aggregate principal amount, as well as an additional $50.0 million delayed draw term loan tranche that would be available upon a Springing Covenant Event. It also continues to permit the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement subject to certain limitations and minimum payment thresholds.

[0000950170-24-057628:mdna:132]
During the Covenant Relief Period, the Company is not permitted to make certain dividend payments to the Company's Stockholders or certain other Restricted Payments. However, the Company is permitted to make the Recurring Compensation Payment to each Adtran Networks shareholder (other than the Company), pursuant to the terms of the DPLTA. See Note 20 for additional information.

[0000950170-24-057628:mdna:133]
Furthermore, the Credit Agreement, as amended, contain customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts; however, certain of the exceptions and carveouts are not permitted to be used during the Covenant Relief Period. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.

[0000950170-24-057628:mdna:134]
[same as prior period, unchanged from 0000950170-23-062173:mdna:116]

[0000950170-24-057628:mdna:135]
Net cash provided by operating activities of $36.6 million during the three months ended March 31, 2024 improved by $56.5 million compared to net cash used in operating activities of $19.9 million during the three months ended March 31, 2023. The increase was primarily due to the net loss for the three months ended March 31, 2024 and 2023 remaining flat, excluding the goodwill impairment charge at March 31, 2024 of $292.6 million, as adjusted primarily for decreased depreciation, decreased deferred taxes and increased net cash inflows from working capital. Additional details related to our working capital and its drivers are discussed below.

[0000950170-24-057628:mdna:136]
Net accounts receivable decreased 13.3% from $216.4 million as of December 31, 2023 to $187.6 million as of March 31, 2024. There was an allowance for credit losses of $0.4 as of March 31, 2024 and December 31, 2023. The decrease in net accounts receivable was due primarily to improved collections. Quarterly accounts receivable DSO decreased from 88 days as of December 31, 2023 to 75 days as of March 31, 2024. The decrease in DSO was primarily driven by customer and geographical mix of commercial terms.

[0000950170-24-057628:mdna:137]
Other receivables decreased 30.6% from $17.5 million as of December 31, 2023 to $12.1 million as of March 31, 2024. The decrease in other receivables was primarily attributable to a decrease for sales of raw materials.

[0000950170-24-057628:mdna:138]
Quarterly inventory turnover was 2.07 turns as of December 31, 2023 and 1.8 turns as of March 31, 2024. Inventory decreased 11.1% from $362.3 million as of December 31, 2023 to $322.1 million as of March 31, 2024. The decrease in inventory was primarily due to a $4.0 million write down of inventory due to a restructuring discontinuation of certain product lines within our Network Solutions segment, a reduction in component purchases due to improved lead times and utilization of buffer stock. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory for customer demand and improve working capital.

[0000950170-24-057628:mdna:139]
Accounts payable decreased 2.4% from $162.9 million as of December 31, 2023 to $159.1 million as of March 31, 2024. The decrease in accounts payable was primarily due to a decrease in the average number of days payable to our trade suppliers. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-24-057628:mdna:140]
[same as prior period, unchanged from 0000950170-23-062173:mdna:123]

[0000950170-24-057628:mdna:141]
Capital expenditures totaled approximately $13.4 million and $8.4 million for the three months ended March 31, 2024 and 2023, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements. The increase in capital expenditures for the three months ended March 31, 2024 is primarily attributable to increases in expenditures related to software and building renovation projects.

[0000950170-24-057628:mdna:142]
Our long-term investments increased 5.4% from $27.7 million as of December 31, 2023 to $29.3 million as of March 31, 2024. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $0.9 million and $1.0 million as of March 31, 2024 and December 31, 2023, respectively. Long-term investments as of March 31, 2024 and December 31, 2023 also included $28.3 million and $26.8 million, respectively, related to our deferred compensation plans. See Note 5 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0000950170-24-057628:mdna:143]
[same as prior period, unchanged from 0000950170-23-062173:mdna:129]

[0000950170-24-057628:mdna:144]
During the three months ended March 31, 2023, we paid dividends totaling $7.1 million. On November 6, 2023, the Board of Directors suspended the Company’s quarterly cash dividend which in order to reduce debt and interest expense and support the Company's capital efficiency program. We consequently did not pay any dividends during the three months ended March 31, 2024. The payment of any future dividends will be at the discretion of the Board of Directors and will depend on the Company’s financial condition, results of operations, capital requirements, and any other factors deemed relevant by the Board of Directors. In addition, the Wells Fargo Credit Agreement currently does not allow for the payment of dividends to shareholders. For additional information, see Note 11 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report and Liquidity & Capital Resources above.

[0000950170-24-057628:mdna:145]
[same as prior period, unchanged from 0000950170-23-062173:mdna:131]

[0000950170-24-057628:mdna:146]
There were no stock repurchases during the periods ended March 31, 2024 and 2023, and there currently is no authorized stock repurchase program.

[0000950170-24-057628:mdna:147]
[same as prior period, unchanged from 0000950170-23-062173:mdna:133]

[0000950170-24-057628:mdna:148]
To accommodate employee stock option exercises, the Company issued 36 thousand and 6 thousand shares of common stock which resulted in proceeds of $0.2 million and $0.1 million during the three months ended March 31, 2024 and 2023, respectively.

[0000950170-24-057628:mdna:149]
Pension Plans

[0000950170-24-057628:mdna:150]
We maintain defined benefit pension plans covering employees in certain foreign countries. The Company's net non-current pension liability for all defined benefit pension plans totaled $11.7 million and $12.5 million as of March 31, 2024 and December 31, 2023, respectively and the net current pension liability for all defined benefit pension plans totaled $0.1 million as of March 31, 2024 and December 31, 2023, which is included in accounts payable on the Condensed Consolidated Balance Sheets. For additional information, see Note 12 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-24-057628:mdna:151]
Deferred Compensation Programs

[0000950170-24-057628:mdna:152]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors. The fair value of the assets held by the deferred compensation programs totaled $28.5 million and $26.8 million as of March 31, 2024 and December 31, 2023, respectively, and is included in long-term investments on the Condensed Consolidated Balance Sheets. The amounts payable to the deferred compensation program participants totaled $29.7 million and $29.0 million as of March 31, 2024 and December 31, 2023, respectively. For additional information, see Note 5 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-24-057628:mdna:153]
[same as prior period, unchanged from 0000950170-23-062173:mdna:135]

[0000950170-24-057628:mdna:154]
We have exposure to credit losses from off-balance sheet exposures, to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of March 31, 2024. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 18 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-057628:mdna:155]
[same as prior period, unchanged from 0000950170-23-062173:mdna:137]

[0000950170-24-057628:mdna:156]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of March 31, 2024, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA and currency hedging arrangements, which are discussed below). Other than operating lease obligations, the cash requirements table excludes interest payments.

[0000950170-24-057628:mdna:157]
| (In thousands) |  | Total |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | 2028 |  |  | Thereafter |  |
| Wells Fargo credit agreement(1) |  | $ | 195,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 195,000 |  |  | $ | — |  |  | $ | — |  |
| Secured borrowings related to accounts receivable(2) |  |  | 12,620 |  |  |  | 12,620 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations(3) |  |  | 237,989 |  |  |  | 201,867 |  |  |  | 31,742 |  |  |  | 4,325 |  |  |  | 55 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations(4) |  |  | 41,139 |  |  |  | 6,534 |  |  |  | 7,699 |  |  |  | 6,091 |  |  |  | 4,560 |  |  |  | 4,274 |  |  |  | 11,981 |  |
| Totals |  | $ | 486,748 |  |  | $ | 221,021 |  |  | $ | 39,441 |  |  | $ | 10,416 |  |  | $ | 199,615 |  |  | $ | 4,274 |  |  | $ | 11,981 |  |

[0000950170-24-057628:mdna:158]
[same as prior period, unchanged from 0000950170-23-062173:mdna:140]

[0000950170-24-057628:mdna:159]
(2) Secured borrowings related to our accounts receivable factoring agreement that are expected to be repaid within 12 months.

[0000950170-24-057628:mdna:160]
[same as prior period, unchanged from 0000950170-23-062173:mdna:142]

[0000950170-24-057628:mdna:161]
partners and other vendors. The settlement of our purchase obligations will occur at various dates beginning in 2024 and going

[0000950170-24-057628:mdna:162]
through 2028. See Note 18 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report

[0000950170-24-057628:mdna:163]
[same as prior period, unchanged from 0000950170-23-062173:mdna:145]

[0000950170-24-057628:mdna:164]
[same as prior period, unchanged from 0000950170-23-062173:mdna:146]

[0000950170-24-057628:mdna:165]
locations. Our operating leases had remaining lease terms ranging from 2 months to 114 months as of March 31, 2024.

[0000950170-24-057628:mdna:166]
[same as prior period, unchanged from 0000950170-23-062173:mdna:96]

[0000950170-24-057628:mdna:167]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into the Credit Agreement with the Administrative Agent and the other lenders named therein. The Credit Agreement was subsequently amended on August 9, 2023, January 16, 2024, and March 12, 2024. The Credit Agreement provides for a revolving line of credit and a DDTL. As of March 31, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $195.0 million. As of March 31, 2024, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. See Note 11 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report and “Liquidity and Capital Resources” in Part I, Item 2 of this report for additional information.

[0000950170-24-057628:mdna:168]
[same as prior period, unchanged from 0000950170-23-062173:mdna:159]

[0000950170-24-057628:mdna:169]
On November 3, 2022, the Company entered into a euro/U.S. dollar forward contract arrangement (the "Initial Forward") with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million for U.S. dollars at a daily fixed forward rate ranging from $1.01 to $1.03. The aggregate amount of €160.0 million is divided into eight quarterly tranches of €20.0 million, which commenced in the fourth quarter of 2022. During the three months ended March 31, 2024, the Company settled one €20.0 million forward contract tranches and the remaining amount will be divided into three quarterly tranches of €20.0 million over the remainder of 2024. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-24-057628:mdna:170]
On March 21, 2023, the Company entered into a euro/U.S. dollar forward contract arrangement (the “Forward”) with the Hedge Counterparty. Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of €160.0 million U.S. dollars for euros at a daily fixed forward rate ranging from $1.09 to $1.10 per €1.00. During the three months ended March 31, 2024, the Company settled one $20.0 million forward contract tranches and the remaining amount will be divided into three quarterly tranches of $20.0 million. These forward contracts were executed on March 21, 2023 (to sell EUR/buy USD) and were entered into for the purpose of unwinding the Initial Forward (to buy EUR/sell USD). The drawdown dates of the Initial Forward are set to the same date as the maturity of the new offsetting Forward.

[0000950170-24-057628:mdna:171]
Receivables Purchase Arrangements

[0000950170-24-057628:mdna:172]
The Company was party to a receivable purchase agreement with a third-party financial institution, which accelerates receivable collection and helps to better manage cash flow. As of December 31, 2023 no accounts receivable were factored under the agreement or held in the reserve account. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months ended March 31, 2023.

[0000950170-24-057628:mdna:173]
On December 19, 2023, the agreement with the Factor was terminated and the Company entered into a receivables purchase agreement with a third-party financial institution (the “New Factor”) to replace the Company’s prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The New Factor provides for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The New Factor qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. Total secured borrowings under the agreement were $12.6 million and $14.3 million as of March 31, 2024 and December 31, 2023, respectively, leaving $27.2 million and $25.4 million available for future borrowings as of March 31, 2024 and December 31, 2023, respectively. Accounts receivable pledged as collateral related to the secured borrowings were $16.4 million and $16.8 million as of March 31, 2024 and December 31, 2023, respectively. For the three months ended March 31, 2024, the Company incurred program fee expenses of $0.3 million. As of March 31, 2024, the program fee rate was 6.88% percent.

[0000950170-24-057628:mdna:174]
[same as prior period, unchanged from 0000950170-23-062173:mdna:163]

[0000950170-24-057628:mdna:175]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE ("Adtran Networks"), as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-24-057628:mdna:176]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally

[0000950170-24-057628:mdna:177]
absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated in 2023.

[0000950170-24-057628:mdna:178]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of March 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.9 million or approximately $365.7 million, based on an exchange rate as of March 31, 2024 and reflecting interest accrued through March 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-057628:mdna:179]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.5 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2024 and 2023, we accrued $2.9 million and $2.8 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit. With respect to the year ended December 31, 2023, we are obligated to pay $11.5 million in Annual Recurring Compensation on the third banking day following the 2024 ordinary general shareholders’ meeting of Adtran Networks, which is expected to occur on June 28, 2024 (but in any event within eight months following December 31, 2023).

[0000950170-24-057628:mdna:180]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders.

[0000950170-24-057628:mdna:181]
We currently hold 33,957,538 no-par value bearer shares of Adtran Networks, representing 65.32% of Adtran Networks outstanding shares as of February 2, 2024.

[0000950170-24-057628:mdna:182]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which incorporated by reference to Exhibit 10.5 included in our Annual Report on Form 10-K filed with the SEC on March 15, 2024.

[0000950170-24-057628:mdna:183]
Business Efficiency Program

[0000950170-24-057628:mdna:184]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (the “Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expands upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment. Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). On October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze. Additionally, on April 11, 2024, management determined to close a facility in Greifswald, Germany. The closure of the facility is expected to be substantially completed by June 30, 2024.

[0000950170-24-057628:mdna:185]
During the three months ended March 31, 2024, we recognized $17.1 million of costs related to the Business Efficiency Program. The costs recognized during the three months ended March 31, 2024, included charges of $8.8 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.0 million relates to inventory write-downs and $4.8 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss. Since the inception of the Business Efficiency Program, we recognized $42.2 million of costs. We expect costs in the second quarter 2024 and thereafter relating to the Business Efficiency Program to range between $20.6 million and $35.8 million. Management

[0000950170-24-057628:mdna:186]
expects these planned costs to include severance costs ranging from $17.3 million to $28.3 million in connection with an early retirement program and reductions in workforce and site consolidation transaction expenses (primarily brokers fees and Greifswald exit costs) ranging from $3.3 million to $7.5 million. Future cash payments include: severance costs and outplacement fees that are anticipated to be in the range of $18.1 million to $29.1 million and payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $3.1 million to $7.3 million. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures. However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing. If required, we will amend this disclosure at such time as management is able in good faith to estimate the amount, or range of amounts, of these charges.

[0000950170-24-057628:mdna:187]
Business Combination Integration Costs

[0000950170-24-057628:mdna:188]
During the three months ended March 31, 2024 and 2023, we recognized $0.5 million and $0.8 million of integration costs related to the Business Combination, respectively, that are included in selling, general and administrative expenses, research & development expenses and cost of revenue in the Condensed Consolidated Statement of Loss. We expect to incur additional integration costs and expenses associated with the implementation of the DPLTA throughout 2024 and such costs are expected to be material. These costs are separate and apart from the costs associated with the integration program discussed below.

[0000950170-24-057628:mdna:189]
Multi-Year Integration Program

[0000950170-24-057628:mdna:190]
During the fourth quarter of 2022, the Company initiated a multi-year integration program designed to optimize the assets, business processes, and information technology systems of the Company. During the three months ended March 31, 2023, we recognized $2.4 million of integration costs related to the Business Combination, of restructuring costs relating to the Business Combination under the multi-year integration program that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss. The Company does not anticipate additional material expenses to be incurred in connection with this integration program. See Note 19 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-057628:mdna:191]
52

[0000950170-24-057628:mdna:192]
[same as prior period, unchanged from 0000950170-23-062173:mdna:173]

[0000950170-24-057628:mdna:193]
During the three months ended March 31, 2024, other than the Exit Compensation payments, Annual Recurring Compensation under the DPLTA, restructuring costs and increased debt service costs, there have been no other material changes in cash requirements from those discussed in the 2023 Form 10-K and our cash requirements table shown in Liquidity and Capital Resources above.

[0000950170-24-057628:mdna:194]
[same as prior period, unchanged from 0000950170-23-062173:mdna:175]

[0000950170-24-057628:mdna:195]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2024 and December 31, 2023, we had commitments related to these bonds totaling $10.6 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-24-057628:mdna:196]
[same as prior period, unchanged from 0000950170-23-062173:mdna:177]

[0000950170-24-057628:mdna:197]
[same as prior period, unchanged from 0000950170-23-062173:mdna:180]

[0000950170-24-057628:mdna:198]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part I, Item 1 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the critical accounting policies affect our more significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements. During the three months ended March 31, 2024, there were no significant changes to our critical accounting policies and estimates as described in the financial statements contained in the 2023 Form 10-K, except for goodwill as discussed below.

[0000950170-24-057628:mdna:199]
[same as prior period, unchanged from 0000950170-23-062173:mdna:178]

[0000950170-24-057628:mdna:200]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company’s annual impairment assessment is done at the reporting unit level, which we determined are generally the same as our operating segments, which are identified in Note 16 to the Condensed Consolidated Financial Statements. We review goodwill for impairment annually during the fourth quarter and also test for impairment between annual tests if an event occurs or circumstances change that would more likely than not reduce the fair value of our reporting unit below its carrying amount. In addition, the Company performs an interim impairment assessment prior to our October 1st annual measurement date, whenever events or changes in circumstances indicate that the carrying amount of such assets (or group of assets) may not be recoverable. Such events and circumstances may include among others: a significant adverse change in legal factors or in the general business climate; significant decline in our stock price and market capitalization; unanticipated competition; the testing for recoverability of a significant asset group within the reporting unit; and an adverse action or assessment by a regulator. Any adverse change in these factors could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000950170-24-057628:mdna:201]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of the Network Solutions reporting unit using a combination of an income approach and a market based peer group analysis. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit during the three months ended March 31, 2024. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the three months ended March 31, 2024. Our Network Solutions reporting unit had no remaining goodwill and our Services & Support reporting unit had $55.1 million of goodwill as of March 31, 2024, respectively.
