# ADTN 10-Q controls and the auditor's report


## item_4_controls

[0000950170-24-057628:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000950170-24-057628:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000950170-24-057628:item_4_controls:3]
We maintain disclosure controls and procedures that are designed to ensure that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000950170-24-057628:item_4_controls:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e)) under the Exchange Act. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that due to the material weaknesses in our internal control over financial reporting described below, our disclosure controls and procedures were not effective as of March 31, 2024.

[0000950170-24-057628:item_4_controls:5]
Material Weaknesses in Internal Control over Financial Reporting

[0000950170-24-057628:item_4_controls:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. In its assessment of the effectiveness of internal control over financial reporting as of March 31, 2024, management determined that there were deficiencies in ADTRAN’s internal control over financial reporting that constituted material weaknesses that existed as of March 31, 2024. Such material weaknesses were as follows:

[0000950170-24-057628:item_4_controls:7]
•
The Company did not design and maintain effective controls in response to the risks of material misstatement. Specifically, changes to existing controls or the implementation of new controls have not been sufficient to respond to changes to the risks of material misstatement to financial reporting. This material weakness contributed to the following additional material weaknesses:

[0000950170-24-057628:item_4_controls:8]
•
The Company did not design and maintain effective controls over financial statement preparation, presentation and disclosure commensurate with its financial reporting requirements. Specifically, the Company did not design and maintain effective controls over the presentation and disclosure of transactions, including non-controlling interest.

[0000950170-24-057628:item_4_controls:9]
•
The Company did not design and maintain effective controls to address the initial application of complex accounting standards and accounting of non-routine, unusual or complex events and transactions. Specifically, the Company did not design and maintain effective controls to timely analyze and account for (i) non-controlling interest and (ii) the receivable purchase and servicing agreement.

[0000950170-24-057628:item_4_controls:10]
The material weaknesses resulted in the restatements and revisions of and immaterial adjustments to our consolidated financial statements for the year ended December 31, 2022, as well as the condensed consolidated financial statements for the quarterly and year-to-date periods ended September 30, 2022, March 31, 2023, June 30, 2023, and September 30, 2023. The material weaknesses also resulted in material adjustments to our consolidated financial statements for the year ended December 31, 2023. Additionally, these material weaknesses could result in misstatements of the Company’s accounts or disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0000950170-24-057628:item_4_controls:11]
56

[0000950170-24-057628:item_4_controls:12]
Management’s Remediation Efforts

[0000950170-24-057628:item_4_controls:13]
To remediate the material weaknesses in the Company’s internal control over financial reporting related to the risks of material misstatement, including financial statement preparation, presentation and disclosure of transactions and the non-controlling interest, the Company plans to initiate a remediation plan that will involve designing and implementing new or enhanced controls over the review of our consolidated financial statements, global identification and reassessment of all key process and controls, increased training and awareness of control activities, and increased scrutiny on control performance and documentation standards. We believe that the foregoing actions will support the improvement of the Company’s internal control over financial reporting, and, through our efforts to identify, design, and implement the necessary control activities, will be effective in remediating such material weaknesses.

[0000950170-24-057628:item_4_controls:14]
To remediate the material weaknesses in the Company’s internal control over financial reporting relating to accounting of non-routine unusual or complex events and transactions for non-controlling interest and the receivable purchase and servicing agreement, the Company is preparing a remediation plan that includes designing and implementing new controls over the identification and review of contracts, transactions or arrangements that may result in a financial obligation including the use of an accounting specialist as needed to ensure proper presentation of these items within our financial statements.

[0000950170-24-057628:item_4_controls:15]
We will continue to devote significant time and attention to these remediation efforts. As we continue to evaluate and work to improve our internal control over financial reporting, management may determine to take additional measures to address the material weaknesses or determine to modify the remediation plans described above. Until the remediation steps set forth above, including the efforts to implement the necessary control activities that we identify, are fully completed, and there has been time for us to conclude through testing that the control activities are operating effectively, the material weaknesses described above will not be considered remediated.

[0000950170-24-057628:item_4_controls:16]
Changes in Internal Control over Financial Reporting.

[0000950170-24-057628:item_4_controls:17]
Other than the remediation plans outlined above, there were no changes in the Company’s internal control over financial reporting that occurred during the most recent fiscal quarter covered by this report that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.

[0000950170-24-057628:item_4_controls:18]
57
