# ADTN 8-K — 0000950170-24-053920 filed 2024-05-07

## item codes, every 8-K on or before 2024-05-10

- 2024-05-09 0000950170-24-056830 — 5.02, 5.07, 9.01
- 2024-05-07 0000950170-24-053920 — 2.02, 7.01, 9.01
- 2024-05-03 0001193125-24-130896 — 2.02, 7.01, 9.01
- 2024-04-17 0000950170-24-045151 — 2.05, 9.01
- 2024-03-15 0000950170-24-031864 — 2.02, 9.01
- 2024-02-27 0000950170-24-020613 — 2.02, 7.01, 9.01
- 2024-02-20 0001193125-24-040068 — 4.02
- 2024-01-22 0001193125-24-011697 — 1.01, 2.03, 9.01
- 2023-12-06 0001193125-23-289895 — 5.02, 9.01
- 2023-12-05 0001193125-23-289150 — 5.02, 9.01
- 2023-11-07 0001193125-23-271842 — 2.02, 7.01, 9.01
- 2023-10-24 0001193125-23-261665 — 5.02, 5.03, 9.01
- 2023-10-17 0001193125-23-257289 — 2.02, 7.01, 9.01
- 2023-09-29 0001193125-23-246498 — 5.02
- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2024-05-10

- 2024-02-29 0000950170-24-023141 — NT 10-K, for the period ended 2023-12-31
- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-24-053920:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0000950170-24-053920:8k_2_02:2]
EX-99.1

[0000950170-24-053920:8k_2_02:3]
EXHIBIT 99.1

[0000950170-24-053920:8k_2_02:4]
ADTRAN Holdings, Inc. reports first quarter 2024 financial results

[0000950170-24-053920:8k_2_02:5]
•
Q1 revenue above mid-point of guidance; non-GAAP profitability in line with guidance

[0000950170-24-053920:8k_2_02:6]
•
$53 million sequential improvement in GAAP operating cash flow

[0000950170-24-053920:8k_2_02:7]
Huntsville, Alabama, USA. — May 06, 2024 — ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” or the “Company”) today announced its unaudited financial results for the first quarter of 2024.

[0000950170-24-053920:8k_2_02:8]
GAAP gross margin for the first quarter was 31.9%, compared to 34.8% in Q4 2023 and 27.1% in the year-ago quarter, representing an improvement of 484 basis points (“bps”) year-over-year but a decrease of 285 bps quarter-over-quarter. The year-over-year improvement primarily resulted from lower purchasing and transportation costs, as well as lower acquisition-related expenses, amortizations and adjustments. The sequential margin decline is primarily due to $8.8 million of inventory charges related to a strategy shift as part of our Business Efficiency Program.

[0000950170-24-053920:8k_2_02:9]
Non-GAAP gross margin for the first quarter was 41.6% compared to 41.9% in Q4 2023 and 37.3% in the year-ago quarter representing a decline of 33 bps sequentially and an improvement of 429 bps year-over-year.

[0000950170-24-053920:8k_2_02:10]
GAAP operating margin for the first quarter was negative 150.2%, primarily driven by a non-cash goodwill impairment charge .

[0000950170-24-053920:8k_2_02:11]
Non-GAAP operating margin for the first quarter was negative 3.9%, which was within the guidance range of between -7% and 0% of revenues. Non-GAAP operating margin was negatively impacted by an unfavorable currency rate development and seasonal effects in the first quarter.

[0000950170-24-053920:8k_2_02:12]
GAAP net loss attributable to the Company for the first quarter of 2024, including the above mentioned impairment charge, was $324.6 million. Diluted loss per share attributable to the Company for the first quarter was $4.12.

[0000950170-24-053920:8k_2_02:13]
Non-GAAP net loss attributable to the Company for the first quarter of 2024 was $1.7 million. Non-GAAP diluted loss per share attributable to the Company for the first quarter was $0.02.

[0000950170-24-053920:8k_2_02:14]
ADTRAN Holdings’ Chairman and Chief Executive Officer Tom Stanton stated, "First quarter revenue and profitability came in as expected, with the weakness still impacting our results. However, we were pleased with the continued momentum in our customer win rate which was bolstered by the ongoing expansion of our Mosaic One platform. As we continued to execute on our business efficiency program , we were able to reduce inventory and significantly improve our operating cashflow while maintaining our diligence in gaining market share during this pivotal time in our industry. We believe that as markets return to normal, our continued focus on these measures, will lead to sustainable margin expansions and shareholder value creation in the mid-term.”

[0000950170-24-053920:8k_2_02:15]
The Company will hold a conference call to discuss its first quarter results on Tuesday, May 07, 2024, at 9:30 a.m. Central Time, or 4:30 p.m. Central European Summer Time. The Company will webcast this conference call. To listen, simply visit our Investor Relations

[0000950170-24-053920:8k_2_02:16]
site at investors.adtran.com approximately 10 minutes prior to the start of the call, click on the event “ADTRAN Holdings Releases 1st Quarter 2024 Financial Results and Earnings Call”, and click on the webcast link.

[0000950170-24-053920:8k_2_02:17]
An online replay of the Company’s conference call, as well as the transcript of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit investors.adtran.com or email investor.relations@adtran.com.

[0000950170-24-053920:8k_2_02:18]
Cautionary Note Regarding Forward-Looking Statements

[0000950170-24-053920:8k_2_02:19]
Explanation of Use of Non-GAAP Financial Measures

[0000950170-24-053920:8k_2_02:20]
Set forth in the tables below are reconciliations of gross profit, gross margin, operating expenses, operating loss, other expense, net loss inclusive of the non-controlling interest, net loss attributable to the Company, net income (loss) attributable to the non-controlling interest, and loss per share - basic and diluted, attributable to the Company, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating loss, non-GAAP other expense, non-GAAP net loss inclusive of the non-controlling interest, non-GAAP net loss attributable to the Company, non-GAAP net income attributable to the non-controlling interest, non-GAAP loss per share - basic and diluted, attributable to the Company, respectively, and non-GAAP free cash flow. Such non-GAAP measures exclude acquisition related expenses, amortization and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments), stock-based compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, integration expenses, restructuring expenses,  goodwill impairments, and the tax effect of these adjustments to net income. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of these non-GAAP measures when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0000950170-24-053920:8k_2_02:21]
These  non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0000950170-24-053920:8k_2_02:22]
About Adtran

[0000950170-24-053920:8k_2_02:23]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises, government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the largest shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE. Find more at Adtran, LinkedIn and Twitter.

[0000950170-24-053920:8k_2_02:24]
Published by

[0000950170-24-053920:8k_2_02:25]
ADTRAN Holdings, Inc.

[0000950170-24-053920:8k_2_02:26]
www.adtran.com

[0000950170-24-053920:8k_2_02:27]
For media

[0000950170-24-053920:8k_2_02:28]
Gareth Spence

[0000950170-24-053920:8k_2_02:29]
+44 1904 699 358

[0000950170-24-053920:8k_2_02:30]
public.relations@adtran.com

[0000950170-24-053920:8k_2_02:31]
For investors

[0000950170-24-053920:8k_2_02:32]
Steven Williams

[0000950170-24-053920:8k_2_02:33]
+49 89 890 665 918

[0000950170-24-053920:8k_2_02:34]
investor@adtran.com

[0000950170-24-053920:8k_2_02:35]
Condensed Consolidated Balance Sheets

[0000950170-24-053920:8k_2_02:36]
(Unaudited)

[0000950170-24-053920:8k_2_02:37]
(In thousands)

[0000950170-24-053920:8k_2_02:38]
|  | March 31, |  |  | December 31, |  |
|  | 2024 |  |  | 2023 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 106,757 |  |  | $ | 87,167 |  |
| Accounts receivable, net |  | 187,554 |  |  |  | 216,445 |  |
| Other receivables |  | 12,116 |  |  |  | 17,450 |  |
| Income tax receivable |  | 8,717 |  |  |  | 7,933 |  |
| Inventory, net |  | 322,147 |  |  |  | 362,295 |  |
| Prepaid expenses and other current assets |  | 59,667 |  |  |  | 45,566 |  |
| Total Current Assets |  | 696,958 |  |  |  | 736,856 |  |
| Property, plant and equipment, net |  | 126,969 |  |  |  | 123,020 |  |
| Deferred tax assets |  | 25,421 |  |  |  | 25,787 |  |
| Goodwill |  | 55,129 |  |  |  | 353,415 |  |
| Intangibles, net |  | 306,448 |  |  |  | 327,985 |  |
| Other non-current assets |  | 87,729 |  |  |  | 87,706 |  |
| Long-term investments |  | 29,252 |  |  |  | 27,743 |  |
| Total Assets | $ | 1,327,906 |  |  | $ | 1,682,512 |  |
| Liabilities, Redeemable Non-Controlling Interest and Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 159,083 |  |  | $ | 162,922 |  |
| Unearned revenue |  | 55,124 |  |  |  | 46,731 |  |
| Accrued expenses and other liabilities |  | 36,404 |  |  |  | 37,607 |  |
| Accrued wages and benefits |  | 25,869 |  |  |  | 27,030 |  |
| Income tax payable, net |  | 6,266 |  |  |  | 5,221 |  |
| Total Current Liabilities |  | 282,746 |  |  |  | 279,511 |  |
| Non-current revolving credit agreement outstanding |  | 195,000 |  |  |  | 195,000 |  |
| Deferred tax liabilities |  | 15,414 |  |  |  | 35,655 |  |
| Non-current unearned revenue |  | 22,884 |  |  |  | 25,109 |  |
| Non-current pension liability |  | 11,692 |  |  |  | 12,543 |  |
| Deferred compensation liability |  | 29,709 |  |  |  | 29,039 |  |
| Non-current lease obligations |  | 27,668 |  |  |  | 31,420 |  |
| Other non-current liabilities |  | 35,375 |  |  |  | 28,657 |  |
| Total Liabilities |  | 620,488 |  |  |  | 636,934 |  |
| Redeemable Non-Controlling Interest |  | 441,635 |  |  |  | 451,756 |  |
| Equity |  |  |  |  |  |
| Common stock |  | 791 |  |  |  | 790 |  |
| Additional paid-in capital |  | 798,897 |  |  |  | 795,304 |  |
| Accumulated other comprehensive income |  | 29,656 |  |  |  | 47,461 |  |
| Retained deficit |  | (558,363 | ) |  |  | (243,908 | ) |
| Treasury stock |  | (5,198 | ) |  |  | (5,825 | ) |
| Total Equity |  | 265,783 |  |  |  | 593,822 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity | $ | 1,327,906 |  |  | $ | 1,682,512 |  |

[0000950170-24-053920:8k_2_02:39]
Condensed Consolidated Statements of Loss

[0000950170-24-053920:8k_2_02:40]
(Unaudited)

[0000950170-24-053920:8k_2_02:41]
(In thousands, except per share amounts)

[0000950170-24-053920:8k_2_02:42]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2024 |  |  | 2023 |  |  |
| Revenue |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 181,273 |  |  | $ | 282,418 |  |  |
| Services & Support |  |  | 44,900 |  |  |  | 41,494 |  |  |
| Total Revenue |  |  | 226,173 |  |  |  | 323,912 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |
| Network Solutions |  |  | 126,326 |  |  |  | 219,130 |  |  |
| Network Solutions - inventory write-down |  |  | 8,782 |  |  |  | — |  |  |
| Services & Support |  |  | 18,810 |  |  |  | 16,974 |  |  |
| Total Cost of Revenue |  |  | 153,918 |  |  |  | 236,104 |  |  |
| Gross Profit |  |  | 72,255 |  |  |  | 87,808 |  |  |
| Selling, general and administrative expenses |  |  | 59,100 |  |  |  | 67,397 |  |  |
| Research and development expenses |  |  | 60,251 |  |  |  | 70,143 |  |  |
| Goodwill impairment |  |  | 292,583 |  |  |  | — |  |  |
| Operating Loss |  |  | (339,679 | ) |  |  | (49,732 | ) |  |
| Interest and dividend income |  |  | 397 |  |  |  | 304 |  |  |
| Interest expense |  |  | (4,598 | ) |  |  | (3,287 | ) |  |
| Net investment gain |  |  | 2,253 |  |  |  | 1,252 |  |  |
| Other income (expense), net |  |  | 1,310 |  |  |  | (303 | ) |  |
| Loss Before Income Taxes |  |  | (340,317 | ) |  |  | (51,766 | ) |  |
| Income tax benefit |  |  | 18,647 |  |  |  | 11,313 |  |  |
| Net Loss |  | $ | (321,670 | ) |  | $ | (40,453 | ) |  |
| Less: Net Income (Loss) attributable to non-controlling interest |  |  | 2,880 |  |  |  | (370 | ) |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (324,550 | ) |  | $ | (40,083 | ) |  |
| Weighted average shares outstanding – basic |  |  | 78,814 |  |  |  | 78,358 |  |  |
| Weighted average shares outstanding – diluted |  |  | 78,814 |  |  |  | 78,358 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (4.12 | ) |  | $ | (0.51 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (4.12 | ) |  | $ | (0.51 | ) |  |

[0000950170-24-053920:8k_2_02:43]
Condensed Consolidated Statements of Cash Flows

[0000950170-24-053920:8k_2_02:44]
(Unaudited)

[0000950170-24-053920:8k_2_02:45]
(In thousands)

[0000950170-24-053920:8k_2_02:46]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net loss |  | $ | (321,670 | ) |  | $ | (40,453 | ) |
| Adjustments to reconcile net loss to net cash provided by (used in) operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 22,528 |  |  |  | 33,402 |  |
| Goodwill impairment |  |  | 292,583 |  |  |  | — |  |
| Amortization of debt issuance cost |  |  | 1,013 |  |  |  | 146 |  |
| Gain on investments, net |  |  | (2,621 | ) |  |  | (3,154 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 150 |  |  |  | — |  |
| Stock-based compensation expense |  |  | 3,957 |  |  |  | 3,812 |  |
| Deferred income taxes |  |  | (19,738 | ) |  |  | (24,019 | ) |
| Other, net |  |  | 545 |  |  |  | (1 | ) |
| Inventory write down |  |  | 8,782 |  |  |  | — |  |
| Inventory reserves |  |  | (17,247 | ) |  |  | 16,051 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 26,002 |  |  |  | 17,658 |  |
| Other receivables |  |  | 5,606 |  |  |  | 1,980 |  |
| Income taxes receivable, net |  |  | (1,296 | ) |  |  | — |  |
| Inventory |  |  | 49,514 |  |  |  | (2,764 | ) |
| Prepaid expenses, other current assets and other assets |  |  | (15,888 | ) |  |  | 1,118 |  |
| Accounts payable |  |  | (4,236 | ) |  |  | (40,367 | ) |
| Accrued expenses and other liabilities |  |  | 7,459 |  |  |  | 6,349 |  |
| Income taxes payable, net |  |  | 1,155 |  |  |  | 10,316 |  |
| Net cash provided by (used in) operating activities |  |  | 36,598 |  |  |  | (19,926 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (13,374 | ) |  |  | (8,439 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 873 |  |  |  | 930 |  |
| Purchases of available-for-sale investments |  |  | (44 | ) |  |  | (516 | ) |
| Proceeds from beneficial interests in securitized accounts receivable |  |  | — |  |  |  | 1,231 |  |
| Net cash used in investing activities |  |  | (12,545 | ) |  |  | (6,794 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (176 | ) |  |  | (6,258 | ) |
| Proceeds from stock option exercises |  |  | 219 |  |  |  | 58 |  |
| Dividend payments |  |  | — |  |  |  | (7,076 | ) |
| Proceeds from receivables purchase agreement |  |  | 30,231 |  |  |  | — |  |
| Repayments on receivables purchase agreement |  |  | (32,437 | ) |  |  | — |  |
| Proceeds from draw on revolving credit agreements |  |  | — |  |  |  | 138,236 |  |
| Repayment of revolving credit agreements |  |  | — |  |  |  | (43,464 | ) |
| Payment of redemption of redeemable non-controlling interest |  |  | (5 | ) |  |  | (1,176 | ) |
| Payment of debt issuance cost |  |  | (1,994 | ) |  |  | — |  |
| Repayment of notes payable |  |  | — |  |  |  | (24,692 | ) |
| Net cash (used in) provided by financing activities |  |  | (4,162 | ) |  |  | 55,628 |  |
| Net increase in cash and cash equivalents |  |  | 19,891 |  |  |  | 28,908 |  |
| Effect of exchange rate changes |  |  | (301 | ) |  |  | (1,095 | ) |
| Cash and cash equivalents, beginning of period |  |  | 87,167 |  |  |  | 108,644 |  |
| Cash and cash equivalents, end of period |  | $ | 106,757 |  |  | $ | 136,457 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 5,243 |  |  | $ | 1,610 |  |
| Cash paid for income taxes |  | $ | 2,315 |  |  | $ | 1,251 |  |
| Cash used in operating activities related to operating leases |  | $ | 2,384 |  |  | $ | 4,057 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 842 |  |  | $ | 486 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 1,689 |  |  | $ | 4,354 |  |

[0000950170-24-053920:8k_2_02:47]
Supplemental Information

[0000950170-24-053920:8k_2_02:48]
Reconciliation of Gross Profit and Gross Margin to

[0000950170-24-053920:8k_2_02:49]
Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0000950170-24-053920:8k_2_02:50]
(Unaudited)

[0000950170-24-053920:8k_2_02:51]
(In thousands)

[0000950170-24-053920:8k_2_02:52]
|  |  | Three Months Ended |  |
|  |  | March 31, 2024 |  |  | December 31, 2023 |  |  | March 31, 2023 |  |
| Total Revenue |  | $ | 226,173 |  |  | $ | 225,479 |  |  | $ | 323,912 |  |
| Cost of Revenue |  | $ | 153,918 |  |  | $ | 147,014 |  |  | $ | 236,104 |  |
| Acquisition-related expenses, amortizations and adjustments(1) |  |  | (10,177 | ) |  |  | (10,048 | ) |  |  | (32,578 | ) |
| Stock-based compensation expense |  |  | (275 | ) |  |  | (440 | ) |  |  | (240 | ) |
| Restructuring expenses(2) |  |  | (11,247 | ) |  |  | (5,517 | ) |  |  | (76 | ) |
| Integration expenses(3) |  |  | (35 | ) |  |  | 39 |  |  |  | — |  |
| Non-GAAP Cost of Revenue |  | $ | 132,184 |  |  | $ | 131,048 |  |  | $ | 203,210 |  |
| Gross Profit |  | $ | 72,255 |  |  | $ | 78,465 |  |  | $ | 87,808 |  |
| Non-GAAP Gross Profit |  | $ | 93,989 |  |  | $ | 94,431 |  |  | $ | 120,702 |  |
| Gross Margin |  |  | 31.9 | % |  |  | 34.8 | % |  |  | 27.1 | % |
| Non-GAAP Gross Margin |  |  | 41.6 | % |  |  | 41.9 | % |  |  | 37.3 | % |

[0000950170-24-053920:8k_2_02:53]
(1)  Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations.

[0000950170-24-053920:8k_2_02:54]
(2)  Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. These expenses include inventory write down and other charges of $8.8M incurred as a result of a strategic shift in certain product lines in connection with the restructuring program. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and is expected to be substantially completed in late 2024.

[0000950170-24-053920:8k_2_02:55]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE.

[0000950170-24-053920:8k_2_02:56]
Supplemental Information

[0000950170-24-053920:8k_2_02:57]
Reconciliation of Operating Expenses to Non-GAAP Operating Expenses

[0000950170-24-053920:8k_2_02:58]
(Unaudited)

[0000950170-24-053920:8k_2_02:59]
(In thousands)

[0000950170-24-053920:8k_2_02:60]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |  |
|  |  | 2024 |  |  | 2023 |  |  | 2023 |  |  |
| Operating Expenses |  | $ | 411,934 |  |  | $ | 116,080 |  |  | $ | 137,540 |  |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | (4,881 | ) | (1) |  | (4,150 | ) | (7) |  | (4,584 | ) | (11) |
| Stock-based compensation expense |  |  | (3,447 | ) | (2) |  | (3,181 | ) | (8) |  | (3,458 | ) | (12) |
| Restructuring expenses |  |  | (5,862 | ) | (3) |  | (7,859 | ) | (9) |  | (2,361 | ) | (13) |
| Integration expenses |  |  | (480 | ) | (4) |  | (1,928 | ) | (10) |  | (849 | ) | (14) |
| Deferred compensation adjustments(5) |  |  | (1,940 | ) |  |  | (1,324 | ) |  |  | (394 | ) |  |
| Goodwill impairment |  |  | (292,583 | ) | (6) |  | — |  |  |  | — |  |  |
| Non-GAAP Operating Expenses |  | $ | 102,741 |  |  | $ | 97,638 |  |  | $ | 125,894 |  |  |

[0000950170-24-053920:8k_2_02:61]
(1)  Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $4.4 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-053920:8k_2_02:62]
(2) $2.5 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-053920:8k_2_02:63]
(3) $1.8 million is included in selling, general and administrative expenses and $4.1 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-053920:8k_2_02:64]
(4) $0.5 million is included in selling, general and administrative expenses and $0.02 million is included in research and development expenses on the condensed consolidated statements of loss. Includes legal and advisory fees totaling $0.1 million related primarily to the DPLTA proceedings that are recorded in selling, general and administrative expenses. Includes expenses totaling $0.4 million related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE of which $0.4 million are included in selling, general and administrative expenses and $0.02 million are included in research and development expenses. The transformation bonus expense of $0.4 million includes $0.2 million of stock compensation expense.

[0000950170-24-053920:8k_2_02:65]
(5) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-24-053920:8k_2_02:66]
(6) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer inventory adjustments.

[0000950170-24-053920:8k_2_02:67]
(7)   Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $3.7 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-053920:8k_2_02:68]
(8) $2.3 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-053920:8k_2_02:69]
(9) $4.6 million is included in selling, general and administrative expenses and $3.2 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-053920:8k_2_02:70]
(10) $1.9 million is included in selling, general and administrative expenses and $0.02 million is included in research and development expenses on the condensed consolidated statements of loss. Includes legal and advisory fees totaling $1.2 million related to a contemplated capital raise transaction that are recorded in selling, general and administrative expenses. Includes expenses totaling $0.4 million related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE of which $0.4 million are included in selling, general and administrative expenses and $0.02 million are included in research and development expenses. The integration bonus expense of $0.4 million includes $0.2 million of stock compensation expense. Additionally, includes fees relating to the expansion of internal controls at Adtran Networks SE and the implementation of the DPLTA.

[0000950170-24-053920:8k_2_02:71]
(11)  Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $4.1 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of  loss.

[0000950170-24-053920:8k_2_02:72]
(12) $2.5 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-053920:8k_2_02:73]
(13) $2.2 million is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-053920:8k_2_02:74]
(14) $0.8 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at ADTRAN Networks SE and the implementation of the DPLTA.

[0000950170-24-053920:8k_2_02:75]
Supplemental Information

[0000950170-24-053920:8k_2_02:76]
Reconciliation of Operating Loss to Non-GAAP Operating Loss

[0000950170-24-053920:8k_2_02:77]
(Unaudited)

[0000950170-24-053920:8k_2_02:78]
(In thousands)

[0000950170-24-053920:8k_2_02:79]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |  |
|  |  | 2024 |  |  | 2023 |  |  | 2023 |  |  |
| Operating Loss |  | $ | (339,679 | ) |  | $ | (37,615 | ) |  | $ | (49,732 | ) |  |
| Acquisition related expenses, amortizations and adjustments(1) |  |  | 15,058 |  |  |  | 14,198 |  |  |  | 37,162 |  |  |
| Stock-based compensation expense |  |  | 3,722 |  |  |  | 3,621 |  |  |  | 3,698 |  |  |
| Restructuring expenses(2) |  |  | 17,110 |  |  |  | 13,376 |  |  |  | 2,437 |  |  |
| Integration expenses(3) |  |  | 514 |  |  |  | 1,890 |  |  |  | 849 |  |  |
| Deferred compensation adjustments(4) |  |  | 1,940 |  |  |  | 1,324 |  |  |  | 394 |  |  |
| Goodwill impairment(5) |  |  | 292,583 |  |  |  | — |  |  |  | — |  |  |
| Non-GAAP Operating Loss |  | $ | (8,752 | ) |  | $ | (3,206 | ) |  | $ | (5,192 | ) |  |

[0000950170-24-053920:8k_2_02:80]
(1)  Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations.

[0000950170-24-053920:8k_2_02:81]
(2)  Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. These expenses include inventory write down and other charges of $8.8M incurred as a result of a strategic shift in certain product lines in connection with the restructuring program. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and is expected to be completed in late 2024.

[0000950170-24-053920:8k_2_02:82]
(3)  Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks SE. Additionally, includes legal and advisory fees relating to a contemplated capital raise transactions as part of the integration. Includes fees incurred for the expansion of internal controls at Adtran Networks SE and the implementation of the DPTLA.

[0000950170-24-053920:8k_2_02:83]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-24-053920:8k_2_02:84]
(5) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer inventory adjustments.

[0000950170-24-053920:8k_2_02:85]
Supplemental Information

[0000950170-24-053920:8k_2_02:86]
Reconciliation of Other Expense to Non-GAAP Other Expense

[0000950170-24-053920:8k_2_02:87]
(Unaudited)

[0000950170-24-053920:8k_2_02:88]
(In thousands)

[0000950170-24-053920:8k_2_02:89]
|  |  | Three Months Ended |  |  |
|  |  | March 31, 2024 |  |  | December 31, 2023 |  |  | March 31, 2023 |  |  |
| Interest and dividend income |  | $ | 397 |  |  | $ | 1,157 |  |  | $ | 304 |  |  |
| Interest expense |  |  | (4,598 | ) |  |  | (4,441 | ) |  |  | (3,287 | ) |  |
| Net investment gain |  |  | 2,253 |  |  |  | 1,683 |  |  |  | 1,252 |  |  |
| Other income (expense), net |  |  | 1,310 |  |  |  | (3,448 | ) |  |  | (303 | ) |  |
| Total Other Expense |  | $ | (638 | ) |  | $ | (5,049 | ) |  | $ | (2,034 | ) |  |
| Deferred compensation adjustments (1) |  |  | (2,439 | ) |  |  | (1,590 | ) |  |  | (1,250 | ) |  |
| Pension expense (2) |  |  | 7 |  |  |  | 6 |  |  |  | 7 |  |  |
| Non-GAAP Other Expense |  | $ | (3,070 | ) |  | $ | (6,633 | ) |  | $ | (3,277 | ) |  |

[0000950170-24-053920:8k_2_02:90]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0000950170-24-053920:8k_2_02:91]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-24-053920:8k_2_02:92]
Supplemental Information

[0000950170-24-053920:8k_2_02:93]
Reconciliation of Net Loss inclusive of Non-Controlling Interest to

[0000950170-24-053920:8k_2_02:94]
Non-GAAP Net Loss inclusive of Non-Controlling Interest

[0000950170-24-053920:8k_2_02:95]
(Unaudited)

[0000950170-24-053920:8k_2_02:96]
and

[0000950170-24-053920:8k_2_02:97]
Reconciliation of Net Income (Loss) attributable to Non-Controlling Interest to

[0000950170-24-053920:8k_2_02:98]
Non-GAAP Net Income attributable to Non-Controlling Interest

[0000950170-24-053920:8k_2_02:99]
(Unaudited)

[0000950170-24-053920:8k_2_02:100]
and

[0000950170-24-053920:8k_2_02:101]
Reconciliation of  Net Loss attributable to ADTRAN Holdings, Inc. and

[0000950170-24-053920:8k_2_02:102]
Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0000950170-24-053920:8k_2_02:103]
Non-GAAP Net Loss attributable to ADTRAN Holdings, Inc. and

[0000950170-24-053920:8k_2_02:104]
Non-GAAP Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0000950170-24-053920:8k_2_02:105]
(Unaudited)

[0000950170-24-053920:8k_2_02:106]
(In thousands, except per share amounts)

[0000950170-24-053920:8k_2_02:107]
|  |  | Three Months Ended |  |  |
|  |  | March 31,2024 |  |  | December 31,2023 |  |  | March 31,2023 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (324,550 | ) |  | $ | (109,945 | ) |  | $ | (40,083 | ) |  |
| Plus: Net Income (Loss) attributable to non-controlling interest (1) |  |  | 2,880 |  |  |  | 2,919 |  |  |  | (370 | ) |  |
| Net Loss inclusive of non-controlling interest |  | $ | (321,670 | ) |  | $ | (107,026 | ) |  | $ | (40,453 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 15,058 |  |  |  | 14,198 |  |  |  | 37,162 |  |  |
| Stock-based compensation expense |  |  | 3,722 |  |  |  | 3,621 |  |  |  | 3,698 |  |  |
| Deferred compensation adjustments (2) |  |  | (499 | ) |  |  | (267 | ) |  |  | (856 | ) |  |
| Pension adjustments (3) |  |  | 7 |  |  |  | 6 |  |  |  | 7 |  |  |
| Restructuring expenses |  |  | 17,110 |  |  |  | 13,376 |  |  |  | 2,437 |  |  |
| Integration expenses |  |  | 514 |  |  |  | 1,890 |  |  |  | 849 |  |  |
| Goodwill impairment |  |  | 292,583 |  |  |  | — |  |  |  | — |  |  |
| Tax effect of adjustments to net loss |  |  | (5,614 | ) |  |  | (8,735 | ) |  |  | (12,307 | ) |  |
| Non-GAAP Net Loss inclusive of non-controlling interest |  | $ | 1,211 |  |  | $ | (82,937 | ) |  | $ | (9,463 | ) |  |
| Less: Non-GAAP Net Income attributable to non-controlling interest (1) |  |  | 2,880 |  |  |  | 2,919 |  |  |  | 1,159 |  |  |
| Non-GAAP Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (1,669 | ) |  | $ | (85,856 | ) |  | $ | (10,622 | ) |  |
| GAAP Net Income (Loss) attributable to non-controlling interest (1) |  | $ | 2,880 |  |  | $ | 2,919 |  |  | $ | (370 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | — |  |  |  | — |  |  |  | 1,457 |  |  |
| Restructuring expenses |  |  | — |  |  |  | — |  |  |  | 29 |  |  |
| Integration expenses |  |  | — |  |  |  | — |  |  |  | 6 |  |  |
| Stock-based compensation expense |  |  | — |  |  |  | — |  |  |  | 37 |  |  |
| Non-GAAP Net Income attributable to non-controlling interest (1) |  | $ | 2,880 |  |  | $ | 2,919 |  |  | $ | 1,159 |  |  |
| Weighted average shares outstanding – basic |  |  | 78,814 |  |  |  | 78,530 |  |  |  | 78,358 |  |  |
| Weighted average shares outstanding – diluted |  |  | 78,814 |  |  |  | 78,530 |  |  |  | 78,358 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (4.12 | ) |  | $ | (1.40 | ) |  | $ | (0.51 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (4.12 | ) |  | $ | (1.40 | ) |  | $ | (0.51 | ) |  |
| Non-GAAP Loss per common share attributable to ADTRAN – basic |  | $ | (0.02 | ) |  | $ | (1.09 | ) |  | $ | (0.14 | ) |  |
| Non-GAAP Loss per common share attributable to ADTRAN – diluted |  | $ | (0.02 | ) |  | $ | (1.09 | ) |  | $ | (0.14 | ) |  |

[0000950170-24-053920:8k_2_02:108]
(1) Represents the non-controlling interest portion of the Company's ownership of Adtran Networks SE pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0000950170-24-053920:8k_2_02:109]
(2) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-24-053920:8k_2_02:110]
(3) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-24-053920:8k_2_02:111]
Supplemental Information

[0000950170-24-053920:8k_2_02:112]
Reconciliation of Net Cash Provided By (Used In) Operating Activities to Free Cash Flow

[0000950170-24-053920:8k_2_02:113]
(Unaudited)

[0000950170-24-053920:8k_2_02:114]
(In thousands)

[0000950170-24-053920:8k_2_02:115]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2023 |  |
| Net Cash provided by (used in) operating activities |  | $ | 36,598 |  |  | $ | (16,290 | ) |  | $ | (19,926 | ) |
| Purchases of property, plant and equipment |  |  | (13,374 | ) |  |  | (9,447 | ) |  |  | (8,439 | ) |
| Free cash flow |  | $ | 23,224 |  |  | $ | (25,737 | ) |  | $ | (28,365 | ) |
