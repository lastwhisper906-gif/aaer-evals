# ADTN notes — 0000950170-24-057628


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-24-057628:notes:1]
[same as prior period, unchanged from 0000950170-23-062173:notes:1]

[0000950170-24-057628:notes:2]
[same as prior period, unchanged from 0000950170-23-062173:notes:2]

[0000950170-24-057628:notes:3]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer and in particular upon the convergence of solutions at the network edge.

[0000950170-24-057628:notes:4]
Liquidity, Domination and Profit and Loss Transfer Agreement and Credit Facility

[0000950170-24-057628:notes:5]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE ("Adtran Networks"), as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-24-057628:notes:6]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally

[0000950170-24-057628:notes:7]
absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated in 2023.

[0000950170-24-057628:notes:8]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of March 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.9 million or approximately $365.7 million, based on an exchange rate as of March 31, 2024 and reflecting interest accrued through March 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-057628:notes:9]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.5 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2024 and 2023, we accrued $2.9 million and $2.8 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit. With respect to the year ended December 31, 2023, we are obligated to pay $11.5 million in Annual Recurring Compensation on the third banking day following the 2024 ordinary general shareholders’ meeting of Adtran Networks, which is expected to occur on June 28, 2024 (but in any event within eight months following December 31, 2023).

[0000950170-24-057628:notes:10]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders.

[0000950170-24-057628:notes:11]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”), which has since been amended three times. Pursuant to the terms of the Credit Agreement, as amended, the Company, ADTRAN, Inc., and the subsidiary guarantors (together, the “Credit Parties”) are subject to a liquidity covenant, which provides that, during the fourth quarter of 2023 through and including the third quarter of 2024 (the “Covenant Relief Period”) or a Springing Covenant Period (i.e., the period beginning upon the purchase by the Company of at least 60% of the outstanding shares of Adtran Networks not owned by the Company as of August 9, 2023 and the three consecutive quarterly test periods after such date), as of the last day of any fiscal quarter, the cash and cash equivalents of the Credit Parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million, limiting our ability to pay the obligations under the DPLTA. The Company had access to $203.0 million on its Credit Facility for future borrowings; however, as of March 31, 2024, the Company was limited to additional borrowings of $22.7 million based on debt covenant compliance metrics. See Note 11, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

[0000950170-24-057628:notes:12]
As of March 31, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-32 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks shares.

[0000950170-24-057628:notes:13]
The Company experienced revenue declines in the year ended December 31, 2023 and during the three months ended March 31, 2024. To the extent that the Company is further impacted by the uncertain macroeconomic environment related to continued elevated interest rates and ongoing inflationary pressures, the Company has established plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a business efficiency program, which includes, but is not limited to planned reductions in operating expenses and a site consolidation plan. In connection with

[0000950170-24-057628:notes:14]
the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

[0000950170-24-057628:notes:15]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility, including (i) the additional funding provided for under the First Amendment to the Wells Fargo Credit Facility that was signed on August 9, 2023, (ii) the additional covenant headroom during the Covenant Relief Period provided for under the Second Amendment to Wells Fargo Credit Facility, and (iii) the exclusion of the Factoring Agreement as debt for purposes of the Credit Facility’s financial covenants as provided for under the Third Amendment to the Wells Fargo Credit Facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and ability to continue to comply with our debt covenants under the Credit Facility, for at least the next twelve months, from the issuance of these financial statements. See Note 11, Revolving Credit Agreements, for additional information regarding the terms of the First, Second and Third Amendments of the Wells Fargo Credit agreement.

[0000950170-24-057628:notes:16]
[same as prior period, unchanged from 0000950170-23-062173:notes:14]

[0000950170-24-057628:notes:17]
[same as prior period, unchanged from 0000950170-23-062173:notes:15]

[0000950170-24-057628:notes:18]
The accompanying unaudited Condensed Consolidated Financial Statements of ADTRAN Holdings, Inc. and its subsidiaries have been prepared pursuant to the rules and regulations of the SEC applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2023 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP for annual financial statements.

[0000950170-24-057628:notes:19]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on March 15, 2024.

[0000950170-24-057628:notes:20]
[same as prior period, unchanged from 0000950170-23-062173:notes:18]

[0000950170-24-057628:notes:21]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

[0000950170-24-057628:notes:22]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, the energy crisis, currency fluctuations and political tensions as of March 31, 2024, and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to ongoing inflationary pressures, the energy crisis, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.

[0000950170-24-057628:notes:23]
Accounts Receivable Factoring

[0000950170-24-057628:notes:24]
New Accounts Receivable Factoring Agreement

[0000950170-24-057628:notes:25]
On December 19, 2023, the Company entered into a new factoring agreement with a third-party financial institution to replace the Company’s prior accounts receivable purchase agreement, to sell on a revolving basis, undivided interests in the Company’s accounts receivable. The new factoring agreement qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company is considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retains a residual claim on reserves related to the factored receivables. Within the Condensed Consolidated Balance Sheets, the receivables factored continue to be carried in accounts receivable, less allowance for credit losses, and the secured borrowings are carried as a current liability within accounts payable. The proceeds and repayments of secured borrowings are reflected as cash flows provided by (used in) financing activities within the Condensed Consolidated Statements of Cash Flows, and program fees are recorded as interest expense in the Consolidated Statements of Loss. The short-term liability classification of the secured borrowings is based on the estimated timing of the collection of the accounts receivable which are expected to be received within 12 months. See Note 2 for additional information.

[0000950170-24-057628:notes:26]
Previous Accounts Receivable Factoring Agreement

[0000950170-24-057628:notes:27]
The Company had previously entered into a factoring agreement to sell certain receivables to an unrelated third-party financial institution on a non-recourse basis. These transactions were accounted for in accordance with ASC Topic 860 and resulted in a reduction in accounts receivable because the agreement transferred effective control over and risk related to the receivables to the buyers. Trade accounts receivables balances sold were removed from the Condensed Consolidated Balance Sheets and cash received was reflected as cash flows provided by (used in) operating activities in the Condensed Consolidated Statements of Cash Flow. Factoring related interest expense was recorded to interest expense on the Condensed Consolidated Statements of Loss. On each sale date, the financial institution retained from the sale price a default reserve, up to a required balance, which was held by the financial institution in a reserve account and pledged to the Company. The financial institution was entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account was included in other assets on the Condensed Consolidated Balance Sheets.

[0000950170-24-057628:notes:28]
[same as prior period, unchanged from 0000950170-23-062173:notes:21]

[0000950170-24-057628:notes:29]
As of March 31, 2024 and December 31, 2023, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.7% for each period.

[0000950170-24-057628:notes:30]
[same as prior period, unchanged from 0000950170-23-062173:notes:23]

[0000950170-24-057628:notes:31]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. However, the RNCI will be remeasured using the current exchange rate at each reporting date as long as the RNCI is currently redeemable. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Condensed Consolidated Balance Sheets. See Note 14 for additional information on RNCI.

[0000950170-24-057628:notes:32]
[same as prior period, unchanged from 0000950170-23-062173:notes:28]

[0000950170-24-057628:notes:33]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2023-09 will have on our disclosures.

[0000950170-24-057628:notes:34]
In November 2023, the FASB issued ASU 2023-7, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures", which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses, allowing financial statement users to better understand the components of a segment's profit or loss to assess potential future cash flows for each reportable segment and the entity as a whole. The amendments expand a public entity's segment disclosures by requiring disclosure of significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), clarifying when an entity may report one or more additional measures to assess segment performance, requiring enhanced interim disclosures, providing new disclosure requirements for entities with a single reportable segment, and requiring other new disclosures. The amendments are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, and early adoption is permitted. The Company expect to adopt the new disclosures as required for the year ended December 31, 2024. The Company is currently evaluating the impact on the related disclosures.

[0000950170-24-057628:notes:35]
Recent Final Rules Not Yet Adopted

[0000950170-24-057628:notes:36]
In March 2024, the SEC adopted final rules under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, which requires registrants to provide certain climate-related information in their registration statements and annual reports. The rules require information about a registrant's climate-related risks that are reasonably likely to have a material impact on its business, results of operations, or financial condition. The required information about climate-related risks will also include disclosure of a registrant's greenhouse gas emissions. In addition, the rules will require registrants to present certain climate-related financial metrics in their audited financial statements. These requirements are effective for the Company in various fiscal years, starting with its fiscal year beginning January 1, 2025. Disclosures will be required prospectively, with information for prior periods required only to the extent it was previously disclosed in an SEC filing. The Company is currently evaluating the impact of these final rules on its consolidated financial statements and disclosures. On April 12, 2024, the final rules were indefinitely delayed pending the completion of judicial review in consolidated proceedings in the U.S. Court of Appeals, Eighth Circuit.

[0000950170-24-057628:notes:37]
Recently Adopted Accounting Pronouncements

[0000950170-24-057628:notes:38]
There are currently no recently adopted accounting pronouncements that are expected to have a material effect on the Condensed Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-24-057628:notes:39]
2. REVENUE

[0000950170-24-057628:notes:40]
[same as prior period, unchanged from 0000950170-23-062173:notes:57]

[0000950170-24-057628:notes:41]
[same as prior period, unchanged from 0000950170-23-062173:notes:58]

[0000950170-24-057628:notes:42]
[same as prior period, unchanged from 0000950170-23-062173:notes:59]

[0000950170-24-057628:notes:43]
[same as prior period, unchanged from 0000950170-23-062173:notes:60]

[0000950170-24-057628:notes:44]
[same as prior period, unchanged from 0000950170-23-062173:notes:61]

[0000950170-24-057628:notes:45]
[same as prior period, unchanged from 0000950170-23-062173:notes:63]

[0000950170-24-057628:notes:46]
[same as prior period, unchanged from 0000950170-23-062173:notes:64]

[0000950170-24-057628:notes:47]
[same as prior period, unchanged from 0000950170-23-062173:notes:65]

[0000950170-24-057628:notes:48]
The following table disaggregates revenue by reportable segment and revenue category:

[0000950170-24-057628:notes:49]
|  |  | Three Months Ended |  |
|  |  | March 31, 2024 |  |  | March 31, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 60,369 |  |  | $ | 9,399 |  |  | $ | 69,767 |  |  | $ | 70,287 |  |  | $ | 9,049 |  |  | $ | 79,336 |  |
| Access & Aggregation Solutions |  |  | 67,777 |  |  |  | 13,535 |  |  |  | 81,312 |  |  |  | 84,554 |  |  |  | 12,266 |  |  |  | 96,820 |  |
| Optical Networking Solutions |  |  | 53,127 |  |  |  | 21,966 |  |  |  | 75,094 |  |  |  | 127,577 |  |  |  | 20,179 |  |  |  | 147,756 |  |
| Total |  | $ | 181,273 |  |  | $ | 44,900 |  |  | $ | 226,173 |  |  | $ | 282,418 |  |  | $ | 41,494 |  |  | $ | 323,912 |  |

[0000950170-24-057628:notes:50]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2024 and December 31, 2023 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $346.9 million and $314.8 million, respectively. As of March 31, 2024, approximately 61.0% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of March 31, 2024 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-24-057628:notes:51]
The following table provides information about accounts receivable, contract assets and unearned revenue from contracts with customers:

[0000950170-24-057628:notes:52]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Accounts receivable, net |  | $ | 187,554 |  |  | $ | 216,445 |  |
| Contract assets(1) |  | $ | 815 |  |  | $ | 691 |  |
| Unearned revenue |  | $ | 55,124 |  |  | $ | 46,731 |  |
| Non-current unearned revenue |  | $ | 22,884 |  |  | $ | 25,109 |  |

[0000950170-24-057628:notes:53]
[same as prior period, unchanged from 0000950170-23-062173:notes:72]

[0000950170-24-057628:notes:54]
[same as prior period, unchanged from 0000950170-23-062173:notes:75]

[0000950170-24-057628:notes:55]
The allowance for credit losses was $0.4 million as of March 31, 2024 and December 31, 2023, related to accounts receivable.

[0000950170-24-057628:notes:56]
[same as prior period, unchanged from 0000950170-23-062173:notes:79]

[0000950170-24-057628:notes:57]
No allowance for credit losses was recorded for the three months ended March 31, 2024 and 2023 related to contract assets.

[0000950170-24-057628:notes:58]
Receivables Purchase Agreement

[0000950170-24-057628:notes:59]
The Company was party to a receivable purchase agreement with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. As of December 31, 2023 no accounts receivable were factored under the agreement or held in the reserve account. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months ended March 31, 2023.

[0000950170-24-057628:notes:60]
On December 19, 2023, the agreement with the Factor was terminated and the Company, entered into a receivables purchase agreement with a third-party financial institution (the “New Factor”) to replace the Company’s prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The New Factor provides for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The New Factor qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. Total secured borrowings under the agreement were $12.6 million and $14.3 million as of March 31, 2024 and December 31, 2023, respectively, leaving $27.2 million and $25.4 million available for future borrowings as of March 31, 2024 and December 31, 2023, respectively. Accounts receivable pledged as collateral related to the secured borrowings were $16.4 million and $16.8 million as of March 31, 2024 and December 31, 2023, respectively. For the three months ended March 31, 2024, the Company incurred program fee expenses of $0.3 million. As of March 31, 2024, the program fee rate was 6.88% percent.

[0000950170-24-057628:notes:61]
Of the outstanding unearned revenue balances as of December 31, 2023, $19.7 million were recognized as revenue during the three months ended March 31, 2024. Of the $60.4 million of outstanding unearned revenue balances as of December 31, 2022, $25.6 million were recognized as revenue during the three months ended March 31, 2023.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-057628:notes:62]
3. INCOME TAXES

[0000950170-24-057628:notes:63]
The Company’s effective tax rate changed from a benefit of 21.9% of pre-tax loss for the three months ended March 31, 2023, to a benefit of 5.5% of pre-tax loss for the three months ended March 31, 2024. The change in the effective tax rate for the three months ended March 31, 2024, was driven primarily by a loss jurisdiction for which no tax benefits were recognized on its pre-tax losses during the first quarter of 2024.

[0000950170-24-057628:notes:64]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of March 31, 2024, the Company had net deferred tax assets totaling $96.5 million, and a valuation allowance totaling $86.5 million against those deferred tax assets. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results, as well as the evaluation of evidence which requires significant judgment, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance, or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-057628:notes:65]
4. STOCK-BASED COMPENSATION

[0000950170-24-057628:notes:66]
For the three months ended March 31, 2024 and 2023, stock-based compensation expense was $4.0 million and $2.6 million, respectively.

[0000950170-24-057628:notes:67]
[same as prior period, unchanged from 0000950170-23-062173:notes:93]

[0000950170-24-057628:notes:68]
The following table summarizes the PSUs, RSUs and restricted stock outstanding as of December 31, 2023 and March 31, 2024 and the changes that occurred during the three months ended March 31, 2024:

[0000950170-24-057628:notes:69]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2023 |  |  | 1,942 |  |  | $ | 17.46 |  |
| PSUs, RSUs and restricted stock granted |  |  | 966 |  |  | $ | 7.22 |  |
| PSUs, RSUs and restricted stock vested |  |  | (102 | ) |  | $ | 18.47 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (32 | ) |  | $ | 17.36 |  |
| Unvested PSUs RSUs and restricted stock outstanding, March 31, 2024 |  |  | 2,774 |  |  | $ | 13.79 |  |

[0000950170-24-057628:notes:70]
The fair value of PSUs with performance conditions, RSUs and restricted stock is equal to the closing price of the Company's stock on the date of grant. The fair value of PSUs with market conditions is calculated using a Monte Carlo simulation valuation method.

[0000950170-24-057628:notes:71]
As of March 31, 2024, total unrecognized compensation expense related to non-vested portion of performance-based PSUs (considered probable), market-based PSUs, RSUs and restricted stock was approximately $19.4 million, which will be recognized over the remaining weighted-average period of 1.8 years. As of March 31, 2024, there was $10.2 million of unrecognized compensation expense related to unvested performance-based PSUs (not-considered probable), which will be recognized over the remaining requisite service period of 1.8 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0000950170-24-057628:notes:72]
As of March 31, 2024, 0.5 million shares were available for issuance under stockholder-approved equity plans.

[0000950170-24-057628:notes:73]
[same as prior period, unchanged from 0000950170-23-062173:notes:100]

[0000950170-24-057628:notes:74]
The following table summarizes the ADTRAN Holdings, Inc. stock options outstanding as of December 31, 2023 and March 31, 2024 and the changes that occurred during the three months ended March 31, 2024:

[0000950170-24-057628:notes:75]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2023 |  |  | 3,894 |  |  | $ | 10.32 |  |  |  | 5.25 |  |  | $ | 3,087 |  |
| Stock options exercised |  |  | (36 | ) |  | $ | 6.06 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (58 | ) |  | $ | 6.68 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (178 | ) |  | $ | 7.89 |  |  |  |  |  |  |  |
| Stock options outstanding, March 31, 2024 |  |  | 3,622 |  |  | $ | 10.54 |  |  |  | 5.18 |  |  | $ | 268 |  |
| Stock options exercisable, March 31, 2024 |  |  | 1,264 |  |  | $ | 13.30 |  |  |  | 1.43 |  |  | $ | — |  |

[0000950170-24-057628:notes:76]
As of March 31, 2024, there was $6.6 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 1.6 years.

[0000950170-24-057628:notes:77]
The determination of the fair value of stock options assumed or granted by ADTRAN Holdings was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors.

[0000950170-24-057628:notes:78]
[same as prior period, unchanged from 0000950170-23-062173:notes:105]

[0000950170-24-057628:notes:79]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between the Company's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on March 31, 2024. The amount of aggregate intrinsic value was $0.3 million as of March 31, 2024, which will change based on the fair market value of the Company's stock. The total pre-tax intrinsic value of options exercised during the three months ended March 31, 2024 and 2023 was $34 thousand and $43 thousand, respectively. No stock options vested during the three months ended March 31, 2024 and 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-24-057628:notes:80]
5. INVESTMENTS

[0000950170-24-057628:notes:81]
Debt Securities and Other Investments

[0000950170-24-057628:notes:82]
The Company did not have any debt securities and other investments as of March 31, 2024.

[0000950170-24-057628:notes:83]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to its debt securities:

[0000950170-24-057628:notes:84]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | 4 |  |
| Gross realized loss on debt securities |  |  | — |  |  |  | (11 | ) |
| Total loss recognized, net |  | $ | — |  |  | $ | (7 | ) |

[0000950170-24-057628:notes:85]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0000950170-24-057628:notes:86]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Realized gain on equity securities sold |  | $ | 123 |  |  | $ | 13 |  |
| Unrealized gain on equity securities held |  |  | 2,130 |  |  |  | 1,246 |  |
| Total gain recognized, net |  | $ | 2,253 |  |  | $ | 1,259 |  |

[0000950170-24-057628:notes:87]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-24-057628:notes:88]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-24-057628:notes:89]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-24-057628:notes:90]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-24-057628:notes:91]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-24-057628:notes:92]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,375 |  |  | $ | 5,375 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 987 |  |  |  | 987 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 28,265 |  |  |  | 28,265 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 34,627 |  |  | $ | 34,627 |  |  | $ | — |  |  | $ | — |  |

[0000950170-24-057628:notes:93]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,302 |  |  | $ | 5,302 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 905 |  |  |  | 905 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,838 |  |  |  | 26,838 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,045 |  |  | $ | 33,045 |  |  | $ | — |  |  | $ | — |  |

[0000950170-24-057628:notes:94]
Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-24-057628:notes:95]
6. INVENTORY

[0000950170-24-057628:notes:96]
[same as prior period, unchanged from 0000950170-23-062173:notes:132]

[0000950170-24-057628:notes:97]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Raw materials |  | $ | 130,977 |  |  | $ | 152,140 |  |
| Work in process |  |  | 14,856 |  |  |  | 17,239 |  |
| Finished goods |  |  | 176,314 |  |  |  | 192,916 |  |
| Total inventory, net |  | $ | 322,147 |  |  | $ | 362,295 |  |

[0000950170-24-057628:notes:98]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which considers historical usage, known trends, inventory age and market conditions.

[0000950170-24-057628:notes:99]
During the three months ended March 31, 2024, we incurred total charges of $8.8 million as a result of a strategy shift which included discontinuance of certain product lines in connection with the Business Efficiency Program, of which, $4.0 million relates to inventory write-downs and $4.8 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss. There were no write-downs of inventory during the three months ended March 31, 2023.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-24-057628:notes:100]
7. PROPERTY, PLANT AND EQUIPMENT

[0000950170-24-057628:notes:101]
[same as prior period, unchanged from 0000950170-23-062173:notes:137]

[0000950170-24-057628:notes:102]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Engineering and other equipment |  | $ | 184,330 |  |  | $ | 183,336 |  |
| Building |  |  | 79,159 |  |  |  | 79,215 |  |
| Computer hardware and software |  |  | 111,354 |  |  |  | 101,572 |  |
| Building and land improvements |  |  | 57,491 |  |  |  | 58,238 |  |
| Furniture and fixtures |  |  | 21,536 |  |  |  | 21,368 |  |
| Land |  |  | 5,227 |  |  |  | 5,242 |  |
| Total property, plant and equipment |  |  | 459,097 |  |  |  | 448,971 |  |
| Less: accumulated depreciation |  |  | (332,128 | ) |  |  | (325,951 | ) |
| Total property, plant and equipment, net |  | $ | 126,969 |  |  | $ | 123,020 |  |

[0000950170-24-057628:notes:103]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value.

[0000950170-24-057628:notes:104]
Depreciation expense was $7.2 million and $7.6 million for the three months ended March 31, 2024 and 2023, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-24-057628:notes:105]
8. GOODWILL

[0000950170-24-057628:notes:106]
The changes in the carrying amount of goodwill for the three months ended March 31, 2024 are as follows:

[0000950170-24-057628:notes:107]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2023 |  | $ | 297,031 |  |  | $ | 56,384 |  |  | $ | 353,415 |  |
| Goodwill impairment |  |  | (290,528 | ) |  |  | — |  |  |  | (290,528 | ) |
| Foreign currency translation adjustments |  |  | (6,503 | ) |  |  | (1,255 | ) |  |  | (7,758 | ) |
| As of March 31, 2024 |  | $ | — |  |  | $ | 55,129 |  |  | $ | 55,129 |  |

[0000950170-24-057628:notes:108]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company performs its annual goodwill impairment assessment on the first day of the fourth quarter. In addition, the Company performs an interim impairment assessment prior to our October 1st annual measurement date whenever events or changes in circumstances indicate that the carrying amount of such assets (or group of assets) may not be recoverable.

[0000950170-24-057628:notes:109]
During the third quarter of 2023, the Company identified a triggering event due to a decrease in the Company’s market capitalization and changes in projections (decrease in estimated cash flows). While the quantitative impairment analysis indicated that there was no impairment of Network Solutions goodwill, the Company determined that a $37.9 million non-cash impairment charge for goodwill was warranted for the Services & Support reporting unit. During the fourth quarter of 2023, the Company completed its annual

[0000950170-24-057628:notes:110]
impairment test. There were no significant market changes or changes to cash flow projections, as such no triggering event was identified during the fourth quarter of 2023.

[0000950170-24-057628:notes:111]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of each reporting unit using a combination of an income approach and a market based peer group analysis. The significant inputs and assumptions used in the determination of the fair value of our reporting units based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to cash flow projections, discount rate, peer group determination and market multiple selection. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill. No impairment of goodwill was recorded during the three months ended March 31, 2023. As of March 31, 2024, accumulated goodwill impairment losses totaled $330.5 million.

[0000950170-24-057628:notes:112]
Subsequent to March 31, 2024, the Company has experienced volatility in its stock price which reduced the market value of the Company’s common stock as of this filing. The Company will continue to monitor its stock price, operating results and other macroeconomic factors to determine if there is further indication of a sustained decline in fair value requiring an event driven assessment of the recoverability of its remaining goodwill prior to the annual assessment.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-24-057628:notes:113]
9. INTANGIBLE ASSETS

[0000950170-24-057628:notes:114]
[same as prior period, unchanged from 0000950170-23-062173:notes:147]

[0000950170-24-057628:notes:115]
|  |  |  |  | As of March 31, 2024 |  |  | As of December 31, 2023 |  |
| (In thousands) | Weighted Average Useful Life(in years) |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | 10.9 |  |  | $ | 52,754 |  |  | $ | (15,725 | ) |  | $ | 37,029 |  |  | $ | 54,856 |  |  | $ | (15,943 | ) |  | $ | 38,913 |  |
| Backlog |  | 1.6 |  |  |  | 56,106 |  |  |  | (51,712 | ) |  |  | 4,394 |  |  |  | 57,391 |  |  |  | (52,022 | ) |  |  | 5,369 |  |
| Developed technology |  | 8.5 |  |  |  | 322,176 |  |  |  | (69,549 | ) |  |  | 252,627 |  |  |  | 329,369 |  |  |  | (61,271 | ) |  |  | 268,098 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (3,961 | ) |  |  | 1,939 |  |  |  | 5,900 |  |  |  | (3,797 | ) |  |  | 2,103 |  |
| Licensing agreements |  | 8.5 |  |  |  | 560 |  |  |  | (378 | ) |  |  | 182 |  |  |  | 560 |  |  |  | (368 | ) |  |  | 192 |  |
| Trade names |  | 3.0 |  |  |  | 29,024 |  |  |  | (18,747 | ) |  |  | 10,277 |  |  |  | 29,689 |  |  |  | (16,379 | ) |  |  | 13,310 |  |
| Total |  |  |  | $ | 466,520 |  |  | $ | (160,072 | ) |  | $ | 306,448 |  |  | $ | 477,765 |  |  | $ | (149,780 | ) |  | $ | 327,985 |  |

[0000950170-24-057628:notes:116]
Intangible assets are reviewed for impairment whenever events and circumstances indicate impairment may have occurred. The Company assessed impairment triggers related to intangible assets during each financial period in 2024 and 2023. During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer inventory adjustments triggered a quantitative reassessment of our estimated future undiscounted cash flows for our Network Solutions reporting unit. The Company determined that our estimated future undiscounted cash flows exceeded the carrying value of our Network Solutions reporting unit as of March 31, 2024. Our Services & Support asset group is a stable business with gross margins of 58%, the Company has sufficient cash flows that exceed the carrying value as of March 31, 2024. No impairment losses related to intangible assets were recorded during the three months ended March 31, 2024 and 2023.

[0000950170-24-057628:notes:117]
Amortization expense was $14.6 million and $25.8 million in the three months ended March 31, 2024 and 2023, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.

[0000950170-24-057628:notes:118]
[same as prior period, unchanged from 0000950170-23-062173:notes:151]

[0000950170-24-057628:notes:119]
|  |  | As of |  |
| (In thousands) |  | March 31, 2024 |  |
| 2024 |  | $ | 43,396 |  |
| 2025 |  |  | 46,346 |  |
| 2026 |  |  | 43,089 |  |
| 2027 |  |  | 41,725 |  |
| 2028 |  |  | 41,578 |  |
| Thereafter |  |  | 90,314 |  |
| Total |  | $ | 306,448 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-24-057628:notes:120]
10. HEDGING

[0000950170-24-057628:notes:121]
The Company has certain forward rate agreements to hedge foreign currency exposure of expected future cash flows in foreign currency. The Company does not hold or issue derivative instruments for trading or other speculative purposes. Derivatives are initially recognized at fair value on the date a derivative contract is entered into and are subsequently re-measured to their fair value at the end of each reporting period. All changes in the fair value of derivative instruments are recognized as other income (expense) in the Consolidated Statements of Loss and are classified as Level II under the fair value hierarchy. The derivative instruments are not subject to master netting agreements and are not offset in the Consolidated Balance Sheets. We are exposed to risk from credit-related losses resulting from nonperformance by counterparties to our financial instruments. We perform credit evaluations of our counterparties under forward exchange contracts and expect all counterparties to meet their obligations. We have not experienced credit losses from our counterparties. As of March 31, 2024, the Company had 45 forward rate contracts outstanding.

[0000950170-24-057628:notes:122]
[same as prior period, unchanged from 0000950170-23-062173:notes:155]

[0000950170-24-057628:notes:123]
On November 3, 2022, the Company entered into a euro/U.S. dollar forward contract arrangement (the "Initial Forward") with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million for U.S. dollars at a daily fixed forward rate ranging from $1.01 to $1.03. The aggregate amount of €160.0 million is divided into eight quarterly tranches of €20.0 million, which commenced in the fourth quarter of 2022. During the three months ended March 31, 2024, the Company settled one €20.0 million forward contract tranches and the remaining amount will be divided into three quarterly tranches of €20.0 million over the remainder of 2024. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-24-057628:notes:124]
On March 21, 2023, the Company entered into a euro/U.S. dollar forward contract arrangement (the “Forward”) with the Hedge Counterparty. Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of €160.0 million U.S. dollars for euros at a daily fixed forward rate ranging from $1.09 to $1.10 per €1.00. During the three months ended March 31, 2024, the Company settled one $20.0 million forward contract tranches and the remaining amount will be divided into three quarterly tranches of $20.0 million. These forward contracts were executed on March 21, 2023 (to sell EUR/buy USD) and were entered into for the purpose of unwinding the Initial Forward (to buy EUR/sell USD). The drawdown dates of the Initial Forward are set to the same date as the maturity of the new offsetting Forward.

[0000950170-24-057628:notes:125]
The fair values of the Company's derivative instruments recorded in the Condensed Consolidated Balance Sheet as of March 31, 2024 and December 31, 2023 were as follows:

[0000950170-24-057628:notes:126]
| (In thousands) |  | Balance Sheet Location |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  | $ | 4,088 |  |  | $ | 7,125 |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  | $ | (16 | ) |  | $ | (2,277 | ) |
| Total derivatives |  |  |  | $ | 4,072 |  |  | $ | 4,848 |  |

[0000950170-24-057628:notes:127]
The change in the fair values of the Company's derivative instruments recorded in the Condensed Consolidated Statements of Loss during the three months ended March 31, 2024 and 2023 were as follows:

[0000950170-24-057628:notes:128]
|  |  |  |  | Three Months Ended |  |
|  |  |  |  | March 31, |  |
| (In thousands) |  | Income StatementLocation |  | 2024 |  |  | 2023 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense), net |  | $ | 766 |  |  | $ | (69 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000950170-24-057628:notes:129]
11. REVOLVING CREDIT AGREEMENTS

[0000950170-24-057628:notes:130]
The carrying amounts of the Company's non-current revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-24-057628:notes:131]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Wells Fargo credit agreement |  | $ | 195,000 |  |  | $ | 195,000 |  |
| Total non-current revolving credit agreement |  | $ | 195,000 |  |  | $ | 195,000 |  |

[0000950170-24-057628:notes:132]
As of March 31, 2024, the weighted average interest rate on our revolving credit agreements was 8.46%.

[0000950170-24-057628:notes:133]
Wells Fargo Credit Agreement

[0000950170-24-057628:notes:134]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount, as well as the $50.0 million delayed draw term loan facility described below.

[0000950170-24-057628:notes:135]
On August 9, 2023, (the "First Amendment Effective Date") the Company, its wholly-owned direct subsidiary, ADTRAN, Inc. and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and together with the Credit Agreement, the "Credit Facility").

[0000950170-24-057628:notes:136]
The First Amendment, provided for, among other things, a new $50.0 million delayed draw term loan (“DDTL”), which (subject to certain conditions) is available for borrowing in the event of the purchase by the Company of at least sixty percent (60.0%) of the outstanding shares of Adtran Networks SE that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks SE. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through August 9, 2024.

[0000950170-24-057628:notes:137]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-24-057628:notes:138]
On January 16, 2024, the Company entered into a Second Amendment to the Credit Agreement and First Amendment to the Collateral Agreement. The Second Amendment, among other things, provides the Company and its subsidiaries with additional covenant headroom for the fourth quarter of 2023 through the third quarter of 2024 (the "Covenant Relief Period") and adds certain other financial covenants which are described below.

[0000950170-24-057628:notes:139]
On March 12, 2024, the Company entered into a Third Amendment to the Credit Agreement. The Third Amendment, among other things, amends the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024 and June 30, 2024.

[0000950170-24-057628:notes:140]
As of March 31, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $195.0 million. As of March 31, 2024, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. In addition, we may issue up to $50.0 million in letters of credit against our $400.0 million total facility. As of March 31, 2024, we had a total of $2.0 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $203.0 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of March 31, 2024, the Company was in compliance with all covenants.

[0000950170-24-057628:notes:141]
Revolving Line of Credit Interest Rate

[0000950170-24-057628:notes:142]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin) bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.15% per annum).

[0000950170-24-057628:notes:143]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.

[0000950170-24-057628:notes:144]
“Adjusted Term SOFR” means Term SOFR for the applicable interest period plus 0.10% per annum. Adjusted Term SOFR is subject to a floor of 0.00% per annum.

[0000950170-24-057628:notes:145]
All Euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.25% per annum).

[0000950170-24-057628:notes:146]
In addition, (x) if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-057628:notes:147]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

[0000950170-24-057628:notes:148]
The increases in the commitment fee and margin rates during the Covenant Relief Period (referenced above) continue until the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the “Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, the Company has repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the Company has reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) the Company is in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-24-057628:notes:149]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

[0000950170-24-057628:notes:150]
DDTL Interest Rate

[0000950170-24-057628:notes:151]
All U.S. dollar borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.90% to 1.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.40% per annum), or (B) Adjusted Term SOFR plus an applicable margin ranging from 1.90% to 2.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.40% per annum).

[0000950170-24-057628:notes:152]
In addition to paying interest on outstanding principal under the DDTL loan, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment.

[0000950170-24-057628:notes:153]
Covenants Under the Credit Agreement

[0000950170-24-057628:notes:154]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable)::

[0000950170-24-057628:notes:155]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Total Net Leverage Ratio may not exceed 5.00x.

[0000950170-24-057628:notes:156]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

[0000950170-24-057628:notes:157]
•
In the event of the purchase by the Company of at least sixty percent (60%) of the outstanding shares of Adtran Networks SE not owned by the Company as of August 9, 2023 that have been tendered (such event, a “Springing Covenant Event” and the fiscal quarter in which the Springing Covenant Event Occurs and the three consecutive quarterly test periods thereafter, the “Springing Covenant Period”), the following covenant levels:

[0000950170-24-057628:notes:158]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

[0000950170-24-057628:notes:159]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

[0000950170-24-057628:notes:160]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

[0000950170-24-057628:notes:161]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50,000,000 in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

[0000950170-24-057628:notes:162]
•
If a Springing Covenant Period is not in effect, the following covenant levels:

[0000950170-24-057628:notes:163]
•
From December 31, 2023 through and including March 31, 2024: 3.25x.

[0000950170-24-057628:notes:164]
•
From April 1, 2024 through and including June 30, 2024: 3.50x.

[0000950170-24-057628:notes:165]
•
From July 1, 2024 and thereafter: 3.25x.

[0000950170-24-057628:notes:166]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not exceed 1.25x.

[0000950170-24-057628:notes:167]
•
During the Covenant Relief Period or a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million.

[0000950170-24-057628:notes:168]
The Credit Agreement is guaranteed by certain domestic subsidiaries of the Company, and the Company is also required to add certain additional domestic and international subsidiaries as guarantors under the Credit Agreement (such existing and new guarantors, collectively, the “Guarantors”). In addition to the guarantees provided by the Guarantors, the Guarantors have granted (or will grant) security interests in favor of the Administrative Agent over substantially all tangible and intangible assets, and the Borrower will grant mortgages in favor of the Administrative Agent over certain owned real estate assets. The Company is currently in negotiations with the Administrative Agent regarding a potential further amendment to the Credit Agreement to address the addition of certain foreign subsidiary guarantors.

[0000950170-24-057628:notes:169]
The Credit Agreement provides for revolving borrowings of up to $400.0 million in aggregate principal amount, as well as an additional $50.0 million delayed draw term loan tranche that would be available upon a Springing Covenant Event. It also continues to permit the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement subject to certain limitations and minimum payment thresholds.

[0000950170-24-057628:notes:170]
During the Covenant Relief Period, the Company is not permitted to make certain dividend payments to the Company's Stockholders or certain other Restricted Payments. However, the Company is permitted to make the Recurring Compensation Payment to each Adtran Networks shareholder (other than the Company), pursuant to the terms of the DPLTA.

[0000950170-24-057628:notes:171]
Furthermore, the Credit Agreement, as amended, contain customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts; however, certain of the exceptions and carveouts are not permitted to be used during the Covenant Relief Period. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-24-057628:notes:172]
12. EMPLOYEE BENEFIT PLANS

[0000950170-24-057628:notes:173]
Pension Benefit Plan

[0000950170-24-057628:notes:174]
We maintain a defined benefit pension plan covering employees in certain foreign countries. The Company's net non-current pension liability for all defined benefit pension plans totaled $11.7 million and $12.5 million as of March 31, 2024 and December 31, 2023, respectively and the net current pension liability for all defined benefit pension plans totaled $0.1 million as of March 31, 2024 and December 31, 2023, which is included in accounts payable on the Condensed Consolidated Balance Sheets. The Company's defined benefit pension liability represents the projected benefit obligation, which is the actuarial present value of the vested benefits to which the employee is currently entitled based on the employee's expected date of retirement.

[0000950170-24-057628:notes:175]
[same as prior period, unchanged from 0000950170-23-062173:notes:206]

[0000950170-24-057628:notes:176]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Service cost |  | $ | 340 |  |  | $ | 398 |  |
| Interest cost |  |  | 285 |  |  |  | (32 | ) |
| Expected return on plan assets |  |  | (360 | ) |  |  | 58 |  |
| Amortization of actuarial losses |  |  | 2 |  |  |  | 6 |  |
| Net periodic pension cost |  | $ | 267 |  |  | $ | 430 |  |

[0000950170-24-057628:notes:177]
The components of net periodic pension cost, other than the service cost component, are included in other income, net in the Condensed Consolidated Statements of Loss. Service cost is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss. The Company made contributions to the defined benefit pension plans totaling $1.2 million and $1.0 million during the three months ended March 31, 2024 and 2023, respectively. Contributions to the defined benefit pension plans for the remainder of 2024 will be limited to benefit payments to retirees which are paid out of the operating cash flows of the Company and are expected to be approximately $3.5 million.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-24-057628:notes:178]
13. EQUITY

[0000950170-24-057628:notes:179]
Accumulated Other Comprehensive Income

[0000950170-24-057628:notes:180]
The following tables present the changes in accumulated other comprehensive income, net of tax, by component:

[0000950170-24-057628:notes:181]
|  |  | Three Months Ended March 31, 2024 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2023 |  | $ | (382 | ) |  | $ | (2,506 | ) |  | $ | 49,964 |  |  | $ | 385 |  |  | $ | 47,461 |  |
| Other comprehensive loss before reclassifications |  |  | (119 | ) |  |  | — |  |  |  | (17,745 | ) |  |  | — |  |  |  | (17,864 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 119 |  |  |  | (60 | ) |  |  | — |  |  |  | — |  |  |  | 59 |  |
| Net current period other comprehensive loss |  |  | — |  |  |  | (60 | ) |  |  | (17,745 | ) |  |  | — |  |  |  | (17,805 | ) |
| Balance as of March 31, 2024 |  | $ | (382 | ) |  | $ | (2,566 | ) |  | $ | 32,219 |  |  | $ | 385 |  |  | $ | 29,656 |  |

[0000950170-24-057628:notes:182]
|  |  | Three Months Ended March 31, 2023 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2022 |  | $ | (836 | ) |  | $ | (1,016 | ) |  | $ | 27,593 |  |  | $ | 385 |  |  | $ | 26,126 |  |
| Other comprehensive income before reclassifications |  |  | 83 |  |  |  | — |  |  |  | 8,678 |  |  |  | — |  |  |  | 8,761 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (14 | ) |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |
| Net current period other comprehensive income |  |  | 69 |  |  |  | 35 |  |  |  | 8,678 |  |  |  | — |  |  |  | 8,782 |  |
| Less: Comprehensive income attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | 382 |  |  |  | — |  |  |  | 382 |  |
| Balance as of March 31, 2023 |  | $ | (767 | ) |  | $ | (981 | ) |  | $ | 35,889 |  |  | $ | 385 |  |  | $ | 34,526 |  |

[0000950170-24-057628:notes:183]
The following tables present the details of reclassifications out of accumulated other comprehensive income:

[0000950170-24-057628:notes:184]
|  |  | Three Months Ended March 31, 2024 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in theStatement Where Net(Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (161 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial gain |  |  | 87 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (74 | ) |  |  |
| Tax benefit |  |  | 15 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (59 | ) |  |  |

[0000950170-24-057628:notes:185]
[same as prior period, unchanged from 0000950170-23-062173:notes:218]

[0000950170-24-057628:notes:186]
|  |  | Three Months Ended March 31, 2023 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net (Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 18 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial loss |  |  | (51 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (33 | ) |  |  |
| Tax benefit |  |  | 12 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (21 | ) |  |  |

[0000950170-24-057628:notes:187]
[same as prior period, unchanged from 0000950170-23-062173:notes:222]

[0000950170-24-057628:notes:188]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | March 31, 2024 |  |  | March 31, 2023 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized (loss) gain on available-for-sale securities |  | $ | (161 | ) |  | $ | 42 |  |  | $ | (119 | ) |  | $ | 109 |  |  | $ | (26 | ) |  | $ | 83 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net gain (loss) |  |  | 161 |  |  |  | (42 | ) |  |  | 119 |  |  |  | (18 | ) |  |  | 4 |  |  |  | (14 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) gain |  |  | (87 | ) |  |  | 27 |  |  |  | (60 | ) |  |  | 51 |  |  |  | (16 | ) |  |  | 35 |  |
| Foreign currency translation adjustments |  |  | (17,745 | ) |  |  | — |  |  |  | (17,745 | ) |  |  | 8,678 |  |  |  | — |  |  |  | 8,678 |  |
| Total Other Comprehensive (Loss) Income |  | $ | (17,832 | ) |  | $ | 27 |  |  | $ | (17,805 | ) |  | $ | 8,820 |  |  | $ | (38 | ) |  | $ | 8,782 |  |


## us-gaap:RedeemableNoncontrollingInterestTableTextBlock

[0000950170-24-057628:notes:189]
The following table summarizes the redeemable non-controlling interest activity for the three months ended March 31, 2024 and for the year ended December 31, 2023:

[0000950170-24-057628:notes:190]
|  |  | Three Months Ended |  |  | For the Year Ended |  |
| (In thousands) |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Balance at beginning of period |  | $ | 451,756 |  |  | $ | — |  |
| Reclassification of non-controlling interests |  |  | — |  |  |  | 443,757 |  |
| Fair value on redemption of redeemable non-controlling interest |  |  | (6 | ) |  |  | (1,657 | ) |
| Net income attributable to redeemable non-controlling interests |  |  | 2,880 |  |  |  | 11,525 |  |
| Annual recurring compensation earned |  |  | (2,880 | ) |  |  | (11,525 | ) |
| Adtran Networks stock option exercises |  |  | — |  |  |  | 52 |  |
| Translation adjustment |  |  | (10,115 | ) |  |  | 9,604 |  |
| Balance at end of period |  | $ | 441,635 |  |  | $ | 451,756 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-057628:notes:191]
15. LOSS PER SHARE

[0000950170-24-057628:notes:192]
[same as prior period, unchanged from 0000950170-23-062173:notes:228]

[0000950170-24-057628:notes:193]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2024 |  |  | 2023 |  |
| Numerator |  |  |  |  |  |  |
| Net loss attributable to ADTRAN Holdings, Inc. |  | $ | (324,550 | ) |  | $ | (40,083 | ) |
| Denominator |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 78,814 |  |  |  | 78,358 |  |
| Effect of dilutive securities |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 78,814 |  |  |  | 78,358 |  |
| Loss per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (4.12 | ) |  | $ | (0.51 | ) |
| Loss per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (4.12 | ) |  | $ | (0.51 | ) |

[0000950170-24-057628:notes:194]
For the three months ended March 31, 2024 and 2023, 1.1 million and 0.1 million shares, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0000950170-24-057628:notes:195]
For the three months ended March 31, 2024 and 2023, 3.5 million and 0.4 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the applicable period, making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-057628:notes:196]
16. SEGMENT INFORMATION

[0000950170-24-057628:notes:197]
[same as prior period, unchanged from 0000950170-23-062173:notes:233]

[0000950170-24-057628:notes:198]
[same as prior period, unchanged from 0000950170-23-062173:notes:234]

[0000950170-24-057628:notes:199]
[same as prior period, unchanged from 0000950170-23-062173:notes:235]

[0000950170-24-057628:notes:200]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain, other income (expense), net and income tax benefit are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-24-057628:notes:201]
[same as prior period, unchanged from 0000950170-23-062173:notes:237]

[0000950170-24-057628:notes:202]
|  |  | Three Months Ended |  |
|  |  | March 31, 2024 |  |  | March 31, 2023 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 181,273 |  |  | $ | 46,165 |  |  | $ | 282,418 |  |  | $ | 63,288 |  |
| Services & Support |  |  | 44,900 |  |  |  | 26,090 |  |  |  | 41,494 |  |  |  | 24,520 |  |
| Total |  | $ | 226,173 |  |  | $ | 72,255 |  |  | $ | 323,912 |  |  | $ | 87,808 |  |

[0000950170-24-057628:notes:203]
For the three months ended March 31, 2024 and 2023, $1.6 million and $1.5 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the three months ended March 31, 2024 and 2023, $8 and $2
thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0000950170-24-057628:notes:204]
[same as prior period, unchanged from 0000950170-23-062173:notes:243]

[0000950170-24-057628:notes:205]
[same as prior period, unchanged from 0000950170-23-062173:notes:244]

[0000950170-24-057628:notes:206]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| United States |  | $ | 83,290 |  |  | $ | 131,466 |  |
| Germany |  |  | 39,741 |  |  |  | 76,286 |  |
| United Kingdom |  |  | 52,740 |  |  |  | 57,397 |  |
| Other international |  |  | 50,402 |  |  |  | 58,763 |  |
| Total |  | $ | 226,173 |  |  | $ | 323,912 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-24-057628:notes:207]
17. LIABILITY FOR WARRANTY RETURNS

[0000950170-24-057628:notes:208]
The Company's products generally include warranties of 90 days to five years for product defects. The Company accrues for warranty returns at the time of product shipment based on its historical return rate and estimate of the cost to repair or replace the defective products. The Company engages in extensive product quality programs and processes, including actively monitoring and evaluating the quality of its component suppliers. The increasing complexity of the Company's products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should the Company's actual experience relative to these factors be worse than its estimates, the Company will be required to record additional warranty expense. The liability for warranty obligations totaled $6.2 million and $6.4 million as of March 31, 2024 and December 31, 2023, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. The warranty expense and write-off activity for the three months ended March 31, 2024 and 2023 are summarized as follows:

[0000950170-24-057628:notes:209]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 6,445 |  |  | $ | 7,196 |  |
| Plus: Amounts charged to cost and expenses |  |  | 646 |  |  |  | 1,077 |  |
| Plus: Foreign currency translation adjustments |  |  | (54 | ) |  |  | 26 |  |
| Less: Deductions |  |  | (816 | ) |  |  | (1,099 | ) |
| Balance at end of period |  | $ | 6,221 |  |  | $ | 7,200 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-057628:notes:210]
18. COMMITMENTS AND CONTINGENCIES

[0000950170-24-057628:notes:211]
Legal Matters

[0000950170-24-057628:notes:212]
From time to time, the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

[0000950170-24-057628:notes:213]
DPLTA Exit and Recurring Compensation Costs

[0000950170-24-057628:notes:214]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.5 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2024 and 2023, we accrued $2.9 million and $2.8 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit. With respect to the year ended December 31, 2023, we are obligated to pay $11.5 million in Annual Recurring Compensation on the third banking day following the 2024 ordinary general shareholders’ meeting of Adtran Networks, which is expected to occur on June 28, 2024 (but in any event within eight months following December 31, 2023).

[0000950170-24-057628:notes:215]
For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or

[0000950170-24-057628:notes:216]
approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders.

[0000950170-24-057628:notes:217]
Performance Bonds

[0000950170-24-057628:notes:218]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2024 and December 31, 2023, we had commitments related to these bonds totaling $10.6 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-24-057628:notes:219]
Purchase Obligations

[0000950170-24-057628:notes:220]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for short-term product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of March 31, 2024, purchase obligations totaled $238.0 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-057628:notes:221]
19. RESTRUCTURING

[0000950170-24-057628:notes:222]
During the fourth quarter of 2022, the Company initiated a restructuring program designed to optimize the assets, business processes, and information technology systems of the Company in relation to the Business Combination with Adtran Networks. The restructuring program is expected to maximize cost synergies by realizing operation scale, combining sales channels, streamlining corporate and general and administrative functions, including human capital resources and combining sourcing and production costs. This restructuring program is expected to be completed in late 2024 and includes expenses specifically associated with achieving run-rate synergies as well as Business Efficiency Program expenses described below.

[0000950170-24-057628:notes:223]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (the “Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expands upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment. Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). On October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze. Additionally, on April 11, 2024, management determined to close a facility in Greifswald, Germany. The closure of the facility is expected to be substantially completed by June 30, 2024.

[0000950170-24-057628:notes:224]
During the three months ended March 31, 2024, we recognized $17.1 million of costs related to the Business Efficiency Program. The costs recognized during the three months ended March 31, 2024, included charges of $8.8 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.0 million relates to inventory write-downs and $4.8 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss. Since the inception of the Business Efficiency Program, we recognized $42.2 million of costs. We expect costs in the second quarter 2024 and thereafter relating to the Business Efficiency Program to range between $20.6 million and $35.8 million. Management expects these planned costs to include severance costs ranging from $17.3 million to $28.3 million in connection with an early retirement program and reductions in workforce and site consolidation transaction expenses (primarily brokers fees and Greifswald exit costs) ranging from $3.3 million to $7.5 million. Future cash payments include: severance costs and outplacement fees that are anticipated to be in the range of $18.1 million to $29.1 million and payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $3.1 million to $7.3 million. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures.  However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing. If required, we will amend this disclosure at such time as management is able in good faith to estimate the amount, or range of amounts, of these charges.

[0000950170-24-057628:notes:225]
For the three months ended March 31, 2023, we recognized $2.4 million of restructuring costs relating to the Business Combination under the multi-year integration program and synergy realization that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss.

[0000950170-24-057628:notes:226]
A reconciliation of the beginning and ending restructuring liabilities, which is included in accrued wages and benefits and accounts payable in the Condensed Consolidated Balance Sheets as of March 31, 2024 and December 31, 2023, is as follows:

[0000950170-24-057628:notes:227]
|  |  | Three Months Ended |  |
| (In thousands) |  | March 31, 2024 |  |
| Balance at beginning of period |  | $ | 8,309 |  |
| Plus: Amounts charged to cost and expense |  |  | 13,118 |  |
| Less: Amounts paid |  |  | (11,075 | ) |
| Balance as of March 31, 2024 |  | $ | 10,352 |  |

[0000950170-24-057628:notes:228]
|  |  | For the Year Ended |  |
| (In thousands) |  | December 31, 2023 |  |
| Balance as of December 31, 2022 |  | $ | 159 |  |
| Plus: Amounts charged to cost and expense |  |  | 22,241 |  |
| Less: Amounts paid |  |  | (14,091 | ) |
| Balance as of December 31, 2023 |  | $ | 8,309 |  |

[0000950170-24-057628:notes:229]
Restructuring expenses included in the Condensed Consolidated Statements of Loss are for the three months ended March 31, 2024 and 2023:

[0000950170-24-057628:notes:230]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Network Solutions - Cost of revenue |  | $ | 2,318 |  |  | $ | 58 |  |
| Network Solutions - inventory write-down |  |  | 8,782 |  |  |  | — |  |
| Services & Support - Cost of revenue |  |  | 148 |  |  |  | 18 |  |
| Cost of revenue |  | $ | 11,248 |  |  | $ | 76 |  |
| Selling, general and administrative expenses |  |  | 1,801 |  |  |  | 2,180 |  |
| Research and development expenses |  |  | 4,061 |  |  |  | 181 |  |
| Total restructuring expenses |  | $ | 17,110 |  |  | $ | 2,437 |  |

[0000950170-24-057628:notes:231]
The following table represents the components of restructuring expenses by geographic area for the three months ended March 31, 2024 and 2023:

[0000950170-24-057628:notes:232]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| United States |  | $ | 15,060 |  |  | $ | 1,119 |  |
| International |  |  | 2,050 |  |  |  | 1,318 |  |
| Total restructuring expenses |  | $ | 17,110 |  |  | $ | 2,437 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-24-057628:notes:233]
20. SUBSEQUENT EVENTS

[0000950170-24-057628:notes:234]
Facility Closure

[0000950170-24-057628:notes:235]
In connection with the Business Efficiency Program, management of the Company determined on April 11, 2024 to close the Company’s facility in Greifswald, Germany. The closure of the facility is expected to be substantially completed by June 30, 2024.
