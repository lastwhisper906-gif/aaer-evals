# ADTN notes — 0001564590-19-005179


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-19-005179:notes:1]
Note 1 – Nature of Business and Summary of Significant Accounting Policies

[0001564590-19-005179:notes:2]
At ADTRAN, Inc., we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking.

[0001564590-19-005179:notes:3]
Principles of Consolidation

[0001564590-19-005179:notes:4]
The consolidated financial statements include ADTRAN and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-19-005179:notes:5]
Use of Estimates

[0001564590-19-005179:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include obsolete and excess inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-19-005179:notes:7]
Cash and Cash Equivalents

[0001564590-19-005179:notes:8]
Cash and cash equivalents represent demand deposits, money market funds, and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions, and determined the risk of material financial loss due to the exposure of such credit risk to be minimal. As of December 31, 2018, $102.2 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits.

[0001564590-19-005179:notes:9]
Financial Instruments

[0001564590-19-005179:notes:10]
The carrying amounts reported in the consolidated balance sheets for cash and cash equivalents, accounts receivable, and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments. The carrying amount reported for bonds payable was $25.6 million, compared to an estimated fair value of $25.4 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA.

[0001564590-19-005179:notes:11]
Investments with contractual maturities beyond one year may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe we have the ability to quickly sell them to the remarketing agent, tender agent, or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. All income generated from these investments was recorded as interest income. We have not been required to record any losses relating to variable rate demand notes.

[0001564590-19-005179:notes:12]
Long-term investments represent a restricted certificate of deposit held at cost, deferred compensation plan assets, corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. and foreign government bonds, marketable equity securities and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Any changes in fair value are recognized in net investment gain (loss). Realized gains and losses on sales of debt securities are computed under the specific identification method and are included in current income. See Note 5 of Notes to Consolidated Financial Statements for additional information.

[0001564590-19-005179:notes:13]
Accounts Receivable

[0001564590-19-005179:notes:14]
We record accounts receivable at net realizable value. Prior to establishing payment terms for a new customer, we evaluate the credit risk of the customer. Credit limits and payment terms established for new customers are re-evaluated periodically based on customer collection experience and other financial factors. At December 31, 2018, single customers comprising more than 10% of our total accounts receivable balance included three customers, which accounted for 45.8% of our total accounts receivable. As of December 31, 2017, single customers comprising more than 10% of our total accounts receivable balance included two customers, which accounted for 63.8% of our total accounts receivable.

[0001564590-19-005179:notes:15]
We regularly review the need to maintain an allowance for doubtful accounts and consider factors such as the age of accounts receivable balances, the current economic conditions that may affect a customer’s ability to pay, significant one-time events and our historical experience. If the financial condition of a customer deteriorates, resulting in an impairment of their ability to make payments, we may be required to record an allowance for doubtful accounts. If circumstances change with regard to individual receivable balances that have previously been determined to be uncollectible (and for which a specific reserve has been established), a reduction in our allowance for doubtful accounts may be required. Our allowance for doubtful accounts was $0.1 million and zero as of December 31, 2018 and December 31, 2017, respectively.

[0001564590-19-005179:notes:16]
Other Receivables

[0001564590-19-005179:notes:17]
Other receivables are comprised primarily of lease receivables, amounts due from subcontract manufacturers for product component transfers, unbilled receivables, investment loan, amounts due from various jurisdictions for value-added tax, and income tax receivable.

[0001564590-19-005179:notes:18]
Inventory

[0001564590-19-005179:notes:19]
Inventory is carried at the lower of cost and net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory. Standard costs are updated at least quarterly; therefore, inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess, obsolete or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand, market conditions and life. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 7 of Notes to Consolidated Financial Statements for additional information.

[0001564590-19-005179:notes:20]
Property, Plant and Equipment

[0001564590-19-005179:notes:21]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. We depreciate building and land improvements from five to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years, and computer software from three to five years. Expenditures for repairs and maintenance are charged to expense as incurred. Major improvements that materially prolong the lives of the assets are capitalized. Gains and losses on the disposal of property, plant and equipment are recorded in operating income. See Note 8 of Notes to Consolidated Financial Statements for additional information.

[0001564590-19-005179:notes:22]
Intangible Assets

[0001564590-19-005179:notes:23]
Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets, which is two to 14 years. See Note 10 of Notes to Consolidated Financial Statements for additional information.

[0001564590-19-005179:notes:24]
Impairment of Long-Lived Assets and Intangibles

[0001564590-19-005179:notes:25]
We review long-lived assets used in operations and intangible assets for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. An impairment loss would be recognized in the amount by which the recorded value of the asset exceeds the fair value of the asset, measured by the quoted market price of an asset or an estimate based on the best information available in the circumstances. There were no impairment losses for long-lived assets or intangible assets recognized during the years ended December 31, 2018, 2017 or 2016.

[0001564590-19-005179:notes:26]
Goodwill

[0001564590-19-005179:notes:27]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2018, we concluded that it was not necessary to perform the two-step impairment test. There were no impairment losses on goodwill recognized during the years ended December 31, 2018, 2017 and 2016.

[0001564590-19-005179:notes:28]
Liability for Warranty

[0001564590-19-005179:notes:29]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.6 million and $9.7 million as of December 31, 2018 and 2017, respectively. These liabilities are included in accrued expenses in the accompanying consolidated balance sheets. During 2017, we recorded a reduction in warranty expense related to a settlement with a third party supplier for a defective component, the impact of which is reflected in the following table.

[0001564590-19-005179:notes:30]
A summary of warranty expense and write-off activity for the years ended December 31, 2018, 2017 and 2016 is as follows:

[0001564590-19-005179:notes:31]
| Year Ended December 31, |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| (In thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 9,724 |  |  | $ | 8,548 |  |  | $ | 8,739 |  |
| Plus: Amounts charged to cost and expenses |  |  | 7,392 |  |  |  | 6,951 |  |  |  | 8,561 |  |
| Less: Deductions |  |  | (8,493 | ) |  |  | (5,775 | ) |  |  | (8,752 | ) |
| Balance at end of period |  | $ | 8,623 |  |  | $ | 9,724 |  |  | $ | 8,548 |  |

[0001564590-19-005179:notes:32]
Pension Benefit Plan Obligations

[0001564590-19-005179:notes:33]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $13.1 million and $8.3 million at December 31, 2018 and 2017, respectively. This liability is included in other non-current liabilities in the accompanying consolidated balance sheets.

[0001564590-19-005179:notes:34]
Stock-Based Compensation

[0001564590-19-005179:notes:35]
We have two Board and stockholder-approved stock incentive plans from which stock options, performance stock units (PSUs), restricted stock units (RSUs) and restricted stock are available for grant to employees and directors. All employee and director stock options granted under our stock option plans have an exercise price equal to the fair market value of the award, as defined in the plan, of the underlying common stock on the grant date. All of our outstanding stock option awards are classified as equity awards.

[0001564590-19-005179:notes:36]
Stock-based compensation expense recognized for the years ended December 31, 2018, 2017 and 2016 was approximately $7.2 million, $7.4 million and $6.7 million, respectively. As of December 31, 2018, total compensation cost related to non-vested stock options, PSUs, RSUs and restricted stock not yet recognized was approximately $18.6 million, which is expected to be recognized over an average remaining recognition period of 2.9 years. In addition, there was $9.1 million of unrecognized compensation expense related to unvested 2017 performance-based PSUs, which will be recognized over the remaining requisite service period if achievement of the performance obligation becomes probable. See Note 4 of Notes to Consolidated Financial Statements for additional information.

[0001564590-19-005179:notes:37]
Research and Development Costs

[0001564590-19-005179:notes:38]
Research and development costs include compensation for engineers and support personnel, outside contracted services, depreciation and material costs associated with new product development, enhancement of current products and product cost reductions. We continually evaluate new product opportunities and engage in intensive research and product development efforts. Research and development costs totaled $124.5 million, $130.7 million and $124.9 million for the years ended December 31, 2018, 2017 and 2016, respectively.

[0001564590-19-005179:notes:39]
Other Comprehensive Income

[0001564590-19-005179:notes:40]
Other comprehensive income consists of unrealized gains (losses) on available-for-sale debt securities, unrealized gains (losses) on cash flow hedges, reclassification adjustments for amounts included in net income related to impairments of available-for-sale securities, realized gains (losses) on debt securities, realized gains (losses) on cash flow hedges, and amortization of actuarial gains (losses) related to our defined benefit plan, defined benefit plan adjustments, and foreign currency translation adjustments.

[0001564590-19-005179:notes:41]
The following table presents changes in accumulated other comprehensive income, net of tax, by component for the years ended December 31, 2018, 2017 and 2016:

[0001564590-19-005179:notes:42]
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Balance at December 31, 2015 |  | $ | 1,932 |  |  | $ | — |  |  | $ | (3,895 | ) |  | $ | (7,006 | ) |  | $ | (8,969 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,515 |  |  |  | — |  |  |  | (1,229 | ) |  |  | (569 | ) |  |  | (283 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (3,043 | ) |  |  | — |  |  |  | 107 |  |  |  | — |  |  |  | (2,936 | ) |
| Balance at December 31, 2016 |  |  | 404 |  |  |  | — |  |  |  | (5,017 | ) |  |  | (7,575 | ) |  |  | (12,188 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 5,020 |  |  |  | (619 | ) |  |  | 451 |  |  |  | 5,999 |  |  |  | 10,851 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,857 | ) |  |  | 619 |  |  |  | 280 |  |  |  | — |  |  |  | (1,958 | ) |
| Balance at December 31, 2017 |  |  | 2,567 |  |  |  | — |  |  |  | (4,286 | ) |  |  | (1,576 | ) |  |  | (3,295 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 685 |  |  |  | — |  |  |  | (3,890 | ) |  |  | (4,236 | ) |  |  | (7,441 | ) |
| Amounts reclassified to retained earnings (1) |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (595 | ) |  |  | — |  |  |  | 135 |  |  |  | — |  |  |  | (460 | ) |
| Balance at December 31, 2018 |  | $ | (563 | ) |  | $ | — |  |  | $ | (8,041 | ) |  | $ | (5,812 | ) |  | $ | (14,416 | ) |

[0001564590-19-005179:notes:43]
| (1) | With the adoption of ASU 2016-01, the unrealized gains on our equity investments were reclassified to retained earnings. See Recently Issued Accounting Standards later in Note 1 for more information. |

[0001564590-19-005179:notes:44]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the years ended December 31, 2018, 2017 and 2016:

[0001564590-19-005179:notes:45]
| (In thousands) |  | 2018 |
| Details about Accumulated Other Comprehensive Loss Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 804 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (196 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 608 |  |  |  |
| Tax expense |  |  | (148 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 460 |  |  |  |

[0001564590-19-005179:notes:46]
| (1) | Included in the computation of net periodic pension cost. See Note 13 of Notes to Consolidated Financial Statements. |

[0001564590-19-005179:notes:47]
| (In thousands) |  | 2017 |
| Details about Accumulated Other Comprehensive Loss Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 4,864 |  |  | Net investment gain (loss) |
| Impairment expense |  |  | (180 | ) |  | Net investment gain (loss) |
| Net losses on derivatives designated as hedging instruments |  |  | (897 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (406 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 3,381 |  |  |  |
| Tax expense |  |  | (1,423 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,958 |  |  |  |

[0001564590-19-005179:notes:48]
|  | (0) | Included in the computation of net periodic pension cost. See Note 13 of Notes to Consolidated Financial Statements. |

[0001564590-19-005179:notes:49]
| (In thousands) |  | 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 5,408 |  |  | Net investment gain (loss) |
| Impairment expense |  |  | (419 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (156 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 4,833 |  |  |  |
| Tax expense |  |  | (1,897 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,936 |  |  |  |

[0001564590-19-005179:notes:50]
The following tables present the tax effects related to the change in each component of other comprehensive income (loss) for the years ended December 31, 2018, 2017 and 2016:

[0001564590-19-005179:notes:51]
|  |  | 2018 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 926 |  |  | $ | (241 | ) |  | $ | 685 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net loss |  |  | (804 | ) |  |  | 209 |  |  |  | (595 | ) |
| Reclassification adjustment for amounts reclassed to retained earnings related to the adoption of ASU 2016-01 |  |  | (4,351 | ) |  |  | 1,131 |  |  |  | (3,220 | ) |
| Defined benefit plan adjustments |  |  | (5,638 | ) |  |  | 1,748 |  |  |  | (3,890 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net loss |  |  | 196 |  |  |  | (61 | ) |  |  | 135 |  |
| Foreign currency translation adjustment |  |  | (4,236 | ) |  |  | — |  |  |  | (4,236 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (13,907 | ) |  | $ | 2,786 |  |  | $ | (11,121 | ) |

[0001564590-19-005179:notes:52]
|  |  | 2017 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 8,230 |  |  | $ | (3,210 | ) |  | $ | 5,020 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (4,684 | ) |  |  | 1,827 |  |  |  | (2,857 | ) |
| Unrealized gains (losses) on cash flow hedges |  |  | (897 | ) |  |  | 278 |  |  |  | (619 | ) |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | 897 |  |  |  | (278 | ) |  |  | 619 |  |
| Defined benefit plan adjustments |  |  | 654 |  |  |  | (203 | ) |  |  | 451 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 406 |  |  |  | (126 | ) |  |  | 280 |  |
| Foreign currency translation adjustment |  |  | 5,999 |  |  |  | — |  |  |  | 5,999 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 10,605 |  |  | $ | (1,712 | ) |  | $ | 8,893 |  |

[0001564590-19-005179:notes:53]
|  |  | 2016 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 2,484 |  |  | $ | (969 | ) |  | $ | 1,515 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (4,989 | ) |  |  | 1,946 |  |  |  | (3,043 | ) |
| Defined benefit plan adjustments |  |  | (1,782 | ) |  |  | 553 |  |  |  | (1,229 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 156 |  |  |  | (49 | ) |  |  | 107 |  |
| Foreign currency translation adjustment |  |  | (569 | ) |  |  | — |  |  |  | (569 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (4,700 | ) |  | $ | 1,481 |  |  | $ | (3,219 | ) |

[0001564590-19-005179:notes:54]
Income Taxes

[0001564590-19-005179:notes:55]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax bases of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0001564590-19-005179:notes:56]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001564590-19-005179:notes:57]
On December 22, 2017, the Tax Cuts and Jobs Act (the Act) was signed into law. As a result of the Act, we recognized an estimated expense of $11.9 million in the fourth quarter of 2017, of which $9.2 million related to the write-down of deferred tax assets and $2.7 million related to tax on unrepatriated foreign earnings. We calculated our best estimate of the impact of the Act in our 2017 year-end income tax provision, in accordance with Staff Accounting Bulletin No. 118, which was issued to address the application of U.S. GAAP in situations when a registrant does not have the necessary information available, prepared or analyzed to finalize the accounting for certain income tax effects of the Act. Additional work to complete a more detailed analysis of historical foreign earnings, as well as the full impact relating to the write-down of deferred tax assets, was completed in the third quarter of 2018 and resulted in a tax benefit of $4.0 million.

[0001564590-19-005179:notes:58]
Foreign Currency

[0001564590-19-005179:notes:59]
We record transactions denominated in foreign currencies on a monthly basis using exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are remeasured at the balance sheet dates using the closing rates of exchange between those foreign currencies and the functional currency with any transaction gains or losses reported in other income (expense). Our primary exposures to foreign currency exchange rate movements are with our German subsidiary, whose functional currency is the Euro, our Australian subsidiary, whose functional currency is the Australian dollar, and our Mexican subsidiary, whose functional currency is the U.S. dollar. Adjustments resulting from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive income (loss).

[0001564590-19-005179:notes:60]
Revenue Recognition

[0001564590-19-005179:notes:61]
On January 1, 2018 we adopted ASU 2014-09, Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition.

[0001564590-19-005179:notes:62]
Accounting Policy under Topic 606

[0001564590-19-005179:notes:63]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value-added, and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general, and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0001564590-19-005179:notes:64]
A portion of our products is sold to a non-exclusive distribution network of major technology distributors in the United States. These large organizations then distribute or provide fulfillment services to an extensive network of VARs and Sis. VARs and Sis may be affiliated with us as a channel partner, or they may purchase from the distributor in an unaffiliated fashion. Additionally, with certain limitations our distributors may return unused and unopened product for stock-balancing purposes when such returns are accompanied by offsetting orders for products of equal or greater value.

[0001564590-19-005179:notes:65]
We participate in cooperative advertising and market development programs with certain customers. We use these programs to reimburse customers for certain forms of advertising, and in general, to allow our customers credits up to a specified percentage of their net purchases. Our costs associated with these programs are estimated and included in marketing expenses in our consolidated statements of income. We also participate in rebate programs to provide sales incentives for certain products. Our costs associated with these programs are estimated and accrued at the time of sale, and are recorded as a reduction of sales in our consolidated statements of income.

[0001564590-19-005179:notes:66]
Accounting Policy under Topic 605

[0001564590-19-005179:notes:67]
Revenue was generally recognized when persuasive evidence of an arrangement exists, delivery has occurred, the product price was fixed or determinable, collection of the resulting receivable was reasonably assured, and product returns were reasonably estimable. For product sales, revenue was generally recognized upon shipment of the product to our customer in accordance with the title transfer terms of the sales agreement, generally Ex Works, per International Commercial Terms. In the case of consigned inventory, revenue was recognized when the end customer assumes ownership of the product. Contracts that contained multiple deliverables were evaluated to determine the units of accounting, and the consideration from the arrangement was allocated to each unit of accounting based on the relative selling price and corresponding terms of the contract. When this was not available, we were generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. In these instances, we used best estimates to allocate consideration to each respective unit of accounting. These estimates included analysis of respective bills of material and review and analysis of similar product and service offerings. We recorded revenue associated with installation services when respective contractual obligations are complete. In instances where customer acceptance was required, revenue was deferred until respective acceptance criteria were met. Contracts that included both installation services and product sales were evaluated for revenue recognition in accordance with contract terms. As a result, installation services may have been considered a separate deliverable or may have been considered a combined single unit of accounting with the delivered product. Generally, either the purchaser, ADTRAN, or a third party would perform the installation of our products. Shipping fees were recorded as revenue and the related costs were included in cost of sales. Sales taxes invoiced to customers were included in revenues, and represented less than one percent of total revenues. The corresponding sales taxes paid were included in cost of goods sold. Value-added taxes collected from customers in international jurisdictions were recorded in accrued expenses as a liability. Revenue was recorded net of discounts. Sales returns were recorded as a reduction of revenue and accrued based on historical sales return experience, which we believed provided a reasonable estimate of future returns.

[0001564590-19-005179:notes:68]
Unearned Revenue

[0001564590-19-005179:notes:69]
Unearned revenue primarily represents customer billings on our maintenance service programs and leases and unearned revenues related to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one month to five years. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. In addition, we provide software maintenance and a variety of hardware maintenance services to customers under contracts with terms up to ten years. When we defer revenue related to multiple-element contracts where we still have contractual obligations, we also defer the related costs. Current deferred costs are included in prepaid expenses and other assets and totaled $2.4 million and $11.4 million as of December 31, 2018 and 2017, respectively. Non-current deferred costs are included in other assets and totaled $0.8 million and $2.8 million as of December 31, 2018 and 2017, respectively.

[0001564590-19-005179:notes:70]
Other Income (Expense), Net

[0001564590-19-005179:notes:71]
Other income (expense), net, is comprised primarily of gains and losses on foreign currency transactions, net periodic pension costs, scrap raw material sales, investment account management fees, gains and losses on foreign exchange forward contracts and miscellaneous income and expense.

[0001564590-19-005179:notes:72]
Earnings (Loss) per Share

[0001564590-19-005179:notes:73]
Earnings (loss) per common share and earnings (loss) per common share assuming dilution, are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year. See Note 16 of Notes to Consolidated Financial Statements for additional information.

[0001564590-19-005179:notes:74]
Dividends

[0001564590-19-005179:notes:75]
During 2018, 2017 and 2016, we paid shareholder dividends totaling $17.3 million, $17.4 million and $17.6 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained. The following table shows dividends paid to our shareholders in each quarter of 2018, 2017 and 2016.

[0001564590-19-005179:notes:76]
| Dividends per Common Share |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001564590-19-005179:notes:77]
On January 23, 2019, the Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on February 7, 2019. The ex-dividend date was February 6, 2019 and the payment date was February 21, 2019. The quarterly dividend payment was $4.3 million.

[0001564590-19-005179:notes:78]
Business Combinations

[0001564590-19-005179:notes:79]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying condensed consolidated statements of operations since their dates of acquisition. Costs incurred to complete the business combination, such as legal, accounting, or other professional fees, are charged to general and administrative expenses as they are incurred.

[0001564590-19-005179:notes:80]
Recently Issued Accounting Standards

[0001564590-19-005179:notes:81]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as, ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provides for an optional transition method that allows for the application of the legacy lease guidance, including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. For lessors, the new leasing standard requires leases to be classified as a sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard and related updates are effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.

[0001564590-19-005179:notes:82]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. The Company will not adjust the comparative period financial information prior to January 1, 2019 and will carry forward the legacy (ASC 840) disclosures for comparative periods. In addition, the Company elected the package of practical expedients which allows for companies to not reassess historical lease classifications and initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and non-lease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our consolidated balance sheet of less than 3% of total assets, mainly related to our operating leases for office space.  The adoption of this standard did not have a material impact on our consolidated statement of income or statement of cash flow.

[0001564590-19-005179:notes:83]
The adoption of this standard from a lessor perspective did not have a material impact on the Company’s consolidated balance sheet, consolidated statement of income or statement of cash flow. Prior to adoption, all of our leases in which we are the lessor were classified as sales-types leases and will continue after adoption of the new standard.

[0001564590-19-005179:notes:84]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather, should be accounted for in accordance with the leases standard.  ASU 2016-13 and ASU 2018-19 are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect ASU 2016-13 and ASU 2018-19 will have on our consolidated financial statements.

[0001564590-19-005179:notes:85]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material effect on our consolidated financial statements.

[0001564590-19-005179:notes:86]
In March 2017, the FASB issued ASU 2017-08, Receivables – Nonrefundable Fees and Other Costs (Subtopic 310-20): Premium Amortization on Purchased Callable Debt Securities, which shortens the amortization period for the premium on certain purchased callable debt securities to the earliest call date.  ASU 2017-08 is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2018 with early adoption permitted.  The amendments should be applied through a modified-retrospective transition approach that requires a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  The Company adopted ASU 2017-08 on January 1, 2019 and the adoption of this standard did not have a material impact on our consolidated financial statements.

[0001564590-19-005179:notes:87]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. The Company adopted ASU 2017-12 on January 1, 2019 and the adoption of this standard did not have a material impact on our consolidated financial statements as we currently do not have any hedging instruments.

[0001564590-19-005179:notes:88]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allows for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. The Company adopted ASU 2018-02 on January 1, 2019, and upon adoption elected to reclassify the stranded tax effects related to the Tax Cuts and Jobs Act of 2017 to retained earnings.

[0001564590-19-005179:notes:89]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820) Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project called, Concepts Statement No. 8 -  Conceptual Framework for Financial Reporting — Chapter 8, Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements.  ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements.  More specifically ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value.  In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows.  ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but we do not expect it will have a material effect on our financial statement disclosures.

[0001564590-19-005179:notes:90]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715.  ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (PBO) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (ABO) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but we do not expect it will have a material effect on our financial statement disclosures.

[0001564590-19-005179:notes:91]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40), Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement.  Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software.  ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted.  We are currently evaluating whether to early adopt, but we do not expect it will have a material effect on our consolidated financial statements.

[0001564590-19-005179:notes:92]
During 2018, we adopted the following accounting standards, which had no material effect on our financial position, results of operations or cash flows:

[0001564590-19-005179:notes:93]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification and/or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We adopted ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method, which was applied to all contracts on the date of initial adoption.

[0001564590-19-005179:notes:94]
These ASUs primarily affected our network implementation service revenue performance obligations and contract costs. We are using the “output method” to measure network implementation services progress, which 1) accelerates revenue recognition for certain performance obligations related to service revenue arrangements that were previously deferred until customer acceptance and 2) requires capitalization and amortization of the incremental costs of obtaining a contract as described below.

[0001564590-19-005179:notes:95]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we adopted ASC 340-40, Other Assets and Deferred Costs – Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract, including sales commissions, will be capitalized, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. The primary effect was the capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and amortization of those costs over the period that the related revenue is recognized. Those costs that will be amortized within the next 12 months are included in prepaid expenses and other current assets and those costs that will be amortized after the next 12 months are included in other assets on the consolidated balance sheets.

[0001564590-19-005179:notes:96]
The cumulative effect of the changes made to our Consolidated Balance Sheet on January 1, 2018 for the adoption of ASU 2014-09 and the related ASUs was as follows:

[0001564590-19-005179:notes:97]
| (In thousands) |  | Balance at December 31, 2017 |  |  | Adjustments due to ASU 2014-09 |  |  | Balance at January 1, 2018 |  |  |
| Other receivables |  | $ | 26,578 |  |  | $ | 374 |  |  | $ | 26,952 |  |
| Deferred tax assets, net |  | $ | 23,428 |  |  | $ | (96 | ) |  | $ | 23,332 |  |
| Retained earnings |  | $ | 922,178 |  |  | $ | 278 |  |  | $ | 922,456 |  |

[0001564590-19-005179:notes:98]
The effect of the adoption of ASU 2014-09 and the related ASUs on our financial statements was as follows:

[0001564590-19-005179:notes:99]
|  |  | As of December 31, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 458,232 |  |  | $ | 458,182 |  |  | $ | 50 |  |
| Services |  | $ | 71,045 |  |  | $ | 67,329 |  |  | $ | 3,716 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 278,929 |  |  | $ | 278,904 |  |  | $ | 25 |  |
| Services |  | $ | 46,783 |  |  | $ | 44,788 |  |  | $ | 1,995 |  |
| Loss before benefit for income taxes |  | $ | (33,371 | ) |  | $ | (35,117 | ) |  | $ | 1,746 |  |
| Benefit for income taxes |  | $ | 14,029 |  |  | $ | 14,763 |  |  | $ | (734 | ) |
| Net loss |  | $ | (19,342 | ) |  | $ | (20,354 | ) |  | $ | 1,012 |  |

[0001564590-19-005179:notes:100]
|  |  | As of December 31, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other receivables |  | $ | 36,699 |  |  | $ | 32,933 |  |  | $ | 3,766 |  |
| Prepaid expenses and other current assets |  | $ | 10,744 |  |  | $ | 12,739 |  |  | $ | (1,995 | ) |
| Inventory |  | $ | 99,848 |  |  | $ | 99,873 |  |  | $ | (25 | ) |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax payable |  | $ | 12,518 |  |  | $ | 13,252 |  |  | $ | (734 | ) |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 883,975 |  |  | $ | 882,963 |  |  | $ | 1,012 |  |

[0001564590-19-005179:notes:101]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. Subsequently, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, which issued technical corrections and improvements intended to clarify certain aspects of ASU 2016-01. ASU 2016-01 was effective beginning January 1, 2018 and we now recognize any changes in the fair value of certain equity investments in net income as prescribed by the new standard rather than in other comprehensive income. We adopted ASU 2016-01 on January 1, 2018 using the modified retrospective method, which resulted in a $3.2 million reclassification of net unrealized gains from accumulated other comprehensive income to opening retained earnings. ASU 2018-03 is effective for us with the interim period beginning after June 15, 2018. See Note 5 of Notes to Consolidated Financial Statements for additional information.

[0001564590-19-005179:notes:102]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230) – Classification of Certain Cash Receipts and Cash Payments, which clarifies how to classify cash receipts and cash payments on the statement of cash flows.  The new guidance also clarifies how the predominance principle should be applied when cash receipts and cash payments have aspects of more than one class of cash flows.  We adopted ASU 2016-15 on January 1, 2018, which has been applied retrospectively.  The adoption of this guidance did not have a material effect on our consolidated financial statements.

[0001564590-19-005179:notes:103]
In March 2017, the FASB issued ASU 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost. ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. We adopted ASU 2017-07 on January 1, 2018. We retrospectively adopted the presentation of service cost separate from other components of net periodic pension costs. As a result, $0.4 million and $0.2 million have been reclassified from cost of sales, selling, general and administrative expenses, and research and development expense to other income (expense), net for the years ended December 31, 2017 and 2016, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-005179:notes:104]
Note 2 – Business Combinations

[0001564590-19-005179:notes:105]
On November 30, 2018, we acquired SmartRG, Inc., a provider of carrier-class, open-source connected home platforms and cloud services for broadband service providers for cash consideration. Together, ADTRAN Mosaic and SmartOS provide full end-to-end management and orchestration solutions from cloud edge to subscriber edge. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. These revenues are included in the Subscriber Solutions & Experience category within the Network Solutions and Services & Support reportable segments.

[0001564590-19-005179:notes:106]
As of the acquisition date, we acquired accounts receivables with a fair value of $4.9 million all of which we estimate will be collected under the respective terms of each agreement.

[0001564590-19-005179:notes:107]
Contingent liabilities with a fair value totaling $1.2 million were recognized at the acquisition date, the payments of which are dependent upon SmartRG achieving future revenue, EBIT or customer purchase order milestones. The contingent payments are subject to arbitration and the final payouts are expected to occur during the first quarter of 2020. The minimum and maximum potential payment under the total of the contingent liabilities ranges from no payment to $1.5 million. As of December 31, 2018, the fair value of the contingent liability was re-assessed and was determined to be $1.2 million, based on the expected probable outcomes. No change in fair value was recognized.

[0001564590-19-005179:notes:108]
An escrow in the amount of $2.8 million was set up at the acquisition date, to fund post-closing working capital settlements and to indemnify the Company from any inaccuracy or breach of representations, warranties, covenants, agreements or obligations of the sellers. The escrow is subject to arbitration with final settlement expected during the fourth quarter of 2020.  The minimum and maximum potential release of funds to the seller ranges from no payment to $2.8 million.

[0001564590-19-005179:notes:109]
We have made preliminary allocations of the purchase price to the assets acquired and liabilities assumed based on estimated fair value assessments; however, we are still completing those assessments, including an analysis of the discounted cash flows. Once we finalize the fair values, we may have changes in the following areas: tangible and intangible assets, goodwill, commitments and contingencies, and deferred taxes. We recorded goodwill of $3.6 million during the year ended December 31, 2018. Goodwill represents the excess of the purchase price over the fair value of net assets acquired. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and we have concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-19-005179:notes:110]
On March 19, 2018, we acquired Sumitomo Electric Lightwave Corp.’s (SEL) North American EPON business and entered into a technology license and OEM supply agreement with Sumitomo Electric Industries, Ltd. (SEI). This acquisition establishes ADTRAN as a North American market leader for EPON solutions for the cable MSO industry and it will accelerate the MSO market’s adoption of our open, programmable and scalable architectures. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. These revenues are included in the Access & Aggregation and Subscriber Solutions & Experience categories within the Network Solutions reportable segment.

[0001564590-19-005179:notes:111]
We recorded a bargain purchase gain of $11.3 million during the first quarter of 2018, net of income taxes, which is subject to customary working capital adjustments between the parties. The bargain purchase gain of $11.3 million represents the difference between the fair-value of the net assets acquired over the cash paid. SEI, an OEM supplier based in Japan, is the global market leader in EPON. SEI’s Broadband Networks Division, through its SEL subsidiary, operated a North American EPON business that included sales, marketing, support, and region-specific engineering development. The North American EPON market is primarily driven by the Tier 1 cable MSO operators and has developed more slowly than anticipated. Through the transaction, SEI divested its North American EPON assets and established a relationship with ADTRAN. The transfer of these assets to ADTRAN, which included key customer relationships and a required assumption by ADTRAN of relatively low incremental expenses, along with the value of the technology license and OEM supply agreement, resulted in the bargain purchase gain. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and we have concluded that our valuation procedures and resulting measures were appropriate.  The gain is included in the line item “Gain on bargain purchase of a business” in the 2018 Consolidated Statements of Income.

[0001564590-19-005179:notes:112]
The preliminary allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date for SmartRG and the final allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date for Sumitomo are as follows:

[0001564590-19-005179:notes:113]
| (In Thousands) |  | Sumitomo |  |  | SmartRG |  |
| Assets |  |  |  |  |  |  |  |  |
| Tangible assets acquired |  | $ | 1,006 |  |  | $ | 8,594 |  |
| Intangible assets |  |  | 22,100 |  |  |  | 9,960 |  |
| Goodwill |  |  | — |  |  |  | 3,614 |  |
| Total assets acquired |  |  | 23,106 |  |  |  | 22,168 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Liabilities assumed |  |  | (3,978 | ) |  |  | (6,126 | ) |
| Total liabilities assumed |  |  | (3,978 | ) |  |  | (6,126 | ) |
| Total net assets |  |  | 19,128 |  |  |  | 16,042 |  |
| Gain on bargain purchase of a business, net of tax |  |  | (11,322 | ) |  |  | — |  |
| Total purchase price |  | $ | 7,806 |  |  | $ | 16,042 |  |

[0001564590-19-005179:notes:114]
Our consolidated income statements include the following revenue and net loss attributable to SmartRG and Sumitomo since the date of acquisition:

[0001564590-19-005179:notes:115]
| (In thousands) |  | March 19, 2018 to December 31, 2018 |  |
| Revenue |  | $ | 9,186 |  |
| Net loss |  | $ | (1,297 | ) |

[0001564590-19-005179:notes:116]
The details of the acquired intangible assets are as follows:

[0001564590-19-005179:notes:117]
| (In thousands) |  | Value |  |  | Life (years) |  |
| Customer relationships |  | $ | 15,190 |  |  | 3 – 12 |  |
| Developed technology |  |  | 7,400 |  |  |  | 7 |  |
| Licensed technology |  |  | 5,900 |  |  |  | 9 |  |
| Supplier relationship |  |  | 2,800 |  |  |  | 2 |  |
| Licensing agreements |  |  | 560 |  |  | 5 – 10 |  |
| Trade name |  |  | 210 |  |  |  | 3 |  |
| Total |  | $ | 32,060 |  |  |  |  |  |

[0001564590-19-005179:notes:118]
The following unaudited supplemental pro forma information presents the financial results as if the acquisition of SmartRG and Sumitomo had occurred on January 1, 2017. This unaudited supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2017, nor is it indicative of any future results. Aside from revising the 2017 net income for the effect of the bargain purchase gains, there were no material, non-recurring adjustments to this unaudited pro forma information.

[0001564590-19-005179:notes:119]
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Pro forma revenue |  | $ | 559,050 |  |  | $ | 702,573 |  |
| Pro forma net income (loss) |  | $ | (33,862 | ) |  | $ | 33,206 |  |
| Pro forma earnings (loss) per share – basic |  | $ | (0.71 | ) |  | $ | 0.69 |  |
| Pro forma earnings (loss) per share – diluted |  | $ | (0.71 | ) |  | $ | 0.68 |  |

[0001564590-19-005179:notes:120]
For the year ended December 31, 2018, we incurred acquisition and integration related expenses and amortization of acquired intangibles related to these acquisitions of $2.9 million.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-005179:notes:121]
Note 3 - Revenue

[0001564590-19-005179:notes:122]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product or service to the customer. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. The stand-alone selling prices are determined based on the prices at which we sell the separate products and services and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value-added, and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0001564590-19-005179:notes:123]
The following is a description of the principal activities from which we generate our revenue by reportable segment.

[0001564590-19-005179:notes:124]
Network Solutions Segment

[0001564590-19-005179:notes:125]
Network Solutions includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales.

[0001564590-19-005179:notes:126]
Hardware and Software Revenue

[0001564590-19-005179:notes:127]
Revenue from hardware sales is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. This segment also includes revenues from software license sales which is recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

[0001564590-19-005179:notes:128]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term. In relation to these lease agreements, during the years ended December 31, 2018, 2017 and 2016 we recognized revenue of $13.7 million, $16.5 million and $2.7 million, respectively.

[0001564590-19-005179:notes:129]
Services & Support Segment

[0001564590-19-005179:notes:130]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, and solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-19-005179:notes:131]
Maintenance Revenue

[0001564590-19-005179:notes:132]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue as our customers benefit evenly throughout the contract term and deferred revenues are recorded in current and non-current unearned revenue.

[0001564590-19-005179:notes:133]
Network Implementation Revenue

[0001564590-19-005179:notes:134]
We recognize revenue for network implementation, which primarily consists of engineering, execution, and enablement services, at a point in time when each performance obligation is complete. If we have recognized revenue, but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables in the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0001564590-19-005179:notes:135]
As of December 31, 2018, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

[0001564590-19-005179:notes:136]
The following table provides information about receivables, contract assets and unearned revenue from contracts with customers:

[0001564590-19-005179:notes:137]
| (In thousands) |  | December 31, 2018 |  |  | January 1, 2018 |  |
| Accounts receivable |  | $ | 99,385 |  |  | $ | 144,150 |  |
| Contract assets |  | $ | 3,766 |  |  | $ | 374 |  |
| Unearned revenue |  | $ | 17,940 |  |  | $ | 13,070 |  |
| Non-current unearned revenue |  | $ | 5,296 |  |  | $ | 4,556 |  |

[0001564590-19-005179:notes:138]
The decrease in accounts receivable is due to the collection of customer-specific payment terms that became due in the first quarter of 2018. The increase in the contract asset balance for the year ended December 31, 2018 is primarily attributable to revenue recognized that has not yet been billed to the customer during the period. The increase in the unearned revenue balance as of the year ended December 31, 2018 is primarily attributable to cash payments received or due in advance of satisfying our performance obligations, offset by $9.9 million of revenues recognized that were included in the unearned revenue balance as of December 31, 2017.

[0001564590-19-005179:notes:139]
The following table disaggregates our revenue by major source for the year ended December 31, 2018.

[0001564590-19-005179:notes:140]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 301,801 |  |  | $ | 57,069 |  |  | $ | 358,870 |  |
| Subscriber Solutions & Experience (1) |  |  | 129,067 |  |  |  | 5,393 |  |  |  | 134,460 |  |
| Traditional & Other Products |  |  | 27,364 |  |  |  | 8,583 |  |  |  | 35,947 |  |
| Total |  | $ | 458,232 |  |  | $ | 71,045 |  |  | $ | 529,277 |  |

[0001564590-19-005179:notes:141]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-19-005179:notes:142]
The following tables disaggregates our revenue by major source for the years ended December 31, 2018, 2017 and 2016:

[0001564590-19-005179:notes:143]
|  |  | 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 301,801 |  |  | $ | 57,069 |  |  | $ | 358,870 |  |
| Subscriber Solutions & Experience (1) |  |  | 129,067 |  |  |  | 5,393 |  |  |  | 134,460 |  |
| Traditional & Other Products |  |  | 27,364 |  |  |  | 8,583 |  |  |  | 35,947 |  |
| Total |  | $ | 458,232 |  |  | $ | 71,045 |  |  | $ | 529,277 |  |

[0001564590-19-005179:notes:144]
|  |  | 2017 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 361,955 |  |  | $ | 111,989 |  |  | $ | 473,944 |  |
| Subscriber Solutions & Experience (1) |  |  | 132,294 |  |  |  | 6,162 |  |  |  | 138,456 |  |
| Traditional & Other Products |  |  | 46,147 |  |  |  | 8,353 |  |  |  | 54,500 |  |
| Total |  | $ | 540,396 |  |  | $ | 126,504 |  |  | $ | 666,900 |  |

[0001564590-19-005179:notes:145]
|  |  | 2016 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 339,451 |  |  | $ | 96,921 |  |  | $ | 436,372 |  |
| Subscriber Solutions & Experience (1) |  |  | 130,645 |  |  |  | 6,963 |  |  |  | 137,608 |  |
| Traditional & Other Products |  |  | 55,406 |  |  |  | 7,395 |  |  |  | 62,801 |  |
| Total |  | $ | 525,502 |  |  | $ | 111,279 |  |  | $ | 636,781 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-005179:notes:146]
Note 4 – Stock-Based Compensation

[0001564590-19-005179:notes:147]
Stock Incentive Program Descriptions

[0001564590-19-005179:notes:148]
On January 23, 2006, the Board of Directors adopted the ADTRAN, Inc. 2006 Employee Stock Incentive Plan (2006 Plan), which authorized 13.0 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs, and restricted stock. The 2006 Plan was adopted by stockholder approval at our annual meeting of stockholders held on May 9, 2006. Options granted under the 2006 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date, and have a ten-year contractual term. The 2006 Plan was replaced on May 13, 2015 by the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (2015 Plan). Expiration dates of options outstanding as of December 31, 2018 under the 2006 Plan range from 2019 to 2024.

[0001564590-19-005179:notes:149]
On January 20, 2015, the Board of Directors adopted the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (2015 Plan), which authorized 7.7 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, PSUs, RSUs, and restricted stock. The 2015 Plan was adopted by stockholder approval at our annual meeting of stockholders held on May 13, 2015. PSUs, RSUs, and restricted stock granted under the 2015 Plan reduce the shares authorized for issuance under the 2015 Plan by 2.5 shares of common stock for each share underlying the award. Options granted under the 2015 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date, and have a ten-year contractual term. Expiration dates of options outstanding as of December 31, 2018 under the 2015 Plan range from 2025 to 2026.

[0001564590-19-005179:notes:150]
Our stockholders approved the 2010 Directors Stock Plan (2010 Directors Plan) on May 5, 2010, under which 0.5 million shares of common stock have been reserved. This plan replaces the 2005 Directors Stock Option Plan. Under the 2010 Directors Plan, the Company may issue stock options, restricted stock and RSUs to our non-employee directors. Stock awards issued under the 2010 Directors Plan normally become vested in full on the first anniversary of the grant date. Options issued under the 2010 Directors Plan have a ten-year contractual term. All remaining options outstanding as of December 31, 2018 under the 2010 Directors Plan will expire in 2019.

[0001564590-19-005179:notes:151]
The following table summarizes stock-based compensation expense related to stock options, PSUs, RSUs and restricted stock for the years ended December 31, 2018, 2017 and 2016, which was recognized as follows:

[0001564590-19-005179:notes:152]
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 418 |  |  | $ | 379 |  |  | $ | 389 |  |
| Selling, general and administrative expense |  |  | 3,989 |  |  |  | 4,063 |  |  |  | 3,341 |  |
| Research and development expense |  |  | 2,748 |  |  |  | 2,991 |  |  |  | 2,965 |  |
| Stock-based compensation expense included in operating expenses |  |  | 6,737 |  |  |  | 7,054 |  |  |  | 6,306 |  |
| Total stock-based compensation expense |  |  | 7,155 |  |  |  | 7,433 |  |  |  | 6,695 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (1,432 | ) |  |  | (1,699 | ) |  |  | (963 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 5,723 |  |  | $ | 5,734 |  |  | $ | 5,732 |  |

[0001564590-19-005179:notes:153]
With our adoption of ASU 2016-09 Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting in January 2017, we elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur.

[0001564590-19-005179:notes:154]
Stock Options

[0001564590-19-005179:notes:155]
The following table is a summary of our stock options outstanding as of December 31, 2017 and 2018 and the changes that occurred during 2018:

[0001564590-19-005179:notes:156]
|  |  | Number of Options (in thousands) |  |  | Weighted Average Exercise Price (per share) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Aggregate Intrinsic Value (in thousands) |  |
| Stock options outstanding, December 31, 2017 |  |  | 5,148 |  |  | $ | 22.65 |  |  |  | 4.87 |  |  | $ | 6,109 |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (96 | ) |  | $ | 15.46 |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (73 | ) |  | $ | 16.49 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (597 | ) |  | $ | 22.58 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, December 31, 2018 |  |  | 4,382 |  |  | $ | 22.91 |  |  |  | 4.10 |  |  | $ | — |  |
| Stock options exercisable, December 31, 2018 |  |  | 4,131 |  |  | $ | 23.37 |  |  |  | 3.93 |  |  | $ | — |  |

[0001564590-19-005179:notes:157]
At December 31, 2018, total unrecognized compensation expense related to non-vested stock options was approximately $0.8 million, which is expected to be recognized over an average remaining recognition period of one year.

[0001564590-19-005179:notes:158]
All of the options above were issued at exercise prices that approximated fair market value at the date of grant. At December 31, 2018, 2.5 million options were available for grant under the shareholder-approved plans.

[0001564590-19-005179:notes:159]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of 2018 and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2018. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock.

[0001564590-19-005179:notes:160]
The total pre-tax intrinsic value of options exercised during 2018, 2017 and 2016 was $0.2 million, $3.4 million and $1.1 million, respectively. The fair value of options fully vesting during 2018, 2017 and 2016 was $2.5 million, $4.3 million and $5.7 million, respectively.

[0001564590-19-005179:notes:161]
The following table further describes our stock options outstanding as of December 31, 2018:

[0001564590-19-005179:notes:162]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range of Exercise Prices |  | Options Outstanding at 12/31/18 (In thousands) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Weighted Average Exercise Price |  |  | Options Exercisable at 12/31/18 (In thousands) |  |  | Weighted Average Exercise Price |  |
| $14.88 – $18.96 |  |  | 1,257 |  |  |  | 5.93 |  |  | $ | 15.87 |  |  |  | 1,006 |  |  | $ | 15.99 |  |
| $18.97 – $23.45 |  |  | 739 |  |  |  | 5.68 |  |  | $ | 19.12 |  |  |  | 739 |  |  | $ | 19.12 |  |
| $23.46 – $30.35 |  |  | 1,223 |  |  |  | 3.18 |  |  | $ | 23.87 |  |  |  | 1,223 |  |  | $ | 23.87 |  |
| $30.36 – $41.92 |  |  | 1,163 |  |  |  | 2.29 |  |  | $ | 31.93 |  |  |  | 1,163 |  |  | $ | 31.93 |  |
|  |  |  | 4,382 |  |  |  |  |  |  |  |  |  |  |  | 4,131 |  |  |  |  |  |

[0001564590-19-005179:notes:163]
We use the Black-Scholes option pricing model (Black-Scholes Model) for the purpose of determining the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options.

[0001564590-19-005179:notes:164]
The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0001564590-19-005179:notes:165]
There were no stock options granted in 2017 or 2018. The weighted-average estimated fair value of stock options granted to employees during the year ended December 31, 2016 was $5.22 per share, with the following weighted-average assumptions:

[0001564590-19-005179:notes:166]
|  |  | 2016 |  |
| Expected volatility |  |  | 34.79 | % |
| Risk-free interest rate |  |  | 1.36 | % |
| Expected dividend yield |  |  | 1.98 | % |
| Expected life (in years) |  |  | 6.25 |  |

[0001564590-19-005179:notes:167]
We based our estimate of expected volatility for the year ended December 31, 2016 on the sequential historical daily trading data of our common stock for a period equal to the expected life of the options granted. The selection of the historical volatility method was based on available data indicating our historical volatility is as equally representative of our future stock price trends as is our implied volatility. The risk-free interest rate assumption is based upon implied yields of U.S. Treasury zero-coupon bonds on the date of grant having a remaining term equal to the expected life of the options granted. The dividend yield is based on our historical and expected dividend payouts. The expected life of our stock options is based upon historical exercise and forfeiture activity of our previous stock-based grants with a ten-year contractual term.

[0001564590-19-005179:notes:168]
PSUs, RSUs and restricted stock

[0001564590-19-005179:notes:169]
Under the 2015 Plan, awards other than stock options, including PSUs, RSUs, and restricted stock, may be granted to certain employees and officers.

[0001564590-19-005179:notes:170]
Under our market-based PSU program, the number of shares of common stock earned by a recipient pursuant to the PSUs is subject to a market condition based on ADTRAN’s relative total shareholder return against all companies in the NASDAQ Telecommunications Index at the end of a three-year performance period. Depending on the relative total shareholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the PSUs, with the shares earned distributed upon the vesting of the PSUs at the end of the three-year performance period. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted PSUs vests and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of ADTRAN, as defined by the 2015 Plan. The recipients of the PSUs receive dividend credits based on the shares of common stock underlying the PSUs. The dividend credits are vested and earned in the same manner as the PSUs and are paid in cash upon the issuance of common stock for the PSUs.

[0001564590-19-005179:notes:171]
During the first quarter of 2017, the Compensation Committee of the Board of Directors approved a one-time PSU grant of 0.5 million shares that contain performance conditions and vest at the end of a three-year period if such performance conditions are met. The fair value of these performance-based PSU awards was equal to the closing price of our stock on the date of grant.

[0001564590-19-005179:notes:172]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. RSUs and restricted stock vest ratably over four-year and one-year periods, respectively.

[0001564590-19-005179:notes:173]
We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0001564590-19-005179:notes:174]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2017 and 2018 and the changes that occurred during 2018. The unvested awards outstanding as of December 31, 2017 have been adjusted for the actual shares vested in 2018 for our market-based PSUs.

[0001564590-19-005179:notes:175]
| (In thousands, except per share amounts) |  | Number of shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2017 |  |  | 1,292 |  |  | $ | 21.33 |  |
| PSUs, RSUs and restricted stock granted |  |  | 690 |  |  | $ | 14.48 |  |
| PSUs, RSUs and restricted stock vested |  |  | (217 | ) |  | $ | 19.94 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (195 | ) |  | $ | 21.29 |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2018 |  |  | 1,570 |  |  | $ | 18.52 |  |

[0001564590-19-005179:notes:176]
At December 31, 2018, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $17.8 million, which is expected to be recognized over an average remaining recognition period of 3.0 years. In addition, there was $9.1 million of unrecognized compensation expense related to the unvested 2017 performance-based PSUs, which will be recognized over the remaining requisite service period if achievement of the performance obligation becomes probable. For the years ended December 31, 2018 and 2017, no compensation expense was recognized related to these performance-based PSUs.

[0001564590-19-005179:notes:177]
The market based PSU pricing model also requires the use of several significant assumptions that impact the fair value estimate. The estimated fair value of the PSUs granted to employees during the year ended December 31, 2018, 2017 and 2016 was $16.59 per share, $24.17 per share and $23.50 per share, respectively, with the following assumptions:

[0001564590-19-005179:notes:178]
|  |  | 2018 |  | 2017 |  |  | 2016 |  |
| Expected volatility |  | 27.98% to 31.58% |  |  | 27.03 | % |  |  | 29.79 | % |
| Risk-free interest rate |  | 2.11% to 2.99% |  |  | 1.78 | % |  |  | 1.17 | % |
| Expected dividend yield |  | 1.83% to 2.49% |  |  | 1.74 | % |  |  | 1.80 | % |


## adtn:ScheduleOfShareBasedCompensationPerformanceStockUnitsRestrictedStockUnitsAndRestrictedStockActivityTableTextBlock

[0001564590-19-005179:notes:179]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2017 and 2018 and the changes that occurred during 2018.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001564590-19-005179:notes:180]
The market based PSU pricing model also requires the use of several significant assumptions that impact the fair value estimate. The estimated fair value of the PSUs granted to employees during the year ended December 31, 2018, 2017 and 2016 was $16.59 per share, $24.17 per share and $23.50 per share, respectively, with the following assumptions


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-19-005179:notes:181]
Note 5 – Investments

[0001564590-19-005179:notes:182]
Debt securities and Other Investments

[0001564590-19-005179:notes:183]
At December 31, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-19-005179:notes:184]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 20,777 |  |  | $ | 19 |  |  | $ | (112 | ) |  | $ | 20,684 |  |
| Municipal fixed-rate bonds |  |  | 1,339 |  |  |  | — |  |  |  | (26 | ) |  |  | 1,313 |  |
| Asset-backed bonds |  |  | 5,230 |  |  |  | 5 |  |  |  | (14 | ) |  |  | 5,221 |  |
| Mortgage/Agency-backed bonds |  |  | 3,833 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 3,791 |  |
| U.S. government bonds |  |  | 9,271 |  |  |  | 1 |  |  |  | (66 | ) |  |  | 9,206 |  |
| Foreign government bonds |  |  | 592 |  |  |  | — |  |  |  | (8 | ) |  |  | 584 |  |
| Available-for-sale debt securities held at fair value |  | $ | 41,042 |  |  | $ | 27 |  |  | $ | (270 | ) |  | $ | 40,799 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 397 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 66,796 |  |

[0001564590-19-005179:notes:185]
At December 31, 2017, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-19-005179:notes:186]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 32,654 |  |  | $ | 44 |  |  | $ | (155 | ) |  | $ | 32,543 |  |
| Municipal fixed-rate bonds |  |  | 2,902 |  |  |  | 2 |  |  |  | (22 | ) |  |  | 2,882 |  |
| Asset-backed bonds |  |  | 6,545 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 6,526 |  |
| Mortgage/Agency-backed bonds |  |  | 5,554 |  |  |  | 1 |  |  |  | (46 | ) |  |  | 5,509 |  |
| U.S. government bonds |  |  | 14,477 |  |  |  | — |  |  |  | (174 | ) |  |  | 14,303 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 5 |  |  |  | — |  |  |  | 730 |  |
| Available-for-sale debt securities held at fair value |  | $ | 62,857 |  |  | $ | 53 |  |  | $ | (417 | ) |  | $ | 62,493 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 90,840 |  |

[0001564590-19-005179:notes:187]
As of December 31, 2018, our debt securities had the following contractual maturities:

[0001564590-19-005179:notes:188]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage / Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 2,127 |  |  | $ | 176 |  |  | $ | 943 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 11,557 |  |  |  | 208 |  |  |  | 401 |  |  |  | — |  |  |  | 6,714 |  |  |  | 285 |  |
| Two to three years |  |  | 6,831 |  |  |  | 929 |  |  |  | 193 |  |  |  | 425 |  |  |  | — |  |  |  | 299 |  |
| Three to five years |  |  | 169 |  |  |  | — |  |  |  | 2,433 |  |  |  | 853 |  |  |  | 2,492 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 260 |  |  |  | 6 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 991 |  |  |  | 2,507 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 20,684 |  |  | $ | 1,313 |  |  | $ | 5,221 |  |  | $ | 3,791 |  |  | $ | 9,206 |  |  | $ | 584 |  |

[0001564590-19-005179:notes:189]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-19-005179:notes:190]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities for the years ended December 31, 2018, 2017 and 2016:

[0001564590-19-005179:notes:191]
| Year Ended December 31, (In thousands) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Gross realized gains on debt securities |  | $ | 57 |  |  | $ | 169 |  |  | $ | 341 |  |
| Gross realized losses on debt securities |  |  | (592 | ) |  |  | (226 | ) |  |  | (222 | ) |
| Total gain (loss) recognized, net |  | $ | (535 | ) |  | $ | (57 | ) |  | $ | 119 |  |

[0001564590-19-005179:notes:192]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-19-005179:notes:193]
The following table presents the breakdown of debt securities and other investments with unrealized losses at December 31, 2018:

[0001564590-19-005179:notes:194]
|  |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  |  | 11,129 |  |  |  | (60 | ) |  |  | 3,608 |  |  |  | (52 | ) |  |  | 14,737 |  |  |  | (112 | ) |
| Municipal fixed-rate bonds |  |  | — |  |  |  | — |  |  |  | 1,136 |  |  |  | (26 | ) |  |  | 1,136 |  |  |  | (26 | ) |
| Asset-backed bonds |  |  | 1,874 |  |  |  | (2 | ) |  |  | 1,257 |  |  |  | (12 | ) |  |  | 3,131 |  |  |  | (14 | ) |
| Mortgage/Agency-backed bonds |  |  | 1,021 |  |  |  | (5 | ) |  |  | 1,918 |  |  |  | (39 | ) |  |  | 2,939 |  |  |  | (44 | ) |
| U.S. government bonds |  |  | 6,527 |  |  |  | (48 | ) |  |  | 537 |  |  |  | (18 | ) |  |  | 7,064 |  |  |  | (66 | ) |
| Foreign government bonds |  |  | 584 |  |  |  | (8 | ) |  |  | — |  |  |  | — |  |  |  | 584 |  |  |  | (8 | ) |
| Total |  | $ | 21,135 |  |  | $ | (123 | ) |  | $ | 8,456 |  |  | $ | (147 | ) |  | $ | 29,591 |  |  | $ | (270 | ) |

[0001564590-19-005179:notes:195]
The following table presents the breakdown of debt securities and other investments with unrealized losses at December 31, 2017:

[0001564590-19-005179:notes:196]
|  |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  |  | 16,015 |  |  |  | (58 | ) |  |  | 6,112 |  |  |  | (97 | ) |  |  | 22,127 |  |  |  | (155 | ) |
| Municipal fixed-rate bonds |  |  | 230 |  |  |  | — |  |  |  | 1,165 |  |  |  | (22 | ) |  |  | 1,395 |  |  |  | (22 | ) |
| Asset-backed bonds |  |  | 4,941 |  |  |  | (17 | ) |  |  | 179 |  |  |  | (3 | ) |  |  | 5,120 |  |  |  | (20 | ) |
| Mortgage/Agency-backed bonds |  |  | 3,062 |  |  |  | (8 | ) |  |  | 1,673 |  |  |  | (38 | ) |  |  | 4,735 |  |  |  | (46 | ) |
| U.S. government bonds |  |  | 2,754 |  |  |  | (26 | ) |  |  | 11,549 |  |  |  | (148 | ) |  |  | 14,303 |  |  |  | (174 | ) |
| Total |  | $ | 27,002 |  |  | $ | (109 | ) |  | $ | 20,678 |  |  | $ | (308 | ) |  | $ | 47,680 |  |  | $ | (417 | ) |

[0001564590-19-005179:notes:197]
The decrease in unrealized losses during 2018, as reflected in the table above, results from changes in market positions associated with our fixed income portfolio.

[0001564590-19-005179:notes:198]
Marketable Equity Securities

[0001564590-19-005179:notes:199]
Our marketable equity securities consist of publicly traded stocks or funds measured at fair value.

[0001564590-19-005179:notes:200]
Prior to January 1, 2018, our marketable equity securities were classified as available-for-sale. Realized gains and losses on marketable equity securities were included in net investment gain (loss). Unrealized gains and losses were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet.

[0001564590-19-005179:notes:201]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to opening retained earnings.

[0001564590-19-005179:notes:202]
Realized and unrealized gains and losses for our marketable equity securities for the twelve months ended December 31, 2018 were as follows:

[0001564590-19-005179:notes:203]
| (In thousands) |  | 2018 |  |
| Realized gains on equity securities sold |  | $ | 1,306 |  |
| Unrealized losses on equity securities held |  |  | (4,821 | ) |
| Total loss recognized, net |  | $ | (3,515 | ) |

[0001564590-19-005179:notes:204]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0001564590-19-005179:notes:205]
|  |  | Fair Value Measurements at December 31, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,554 |  |  | $ | 1,554 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 1,554 |  |  |  | 1,554 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,684 |  |  |  | — |  |  |  | 20,684 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,313 |  |  |  | — |  |  |  | 1,313 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,221 |  |  |  | — |  |  |  | 5,221 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 3,791 |  |  |  | — |  |  |  | 3,791 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,206 |  |  |  | 9,206 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 584 |  |  |  | — |  |  |  | 584 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Marketable equity securities – various industries |  |  | 26,763 |  |  |  | 26,763 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 253 |  |  |  | 253 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 18,256 |  |  |  | 18,256 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 86,071 |  |  |  | 54,478 |  |  |  | 31,593 |  |  |  | — |  |
| Total |  | $ | 87,625 |  |  | $ | 56,032 |  |  | $ | 31,593 |  |  | $ | — |  |

[0001564590-19-005179:notes:206]
|  |  | Fair Value Measurements at December 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,851 |  |  | $ | 5,851 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 3,999 |  |  |  | — |  |  |  | 3,999 |  |  |  | — |  |
| Cash equivalents |  |  | 9,850 |  |  |  | 5,851 |  |  |  | 3,999 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 32,543 |  |  |  | — |  |  |  | 32,543 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,882 |  |  |  | — |  |  |  | 2,882 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,526 |  |  |  | — |  |  |  | 6,526 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,509 |  |  |  | — |  |  |  | 5,509 |  |  |  | — |  |
| U.S. government bonds |  |  | 14,303 |  |  |  | 14,303 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 730 |  |  |  | — |  |  |  | 730 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,662 |  |  |  | 35,662 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 19,883 |  |  |  | 19,883 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 118,038 |  |  |  | 69,848 |  |  |  | 48,190 |  |  |  | — |  |
| Total |  | $ | 127,888 |  |  | $ | 75,699 |  |  | $ | 52,189 |  |  | $ | — |  |

[0001564590-19-005179:notes:207]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-19-005179:notes:208]
Note 6 – Derivative Instruments and Hedging Activities

[0001564590-19-005179:notes:209]
We participate in foreign exchange forward contracts in connection with the management of exposure to fluctuations in foreign exchange rates.

[0001564590-19-005179:notes:210]
Cash Flow Hedges

[0001564590-19-005179:notes:211]
Our cash flow hedging activities utilize foreign exchange forward contracts to reduce the risk that movements in exchange rates will adversely affect the net cash flows resulting from the planned purchase of products from foreign suppliers. Purchases of U.S. denominated inventory by our European subsidiary represent our primary exposure. Changes in the fair value of derivatives designated as cash flow hedges are not recognized in current operating results, but are recorded in accumulated other comprehensive income. Amounts related to cash flow hedges are reclassified from accumulated other comprehensive income when the underlying hedged item impacts earnings. This reclassification is recorded in the same line item of the consolidated statements of income as where the effects of the hedged item are recorded, which is cost of sales.

[0001564590-19-005179:notes:212]
Undesignated Hedges

[0001564590-19-005179:notes:213]
We have certain customers and suppliers who are invoiced or pay in a non-functional currency. Changes in the monetary exchange rates may adversely affect our results of operations and financial condition, as outstanding non-functional balances are revalued to the functional currency through profit and loss. When appropriate, we utilize foreign exchange forward contracts to help manage the volatility relating to these valuation exposures. All changes in the fair value of our derivative instruments that do not qualify for or are not designated for hedged accounting transactions are recognized as other income (expense), net in the Consolidated Statements of Income.

[0001564590-19-005179:notes:214]
We do not hold or issue derivative instruments for trading or other speculative purposes. Our derivative instruments are recorded in the Consolidated Balance Sheets at their fair values. Our derivative instruments are not subject to master netting arrangements and are not offset in the Consolidated Balance Sheets.

[0001564590-19-005179:notes:215]
As of December 31, 2018 and 2017, we had no foreign exchange forward contracts.

[0001564590-19-005179:notes:216]
The change in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the years ended December 31, 2018, 2017 and 2016 were as follows:

[0001564590-19-005179:notes:217]
| (In thousands) |  | Income Statement Location |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | 13 |  |  | $ | (754 | ) |  | $ | 724 |  |

[0001564590-19-005179:notes:218]
The change in our derivatives designated as hedging instruments recorded in other comprehensive income (OCI) and reclassified to income, net of tax, during the twelve months ended December 31, 2018, 2017 and 2016 were as follows:

[0001564590-19-005179:notes:219]
|  |  | Location of |  | Amount of Losses Reclassified |  |
|  |  | Losses Reclassified |  | from AOCI into Income |  |
| (In thousands) |  | from AOCI into Income |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Cost of Sales |  | $ | — |  |  | $ | (897 | ) |  | $ | — |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-19-005179:notes:220]
Note 7 – Inventory

[0001564590-19-005179:notes:221]
At December 31, 2018 and 2017, inventory was comprised of the following:

[0001564590-19-005179:notes:222]
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Raw materials |  | $ | 45,333 |  |  | $ | 44,185 |  |
| Work in process |  |  | 1,638 |  |  |  | 1,939 |  |
| Finished goods |  |  | 52,877 |  |  |  | 76,418 |  |
| Total Inventory, net |  | $ | 99,848 |  |  | $ | 122,542 |  |

[0001564590-19-005179:notes:223]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand, market conditions, and life. At December 31, 2018 and 2017, raw materials reserves totaled $17.6 million and $15.0 million, respectively, and finished goods inventory reserves totaled $12.4 million and $8.3 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-19-005179:notes:224]
Note 8 – Property, Plant and Equipment

[0001564590-19-005179:notes:225]
At December 31, 2018 and 2017, property, plant and equipment were comprised of the following:

[0001564590-19-005179:notes:226]
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 34,379 |  |  |  | 32,470 |  |
| Building |  |  | 68,183 |  |  |  | 68,301 |  |
| Furniture and fixtures |  |  | 19,831 |  |  |  | 19,489 |  |
| Computer hardware and software |  |  | 92,071 |  |  |  | 90,726 |  |
| Engineering and other equipment |  |  | 127,060 |  |  |  | 123,363 |  |
| Total Property, Plant and Equipment |  |  | 346,099 |  |  |  | 338,924 |  |
| Less accumulated depreciation |  |  | (265,464 | ) |  |  | (253,845 | ) |
| Total Property, Plant and Equipment, net |  | $ | 80,635 |  |  | $ | 85,079 |  |

[0001564590-19-005179:notes:227]
Depreciation expense was $12.7 million, $12.8 million and $12.0 million for the years ended December 31, 2018, 2017 and 2016, respectively, which is recorded in cost of sales, selling, general and administrative expense and research and development expense in the consolidated statements of income.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0001564590-19-005179:notes:228]
Note 9 – Lease Arrangements

[0001564590-19-005179:notes:229]
We are the lessor in sales-type lease arrangements for network equipment, which have terms of 18 months to five years. The net investment in sales-type leases consists of lease receivables less unearned income. Collectability of sales-type leases is evaluated periodically at an individual customer level. At December 31, 2018 and 2017, we had no allowance for credit losses for our net investment in sales-type leases. As of December 31, 2018 and 2017, the components of the net investment in sales-type leases were as follows:

[0001564590-19-005179:notes:230]
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Current minimum lease payments receivable (included in other receivables) |  | $ | 11,339 |  |  | $ | 11,325 |  |
| Non-current minimum lease payments receivable (included in other assets) |  |  | 1,670 |  |  |  | 2,913 |  |
| Total minimum lease payments receivable |  |  | 13,009 |  |  |  | 14,238 |  |
| Less: Current unearned revenue |  |  | 631 |  |  |  | 707 |  |
| Less: Non-current unearned revenue |  |  | 473 |  |  |  | 787 |  |
| Net investment in sales-type leases |  | $ | 11,905 |  |  | $ | 12,744 |  |

[0001564590-19-005179:notes:231]
Future minimum lease payments to be received from sales-type leases as of December 31, 2018 are as follows:

[0001564590-19-005179:notes:232]
| (In thousands) |  | Amount (1) |  |
| 2019 |  | $ | 11,339 |  |
| 2020 |  |  | 990 |  |
| 2021 |  |  | 431 |  |
| 2022 |  |  | 189 |  |
| 2023 |  |  | 60 |  |
| Total |  | $ | 13,009 |  |

[0001564590-19-005179:notes:233]
|  | (1) | $9.4 million of these future minimum lease payments relate to one of our customers who filed for Chapter 11 bankruptcy in February 2019. Therefore, there is a potential risk of uncollectibility related to any outstanding balance. See Note 18 of Notes to Consolidated Financial Statements for additional information. |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-19-005179:notes:234]
Note 10 – Goodwill and Intangible Assets

[0001564590-19-005179:notes:235]
Goodwill, which relates to our acquisitions of Bluesocket, Inc. and SmartRG, were $7.1 million at December 31, 2018 and $3.5 million at December 31, 2017 of which $6.7 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively, for the year ended December 31, 2018 and of which $3.1 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively, for the year ended December 31, 2017.

[0001564590-19-005179:notes:236]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test is performed. Based on the results of our qualitative assessment in 2018, we concluded that it was not necessary to perform the two-step impairment test. There were no impairment losses on goodwill recognized for the years ended December 31, 2018, 2017 and 2016.

[0001564590-19-005179:notes:237]
The following table presents our intangible assets as of December 31, 2018 and 2017:

[0001564590-19-005179:notes:238]
|  |  | 2018 |  |  | 2017 |  |
| (In thousands) |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 22,455 |  |  | $ | (5,380 | ) |  | $ | 17,075 |  |  | $ | 7,474 |  |  | $ | (4,283 | ) |  | $ | 3,191 |  |
| Developed technology |  |  | 12,801 |  |  |  | (4,867 | ) |  |  | 7,934 |  |  |  | 5,524 |  |  |  | (4,663 | ) |  |  | 861 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (520 | ) |  |  | 5,380 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Supplier relationships |  |  | 2,800 |  |  |  | (1,108 | ) |  |  | 1,692 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Patents |  |  | 500 |  |  |  | (157 | ) |  |  | 343 |  |  |  | 500 |  |  |  | (89 | ) |  |  | 411 |  |
| Licensing agreements |  |  | 560 |  |  |  | (5 | ) |  |  | 555 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Intellectual property |  |  | 930 |  |  |  | (930 | ) |  |  | — |  |  |  | 930 |  |  |  | (852 | ) |  |  | 78 |  |
| Non-compete |  |  | 200 |  |  |  | (200 | ) |  |  | — |  |  |  | 200 |  |  |  | (115 | ) |  |  | 85 |  |
| Trade names |  |  | 310 |  |  |  | (106 | ) |  |  | 204 |  |  |  | 100 |  |  |  | (65 | ) |  |  | 35 |  |
| Total |  | $ | 46,456 |  |  | $ | (13,273 | ) |  | $ | 33,183 |  |  | $ | 14,728 |  |  | $ | (10,067 | ) |  | $ | 4,661 |  |

[0001564590-19-005179:notes:239]
Amortization expense was $2.3 million, $2.9 million and $2.5 million for the years ended December 31, 2018, 2017 and 2016, respectively.

[0001564590-19-005179:notes:240]
As of December 31, 2018, the estimated future amortization expense of intangible assets is as follows:

[0001564590-19-005179:notes:241]
| (In thousands) |  | Amount |  |
| 2019 |  | $ | 5,332 |  |
| 2020 |  |  | 4,450 |  |
| 2021 |  |  | 4,101 |  |
| 2022 |  |  | 3,477 |  |
| 2023 |  |  | 3,325 |  |
| Thereafter |  |  | 12,498 |  |
| Total |  | $ | 33,183 |  |


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001564590-19-005179:notes:242]
Note 11 – Alabama State Industrial Development Authority Financing and Economic Incentives

[0001564590-19-005179:notes:243]
In conjunction with the 1995 expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the Authority). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN. The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (now Regions Bank of Alabama) (the Bank). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the Bondholder), which was acquired by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond (Amended and Restated Bond) was issued and the original financing agreement was amended. The Amended and Restated Bond bears interest, payable monthly. The interest rate is 2% per annum. The Amended and Restated Bond matures on January 1, 2020, and is currently outstanding in the aggregate principal amount of $25.6 million. The estimated fair value of the bond using a level 2 valuation technique at December 31, 2018 was approximately $25.4 million based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. We are required to make payments to the Authority in amounts necessary to pay the interest on the Amended and Restated Bond. Included in long-term investments at December 31, 2018 is $25.6 million which is invested in a restricted certificate of deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the balance of the Amended and Restated Bond with the collateral deposit in order to reduce the balance of the indebtedness.

[0001564590-19-005179:notes:244]
In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we are required to remit to the state for those employment positions that qualify under the program. We realized economic incentives related to payroll withholdings totaling $1.4 million, $1.5 million and $1.3 million for the years ended December 31, 2018, 2017 and 2016, respectively.

[0001564590-19-005179:notes:245]
We made principal payments of $1.1 million for each of the years ended December 31, 2018 and 2017, and anticipate making a principal payment in 2019. At December 31, 2018 and 2017, $1.0 million and $1.1 million, respectively of the bond debt was classified as a current liability in accounts payable in the Consolidated Balance Sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-005179:notes:246]
Note 12 – Income Taxes

[0001564590-19-005179:notes:247]
A summary of the components of the provision (benefit) for income taxes for the years ended December 31, 2018, 2017 and 2016 is as follows:

[0001564590-19-005179:notes:248]
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (8,001 | ) |  | $ | 466 |  |  | $ | 12,733 |  |
| State |  |  | (476 | ) |  |  | (150 | ) |  |  | 1,141 |  |
| International |  |  | 11,705 |  |  |  | 6,458 |  |  |  | 477 |  |
| Total Current |  |  | 3,228 |  |  |  | 6,774 |  |  |  | 14,351 |  |
| Deferred |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (14,448 | ) |  |  | 8,024 |  |  |  | 647 |  |
| State |  |  | (3,390 | ) |  |  | 1,882 |  |  |  | 73 |  |
| International |  |  | 581 |  |  |  | 4,167 |  |  |  | (3,405 | ) |
| Total Deferred |  |  | (17,257 | ) |  |  | 14,073 |  |  |  | (2,685 | ) |
| Total Provision (Benefit) for Income Taxes |  | $ | (14,029 | ) |  | $ | 20,847 |  |  | $ | 11,666 |  |

[0001564590-19-005179:notes:249]
Our effective income tax rate differs from the federal statutory rate due to the following:

[0001564590-19-005179:notes:250]
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Tax provision computed at the federal statutory rate |  |  | 21.00 | % |  |  | 35.00 | % |  |  | 35.00 | % |
| State income tax provision, net of federal benefit |  |  | 14.53 |  |  |  | 2.17 |  |  |  | 3.93 |  |
| Federal research credits |  |  | 14.23 |  |  |  | (11.88 | ) |  |  | (8.15 | ) |
| Foreign taxes |  |  | (11.45 | ) |  |  | (2.27 | ) |  |  | (0.34 | ) |
| Tax-exempt income |  |  | 0.45 |  |  |  | (0.75 | ) |  |  | (0.53 | ) |
| State tax incentives |  |  | 3.15 |  |  |  | (2.71 | ) |  |  | (2.77 | ) |
| Stock-based compensation |  |  | (2.87 | ) |  |  | 1.43 |  |  |  | 2.53 |  |
| Domestic production activity deduction |  |  | — |  |  |  | (1.13 | ) |  |  | (2.23 | ) |
| Bargain purchase |  |  | 8.82 |  |  |  | — |  |  |  | (2.64 | ) |
| Impact of U.S. tax reform |  |  | 12.00 |  |  |  | 26.70 |  |  |  | — |  |
| Global intangible low-taxed income (GILTI) |  |  | (17.48 | ) |  |  | — |  |  |  | — |  |
| Other, net |  |  | (0.34 | ) |  |  | 0.09 |  |  |  | 0.08 |  |
| Effective Tax Rate |  |  | 42.04 | % |  |  | 46.65 | % |  |  | 24.88 | % |

[0001564590-19-005179:notes:251]
Income (loss) before provision for income taxes for the years ended December 31, 2018, 2017 and 2016 is as follows:

[0001564590-19-005179:notes:252]
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| U.S. entities |  | $ | (74,131 | ) |  | $ | 26,552 |  |  | $ | 54,077 |  |
| International entities |  |  | 40,760 |  |  |  | 18,135 |  |  |  | (7,182 | ) |
| Total |  | $ | (33,371 | ) |  | $ | 44,687 |  |  | $ | 46,895 |  |

[0001564590-19-005179:notes:253]
Income (loss) before provision (benefit) for income taxes for international entities reflects income (loss) based on statutory transfer pricing agreements. This amount does not correlate to consolidated international revenues, many of which occur from our U.S. entity.

[0001564590-19-005179:notes:254]
Deferred income taxes on the balance sheet result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The principal components of our current and non-current deferred taxes are as follows:

[0001564590-19-005179:notes:255]
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Deferred tax assets |  |  |  |  |  |  |  |  |
| Inventory |  | $ | 6,609 |  |  | $ | 7,545 |  |
| Accrued expenses |  |  | 2,850 |  |  |  | 3,103 |  |
| Investments |  |  | 1,122 |  |  |  | — |  |
| Deferred compensation |  |  | 4,779 |  |  |  | 5,204 |  |
| Stock-based compensation |  |  | 3,069 |  |  |  | 2,988 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 326 |  |  |  | 370 |  |
| Pensions |  |  | 5,538 |  |  |  | 4,727 |  |
| Foreign losses |  |  | 3,097 |  |  |  | 3,091 |  |
| State losses and credit carry-forwards |  |  | 8,164 |  |  |  | 3,854 |  |
| Federal loss and research carry-forwards |  |  | 17,495 |  |  |  | 3,058 |  |
| Valuation allowance |  |  | (5,816 | ) |  |  | (6,006 | ) |
| Total Deferred Tax Assets |  |  | 47,233 |  |  |  | 27,934 |  |
| Deferred tax liabilities |  |  |  |  |  |  |  |  |
| Property, plant and equipment |  |  | (3,515 | ) |  |  | (3,553 | ) |
| Intellectual property |  |  | (6,531 | ) |  |  | (663 | ) |
| Investments |  |  | — |  |  |  | (290 | ) |
| Total Deferred Tax Liabilities |  |  | (10,046 | ) |  |  | (4,506 | ) |
| Net Deferred Tax Assets |  | $ | 37,187 |  |  | $ | 23,428 |  |

[0001564590-19-005179:notes:256]
At December 31, 2018 and 2017, non-current deferred taxes related to our investments and our defined benefit pension plan reflect deferred taxes on the net unrealized gains and losses on available-for-sale investments and deferred taxes on unrealized losses in our pension plan. The net change in non-current deferred taxes associated with these items, a deferred tax benefit of $2.8 million and $1.7 million in 2018 and 2017, respectively, is recorded as an adjustment to other comprehensive income, presented in the Consolidated Statements of Comprehensive Income.

[0001564590-19-005179:notes:257]
The Company continually reviews the adequacy of the valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes (ASC 740). As of December 31, 2018, we had foreign losses of $3.1 million. A valuation allowance of $2.4 million has been established against the loss carryforwards.  The foreign loss carryforwards primarily resulted from an acquisition in 2009.  As of December 31, 2018, we had $8.2 million of state loss and tax credit carryforwards. We believe it is more likely than not we will not realize the full benefit of the deferred tax asset arising from these losses and credit carryforwards. Therefore, a valuation allowance of $3.4 million has been established against these carryforwards. The valuation allowance relates to a particular state where we no longer generate sufficient state income.  As of December 31, 2018, we had $17.5 million of federal loss and research carryforwards. These carryforwards are the result of acquisitions in 2011 and 2018 as well as domestic operating losses in 2018. Management will continue to assess the realization of our deferred tax assets and related valuation allowance. As such, we may release a portion of the valuation allowance or establish a new valuation allowance based on operations in the jurisdictions in which these assets arose. Management continues to evaluate all evidence including historical operating results, the existence of losses in the most recent year, forecasted earnings, future taxable income, and tax planning strategies. Should management determine a valuation allowance is needed in the future due to not being able to absorb loss carryforwards, it would have a material impact on our consolidated financial statements.

[0001564590-19-005179:notes:258]
The deferred tax assets for foreign and domestic carry-forwards, research and development tax credits, unamortized research and development costs, and state credit carry-forwards are $28.8 million. Some of these deferred tax assets will expire between 2019 and 2030 and others carryforward indefinitely. We will continue to assess the realization of our deferred tax assets and related valuation allowances. The net change in our valuation allowance from December 31, 2017 to December 31, 2018 was $(0.2) million.

[0001564590-19-005179:notes:259]
As of December 31, 2018 and 2017, respectively, our cash and cash equivalents were $105.5 million and $86.4 million and short-term investments were $3.2 million and $16.1 million, which provided available short-term liquidity of $108.7 million and $102.6 million. Of these amounts, our foreign subsidiaries held cash of $87.1 million and $56.8 million, respectively, representing approximately 80.1% and 55.4% of available short-term liquidity, which is used to fund on-going liquidity needs of these subsidiaries. We intend to permanently reinvest these funds outside the U.S., except to the extent any of these funds can be repatriated without withholding tax, and our current business plans do not indicate a need to repatriate to fund domestic operations. However, if all these funds were repatriated to the U.S. or used for U.S. operations, certain amounts could be subject to tax. Due to the timing and circumstances of repatriation of such earnings, if any, it is not practical to determine the amount of funds subject to unrecognized deferred tax liability.

[0001564590-19-005179:notes:260]
During 2018, 2017 and 2016, we recorded no income tax benefit or expense for stock options exercised as an adjustment to equity.  This is calculated on the difference between the exercise price of stock option exercises and the market price of the underlying common stock upon exercise.

[0001564590-19-005179:notes:261]
The change in the unrecognized income tax benefits for the years ended December 31, 2018, 2017 and 2016 is reconciled below:

[0001564590-19-005179:notes:262]
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 2,366 |  |  | $ | 2,226 |  |  | $ | 2,537 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | 3 |  |  |  | 465 |  |  |  | 95 |  |
| Current year |  |  | 254 |  |  |  | 285 |  |  |  | 428 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | (14 | ) |  |  | — |  |
| Settlements with taxing authorities |  |  | — |  |  |  | — |  |  |  | — |  |
| Expiration of applicable statute of limitations |  |  | (755 | ) |  |  | (596 | ) |  |  | (834 | ) |
| Balance at end of period |  | $ | 1,868 |  |  | $ | 2,366 |  |  | $ | 2,226 |  |

[0001564590-19-005179:notes:263]
As of December 31, 2018, 2017 and 2016, our total liability for unrecognized tax benefits was $1.9 million, $2.4 million and $2.2 million, respectively, of which $1.7 million, $2.2 million and $1.7 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of December 31, 2018, 2017 and 2016, the balances of accrued interest and penalties were $0.7 million, $0.8 million and $0.8 million, respectively.

[0001564590-19-005179:notes:264]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date. We file income tax returns in the U.S. federal and various state jurisdictions and several foreign jurisdictions. We are not currently under audit by the Internal Revenue Service. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2015.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-19-005179:notes:265]
Note 13 – Employee Benefit Plans

[0001564590-19-005179:notes:266]
Pension Benefit Plan

[0001564590-19-005179:notes:267]
We maintain a defined benefit pension plan covering employees in certain foreign countries.

[0001564590-19-005179:notes:268]
The pension benefit plan obligations and funded status at December 31, 2018 and 2017, are as follows:

[0001564590-19-005179:notes:269]
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 34,893 |  |  | $ | 30,011 |  |
| Service cost |  |  | 1,193 |  |  |  | 1,260 |  |
| Interest cost |  |  | 727 |  |  |  | 607 |  |
| Actuarial loss - experience |  |  | 38 |  |  |  | 47 |  |
| Actuarial (gain) loss - assumptions |  |  | 2,139 |  |  |  | (1,294 | ) |
| Benefit payments |  |  | (138 | ) |  |  | (80 | ) |
| Effects of foreign currency exchange rate changes |  |  | (1,615 | ) |  |  | 4,342 |  |
| Projected benefit obligation at end of period |  |  | 37,237 |  |  |  | 34,893 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  |  | 26,624 |  |  |  | 20,045 |  |
| Actual return (loss) on plan assets |  |  | (2,024 | ) |  |  | 709 |  |
| Contributions |  |  | 688 |  |  |  | 3,001 |  |
| Effects of foreign currency exchange rate changes |  |  | (1,129 | ) |  |  | 2,869 |  |
| Fair value of plan assets at end of period |  |  | 24,159 |  |  |  | 26,624 |  |
| Unfunded status at end of period |  | $ | (13,078 | ) |  | $ | (8,269 | ) |

[0001564590-19-005179:notes:270]
The accumulated benefit obligation was $37.2 million and $32.9 million at December 31, 2018 and 2017, respectively. The increase in the accumulated benefit obligation and the actuarial loss is primarily attributable to a decrease in the discount rate during 2018.

[0001564590-19-005179:notes:271]
The net amounts recognized in the balance sheet for the unfunded pension liability as of December 31, 2018 and 2017 are as follows:

[0001564590-19-005179:notes:272]
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Current liability |  | $ | — |  |  | $ | — |  |
| Non-current liability |  |  | 13,078 |  |  |  | 8,269 |  |
| Total |  | $ | 13,078 |  |  | $ | 8,269 |  |

[0001564590-19-005179:notes:273]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the consolidated statements of income (loss). The components of net periodic pension cost and amounts recognized in other comprehensive income (loss) for the years ended December 31, 2018, 2017 and 2016 are as follows:

[0001564590-19-005179:notes:274]
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,193 |  |  | $ | 1,260 |  |  | $ | 1,211 |  |
| Interest cost |  |  | 727 |  |  |  | 607 |  |  |  | 720 |  |
| Expected return on plan assets |  |  | (1,548 | ) |  |  | (1,267 | ) |  |  | (1,057 | ) |
| Amortization of actuarial losses |  |  | 247 |  |  |  | 309 |  |  |  | 175 |  |
| Net periodic benefit cost |  |  | 619 |  |  |  | 909 |  |  |  | 1,049 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | 5,638 |  |  |  | (654 | ) |  |  | 1,782 |  |
| Amortization of actuarial losses |  |  | (196 | ) |  |  | (406 | ) |  |  | (156 | ) |
| Amount recognized in other comprehensive income (loss) |  |  | 5,442 |  |  |  | (1,060 | ) |  |  | 1,626 |  |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) |  | $ | 6,061 |  |  | $ | (151 | ) |  | $ | 2,675 |  |

[0001564590-19-005179:notes:275]
The amounts recognized in accumulated other comprehensive income as of December 31, 2018 and 2017 are as follows:

[0001564590-19-005179:notes:276]
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Net actuarial loss |  | $ | (11,256 | ) |  | $ | (5,812 | ) |

[0001564590-19-005179:notes:277]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the selection of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations, and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return.

[0001564590-19-005179:notes:278]
Another key assumption in determining net pension expense is the assumed discount rate to be used to discount plan obligations. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations.

[0001564590-19-005179:notes:279]
The weighted-average assumptions that were used to determine the net periodic benefit cost for the years ended December 31, 2018, 2017 and 2016 are as follows:

[0001564590-19-005179:notes:280]
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Discount rates |  |  | 2.13 | % |  |  | 1.90 | % |  |  | 2.64 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.00 | % |  |  | 2.00 | % |
| Expected long-term rates of return |  |  | 5.90 | % |  |  | 5.90 | % |  |  | 5.40 | % |

[0001564590-19-005179:notes:281]
The weighted-average assumptions that were used to determine the benefit obligation at December 31, 2018 and 2017:

[0001564590-19-005179:notes:282]
|  |  | 2018 |  |  | 2017 |  |
| Discount rates |  |  | 1.75 | % |  |  | 2.13 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.00 | % |

[0001564590-19-005179:notes:283]
Actuarial gains and losses are recorded in accumulated other comprehensive income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants. We estimate that $0.7 million will be amortized from accumulated other comprehensive income into net periodic pension cost in 2019 for the net actuarial loss.

[0001564590-19-005179:notes:284]
We anticipate making a contribution to the pension plan in 2019 of approximately $1.1 million which reflects the net amount of service costs less expected benefit payments. The following pension benefit payments, which reflect expected future service, as appropriate, are expected to be paid to participants:

[0001564590-19-005179:notes:285]
| (In thousands) |  |  |  |  |
| 2019 |  | $ | 400 |  |
| 2020 |  |  | 555 |  |
| 2021 |  |  | 646 |  |
| 2022 |  |  | 704 |  |
| 2023 |  |  | 808 |  |
| 2024 – 2028 |  |  | 5,430 |  |
| Total |  | $ | 8,543 |  |

[0001564590-19-005179:notes:286]
We have categorized our cash equivalents and our investments held at fair value that are included in the pension plan into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 - values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-19-005179:notes:287]
|  |  | Fair Value Measurements at December 31, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash and cash equivalents |  | $ | 1,010 |  |  | $ | 1,010 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Government bonds |  |  | 6,268 |  |  |  | 6,268 |  |  |  | — |  |  |  | — |  |
| Corporate bonds |  |  | 4,840 |  |  |  | 4,840 |  |  |  | — |  |  |  | — |  |
| Emerging markets bonds |  |  | 443 |  |  |  | 443 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global equity |  |  | 7,743 |  |  |  | 7,743 |  |  |  | — |  |  |  | — |  |
| Emerging markets |  |  | 1,188 |  |  |  | 1,188 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 815 |  |  |  | 815 |  |  |  | — |  |  |  | — |  |
| Large-cap value |  |  | 262 |  |  |  | 262 |  |  |  | — |  |  |  | — |  |
| Global real estate fund |  |  | 926 |  |  |  | 926 |  |  |  | — |  |  |  | — |  |
| Managed futures fund |  |  | 664 |  |  |  | 664 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 23,149 |  |  |  | 23,149 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 24,159 |  |  | $ | 24,159 |  |  | $ | — |  |  | $ | — |  |

[0001564590-19-005179:notes:288]
|  |  | Fair Value Measurements at December 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash and cash equivalents |  | $ | 3,005 |  |  | $ | 3,005 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 14,349 |  |  |  | 14,349 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 2,305 |  |  |  | 2,305 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large-cap blend |  |  | 5,758 |  |  |  | 5,758 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 898 |  |  |  | 898 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 309 |  |  |  | 309 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 23,619 |  |  |  | 23,619 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 26,624 |  |  | $ | 26,624 |  |  | $ | — |  |  | $ | — |  |

[0001564590-19-005179:notes:289]
Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants, and consider a broad range of economic conditions. Central to the policy are target allocation ranges by asset class, which is currently 50% for bond funds, 40% for equity funds and 10% cash, real estate and managed futures.

[0001564590-19-005179:notes:290]
The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions, and achieve asset returns that are competitive with like institutions employing similar investment strategies.

[0001564590-19-005179:notes:291]
The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations.

[0001564590-19-005179:notes:292]
401(k) Savings Plan

[0001564590-19-005179:notes:293]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (Savings Plan) for the benefit of our eligible employees. The Savings Plan is intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (Code), and is intended to be a “safe harbor” 401(k) plan under Code Section 401(k)(12). The Savings Plan allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plan also requires us to contribute a “safe harbor” amount each year. We match up to 4% of employee contributions (100% of an employee’s first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s one-year anniversary date. In calculating our matching contribution, we only use compensation up to the statutory maximum under the Code ($275,000 for 2018). All contributions under the Savings Plan are 100% vested. Expenses recorded for employer contributions and plan administration costs for the Savings Plan amounted to approximately $4.4 million, $4.6 million and $4.1 million in 2018, 2017 and 2016, respectively.

[0001564590-19-005179:notes:294]
Deferred Compensation Plans

[0001564590-19-005179:notes:295]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors.

[0001564590-19-005179:notes:296]
For our executive management employees, the ADTRAN, Inc. Deferred Compensation Program for Employees is offered as a supplement to our tax-qualified 401(k) plan and is available to certain executive management employees who have been designated by our Board of Directors. This deferred compensation plan allows participants to defer all or a portion of certain specified bonuses and up to 25% of remaining cash compensation, and permits us to make matching contributions on a discretionary basis, without the limitations that apply to the 401(k) plan. To date, we have not made any matching contributions under this plan. We also maintain the ADTRAN, Inc. Equity Deferral Program for Employees. Under this plan, participants may elect to defer all or a portion of their vested PSU’s and RSU’s to the Plan. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the Participant.

[0001564590-19-005179:notes:297]
For our Board of Directors, we maintain the ADTRAN, Inc. Deferred Compensation Program for Directors. This program allows our Board of Directors to defer all or a portion of monetary remuneration paid to the Director, including, but not limited to, meeting fees and annual retainers. We also maintain the ADTRAN, Inc. Equity Deferral Program for Directors. Under this plan, participants may elect to defer all or a portion of their vested restricted stock awards. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the Director.

[0001564590-19-005179:notes:298]
We have set aside the plan assets for all plans in a rabbi trust (the Trust) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant, and the participant’s bookkeeping account is credited with the earnings and losses attributable to those investments. Benefits are scheduled to be distributed six months after termination of employment in a single lump sum payment or annual installments paid over a three or ten-year term based on the participant’s election. Distributions will be made on a pro-rata basis from each of the hypothetical investments of the Participant’s account in cash. Any whole shares of ADTRAN, Inc. common stock that are distributed will be distributed in-kind.

[0001564590-19-005179:notes:299]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging from equities to money market instruments. These mutual funds are publicly quoted and reported at fair value. The fair value of the assets held by the Trust and the amounts payable to the plan participants at December 31, 2018 and 2017 are as follows:

[0001564590-19-005179:notes:300]
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |  |  |
| Long-term investments |  | $ | 18,256 |  |  | $ | 19,883 |  |
| Total Fair Value of Plan Assets |  | $ | 18,256 |  |  | $ | 19,883 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |  |  |
| Non-current liabilities |  | $ | 18,256 |  |  | $ | 19,883 |  |
| Total Amounts Payable to Plan Participants |  | $ | 18,256 |  |  | $ | 19,883 |  |

[0001564590-19-005179:notes:301]
Interest and dividend income of the Trust have been included in interest and dividend income in the accompanying 2018, 2017 and 2016 Consolidated Statements of Income (Loss). Changes in the fair value of the plan assets held by the Trust have been included in other income (expense) in the accompanying 2018, 2017 and 2016 Consolidated Statements of Income (Loss). Changes in the fair value of the deferred compensation liability are included as selling, general, and administrative expense in the accompanying 2018, 2017 and 2016 Consolidated Statements of Income (Loss). Based on the changes in the total fair value of the Trust’s assets, we recorded deferred compensation income (expense) in 2018, 2017 and 2016 of $2.1 million, $(2.6) million and $(1.3) million, respectively.

[0001564590-19-005179:notes:302]
Retiree Medical Coverage

[0001564590-19-005179:notes:303]
We provided medical, dental and prescription drug coverage to one retired former officer and his spouse, for his life, on the same terms as provided to our active officers, and to the spouse of a former deceased officer for up to 30 years. At December 31, 2018 and 2017, this liability totaled $0.1 million.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-005179:notes:304]
Note 14 – Segment Information and Major Customers

[0001564590-19-005179:notes:305]
Our chief operating decision maker regularly reviews our financial performance based on two reportable segments – Network Solutions and Services & Support. Network Solutions includes software and hardware products and next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes our suite of ProCloud managed services, network installation, engineering and maintenance services, and fee-based technical support and equipment repair/replacement plans.

[0001564590-19-005179:notes:306]
We evaluate the performance of our segments based on gross profit. Selling, general, and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense) and provision (benefit) for taxes are reported on a company-wide, functional basis only. There are no inter-segment revenues.

[0001564590-19-005179:notes:307]
The following table presents information about the reported sales and gross profit of our reportable segments for each of the years ended December 31, 2018, 2017 and 2016. Asset information by reportable segment is not reported, since we do not produce such information internally.

[0001564590-19-005179:notes:308]
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 458,232 |  |  | $ | 179,303 |  |  | $ | 540,396 |  |  | $ | 260,833 |  |  | $ | 525,502 |  |  | $ | 254,797 |  |
| Services & Support |  |  | 71,045 |  |  |  | 24,262 |  |  |  | 126,504 |  |  |  | 42,802 |  |  |  | 111,279 |  |  |  | 36,533 |  |
| Total |  | $ | 529,277 |  |  | $ | 203,565 |  |  | $ | 666,900 |  |  | $ | 303,635 |  |  | $ | 636,781 |  |  | $ | 291,330 |  |

[0001564590-19-005179:notes:309]
Sales by Category

[0001564590-19-005179:notes:310]
In addition to the above reporting segments, we also report revenue for the following three categories – Access & Aggregation, Subscriber Solutions & Experience, and Traditional & Other Products.

[0001564590-19-005179:notes:311]
The following table presents sales information by geographic area for the years ended December 31, 2018, 2017 and 2016:

[0001564590-19-005179:notes:312]
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| United States |  | $ | 288,843 |  |  | $ | 508,178 |  |  | $ | 501,337 |  |
| Germany |  |  | 167,251 |  |  |  | 119,502 |  |  |  | 85,780 |  |
| Other international |  |  | 73,183 |  |  |  | 39,220 |  |  |  | 49,664 |  |
| Total |  | $ | 529,277 |  |  | $ | 666,900 |  |  | $ | 636,781 |  |

[0001564590-19-005179:notes:313]
Customers comprising more than 10% of revenue can change from year to year. Single customers comprising more than 10% of our revenue in 2018 included two customers at 27% and 17%. Single customers comprising more than 10% of our revenue in 2017 included two customers at 40% and 16%. Single customers comprising more than 10% of our revenue in 2016 included three customers at 24%, 19% and 12%. Other than those with more than 10 percent of revenues disclosed above, and excluding distributors, our next five largest customers can change from year-to-year. These customers represented 18%, 15% and 13% of total revenue in 2018, 2017 and 2016, respectively.

[0001564590-19-005179:notes:314]
Additional Segment Information

[0001564590-19-005179:notes:315]
As of December 31, 2018, long-lived assets, net totaled $80.6 million, which includes $77.3 million held in the U.S. and $3.3 million held outside the U.S. As of December 31, 2017, long-lived assets, net totaled $85.1 million, which includes $80.6 million held in the U.S. and $4.5 million held outside the U.S.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-005179:notes:316]
Note 15 – Commitments and Contingencies

[0001564590-19-005179:notes:317]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition, or cash flows.

[0001564590-19-005179:notes:318]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of December 31, 2018, of which $7.7 million has been applied to these commitments.

[0001564590-19-005179:notes:319]
We lease office space and equipment under operating leases which expire at various dates through 2025. As of December 31, 2018, future minimum rental payments under non-cancelable operating leases, including renewals determined to be reasonably assured, with original maturities of greater than 12 months are as follows:

[0001564590-19-005179:notes:320]
| (In thousands) |  |  |  |  |
| 2019 |  | $ | 3,873 |  |
| 2020 |  |  | 3,580 |  |
| 2021 |  |  | 2,771 |  |
| 2022 |  |  | 2,053 |  |
| 2023 |  |  | 1,317 |  |
| Thereafter |  |  | 762 |  |
| Total |  | $ | 14,356 |  |

[0001564590-19-005179:notes:321]
Rental expense was $4.6 million, $4.7 million and $4.5 million for the years ended December 31, 2018, 2017 and 2016, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-005179:notes:322]
Note 16 – Earnings (Loss) per Share

[0001564590-19-005179:notes:323]
A summary of the calculation of basic and diluted earnings (loss) per share for the years ended December 31, 2018, 2017 and 2016 is as follows:

[0001564590-19-005179:notes:324]
| (In thousands, except for per share amounts) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income (Loss) |  | $ | (19,342 | ) |  | $ | 23,840 |  |  | $ | 35,229 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,880 |  |  |  | 48,153 |  |  |  | 48,724 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | 406 |  |  |  | 170 |  |
| Restricted stock and restricted stock units |  |  | — |  |  |  | 140 |  |  |  | 55 |  |
| Weighted average number of shares – diluted |  | $ | 47,880 |  |  | $ | 48,699 |  |  | $ | 48,949 |  |
| Earnings (loss) per share – basic |  | $ | (0.40 | ) |  | $ | 0.50 |  |  | $ | 0.72 |  |
| Earnings (loss) per share – diluted |  | $ | (0.40 | ) |  | $ | 0.49 |  |  | $ | 0.72 |  |

[0001564590-19-005179:notes:325]
For each of the years ended December 31, 2018, 2017 and 2016, 2.5 million, 3.2 million and 4.6 million stock options were outstanding but were not included in the computation of diluted earnings (loss) per share because the options’ exercise prices were greater than the average market price of the common shares, therefore making them anti-dilutive under the treasury stock method.  As a result of the net loss for the year ended December 31, 2018, we excluded 0.1 million of unvested stock options, PSU’s, RSU’s and restricted stock from the calculation of diluted EPS due to their anti-dilutive effect.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001564590-19-005179:notes:326]
Note 17 – Summarized Quarterly Financial Data (Unaudited)

[0001564590-19-005179:notes:327]
The following table presents unaudited quarterly operating results for each of our last eight fiscal quarters. This information has been prepared on a basis consistent with our audited financial statements and includes all adjustments, consisting only of normal recurring adjustments, considered necessary for a fair presentation of the data.

[0001564590-19-005179:notes:328]
Unaudited Quarterly Operating Results

[0001564590-19-005179:notes:329]
(In thousands, except for per share amounts)

[0001564590-19-005179:notes:330]
| Three Months Ended |  | March 31, 2018 |  |  | June 30, 2018 |  |  | September 30, 2018 |  |  | December 31, 2018 |  |
| Net sales |  | $ | 120,806 |  |  | $ | 128,048 |  |  | $ | 140,335 |  |  | $ | 140,088 |  |
| Gross profit |  | $ | 39,733 |  |  | $ | 49,996 |  |  | $ | 58,448 |  |  | $ | 55,388 |  |
| Operating income (loss) |  | $ | (26,647 | ) |  | $ | (12,813 | ) |  | $ | (2,179 | ) |  | $ | (3,783 | ) |
| Net income (loss) |  | $ | (10,814 | ) |  | $ | (7,670 | ) |  | $ | 7,589 |  |  | $ | (8,447 | ) |
| Earnings (loss) per common share - basic |  | $ | (0.22 | ) |  | $ | (0.16 | ) |  | $ | 0.16 |  |  | $ | (0.18 | ) |
| Earnings (loss) per common share – diluted (1) |  | $ | (0.22 | ) |  | $ | (0.16 | ) |  | $ | 0.16 |  |  | $ | (0.18 | ) |

[0001564590-19-005179:notes:331]
| Three Months Ended |  | March 31, 2017 |  |  | June 30, 2017 |  |  | September 30, 2017 |  |  | December 31, 2017 |  |
| Net sales |  | $ | 170,279 |  |  | $ | 184,673 |  |  | $ | 185,112 |  |  | $ | 126,836 |  |
| Gross profit |  | $ | 73,709 |  |  | $ | 84,626 |  |  | $ | 86,491 |  |  | $ | 58,809 |  |
| Operating income (loss) |  | $ | 6,949 |  |  | $ | 16,363 |  |  | $ | 18,227 |  |  | $ | (4,153 | ) |
| Net income (loss) |  | $ | 6,651 |  |  | $ | 12,401 |  |  | $ | 15,898 |  |  | $ | (11,110 | ) |
| Earnings (loss) per common share - basic |  | $ | 0.14 |  |  | $ | 0.26 |  |  | $ | 0.33 |  |  | $ | (0.23 | ) |
| Earnings (loss) per common share – diluted (1) |  | $ | 0.14 |  |  | $ | 0.26 |  |  | $ | 0.33 |  |  | $ | (0.23 | ) |

[0001564590-19-005179:notes:332]
|  | (1) | Assumes exercise of dilutive securities calculated under the treasury stock method. |


## us-gaap:SubsequentEventsTextBlock

[0001564590-19-005179:notes:333]
Note 18 – Subsequent Events

[0001564590-19-005179:notes:334]
On January 23, 2019, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on February 7, 2019. The quarterly dividend payment was $4.3 million and was paid on February 21, 2019. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-19-005179:notes:335]
During the first quarter and as of February 26, 2019, we have repurchased 13,000 shares of our common stock through open market purchases at an average cost of $14.06 per share. We currently have the authority to purchase an additional 2.5 million shares of our common stock under the current plan approved by the Board of Directors.

[0001564590-19-005179:notes:336]
In February 2019, $1.0 million of an outstanding investment loan due to ADTRAN was replaced with a secured loan in that amount. The remaining balance of this investment loan was converted to participating preferred shares of the respective company.

[0001564590-19-005179:notes:337]
In February 2019, we announced the restructuring of our workforce in Germany, which includes the closure of the office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees and a voluntary early retirement offering to certain other employees. The restructuring is expected to be completed in the fourth quarter of 2019. ADTRAN does not have sufficient information currently on which to estimate the liability associated with this restructuring, including costs associated with employee severance and relocation.

[0001564590-19-005179:notes:338]
On February 25, 2019, one the Company’s customers filed for voluntary Chapter 11 bankruptcy as a result of a court ruling resulting in a substantial legal judgment against the customer. In 2018, this customer accounted for less than 5% of the Company’s revenue. As of December 31, 2018, the Company had $2.6 million related to product and services revenue and $0.3 million related to a leased equipment arrangement included in accounts receivable on the Consolidated Balance Sheet that was due from this customer. As of December 31, 2018, the Company had $9.4 million included in other receivables related to a leased equipment arrangement on its Consolidated Balance Sheet that was due from this customer. Since December 31, 2018, and through the date of this filing, all $2.6 million of the outstanding products and services accounts receivable and $0.1 million of the outstanding accounts receivable related to leased equipment have been collected. Additionally, $1.7 million of the outstanding other receivables related to leased equipment have been collected. Therefore, there is potential risk of uncollectibility up to $7.8 million on the remaining outstanding receivable balances as of December 31 2018. The Company has evaluated the collectibility of the remaining receivable balances with the best available and applicable information as of the date of this filing and the impact was not material to the consolidated financial statements as of December 31, 2018. The Company will continue to evaluate the collectibility of the remaining accounts receivable balances in subsequent reporting periods. Additionally, it is uncertain at this time the impact this voluntary bankruptcy filing might have on the Company’s operating income prospectively; however, the Company believes it will not have a significant impact on the Company’s liquidity and capital resources.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001564590-19-005179:notes:339]
SCHEDULE II

[0001564590-19-005179:notes:340]
VALUATION AND QUALIFYING ACCOUNTS

[0001564590-19-005179:notes:341]
| (In thousands) |  | Balance at Beginning of Period |  |  | Charged to Costs & Expenses |  |  | Deductions |  |  | Balance at End of Period |  |
| Year ended December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | — |  |  |  | 128 |  |  |  | — |  |  | $ | 128 |  |
| Inventory Reserve |  | $ | 23,355 |  |  |  | 7,006 |  |  |  | 352 |  |  | $ | 30,009 |  |
| Warranty Liability |  | $ | 9,724 |  |  |  | 7,392 |  |  |  | 8,493 |  |  | $ | 8,623 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 6,006 |  |  |  | — |  |  |  | 190 |  |  | $ | 5,816 |  |
| Year ended December 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | — |  |  |  | — |  |  |  | — |  |  | $ | — |  |
| Inventory Reserve |  | $ | 25,249 |  |  |  | 6,406 |  |  |  | 8,300 |  |  | $ | 23,355 |  |
| Warranty Liability |  | $ | 8,548 |  |  |  | 6,951 |  |  |  | 5,775 |  |  | $ | 9,724 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 6,149 |  |  |  | 18 |  |  |  | 161 |  |  | $ | 6,006 |  |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 19 |  |  |  | — |  |  |  | 19 |  |  | $ | — |  |
| Inventory Reserve |  | $ | 26,675 |  |  |  | 3,303 |  |  |  | 4,729 |  |  | $ | 25,249 |  |
| Warranty Liability |  | $ | 8,739 |  |  |  | 8,561 |  |  |  | 8,752 |  |  | $ | 8,548 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 7,250 |  |  |  | 69 |  |  |  | 1,170 |  |  | $ | 6,149 |  |
