# ADTN 8-K — 0001564590-19-001024 filed 2019-01-24

## item codes, every 8-K on or before 2019-02-28

- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2019-02-28

- none on or before 2019-02-28

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-001024:8k_2_02:1]
EX-99.1
2
adtn-ex991_7.htm
EX-99.1

[0001564590-19-001024:8k_2_02:2]
adtn-ex991_7.htm

[0001564590-19-001024:8k_2_02:3]
EXHIBIT 99.1

[0001564590-19-001024:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the Fourth Quarter 2018 and Declares Quarterly Cash Dividend

[0001564590-19-001024:8k_2_02:5]
HUNTSVILLE, Ala. -- (BUSINESS WIRE) -- January 23, 2019 -- ADTRAN, Inc. (NASDAQ:ADTN) reported results for the fourth quarter 2018. For the quarter, sales were $140.1 million compared to $126.8 million for the fourth quarter of 2017. Net loss was $8.4 million compared to a net loss of $11.1 million for the fourth quarter of 2017. Earnings per share were a loss of $0.18 compared to a loss of $0.23 for the fourth quarter of 2017. Non-GAAP earnings per share were a loss of $0.12 compared to earnings of $0.05 for the fourth quarter of 2017. Net loss and GAAP and non-GAAP earnings per share for the fourth quarter 2018 reflect the effect of a loss in other income of $6.8 million, which resulted primarily from the impact of unrealized losses in our equity investment portfolio arising from U.S. equity market volatility during the quarter.  Non-GAAP earnings per share exclude stock-based compensation expense, acquisition related amortizations and other expenses, restructuring expenses, gain on bargain purchase of a business and the impact of the Tax Cuts and Jobs Act in 2017. The reconciliation between GAAP earnings per share and non-GAAP earnings per share is in the table provided.

[0001564590-19-001024:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “Operating results for the final quarter of 2018 came in largely as expected with strong international revenue growth and an increase in U.S. tier 1 sales allowing the company to offset its normal sequential seasonal trend.  International revenue contributed 46.6% of the total with strong contributions from the Asia-Pacific and LATAM regions.  Our customer engagements increased, centering around our comprehensive portfolio of software-defined access, 10G solutions and G.fast products.  During the quarter, we also acquired SmartRG, a leading provider of open-source connected home platforms and cloud services, whose software approach to delivering both hardware-based and virtualized solutions will enable us to extend the value of our open, programmable and web scalable Mosaic Cloud platform. Looking forward, we believe that ADTRAN is well positioned to leverage our customer, geographic and product diversity momentum as service providers look to accelerate service velocity and scale networks in size, scope and service capabilities.”

[0001564590-19-001024:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the fourth quarter of 2018. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on February 7, 2019. The ex-dividend date is February 6, 2019, and the payment date is February 21, 2019.

[0001564590-19-001024:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its fourth quarter results Thursday, January 24, 2019, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, simply visit the Investor Relations site at www.investors.adtran.com approximately 10 minutes prior to the start of the call and click on the conference call link provided.

[0001564590-19-001024:8k_2_02:9]
An online replay of the conference call, as well as the text of the Company's earnings release, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or via email at investor.relations@adtran.com.

[0001564590-19-001024:8k_2_02:10]
At ADTRAN, we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help communications service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking. Find more at ADTRAN, LinkedIn and Twitter.

[0001564590-19-001024:8k_2_02:11]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2017. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-19-001024:8k_2_02:12]
Condensed Consolidated Balance Sheet

[0001564590-19-001024:8k_2_02:13]
(Unaudited)

[0001564590-19-001024:8k_2_02:14]
(In thousands)

[0001564590-19-001024:8k_2_02:15]
|  | December 31, |  |  | December 31, |  |
|  | 2018 |  |  | 2017 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 105,504 |  |  | $ | 86,433 |  |
| Short-term investments |  | 3,246 |  |  |  | 16,129 |  |
| Accounts receivable, net |  | 99,385 |  |  |  | 144,150 |  |
| Other receivables |  | 36,699 |  |  |  | 26,578 |  |
| Inventory, net |  | 99,848 |  |  |  | 122,542 |  |
| Prepaid expenses and other current assets |  | 10,744 |  |  |  | 17,282 |  |
| Total Current Assets |  | 355,426 |  |  |  | 413,114 |  |
| Property, plant and equipment, net |  | 80,635 |  |  |  | 85,079 |  |
| Other non-current assets (1) |  | 83,144 |  |  |  | 40,645 |  |
| Long-term investments |  | 108,822 |  |  |  | 130,256 |  |
| Total Assets | $ | 628,027 |  |  | $ | 669,094 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 61,054 |  |  | $ | 60,632 |  |
| Unearned revenue |  | 17,940 |  |  |  | 13,070 |  |
| Accrued expenses |  | 11,746 |  |  |  | 13,232 |  |
| Accrued wages and benefits |  | 14,752 |  |  |  | 15,948 |  |
| Income tax payable, net |  | 12,518 |  |  |  | 3,936 |  |
| Total Current Liabilities |  | 118,010 |  |  |  | 106,818 |  |
| Non-current unearned revenue |  | 5,296 |  |  |  | 4,556 |  |
| Other non-current liabilities |  | 33,842 |  |  |  | 34,209 |  |
| Bonds payable |  | 24,600 |  |  |  | 25,600 |  |
| Total Liabilities |  | 181,748 |  |  |  | 171,183 |  |
| Stockholders' Equity |  | 446,279 |  |  |  | 497,911 |  |
| Total Liabilities and Stockholders' Equity | $ | 628,027 |  |  | $ | 669,094 |  |

[0001564590-19-001024:8k_2_02:16]
(1) Other non-current assets includes certain identifiable intangible assets as a result of the preliminary purchase accounting for the acquisition of SmartRG Inc, net deferred tax assets, goodwill and other non-current assets. The purchase accounting is still considered preliminary pending management’s final assessment of fair values and therefore is subject to further adjustments. The final valuation is expected to result in goodwill equal to the excess of the purchase price over the identifiable intangible assets.

[0001564590-19-001024:8k_2_02:17]
Consolidated Statements of Income

[0001564590-19-001024:8k_2_02:18]
(Unaudited)

[0001564590-19-001024:8k_2_02:19]
(In thousands, except per share data)

[0001564590-19-001024:8k_2_02:20]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |  |
|  |  | December 31, |  |  | December 31, |  |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 116,873 |  |  | $ | 95,789 |  |  | $ | 458,232 |  |  | $ | 540,396 |  |  |
| Services |  |  | 23,215 |  |  |  | 31,047 |  |  |  | 71,045 |  |  |  | 126,504 |  |  |
| Total Sales |  |  | 140,088 |  |  |  | 126,836 |  |  |  | 529,277 |  |  |  | 666,900 |  |  |
| Cost of sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 70,745 |  |  |  | 49,702 |  |  |  | 278,929 |  |  |  | 279,563 |  |  |
| Services |  |  | 13,955 |  |  |  | 18,325 |  |  |  | 46,783 |  |  |  | 83,702 |  |  |
| Total Cost of Sales |  |  | 84,700 |  |  |  | 68,027 |  |  |  | 325,712 |  |  |  | 363,265 |  |  |
| Gross Profit |  |  | 55,388 |  |  |  | 58,809 |  |  |  | 203,565 |  |  |  | 303,635 |  |  |
| Selling, general and administrative expenses |  |  | 28,079 |  |  |  | 31,412 |  |  |  | 124,440 |  |  |  | 135,583 |  |  |
| Research and development expenses |  |  | 31,092 |  |  |  | 31,550 |  |  |  | 124,547 |  |  |  | 130,666 |  |  |
| Operating Income (Loss) |  |  | (3,783 | ) |  |  | (4,153 | ) |  |  | (45,422 | ) |  |  | 37,386 |  |  |
| Interest and dividend income |  |  | 1,422 |  |  |  | 1,523 |  |  |  | 4,026 |  |  |  | 4,380 |  |  |
| Interest expense |  |  | (135 | ) |  |  | (139 | ) |  |  | (533 | ) |  |  | (556 | ) |  |
| Net investment gain (loss) |  |  | (9,450 | ) |  |  | 1,816 |  |  |  | (4,050 | ) |  |  | 4,685 |  |  |
| Other income (expense), net |  |  | 1,359 |  |  |  | 219 |  |  |  | 1,286 |  |  |  | (1,208 | ) |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  | 11,322 |  |  |  | — |  |  |
| Income (Loss) before provision for income taxes |  |  | (10,587 | ) |  |  | (734 | ) |  |  | (33,371 | ) |  |  | 44,687 |  |  |
| (Provision) benefit for income taxes |  |  | 2,140 |  |  |  | (10,376 | ) |  |  | 14,029 |  |  |  | (20,847 | ) |  |
| Net Income (Loss) |  | $ | (8,447 | ) |  | $ | (11,110 | ) |  | $ | (19,342 | ) |  | $ | 23,840 |  |  |
| Weighted average shares outstanding – basic |  |  | 47,730 |  |  |  | 48,280 |  |  |  | 47,880 |  |  |  | 48,153 |  |  |
| Weighted average shares outstanding – diluted |  |  | 47,730 |  |  |  | 48,280 |  |  |  | 47,880 |  |  |  | 48,699 |  | (1) |
| Earnings (loss) per common share – basic |  | $ | (0.18 | ) |  | $ | (0.23 | ) |  | $ | (0.40 | ) |  | $ | 0.50 |  |  |
| Earnings (loss) per common share – diluted |  | $ | (0.18 | ) |  | $ | (0.23 | ) |  | $ | (0.40 | ) |  | $ | 0.49 |  | (1) |

[0001564590-19-001024:8k_2_02:21]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-19-001024:8k_2_02:22]
Consolidated Statements of Comprehensive Income

[0001564590-19-001024:8k_2_02:23]
(Unaudited)

[0001564590-19-001024:8k_2_02:24]
(In thousands)

[0001564590-19-001024:8k_2_02:25]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net Income (Loss) |  | $ | (8,447 | ) |  | $ | (11,110 | ) |  | $ | (19,342 | ) |  | $ | 23,840 |  |
| Other Comprehensive Income (Loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net unrealized gains (losses) on available-for-sale securities |  |  | 210 |  |  |  | (349 | ) |  |  | (3,130 | ) |  |  | 2,163 |  |
| Net unrealized gains on cash flow hedges |  |  | — |  |  |  | 196 |  |  |  | — |  |  |  | — |  |
| Defined benefit plan adjustments |  |  | (3,859 | ) |  |  | 517 |  |  |  | (3,755 | ) |  |  | 731 |  |
| Foreign currency translation |  |  | (1,203 | ) |  |  | 597 |  |  |  | (4,236 | ) |  |  | 5,999 |  |
| Other Comprehensive Income (Loss), net of tax |  |  | (4,852 | ) |  |  | 961 |  |  |  | (11,121 | ) |  |  | 8,893 |  |
| Comprehensive Income (Loss), net of tax |  | $ | (13,299 | ) |  | $ | (10,149 | ) |  | $ | (30,463 | ) |  | $ | 32,733 |  |

[0001564590-19-001024:8k_2_02:26]
Consolidated Statements of Cash Flows

[0001564590-19-001024:8k_2_02:27]
(Unaudited)

[0001564590-19-001024:8k_2_02:28]
(In thousands)

[0001564590-19-001024:8k_2_02:29]
|  |  | Twelve Months Ended |  |
|  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (19,342 | ) |  | $ | 23,840 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 15,891 |  |  |  | 15,692 |  |
| Amortization of net premium (discount) on available-for-sale investments |  |  | (50 | ) |  |  | 425 |  |
| Net unrealized (gain) loss on long-term investments |  |  | 4,050 |  |  |  | (4,685 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | 67 |  |  |  | (145 | ) |
| Gain on bargain purchase of a business |  |  | (11,322 | ) |  |  | — |  |
| Stock-based compensation expense |  |  | 7,155 |  |  |  | 7,433 |  |
| Deferred income taxes |  |  | (17,257 | ) |  |  | 14,073 |  |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 49,200 |  |  |  | (49,103 | ) |
| Other receivables |  |  | (8,522 | ) |  |  | (10,222 | ) |
| Inventory |  |  | 24,192 |  |  |  | (15,518 | ) |
| Prepaid expenses and other assets |  |  | 10,727 |  |  |  | (4,830 | ) |
| Accounts payable |  |  | (2,669 | ) |  |  | (17,742 | ) |
| Accrued expenses and other liabilities |  |  | (3,226 | ) |  |  | (5,455 | ) |
| Income taxes payable |  |  | 7,690 |  |  |  | 3,858 |  |
| Net cash provided by (used in) operating activities |  |  | 56,584 |  |  |  | (42,379 | ) |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (8,110 | ) |  |  | (14,720 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 151 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 153,649 |  |  |  | 173,752 |  |
| Purchases of available-for-sale investments |  |  | (123,209 | ) |  |  | (93,141 | ) |
| Acquisition of business |  |  | (23,275 | ) |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | (945 | ) |  |  | 66,042 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 1,483 |  |  |  | 13,412 |  |
| Purchases of treasury stock |  |  | (15,532 | ) |  |  | (17,348 | ) |
| Dividend payments |  |  | (17,267 | ) |  |  | (17,368 | ) |
| Payments on long-term debt |  |  | (1,000 | ) |  |  | (1,100 | ) |
| Net cash used in financing activities |  |  | (32,316 | ) |  |  | (22,404 | ) |
| Net increase in cash and cash equivalents |  |  | 23,323 |  |  |  | 1,259 |  |
| Effect of exchange rate changes |  |  | (4,252 | ) |  |  | 5,279 |  |
| Cash and cash equivalents, beginning of year |  |  | 86,433 |  |  |  | 79,895 |  |
| Cash and cash equivalents, end of year |  | $ | 105,504 |  |  | $ | 86,433 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 62 |  |  | $ | 408 |  |

[0001564590-19-001024:8k_2_02:30]
Supplemental Information

[0001564590-19-001024:8k_2_02:31]
Restructuring Expenses

[0001564590-19-001024:8k_2_02:32]
(Unaudited)

[0001564590-19-001024:8k_2_02:33]
(In thousands)

[0001564590-19-001024:8k_2_02:34]
Restructuring expense was recorded in the following Consolidated Statements of Income categories for three and twelve months ended December 31, 2018 and 2017:

[0001564590-19-001024:8k_2_02:35]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Restructuring expense included in cost of sales |  | $ | — |  |  | $ | — |  |  | $ | 2,761 |  |  | $ | — |  |
| Selling, general and administrative expense |  |  | 25 |  |  |  | 59 |  |  |  | 2,686 |  |  |  | 152 |  |
| Research and development expense |  |  | — |  |  |  | — |  |  |  | 1,814 |  |  |  | 122 |  |
| Restructuring expense included in operating expenses |  |  | 25 |  |  |  | 59 |  |  |  | 4,500 |  |  |  | 274 |  |
| Total restructuring expense |  |  | 25 |  |  |  | 59 |  |  |  | 7,261 |  |  |  | 274 |  |
| Provision for income taxes |  |  | (6 | ) |  |  | (23 | ) |  |  | (1,888 | ) |  |  | (107 | ) |
| Total restructuring expense, net of tax |  | $ | 19 |  |  | $ | 36 |  |  | $ | 5,373 |  |  | $ | 167 |  |

[0001564590-19-001024:8k_2_02:36]
Supplemental Information

[0001564590-19-001024:8k_2_02:37]
Acquisition Related Expenses, Amortizations and Adjustments

[0001564590-19-001024:8k_2_02:38]
(Unaudited)

[0001564590-19-001024:8k_2_02:39]
(In thousands)

[0001564590-19-001024:8k_2_02:40]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc., on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA), on September 13, 2016, we closed on the acquisition of CommScope’s active fiber business (CommScope), on March 19, 2018, we closed on the acquisition of Sumitomo Electric Lightwave Corp.’s North American EPON business (Sumitomo), and on November 30, 2018, we closed on the acquisition of SmartRG Inc. (SmartRG). Acquisition related expenses, amortizations and adjustments for the three and twelve months ended December 31, 2018 and 2017 for all five transactions are as follows:

[0001564590-19-001024:8k_2_02:41]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | — |  |  | $ | 158 |  |  | $ | 369 |  |  | $ | 632 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 85 |  |  |  | 95 |  |  |  | 355 |  |  |  | 527 |  |
| Amortization of other purchase accounting adjustments |  |  | 2 |  |  |  | — |  |  |  | 3 |  |  |  | 39 |  |
| Subtotal - NSN BBA acquisition |  |  | 87 |  |  |  | 95 |  |  |  | 358 |  |  |  | 566 |  |
| CommScope acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 110 |  |  |  | 219 |  |  |  | 483 |  |  |  | 1,732 |  |
| Amortization of other purchase accounting adjustments |  |  | 3 |  |  |  | 3 |  |  |  | 4 |  |  |  | 88 |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8 |  |
| Subtotal - CommScope acquisition |  |  | 113 |  |  |  | 222 |  |  |  | 487 |  |  |  | 1,828 |  |
| Sumitomo acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 663 |  |  |  | — |  |  |  | 2,097 |  |  |  | — |  |
| Amortization of other purchase accounting adjustments |  |  | 7 |  |  |  | — |  |  |  | 86 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | (1 | ) |  |  | — |  |  |  | 123 |  |  |  | — |  |
| Subtotal - Sumitomo acquisition |  |  | 669 |  |  |  | — |  |  |  | 2,306 |  |  |  | — |  |
| SmartRG acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 150 |  |  |  | — |  |  |  | 150 |  |  |  | — |  |
| Amortization of other purchase accounting adjustments |  |  | 181 |  |  |  | — |  |  |  | 181 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | 233 |  |  |  | — |  |  |  | 233 |  |  |  | — |  |
| Subtotal - SmartRG acquisition |  |  | 564 |  |  |  | — |  |  |  | 564 |  |  |  | — |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 1,433 |  |  |  | 475 |  |  |  | 4,084 |  |  |  | 3,026 |  |
| Provision for income taxes |  |  | (378 | ) |  |  | (178 | ) |  |  | (1,080 | ) |  |  | (1,135 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,055 |  |  | $ | 297 |  |  | $ | 3,004 |  |  | $ | 1,891 |  |

[0001564590-19-001024:8k_2_02:42]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and twelve months ended December 31, 2018 and 2017:

[0001564590-19-001024:8k_2_02:43]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Cost of goods sold |  | $ | 542 |  |  | $ | 2 |  |  | $ | 1,381 |  |  | $ | 88 |  |
| Selling, general and administrative expenses |  |  | 583 |  |  |  | 51 |  |  |  | 1,457 |  |  |  | 215 |  |
| Research and development expenses |  |  | 308 |  |  |  | 422 |  |  |  | 1,246 |  |  |  | 2,723 |  |
| Total acquisition related expenses, amortizations and adjustments included in operating expenses |  |  | 891 |  |  |  | 473 |  |  |  | 2,703 |  |  |  | 2,938 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 1,433 |  |  |  | 475 |  |  |  | 4,084 |  |  |  | 3,026 |  |
| Provision for income taxes |  |  | (378 | ) |  |  | (178 | ) |  |  | (1,080 | ) |  |  | (1,135 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,055 |  |  | $ | 297 |  |  | $ | 3,004 |  |  | $ | 1,891 |  |

[0001564590-19-001024:8k_2_02:44]
Supplemental Information

[0001564590-19-001024:8k_2_02:45]
Stock-based Compensation Expense

[0001564590-19-001024:8k_2_02:46]
(Unaudited)

[0001564590-19-001024:8k_2_02:47]
(In thousands)

[0001564590-19-001024:8k_2_02:48]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 120 |  |  | $ | 98 |  |  | $ | 418 |  |  | $ | 379 |  |
| Selling, general and administrative expense |  |  | 1,065 |  |  |  | 1,045 |  |  |  | 3,989 |  |  |  | 4,063 |  |
| Research and development expense |  |  | 727 |  |  |  | 717 |  |  |  | 2,748 |  |  |  | 2,991 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,792 |  |  |  | 1,762 |  |  |  | 6,737 |  |  |  | 7,054 |  |
| Total stock-based compensation expense |  |  | 1,912 |  |  |  | 1,860 |  |  |  | 7,155 |  |  |  | 7,433 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (416 | ) |  |  | (484 | ) |  |  | (1,432 | ) |  |  | (1,699 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,496 |  |  | $ | 1,376 |  |  | $ | 5,723 |  |  | $ | 5,734 |  |

[0001564590-19-001024:8k_2_02:49]
Reconciliation of GAAP earnings (loss) per share, diluted, to

[0001564590-19-001024:8k_2_02:50]
Non-GAAP earnings (loss) per common share, diluted

[0001564590-19-001024:8k_2_02:51]
(Unaudited)

[0001564590-19-001024:8k_2_02:52]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| GAAP earnings (loss) per common share - diluted |  | $ | (0.18 | ) |  | $ | (0.23 | ) |  | $ | (0.40 | ) |  | $ | 0.49 |  |
| Restructuring expense |  |  | — |  |  |  | — |  |  |  | 0.11 |  |  |  | — |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.02 |  |  |  | 0.01 |  |  |  | 0.06 |  |  |  | 0.04 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.12 |  |  |  | 0.12 |  |
| Impact of the Tax Cuts and Jobs Act |  |  | — |  |  |  | 0.24 |  |  |  | — |  |  |  | 0.24 |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  | (0.24 | ) |  |  | — |  |
| Non-GAAP earnings (loss) per common share - diluted (1) |  | $ | (0.12 | ) |  | $ | 0.05 |  |  | $ | (0.35 | ) |  | $ | 0.89 |  |

[0001564590-19-001024:8k_2_02:53]
(1) Table may not foot due to rounding
