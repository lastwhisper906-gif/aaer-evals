# ADTN MD&A — 0001564590-19-005179


## mdna

[0001564590-19-005179:mdna:1]
| ITEM 7. | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001564590-19-005179:mdna:2]
Overview

[0001564590-19-005179:mdna:3]
ADTRAN is a leading global provider of networking and communications equipment, serving a diverse domestic and international customer base in 68 countries that includes Tier 1, 2 and 3 service providers, cable/MSOs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions of users worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors.  In order to service our customers and build revenue, we are constantly conducting research and development of new products addressing customer needs and testing those products for the particular specifications of the particular customers. In addition to our corporate headquarters in Huntsville, Alabama, we have research and development (R&D) facilities in strategic global locations.

[0001564590-19-005179:mdna:4]
We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly automated, cloud-controlled voice, data, internet and video network of the future.

[0001564590-19-005179:mdna:5]
Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek to be a high-quality, and in most instances the low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001564590-19-005179:mdna:6]
Our business is global. We supply different sets of products to different customers in different regions around the world. Our financial results in any period reflect the activities of our various customers in their respective regions at any given time. In order to service our customers and build revenue, we are constantly conducting research and development of new products addressing customer needs and testing those products for the particular specifications of the particular customers. The lead times to revenues for these products vary.

[0001564590-19-005179:mdna:7]
The company made two acquisitions in 2018, strengthening its position in both the Cable/MSO and connected home markets. In the first quarter of 2018, we acquired the market-leading EPON business and certain assets for North America from Sumitomo Electric Industries Ltd. These solutions, combined with our organic fiber access product portfolio and our distributed access expertise, present new opportunities in the cable/MSO market. Also, in the fourth quarter of 2018, we acquired U.S.-based SmartRG, an industry-leading provider of carrier-class, connected–home software platforms and cloud services for broadband service providers. With this acquisition, ADTRAN now offers a complete cloud-to-consumer portfolio of virtualized management, data analytics, Wi-Fi-enabled residential gateways and software platforms. For more information, see Note 2 of the Notes to Consolidated Financial Statements included in Item 8 of this report.

[0001564590-19-005179:mdna:8]
As previously reported, we experienced a significant negative impact on our North American revenue as a result of a decision in mid-fourth quarter 2017 by a major customer to suspend a product rollout and network upgrade following a merger. While we continue to sell to that customer, the project in question has not yet resumed to prior levels, and we are unsure when, if ever, it will. During the periods covered in this report, our North American revenue was also impacted by slower-than-expected orders of an ultra-broadband product by a large domestic customer.

[0001564590-19-005179:mdna:9]
During the same period, however, we have seen an expansion of our revenues from much of the customer base and have brought to fruition our participation in a number of large customer projects, which in some cases have begun to produce some revenues and in all cases represent a possibility of significant revenue in the future. These include next-generation PON projects with service providers, both domestically and internationally, the deployment for a large project in the APAC region, a significant network upgrade by a Tier 1 European customer, as well as continued expansion and opportunities for our EPON products to two of the top North American cable/MSO operators.

[0001564590-19-005179:mdna:10]
While our services business did not increase at the rate that it did in 2016 and 2017, and has decreased from the record levels we achieved in 2017 due to the above-mentioned merger-related disruption, we continue to develop our services business around the world, and we anticipate that it will continue to expand and remain an increasingly important part of our revenue streams across the world. Margins on services revenue vary depending upon the types of services performed.

[0001564590-19-005179:mdna:11]
We review our financial performance, specifically revenue and gross profit, based on two reportable segments – Network Solutions and Services & Support. Network Solutions software and hardware products provide solutions supporting fiber-, copper- and coaxial-based infrastructures and a growing number of wireless solutions, lowering the overall cost to deploy advanced services across a wide range of applications for Carrier, Cable/MSO networks and business networks, as well as prior-generation products. Our Services & Support enables our customers to accelerate time to market, reduce costs and improve customer satisfaction through a complete portfolio of services, including maintenance, turnkey network implementation, solutions integration, and managed services. ADTRAN’s comprehensive network implementation services include engineering design and documentation (pre-construction), construction and installation (construction), and test, turn-up and provisioning (post-construction). Additionally, we partner with customers to tailor a program to each specific service-delivery need.

[0001564590-19-005179:mdna:12]
In addition, we also report revenue for the following three categories – Access & Aggregation, Subscriber Solutions & Experience (formerly Customer Devices) and Traditional & Other Products.

[0001564590-19-005179:mdna:13]
Access & Aggregation solutions are used by service providers to connect their network infrastructure to subscribers. This category includes software- and hardware-based products and services that aggregate and/or originate access technologies. The portfolio of ADTRAN solutions within this category includes a wide array of modular or fixed physical form factors designed to deliver the best technology and economic fit based on the target subscriber density and environmental conditions.

[0001564590-19-005179:mdna:14]
The Access & Aggregation category includes product and service families such as:

[0001564590-19-005179:mdna:15]
|  | • | Mosaic-branded network management and subscriber services control and orchestration software within SD-Access architectures; |

[0001564590-19-005179:mdna:16]
|  | • | SDX series of SDN-controlled programmable network elements that form the hardware components within SD-Access architectures; |

[0001564590-19-005179:mdna:17]
|  | • | Total Access 5000 Series Fiber to the Premises (FTTP) and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN); |

[0001564590-19-005179:mdna:18]
|  | • | hiX 5600 Series fiber aggregation and FTTN MSAN; |

[0001564590-19-005179:mdna:19]
|  | • | Fiber to the Distribution Point (FTTdp) Gfast Distribution Point Units (DPUs); |

[0001564590-19-005179:mdna:20]
|  | • | GPON, EPON and 10G PON Optical Line Terminals (OLTs); |

[0001564590-19-005179:mdna:21]
|  | • | Optical Networking Edge (ONE) aggregation; |

[0001564590-19-005179:mdna:22]
|  | • | IP-based Digital Subscriber Line Access Multiplexers (DSLAMs); |

[0001564590-19-005179:mdna:23]
|  | • | Cabinet and Outside-Plant (OSP) enclosures and services; |

[0001564590-19-005179:mdna:24]
|  | • | Pluggable optical transceivers (i.e., SFP, SFP+, XFP, QSFP), cables and other miscellaneous materials; |

[0001564590-19-005179:mdna:25]
|  | • | Planning, engineering, program management, maintenance, installation and commissioning services to implement customer network solutions; |

[0001564590-19-005179:mdna:26]
|  | • | Other products and services that are generally applicable to Access & Aggregation. |

[0001564590-19-005179:mdna:27]
31

[0001564590-19-005179:mdna:28]
Subscriber Solutions & Experience (formerly Customer Devices) includes open-source connected home platforms, cloud services and any of our solutions and services that deliver residential and/or enterprise subscribers an immersive and interactive broadband experience from the service provider’s access network. These products, software, and services include SmartRG solutions and applications, NetVanta Enterprise IP business gateways, access routers, Ethernet switches, ProCloud service offerings, residential and enterprise operating systems (such as SmartOS and AOS), Bluesocket Wi-Fi portfolio, service provider and Cable/MSO Optical Network Terminals (ONTs), as well as related software applications and services. In alignment with our increased focus on enhancing customer experience for both business and consumer broadband customers as well as the addition of SmartRG during 2018, Customer Devices will now be known as Subscriber Solutions & Experience, as this more accurately represents this revenue category and our vision moving forward.

[0001564590-19-005179:mdna:29]
The Subscriber Solutions & Experience category includes products and services such as:

[0001564590-19-005179:mdna:30]
|  | • | Cloud-based SaaS management platforms for service providers to manage residential and enterprise networks; |

[0001564590-19-005179:mdna:31]
|  | • | SaaS platforms for subscriber and network analytics collection used to enhance network operations and customer experience; |

[0001564590-19-005179:mdna:32]
|  | • | SmartOS-branded embedded software licensing for residential and enterprise gateway and Wi-Fi devices; |

[0001564590-19-005179:mdna:33]
|  | • | Broadband customer premises solutions, including GPON, XGS-PON, NG-PON2, EPON and 10G EPON and point-to-point Ethernet Optical Network Terminals (ONTs); |

[0001564590-19-005179:mdna:34]
|  | • | Radio Frequency over Glass (RFoG) MicroNodes; |

[0001564590-19-005179:mdna:35]
|  | • | Wi-Fi enabled residential gateway products and accessories across xDSL, Ethernet, DOCSIS, LTE, and fiber technologies; |

[0001564590-19-005179:mdna:36]
|  | • | Enterprise Wi-Fi access points and associated powering and switching infrastructure; |

[0001564590-19-005179:mdna:37]
|  | • | Enterprise Session Border Controller (eSBC) device platforms and software; |

[0001564590-19-005179:mdna:38]
|  | • | Branch office business routers; |

[0001564590-19-005179:mdna:39]
|  | • | Carrier Ethernet services termination devices; |

[0001564590-19-005179:mdna:40]
|  | • | Voice over Internet Protocol (VoIP) media gateways; |

[0001564590-19-005179:mdna:41]
|  | • | ProServices pre-sale and post-sale technical support; |

[0001564590-19-005179:mdna:42]
|  | • | Planning, engineering, program management, maintenance, installation and commissioning services to implement customer devices solutions into consumer, small business and enterprise locations; |

[0001564590-19-005179:mdna:43]
|  | • | Other products, software and services applicable to subscriber solutions and experience. |

[0001564590-19-005179:mdna:44]
Traditional & Other Products generally includes a mix of prior-generation technologies’ products and services, as well as other products and services that do not fit within the Access & Aggregation or Subscriber Solutions & Experience categories.

[0001564590-19-005179:mdna:45]
The Traditional & Other Products category includes products and services such as:

[0001564590-19-005179:mdna:46]
|  | • | Time Division Multiplexed (TDM) and Asynchronous Transfer Mode (ATM)-based aggregation systems and customer devices; |

[0001564590-19-005179:mdna:47]
|  | • | HDSL, ADSL and other mature technologies used to deliver business and residential services over service provider access and customer networks; |

[0001564590-19-005179:mdna:48]
|  | • | Other products and services outside the Access & Aggregation and Subscriber Solutions & Experience categories. |

[0001564590-19-005179:mdna:49]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future periods due to a number of factors, including customer order activity and backlog. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days. These factors normally result in very little order backlog or order flow visibility. Additionally, backlog levels may vary because of seasonal trends, the timing of customer projects, and other factors that affect customer order lead times. Because many of our customers require prompt delivery of products, we are required to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001564590-19-005179:mdna:50]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter.

[0001564590-19-005179:mdna:51]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. See Note 17 of Notes to Consolidated Financial Statements, included in Item 8 of this report, for additional information. For a discussion of risks associated with our operating results, see Item 1A of this report.

[0001564590-19-005179:mdna:52]
Results of Operations

[0001564590-19-005179:mdna:53]
The following table presents selected financial information derived from our consolidated statements of income expressed as a percentage of sales for the years indicated. Amounts may not foot due to rounding.

[0001564590-19-005179:mdna:54]
| Year Ended December 31, |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 86.6 | % |  |  | 81.0 | % |  |  | 82.5 | % |
| Services |  |  | 13.4 |  |  |  | 19.0 |  |  |  | 17.5 |  |
| Total sales |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 52.7 |  |  |  | 41.9 |  |  |  | 42.5 |  |
| Services |  |  | 8.8 |  |  |  | 12.6 |  |  |  | 11.7 |  |
| Total cost of sales |  |  | 61.5 |  |  |  | 54.5 |  |  |  | 54.2 |  |
| Gross profit |  |  | 38.5 |  |  |  | 45.5 |  |  |  | 45.8 |  |
| Selling, general and administrative expenses |  |  | 23.5 |  |  |  | 20.3 |  |  |  | 20.7 |  |
| Research and development expenses |  |  | 23.5 |  |  |  | 19.6 |  |  |  | 19.6 |  |
| Operating income (loss) |  |  | (8.6 | ) |  |  | 5.6 |  |  |  | 5.4 |  |
| Interest and dividend income |  |  | 0.8 |  |  |  | 0.7 |  |  |  | 0.6 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Net investment gain (loss) |  |  | (0.8 | ) |  |  | 0.7 |  |  |  | 0.9 |  |
| Other income (expense), net |  |  | 0.2 |  |  |  | (0.2 | ) |  |  | (0.1 | ) |
| Gain on bargain purchase of a business |  |  | 2.1 |  |  |  | — |  |  |  | 0.6 |  |
| Income (loss) before (provision) benefit for income taxes |  |  | (6.3 | ) |  |  | 6.7 |  |  |  | 7.4 |  |
| (Provision) benefit for income taxes |  |  | 2.7 |  |  |  | (3.1 | ) |  |  | (1.8 | ) |
| Net income (loss) |  |  | (3.7 | )% |  |  | 3.6 | % |  |  | 5.5 | % |

[0001564590-19-005179:mdna:55]
2018 Compared to 2017

[0001564590-19-005179:mdna:56]
Sales

[0001564590-19-005179:mdna:57]
Our sales decreased 20.6% from $666.9 million for the year ended December 31, 2017 to $529.3 million for the year ended December 31, 2018. The decrease in sales occurred over both our Network Solutions and our Services & Support reporting segments. Our Network Solutions sales decreased $82.2 million compared to 2017, and our Services & Support sales decreased $55.5 million versus the prior year. The decrease in our 2018 sales is primarily attributable to the termination of a multi-city broadband project, resulting from a merger-related review and slowdown in spending at a domestic Tier 1 customer that particularly affected our Access & Aggregation products and services, which decreased $115.1 million in 2018. The 2018 decline in sales to this domestic Tier 1 customer was partially offset by an increase in international sales of $81.7 million during the year, primarily as a result of increased sales to Tier 1 customers in the EMEA and Asia-Pacific regions. During 2018, sales of our Subscriber Solutions & Experience products decreased $4.0 million, due primarily to decreases in sales of our fiber CPE, and sales of our Traditional & Other Products decreased $18.6 million.

[0001564590-19-005179:mdna:58]
Network Solutions segment sales decreased by 15.2% from $540.4 million in 2017 to $458.2 million in 2018, due primarily to a decrease in our Access & Aggregation products. The decrease in sales of 16.6% of our Access & Aggregation products for 2018 is primarily attributable to the above-mentioned merger-related review and slowdown in spending at a domestic Tier 1 customer, partially offset by an increase in sales to international Tier 1 customers as discussed further below. The decrease of 2.9% in 2018 for sales of our Subscriber Solutions & Experience products is primarily attributable to the changes in sales of fiber CPE products. While we expect that revenues from Traditional & Other Products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-19-005179:mdna:59]
Services & Support sales decreased by 43.8% from $126.5 million in 2017 to $71.0 million in 2018. The decrease in sales for 2018 is primarily attributable to a significant decrease in network installation services for Access & Aggregation products related to the above mentioned merger-related review and slowdown in spending at a domestic Tier 1 customer.

[0001564590-19-005179:mdna:60]
Domestic sales decreased 43.2% from $508.2 million in 2017 to $288.8 million in 2018 which was a result of a decision in the mid-fourth quarter 2017 by a major customer to suspend a product rollout and network upgrade following a major. Excluding the impact of this customer, domestic sales increased by 9.1% in 2018 over the prior year.

[0001564590-19-005179:mdna:61]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, increased 51.5% from $158.7 million in 2017 to $240.4 million in 2018. International sales as a percentage of total sales increased from 23.8% in 2017 to 45.4% in 2018. The increase in sales for 2018 is primarily attributable to an increase in sales in EMEA and APAC. The increase in sales for 2018 in EMEA is primarily attributable to a network expansion program and a services award by a large European Tier 1 customer. The increase in sales in APAC for 2018 is primarily attributable to a network expansion program by a Tier 1 customer in Australia.

[0001564590-19-005179:mdna:62]
Our international revenues are largely focused on broadband infrastructure and are impacted by the decisions of our customers as to the timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. For example, the European Commission launched a Gigabit Society initiative, and before that, the Digital Agenda, which has provided a favorable market environment for the deployment of ultra-broadband and Gigabit network solutions. Although the overall environment and market demand for broadband service deployment in the European Union have improved, some new broadband technologies are still being reviewed for regulatory and standards compliance, which may affect the timing of those technologies. In Mexico, regulatory changes have created uncertainty for customers resulting in slowdowns in their network buying patterns, which are only now beginning to be resolved. The competitive landscape in certain international markets is also impacted by the increased presence of Asian manufacturers that seek to compete aggressively on price. A strengthening U.S. dollar can also negatively impact our revenues in regions such as Latin America, where our products are traditionally priced in U.S. dollars, while in regions where our products are sold in local currency, such as Europe, a stronger U.S. dollar can negatively impact operating income. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenues and operating income. However, we do not presently foresee a significant negative impact on our financial condition based on our strong liquidity and the generally positive environment described above.

[0001564590-19-005179:mdna:63]
We recognized a positive revenue impact in the first half of 2017 due to our being awarded a network expansion program by a large European Tier 1 customer. During 2018, this European Tier 1 customer undertook an additional network expansion project. Additionally, we anticipate that as our Latin American customers resume their network upgrade projects, we may experience further enhancement to our revenues. As announced, we received of a new nationwide award in the APAC region, as well as additional awards based on new ADTRAN technologies in the EMEA region that have, and we believe will continue to have, a positive impact to our revenues.

[0001564590-19-005179:mdna:64]
Cost of Sales

[0001564590-19-005179:mdna:65]
As a percentage of sales, cost of sales increased from 54.5% for the year ended December 31, 2017 to 61.5% for the year ended December 31, 2018. The increase in the cost of sales as a percentage of sales is due primarily to regional revenue shifts, customer and product mix, services and support mix, restructuring expenses and an increase in warranty expense.

[0001564590-19-005179:mdna:66]
Network Solutions cost of sales, as a percent of that segment’s sales, increased from 51.7% of sales in 2017 to 60.9% of sales in 2018. The increase in Network Solutions cost of sales as a percentage of that segment’s sales is primarily attributable to a regional revenue shift, customer and product mix, an increase in warranty expense from the prior year due to a settlement received in first quarter of 2017 from a third-party supplier for a defective component, higher product costs versus the prior year due to purchase discounts received from a contract manufacturer in the first quarter of 2017 and an increase in restructuring expenses incurred during 2018.

[0001564590-19-005179:mdna:67]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-19-005179:mdna:68]
Services & Support cost of sales, as a percent of that segment’s sales, decreased from 66.2% of sales in 2017 to 65.8% of sales in 2018. The decrease in Services & Support cost of sales as a percentage of that segment’s sales in 2018 is primarily attributable to customer mix, services and support mix, and certain cost reductions from restructuring related to the realignment of our Services & Support labor expense resulting from the above-mentioned merger-related termination of a network upgrade project by a domestic Tier 1 customer.

[0001564590-19-005179:mdna:69]
Our Services & Support revenues are comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component. Our services business has experienced significant growth since 2015 as competitive pressures to expand broadband access and speeds have strained carriers’ ability to respond to customer demand. However, the revenue associated with this business decreased from 2017 to 2018 due to the impact of the above-mentioned merger-related review and slowdown of a network upgrade project by a domestic Tier 1 customer. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and sub-contracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services.

[0001564590-19-005179:mdna:70]
As our network planning and implementation revenues have grown and are now the largest component of our Services & Support business, our Services & Support segment gross margins decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support revenues comprising a larger percentage of our overall revenues, and because our Services & Support gross margins are below those of the Network Solutions segment, our overall corporate gross margins have declined as that business has continued to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-19-005179:mdna:71]
Selling, General and Administrative Expenses

[0001564590-19-005179:mdna:72]
Selling, general and administrative expenses decreased by 8.2% from $135.6 million in 2017 to $124.4 million in 2018. Selling, general and administrative expenses include personnel costs for administration, finance, information technology, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, advertising, promotional material, trade show expenses, and related travel costs. The decrease in selling, general and administrative expenses is primarily attributable to a decrease in compensation and labor expense, independent contractor expense, and travel expense, partially offset by an increase in restructuring expenses.

[0001564590-19-005179:mdna:73]
Selling, general and administrative expenses as a percentage of sales increased from 20.3% for the year ended December 31, 2017 to 23.5% for the year ended December 31, 2018. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared as these costs are relatively fixed in the short term.

[0001564590-19-005179:mdna:74]
Research and Development Expenses

[0001564590-19-005179:mdna:75]
Research and development expenses decreased by 4.7% from $130.7 million for the year ended December 31, 2017 to $124.5 million for the year ended December 31, 2018. The decrease in research and development expenses is primarily attributable to a decrease in compensation and labor expense, independent contractor expense, and travel expense, partially offset by an increase in restructuring expenses.

[0001564590-19-005179:mdna:76]
Research and development expenses as a percentage of sales increased from 19.6% for the year ended December 31, 2017 to 23.5% for the year ended December 31, 2018. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenues for the periods being compared.

[0001564590-19-005179:mdna:77]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product and market opportunities and engage in significant research and development efforts which provide for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001564590-19-005179:mdna:78]
Interest and Dividend Income

[0001564590-19-005179:mdna:79]
Interest and dividend income decreased by 8.1% from $4.4 million for the year ended December 31, 2017 to $4.0 million for the year ended December 31, 2018. The decrease in interest and dividend income is primarily attributable to fluctuations in investment balances.

[0001564590-19-005179:mdna:80]
Interest Expense

[0001564590-19-005179:mdna:81]
Interest expense, which is primarily related to our taxable revenue bond, decreased by 4.1% from $0.6 million for the year ended December 31, 2017 to $0.5 million for the year ended December 31, 2018 as a result of a principal payment made on our taxable revenue bond during the year ended December 31, 2018. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001564590-19-005179:mdna:82]
Net Investment Gain (Loss)

[0001564590-19-005179:mdna:83]
Net investment gain (loss) reversed from a gain of $4.7 million for the year ended December 31, 2017 to a loss of $4.0 million for the year ended December 31, 2018. The decrease is primarily attributable to changes in fair value on equity securities recognized during the period under ASC 2016-01. Prior to January 1, 2018, changes in fair value were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet. With the adoption of ASC 2016-01 in January 2018, unrealized gains or losses are now recognized in other income in the period they are incurred. The loss in 2018 is a result of unrealized losses in our professionally-managed equity investment portfolios resulting from extreme equity market volatility in the fourth quarter of 2018. We expect that any future equity market volatility will result in continued volatility in gains or losses from our equity investment portfolios. See “Investing Activities” in “Liquidity and Capital Resources” and Note 1 and Note 5 of Notes to Consolidated Financial Statements included in Item 8 of this report for additional information.

[0001564590-19-005179:mdna:84]
Other Income (Expense), net

[0001564590-19-005179:mdna:85]
Other income (expense), net, which is comprised primarily of gains and losses on foreign currency transactions, gains and losses on foreign exchange forward contracts, investment account management fees, and miscellaneous income and expense, increased 206.5% from expense of $1.2 million for the year ended December 31, 2017 to income of $1.3 million for the year ended December 31, 2018. The change is primarily attributable to losses on foreign exchange contracts and transactions in 2017 as compared to foreign exchange gains in 2018.

[0001564590-19-005179:mdna:86]
Gain on Bargain Purchase of a Business

[0001564590-19-005179:mdna:87]
Gain on bargain purchase of a business is related to our acquisition of Sumitomo Electric Lightwave Corp.’s North American EPON business and entry into a technology license and supply agreement with Sumitomo Electric Industries, Ltd. on March 19, 2018. See Note 2 of Notes to Consolidated Financial Statements included in Item 8 of this report for additional information.

[0001564590-19-005179:mdna:88]
(Provision) Benefit for Income Taxes

[0001564590-19-005179:mdna:89]
Our effective tax rate decreased from an expense of 46.7% for the year ended December 31, 2017 to a benefit of 42.0%, excluding the tax effect of the bargain purchase gain, for the year ended December 31, 2018. The decrease in the effective tax rate between the two periods was primarily driven by the current year losses in our domestic business and the expense recognized in 2017 related to the effect of the U.S. Tax Cuts and Jobs Act, which was signed into law on December 22, 2017. As a result of the 2017 tax law change, an expense of $11.9 million was recorded in the fourth quarter of 2017, of which $9.2 million related to the write-down of deferred tax assets and $2.7 million related to tax on unrepatriated foreign earnings. Additional work to complete a more detailed analysis of historical foreign earnings, as well as the full impact to the write-down of deferred tax assets, was completed in the third quarter of 2018 and resulted in a tax benefit of $4.0 million. See Note 12 of Notes to Consolidated Financial Statements included in Item 8 of this report for additional information.

[0001564590-19-005179:mdna:90]
Net Income (Loss)

[0001564590-19-005179:mdna:91]
As a result of the above factors, net income (loss) decreased from income of $23.8 million for the year ended December 31, 2017 to a loss of $(19.3) million for the year ended December 31, 2018. As a percentage of sales, net income (loss) decreased from 3.6% for the year ended December 31, 2017 to (3.7%) for the year ended December 31, 2018.

[0001564590-19-005179:mdna:92]
2017 Compared to 2016

[0001564590-19-005179:mdna:93]
Sales

[0001564590-19-005179:mdna:94]
Our sales increased by 4.7% from $636.8 million in 2016 to $666.9 million in 2017. The increase in sales occurred over both our Network Solutions and our Services & Support reporting segments. Our Network Solutions sales increased $14.9 million in 2017, and our Services & Support sales increased $15.2 million compared to the prior year.

[0001564590-19-005179:mdna:95]
Network Solutions sales increased by 2.8% from $525.5 million in 2016 to $540.4 million in 2017. The increase in sales in 2017 is primarily attributable to an increase in sales of our Access & Aggregation products, partially offset by a decrease in sales of our Traditional & Other products. The increase in sales of our Access & Aggregation products is primarily attributable to increased VDSL2 vectoring product sales in the U.S. and European carrier markets. While we expect that revenues from Traditional & Other products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-19-005179:mdna:96]
Services & Support sales increased by 13.7% from $111.3 million in 2016 to $126.5 million in 2017. The increase in sales in 2017 is primarily attributable to an increase in network installation services for Access & Aggregation products.

[0001564590-19-005179:mdna:97]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, increased 17.2% from $135.4 million in 2016 to $158.7 million in 2017. International sales, as a percentage of total sales, increased from 21.3% in 2016 to 23.8% in 2017. The increase in international sales in 2017 is primarily attributable to an increase in sales in EMEA, partially offset by a decrease in sales in Latin America and the APAC region.

[0001564590-19-005179:mdna:98]
Cost of Sales

[0001564590-19-005179:mdna:99]
As a percentage of sales, cost of sales increased from 54.2% in 2016 to 54.5% in 2017. The increase is primarily attributable to a regional revenue shift, customer and product mix and services and support mix.

[0001564590-19-005179:mdna:100]
Network Solutions cost of sales, as a percent of that segment’s sales, increased from 51.5% of sales in 2016 to 51.7% of sales in 2017. The increase in Network Solutions cost of sales as a percentage of that segment’s sales is primarily attributable to customer and product mix.

[0001564590-19-005179:mdna:101]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-19-005179:mdna:102]
Services & Support cost of sales, as a percent of that segment’s sales, decreased from 67.2% of sales in 2016 to 66.2% of sales in 2017. The decrease in Services & Support cost of sales as a percentage of that segment’s sales is primarily attributable to the mix of network installation programs and support.

[0001564590-19-005179:mdna:103]
Selling, General and Administrative Expenses

[0001564590-19-005179:mdna:104]
Selling, general and administrative expenses increased 2.8% from $131.8 million in 2016 to $135.6 million in 2017. Selling, general and administrative expenses include personnel costs for administration, finance, information technology, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material, trade show expenses, and related travel costs. The increase in selling, general and administrative expenses is primarily attributable to increases in ERP implementation expense, deferred compensation expense, travel expense, and stock-based compensation expense, partially offset by a decrease in performance-based compensation expense.

[0001564590-19-005179:mdna:105]
Selling, general and administrative expenses as a percentage of sales decreased from 20.7% for the year ended December 31, 2016 to 20.3% for the year ended December 31, 2017. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-19-005179:mdna:106]
Research and Development Expenses

[0001564590-19-005179:mdna:107]
Research and development expenses increased 4.6% from $124.9 million in 2016 to $130.7 million in 2017. The increase in research and development expenses is primarily attributable to an increase in labor and engineering materials related to customer specific projects, contract services and amortization of intangibles acquired in the third quarter of 2016.

[0001564590-19-005179:mdna:108]
Research and development expenses as a percentage of sales remained constant at 19.6% for the years ended December 31, 2016 and 2017. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenues for the periods being compared.

[0001564590-19-005179:mdna:109]
Interest and Dividend Income

[0001564590-19-005179:mdna:110]
Interest and dividend income increased by 11.8% from $3.9 million in 2016 to $4.4 million in 2017. The increase in interest and dividend income is primarily attributable to an increase in the rate of return on investments.

[0001564590-19-005179:mdna:111]
Interest Expense

[0001564590-19-005179:mdna:112]
Interest expense, which is primarily related to our taxable revenue bond, remained consistent at $0.6 million in 2016 and 2017, as we had no substantial change in our fixed-rate borrowing. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001564590-19-005179:mdna:113]
Net Investment Gain

[0001564590-19-005179:mdna:114]
Net investment gain decreased by 20.9% from $5.9 million in 2016 to $4.7 million in 2017. The decrease in realized investment gains is primarily attributable to decreased gains from the sale of equity securities. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-19-005179:mdna:115]
Other Income (Expense), net

[0001564590-19-005179:mdna:116]
Other income (expense), net, comprised primarily of miscellaneous income and expense, gains and losses on foreign currency transactions, gains and losses on foreign exchange forward contracts, investment account management fees, and scrap raw material sales, increased 147.0% from $0.5 million of expense in 2016 to $1.2 million of expense in 2017. The change is primarily attributable to increased losses on our foreign exchange contracts.

[0001564590-19-005179:mdna:117]
Gain on Bargain Purchase of a Business

[0001564590-19-005179:mdna:118]
Gain on bargain purchase of a business in 2016 is related to our acquisition of key fiber access products, technologies and service relationships from subsidiaries of CommScope, Inc. on September 13, 2016. See Note 2 of Notes to Consolidated Financial Statements included in Item 8 of this report for additional information.

[0001564590-19-005179:mdna:119]
Provision for Income Taxes

[0001564590-19-005179:mdna:120]
Our effective tax rate increased from 24.9% in 2016 to 46.7% in 2017. The increase in the effective tax rate between the two periods is primarily attributable to the Tax Cuts and Jobs Act, which was signed into law on December 22, 2017. As a result of the new law, we recognized an estimated expense of $11.9 million in the fourth quarter of 2017, of which $9.2 million related to the write-down of deferred tax assets and $2.7 million related to tax on unrepatriated foreign earnings. See Note 12 of Notes to Consolidated Financial Statements included in Item 8 of this report for additional information.

[0001564590-19-005179:mdna:121]
Net Income

[0001564590-19-005179:mdna:122]
As a result of the above factors, net income decreased from $35.2 million in 2016 to $23.8 million in 2017. As a percentage of sales, net income decreased from 5.5% in 2016 to 3.6% in 2017.

[0001564590-19-005179:mdna:123]
Liquidity and Capital Resources

[0001564590-19-005179:mdna:124]
Liquidity

[0001564590-19-005179:mdna:125]
We currently expect to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including product development activities to enhance our existing products and develop new products and expansion of our sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-19-005179:mdna:126]
At December 31, 2018, cash on hand was $105.5 million and short-term investments were $3.2 million, which resulted in available short-term liquidity of $108.7 million, of which $87.1 million was held by our foreign subsidiaries. At December 31, 2017, cash on hand was $86.4 million and short-term investments were $16.1 million, which resulted in available short-term liquidity of $102.6 million, of which $56.8 million was held by our foreign subsidiaries. The increase in short-term liquidity from December 31, 2017 to December 31, 2018 is primarily attributable to cash held by certain foreign subsidiaries, at least some of which we expect to repatriate as tax and regulatory considerations may allow.

[0001564590-19-005179:mdna:127]
Operating Activities

[0001564590-19-005179:mdna:128]
Our working capital, which consists of current assets less current liabilities, decreased 22.5% from $306.3 million as of December 31, 2017 to $237.4 million as of December 31, 2018. The current ratio, defined as current assets divided by current liabilities, decreased from 3.87 as of December 31, 2017 to 3.01 as of December 31, 2018. The decrease in our working capital and current ratio is primarily attributable to a decrease in net accounts receivable, inventory, and short term investments as well as an increase in income tax payable. The quick ratio, defined as cash and cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.31 as of December 31, 2017 to 1.76 as of December 31, 2018. The decrease in the quick ratio is primarily attributable to a decrease in net accounts receivable and short term investments with an increase in income taxes payable.  This decrease was slightly offset by an increase in cash and cash equivalents.

[0001564590-19-005179:mdna:129]
Net accounts receivable decreased 31.1% from $144.2 million at December 31, 2017 to $99.4 million at December 31, 2018. Our allowance for doubtful accounts was $0.1 million at December 31, 2018.  We did not have an allowance for doubtful accounts at December 31, 2017. Quarterly accounts receivable DSO decreased from 105 days as of December 31, 2017 to 65 days as of December 31, 2018. The decrease in net accounts receivable and DSO is attributable to customer specific payment terms agreed upon in 2017 that became due in the first quarter of 2018 and the timing of sales and other collections during the quarter.

[0001564590-19-005179:mdna:130]
Other receivables increased 38.1% from $26.6 million at December 31, 2017 to $36.7 million at December 31, 2018. The increase in other receivables is primarily attributable to an increase in contract assets, purchasing shipments, investment loan receivable and income tax receivables.

[0001564590-19-005179:mdna:131]
On February 25, 2019, one the Company’s customers filed for voluntary Chapter 11 bankruptcy as a result of a court ruling resulting in a substantial legal judgment against the customer. In 2018, this customer accounted for less than 5% of the Company’s revenue. As of December 31, 2018, the Company had $2.6 million related to product and services revenue and $0.3 million related to a leased equipment arrangement included in accounts receivable on the Consolidated Balance Sheet that was due from this customer. As of December 31, 2018, the Company had $9.4 million included in other receivables related to a leased equipment arrangement on its Consolidated Balance Sheet that was due from this customer. Since December 31, 2018, and through the date of this filing, all $2.6 million of the outstanding products and services accounts receivable and $0.1 million of the outstanding accounts receivable related to leased equipment have been collected. Additionally, $1.7 million of the outstanding other receivables related to leased equipment have been collected. Therefore, there is potential risk of uncollectibility up to $7.8 million on the remaining outstanding receivable balances as of December 31 2018. The Company has evaluated the collectibility of the remaining receivable balances with the best available and applicable information as of the date of this filing and the impact was not material to the consolidated financial statements as of December 31, 2018. The Company will continue to evaluate the collectibility of the remaining accounts receivable balances in subsequent reporting periods. Additionally, it is uncertain at this time the impact this voluntary bankruptcy filing might have on the Company’s operating income prospectively; however, the Company believes it will not have a significant impact on the Company’s liquidity and capital resources.

[0001564590-19-005179:mdna:132]
Annual inventory turnover decreased from 3.19 turns as of December 31, 2017 to 2.93 turns as of December 31, 2018. Inventory decreased 18.5% from $122.5 million at December 31, 2017 to $99.8 million at December 31, 2018. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-19-005179:mdna:133]
Accounts payable increased 0.7% from $60.6 million at December 31, 2017 to $61.1 million at December 31, 2018. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-19-005179:mdna:134]
Investing Activities

[0001564590-19-005179:mdna:135]
Capital expenditures totaled approximately $8.1 million, $14.7 million and $21.4 million for the years ended December 31, 2018, 2017 and 2016, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-19-005179:mdna:136]
Our combined short-term and long-term investments decreased $34.3 million from $146.4 million at December 31, 2017 to $112.1 million at December 31, 2018. This decrease reflects the impact of our cash used for business acquisitions, share repurchases, shareholder dividends, property, plant and equipment purchases, as well as net realized losses on these investments.

[0001564590-19-005179:mdna:137]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At December 31, 2018, these investments included corporate bonds of $20.7 million, municipal fixed-rate bonds of $1.3 million, asset-backed bonds of $5.2 million, mortgage/agency-backed bonds of $3.8 million, U.S. government bonds of $9.2 million, and foreign government bonds of $0.6 million. At December 31, 2017, these investments included corporate bonds of $32.5 million, municipal fixed-rate bonds of $2.9 million, asset-backed bonds of $6.5 million, mortgage/agency-backed bonds of $5.5 million, U.S. government bonds of $14.3 million and foreign government bonds of $0.7 million. As of December 31, 2018, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds were classified as available-for-sale and had a combined duration of 1.55 years with an average credit rating of A+. Because our bond portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-19-005179:mdna:138]
Our long-term investments decreased 16.5% from $130.3 million at December 31, 2017 to $108.8 million at December 31, 2018. Long-term investments at December 31, 2018 and December 31, 2017 included investments in various marketable equity securities classified as long-term investments with a fair market value of $27.0 million and $35.7 million, at December 31, 2018 and December 31, 2017, respectively. Our long-term investments also included an investment in a certificate of deposit of $25.6 million and $27.8 million, respectively, which serves as collateral for our revenue bond, as discussed below.

[0001564590-19-005179:mdna:139]
Long-term investments at December 31, 2018 and 2017 also included $18.3 million and $19.9 million, respectively, related to our deferred compensation plan, and $0.4 million and $0.5 million, respectively, of other investments, consisting of interests in two private equity funds.

[0001564590-19-005179:mdna:140]
Acquisition of businesses, net of cash acquired, totaled $22.0 million, zero and $0.9 million for the years ended December 31, 2018, 2017 and 2016, respectively. See Note 2 of Notes to Consolidated Financial Statements included in Item 8 of this report for additional information.

[0001564590-19-005179:mdna:141]
Financing Activities

[0001564590-19-005179:mdna:142]
In conjunction with the 1995 expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the Authority). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN. The bonds were originally purchased by AmSouth Bank of Alabama (now Regions Bank of Alabama) (the Bank). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the Bondholder), which was acquired by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond (Amended and Restated Bond) was issued and the original financing agreement was amended. The Amended and Restated Bond bears interest, payable monthly. The interest rate is 2% per annum. The Amended and Restated Bond matures on January 1, 2020, and is currently outstanding in the aggregate principal amount of $25.6 million. The estimated fair value of the bond using a level 2 valuation technique at December 31, 2018 was approximately $25.4 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. We are required to make payments to the Authority in amounts necessary to pay the interest on the Amended and Restated Bond. Included in long-term investments at December 31, 2018 is $25.6 million which is invested in a restricted certificate of deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the balance of the Amended and Restated Bond with the collateral deposit in order to reduce the balance of the indebtedness.

[0001564590-19-005179:mdna:143]
In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we are required to remit to the state for those employment positions that qualify under the program. We realized economic incentives related to payroll withholdings totaling $1.4 million, $1.5 million and $1.3 million for the years ended December 31, 2018, 2017 and 2016.

[0001564590-19-005179:mdna:144]
We made principal payments of $1.1 million for each of the years ended December 31, 2018 and 2017, and we anticipate making a principal payment in 2019. At December 31, 2018 and 2017, $1.0 million and $1.1 million, respectively of the bond debt was classified as a current liability in accounts payable in the Consolidated Balance Sheets included in Item 8 of this report.

[0001564590-19-005179:mdna:145]
Dividends

[0001564590-19-005179:mdna:146]
During 2018, 2017 and 2016, we paid shareholder dividends totaling $17.3 million, $17.4 million and $17.6 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained. The following table shows dividends per common share paid to our shareholders in each quarter of 2018, 2017 and 2016.

[0001564590-19-005179:mdna:147]
| Dividends per Common Share |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001564590-19-005179:mdna:148]
Stock Repurchase Program

[0001564590-19-005179:mdna:149]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. For the years 2018, 2017 and 2016, we repurchased 1.0 million shares, 0.9 million shares and 1.4 million shares, respectively, for a cost of $15.5 million, $17.3 million and $25.8 million, respectively, at an average price of $15.52, $20.27 and $18.29 per share, respectively. We currently have authorization to repurchase an additional 2.6 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-19-005179:mdna:150]
Stock Option Exercises

[0001564590-19-005179:mdna:151]
To accommodate employee stock option exercises, we issued 0.1 million shares of treasury stock for $1.5 million during the year ended December 31, 2018, 0.7 million shares of treasury stock for $13.4 million during the year ended December 31, 2017, and 0.3 million shares of treasury stock for $4.7 million during the year ended December 31, 2016.

[0001564590-19-005179:mdna:152]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001564590-19-005179:mdna:153]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0001564590-19-005179:mdna:154]
We have various contractual obligations and commercial commitments. The following table sets forth, in millions, the annual payments we are required to make under contractual cash obligations and other commercial commitments at December 31, 2018.

[0001564590-19-005179:mdna:155]
Contractual Obligations

[0001564590-19-005179:mdna:156]
| (In millions) |  | Total |  |  | 2019 |  |  | 2020 |  |  | 2021 |  |  | 2022 |  |  | 2023 |  |  | After 2023 |  |
| Short-term and long-term debt |  | $ | 25.6 |  |  | $ | — |  |  | $ | 25.6 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest on short-term and long-term debt |  |  | 0.5 |  |  |  | 0.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 127.1 |  |  |  | 126.1 |  |  |  | 0.9 |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Operating lease obligations |  |  | 14.4 |  |  |  | 3.9 |  |  |  | 3.6 |  |  |  | 2.8 |  |  |  | 2.0 |  |  |  | 1.3 |  |  |  | 0.8 |  |
| Totals |  | $ | 167.6 |  |  | $ | 130.5 |  |  | $ | 30.1 |  |  | $ | 2.9 |  |  | $ | 2.0 |  |  | $ | 1.3 |  |  | $ | 0.8 |  |

[0001564590-19-005179:mdna:157]
We are required to make payments necessary to pay the interest on the Amended and Restated Bond, currently outstanding in the aggregate principal amount of $25.6 million. The bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. Included in long-term investments are $25.6 million of restricted funds, which is a collateral deposit against the principal amount of this bond. We made principal payments of $1.1 million for each of the years ended December 31, 2018 and 2017. We anticipate making a principal payment in 2019. At December 31, 2018 and 2017, $1.0 million and $1.1 million, respectively of the bond debt was classified as a current liability in accounts payable in the Consolidated Balance Sheets included in Item 8 of this report. See Note 11 of Notes to Consolidated Financial Statements included in Item 8 of this report for additional information.

[0001564590-19-005179:mdna:158]
Purchase obligations primarily relate to open purchase orders to our contract manufacturers, component suppliers, service partners, and other vendors.

[0001564590-19-005179:mdna:159]
Operating lease obligations primarily relate to future minimum rental payments under non-cancelable operating leases, including renewals determined to be reasonably assured, with original maturities of greater than 12 months.

[0001564590-19-005179:mdna:160]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of December 31, 2018, of which $7.7 million has been applied to these commitments. The additional $0.2 million commitment has been excluded from the table above due to the uncertainty of when it will be applied.

[0001564590-19-005179:mdna:161]
We also have obligations related to uncertain income tax positions that have been excluded from the table above due to the uncertainty of when the related expense will be recognized. See Note 12 of Notes to Consolidated Financial Statements included in Item 8 of this report for additional information.

[0001564590-19-005179:mdna:162]
Recently Issued Accounting Pronouncements

[0001564590-19-005179:mdna:163]
For a discussion of recently issued accounting pronouncements, see Note 1 of Notes to Consolidated Financial Statements included in Item 8 of this report for additional information.

[0001564590-19-005179:mdna:164]
Critical Accounting Policies and Estimates

[0001564590-19-005179:mdna:165]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. These policies have been consistently applied across our two reportable segments: (1) Network Solutions and (2) Services & Support.

[0001564590-19-005179:mdna:166]
Revenue Recognition

[0001564590-19-005179:mdna:167]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product or service to the customer. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. The stand-alone selling prices are determined based on the prices at which we sell the separate products and services and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0001564590-19-005179:mdna:168]
The following is a description of the principal activities from which we generate our revenue by reportable segment.

[0001564590-19-005179:mdna:169]
Network Solutions Segment

[0001564590-19-005179:mdna:170]
Network Solutions includes software and hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales.

[0001564590-19-005179:mdna:171]
Hardware and Software Revenue

[0001564590-19-005179:mdna:172]
Revenue from hardware sales is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. This segment also includes revenues from software license sales which is recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

[0001564590-19-005179:mdna:173]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term. In relation to these lease agreements, during the years ended December 31, 2018, 2017 and 2016 we recognized revenue of $13.7 million, $16.5 million and $2.7 million, respectively.

[0001564590-19-005179:mdna:174]
Services & Support Segment

[0001564590-19-005179:mdna:175]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, and solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-19-005179:mdna:176]
Maintenance Revenue

[0001564590-19-005179:mdna:177]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue as our customers benefit evenly throughout the contract term and deferred revenues are recorded in current and non-current unearned revenue.

[0001564590-19-005179:mdna:178]
Network Implementation Revenue

[0001564590-19-005179:mdna:179]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services, at a point in time when each performance obligation is complete. If we have recognized revenue, but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables in the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0001564590-19-005179:mdna:180]
Inventory

[0001564590-19-005179:mdna:181]
We carry our inventory at the lower of cost and net realizable value, with cost being determined using the first-in, first-out method. We use standard costs for material, labor, and manufacturing overhead to value our inventory. Our standard costs are updated on at least a quarterly basis and any variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We write down our inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated fair value based upon assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $30.0 million and $23.4 million at December 31, 2018 and 2017, respectively. Inventory disposals charged against the reserve were $0.4 million, $8.3 million and $4.7 million for the years ended December 31, 2018, 2017 and 2016, respectively.

[0001564590-19-005179:mdna:182]
Stock-Based Compensation

[0001564590-19-005179:mdna:183]
For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable, single measure of the fair value of our stock option awards. For purposes of determining the estimated fair value of our market-based performance stock unit (PSU) awards on the date of grant, we use a Monte Carlo Simulation valuation method. These PSUs are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of performance-based PSUs, restricted stock units (RSUs) and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. Compensation expense related to unvested performance-based PSUs will be recognized over the requisite service period of three years as the achievement of the performance obligation becomes probable. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period.

[0001564590-19-005179:mdna:184]
Business Combinations

[0001564590-19-005179:mdna:185]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying condensed consolidated statements of operations since their dates of acquisition. Costs incurred to complete the business combination, such as legal, accounting, or other professional fees, are charged to general and administrative expenses as they are incurred.

[0001564590-19-005179:mdna:186]
Goodwill

[0001564590-19-005179:mdna:187]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2018, we concluded that it was not necessary to perform the two-step impairment test. There were no impairment losses on goodwill recognized during the years ended December 31, 2018, 2017 and 2016.

[0001564590-19-005179:mdna:188]
44

[0001564590-19-005179:mdna:189]
Income Taxes

[0001564590-19-005179:mdna:190]
We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets, and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. At December 31, 2018 and 2017, the Company had federal and state net operating loss carryforwards of $16.1 million and $2.8 million, respectively. These carryforwards are the result of acquisitions in 2011 and 2018 and domestic operating losses in 2018.  A valuation allowance of $0.1 million has been established against these losses as losses in a particular state may not be recognized.  At December 31, 2018 and 2017, the Company had state tax credit carryforwards of $3.7 million, which expire between 2019 and 2030.  A valuation allowance of $3.3 million and $3.4, million, respectively, has been established against these credits.  These state credits were generated primarily in a particular state where we no longer generate sufficient state income.  In addition, at December 31, 2018 and 2017, the Company had foreign loss carryforwards of $3.1 million.  A majority of these loss carryforwards are the result of an acquisition in 2009.  A valuation allowance of $2.4 million and $2.5 million, respectively, has been established against the net operating losses in a foreign jurisdiction where the Company has limited business.  We believe it is more likely than not that we will not realize the full benefits of some of our deferred tax assets, and accordingly, we have provided a valuation allowance against that piece.

[0001564590-19-005179:mdna:191]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain.  We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001564590-19-005179:mdna:192]
Liability for Warranty

[0001564590-19-005179:mdna:193]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our historical return rate and an estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.6 million and $9.7 million at December 31, 2018 and 2017, respectively. These liabilities are included in accrued expenses in the accompanying consolidated balance sheets.

[0001564590-19-005179:mdna:194]
Pension Benefit Obligations

[0001564590-19-005179:mdna:195]
Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $13.1 million and $8.3 million at December 31, 2018 and 2017, respectively. This liability is included in other non-current liabilities in the accompanying consolidated balance sheets.

[0001564590-19-005179:mdna:196]
Subsequent Events

[0001564590-19-005179:mdna:197]
On January 23, 2019, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on February 7, 2019. The quarterly dividend payment was $4.3 million and was paid on February 21, 2019. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-19-005179:mdna:198]
During the first quarter and as of February 26, 2019, we have repurchased 13,000 shares of our common stock through open market purchases at an average cost of $14.06 per share. We currently have the authority to purchase an additional 2.5 million shares of our common stock under the current plan approved by the Board of Directors.

[0001564590-19-005179:mdna:199]
In February 2019, $1.0 million of an outstanding investment loan due to ADTRAN was replaced with a secured loan in that amount. The remaining balance of this investment loan was converted to participating preferred shares of the respective company.

[0001564590-19-005179:mdna:200]
In February 2019, we announced the restructuring of our workforce in Germany, which includes the closure of the office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees and a voluntary early retirement offering to certain other employees. The restructuring is expected to be completed in the fourth quarter of 2019. ADTRAN does not have sufficient information currently on which to estimate the liability associated with this restructuring, including costs associated with employee severance and relocation.

[0001564590-19-005179:mdna:201]
On February 25, 2019, one the Company’s customers filed for voluntary Chapter 11 bankruptcy as a result of a court ruling resulting in a substantial legal judgment against the customer. In 2018, this customer accounted for less than 5% of the Company’s revenue. As of December 31, 2018, the Company had $2.6 million related to product and services revenue and $0.3 million related to a leased equipment arrangement included in accounts receivable on the Consolidated Balance Sheet that was due from this customer. As of December 31, 2018, the Company had $9.4 million included in other receivables related to a leased equipment arrangement on its Consolidated Balance Sheet that was due from this customer. Since December 31, 2018, and through the date of this filing, all $2.6 million of the outstanding products and services accounts receivable and $0.1 million of the outstanding accounts receivable related to leased equipment have been collected. Additionally, $1.7 million of the outstanding other receivables related to leased equipment have been collected. Therefore, there is potential risk of uncollectibility up to $7.8 million on the remaining outstanding receivable balances as of December 31, 2018. The Company has evaluated the collectibility of the remaining receivable balances with the best available and applicable information as of the date of this filing and the impact was not material to the consolidated financial statements as of December 31, 2018. The Company will continue to evaluate the collectibility of the remaining accounts receivable balances in subsequent reporting periods. Additionally, it is uncertain at this time the impact this voluntary bankruptcy filing might have on the Company’s operating income prospectively; however, the Company believes it will not have a significant impact on the Company’s liquidity and capital resources.

[0001564590-19-005179:mdna:202]
46
