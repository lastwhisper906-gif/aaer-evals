# ADTN MD&A — 0001564590-19-035143


## mdna

[0001564590-19-035143:mdna:1]
[same as prior period, unchanged from 0001564590-19-016264:mdna:1]

[0001564590-19-035143:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and the related notes that appear in Part I, Item 1 of this document.  In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2018, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1, Business, and Item 1A, Risk Factors, included in our Annual Report on Form 10-K for the year ended December 31, 2018 filed with the Securities and Exchange Commission (the “SEC”) on February 28, 2019 (the “2018 Form 10-K”).

[0001564590-19-035143:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our condensed consolidated financial statements.  See “Cautionary Note Regarding Forward-Looking Statements” on page 2 of this report for a description of important factors that could cause actual results to differ from expected results.  See also Item 1A, Risk Factors, of the 2018 Form 10‑K.

[0001564590-19-035143:mdna:4]
[same as prior period, unchanged from 0001564590-19-016264:mdna:3]

[0001564590-19-035143:mdna:5]
ADTRAN is a leading global provider of networking and communications equipment, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, Cable/MSOs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. In order to service our customers and build revenue, we are constantly conducting research and development (“R&D”) of new products addressing customer needs and testing those products for the particular specifications of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have R&D facilities in strategic global locations.

[0001564590-19-035143:mdna:6]
An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek to be a high-quality, and in most instances the low-cost, provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001564590-19-035143:mdna:7]
The Company made two acquisitions in 2018, strengthening its position in both the Cable/MSO and connected home markets. In the first quarter of 2018, we acquired Sumitomo Electric Lightwave Corp.’s (“SEL”) North American EPON business and certain assets for North America and entered into a technology license and OEM supply agreement with Sumitomo Electric Industries, Ltd. (“SEI”). These solutions, combined with our organic fiber access product portfolio and our distributed access expertise, present new opportunities in the Cable/MSO market. Also, in the fourth quarter of 2018, we acquired U.S.-based SmartRG, an industry-leading provider of carrier-class, connected-home software platforms and cloud services for broadband service providers. With this acquisition, ADTRAN now offers a complete cloud-to-consumer portfolio of virtualized management, data analytics, Wi-Fi-enabled residential gateways and software platforms.

[0001564590-19-035143:mdna:8]
We review our financial performance, specifically revenue and gross profit, based on two reportable segments – Network Solutions and Services & Support. Network Solutions software and hardware products provide solutions supporting fiber-, copper- and coaxial-based infrastructures and a growing number of wireless solutions, lowering the overall cost to deploy advanced services across a wide range of applications for Carrier, Cable/MSO networks and business networks, as well as for prior-generation products. Services & Support enables our customers to accelerate time to market, reduce costs and improve customer satisfaction through a complete portfolio of services, including maintenance, turnkey network implementation, solutions integration, and managed services. ADTRAN’s comprehensive network implementation services include engineering design and documentation (pre-construction), construction and installation (construction), and test, turn-up and provisioning (post-construction). Additionally, we partner with customers to tailor a program to each specific service-delivery need.

[0001564590-19-035143:mdna:9]
[same as prior period, unchanged from 0001564590-19-016264:mdna:10]

[0001564590-19-035143:mdna:10]
|  | • | Access & Aggregation solutions are used by service providers to connect their network infrastructure to their subscribers. This category includes software- and hardware-based products and services that aggregate and/or originate access technologies. The portfolio of ADTRAN solutions within this category includes a wide array of modular or fixed physical form factors designed to deliver the best technology and economic fit based on the target subscriber density and environmental conditions. |

[0001564590-19-035143:mdna:11]
|  | • | Subscriber Solutions & Experience (formerly Customer Devices) includes open connected home platforms, cloud services and any of our solutions and services that deliver residential and/or enterprise subscribers an immersive and interactive broadband experience from the service provider’s access network. These products, software and services include SmartRG solutions and applications, NetVanta Enterprise IP business gateways, access routers, Ethernet switches, ProCloud service offerings, residential and enterprise operating systems (such as SmartOS and AOS), Bluesocket Wi-Fi portfolio, service provider and Cable/MSO Optical Network Terminals (ONTs), as well as related software applications and services. In alignment with our increased focus on enhancing customer experience for both business and consumer broadband customers as well as the addition of SmartRG during 2018, Customer Devices is now known as Subscriber Solutions & Experience, as this more accurately represents this revenue category and our vision moving forward. |

[0001564590-19-035143:mdna:12]
|  | • | Traditional & Other Products generally includes a mix of prior generation technologies’ products and services, as well as other products and services that do not fit within the Access & Aggregation or Subscriber Solutions & Experience categories. |

[0001564590-19-035143:mdna:13]
See Note 14 of Notes to Consolidated Financial Statements in Part I, Item 1 of this report for further information regarding these segments and revenue categories.

[0001564590-19-035143:mdna:14]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future periods, due to a number of factors, including customer order activity and purchase order backlog. Although the timing of our product deliveries in response to customer orders results in very little purchase order backlog. Such backlog levels vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. In the second quarter of 2019, we had three 10% of revenue customers geographically diversified in Latin America (“LATAM”), Europe, and the U.S. For the third and fourth quarter of 2019, our current expectations include the effect of a temporary slowdown in capital spending in one of these regions for access at a Tier-1 European carrier customer for the remainder of 2019, however the full effect of this slowdown has not yet been determined. We believe that normal spending should resume at the beginning of 2020. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenue could significantly impact our financial results in a given quarter.

[0001564590-19-035143:mdna:15]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, changes related to domestic and international tariffs, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter.

[0001564590-19-035143:mdna:16]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Part I, Item 1A of the 2018 Form 10-K and in Part II, Item 1A of this Form 10-Q.

[0001564590-19-035143:mdna:17]
34

[0001564590-19-035143:mdna:18]
[same as prior period, unchanged from 0001564590-19-016264:mdna:18]

[0001564590-19-035143:mdna:19]
There have been no material changes to our critical accounting policies and estimates from those disclosed in in our 2018 Form 10-K/A, other than as described in the below.

[0001564590-19-035143:mdna:20]
During the three months ended June 30, 2019, the Company changed the manner in which it estimates its excess and obsolete inventory reserves. Under the new policy, we establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on historical usage, known trends, inventory age, and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 8 of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this report for additional information.

[0001564590-19-035143:mdna:21]
[same as prior period, unchanged from 0001564590-19-016264:mdna:20]

[0001564590-19-035143:mdna:22]
See Note 1 of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this report for a full description of recent accounting pronouncements, including the expected dates of adoption and estimated effects on results of operations and financial condition, which is incorporated herein by reference.

[0001564590-19-035143:mdna:23]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2019 COMPARED TO THREE AND SIX MONTHS ENDED JUNE 30, 2018

[0001564590-19-035143:mdna:24]
The following table presents selected financial information derived from our Condensed Consolidated Statements of Income expressed as a percentage of sales for the periods indicated. Amounts may not foot due to rounding.

[0001564590-19-035143:mdna:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 89.0 |  | % |  | 89.9 |  | % |  | 88.3 |  | % |  | 88.5 |  | % |
| Services & Support |  |  | 11.0 |  |  |  | 10.1 |  |  |  | 11.7 |  |  |  | 11.5 |  |  |
| Total Sales |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 51.3 |  |  |  | 54.4 |  |  |  | 50.3 |  |  |  | 55.6 |  |  |
| Services & Support |  |  | 7.2 |  |  |  | 6.6 |  |  |  | 7.9 |  |  |  | 8.4 |  |  |
| Total Cost of Sales |  |  | 58.4 |  |  |  | 61.0 |  |  |  | 58.1 |  |  |  | 63.9 |  |  |
| Gross Profit |  |  | 41.6 |  |  |  | 39.0 |  |  |  | 41.9 |  |  |  | 36.1 |  |  |
| Selling, general and administrative expenses |  |  | 21.5 |  |  |  | 25.1 |  |  |  | 22.9 |  |  |  | 26.4 |  |  |
| Research and development expenses |  |  | 20.5 |  |  |  | 24.0 |  |  |  | 21.2 |  |  |  | 25.5 |  |  |
| Gain on contingency |  |  | (0.8 | ) |  |  | — |  |  |  | (0.4 | ) |  |  | — |  |  |
| Operating Income (Loss) |  |  | 0.4 |  |  |  | (10.0 | ) |  |  | (1.9 | ) |  |  | (15.9 | ) |  |
| Interest and dividend income |  |  | 0.4 |  |  |  | 0.7 |  |  |  | 0.4 |  |  |  | 0.7 |  |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |  |
| Net investment gain |  |  | 1.6 |  |  |  | 0.8 |  |  |  | 2.8 |  |  |  | 0.4 |  |  |
| Other income (expense), net |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | 0.2 |  |  |  | (0.1 | ) |  |
| Gain on bargain purchase of a business, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4.5 |  |  |
| Income (Loss) Before Benefit for Income Taxes |  |  | 2.2 |  |  |  | (8.8 | ) |  |  | 1.5 |  |  |  | (10.4 | ) |  |
| Benefit for income taxes |  |  | 0.4 |  |  |  | 2.8 |  |  |  | 0.1 |  |  |  | 3.0 |  |  |
| Net Income (Loss) |  |  | 2.6 |  | % |  | (6.0 | ) | % |  | 1.6 |  | % |  | (7.4 | ) | % |

[0001564590-19-035143:mdna:26]
[same as prior period, unchanged from 0001564590-19-016264:mdna:25]

[0001564590-19-035143:mdna:27]
Our sales increased 22.1% from $128.0 million for the three months ended June 30, 2018 to $156.4 million for the three months ended June 30, 2019, and increased 20.6% from $248.9 million for the six months ended June 30, 2018 to $300.2 million for the six months ended June 30, 2019. The increase in sales for the three and six months ended June 30, 2019 was primarily attributable to $24.7 million and $42.8 million increase in Access & Aggregation products, respectively, and $5.9 million and $12.6 million increase in sales of our Subscriber Solutions & Experience products, respectively, partially offset by a $2.3 million and a $4.0 million decrease in sales of our Traditional & Other Products, respectively.

[0001564590-19-035143:mdna:28]
Network Solutions segment sales increased 20.9% from $115.1 million for the three months ended June 30, 2018 to $139.2 million for the three months ended June 30, 2019, and increased 20.3% from $220.3 million for the six months ended June 30, 2018 to $265.0 million for the six months ended June 30, 2019. The increase in sales for the three and six months ended June 30, 2019 was primarily attributable to an increase in Access & Aggregation and Subscriber Solutions & Experience sales, partially offset by a decrease in Traditional & Other Products sales. The increase in Access & Aggregation sales for the three and six months ended June 30, 2019 was primarily attributable to increased fiber to the node (FTTN) products, Gfast distribution point units (DPUs) and fiber access and aggregation. The increase in Subscriber Solutions & Experience was primarily attributable to increased fiber CPE and network termination. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-19-035143:mdna:29]
Services & Support segment sales increased 32.6% from $13.0 million for the three months ended June 30, 2018 to $17.2 million for the three months ended June 30, 2019, and increased 23.3% from $28.5 million for the six months ended June 30, 2018 to $35.2 million for the six months ended June 30, 2019. The increase in sales for the three and six months ended June 30, 2019 was primarily attributable to an increase in network installation services for Access & Aggregation products and maintenance.

[0001564590-19-035143:mdna:30]
36

[0001564590-19-035143:mdna:31]
International sales, which are included in the amounts for the Network Solutions and Services & Support segments amounts discussed above, increased 35.6% from $59.8 million for the three months ended June 30, 2018 to $81.1 million for the three months ended June 30, 2019 and increased 28.5% from $118.5 million for the six months ended June 30, 2018 to $152.4 million for the six months ended June 30, 2019. International sales, as a percentage of total sales, increased from 46.7% for the three months ended June 30, 2018 to 51.9% for the three months ended June 30, 2019 and increased from 47.6% for the six months ended June 30, 2018 to 50.8% for the six months ended June 30, 2019. The increase in sales for the three and six months ended June 30, 2019, was primarily attributable to an increase in sales in LATAM and Asia Pacific (“APAC”), primarily attributable to network expansion programs of large Tier-1 customers.

[0001564590-19-035143:mdna:32]
Our international revenue is largely focused on broadband infrastructure and is affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. The competitive landscape in certain international markets is also affected by the increased presence of Asian manufacturers that seek to compete aggressively on price. Our revenue and operating income in some international markets can be negatively impacted by a strengthening U.S. dollar. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in negative pressure on revenue and operating income.

[0001564590-19-035143:mdna:33]
[same as prior period, unchanged from 0001564590-19-016264:mdna:32]

[0001564590-19-035143:mdna:34]
As a percentage of sales, cost of sales decreased from 61.0% for the three months ended June 30, 2018 to 58.4% for the three months ended June 30, 2019 and decreased from 63.9% for the six months ended June 30, 2018 to 58.2% for the six months ended June 30, 2019. The decrease in cost of sales as a percentage of sales for the three months ended June 30, 2019 was primarily attributable to an increase in volume, a regional revenue shift, changes in customer and product mix and changes in services and support mix. The decrease in cost of sales as a percentage of sales for the six months ended June 30, 2019 was primarily attributable to an increase in volume, a regional revenue shift, changes in customer and product mix, changes in services and support mix and a decrease in labor expense as a result of a restructuring program initiated in the first quarter of 2018.

[0001564590-19-035143:mdna:35]
Network Solutions segment cost of sales, as a percentage of that segment’s sales, decreased from 60.5% for the three months ended June 30, 2018 to 57.6% for the three months ended June 30, 2019 and decreased from 62.7% for the six months ended June 30, 2018 to 57.0% for the six months ended June 30, 2019. The decrease in cost of sales as a percentage of sales for the three months ended June 30, 2019 was primarily attributable to an increase in volume, a regional revenue shift and changes in customer and product mix. The decrease in cost of sales as a percentage of sales for the six months ended June 30, 2019 was primarily attributable to an increase in volume, a regional revenue shift, changes in customer and product mix and a decrease in labor expense due to a restructuring program initiated in the first quarter of 2018.

[0001564590-19-035143:mdna:36]
[same as prior period, unchanged from 0001564590-19-016264:mdna:35]

[0001564590-19-035143:mdna:37]
Services & Support segment cost of sales, as a percentage of that segment’s sales, increased from 64.9% for the three months ended June 30, 2018 to 65.0% for the three months ended June 30, 2019 and decreased from 73.2% for the six months ended June 30, 2018 to 67.2% for the six months ended June 30, 2019. The increase in cost of sales as a percentage of sales for the three months ended June 30, 2019 was primarily attributable to customer mix and changes in services and support mix. The decrease in cost of sales as a percentage of sales for the six months ended June 30, 2019 was primarily attributable to an increase in volume, lower fixed personnel costs due to a restructuring program initiated in the first quarter of 2018, changes in customer mix and changes in services and support mix.

[0001564590-19-035143:mdna:38]
Our Services & Support segment revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services.

[0001564590-19-035143:mdna:39]
As our network planning and implementation revenue grew to become the largest component of our Services & Support segment business, our Services & Support segment gross margins decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support segment revenue comprising a larger percentage of our overall revenue, and because our Services & Support segment gross margins are below those of the Network Solutions segment, our overall corporate gross margins have declined as that business has continued to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-19-035143:mdna:40]
[same as prior period, unchanged from 0001564590-19-016264:mdna:39]

[0001564590-19-035143:mdna:41]
Selling, general and administrative expenses increased 4.8% from $32.1 million for the three months ended June 30, 2018 to $33.6 million for the three months ended June 30, 2019, and increased 4.8% from $65.6 million for the six months ended June 30, 2018 to $68.8 million for the six months ended June 30, 2019. The increase in selling, general and administrative expenses for the three months ended June 30, 2019 was primarily attributable to increases in incremental expenses as a result of the SmartRG acquisition, deferred compensation and short-term incentive compensation. The increase in selling, general and administrative expenses for the six months ended June 30, 2019 was primarily attributable to increases in deferred compensation and incremental expenses as a result of the SmartRG acquisition offset by decreases in stock-based compensation expense, commissions and restructuring expenses.

[0001564590-19-035143:mdna:42]
As a percentage of sales, selling, general and administrative expenses decreased from 25.1% for the three months ended June 30, 2018 to 21.5% for the three months ended June 30, 2019, and decreased from 26.4% for the six months ended June 30, 2018 to 22.9% for the six months ended June 30, 2019. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0001564590-19-035143:mdna:43]
[same as prior period, unchanged from 0001564590-19-016264:mdna:42]

[0001564590-19-035143:mdna:44]
Research and development expenses increased 4.3% from $30.7 million for the three months ended June 30, 2018 to $32.1 million for the three months ended June 30, 2019 and increased 0.2% from $63.6 million for the six months ended June 30, 2018 to $63.7 million for the six months ended June 30, 2019. The increase in research and development expenses for the three months ended June 30, 2019 was primarily attributable to increases in incremental expenses as a result of the SmartRG acquisition and restructuring expenses. The increase in research and development expense for the six months ended June 30, 2019 was primarily attributable to increases in contract services and increases in incremental expenses as a result of the SmartRG acquisition, partially offset by decreases in personnel expense and stock-based compensation expense.

[0001564590-19-035143:mdna:45]
As a percentage of sales, research and development expenses decreased from 24.0% for the three months ended June 30, 2018 to 20.5% for the three months ended June 30, 2019, and decreased from 25.5% for the six months ended June 30, 2018 to 21.2% for the six months ended June 30, 2019. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0001564590-19-035143:mdna:46]
[same as prior period, unchanged from 0001564590-19-016264:mdna:45]

[0001564590-19-035143:mdna:47]
GAIN ON CONTINGENCY

[0001564590-19-035143:mdna:48]
Gain on contingency, which was $1.2 million for the three and six months ended June 30, 2019, relates to the reversal of unearned contingent liabilities which were initially recognized upon the acquisition of SmartRG in the fourth quarter of 2018. See Note 2 of Notes to Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001564590-19-035143:mdna:49]
[same as prior period, unchanged from 0001564590-19-016264:mdna:46]

[0001564590-19-035143:mdna:50]
Interest and dividend income decreased 24.2% from $0.9 million for the three months ended June 30, 2018 to $0.7 million for the three months ended June 30, 2019, and decreased 27.9% from $1.8 million for the six months ended June 30, 2018 to $1.3 million for the six months ended June 30, 2019. The changes in interest and dividend income for the three and six months ended June 30, 2019 were primarily attributable to fluctuations in investment balances.

[0001564590-19-035143:mdna:51]
[same as prior period, unchanged from 0001564590-19-016264:mdna:48]

[0001564590-19-035143:mdna:52]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended June 30, 2018 and 2019 and $0.3 million in the six months ended June 30, 2018 and 2019, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-19-035143:mdna:53]
NET INVESTMENT GAIN

[0001564590-19-035143:mdna:54]
Net investment gain increased from $1.0 million for the three months ended June 30, 2018 to $2.5 million for the three months ended June 30, 2019, and increased from $0.9 million for the six months ended June 30, 2018 to $8.4 million for the six months ended June 30, 2019. The fluctuation in our net investment gain was primarily attributable to changes in fair value of equity securities recognized during the period. See Note 7 of Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-19-035143:mdna:55]
[same as prior period, unchanged from 0001564590-19-016264:mdna:52]

[0001564590-19-035143:mdna:56]
Other income (expense), net is comprised primarily of miscellaneous income and gains and losses on foreign currency transactions. Other income (expense), net remained flat at $0.2 million of expense for the three months ended June 30, 2018 and 2019, and increased from $0.3 million of expense for the six months ended June 30, 2018 to $0.7 million of income for the six months ended June 30, 2019. The change in other income (expense), net for the six months ended June 30, 2019 was primarily attributable to the receipt of insurance proceeds from a life insurance policy.

[0001564590-19-035143:mdna:57]
[same as prior period, unchanged from 0001564590-19-016264:mdna:54]

[0001564590-19-035143:mdna:58]
Gain on bargain purchase of a business, net, which was $11.3 million during the six months ended June 30, 2018, was related to our acquisition of Sumitomo Electric Lightwave Corp.’s North American EPON business and entry into a technology license and supply agreement with Sumitomo Electric Industries, Ltd. in March 2018. No gain on bargain purchase of a business was recorded during the three or six months ended June 30, 2019.

[0001564590-19-035143:mdna:59]
BENEFIT FOR INCOME TAXES

[0001564590-19-035143:mdna:60]
Our effective tax rate decreased from a benefit of 31.9% for the three months ended June 30, 2018 to a benefit of 17.3% for the three months ended June 30, 2019, and increased from a benefit of 20.1%, excluding the tax effect of the bargain purchase gain, for the six months ended June 30, 2018 to a benefit of 6.2% for the six months ended June 30, 2019. The increase in the effective tax rate between the two periods was primarily driven by the shift to profitability for the three and six months ended June 30, 2019, with tax expense being offset by a 29.1% rate reduction related to a transfer pricing study completed during the second quarter of 2019 that resulted in the assignment of operating expenditures to specific company locations, and the effective income tax rates among the respective jurisdictions.

[0001564590-19-035143:mdna:61]
[same as prior period, unchanged from 0001564590-19-016264:mdna:58]

[0001564590-19-035143:mdna:62]
As a result of the above factors, net income (loss) increased $11.7 million from a net loss of $(7.7) million for the three months ended June 30, 2018 to net income of $4.0 million for the three months ended June 30, 2019, and increased $23.3 million from a net loss of $(18.5) million for the six months ended June 30, 2018 to net income of $4.8 million for the six months ended June 30, 2019.

[0001564590-19-035143:mdna:63]
[same as prior period, unchanged from 0001564590-19-016264:mdna:60]

[0001564590-19-035143:mdna:64]
[same as prior period, unchanged from 0001564590-19-016264:mdna:61]

[0001564590-19-035143:mdna:65]
[same as prior period, unchanged from 0001564590-19-016264:mdna:62]

[0001564590-19-035143:mdna:66]
At June 30, 2019, cash on hand was $106.8 million and short-term investments were $30.9 million, which resulted in available short-term liquidity of $137.7 million, of which $64.1 million was held by our foreign subsidiaries. At December 31, 2018, cash on hand was $105.5 million and short-term investments were $3.2 million, which resulted in available short-term liquidity of $108.7 million, of which $87.1 million was held by our foreign subsidiaries. The increase in short-term liquidity from December 31, 2018 to June 30, 2019 is primarily attributable to a restricted certificate of deposit of $25.6 million, which serves as collateral for our revenue bond, being reclassified from a long-term investment to a short-term investment.

[0001564590-19-035143:mdna:67]
[same as prior period, unchanged from 0001564590-19-016264:mdna:64]

[0001564590-19-035143:mdna:68]
Our working capital, which consists of current assets less current liabilities, increased 0.2% from $237.4 million as of December 31, 2018 to $238.0 million as of June 30, 2019, and our current ratio, defined as current assets divided by current liabilities, decreased from 3.01 as of December 31, 2018 to 2.64 as of June 30, 2019. The slight increase in our working capital and decrease in our current ratio was primarily attributable to the reclassification of our bond payable to current liabilities as it matures in January 2020, as well as the reclassification of the related restricted certificate of deposit from a long-term investment to a short-term investment. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 1.76 as of December 31, 2018 to 1.75 as of June 30, 2019. The decrease in the quick ratio was primarily attributable to the reclassification of our bond payable to current liabilities as it matures in January 2020, partially offset by an increase in short-term investments, primarily related to the reclassification of our restricted certificate of deposit from a long-term investment to a short-term investment.

[0001564590-19-035143:mdna:69]
Net accounts receivable increased 17.4% from $99.4 million at December 31, 2018 to $116.7 million at June 30, 2019. Our allowance for doubtful accounts was $0.1 million at December 31, 2018 and June 30, 2019. Quarterly accounts receivable day’s sales outstanding (DSO) increased from 65 days as of December 31, 2018 to 68 days as of June 30, 2019. The increase in net accounts receivable was due to an increase in volume, the timing of customer mix and international shipments.

[0001564590-19-035143:mdna:70]
Other receivables decreased 31.9% from $36.7 million at December 31, 2018 to $25.0 million at June 30, 2019. The decrease in other receivables was primarily attributable to a decrease in contract assets, leased equipment receivables, contract manufacturers’ receivables and income tax receivables.

[0001564590-19-035143:mdna:71]
Quarterly inventory turnover increased from 3.29 turns as of December 31, 2018 to 3.87 turns at June 30, 2019. Inventory decreased 3.5% from $99.8 million at December 31, 2018 to $95.1 million at June 30, 2019. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-19-035143:mdna:72]
Accounts payable increased 6.3% from $60.1 million at December 31, 2018 to $63.8 million at June 30, 2019. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-19-035143:mdna:73]
[same as prior period, unchanged from 0001564590-19-016264:mdna:70]

[0001564590-19-035143:mdna:74]
Capital expenditures totaled approximately $4.3 million and $4.2 million for the six months ended June 30, 2019 and 2018, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment and building improvements.

[0001564590-19-035143:mdna:75]
Our combined short-term and long-term investments increased $6.1 million from $112.1 million at December 31, 2018 to $118.2 million at June 30, 2019. This increase reflects the impact of net realized and unrealized gains and losses on our combined investments plus new investments.

[0001564590-19-035143:mdna:76]
We typically invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At June 30, 2019, these investments included corporate bonds of $14.2 million, municipal bonds of $0.9 million, asset-backed bonds of $6.6 million, mortgage/agency bonds of $5.4 million, U.S. government bonds of $5.0 million and foreign government bonds of $1.9 million. At December 31, 2018, these investments included corporate bonds of $20.7 million, municipal fixed-rate bonds of $1.3 million, asset-backed bonds of $5.2 million, mortgage/agency-backed bonds of $3.8 million, U.S. government bonds of $9.2 million and foreign government bonds of $0.6 million. As of June 30, 2019, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds and foreign government bonds were classified as available-for-sale and had a combined duration of 0.90 years with an average Moody’s credit rating of A+. Because our bond portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-19-035143:mdna:77]
Our long-term investments decreased 19.8% from $108.8 million at December 31, 2018 to $87.3 million at June 30, 2019. Long-term investments at December 31, 2018 included an investment in a certificate of deposit of $25.6 million, which serves as collateral for our revenue bond. This certificate of deposit is now included in short-term investments as of June 30, 2019, as this bond matures on January 1, 2020. See “Debt” below for additional information. We also have investments in various marketable equity securities classified as long-term investments with a fair market value of $32.7 million and $27.0 million, at June 30, 2019 and December 31, 2018, respectively. Long-term investments at June 30, 2019 and December 31, 2018 also included $21.2 million and $18.3 million, respectively, related to our deferred compensation plans.

[0001564590-19-035143:mdna:78]
No businesses were acquired during the six months ended June 30, 2019. Acquisition of businesses, net of cash acquired, totaled $7.8 million for the six months ended June 30, 2018. See Note 2 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001564590-19-035143:mdna:79]
[same as prior period, unchanged from 0001564590-19-016264:mdna:76]

[0001564590-19-035143:mdna:80]
[same as prior period, unchanged from 0001564590-19-016264:mdna:77]

[0001564590-19-035143:mdna:81]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the six months ended June 30, 2019 and 2018, we paid dividends totaling $8.6 million and $8.7 million, respectively. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0001564590-19-035143:mdna:82]
[same as prior period, unchanged from 0001564590-19-016264:mdna:79]

[0001564590-19-035143:mdna:83]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the “Bond”) which totaled $25.6 million at June 30, 2019 and December 31, 2018. At June 30, 2019, the estimated fair value of the Bond was $25.6 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Restricted funds serving as a collateral deposit against the principal amount of the Bond in the amount of $25.6 million were included in short-term investments at June 30, 2019 and long-term investments at December 31, 2018, respectively. We have the right to offset the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the State of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. The restricted funds held as collateral against the principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity on January 1, 2020.

[0001564590-19-035143:mdna:84]
[same as prior period, unchanged from 0001564590-19-016264:mdna:81]

[0001564590-19-035143:mdna:85]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized repurchases of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2019, we repurchased 13 thousand shares of our common stock, for $0.2 million at an average price of $14.06 per share. We currently have authorization to repurchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-19-035143:mdna:86]
[same as prior period, unchanged from 0001564590-19-016264:mdna:83]

[0001564590-19-035143:mdna:87]
We issued 34,000 shares of treasury stock during the six months ended June 30, 2019 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.33 to $16.97. We received proceeds totaling $0.5 million from the exercise of these stock options during the six months ended June 30, 2019.

[0001564590-19-035143:mdna:88]
[same as prior period, unchanged from 0001564590-19-016264:mdna:85]

[0001564590-19-035143:mdna:89]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the six months ended June 30, 2019, there have been no material changes in contractual obligations and commercial commitments from those discussed in the 2018 Form 10-K.

[0001564590-19-035143:mdna:90]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied to these commitments as of June 30, 2019.
