# ADTN note change history — 0001564590-19-016264 → 0001564590-19-035143


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-09-20):
[0001564590-19-035143:note_history:1]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants may seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.
  (was, 2019-05-07, similarity 0.9967):
[0001564590-19-016264:note_history:1]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

- changed (2019-09-20):
[0001564590-19-035143:note_history:2]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied to these commitments as of June 30, 2019.
  (was, 2019-05-07, similarity 0.8144):
[0001564590-19-016264:note_history:2]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2019, of which $7.7 million has been applied to these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-09-20):
[0001564590-19-035143:note_history:3]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“GAAP”) for complete financial statements are not included herein. The December 31, 2018 Condensed Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by GAAP.
  (was, 2019-05-07, similarity 0.7873):
[0001564590-19-016264:note_history:3]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN” or the “Company”) have been prepared pursuant to the rules and regulations for reporting on Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles for complete financial statements are not included herein. The December 31, 2018 Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.

- changed (2019-09-20):
[0001564590-19-035143:note_history:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K/A for the year ended December 31, 2018, filed on September 20, 2019, with the SEC.
  (was, 2019-05-07, similarity 0.9599):
[0001564590-19-016264:note_history:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim statements should be read in conjunction with the financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2018, filed on February 28, 2019 with the SEC.

- changed (2019-09-20):
[0001564590-19-035143:note_history:5]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the excess, obsolete and slow moving inventory reserves, warranty reserves, customer rebates, determination of the deferred and accrued revenue components of multiple performance obligations sales agreements, estimated costs to complete obligations associated with deferred and accrued revenue, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.
  (was, 2019-05-07, similarity 0.8183):
[0001564590-19-016264:note_history:5]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred and accrued revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenue, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

- added (2019-09-20):
[0001564590-19-035143:note_history:6]
During the three months ended June 30, 2019, the Company revised the methodology in how it estimates its excess and obsolete inventory reserves. Under the revised methodology, we establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on historical usage, known trends, inventory age, and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 8 of Notes to Condensed Consolidated Financial Statements for additional information.

- added (2019-09-20):
[0001564590-19-035143:note_history:7]
Correction of Immaterial Misstatements.

- added (2019-09-20):
[0001564590-19-035143:note_history:8]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The accompanying Unaudited Condensed Consolidated Statement of Cash Flows for the six months ended June 30, 2019 correctly reflects the $1.0 million insurance recovery as a cash inflow from investing activities. Management has determined that these misstatements were not material to any of its previously issued financial statements and that correction of the misstatements is also not material to the current or estimated annual 2019 financial results on both a quantitative and qualitative basis.

- changed (2019-09-20):
[0001564590-19-035143:note_history:9]
Recent Accounting Pronouncements Not Yet Adopted
  (was, 2019-05-07, similarity 0.8):
[0001564590-19-016264:note_history:9]
Recent Accounting Pronouncements

- added (2019-09-20):
[0001564590-19-035143:note_history:10]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the leases standard. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. All of these ASUs are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect these ASUs will have on our consolidated financial statements.

- added (2019-09-20):
[0001564590-19-035143:note_history:11]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of Accounting Standards Codification (“ASC”) 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but do not expect it will have a material effect on our financial statement disclosures.

- changed (2019-09-20):
[0001564590-19-035143:note_history:12]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect of ASU 2018-15, but do not expect it will have a material effect on our consolidated financial statements.
  (was, 2019-05-07, similarity 0.9989):
[0001564590-19-016264:note_history:12]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40), Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect of ASU 2018-15, but do not expect it will have a material effect on our consolidated financial statements.

- added (2019-09-20):
[0001564590-19-035143:note_history:13]
Recently Adopted Accounting Pronouncements

- changed (2019-09-20):
[0001564590-19-035143:note_history:14]
During 2019, we adopted the following accounting standards, which had the following impacts on our consolidated financial statements:
  (was, 2019-05-07, similarity 0.969):
[0001564590-19-016264:note_history:14]
During 2019, we adopted the following accounting standards, which had the following effects on our consolidated financial statements:

- added (2019-09-20):
[0001564590-19-035143:note_history:15]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provided for an optional transition method allowing for the application of the legacy lease guidance, Leases (Topic 840), including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. In March 2019, the FASB issued ASU 2019-01, Leases (Topic 842) Codification Improvements, which removed the requirement for an entity to disclose in the interim periods after adoption, the effect of the change on income from continuing operations, net income, any other affected financial statement line item, and any affected per share amount. For lessors, the new leasing standard requires leases to be classified as sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard and related updates were effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.

- changed (2019-09-20):
[0001564590-19-035143:note_history:16]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. The Company has elected to carry forward the legacy ASC 840 disclosures for comparative periods and, therefore, did not adjust the comparative period financial information prior to January 1, 2019. In addition, the Company elected the package of practical expedients which allows for companies to not reassess whether any expired or existing contracts are or contain leases, not reassess historical lease classifications for expired or existing contracts and not reassess initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and non-lease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our Condensed Consolidated Balance Sheet of $10.3 million, primarily related to our operating leases for office space, automobiles and other equipment.
  (was, 2019-05-07, similarity 0.9895):
[0001564590-19-016264:note_history:16]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. The Company has elected to carry forward the legacy (ASC 840) disclosures for comparative periods and therefore, did not adjust the comparative period financial information prior to January 1, 2019. In addition, the Company elected the package of practical expedients which allows for companies to not reassess whether any expired or existing contracts are or contain leases, not reassess historical lease classifications for expired or existing contracts and not reassess initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and non-lease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our Consolidated Balance Sheet of $10.3 million, mainly related to our operating leases for office space, automobiles and other equipment.

- changed (2019-09-20):
[0001564590-19-035143:note_history:17]
As a lessee, the adoption of this standard did not have a material impact on our Condensed Consolidated Statement of Income or Statement of Cash Flow. See Note 11 for additional information.
  (was, 2019-05-07, similarity 0.9728):
[0001564590-19-016264:note_history:17]
As a lessee, the adoption of this standard did not have a material impact on our Consolidated Statement of Income or Statement of Cash Flow. See Note 12 for additional information.

- changed (2019-09-20):
[0001564590-19-035143:note_history:18]
As a lessor, the adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Balance Sheet, Condensed Consolidated Statement of Income or Condensed Statement of Cash Flow. Prior to and after adoption, all of our leases in which we are the lessor were classified as sales-types leases.
  (was, 2019-05-07, similarity 0.8464):
[0001564590-19-016264:note_history:18]
As a lessor, the adoption of this standard did not have a material impact on the Company’s Consolidated Balance Sheet, Consolidated Statement of Income or Statement of Cash Flow. Prior to and after adoption, all of our leases in which we are the lessor were classified as sales-types leases.

- removed (2019-09-20):
[0001564590-19-016264:note_history:19]
In June 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather, should be accounted for in accordance with the leases standard. ASU 2016-13 and ASU 2018-19 are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect ASU 2016-13 and ASU 2018-19 will have on our consolidated financial statements.

- removed (2019-09-20):
[0001564590-19-016264:note_history:20]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820) Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project called, Concepts Statement No. 8 - Conceptual Framework for Financial Reporting — Chapter 8, Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but do not expect it will have a material effect on our financial statement disclosures.

- removed (2019-09-20):
[0001564590-19-016264:note_history:21]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as, ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provided for an optional transition method which allowed for the application of the legacy lease guidance, including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. In March 2019, the FASB issued ASU 2019-01, Leases (Topic 824) Codification Improvements, which removed the requirement for an entity to disclose in the interim periods after adoption, the effect of the change on income from continuing operations, net income, any other affected financial statement line item, and any affected per share amount. For lessors, the new leasing standard requires leases to be classified as a sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard and related updates were effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-20):
[0001564590-19-035143:note_history:22]
At June 30, 2019, we held the following debt securities and other investments, recorded at either fair value or cost:
  (was, 2019-05-07, similarity 0.9596):
[0001564590-19-016264:note_history:22]
At March 31, 2019, we held the following debt securities and other investments, recorded at either fair value or cost:

- changed (2019-09-20):
[0001564590-19-035143:note_history:23]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 14,132 |  |  | $ | 111 |  |  | $ | (4 | ) |  | $ | 14,239 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | (3 | ) |  |  | 927 |  |
| Asset-backed bonds |  |  | 6,580 |  |  |  | 32 |  |  |  | (3 | ) |  |  | 6,609 |  |
| Mortgage/Agency-backed bonds |  |  | 5,362 |  |  |  | 23 |  |  |  | (6 | ) |  |  | 5,379 |  |
| U.S. government bonds |  |  | 5,027 |  |  |  | 6 |  |  |  | (6 | ) |  |  | 5,027 |  |
| Foreign government bonds |  |  | 1,852 |  |  |  | 1 |  |  |  | (1 | ) |  |  | 1,852 |  |
| Available-for-sale debt securities held at fair value |  | $ | 33,883 |  |  | $ | 173 |  |  | $ | (23 | ) |  | $ | 34,033 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,199 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 60,832 |  |
  (was, 2019-05-07, similarity 0.9978):
[0001564590-19-016264:note_history:23]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 15,964 |  |  | $ | 69 |  |  | $ | (24 | ) |  | $ | 16,009 |  |
| Municipal fixed-rate bonds |  |  | 951 |  |  |  | — |  |  |  | (13 | ) |  |  | 938 |  |
| Asset-backed bonds |  |  | 7,171 |  |  |  | 13 |  |  |  | (9 | ) |  |  | 7,175 |  |
| Mortgage/Agency-backed bonds |  |  | 4,561 |  |  |  | 6 |  |  |  | (26 | ) |  |  | 4,541 |  |
| U.S. government bonds |  |  | 4,238 |  |  |  | — |  |  |  | (11 | ) |  |  | 4,227 |  |
| Foreign government bonds |  |  | 2,159 |  |  |  | — |  |  |  | (2 | ) |  |  | 2,157 |  |
| Available-for-sale debt securities held at fair value |  | $ | 35,044 |  |  | $ | 88 |  |  | $ | (85 | ) |  | $ | 35,047 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,180 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 61,827 |  |

- changed (2019-09-20):
[0001564590-19-035143:note_history:24]
As of June 30, 2019, our debt securities had the following contractual maturities:
  (was, 2019-05-07, similarity 0.9412):
[0001564590-19-016264:note_history:24]
As of March 31, 2019, our debt securities had the following contractual maturities:

- changed (2019-09-20):
[0001564590-19-035143:note_history:25]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 2,749 |  |  | $ | — |  |  | $ | 96 |  |  | $ | — |  |  | $ | 2,443 |  |  | $ | — |  |
| One to two years |  |  | 8,460 |  |  |  | 927 |  |  |  | 430 |  |  |  | 264 |  |  |  | — |  |  |  | 891 |  |
| Two to three years |  |  | 3,030 |  |  |  | — |  |  |  | 1,667 |  |  |  | 588 |  |  |  | 1,346 |  |  |  | 961 |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 2,018 |  |  |  | 510 |  |  |  | 1,238 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,772 |  |  |  | 425 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 626 |  |  |  | 3,592 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 14,239 |  |  | $ | 927 |  |  | $ | 6,609 |  |  | $ | 5,379 |  |  | $ | 5,027 |  |  | $ | 1,852 |  |
  (was, 2019-05-07, similarity 0.972):
[0001564590-19-016264:note_history:25]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 3,127 |  |  | $ | — |  |  | $ | 872 |  |  | $ | — |  |  | $ | 1,691 |  |  | $ | — |  |
| One to two years |  |  | 8,389 |  |  |  | — |  |  |  | 387 |  |  |  | 289 |  |  |  | — |  |  |  | 1,196 |  |
| Two to three years |  |  | 4,493 |  |  |  | 938 |  |  |  | 976 |  |  |  | — |  |  |  | 1,324 |  |  |  | 961 |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 3,105 |  |  |  | 827 |  |  |  | 1,212 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,038 |  |  |  | 303 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 797 |  |  |  | 3,122 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 16,009 |  |  | $ | 938 |  |  | $ | 7,175 |  |  | $ | 4,541 |  |  | $ | 4,227 |  |  | $ | 2,157 |  |

- changed (2019-09-20):
[0001564590-19-035143:note_history:26]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.
  (was, 2019-05-07, similarity 0.9851):
[0001564590-19-016264:note_history:26]
Actual maturities may differ from contractual maturities because some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

- added (2019-09-20):
[0001564590-19-035143:note_history:27]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Gross realized gains on debt securities |  | $ | 8 |  |  | $ | 25 |  |  | $ | 49 |  |  | $ | 25 |  |
| Gross realized losses on debt securities |  |  | (14 | ) |  |  | (241 | ) |  |  | (33 | ) |  |  | (315 | ) |
| Total gain (loss) recognized, net |  | $ | (6 | ) |  | $ | (216 | ) |  | $ | 16 |  |  | $ | (290 | ) |

- changed (2019-09-20):
[0001564590-19-035143:note_history:28]
At June 30, 2019, we held a $25.6 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the “Bond”), which totaled $25.6 million at June 30, 2019 and December 31, 2018. At June 30, 2019 and December 31, 2018, the estimated fair value of the Bond using a level 2 valuation technique was approximately $25.6 million and $25.4 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to offset the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the State of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. We have made annual principal payments in addition to the interest amounts that are due. The restricted funds held as collateral against the outstanding principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity on January 1, 2020.
  (was, 2019-05-07, similarity 0.8236):
[0001564590-19-016264:note_history:28]
At March 31, 2019, we held a $25.6 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $25.6 million at March 31, 2019 and December 31, 2018. At March 31, 2019 and December 31, 2018, the estimated fair value of the Bond using a level 2 valuation technique was approximately $25.5 million and $25.4 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. The restricted funds held as collateral against the principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity on January 1, 2020.

- added (2019-09-20):
[0001564590-19-035143:note_history:29]
ASU 2016-01 also provides a measurement alternative for equity investments that do not have a readily determinable fair value in which investments can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. We elected to record our equity investment that does not have a readily determinable fair value using the measurement alternative method. As of December 31, 2018, the Company had a note receivable of approximately $4.3 million, which was included in other receivables on the Condensed Consolidated Balance Sheet. During the three months ended March 31, 2019, this amount was repaid as follows. Approximately $3.4 million was issued as an equity investment, which represented a non-cash investing activity. The carrying value of this investment under the measurement alternative was $3.4 million as of June 30, 2019. The remaining amount was converted into a new note receivable, which is included in other receivables on the Condensed Consolidated Balance Sheet and represents a non-cash operating activity.

- changed (2019-09-20):
[0001564590-19-035143:note_history:30]
Realized and unrealized gains and losses for our marketable equity securities for the three and six months ended June 30, 2019 and 2018 were as follows:
  (was, 2019-05-07, similarity 0.9395):
[0001564590-19-016264:note_history:30]
Realized and unrealized gains and losses for our marketable equity securities for the three months ended March 31, 2019 and 2018 were as follows:

- added (2019-09-20):
[0001564590-19-035143:note_history:31]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (49 | ) |  | $ | (52 | ) |  | $ | (63 | ) |  | $ | 347 |  |
| Unrealized gains on equity securities held |  |  | 2,540 |  |  |  | 1,258 |  |  |  | 8,458 |  |  |  | 836 |  |
| Total gain recognized, net |  | $ | 2,491 |  |  | $ | 1,206 |  |  | $ | 8,395 |  |  | $ | 1,183 |  |

- changed (2019-09-20):
[0001564590-19-035143:note_history:32]
As of June 30, 2019 and 2018, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.
  (was, 2019-05-07, similarity 0.9236):
[0001564590-19-016264:note_history:32]
As of March 31, 2019 and 2018, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not significant.

- changed (2019-09-20):
[0001564590-19-035143:note_history:33]
|  |  |  |  |  |  | Fair Value Measurements at June 30, 2019 Using |  |
| (In thousands) |  | Cost or Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,337 |  |  | $ | 1,337 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 2,973 |  |  |  | — |  |  |  | 2,973 |  |  |  | — |  |
| Cash equivalents |  |  | 4,310 |  |  |  | 1,337 |  |  |  | 2,973 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 14,239 |  |  |  | — |  |  |  | 14,239 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 927 |  |  |  | — |  |  |  | 927 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,609 |  |  |  | — |  |  |  | 6,609 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,379 |  |  |  | — |  |  |  | 5,379 |  |  |  | — |  |
| U.S. government bonds |  |  | 5,027 |  |  |  | 5,027 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,852 |  |  |  | — |  |  |  | 1,852 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 32,548 |  |  |  | 32,548 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 185 |  |  |  | 185 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,228 |  |  |  | 21,228 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 87,994 |  |  |  | 58,988 |  |  |  | 29,006 |  |  |  | — |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other investments |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other investments held at cost |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 95,679 |  |  | $ | 60,325 |  |  | $ | 31,979 |  |  | $ | — |  |
  (was, 2019-05-07, similarity 0.9967):
[0001564590-19-016264:note_history:33]
|  |  |  |  |  |  | Fair Value Measurements at March 31, 2019 Using |  |
| (In thousands) |  | Cost or Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,279 |  |  | $ | 1,279 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 6,547 |  |  |  | — |  |  |  | 6,547 |  |  |  | — |  |
| Cash equivalents |  |  | 7,826 |  |  |  | 1,279 |  |  |  | 6,547 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 16,009 |  |  |  | — |  |  |  | 16,009 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 938 |  |  |  | — |  |  |  | 938 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,175 |  |  |  | — |  |  |  | 7,175 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,541 |  |  |  | — |  |  |  | 4,541 |  |  |  | — |  |
| U.S. government bonds |  |  | 4,227 |  |  |  | 4,227 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 2,157 |  |  |  | — |  |  |  | 2,157 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Marketable equity securities – various industries |  |  | 30,725 |  |  |  | 30,725 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 174 |  |  |  | 174 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,416 |  |  |  | 20,416 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 86,362 |  |  |  | 55,542 |  |  |  | 30,820 |  |  |  | — |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other investments |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other investments held at cost |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 97,563 |  |  | $ | 56,821 |  |  | $ | 37,367 |  |  | $ | — |  |

- removed (2019-09-20):
[0001564590-19-016264:note_history:34]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Gross realized gains on debt securities |  | $ | 41 |  |  | $ | — |  |
| Gross realized losses on debt securities |  |  | (19 | ) |  |  | (73 | ) |
| Total gain (loss) recognized, net |  | $ | 22 |  |  | $ | (73 | ) |

- removed (2019-09-20):
[0001564590-19-016264:note_history:35]
ASU 2016-01 also provides a measurement alternative for equity investments that do not have a readily determinable fair value in which investments can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. We elected to record our equity investment that does not have a readily determinable fair value using the measurement alternative method. The carrying value of this investment was $3.4 million and $0 as of March 31, 2019 and December 31, 2018, respectively.

- removed (2019-09-20):
[0001564590-19-016264:note_history:36]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (14 | ) |  | $ | 398 |  |
| Unrealized gains (losses) on equity securities held |  |  | 5,918 |  |  |  | (422 | ) |
| Total gain (loss) recognized, net |  | $ | 5,904 |  |  | $ | (24 | ) |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-09-20):
[0001564590-19-035143:note_history:37]
The following table disaggregates our revenue by reportable segment and revenue category for the three months ended June 30, 2019 and 2018:
  (was, 2019-05-07, similarity 0.7565):
[0001564590-19-016264:note_history:37]
The following table disaggregates our revenue by major source for the three months ended March 31, 2019:

- changed (2019-09-20):
[0001564590-19-035143:note_history:38]
|  |  | For the Three Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 96,262 |  |  | $ | 13,159 |  |  | $ | 109,421 |  |  | $ | 75,222 |  |  | $ | 9,520 |  |  | $ | 84,742 |  |
| Subscriber Solutions & Experience(1) |  |  | 38,444 |  |  |  | 2,058 |  |  |  | 40,502 |  |  |  | 33,306 |  |  |  | 1,254 |  |  |  | 34,560 |  |
| Traditional & Other Products |  |  | 4,461 |  |  |  | 2,007 |  |  |  | 6,468 |  |  |  | 6,535 |  |  |  | 2,211 |  |  |  | 8,746 |  |
| Total |  | $ | 139,167 |  |  | $ | 17,224 |  |  | $ | 156,391 |  |  | $ | 115,063 |  |  | $ | 12,985 |  |  | $ | 128,048 |  |
  (was, 2019-05-07, similarity 0.6128):
[0001564590-19-016264:note_history:38]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 85,673 |  |  | $ | 14,105 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience(1) |  |  | 34,719 |  |  |  | 2,034 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 5,430 |  |  |  | 1,830 |  |  |  | 7,260 |  |
| Total |  | $ | 125,822 |  |  | $ | 17,969 |  |  | $ | 143,791 |  |

- changed (2019-09-20):
[0001564590-19-035143:note_history:39]
The following table disaggregates our revenue by reportable segment and revenue category for the six months ended June 30, 2019 and 2018:
  (was, 2019-05-07, similarity 0.7193):
[0001564590-19-016264:note_history:39]
The following table disaggregates our revenue by major source for the three months ended March 31, 2018:

- changed (2019-09-20):
[0001564590-19-035143:note_history:40]
|  |  | For the Six Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 181,935 |  |  | $ | 27,264 |  |  | $ | 209,199 |  |  | $ | 144,607 |  |  | $ | 21,815 |  |  | $ | 166,422 |  |
| Subscriber Solutions & Experience(1) |  |  | 73,163 |  |  |  | 4,092 |  |  |  | 77,255 |  |  |  | 62,083 |  |  |  | 2,578 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 9,891 |  |  |  | 3,837 |  |  |  | 13,728 |  |  |  | 13,626 |  |  |  | 4,145 |  |  |  | 17,771 |  |
| Total |  | $ | 264,989 |  |  | $ | 35,193 |  |  | $ | 300,182 |  |  | $ | 220,316 |  |  | $ | 28,538 |  |  | $ | 248,854 |  |
  (was, 2019-05-07, similarity 0.6142):
[0001564590-19-016264:note_history:40]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,385 |  |  | $ | 12,295 |  |  | $ | 81,680 |  |
| Subscriber Solutions & Experience(1) |  |  | 28,777 |  |  |  | 1,324 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,091 |  |  |  | 1,934 |  |  |  | 9,025 |  |
| Total |  | $ | 105,253 |  |  | $ | 15,553 |  |  | $ | 120,806 |  |

- changed (2019-09-20):
[0001564590-19-035143:note_history:41]
The table below presents sales information by category for the three and six months ended June 30, 2019 and 2018:
  (was, 2019-05-07, similarity 0.9163):
[0001564590-19-016264:note_history:41]
The table below presents sales information by category for the three months ended March 31, 2019 and 2018:

- changed (2019-09-20):
[0001564590-19-035143:note_history:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Access & Aggregation |  | $ | 109,421 |  |  | $ | 84,742 |  |  | $ | 209,199 |  |  | $ | 166,422 |  |
| Subscriber Solutions & Experience |  |  | 40,502 |  |  |  | 34,560 |  |  |  | 77,255 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 6,468 |  |  |  | 8,746 |  |  |  | 13,728 |  |  |  | 17,771 |  |
| Total |  | $ | 156,391 |  |  | $ | 128,048 |  |  | $ | 300,182 |  |  | $ | 248,854 |  |
  (was, 2019-05-07, similarity 0.7779):
[0001564590-19-016264:note_history:42]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Access & Aggregation |  | $ | 99,778 |  |  | $ | 81,680 |  |
| Subscriber Solutions & Experience |  |  | 36,753 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,260 |  |  |  | 9,025 |  |
| Total |  | $ | 143,791 |  |  | $ | 120,806 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-09-20):
[0001564590-19-035143:note_history:43]
Network Solutions includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales. In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment. These arrangements typically include network equipment, network implementation services and maintenance services. Network implementation services and maintenance services are included in the Services & Support segment discussed below. See Note 11 for additional information.
  (was, 2019-05-07, similarity 0.8306):
[0001564590-19-016264:note_history:43]
Network Solutions includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales. In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment. These arrangements typically include network equipment, network implementation services and maintenance services. See Note 12 for additional information.

- changed (2019-09-20):
[0001564590-19-035143:note_history:44]
The following table disaggregates our revenue by reportable segment and revenue category for the three months ended June 30, 2019 and 2018:
  (was, 2019-05-07, similarity 0.7565):
[0001564590-19-016264:note_history:44]
The following table disaggregates our revenue by major source for the three months ended March 31, 2019:

- changed (2019-09-20):
[0001564590-19-035143:note_history:45]
|  |  | For the Three Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 96,262 |  |  | $ | 13,159 |  |  | $ | 109,421 |  |  | $ | 75,222 |  |  | $ | 9,520 |  |  | $ | 84,742 |  |
| Subscriber Solutions & Experience(1) |  |  | 38,444 |  |  |  | 2,058 |  |  |  | 40,502 |  |  |  | 33,306 |  |  |  | 1,254 |  |  |  | 34,560 |  |
| Traditional & Other Products |  |  | 4,461 |  |  |  | 2,007 |  |  |  | 6,468 |  |  |  | 6,535 |  |  |  | 2,211 |  |  |  | 8,746 |  |
| Total |  | $ | 139,167 |  |  | $ | 17,224 |  |  | $ | 156,391 |  |  | $ | 115,063 |  |  | $ | 12,985 |  |  | $ | 128,048 |  |
  (was, 2019-05-07, similarity 0.6128):
[0001564590-19-016264:note_history:45]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 85,673 |  |  | $ | 14,105 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience(1) |  |  | 34,719 |  |  |  | 2,034 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 5,430 |  |  |  | 1,830 |  |  |  | 7,260 |  |
| Total |  | $ | 125,822 |  |  | $ | 17,969 |  |  | $ | 143,791 |  |

- changed (2019-09-20):
[0001564590-19-035143:note_history:46]
The following table disaggregates our revenue by reportable segment and revenue category for the six months ended June 30, 2019 and 2018:
  (was, 2019-05-07, similarity 0.7193):
[0001564590-19-016264:note_history:46]
The following table disaggregates our revenue by major source for the three months ended March 31, 2018:

- changed (2019-09-20):
[0001564590-19-035143:note_history:47]
|  |  | For the Six Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 181,935 |  |  | $ | 27,264 |  |  | $ | 209,199 |  |  | $ | 144,607 |  |  | $ | 21,815 |  |  | $ | 166,422 |  |
| Subscriber Solutions & Experience(1) |  |  | 73,163 |  |  |  | 4,092 |  |  |  | 77,255 |  |  |  | 62,083 |  |  |  | 2,578 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 9,891 |  |  |  | 3,837 |  |  |  | 13,728 |  |  |  | 13,626 |  |  |  | 4,145 |  |  |  | 17,771 |  |
| Total |  | $ | 264,989 |  |  | $ | 35,193 |  |  | $ | 300,182 |  |  | $ | 220,316 |  |  | $ | 28,538 |  |  | $ | 248,854 |  |
  (was, 2019-05-07, similarity 0.6142):
[0001564590-19-016264:note_history:47]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,385 |  |  | $ | 12,295 |  |  | $ | 81,680 |  |
| Subscriber Solutions & Experience(1) |  |  | 28,777 |  |  |  | 1,324 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,091 |  |  |  | 1,934 |  |  |  | 9,025 |  |
| Total |  | $ | 105,253 |  |  | $ | 15,553 |  |  | $ | 120,806 |  |

- added (2019-09-20):
[0001564590-19-035143:note_history:48]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). As of June 30, 2019, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

- changed (2019-09-20):
[0001564590-19-035143:note_history:49]
| (In thousands) |  | June 30, 2019 |  |  | December 31, 2018 |  |
| Accounts receivable, net |  | $ | 116,661 |  |  | $ | 99,385 |  |
| Contract assets(1) |  | $ | 2,251 |  |  | $ | 3,766 |  |
| Unearned revenue |  | $ | 12,910 |  |  | $ | 17,940 |  |
| Non-current unearned revenue |  | $ | 4,265 |  |  | $ | 5,296 |  |
  (was, 2019-05-07, similarity 0.9763):
[0001564590-19-016264:note_history:49]
| (In thousands) |  | March 31, 2019 |  |  | December 31, 2018 |  |
| Accounts receivable, net |  | $ | 99,032 |  |  | $ | 99,385 |  |
| Contract assets |  | $ | 2,333 |  |  | $ | 3,766 |  |
| Unearned revenue |  | $ | 15,230 |  |  | $ | 17,940 |  |
| Non-current unearned revenue |  | $ | 4,514 |  |  | $ | 5,296 |  |

- added (2019-09-20):
[0001564590-19-035143:note_history:50]
|  | (1) | Included in other receivables on the Condensed Consolidated Balance Sheet. |

- changed (2019-09-20):
[0001564590-19-035143:note_history:51]
Of the outstanding unearned revenue balance at December 31, 2018, $3.6 million and $10.5 million was recognized as revenue during the three and six months ended June 30, 2019, respectively.
  (was, 2019-05-07, similarity 0.7792):
[0001564590-19-016264:note_history:51]
$6.9 million of the outstanding unearned revenue balance at December 31, 2018 was recognized as revenue during the three months ended March 31, 2019.

- removed (2019-09-20):
[0001564590-19-016264:note_history:52]
As of March 31, 2019, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2019-09-20):
[0001564590-19-035143:note_history:53]
On July 17, 2019, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on August 1, 2019. The dividend was paid on August 15, 2019 and totaled $4.3 million.

- added (2019-09-20):
[0001564590-19-035143:note_history:54]
In September 2019, we entered into an operating lease for office space in India. This lease has an initial term of five years and includes an option to renew for an additional five-year period. As a result of this agreement, we will record a right-of-use asset and corresponding lease liability of approximately $10.2 million in our Condensed Consolidated Balance Sheet during the third quarter of 2019.

- removed (2019-09-20):
[0001564590-19-016264:note_history:55]
On April 17, 2019, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on May 2, 2019. The payment date will be May 16, 2019. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

- removed (2019-09-20):
[0001564590-19-016264:note_history:56]
A voluntary early retirement offering was communicated to certain of our employees in Germany in March 2019. These employees were given until April 28, 2019 to accept the early retirement offering. Therefore, as of March 31, 2019, we did not have sufficient information on which to estimate the liability associated with this program. The Company expects to incur approximately $0.8 million in restructuring expense during the second quarter of 2019 related to the early retirement program.
