# ADTN notes — 0001564590-19-035143


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-19-035143:notes:1]
[same as prior period, unchanged from 0001564590-19-016264:notes:1]

[0001564590-19-035143:notes:2]
[same as prior period, unchanged from 0001564590-19-016264:notes:2]

[0001564590-19-035143:notes:3]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“GAAP”) for complete financial statements are not included herein. The December 31, 2018 Condensed Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by GAAP.

[0001564590-19-035143:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K/A for the year ended December 31, 2018, filed on September 20, 2019, with the SEC.

[0001564590-19-035143:notes:5]
[same as prior period, unchanged from 0001564590-19-016264:notes:5]

[0001564590-19-035143:notes:6]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the excess, obsolete and slow moving inventory reserves, warranty reserves, customer rebates, determination of the deferred and accrued revenue components of multiple performance obligations sales agreements, estimated costs to complete obligations associated with deferred and accrued revenue, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-19-035143:notes:7]
During the three months ended June 30, 2019, the Company revised the methodology in how it estimates its excess and obsolete inventory reserves. Under the revised methodology, we establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on historical usage, known trends, inventory age, and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 8 of Notes to Condensed Consolidated Financial Statements for additional information.

[0001564590-19-035143:notes:8]
Correction of Immaterial Misstatements.

[0001564590-19-035143:notes:9]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The accompanying Unaudited Condensed Consolidated Statement of Cash Flows for the six months ended June 30, 2019 correctly reflects the $1.0 million insurance recovery as a cash inflow from investing activities. Management has determined that these misstatements were not material to any of its previously issued financial statements and that correction of the misstatements is also not material to the current or estimated annual 2019 financial results on both a quantitative and qualitative basis.

[0001564590-19-035143:notes:10]
Recent Accounting Pronouncements Not Yet Adopted

[0001564590-19-035143:notes:11]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the leases standard. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. All of these ASUs are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect these ASUs will have on our consolidated financial statements.

[0001564590-19-035143:notes:12]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but do not expect it will have a material effect on our consolidated financial statements.

[0001564590-19-035143:notes:13]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of Accounting Standards Codification (“ASC”) 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but do not expect it will have a material effect on our financial statement disclosures.

[0001564590-19-035143:notes:14]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (PBO) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (ABO) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but do not expect it will have a material effect on our financial statement disclosures.

[0001564590-19-035143:notes:15]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect of ASU 2018-15, but do not expect it will have a material effect on our consolidated financial statements.

[0001564590-19-035143:notes:16]
Recently Adopted Accounting Pronouncements

[0001564590-19-035143:notes:17]
During 2019, we adopted the following accounting standards, which had the following impacts on our consolidated financial statements:

[0001564590-19-035143:notes:18]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provided for an optional transition method allowing for the application of the legacy lease guidance, Leases (Topic 840), including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. In March 2019, the FASB issued ASU 2019-01, Leases (Topic 842) Codification Improvements, which removed the requirement for an entity to disclose in the interim periods after adoption, the effect of the change on income from continuing operations, net income, any other affected financial statement line item, and any affected per share amount. For lessors, the new leasing standard requires leases to be classified as sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard and related updates were effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.

[0001564590-19-035143:notes:19]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. The Company has elected to carry forward the legacy ASC 840 disclosures for comparative periods and, therefore, did not adjust the comparative period financial information prior to January 1, 2019. In addition, the Company elected the package of practical expedients which allows for companies to not reassess whether any expired or existing contracts are or contain leases, not reassess historical lease classifications for expired or existing contracts and not reassess initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and non-lease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our Condensed Consolidated Balance Sheet of $10.3 million, primarily related to our operating leases for office space, automobiles and other equipment.

[0001564590-19-035143:notes:20]
As a lessee, the adoption of this standard did not have a material impact on our Condensed Consolidated Statement of Income or Statement of Cash Flow. See Note 11 for additional information.

[0001564590-19-035143:notes:21]
As a lessor, the adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Balance Sheet, Condensed Consolidated Statement of Income or Condensed Statement of Cash Flow. Prior to and after adoption, all of our leases in which we are the lessor were classified as sales-types leases.

[0001564590-19-035143:notes:22]
In March 2017, the FASB issued ASU 2017-08, Receivables – Nonrefundable Fees and Other Costs (Subtopic 310-20): Premium Amortization on Purchased Callable Debt Securities, which shortened the amortization period for the premium on certain purchased callable debt securities to the earliest call date. ASU 2017-08 was effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2018. The amendments were required to be applied through a modified-retrospective transition approach that required a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The Company adopted ASU 2017-08 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-19-035143:notes:23]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expanded and refined hedge accounting for both financial and non-financial risk components, aligned the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and included certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness.  In October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting, which permits the OIS rate based on SOFR as a U.S. benchmark interest rate. Both ASU 2017-12 and ASU 2018-16 were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2017-12 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements as we currently do not have any hedging instruments.

[0001564590-19-035143:notes:24]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allowed for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 was effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2018-02 on January 1, 2019, and upon adoption reclassified $0.4 million of stranded tax effects created by rate changes related to the Tax Cuts and Jobs Act of 2017 to retained earnings. See Note 12 for additional information.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-035143:notes:25]
[same as prior period, unchanged from 0001564590-19-016264:notes:21]

[0001564590-19-035143:notes:26]
On November 30, 2018, we acquired SmartRG, Inc., a provider of carrier-class, open connected home platforms and cloud services for broadband service providers in exchange for cash consideration. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. The revenue from the SmartRG portfolio is included in the Subscriber Solutions & Experience category within the Network Solutions and Services & Support reportable segments.

[0001564590-19-035143:notes:27]
Contingent liabilities with a fair value totaling $1.2 million were recognized at the acquisition date, the payments of which were dependent upon SmartRG achieving future revenue, EBIT or customer purchase order milestones during the first half of 2019. The required milestones were not achieved and, therefore, we recognized a gain of $1.2 million upon the reversal of these liabilities during the second quarter of 2019.

[0001564590-19-035143:notes:28]
An escrow in the amount of $2.8 million was set up at the acquisition date to fund post-closing working capital settlements and to satisfy indemnity obligations to the Company arising from any inaccuracy or breach of representations, warranties, covenants, agreements or obligations of the sellers. The escrow is subject to arbitration with final settlement expected during the fourth quarter of 2020. The minimum and maximum potential release of funds to the sellers ranges from zero to $2.8 million.

[0001564590-19-035143:notes:29]
[same as prior period, unchanged from 0001564590-19-016264:notes:25]

[0001564590-19-035143:notes:30]
The final allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date for SmartRG are as follows:

[0001564590-19-035143:notes:31]
| (In thousands) |  |  |  |  |
| Assets |  |  |  |  |
| Tangible assets acquired |  | $ | 8,594 |  |
| Intangible assets |  |  | 9,960 |  |
| Goodwill |  |  | 3,476 |  |
| Total assets acquired |  |  | 22,030 |  |
| Liabilities |  |  |  |  |
| Liabilities assumed |  |  | (6,001 | ) |
| Total liabilities assumed |  |  | (6,001 | ) |
| Total purchase price |  | $ | 16,029 |  |

[0001564590-19-035143:notes:32]
The details of the acquired intangible assets from the SmartRG acquisition are as follows:

[0001564590-19-035143:notes:33]
| (In thousands) | Value |  |  | Life (in years) |
| Developed technology | $ | 7,400 |  |  | 7 |
| Customer relationships |  | 1,790 |  |  | 3 |
| Licensing agreements |  | 560 |  |  | 5 – 10 |
| Trade name |  | 210 |  |  | 3 |
| Total | $ | 9,960 |  |  |  |

[0001564590-19-035143:notes:34]
For the three and six months ended June 30, 2019, we incurred amortization of acquired intangibles of $0.6 million and $1.2 million, respectively, related to the SmartRG acquisition. No acquisition-related expenses were incurred during the three and six months ended June 30, 2018 related to the SmartRG acquisition.

[0001564590-19-035143:notes:35]
[same as prior period, unchanged from 0001564590-19-016264:notes:26]

[0001564590-19-035143:notes:36]
We recorded a bargain purchase gain, net of income taxes, of $11.3 million during the first quarter of 2018, which represents the difference between the fair-value of the net assets acquired over the cash paid. We assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-19-035143:notes:37]
The following unaudited supplemental pro forma information presents the financial results of the Company, for the six months ended June 30, 2018, as if the acquisition of the Sumitomo EPON business had occurred on January 1, 2017. This unaudited supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2017, nor is it indicative of any future results. There were no material, non-recurring adjustments to this unaudited pro forma information.

[0001564590-19-035143:notes:38]
|  | Six Months Ended |  |
| (In thousands) | June 30, 2018 |  |
| Pro forma revenue | $ | 250,114 |  |
| Pro forma net loss | $ | (31,020 | ) |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-035143:notes:39]
[same as prior period, unchanged from 0001564590-19-016264:notes:37]

[0001564590-19-035143:notes:40]
[same as prior period, unchanged from 0001564590-19-016264:notes:38]

[0001564590-19-035143:notes:41]
[same as prior period, unchanged from 0001564590-19-016264:notes:39]

[0001564590-19-035143:notes:42]
Network Solutions includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales. In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment. These arrangements typically include network equipment, network implementation services and maintenance services. Network implementation services and maintenance services are included in the Services & Support segment discussed below. See Note 11 for additional information.

[0001564590-19-035143:notes:43]
[same as prior period, unchanged from 0001564590-19-016264:notes:41]

[0001564590-19-035143:notes:44]
[same as prior period, unchanged from 0001564590-19-016264:notes:42]

[0001564590-19-035143:notes:45]
[same as prior period, unchanged from 0001564590-19-016264:notes:43]

[0001564590-19-035143:notes:46]
The following table disaggregates our revenue by reportable segment and revenue category for the three months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:47]
|  |  | For the Three Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 96,262 |  |  | $ | 13,159 |  |  | $ | 109,421 |  |  | $ | 75,222 |  |  | $ | 9,520 |  |  | $ | 84,742 |  |
| Subscriber Solutions & Experience(1) |  |  | 38,444 |  |  |  | 2,058 |  |  |  | 40,502 |  |  |  | 33,306 |  |  |  | 1,254 |  |  |  | 34,560 |  |
| Traditional & Other Products |  |  | 4,461 |  |  |  | 2,007 |  |  |  | 6,468 |  |  |  | 6,535 |  |  |  | 2,211 |  |  |  | 8,746 |  |
| Total |  | $ | 139,167 |  |  | $ | 17,224 |  |  | $ | 156,391 |  |  | $ | 115,063 |  |  | $ | 12,985 |  |  | $ | 128,048 |  |

[0001564590-19-035143:notes:48]
[same as prior period, unchanged from 0001564590-19-016264:notes:46]

[0001564590-19-035143:notes:49]
The following table disaggregates our revenue by reportable segment and revenue category for the six months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:50]
|  |  | For the Six Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 181,935 |  |  | $ | 27,264 |  |  | $ | 209,199 |  |  | $ | 144,607 |  |  | $ | 21,815 |  |  | $ | 166,422 |  |
| Subscriber Solutions & Experience(1) |  |  | 73,163 |  |  |  | 4,092 |  |  |  | 77,255 |  |  |  | 62,083 |  |  |  | 2,578 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 9,891 |  |  |  | 3,837 |  |  |  | 13,728 |  |  |  | 13,626 |  |  |  | 4,145 |  |  |  | 17,771 |  |
| Total |  | $ | 264,989 |  |  | $ | 35,193 |  |  | $ | 300,182 |  |  | $ | 220,316 |  |  | $ | 28,538 |  |  | $ | 248,854 |  |

[0001564590-19-035143:notes:51]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). As of June 30, 2019, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

[0001564590-19-035143:notes:52]
[same as prior period, unchanged from 0001564590-19-016264:notes:50]

[0001564590-19-035143:notes:53]
| (In thousands) |  | June 30, 2019 |  |  | December 31, 2018 |  |
| Accounts receivable, net |  | $ | 116,661 |  |  | $ | 99,385 |  |
| Contract assets(1) |  | $ | 2,251 |  |  | $ | 3,766 |  |
| Unearned revenue |  | $ | 12,910 |  |  | $ | 17,940 |  |
| Non-current unearned revenue |  | $ | 4,265 |  |  | $ | 5,296 |  |

[0001564590-19-035143:notes:54]
|  | (1) | Included in other receivables on the Condensed Consolidated Balance Sheet. |

[0001564590-19-035143:notes:55]
Of the outstanding unearned revenue balance at December 31, 2018, $3.6 million and $10.5 million was recognized as revenue during the three and six months ended June 30, 2019, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-19-035143:notes:56]
The table below presents sales information by category for the three and six months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:57]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Access & Aggregation |  | $ | 109,421 |  |  | $ | 84,742 |  |  | $ | 209,199 |  |  | $ | 166,422 |  |
| Subscriber Solutions & Experience |  |  | 40,502 |  |  |  | 34,560 |  |  |  | 77,255 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 6,468 |  |  |  | 8,746 |  |  |  | 13,728 |  |  |  | 17,771 |  |
| Total |  | $ | 156,391 |  |  | $ | 128,048 |  |  | $ | 300,182 |  |  | $ | 248,854 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-035143:notes:58]
[same as prior period, unchanged from 0001564590-19-016264:notes:55]

[0001564590-19-035143:notes:59]
Our effective tax rate decreased from a benefit of 20.1%, excluding the tax effect of the bargain purchase gain, in the six months ended June 30, 2018, to a benefit of 6.2% in the six months ended June 30, 2019. The decrease in the effective tax rate between the two periods was primarily driven by the shift to profitability in the six months ended June 30, 2019, with tax expense being offset by a 29.1% rate reduction related to a transfer pricing study completed during the second quarter of 2019 that resulted in the assignment of operating expenditures to specific company locations, and the effective income tax rates among the respective jurisdictions.

[0001564590-19-035143:notes:60]
The Company continually reviews the adequacy of the valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of June 30, 2019, we had net deferred tax assets of $39.0 million. Since management continues to assess the realization of these deferred tax assets and related valuation allowance(s), as such, we may release a portion of the valuation allowance or establish a new valuation allowance based on operations in the jurisdictions in which these assets arose. Our assessment includes the evaluation of evidence, some of which requires significant judgment, including historical operating results, the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Due to operating losses incurred in prior quarters in the United States, the Company is currently near breakeven on its three-year cumulative income position for this tax jurisdiction. Should the Company determine that a valuation allowance is needed in the future due to management’s conclusion that it is no longer more likely than not that the Company will be able to utilize its deferred tax assets in a particular jurisdiction, it could have a material effect on our consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-19-035143:notes:61]
[same as prior period, unchanged from 0001564590-19-016264:notes:58]

[0001564590-19-035143:notes:62]
[same as prior period, unchanged from 0001564590-19-016264:notes:59]

[0001564590-19-035143:notes:63]
The following table summarizes the components of net periodic pension cost for the three and six months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Service cost |  | $ | 368 |  |  | $ | 303 |  |  | $ | 743 |  |  | $ | 611 |  |
| Interest cost |  |  | 159 |  |  |  | 185 |  |  |  | 321 |  |  |  | 372 |  |
| Expected return on plan assets |  |  | (348 | ) |  |  | (394 | ) |  |  | (703 | ) |  |  | (793 | ) |
| Amortization of actuarial losses |  |  | 199 |  |  |  | 63 |  |  |  | 402 |  |  |  | 127 |  |
| Net periodic pension cost |  | $ | 378 |  |  | $ | 157 |  |  | $ | 763 |  |  | $ | 317 |  |

[0001564590-19-035143:notes:65]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Condensed Consolidated Statements of Income. Service cost are included in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-035143:notes:66]
[same as prior period, unchanged from 0001564590-19-016264:notes:63]

[0001564590-19-035143:notes:67]
The following table summarizes stock-based compensation expense related to stock options, performance stock units (PSUs), restricted stock units (RSUs) and restricted stock for the three and six months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:68]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 85 |  |  | $ | 102 |  |  | $ | 189 |  |  | $ | 197 |  |
| Selling, general and administrative expense |  |  | 662 |  |  |  | 995 |  |  |  | 1,725 |  |  |  | 2,030 |  |
| Research and development expense |  |  | 707 |  |  |  | 687 |  |  |  | 1,399 |  |  |  | 1,376 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,369 |  |  |  | 1,682 |  |  |  | 3,124 |  |  |  | 3,406 |  |
| Total stock-based compensation expense |  |  | 1,454 |  |  |  | 1,784 |  |  |  | 3,313 |  |  |  | 3,603 |  |
| Tax benefit for expense associated with stock options, PSUs, RSUs and restricted stock |  |  | (332 | ) |  |  | (340 | ) |  |  | (775 | ) |  |  | (724 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,122 |  |  | $ | 1,444 |  |  | $ | 2,538 |  |  | $ | 2,879 |  |

[0001564590-19-035143:notes:69]
[same as prior period, unchanged from 0001564590-19-016264:notes:66]

[0001564590-19-035143:notes:70]
The following table is a summary of our stock options outstanding as of December 31, 2018 and June 30, 2019, and the changes that occurred during the six months ended June 30, 2019:

[0001564590-19-035143:notes:71]
|  |  | Number of Stock Options (in thousands) |  |  | Weighted Avg. Exercise Price (per share) |  |  | Weighted Avg. Remaining Contractual Life (in years) |  |  | Aggregate Intrinsic Value (in thousands) |  |
| Stock options outstanding, December 31, 2018 |  |  | 4,382 |  |  | $ | 22.91 |  |  |  | 4.10 |  |  | $ | — |  |
| Stock options exercised |  |  | (34 | ) |  | $ | 15.53 |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (10 | ) |  | $ | 15.67 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (156 | ) |  | $ | 24.50 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, June 30, 2019 |  |  | 4,182 |  |  | $ | 22.93 |  |  |  | 3.64 |  |  | $ | — |  |
| Stock options exercisable, June 30, 2019 |  |  | 3,942 |  |  | $ | 23.39 |  |  |  | 3.47 |  |  | $ | — |  |

[0001564590-19-035143:notes:72]
At June 30, 2019, total unrecognized compensation expense related to non-vested stock options was approximately $0.3 million, which is expected to be recognized over an average remaining recognition period of 0.4 years.

[0001564590-19-035143:notes:73]
All of the options above were issued at exercise prices that approximated fair market value at the date of grant.

[0001564590-19-035143:notes:74]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on June 30, 2019. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock and was zero as of June 30, 2019. The total pre-tax intrinsic value of options exercised during the six months ended June 30, 2019 was $0.1 million.

[0001564590-19-035143:notes:75]
[same as prior period, unchanged from 0001564590-19-016264:notes:72]

[0001564590-19-035143:notes:76]
There were no stock options granted during the three and six months ended June 30, 2019 or 2018.

[0001564590-19-035143:notes:77]
PSUs, RSUs and Restricted Stock

[0001564590-19-035143:notes:78]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2018 and June 30, 2019 and the changes that occurred during the six months ended June 30, 2019:

[0001564590-19-035143:notes:79]
|  |  | Number of Shares (in thousands) |  |  | Weighted Avg. Grant Date Fair Value (per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2018 |  |  | 1,570 |  |  | $ | 18.52 |  |
| PSUs, RSUs and restricted stock granted |  |  | 59 |  |  | $ | 12.54 |  |
| PSUs, RSUs and restricted stock vested |  |  | (1 | ) |  | $ | 18.86 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (63 | ) |  | $ | 16.66 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, June 30, 2019 |  |  | 1,565 |  |  | $ | 18.37 |  |

[0001564590-19-035143:notes:80]
The fair value of our PSUs with market and performance conditions is calculated using a Monte Carlo simulation valuation method. The fair value of RSUs and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date.

[0001564590-19-035143:notes:81]
At June 30, 2019, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $14.2 million, which is expected to be recognized over an average remaining recognition period of 2.6 years. In addition, there was $8.3 million of unrecognized compensation expense related to unvested 2017 performance-based PSUs, which will be recognized over the remaining requisite service period of 0.5 years if achievement of the performance obligation becomes probable. For the three and six months ending June 30, 2019 and 2018, no compensation expense was recognized related to these 2017 performance-based PSUs.

[0001564590-19-035143:notes:82]
At June 30, 2019, 2.6 million stock options, PSUs, RSUs or restricted stock were available for grant under shareholder-approved equity plans.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-19-035143:notes:83]
7. INVESTMENTS

[0001564590-19-035143:notes:84]
Debt Securities and Other Investments

[0001564590-19-035143:notes:85]
At June 30, 2019, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-19-035143:notes:86]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 14,132 |  |  | $ | 111 |  |  | $ | (4 | ) |  | $ | 14,239 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | (3 | ) |  |  | 927 |  |
| Asset-backed bonds |  |  | 6,580 |  |  |  | 32 |  |  |  | (3 | ) |  |  | 6,609 |  |
| Mortgage/Agency-backed bonds |  |  | 5,362 |  |  |  | 23 |  |  |  | (6 | ) |  |  | 5,379 |  |
| U.S. government bonds |  |  | 5,027 |  |  |  | 6 |  |  |  | (6 | ) |  |  | 5,027 |  |
| Foreign government bonds |  |  | 1,852 |  |  |  | 1 |  |  |  | (1 | ) |  |  | 1,852 |  |
| Available-for-sale debt securities held at fair value |  | $ | 33,883 |  |  | $ | 173 |  |  | $ | (23 | ) |  | $ | 34,033 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,199 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 60,832 |  |

[0001564590-19-035143:notes:87]
At December 31, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-19-035143:notes:88]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 20,777 |  |  | $ | 19 |  |  | $ | (112 | ) |  | $ | 20,684 |  |
| Municipal fixed-rate bonds |  |  | 1,339 |  |  |  | — |  |  |  | (26 | ) |  |  | 1,313 |  |
| Asset-backed bonds |  |  | 5,230 |  |  |  | 5 |  |  |  | (14 | ) |  |  | 5,221 |  |
| Mortgage/Agency-backed bonds |  |  | 3,833 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 3,791 |  |
| U.S. government bonds |  |  | 9,271 |  |  |  | 1 |  |  |  | (66 | ) |  |  | 9,206 |  |
| Foreign government bonds |  |  | 592 |  |  |  | — |  |  |  | (8 | ) |  |  | 584 |  |
| Available-for-sale debt securities held at fair value |  | $ | 41,042 |  |  | $ | 27 |  |  | $ | (270 | ) |  | $ | 40,799 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 397 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 66,796 |  |

[0001564590-19-035143:notes:89]
As of June 30, 2019, our debt securities had the following contractual maturities:

[0001564590-19-035143:notes:90]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 2,749 |  |  | $ | — |  |  | $ | 96 |  |  | $ | — |  |  | $ | 2,443 |  |  | $ | — |  |
| One to two years |  |  | 8,460 |  |  |  | 927 |  |  |  | 430 |  |  |  | 264 |  |  |  | — |  |  |  | 891 |  |
| Two to three years |  |  | 3,030 |  |  |  | — |  |  |  | 1,667 |  |  |  | 588 |  |  |  | 1,346 |  |  |  | 961 |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 2,018 |  |  |  | 510 |  |  |  | 1,238 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,772 |  |  |  | 425 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 626 |  |  |  | 3,592 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 14,239 |  |  | $ | 927 |  |  | $ | 6,609 |  |  | $ | 5,379 |  |  | $ | 5,027 |  |  | $ | 1,852 |  |

[0001564590-19-035143:notes:91]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-19-035143:notes:92]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:

[0001564590-19-035143:notes:93]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Gross realized gains on debt securities |  | $ | 8 |  |  | $ | 25 |  |  | $ | 49 |  |  | $ | 25 |  |
| Gross realized losses on debt securities |  |  | (14 | ) |  |  | (241 | ) |  |  | (33 | ) |  |  | (315 | ) |
| Total gain (loss) recognized, net |  | $ | (6 | ) |  | $ | (216 | ) |  | $ | 16 |  |  | $ | (290 | ) |

[0001564590-19-035143:notes:94]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-19-035143:notes:95]
At June 30, 2019, we held a $25.6 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the “Bond”), which totaled $25.6 million at June 30, 2019 and December 31, 2018. At June 30, 2019 and December 31, 2018, the estimated fair value of the Bond using a level 2 valuation technique was approximately $25.6 million and $25.4 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to offset the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the State of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. We have made annual principal payments in addition to the interest amounts that are due. The restricted funds held as collateral against the outstanding principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity on January 1, 2020.

[0001564590-19-035143:notes:96]
Marketable Equity Securities

[0001564590-19-035143:notes:97]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost (where appropriate).

[0001564590-19-035143:notes:98]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to retained earnings.

[0001564590-19-035143:notes:99]
ASU 2016-01 also provides a measurement alternative for equity investments that do not have a readily determinable fair value in which investments can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. We elected to record our equity investment that does not have a readily determinable fair value using the measurement alternative method. As of December 31, 2018, the Company had a note receivable of approximately $4.3 million, which was included in other receivables on the Condensed Consolidated Balance Sheet. During the three months ended March 31, 2019, this amount was repaid as follows. Approximately $3.4 million was issued as an equity investment, which represented a non-cash investing activity. The carrying value of this investment under the measurement alternative was $3.4 million as of June 30, 2019. The remaining amount was converted into a new note receivable, which is included in other receivables on the Condensed Consolidated Balance Sheet and represents a non-cash operating activity.

[0001564590-19-035143:notes:100]
Realized and unrealized gains and losses for our marketable equity securities for the three and six months ended June 30, 2019 and 2018 were as follows:

[0001564590-19-035143:notes:101]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (49 | ) |  | $ | (52 | ) |  | $ | (63 | ) |  | $ | 347 |  |
| Unrealized gains on equity securities held |  |  | 2,540 |  |  |  | 1,258 |  |  |  | 8,458 |  |  |  | 836 |  |
| Total gain recognized, net |  | $ | 2,491 |  |  | $ | 1,206 |  |  | $ | 8,395 |  |  | $ | 1,183 |  |

[0001564590-19-035143:notes:102]
As of June 30, 2019 and 2018, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.

[0001564590-19-035143:notes:103]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-19-035143:notes:104]
|  |  |  |  |  |  | Fair Value Measurements at June 30, 2019 Using |  |
| (In thousands) |  | Cost or Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,337 |  |  | $ | 1,337 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 2,973 |  |  |  | — |  |  |  | 2,973 |  |  |  | — |  |
| Cash equivalents |  |  | 4,310 |  |  |  | 1,337 |  |  |  | 2,973 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 14,239 |  |  |  | — |  |  |  | 14,239 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 927 |  |  |  | — |  |  |  | 927 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,609 |  |  |  | — |  |  |  | 6,609 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,379 |  |  |  | — |  |  |  | 5,379 |  |  |  | — |  |
| U.S. government bonds |  |  | 5,027 |  |  |  | 5,027 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,852 |  |  |  | — |  |  |  | 1,852 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 32,548 |  |  |  | 32,548 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 185 |  |  |  | 185 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,228 |  |  |  | 21,228 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 87,994 |  |  |  | 58,988 |  |  |  | 29,006 |  |  |  | — |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other investments |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other investments held at cost |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 95,679 |  |  | $ | 60,325 |  |  | $ | 31,979 |  |  | $ | — |  |

[0001564590-19-035143:notes:105]
|  |  |  |  |  |  | Fair Value Measurements at December 31, 2018 Using |  |
| (In thousands) |  | Cost or Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,554 |  |  | $ | 1,554 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 1,554 |  |  |  | 1,554 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,684 |  |  |  | — |  |  |  | 20,684 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,313 |  |  |  | — |  |  |  | 1,313 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,221 |  |  |  | — |  |  |  | 5,221 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 3,791 |  |  |  | — |  |  |  | 3,791 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,206 |  |  |  | 9,206 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 584 |  |  |  | — |  |  |  | 584 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,763 |  |  |  | 26,763 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 253 |  |  |  | 253 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 18,256 |  |  |  | 18,256 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 86,071 |  |  |  | 54,478 |  |  |  | 31,593 |  |  |  | — |  |
| Total |  | $ | 87,625 |  |  | $ | 56,032 |  |  | $ | 31,593 |  |  | $ | — |  |

[0001564590-19-035143:notes:106]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:InventoryDisclosureTextBlock

[0001564590-19-035143:notes:107]
8. INVENTORY

[0001564590-19-035143:notes:108]
At June 30, 2019 and December 31, 2018, inventory consisted of the following:

[0001564590-19-035143:notes:109]
|  |  | June 30, |  |  | December 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Raw materials |  | $ | 38,844 |  |  | $ | 45,333 |  |
| Work in process |  |  | 1,383 |  |  |  | 1,638 |  |
| Finished goods |  |  | 54,883 |  |  |  | 52,877 |  |
| Total |  | $ | 95,110 |  |  | $ | 99,848 |  |

[0001564590-19-035143:notes:110]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on historical usage, known trends, inventory age, and market conditions. At June 30, 2019 and December 31, 2018, our inventory reserve was $31.0 million and $30.0 million, respectively.


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-19-035143:notes:111]
9. GOODWILL

[0001564590-19-035143:notes:112]
Goodwill, all of which relates to our acquisitions of Bluesocket, Inc. in 2011 and SmartRG in 2018, was $7.0 million and $7.1 million at June 30, 2019 and December 31, 2018, respectively, of which $6.6 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively, as of June 30, 2019, and of which $6.7 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively, as of December 31, 2018. Goodwill related to our SmartRG acquisition was reduced by $0.1 million during the six months ended June 30, 2019, as a result of a measurement period adjustment.

[0001564590-19-035143:notes:113]
[same as prior period, unchanged from 0001564590-19-016264:notes:119]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-19-035143:notes:114]
10. INTANGIBLE ASSETS

[0001564590-19-035143:notes:115]
Intangible assets include intangibles acquired in conjunction with several acquisitions since 2011, with the most recent being SmartRG, Inc. in November 2018.

[0001564590-19-035143:notes:116]
The following table presents our intangible assets as of June 30, 2019 and December 31, 2018:

[0001564590-19-035143:notes:117]
|  |  | June 30, 2019 |  |  | December 31, 2018 |  |
| (In thousands) |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 22,414 |  |  | $ | (6,311 | ) |  | $ | 16,103 |  |  | $ | 22,455 |  |  | $ | (5,380 | ) |  | $ | 17,075 |  |
| Developed technology |  |  | 10,170 |  |  |  | (2,810 | ) |  |  | 7,360 |  |  |  | 12,801 |  |  |  | (4,867 | ) |  |  | 7,934 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (847 | ) |  |  | 5,053 |  |  |  | 5,900 |  |  |  | (520 | ) |  |  | 5,380 |  |
| Supplier relationships |  |  | 2,800 |  |  |  | (1,808 | ) |  |  | 992 |  |  |  | 2,800 |  |  |  | (1,108 | ) |  |  | 1,692 |  |
| Licensing agreements |  |  | 560 |  |  |  | (43 | ) |  |  | 517 |  |  |  | 560 |  |  |  | (5 | ) |  |  | 555 |  |
| Patents |  |  | 500 |  |  |  | (191 | ) |  |  | 309 |  |  |  | 500 |  |  |  | (157 | ) |  |  | 343 |  |
| Trade names |  |  | 310 |  |  |  | (141 | ) |  |  | 169 |  |  |  | 310 |  |  |  | (106 | ) |  |  | 204 |  |
| Total |  | $ | 42,654 |  |  | $ | (12,151 | ) |  | $ | 30,503 |  |  | $ | 45,326 |  |  | $ | (12,143 | ) |  | $ | 33,183 |  |

[0001564590-19-035143:notes:118]
Amortization expense was $1.3 million and $1.0 million for the three months ended June 30, 2019 and 2018 respectively, and $2.7 million and $1.5 million for the six months ended June 30, 2019 and 2018.

[0001564590-19-035143:notes:119]
As of June 30, 2019, the estimated future amortization expense of our intangible assets was as follows:

[0001564590-19-035143:notes:120]
| (In thousands) |  | Amount |  |
| Remainder of 2019 |  | $ | 2,665 |  |
| 2020 |  |  | 4,448 |  |
| 2021 |  |  | 4,099 |  |
| 2022 |  |  | 3,475 |  |
| 2023 |  |  | 3,322 |  |
| Thereafter |  |  | 12,494 |  |
| Total |  | $ | 30,503 |  |


## adtn:LeasesDisclosureTextBlock

[0001564590-19-035143:notes:121]
11. LEASES

[0001564590-19-035143:notes:122]
[same as prior period, unchanged from 0001564590-19-016264:notes:128]

[0001564590-19-035143:notes:123]
We have operating leases for office space, automobiles, and various other equipment in the United States and in certain international locations in which we do business. We also have other contracts, such as manufacturing agreements and service agreements, which we reviewed to determine if they contain any embedded leases. We specifically reviewed these other contracts to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease.

[0001564590-19-035143:notes:124]
As of June 30, 2019, our operating leases have remaining lease terms of one month to six years, some of which include options to extend the leases for up to three years, and some of which include options to terminate the leases within three months. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and right of use liability. Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. Lease expense related to these short-term leases was $0.1 million and $0.3 million for the three and six months ended June 30, 2019, respectively, and is included in selling, general and administrative expenses on the Condensed Consolidated Statements of Income. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected the practical expedient which allows us to not separate lease and non-lease components. None of our lease agreements contain any material residual value guarantees or material restrictive covenants.

[0001564590-19-035143:notes:125]
[same as prior period, unchanged from 0001564590-19-016264:notes:131]

[0001564590-19-035143:notes:126]
|  |  |  |  | June 30, |  |  | January 1, |  |
| (In thousands) |  | Classification |  | 2019 |  |  | 2019 (1) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |
| Operating lease asset |  | Other assets |  | $ | 8,838 |  |  | $ | 10,322 |  |
| Total lease assets |  |  |  | $ | 8,838 |  |  | $ | 10,322 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses |  | $ | 2,514 |  |  | $ | 2,948 |  |
| Non-current operating lease liability |  | Other non-current liabilities |  |  | 6,349 |  |  |  | 7,374 |  |
| Total lease liability |  |  |  | $ | 8,863 |  |  | $ | 10,322 |  |

[0001564590-19-035143:notes:127]
|  | (1) | Reflects the adoption of the new lease accounting standard on January 1, 2019. |

[0001564590-19-035143:notes:128]
The components of lease expense included in the Condensed Consolidated Statements of Income for the three and six months ended June 30, 2019 are as follows:

[0001564590-19-035143:notes:129]
| (In thousands) |  | Three Months Ended June 30, 2019 |  |  | Six Months Ended June 30, 2019 |  |
| Selling, general and administrative expenses |  | $ | 349 |  |  | $ | 698 |  |
| Research and development expenses |  |  | 430 |  |  |  | 884 |  |
| Cost of sales |  |  | 17 |  |  |  | 33 |  |
| Total operating lease expense |  | $ | 796 |  |  | $ | 1,615 |  |

[0001564590-19-035143:notes:130]
As of June 30, 2019, operating lease liabilities included on the Condensed Consolidated Balance Sheet by future maturity are as follows:

[0001564590-19-035143:notes:131]
| (In thousands) |  | Amount |  |
| Remainder of 2019 |  | $ | 1,583 |  |
| 2020 |  |  | 2,203 |  |
| 2021 |  |  | 2,047 |  |
| 2022 |  |  | 1,560 |  |
| 2023 |  |  | 1,173 |  |
| Thereafter |  |  | 756 |  |
| Total lease payments |  |  | 9,322 |  |
| Less: Interest |  |  | (459 | ) |
| Present value of lease liabilities |  | $ | 8,863 |  |

[0001564590-19-035143:notes:132]
Operating lease payments include $1.2 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0001564590-19-035143:notes:133]
As of December 31, 2018, future minimum rental payments under non-cancelable operating leases, including renewals determined to be reasonably assured as of December 31, 2018, with original maturities of greater than 12 months, are as follows:

[0001564590-19-035143:notes:134]
[same as prior period, unchanged from 0001564590-19-016264:notes:139]

[0001564590-19-035143:notes:135]
|  | (1) | Certain renewal options were subsequently determined to not be reasonably assured of renewal upon the Company’s adoption of the new lease accounting standard on January 1, 2019. |

[0001564590-19-035143:notes:136]
[same as prior period, unchanged from 0001564590-19-016264:notes:141]

[0001564590-19-035143:notes:137]
|  |  | As of June 30, 2019 |  |
| Weighted average remaining lease term (years) |  |  |  |  |
| Operating leases with USD functional currency |  |  | 2.9 |  |
| Operating leases with Euro functional currency |  |  | 4.8 |  |
| Weighted average discount rate |  |  |  |  |
| Operating leases with USD functional currency |  |  | 4.61 | % |
| Operating leases with Euro functional currency |  |  | 1.85 | % |

[0001564590-19-035143:notes:138]
Supplemental cash flow information related to operating leases was as follows:

[0001564590-19-035143:notes:139]
| (In thousands) |  | As of June 30, 2019 |  |
| Cash paid for amounts included in the measurement of operating lease liabilities / assets |  |  |  |  |
| Cash used in operating activities related to operating leases |  | $ | (797 | ) |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 10,396 |  |

[0001564590-19-035143:notes:140]
[same as prior period, unchanged from 0001564590-19-016264:notes:145]

[0001564590-19-035143:notes:141]
We are the lessor in sales-type lease arrangements for network equipment, which have initial terms of up to five years. Our sales-type lease arrangements contain either a provision whereby the network equipment reverts back to us upon the expiration of the lease or a provision that allows the lessee to purchase the network equipment at a bargain purchase amount. In addition, our sales-type lease arrangements do not contain any residual value guarantees or material restrictive covenants. The allocation of the consideration between lease and non-lease components is determined by standalone sales price by component. The net investment in sales-type leases consists of lease receivables less unearned income. Collectability of sales-type leases is evaluated periodically at an individual customer level. At June 30, 2019 and December 31, 2018, we had no allowance for credit losses for our net investment in sales-type leases. As of June 30, 2019 and December 31, 2018, the components of the net investment in sales-type leases were as follows:

[0001564590-19-035143:notes:142]
|  |  | June 30, |  |  | December 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Current minimum lease payments receivable (included in other receivables) |  | $ | 6,360 |  |  | $ | 11,339 |  |
| Non-current minimum lease payments receivable (included in other assets) |  |  | 1,286 |  |  |  | 1,670 |  |
| Total minimum lease payments receivable |  |  | 7,646 |  |  |  | 13,009 |  |
| Less: Current unearned revenue |  |  | 495 |  |  |  | 631 |  |
| Less: Non-current unearned revenue |  |  | 269 |  |  |  | 473 |  |
| Net investment in sales-type leases |  | $ | 6,882 |  |  | $ | 11,905 |  |

[0001564590-19-035143:notes:143]
The components of sales-type lease gross profit recognized at the lease commencement date and interest and dividend income, included in the Condensed Consolidated Statements of Income for the three and six months ended June 30, 2019, are as follows:

[0001564590-19-035143:notes:144]
| (In thousands) |  | Classification |  | Three Months Ended June 30, 2019 |  |  | Six Months Ended June 30, 2019 |  |
| Sales type leases |  | Sales - Network Solutions |  | $ | 109 |  |  | $ | 1,621 |  |
| Sales type leases |  | Cost of sales - Network Solutions |  |  | 44 |  |  |  | 635 |  |
| Sales type leases |  | Gross profit |  | $ | 65 |  |  | $ | 986 |  |
| Sales type leases |  | Interest and dividend income |  | $ | 99 |  |  | $ | 186 |  |

[0001564590-19-035143:notes:145]
As of June 30, 2019, future minimum lease payments to be received from sales-type leases are as follows:

[0001564590-19-035143:notes:146]
| (In thousands) |  | Amount |  |
| Remainder of 2019 |  | $ | 5,705 |  |
| 2020 |  |  | 1,112 |  |
| 2021 |  |  | 525 |  |
| 2022 |  |  | 220 |  |
| 2023 |  |  | 81 |  |
| Thereafter |  |  | 3 |  |
| Total |  | $ | 7,646 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-19-035143:notes:147]
12. STOCKHOLDERS’ EQUITY

[0001564590-19-035143:notes:148]
[same as prior period, unchanged from 0001564590-19-016264:notes:154]

[0001564590-19-035143:notes:149]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized repurchases of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2019, we repurchased 13,000 shares of our common stock at an average price of $14.06 per share. As of June 30, 2019, we had the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-19-035143:notes:150]
[same as prior period, unchanged from 0001564590-19-016264:notes:156]

[0001564590-19-035143:notes:151]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the three months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:152]
|  |  | Three Months Ended June 30, 2019 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| As of March 31, 2019 |  | $ | (378 | ) |  | $ | (7,920 | ) |  | $ | (6,972 | ) |  | $ | 385 |  |  | $ | (14,885 | ) |
| Other comprehensive income before reclassifications |  |  | 180 |  |  |  | — |  |  |  | 533 |  |  |  | — |  |  |  | 713 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (73 | ) |  |  | 150 |  |  |  | — |  |  |  | — |  |  |  | 77 |  |
| Net current period other comprehensive income |  |  | 107 |  |  |  | 150 |  |  |  | 533 |  |  |  | — |  |  |  | 790 |  |
| As of June 30, 2019 |  | $ | (271 | ) |  | $ | (7,770 | ) |  | $ | (6,439 | ) |  | $ | 385 |  |  | $ | (14,095 | ) |

[0001564590-19-035143:notes:153]
|  | (1) | With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings. See Note 1. |

[0001564590-19-035143:notes:154]
|  |  | Three Months Ended June 30, 2018 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| As of March 31, 2018 |  | $ | (845 | ) |  | $ | (4,224 | ) |  | $ | (734 | ) |  | $ | (5,803 | ) |
| Other comprehensive loss before reclassifications |  |  | (82 | ) |  |  | — |  |  |  | (3,424 | ) |  |  | (3,506 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | 186 |  |  |  | 5 |  |  |  | — |  |  |  | 191 |  |
| Net current period other comprehensive income (loss) |  |  | 104 |  |  |  | 5 |  |  |  | (3,424 | ) |  |  | (3,315 | ) |
| As of June 30, 2018 |  | $ | (741 | ) |  | $ | (4,219 | ) |  | $ | (4,158 | ) |  | $ | (9,118 | ) |

[0001564590-19-035143:notes:155]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the six months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:156]
|  |  | Six Months Ended June 30, 2019 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2018 |  | $ | (563 | ) |  | $ | (8,041 | ) |  | $ | (5,812 | ) |  | $ | — |  |  | $ | (14,416 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 411 |  |  |  | — |  |  |  | (627 | ) |  |  | — |  |  |  | (216 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (119 | ) |  |  | 271 |  |  |  | — |  |  |  | — |  |  |  | 152 |  |
| Amounts reclassified to retained earnings (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |  |  | 385 |  |
| Net current period other comprehensive income (loss) |  |  | 292 |  |  |  | 271 |  |  |  | (627 | ) |  |  | 385 |  |  |  | 321 |  |
| As of June 30, 2019 |  | $ | (271 | ) |  | $ | (7,770 | ) |  | $ | (6,439 | ) |  | $ | 385 |  |  | $ | (14,095 | ) |

[0001564590-19-035143:notes:157]
|  |  | Six Months Ended June 30, 2018 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| As of December 31, 2017 |  | $ | 2,567 |  |  | $ | (4,286 | ) |  | $ | (1,576 | ) |  | $ | (3,295 | ) |
| Other comprehensive (loss) before reclassifications |  |  | (339 | ) |  |  | — |  |  |  | (2,582 | ) |  |  | (2,921 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | 251 |  |  |  | 67 |  |  |  | — |  |  |  | 318 |  |
| Amounts reclassified to retained earnings (1) |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |
| Net current period other comprehensive income (loss) |  |  | (3,308 | ) |  |  | 67 |  |  |  | (2,582 | ) |  |  | (5,823 | ) |
| As of June 30, 2018 |  | $ | (741 | ) |  | $ | (4,219 | ) |  | $ | (4,158 | ) |  | $ | (9,118 | ) |

[0001564590-19-035143:notes:158]
|  | (1) | With the Company’s adoption of ASU 2016-01 on January 1, 2018, unrealized gains on our equity investments were reclassified to retained earnings. See Note 7. |

[0001564590-19-035143:notes:159]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the three months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:160]
|  |  | Three Months Ended June 30, 2019 |
| Details about Accumulated Other Comprehensive Income (Loss) Components (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 99 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (217 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (118 | ) |  |  |
| Tax benefit |  |  | 41 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (77 | ) |  |  |

[0001564590-19-035143:notes:161]
[same as prior period, unchanged from 0001564590-19-016264:notes:165]

[0001564590-19-035143:notes:162]
|  |  | Three Months Ended June 30, 2018 |
| Details about Accumulated Other Comprehensive Income (Loss) Components (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gain (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized losses on sales of securities |  | $ | (251 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (7 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (258 | ) |  |  |
| Tax benefit |  |  | 67 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (191 | ) |  |  |

[0001564590-19-035143:notes:163]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the six months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:164]
|  |  | Six Months Ended June 30, 2019 |
| Details about Accumulated Other Comprehensive Income (Loss) Components (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 161 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (393 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (232 | ) |  |  |
| Tax benefit |  |  | 80 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (152 | ) |  |  |

[0001564590-19-035143:notes:165]
|  |  | Six Months Ended June 30, 2018 |
| Details about Accumulated Other Comprehensive Income (Loss) Components (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized losses on sales of securities |  | $ | (324 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (97 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (421 | ) |  |  |
| Tax benefit |  |  | 103 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (318 | ) |  |  |

[0001564590-19-035143:notes:166]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss) for the three months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:167]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 243 |  |  | $ | (63 | ) |  | $ | 180 |  |  | $ | (111 | ) |  | $ | 29 |  |  | $ | (82 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | (99 | ) |  |  | 26 |  |  |  | (73 | ) |  |  | 251 |  |  |  | (65 | ) |  |  | 186 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 217 |  |  |  | (67 | ) |  |  | 150 |  |  |  | 7 |  |  |  | (2 | ) |  |  | 5 |  |
| Foreign currency translation adjustment |  |  | 533 |  |  |  | — |  |  |  | 533 |  |  |  | (3,424 | ) |  |  | — |  |  |  | (3,424 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 894 |  |  | $ | (104 | ) |  | $ | 790 |  |  | $ | (3,277 | ) |  | $ | (38 | ) |  | $ | (3,315 | ) |

[0001564590-19-035143:notes:168]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss) for the six months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:169]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 555 |  |  | $ | (144 | ) |  | $ | 411 |  |  | $ | (458 | ) |  | $ | 119 |  |  | $ | (339 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | (161 | ) |  |  | 42 |  |  |  | (119 | ) |  |  | 324 |  |  |  | (73 | ) |  |  | 251 |  |
| Reclassification adjustment for amounts reclassed to retained earnings related to the adoption of ASU 2016-01 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |  |  | — |  |  |  | (3,220 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 393 |  |  |  | (122 | ) |  |  | 271 |  |  |  | 97 |  |  |  | (30 | ) |  |  | 67 |  |
| Foreign currency translation adjustment |  |  | (627 | ) |  |  | — |  |  |  | (627 | ) |  |  | (2,582 | ) |  |  | — |  |  |  | (2,582 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 160 |  |  | $ | (224 | ) |  | $ | (64 | ) |  | $ | (5,839 | ) |  | $ | 16 |  |  | $ | (5,823 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-035143:notes:170]
13. EARNINGS (LOSS) PER SHARE

[0001564590-19-035143:notes:171]
A summary of the calculation of basic and diluted earnings (loss) per share for the three and six months ended June 30, 2019 and 2018 is as follows:

[0001564590-19-035143:notes:172]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 3,995 |  |  | $ | (7,670 | ) |  | $ | 4,765 |  |  | $ | (18,484 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,802 |  |  |  | 47,856 |  |  |  | 47,792 |  |  |  | 48,043 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 7 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | 227 |  |  |  | — |  |  |  | 147 |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 48,036 |  |  |  | 47,856 |  |  |  | 47,939 |  |  |  | 48,043 |  |
| Earnings (loss) per share – basic |  | $ | 0.08 |  |  | $ | (0.16 | ) |  | $ | 0.10 |  |  | $ | (0.38 | ) |
| Earnings (loss) per share – diluted |  | $ | 0.08 |  |  | $ | (0.16 | ) |  | $ | 0.10 |  |  | $ | (0.38 | ) |

[0001564590-19-035143:notes:173]
For the three months ended June 30, 2019 and 2018, 1.9 million and 5.0 million, respectively, and for the six months ended June 30, 2019 and 2018, 2.3 million and 4.8 million, respectively, stock options were outstanding but were not included in the computation of diluted earnings (loss) per share because the stock options’ exercise prices were greater than the average market price of the common shares, during the applicable periods, therefore making them anti-dilutive under the treasury stock method. For the three months ended June 30, 2019 and 2018, 15,000 and 0.1 million, respectively, and for both the six months ended June 30, 2019 and 2018, 0.1 million PSUs, RSUs and restricted stock awards were not included in the computation of diluted earnings (loss) per share because the weighted average assumed proceeds per share were greater than the average market price of the common shares, during the applicable periods, therefore making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-035143:notes:174]
14. SEGMENT INFORMATION

[0001564590-19-035143:notes:175]
[same as prior period, unchanged from 0001564590-19-016264:notes:174]

[0001564590-19-035143:notes:176]
We evaluate the performance of our segments based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain, other income (expense) and (provision) benefit for income taxes are reported on a company-wide, functional basis only. There is no inter-segment revenue.

[0001564590-19-035143:notes:177]
The following table presents information about the reported sales and gross profit of our reportable segments for the three and six months ended June 30, 2019 and 2018. We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-19-035143:notes:178]
|  |  | Three Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 139,167 |  |  | $ | 58,992 |  |  | $ | 115,063 |  |  | $ | 45,434 |  |
| Services & Support |  |  | 17,224 |  |  |  | 6,023 |  |  |  | 12,985 |  |  |  | 4,562 |  |
| Total |  | $ | 156,391 |  |  | $ | 65,015 |  |  | $ | 128,048 |  |  | $ | 49,996 |  |

[0001564590-19-035143:notes:179]
|  |  | Six Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 264,989 |  |  | $ | 114,080 |  |  | $ | 220,316 |  |  | $ | 82,075 |  |
| Services & Support |  |  | 35,193 |  |  |  | 11,547 |  |  |  | 28,538 |  |  |  | 7,654 |  |
| Total |  | $ | 300,182 |  |  | $ | 125,627 |  |  | $ | 248,854 |  |  | $ | 89,729 |  |

[0001564590-19-035143:notes:180]
[same as prior period, unchanged from 0001564590-19-016264:notes:178]

[0001564590-19-035143:notes:181]
[same as prior period, unchanged from 0001564590-19-016264:notes:179]

[0001564590-19-035143:notes:182]
The following table represents sales information by geographic area for the three and six months ended June 30, 2019 and 2018:

[0001564590-19-035143:notes:183]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| United States |  | $ | 75,288 |  |  | $ | 68,222 |  |  | $ | 147,816 |  |  | $ | 130,308 |  |
| International |  |  | 81,103 |  |  |  | 59,826 |  |  |  | 152,366 |  |  |  | 118,546 |  |
| Total |  | $ | 156,391 |  |  | $ | 128,048 |  |  | $ | 300,182 |  |  | $ | 248,854 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-19-035143:notes:184]
15. LIABILITY FOR WARRANTY RETURNS

[0001564590-19-035143:notes:185]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $9.0 million and $8.6 million at June 30, 2019 and December 31, 2018, respectively, which amounts are included in accrued expenses in the accompanying Condensed Consolidated Balance Sheets.

[0001564590-19-035143:notes:186]
A reconciliation of the beginning and ending warranty accrual for the three and six months ended June 30, 2019 and 2018 is as follows:

[0001564590-19-035143:notes:187]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Warranty accrual at beginning of period |  | $ | 8,802 |  |  | $ | 9,687 |  |  | $ | 8,623 |  |  | $ | 9,724 |  |
| Plus: Amounts charged to expense |  |  | 1,849 |  |  |  | 4,860 |  |  |  | 2,980 |  |  |  | 6,683 |  |
| Less: Deductions |  |  | (1,679 | ) |  |  | (4,436 | ) |  |  | (2,631 | ) |  |  | (6,296 | ) |
| Warranty accrual at end of period |  | $ | 8,972 |  |  | $ | 10,111 |  |  | $ | 8,972 |  |  | $ | 10,111 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-035143:notes:188]
16. COMMITMENTS AND CONTINGENCIES

[0001564590-19-035143:notes:189]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants may seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-19-035143:notes:190]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied to these commitments as of June 30, 2019.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-035143:notes:191]
17. RESTRUCTURING

[0001564590-19-035143:notes:192]
In February 2019, we announced the restructuring of certain of our workforce predominantly in Germany, which included the closure of the office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. We also offered voluntary early retirement to certain other employees, which was announced to employees in March 2019.  The restructuring is expected to be completed in the fourth quarter of 2019.

[0001564590-19-035143:notes:193]
In January 2018, we announced an early retirement incentive program for employees that met certain requirements. The cumulative amount incurred during the year ended December 31, 2018 related to this restructuring program was $7.3 million, of which $1.0 million and $7.0 million was incurred during the three and six months ended June 30, 2018, respectively. We do not expect to incur any additional expenses related to this restructuring program.

[0001564590-19-035143:notes:194]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits on the Condensed Consolidated Balance Sheet, is as follows:

[0001564590-19-035143:notes:195]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 1,971 |  |  | $ | 185 |  |
| Plus: Amounts charged to cost and expense |  |  | 1,400 |  |  |  | 3,463 |  |
| Less: Amounts paid |  |  | (716 | ) |  |  | (993 | ) |
| Balance at end of period |  | $ | 2,655 |  |  | $ | 2,655 |  |

[0001564590-19-035143:notes:196]
The components of restructuring expense in the Condensed Consolidated Statements of Income are as follows:

[0001564590-19-035143:notes:197]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Selling, general and administrative expenses |  | $ | 703 |  |  | $ | 634 |  |  | $ | 1,547 |  |  | $ | 2,400 |  |
| Research and development expenses |  |  | 647 |  |  |  | — |  |  |  | 1,231 |  |  |  | 1,814 |  |
| Cost of sales |  |  | 50 |  |  |  | 391 |  |  |  | 685 |  |  |  | 2,761 |  |
| Total restructuring expenses |  | $ | 1,400 |  |  | $ | 1,025 |  |  | $ | 3,463 |  |  | $ | 6,975 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-19-035143:notes:198]
18. SUBSEQUENT EVENTS

[0001564590-19-035143:notes:199]
On July 17, 2019, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on August 1, 2019. The dividend was paid on August 15, 2019 and totaled $4.3 million.

[0001564590-19-035143:notes:200]
In September 2019, we entered into an operating lease for office space in India. This lease has an initial term of five years and includes an option to renew for an additional five-year period. As a result of this agreement, we will record a right-of-use asset and corresponding lease liability of approximately $10.2 million in our Condensed Consolidated Balance Sheet during the third quarter of 2019.
