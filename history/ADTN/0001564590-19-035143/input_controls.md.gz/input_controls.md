# ADTN 10-Q controls and the auditor's report


## item_4_controls

[0001564590-19-035143:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001564590-19-035143:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures. We maintain disclosure controls and procedures that are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized, and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosure. Because of the inherent limitations to the effectiveness of any system of disclosure controls and procedures, no evaluation of disclosure controls and procedures can provide absolute assurance that all control issues, if any, with a company have been prevented or detected on a timely basis. Even disclosure controls and procedures determined to be effective can only provide reasonable assurance that their objectives are achieved.

[0001564590-19-035143:item_4_controls:3]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures (as defined in Exchange Act Rule 13a-15(e)) pursuant to Rule 13a-15 of the Exchange Act. Based upon that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were not effective as of June 30, 2019 due to the material weaknesses in our internal control over financial reporting described in the 2018 Form 10-K and below.

[0001564590-19-035143:item_4_controls:4]
Material Weaknesses

[0001564590-19-035143:item_4_controls:5]
A material weakness is a significant deficiency, or a combination of significant deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim consolidated financial statements will not be prevented or detected and corrected on a timely basis. On August 8, 2019, the Company’s management, in consultation with the Audit Committee of the Board of Directors, concluded that there were two material weaknesses related to internal control deficiencies that existed as of December 31, 2018 and that continued through the end of the second quarter of 2019. Specifically, the Company’s management determined that the Company did not design and maintain effective internal control over certain aspects of the existence and valuation of inventory:

[0001564590-19-035143:item_4_controls:6]
|  | • | Management determined that controls were not effectively designed, documented, and maintained to verify that the existence of all inventories subject to our cycle count program were included and counted at the frequency required under the Company’s internal policies, and that the key reports and related data used to monitor the results of this program were not validated to ensure completeness and accuracy. |

[0001564590-19-035143:item_4_controls:7]
|  | • | Management determined that controls were not effectively designed and maintained over the determination of the estimated reserve for excess and obsolete inventory, including the review of significant inputs and assumptions used to determine our excess and obsolete inventory reserve, and to ensure the completeness and accuracy of key reports and related data used in the calculation of this reserve. |

[0001564590-19-035143:item_4_controls:8]
Despite the existence of these material weaknesses, we believe that the consolidated financial statements included in this report (as well as the financial statements included in the Form 10-Q for the period ended March 31, 2019) present fairly, in all material respects, our financial position, results of operations, and cash flows for the periods presented, in conformity with accounting principles generally accepted in the United States of America. These material weaknesses did not result in any material misstatement to the Company’s financial statements or disclosures but did result in an out-of-period adjustment with the effect of increasing cost of goods sold during the three months ended June 30, 2019 and decreasing cost of goods sold for the six months ended June 30, 2019. However, these material weaknesses could result in a misstatement of the Company’s interim or annual consolidated financial statements and disclosures that would result in a material misstatement that would not be prevented or detected.

[0001564590-19-035143:item_4_controls:9]
(b) Changes in Internal Control over Financial Reporting. There were no changes in our internal control over financial reporting that occurred during our most recent fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001564590-19-035143:item_4_controls:10]
43

[0001564590-19-035143:item_4_controls:11]
(c) Management’s Remediation Initiatives. Management has been working to further strengthen the Company’s internal controls relating to inventory. Specifically, the Company has begun redesigning and enhancing additional controls and procedures to ensure the completeness of our cycle count program and the completeness and accuracy of key reports and related data used to monitor the results of this cycle count program. Additionally, the Company has begun redesigning and implementing enhanced controls and procedures related to the review of significant inputs and assumptions used to determine our excess and obsolete inventory reserve, and to ensure the completeness and accuracy of key reports and related data used in the calculation of the excess and obsolete inventory reserve. We believe that the foregoing actions will support the improvement of our internal control over financial reporting, and, through our efforts to identify, design, and implement the necessary control activities, will be effective in remediating the material weaknesses described above. We will continue to devote significant time and attention to these remediation efforts. As we continue to evaluate and work to improve our internal control over financial reporting, management may determine to take additional measures to address the material weaknesses or determine to modify the remediation plan described above. Until the remediation steps set forth above, including the efforts to implement the necessary control activities that we identify, are fully completed, the material weaknesses described above will continue to exist.

[0001564590-19-035143:item_4_controls:12]
44
