# ADTN notes — 0000950123-11-045439


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950123-11-045439:notes:1]
[same as prior period, unchanged from 0000950123-10-099391:notes:1]

[0000950123-11-045439:notes:2]
[same as prior period, unchanged from 0000950123-10-099391:notes:2]

[0000950123-11-045439:notes:3]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its
   subsidiaries (ADTRAN) have been prepared pursuant to the rules and regulations for reporting on
   Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally
   accepted accounting principles for complete financial statements are not included herein. The
   December 31, 2010 Consolidated Balance Sheet is derived from audited financial statements, but does
   not include all disclosures required by accounting principles generally accepted in the United
   States.

[0000950123-11-045439:notes:4]
In the opinion of management, all adjustments necessary for a fair presentation of these interim
   statements have been included and are of a normal and recurring nature. The results of operations
   for an interim period are not necessarily indicative of the results for the full year. The interim
   statements should be read in conjunction with the financial statements and notes thereto included
   in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2010, filed on February 25,
   2011 with the SEC.

[0000950123-11-045439:notes:5]
[same as prior period, unchanged from 0000950123-10-099391:notes:5]

[0000950123-11-045439:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted
   in the United States of America requires management to make estimates and assumptions that affect
   the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities
   at the date of the financial statements, and the reported amounts of revenue and expense during the
   reporting period. Our more significant estimates include the allowance for doubtful accounts,
   obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales
   returns, estimated income tax contingencies, the fair value of stock-based compensation, and the
   evaluation of other-than-temporary declines in the value of investments. Actual amounts could
   differ significantly from these estimates.

[0000950123-11-045439:notes:7]
[same as prior period, unchanged from 0000950123-10-099391:notes:7]

[0000950123-11-045439:notes:8]
During the first quarter of 2011, we adopted the following accounting standards, which had no
   material effect on our consolidated results of operations or financial condition:

[0000950123-11-045439:notes:9]
In October 2009, the Financial Accounting Standards Board (FASB) issued Update No. 2009-13, which
   amends the Revenue Recognition topic of the FASB Accounting Standards Codification (ASC). This
   update provides amendments to the criteria in Subtopic 605-25 of the ASC for separating
   consideration in multiple-deliverable arrangements. As a result of those amendments,
   multiple-deliverable arrangements will be separated in more circumstances than under existing U.S.
   GAAP. The amendments establish a selling price hierarchy for determining the selling price of a
   deliverable and will replace the term fair value in the revenue allocation guidance with selling
   price to clarify that the allocation of revenue is based on entity-specific assumptions rather than
   assumptions of a marketplace participant. The amendments will also eliminate the residual method
   of allocation and require that arrangement consideration be allocated at the inception of the
   arrangement to all deliverables using the relative selling price method and will require that a
   vendor determine its best estimate of selling price in a manner that is consistent with that used
   to determine the price to sell the deliverable on a standalone basis.

[0000950123-11-045439:notes:10]
We generally sell our products and services separately, but in some circumstances products and
   services may be sold in bundles that contain multiple deliverables. A sale that includes multiple
   deliverables is evaluated to determine the units of accounting, and the revenue from the
   arrangement is allocated to each item requiring separate revenue recognition based on the relative
   selling price and corresponding terms of the contract. We strive to use vendor-specific objective
   evidence of selling price. When this evidence is not available, we are generally not able to
   determine third-party evidence of selling price because of the extent of customization among
   competing products or services from other companies. In these cases, estimated selling price is
   determined based on the particular circumstances of the arrangement and is used to allocate
   revenues to each unit of accounting. Revenue is recognized incrementally as the necessary criteria
   for each item is met.

[0000950123-11-045439:notes:11]
We adopted this guidance for the three months ended March 31, 2011. The adoption of this guidance
   had no effect on our consolidated results of operations and financial condition for the three
   months ended March 31, 2011.

[0000950123-11-045439:notes:12]
In October 2009, the FASB issued Update No. 2009-14, which amends the Software topic of the ASC.
   The amendments in this update change the accounting model for revenue arrangements that include
   both tangible products and software elements. Tangible products containing software components and
   non-software components that function together to deliver the tangible product’s essential
   functionality is no longer within the scope of the software revenue guidance in Subtopic 985-605 of
   the ASC. In addition, the amendments in this update require that hardware components of a tangible
   product containing software components always be excluded from the software revenue guidance. In
   that regard, the amendments provide additional guidance on how to determine which software, if any,
   relating to the tangible product also would be excluded from the scope of the software revenue
   guidance. The amendments also provide guidance on how a vendor should allocate arrangement
   consideration to deliverables in an arrangement that includes both tangible products and software.
   The amendments also provide further guidance on how to allocate arrangement consideration when an
   arrangement includes deliverables both included and excluded from the scope of the software revenue
   guidance. We adopted this guidance for the three months ended March 31, 2011. The adoption of
   this guidance had no effect on our consolidated results of operations and financial condition for
   the three months ended March 31, 2011.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-11-045439:notes:13]
[same as prior period, unchanged from 0000950123-10-099391:notes:13]

[0000950123-11-045439:notes:14]
Our effective tax rate decreased from 35.7% in the three months ended March 31, 2010 to 30.7% in
   the three months ended March 31, 2011. The decrease is primarily due to the research and
   development tax credit and increased tax benefits from a higher volume of stock option exercises
   during the first quarter of 2011. The tax provision rate in the first quarter of 2010 did not
   include the benefit of the research and development tax credit, which expired on December 31, 2009.
   The credit was reinstated during the fourth quarter of 2010. The inclusion of this benefit in the
   first quarter of 2011 resulted in a 2.2 percentage point decrease in our tax rate. Also, increased
   benefits from a higher volume of stock option exercises in the first quarter of 2011 resulted in a
   3.9 percentage point decrease in our tax rate.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950123-11-045439:notes:15]
[same as prior period, unchanged from 0000950123-10-099391:notes:16]

[0000950123-11-045439:notes:16]
The following table summarizes the stock-based compensation expense related to stock options,
   restricted stock units (RSUs) and restricted stock under the Stock Compensation Topic of the FASB
   ASC for the three months ended March 31, 2011 and 2010, which was recognized as follows:

[0000950123-11-045439:notes:17]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 91 |  |  | $ | 68 |  |
| Selling, general and administrative expense |  |  | 1,007 |  |  |  | 750 |  |
| Research and development expense |  |  | 991 |  |  |  | 871 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,998 |  |  |  | 1,621 |  |
| Total stock-based compensation expense |  |  | 2,089 |  |  |  | 1,689 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (440 | ) |  |  | (177 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,649 |  |  | $ | 1,512 |  |

[0000950123-11-045439:notes:18]
[same as prior period, unchanged from 0000950123-10-099391:notes:19]

[0000950123-11-045439:notes:19]
There were no options granted during the three month period ended March 31, 2011. The
   weighted-average assumptions and value of options granted for the three months ended March 31, 2010
   are summarized as follows:

[0000950123-11-045439:notes:20]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2011 |  |  | 2010 |  |
| Expected volatility |  |  | — |  |  |  | 41.29 | % |
| Risk-free interest rate |  |  | — |  |  |  | 2.52 | % |
| Expected dividend yield |  |  | — |  |  |  | 1.59 | % |
| Expected life (in years) |  |  | — |  |  |  | 5.22 |  |
| Weighted-average estimated value |  | $ | — |  |  | $ | 7.86 |  |

[0000950123-11-045439:notes:21]
The fair value of our RSUs is calculated using a Monte Carlo Simulation valuation method. There
   were no RSU grants during the three months ended March 31, 2011 or 2010.

[0000950123-11-045439:notes:22]
The fair value of restricted stock is equal to the closing price of our stock on the date of grant.
   There were no restricted stock grants during the three months ended March 31, 2011 or 2010.

[0000950123-11-045439:notes:23]
Stock-based compensation expense recognized in our Consolidated Statements of Income for the three
   months ended March 31, 2011 and 2010 is based on options, RSUs and restricted stock ultimately
   expected to vest, and has been reduced for estimated forfeitures. Estimated forfeitures for stock
   options were based upon historical experience and approximate 2.0% annually. We estimated a 0%
   forfeiture rate for our RSUs and restricted stock due to the limited number of recipients and
   historical experience for these awards.

[0000950123-11-045439:notes:24]
As of March 31, 2011, total compensation expense related to non-vested stock options, RSUs and
   restricted stock not yet recognized was approximately $18.1 million, which is expected to be
   recognized over an average remaining recognition period of 2.9 years.

[0000950123-11-045439:notes:25]
The following table is a summary of our stock options outstanding as of December 31, 2010 and March
   31, 2011 and the changes that occurred during the three months ended March 31, 2011:

[0000950123-11-045439:notes:26]
|  |  |  |  |  |  |  |  |  |  | Weighted Avg. |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  | Remaining |  |  | Aggregate |  |
|  |  | Number of |  |  | Weighted Avg. |  |  | Contractual |  |  | Intrinsic |  |
| (In thousands, except per share amounts) |  | Options |  |  | Exercise Price |  |  | Life In years |  |  | Value |  |
| Options outstanding, December 31, 2010 |  |  | 6,234 |  |  | $ | 23.09 |  |  |  | 6.21 |  |  | $ | 81,561 |  |
| Options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (23 | ) |  | $ | 25.07 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (1,653 | ) |  | $ | 19.42 |  |  |  |  |  |  |  |  |  |
| Options outstanding, March 31, 2011 |  |  | 4,558 |  |  | $ | 24.41 |  |  |  | 6.80 |  |  | $ | 82,295 |  |
| Options exercisable, March 31, 2011 |  |  | 2,318 |  |  | $ | 23.08 |  |  |  | 5.05 |  |  | $ | 44,921 |  |

[0000950123-11-045439:notes:27]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the
   difference between ADTRAN’s closing stock price on the last trading day of the quarter and the
   exercise price, multiplied by the number of in-the-money options) that would have been received by
   the option holders had all option holders exercised their options on March 31, 2011. The aggregate
   intrinsic value will change based on the fair market value of ADTRAN’s stock.

[0000950123-11-045439:notes:28]
The total pre-tax intrinsic value of options exercised during the three month period ended March
   31, 2011 was $37.4 million.

[0000950123-11-045439:notes:29]
The following table is a summary of our RSUs and restricted stock outstanding as of December 31,
   2010 and March 31, 2011 and the changes that occurred during the three months ended March 31, 2011:

[0000950123-11-045439:notes:30]
|  |  |  |  |  |  | Weighted |  |
|  |  |  |  |  |  | Average |  |
|  |  | Number of |  |  | Grant Date |  |
| (In thousands, except per share amounts) |  | shares |  |  | Fair Value |  |
| RSUs and restricted stock outstanding, December 31, 2010 |  |  | 87 |  |  | $ | 28.46 |  |
| RSUs and restricted stock granted |  |  | — |  |  |  | — |  |
| RSUs and restricted stock vested |  |  | — |  |  |  | — |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  |  | — |  |
| Unvested RSUs and restricted stock, March 31, 2011 |  |  | 87 |  |  | $ | 28.46 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950123-11-045439:notes:31]
4. INVESTMENTS

[0000950123-11-045439:notes:32]
At March 31, 2011, we held the following securities and investments, recorded at either fair value
   or cost.

[0000950123-11-045439:notes:33]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 5,738 |  |  | $ | 839 |  |  | $ | — |  |  | $ | 6,577 |  |
| Corporate bonds |  |  | 183,761 |  |  |  | 668 |  |  |  | (294 | ) |  |  | 184,135 |  |
| Municipal fixed-rate bonds |  |  | 133,700 |  |  |  | 371 |  |  |  | (53 | ) |  |  | 134,018 |  |
| Municipal variable rate demand notes |  |  | 58,710 |  |  |  | — |  |  |  | — |  |  |  | 58,710 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 232 |  |  |  | — |  |  |  | 759 |  |
| Marketable equity securities |  |  | 11,940 |  |  |  | 32,993 |  |  |  | (132 | ) |  |  | 44,801 |  |
| Available-for-sale securities held at fair value |  | $ | 394,376 |  |  | $ | 35,103 |  |  | $ | (479 | ) |  | $ | 429,000 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,103 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 479,353 |  |

[0000950123-11-045439:notes:34]
At December 31, 2010, we held the following securities and investments, recorded at either fair
   value or cost.

[0000950123-11-045439:notes:35]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 3,483 |  |  | $ | 770 |  |  | $ | (7 | ) |  | $ | 4,246 |  |
| Corporate bonds |  |  | 126,671 |  |  |  | 630 |  |  |  | (229 | ) |  |  | 127,072 |  |
| Municipal fixed-rate bonds |  |  | 71,212 |  |  |  | 268 |  |  |  | (13 | ) |  |  | 71,467 |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | — |  |  |  | 116,745 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 220 |  |  |  | — |  |  |  | 746 |  |
| Marketable equity securities |  |  | 11,486 |  |  |  | 36,657 |  |  |  | (133 | ) |  |  | 48,010 |  |
| Available-for-sale securities held at fair value |  | $ | 330,123 |  |  | $ | 38,545 |  |  | $ | (382 | ) |  | $ | 368,286 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,103 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 418,639 |  |

[0000950123-11-045439:notes:36]
At March 31, 2011, we held $6.6 million of deferred compensation plan assets, carried at fair
   value.

[0000950123-11-045439:notes:37]
At March 31, 2011, we held $184.1 million of corporate bonds. These bonds are classified as
   available-for-sale and had an average duration of 2.3 years at March 31, 2011. At March 31, 2011,
   approximately 1% of our corporate bond portfolio had a credit rating of AAA, 16% had a credit
   rating of AA, 52% had a credit rating of A, and 31% had a credit rating of BBB.

[0000950123-11-045439:notes:38]
At March 31, 2011, we held $134.0 million of municipal fixed-rate bonds. These bonds are
   classified as available-for-sale and had an average duration of 1.5 years at March 31, 2011. At
   March 31, 2011, approximately 21% of our municipal fixed-rate bond portfolio had a credit rating of
   AAA, 64% had a credit rating of AA, and 15% had a credit rating of A. Because our bond portfolio
   has a high quality rating and contractual maturities of a short duration, we are able to obtain
   prices for these bonds derived from observable market inputs, or for similar securities traded in
   an active market, on a daily basis.

[0000950123-11-045439:notes:39]
At March 31, 2011, we held $58.7 million of municipal variable rate demand notes, all of which were
   classified as available-for-sale. At March 31, 2011, 30% of our municipal variable rate demand
   notes had a credit rating of AAA, 55% had a credit rating of AA, 15% had a credit rating of A, and
   all contained put options of seven days. Despite the long-term nature of their stated contractual
   maturities, we routinely buy and sell these securities and we believe that we have the ability to
   quickly liquidate them. Our investments in these securities are recorded at fair value, and the
   interest rates reset every seven days. We believe we have the ability to sell our variable rate
   demand notes to the remarketing agent, tender agent or issuer at par value plus accrued interest in
   the event we decide to liquidate our investment in a particular variable rate demand note. At
   March 31, 2011, approximately 38% of our variable rate demand notes were supported by letters of
   credit from banks that we believe to be in good financial condition. The remaining 62% of our
   variable rate demand notes were supported by standby purchase agreements. As a result of these
   factors, we had no cumulative gross unrealized holding gains (losses) or gross realized gains
   (losses) from these investments. All income generated from these investments was recorded as
   interest income. We have not recorded any losses relating to municipal variable rate demand notes.

[0000950123-11-045439:notes:40]
At March 31, 2011, we held $0.8 million of a fixed income bond fund.

[0000950123-11-045439:notes:41]
At March 31, 2011, we held $44.8 million of marketable equity securities, including a single
   security, of which we held 1.4 million shares, carried at a fair value of $29.8 million. We sold
   93 thousand shares of this security during the three months ended March 31, 2011. The sale of this
   security resulted in proceeds of $2.1 million and a realized gain of $2.0 million. This single
   security traded approximately 1.1 million shares per day in the first quarter of 2011 in an active
   market on a European stock exchange. This single security comprises $29.3 million of the gross
   unrealized gains included in the fair value of our marketable equity securities at March 31, 2011.
   The remaining $3.7 million of gross unrealized gains and $0.1 million of gross unrealized losses at
   March 31, 2011 were spread amongst more than 400 equity securities.

[0000950123-11-045439:notes:42]
At March 31, 2011, we held a $48.3 million restricted certificate of deposit, which is carried at
   cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At March 31, 2011, the estimated fair value of the Bond was approximately $43.7
   million, based on a debt security with a comparable interest rate and maturity and a Standard and
   Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.

[0000950123-11-045439:notes:43]
At March 31, 2011, we held $2.1 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.8 million at March 31, 2011, based on unobservable inputs including information supplied by the
   company and the fund managers. We have committed to invest up to an aggregate of $7.9 million in
   the two private equity funds, and we have contributed $8.0 million as of March 31, 2011, of which
   $7.4 million has been applied toward these commitments. As of March 31, 2011, we have received
   distributions related to these two private equity funds of $7.2 million, of which $0.9 million was
   recorded as investment income. These investments are
   carried at cost, net of distributions, with distributions in excess of our investment recorded as
   investment income. The duration of each of these commitments is ten years with $0.4 million
   expiring in 2013 and $0.1 million expiring in 2012. We have not been required to record any
   impairment losses related to these investments during the three months ended March 31, 2011.

[0000950123-11-045439:notes:44]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $4 thousand during the first
   quarter of 2011 related to one marketable equity security. For the three months ended March 31,
   2010, we recorded an other-than-temporary impairment charge of $2 thousand related to one
   marketable equity security.

[0000950123-11-045439:notes:45]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have
   categorized our cash equivalents held in money market funds and our investments held at fair value
   into a three-level fair value hierarchy based on the priority of the inputs to the valuation
   technique for the cash equivalents and investments as follows: Level 1 — Values based on
   unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 — Values
   based on quoted prices in markets that are not active or model inputs that are observable either
   directly or indirectly; Level 3 — Values based on prices or valuation techniques that require
   inputs that are both unobservable and significant to the overall fair value measurement. These
   inputs include information supplied by investees.

[0000950123-11-045439:notes:46]
|  |  | Fair Value Measurements at March 31, 2011 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 14,276 |  |  | $ | 14,276 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 6,577 |  |  |  | 6,577 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 184,135 |  |  |  | — |  |  |  | 184,135 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 134,018 |  |  |  | — |  |  |  | 134,018 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 58,710 |  |  |  | — |  |  |  | 58,710 |  |  |  | — |  |
| Fixed income bond fund |  |  | 759 |  |  |  | 759 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 31,201 |  |  |  | 31,201 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 13,600 |  |  |  | 13,600 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 429,000 |  |  |  | 52,137 |  |  |  | 376,863 |  |  |  | — |  |
| Total |  | $ | 443,276 |  |  | $ | 66,413 |  |  | $ | 376,863 |  |  | $ | — |  |

[0000950123-11-045439:notes:47]
|  |  | Fair Value Measurements at December 31, 2010 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 14,532 |  |  | $ | 14,532 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 4,246 |  |  |  | 4,246 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 127,072 |  |  |  | — |  |  |  | 127,072 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 71,467 |  |  |  | — |  |  |  | 71,467 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | 116,745 |  |  |  | — |  |
| Fixed income bond fund |  |  | 746 |  |  |  | 746 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 35,596 |  |  |  | 35,596 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 12,414 |  |  |  | 12,414 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 368,286 |  |  |  | 53,002 |  |  |  | 315,284 |  |  |  | — |  |
| Total |  | $ | 382,818 |  |  | $ | 67,534 |  |  | $ | 315,284 |  |  | $ | — |  |

[0000950123-11-045439:notes:48]
As of March 31, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 corporate bonds and municipal fixed-rate bonds was $318.2 million and $198.5 million,
   respectively. The fair value of these securities is calculated using a weighted average market
   price for each security. Market prices are obtained from a variety of industry standard data
   providers, security master files from large financial institutions, and other third-party sources.
   These multiple market prices are used as inputs into a distribution-curve-based algorithm to
   determine the daily market value of each security.

[0000950123-11-045439:notes:49]
As of March 31, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 municipal variable rate demand notes was $58.7 million and $116.7 million, respectively.
   These securities have a structure that implies a standard expected market price. The frequent
   interest rate resets make it reasonable to expect the price to stay at par. These securities are
   priced at the expected market price.


## us-gaap:InventoryDisclosureTextBlock

[0000950123-11-045439:notes:50]
[same as prior period, unchanged from 0000950123-10-099391:notes:45]

[0000950123-11-045439:notes:51]
At March 31, 2011 and December 31, 2010, inventory consisted of the following:

[0000950123-11-045439:notes:52]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Raw materials |  | $ | 42,446 |  |  | $ | 43,897 |  |
| Work in process |  |  | 3,807 |  |  |  | 2,871 |  |
| Finished goods |  |  | 32,781 |  |  |  | 27,506 |  |
| Total |  | $ | 79,034 |  |  | $ | 74,274 |  |

[0000950123-11-045439:notes:53]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the
   difference between the cost of the inventory and the estimated fair value of the inventory based
   upon assumptions about future demand and market conditions. At March 31, 2011 and December 31,
   2010, raw materials reserves totaled $8.0 million and $7.3 million, respectively, and finished
   goods inventory reserves totaled $1.9 million and $1.6 million, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950123-11-045439:notes:54]
[same as prior period, unchanged from 0000950123-10-099391:notes:48]

[0000950123-11-045439:notes:55]
A summary of the changes in stockholders’ equity for the three months ended March 31, 2011 is as
   follows:

[0000950123-11-045439:notes:56]
|  |  | Stockholders’ |  |
| (In thousands) |  | Equity |  |
| Balance, December 31, 2010 |  | $ | 572,322 |  |
| Net income |  |  | 34,258 |  |
| Dividend payments |  |  | (5,775 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (10 | ) |
| Net change in unrealized gains and losses on marketable securities (net of deferred taxes) |  |  | (2,651 | ) |
| Reclassification adjustment for amounts included in net income (net of deferred taxes) |  |  | (159 | ) |
| Foreign currency translation adjustment |  |  | 87 |  |
| Proceeds from stock option exercises |  |  | 31,815 |  |
| Tax benefits from stock option exercises |  |  | 9,942 |  |
| Stock-based compensation expense |  |  | 2,089 |  |
| Balance, March 31, 2011 |  | $ | 641,918 |  |

[0000950123-11-045439:notes:57]
[same as prior period, unchanged from 0000950123-10-099391:notes:51]

[0000950123-11-045439:notes:58]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have
   authorized open market repurchase transactions of up to 30 million shares of our common stock.
   During the three months ended March 31, 2011, we did not repurchase any shares of our common stock.
   We have the authority to purchase an additional 2.0 million shares of our common stock under the
   plan approved by the Board of Directors on April 14, 2008.

[0000950123-11-045439:notes:59]
[same as prior period, unchanged from 0000950123-10-099391:notes:53]

[0000950123-11-045439:notes:60]
We issued 1.7 million shares of treasury stock during the three months ended March 31, 2011 to
   accommodate employee stock option exercises. The stock options had exercise prices ranging from
   $10.50 to $36.64. We received proceeds totaling $31.8 million from the exercise of these stock
   options during the three months ended March 31, 2011.

[0000950123-11-045439:notes:61]
[same as prior period, unchanged from 0000950123-10-099391:notes:55]

[0000950123-11-045439:notes:62]
During the first quarter of 2011, we paid cash dividends as follows (in thousands except per share
   amount):

[0000950123-11-045439:notes:63]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 3, 2011 |  | February 17, 2011 |  | $ | 0.09 |  |  | $ | 5,775 |  |

[0000950123-11-045439:notes:64]
[same as prior period, unchanged from 0000950123-10-099391:notes:58]

[0000950123-11-045439:notes:65]
Comprehensive income consists of net income, net change in unrealized gains and losses on
   marketable securities, reclassification adjustments for amounts included in net income related to
   impaired securities and foreign currency translation adjustments.

[0000950123-11-045439:notes:66]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Net income |  | $ | 34,258 |  |  | $ | 18,194 |  |
| Net change in unrealized gains and losses related to marketable securities, net of deferred tax benefit (expense) of $673 and $(2,772) for the three months ended March 31, 2011 and 2010, respectively |  |  | (2,651 | ) |  |  | 4,622 |  |
| Reclassification adjustment for amounts included in net income, net of deferred tax benefit of $43 and $31 for the three months ended March 31, 2011 and 2010, respectively |  |  | (159 | ) |  |  | (52 | ) |
| Foreign currency translation adjustment |  |  | 87 |  |  |  | 168 |  |
| Total comprehensive income |  | $ | 31,535 |  |  | $ | 22,932 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950123-11-045439:notes:67]
[same as prior period, unchanged from 0000950123-10-099391:notes:61]

[0000950123-11-045439:notes:68]
A summary of the calculation of basic and diluted earnings per share for the three months ended
   March 31, 2011 and 2010 is as follows:

[0000950123-11-045439:notes:69]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2011 |  |  | 2010 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 34,258 |  |  | $ | 18,194 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares — basic |  |  | 64,189 |  |  |  | 61,999 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| Stock options |  |  | 1,711 |  |  |  | 1,045 |  |
| Restricted stock and restricted stock units |  |  | 57 |  |  |  | 16 |  |
| Weighted average number of shares — diluted |  |  | 65,957 |  |  |  | 63,060 |  |
| Net income per share — basic |  | $ | 0.53 |  |  | $ | 0.29 |  |
| Net income per share — diluted |  | $ | 0.52 |  |  | $ | 0.29 |  |

[0000950123-11-045439:notes:70]
Anti-dilutive options to purchase common stock outstanding were excluded from the above
   calculations. Anti-dilutive options totaled 0.9 million and 3.3 million for the three months ended
   March 31, 2011 and 2010, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950123-11-045439:notes:71]
[same as prior period, unchanged from 0000950123-10-099391:notes:65]

[0000950123-11-045439:notes:72]
We operate in two reportable segments: (1) the Carrier Networks Division and (2) the Enterprise
   Networks Division. We evaluate the performance of our segments based on gross profit; therefore,
   selling, general and administrative expenses, research and development expenses, interest and
   dividend income, interest expense, net realized investment gain/loss, other expense, net and
   provision for income taxes are reported on an entity-wide basis only. There are no inter-segment
   revenues.

[0000950123-11-045439:notes:73]
The following table presents information about the reported sales and gross profit of our
   reportable segments for the three months ended March 31, 2011 and 2010. Asset information by
   reportable segment is not reported, since we do not produce such information internally.

[0000950123-11-045439:notes:74]
|  |  | Three Months Ended |  |
|  |  | March 31, 2011 |  |  | March 31, 2010 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 132,360 |  |  | $ | 79,498 |  |  | $ | 99,524 |  |  | $ | 59,266 |  |
| Enterprise Networks |  |  | 33,162 |  |  |  | 19,297 |  |  |  | 27,503 |  |  |  | 16,062 |  |
| Total |  | $ | 165,522 |  |  | $ | 98,795 |  |  | $ | 127,027 |  |  | $ | 75,328 |  |

[0000950123-11-045439:notes:75]
[same as prior period, unchanged from 0000950123-10-099391:notes:70]

[0000950123-11-045439:notes:76]
[same as prior period, unchanged from 0000950123-10-099391:notes:71]

[0000950123-11-045439:notes:77]
Carrier Systems products are used by communications service providers to provide data, voice and
   video services to consumers and enterprises. The Carrier Systems category includes our broadband
   access products comprised of Total Access® 5000 multi-service access and aggregation platform
   products, Total Access 1100/1200 Series Fiber-To-The-Node (FTTN) products, and Digital Subscriber
   Line Access Multiplexer (DSLAM) products. Our broadband access products are used by service
   providers to deliver high-speed Internet access, Voice over Internet Protocol (VoIP), IP Television
   (IPTV), and/or Ethernet services from the central office or remote terminal locations to customer
   premises. The Carrier Systems category also includes our optical access products. These products
   consist of optical access multiplexers including our family of OPTI products and our Optical
   Networking Edge (ONE) products. Optical access products are used to deliver higher bandwidth
   services, or to aggregate large numbers of low bandwidth services for transportation across fiber
   optic infrastructure. Total Access 1500 products, 303 concentrator products, M13 multiplexer
   products, and a number of mobile backhaul products are also included in the Carrier Systems product
   category.

[0000950123-11-045439:notes:78]
Business Networking products provide access to telecommunication services, facilitating the
   delivery of converged services and Unified Communications to the small and mid-sized enterprises
   (SME) market. The Business Networking category includes Internetworking products and Integrated
   Access Devices (IADs). Internetworking products consist of our Total Access IP Business Gateways,
   Optical Network Terminals (ONTs), and NetVanta product lines. NetVanta products include
   multi-service routers, managed Ethernet switches, IP Private Branch Exchange (PBX) products, IP
   phone products, Unified Communications solutions, Unified Threat Management (UTM) solutions, and
   Carrier Ethernet Network Terminating Equipment (NTE). IAD products consist of our Total Access 600
   Series and the Total Access 850.

[0000950123-11-045439:notes:79]
Loop Access products are used by carrier and enterprise customers for access to copper-based
   telecommunications networks. The Loop Access category includes products such as: Digital Data
   Service (DDS) and Integrated Services Digital Network (Total Reach) products, High bit-rate Digital
   Subscriber Line (HDSL) products including Total Access 3000 HDSL and Time Division
   Multiplexed-Symmetrical HDSL (TDM-SHDSL) products, T1/E1/T3, Channel Service Units/Data Service
   Units, and TRACER fixed wireless products.

[0000950123-11-045439:notes:80]
The table below presents sales information by product category for the three months ended March 31,
   2011 and 2010.

[0000950123-11-045439:notes:81]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Carrier Systems |  | $ | 86,750 |  |  | $ | 58,093 |  |
| Business Networking |  |  | 36,363 |  |  |  | 26,457 |  |
| Loop Access |  |  | 42,409 |  |  |  | 42,477 |  |
| Total |  | $ | 165,522 |  |  | $ | 127,027 |  |

[0000950123-11-045439:notes:82]
In addition, we identify subcategories of product revenues, which we divide into growth products,
   representing our primary growth areas, and traditional products. Our growth products consist of
   Broadband Access and Optical Access products (included in Carrier Systems) and Internetworking
   products (included in Business Networking) and our
   traditional products include HDSL products (included in Loop Access) and other products not
   included in the aforementioned growth products.

[0000950123-11-045439:notes:83]
[same as prior period, unchanged from 0000950123-10-099391:notes:78]

[0000950123-11-045439:notes:84]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Growth Products |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 51,782 |  |  | $ | 36,362 |  |
| Optical Access (included in Carrier Systems) |  |  | 20,916 |  |  |  | 11,259 |  |
| Internetworking (NetVanta & Multi-service Access Gateways) (included in Business Networking) |  |  | 32,883 |  |  |  | 22,183 |  |
| Total |  |  | 105,581 |  |  |  | 69,804 |  |
| Traditional Products |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 40,945 |  |  |  | 39,930 |  |
| Other products (excluding HDSL) |  |  | 18,996 |  |  |  | 17,293 |  |
| Total |  |  | 59,941 |  |  |  | 57,223 |  |
| Total |  | $ | 165,522 |  |  | $ | 127,027 |  |

[0000950123-11-045439:notes:85]
[same as prior period, unchanged from 0000950123-10-099391:notes:80]

[0000950123-11-045439:notes:86]
The table below presents sales information by geographic area for the three months ended March 31,
   2011 and 2010. International sales correlate to shipments with a non-U.S. destination.

[0000950123-11-045439:notes:87]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | March 31, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| United States |  | $ | 153,113 |  |  | $ | 120,300 |  |
| International |  |  | 12,409 |  |  |  | 6,727 |  |
| Total |  | $ | 165,522 |  |  | $ | 127,027 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950123-11-045439:notes:88]
[same as prior period, unchanged from 0000950123-10-099391:notes:83]

[0000950123-11-045439:notes:89]
Our products generally include warranties of one to ten years for product defects. We accrue for
   warranty returns at the time revenue is recognized based on our estimate of the cost to repair or
   replace the defective products. We engage in extensive product quality programs and processes,
   including actively monitoring and evaluating the quality of our component suppliers. Our products
   continue to become more complex in both size and functionality as many of our product offerings
   migrate from line card applications to systems products. The increasing complexity of our products
   will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future
   warranty obligations may change due to product failure rates, material usage, and other rework
   costs incurred in correcting a product failure. In addition, from time to time, specific warranty
   accruals may be recorded if unforeseen problems arise. Should our actual experience relative to
   these factors be worse than our estimates, we will be required to record additional warranty
   expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion
   of such provisions in future periods. The liability for warranty obligations totaled $3.5 million
   at March 31, 2011 and $3.3 million at December 31, 2010. These liabilities are included in accrued
   expenses in the accompanying Consolidated Balance Sheets.

[0000950123-11-045439:notes:90]
A summary of warranty expense and write-off activity for the three months ended March 31, 2011 and
   2010 is as follows:

[0000950123-11-045439:notes:91]
| Three Months Ended March 31, |  |  |  |  |  |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Balance at beginning of period |  | $ | 3,304 |  |  | $ | 2,833 |  |
| Plus: Amounts charged to cost and expenses |  |  | 835 |  |  |  | 771 |  |
| Less: Deductions |  |  | (620 | ) |  |  | (703 | ) |
| Balance at end of period |  | $ | 3,519 |  |  | $ | 2,901 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000950123-11-045439:notes:92]
10. RELATED PARTY TRANSACTIONS

[0000950123-11-045439:notes:93]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three months ended March 31, 2011 and 2010, we incurred fees of $10 thousand per month
   for these legal services.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-11-045439:notes:94]
11. COMMITMENTS AND CONTINGENCIES

[0000950123-11-045439:notes:95]
In the ordinary course of business, we may be subject to various legal proceedings and claims,
   including employment disputes, patent claims, disputes over contract agreements and other
   commercial disputes. In some cases, claimants seek damages or other relief, such as royalty
   payments related to patents, which, if granted, could require significant expenditures. Although
   the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of
   all contingencies of which we are currently aware will not materially affect our business,
   operations, financial condition or cash flows.

[0000950123-11-045439:notes:96]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.0 million as of March 31, 2011, of which $7.4 million has been applied to these
   commitments. See Note 4 of Notes to Consolidated Financial Statements for additional information.


## us-gaap:ScheduleOfSubsequentEventsTextBlock

[0000950123-11-045439:notes:97]
12. SUBSEQUENT EVENTS

[0000950123-11-045439:notes:98]
On April 12, 2011, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on April 28,
   2011. The payment date will be May 12, 2011. The quarterly dividend payment will be approximately
   $5.8 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends
   on our common stock considering the tax treatment of dividends and adequate levels of Company
   liquidity.
