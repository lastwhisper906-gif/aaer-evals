# ADTN note change history — 0000950123-10-099391 → 0000950123-11-045439


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2011-05-05):
[0000950123-11-045439:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.0 million as of March 31, 2011, of which $7.4 million has been applied to these
   commitments. See Note 4 of Notes to Consolidated Financial Statements for additional information.
  (was, 2010-11-02, similarity 0.9755):
[0000950123-10-099391:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.0 million as of September 30, 2010, of which $7.5 million has been applied to
   these commitments. See Note 4 of Notes to Consolidated Financial Statements for additional
   information.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2011-05-05):
[0000950123-11-045439:note_history:2]
The preparation of financial statements in conformity with accounting principles generally accepted
   in the United States of America requires management to make estimates and assumptions that affect
   the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities
   at the date of the financial statements, and the reported amounts of revenue and expense during the
   reporting period. Our more significant estimates include the allowance for doubtful accounts,
   obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales
   returns, estimated income tax contingencies, the fair value of stock-based compensation, and the
   evaluation of other-than-temporary declines in the value of investments. Actual amounts could
   differ significantly from these estimates.
  (was, 2010-11-02, similarity 0.9497):
[0000950123-10-099391:note_history:2]
The preparation of financial statements in conformity with accounting principles generally accepted
   in the United States of America requires management to make estimates and assumptions that affect
   the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities
   at the date of the financial statements, and the reported amounts of revenue and expense during the
   reporting period. Our more significant estimates include the allowance for doubtful accounts,
   obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales
   returns, determination of the deferred revenue components of multiple element sales agreements,
   estimated income tax contingencies, the fair value of stock-based compensation, and the evaluation
   of other-than-temporary declines in the value of investments. Actual amounts could differ
   significantly from these estimates.

- changed (2011-05-05):
[0000950123-11-045439:note_history:3]
During the first quarter of 2011, we adopted the following accounting standards, which had no
   material effect on our consolidated results of operations or financial condition:
  (was, 2010-11-02, similarity 0.907):
[0000950123-10-099391:note_history:3]
During the nine months ended September 30, 2010, we adopted the following accounting standards,
   which had no material effect on our consolidated results of operations or financial condition:

- changed (2011-05-05):
[0000950123-11-045439:note_history:4]
In October 2009, the Financial Accounting Standards Board (FASB) issued Update No. 2009-13, which
   amends the Revenue Recognition topic of the FASB Accounting Standards Codification (ASC). This
   update provides amendments to the criteria in Subtopic 605-25 of the ASC for separating
   consideration in multiple-deliverable arrangements. As a result of those amendments,
   multiple-deliverable arrangements will be separated in more circumstances than under existing U.S.
   GAAP. The amendments establish a selling price hierarchy for determining the selling price of a
   deliverable and will replace the term fair value in the revenue allocation guidance with selling
   price to clarify that the allocation of revenue is based on entity-specific assumptions rather than
   assumptions of a marketplace participant. The amendments will also eliminate the residual method
   of allocation and require that arrangement consideration be allocated at the inception of the
   arrangement to all deliverables using the relative selling price method and will require that a
   vendor determine its best estimate of selling price in a manner that is consistent with that used
   to determine the price to sell the deliverable on a standalone basis.
  (was, 2010-11-02, similarity 0.8791):
[0000950123-10-099391:note_history:4]
In October 2009, the Financial Accounting Standards Board (FASB) issued Update No. 2009-13, which
   amends the Revenue Recognition topic of the FASB Accounting Standards Codification (ASC). This
   update provides amendments to the criteria in Subtopic 605-25 of the ASC for separating
   consideration in multiple-deliverable arrangements. As a result of those amendments,
   multiple-deliverable arrangements will be separated in more circumstances than under existing U.S.
   GAAP. The amendments establish a selling price hierarchy for determining the selling price of a
   deliverable and will replace the term fair value in the revenue allocation guidance with selling
   price to clarify that the allocation of revenue is based on entity-specific assumptions rather than
   assumptions of a marketplace participant. The amendments will also eliminate the residual method
   of allocation and require that arrangement consideration be allocated at the inception of the
   arrangement to all deliverables using the relative selling price method and will require that a
   vendor determine its best estimate of selling price in a manner that is consistent with that used
   to determine the price to sell the deliverable on a standalone basis. These amendments will be
   effective prospectively for revenue arrangements entered into or materially modified in fiscal
   years beginning on or after June 15, 2010, with early adoption permitted. We do not expect the
   adoption of this amendment will have a material impact on our consolidated results of operations or
   financial condition.

- added (2011-05-05):
[0000950123-11-045439:note_history:5]
We generally sell our products and services separately, but in some circumstances products and
   services may be sold in bundles that contain multiple deliverables. A sale that includes multiple
   deliverables is evaluated to determine the units of accounting, and the revenue from the
   arrangement is allocated to each item requiring separate revenue recognition based on the relative
   selling price and corresponding terms of the contract. We strive to use vendor-specific objective
   evidence of selling price. When this evidence is not available, we are generally not able to
   determine third-party evidence of selling price because of the extent of customization among
   competing products or services from other companies. In these cases, estimated selling price is
   determined based on the particular circumstances of the arrangement and is used to allocate
   revenues to each unit of accounting. Revenue is recognized incrementally as the necessary criteria
   for each item is met.

- added (2011-05-05):
[0000950123-11-045439:note_history:6]
We adopted this guidance for the three months ended March 31, 2011. The adoption of this guidance
   had no effect on our consolidated results of operations and financial condition for the three
   months ended March 31, 2011.

- changed (2011-05-05):
[0000950123-11-045439:note_history:7]
In October 2009, the FASB issued Update No. 2009-14, which amends the Software topic of the ASC.
   The amendments in this update change the accounting model for revenue arrangements that include
   both tangible products and software elements. Tangible products containing software components and
   non-software components that function together to deliver the tangible product’s essential
   functionality is no longer within the scope of the software revenue guidance in Subtopic 985-605 of
   the ASC. In addition, the amendments in this update require that hardware components of a tangible
   product containing software components always be excluded from the software revenue guidance. In
   that regard, the amendments provide additional guidance on how to determine which software, if any,
   relating to the tangible product also would be excluded from the scope of the software revenue
   guidance. The amendments also provide guidance on how a vendor should allocate arrangement
   consideration to deliverables in an arrangement that includes both tangible products and software.
   The amendments also provide further guidance on how to allocate arrangement consideration when an
   arrangement includes deliverables both included and excluded from the scope of the software revenue
   guidance. We adopted this guidance for the three months ended March 31, 2011. The adoption of
   this guidance had no effect on our consolidated results of operations and financial condition for
   the three months ended March 31, 2011.
  (was, 2010-11-02, similarity 0.8275):
[0000950123-10-099391:note_history:7]
In October 2009, the FASB issued Update No. 2009-14, which amends the Software topic of the ASC.
   The amendments in this update change the accounting model for revenue arrangements that include
   both tangible products and software elements. Tangible products containing software components and
   non-software components that function together to deliver the tangible product’s essential
   functionality is no longer within the scope of the software revenue guidance in Subtopic 985-605 of
   the ASC. In addition, the amendments in this update require that hardware components of a tangible
   product containing software components always be excluded from the software revenue guidance. In
   that regard, the amendments provide additional guidance on how to determine which software, if any,
   relating to the tangible product also would be excluded from the scope of the software revenue
   guidance. The amendments also provide
   guidance on how a vendor should allocate arrangement consideration to deliverables in an
   arrangement that includes both tangible products and software. The amendments also provide further
   guidance on how to allocate arrangement consideration when an arrangement includes deliverables
   both included and excluded from the scope of the software revenue guidance. These amendments will
   be effective prospectively for revenue arrangements entered into or materially modified in fiscal
   years beginning on or after June 15, 2010, with early adoption permitted. We do not expect the
   adoption of this amendment will have a material impact on our consolidated results of operations or
   financial condition.

- removed (2011-05-05):
[0000950123-10-099391:note_history:8]
In January 2010, the FASB issued Update No. 2010-06, which amends the Fair Value Measurements and
   Disclosures topic of the ASC. The amendments in this update require new disclosures about
   transfers in and out of Level 1 and Level 2 fair value measurements and the activity in Level 3
   fair value measurements and, in addition, clarify existing disclosures required for levels of
   disaggregation and inputs and valuation techniques. These amendments are effective for interim and
   annual reporting periods beginning after December 15, 2009, except for the disclosures about
   activity in Level 3 fair value measurements, which is effective for fiscal years beginning after
   December 15, 2010, and for interim periods within those fiscal years. We adopted this amendment
   for the period ended March 31, 2010, and we have provided the disclosures required for the period
   ended September 30, 2010.

- removed (2011-05-05):
[0000950123-10-099391:note_history:9]
In February 2010, the FASB issued Update No. 2010-09, which amends the Subsequent Events topic of
   the ASC. The amendments in this update require entities that are SEC filers to evaluate subsequent
   events through the date that the financial statements are issued. Additionally, SEC filers are no
   longer required to disclose the date through which subsequent events were evaluated. The
   amendments in this update were effective upon issuance. We adopted this amendment for the period
   ended March 31, 2010, and we have provided the disclosures required for the period ended September
   30, 2010.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-05-05):
[0000950123-11-045439:note_history:10]
At March 31, 2011, we held the following securities and investments, recorded at either fair value
   or cost.
  (was, 2010-11-02, similarity 0.9515):
[0000950123-10-099391:note_history:10]
At September 30, 2010, we held the following securities and investments, recorded at either fair
   value or cost.

- changed (2011-05-05):
[0000950123-11-045439:note_history:11]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 5,738 |  |  | $ | 839 |  |  | $ | — |  |  | $ | 6,577 |  |
| Corporate bonds |  |  | 183,761 |  |  |  | 668 |  |  |  | (294 | ) |  |  | 184,135 |  |
| Municipal fixed-rate bonds |  |  | 133,700 |  |  |  | 371 |  |  |  | (53 | ) |  |  | 134,018 |  |
| Municipal variable rate demand notes |  |  | 58,710 |  |  |  | — |  |  |  | — |  |  |  | 58,710 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 232 |  |  |  | — |  |  |  | 759 |  |
| Marketable equity securities |  |  | 11,940 |  |  |  | 32,993 |  |  |  | (132 | ) |  |  | 44,801 |  |
| Available-for-sale securities held at fair value |  | $ | 394,376 |  |  | $ | 35,103 |  |  | $ | (479 | ) |  | $ | 429,000 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,103 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 479,353 |  |
  (was, 2010-11-02, similarity 0.9701):
[0000950123-10-099391:note_history:11]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Fair Value / |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 3,293 |  |  | $ | 637 |  |  | $ | (19 | ) |  | $ | 3,911 |  |
| Corporate bonds |  |  | 109,432 |  |  |  | 920 |  |  |  | (4 | ) |  |  | 110,348 |  |
| Municipal fixed-rate bonds |  |  | 83,332 |  |  |  | 452 |  |  |  | (2 | ) |  |  | 83,782 |  |
| Municipal variable rate demand notes |  |  | 107,420 |  |  |  | — |  |  |  | — |  |  |  | 107,420 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 216 |  |  |  | — |  |  |  | 742 |  |
| Marketable equity securities |  |  | 10,322 |  |  |  | 28,529 |  |  |  | (282 | ) |  |  | 38,569 |  |
| Available-for-sale securities held at fair value |  | $ | 314,325 |  |  | $ | 30,754 |  |  | $ | (307 | ) |  | $ | 344,772 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,228 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 395,250 |  |

- added (2011-05-05):
[0000950123-11-045439:note_history:12]
At December 31, 2010, we held the following securities and investments, recorded at either fair
   value or cost.

- added (2011-05-05):
[0000950123-11-045439:note_history:13]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 3,483 |  |  | $ | 770 |  |  | $ | (7 | ) |  | $ | 4,246 |  |
| Corporate bonds |  |  | 126,671 |  |  |  | 630 |  |  |  | (229 | ) |  |  | 127,072 |  |
| Municipal fixed-rate bonds |  |  | 71,212 |  |  |  | 268 |  |  |  | (13 | ) |  |  | 71,467 |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | — |  |  |  | 116,745 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 220 |  |  |  | — |  |  |  | 746 |  |
| Marketable equity securities |  |  | 11,486 |  |  |  | 36,657 |  |  |  | (133 | ) |  |  | 48,010 |  |
| Available-for-sale securities held at fair value |  | $ | 330,123 |  |  | $ | 38,545 |  |  | $ | (382 | ) |  | $ | 368,286 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,103 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 418,639 |  |

- changed (2011-05-05):
[0000950123-11-045439:note_history:14]
At March 31, 2011, we held $6.6 million of deferred compensation plan assets, carried at fair
   value.
  (was, 2010-11-02, similarity 0.9468):
[0000950123-10-099391:note_history:14]
At September 30, 2010, we held $3.9 million of deferred compensation plan assets, carried at fair
   value.

- changed (2011-05-05):
[0000950123-11-045439:note_history:15]
At March 31, 2011, we held $184.1 million of corporate bonds. These bonds are classified as
   available-for-sale and had an average duration of 2.3 years at March 31, 2011. At March 31, 2011,
   approximately 1% of our corporate bond portfolio had a credit rating of AAA, 16% had a credit
   rating of AA, 52% had a credit rating of A, and 31% had a credit rating of BBB.
  (was, 2010-11-02, similarity 0.7187):
[0000950123-10-099391:note_history:15]
At September 30, 2010, we held $110.3 million of corporate bonds, including a $1.5 million bond
   that has been issued by one bank and is guaranteed by the Federal Deposit Insurance Corporation
   (FDIC) under the Temporary Liquidity Guarantee Program (TLGP). These bonds are classified as
   available-for-sale and had an average duration of 2.2 years at September 30, 2010. At September
   30, 2010, approximately 4% of our corporate bond portfolio had a credit rating of AAA, 11% had a
   credit rating of AA, 51% had a credit rating of A, and 34% had a credit rating of BBB.

- changed (2011-05-05):
[0000950123-11-045439:note_history:16]
At March 31, 2011, we held $134.0 million of municipal fixed-rate bonds. These bonds are
   classified as available-for-sale and had an average duration of 1.5 years at March 31, 2011. At
   March 31, 2011, approximately 21% of our municipal fixed-rate bond portfolio had a credit rating of
   AAA, 64% had a credit rating of AA, and 15% had a credit rating of A. Because our bond portfolio
   has a high quality rating and contractual maturities of a short duration, we are able to obtain
   prices for these bonds derived from observable market inputs, or for similar securities traded in
   an active market, on a daily basis.
  (was, 2010-11-02, similarity 0.9211):
[0000950123-10-099391:note_history:16]
At September 30, 2010, we held $83.8 million of municipal fixed-rate bonds. These bonds are
   classified as available-for-sale investments and had an average duration of 1.1 years at September
   30, 2010. At September 30, 2010, approximately 19% of our municipal fixed-rate bond portfolio had
   a credit rating of AAA, 69% had a credit rating of AA, and 12% had
   a credit rating of A. Because our bond portfolio has a high quality rating and contractual
   maturities of a short duration, we are able to obtain prices for these bonds derived from
   observable market inputs, or for similar securities traded in an active market, on a daily basis.

- changed (2011-05-05):
[0000950123-11-045439:note_history:17]
At March 31, 2011, we held $58.7 million of municipal variable rate demand notes, all of which were
   classified as available-for-sale. At March 31, 2011, 30% of our municipal variable rate demand
   notes had a credit rating of AAA, 55% had a credit rating of AA, 15% had a credit rating of A, and
   all contained put options of seven days. Despite the long-term nature of their stated contractual
   maturities, we routinely buy and sell these securities and we believe that we have the ability to
   quickly liquidate them. Our investments in these securities are recorded at fair value, and the
   interest rates reset every seven days. We believe we have the ability to sell our variable rate
   demand notes to the remarketing agent, tender agent or issuer at par value plus accrued interest in
   the event we decide to liquidate our investment in a particular variable rate demand note. At
   March 31, 2011, approximately 38% of our variable rate demand notes were supported by letters of
   credit from banks that we believe to be in good financial condition. The remaining 62% of our
   variable rate demand notes were supported by standby purchase agreements. As a result of these
   factors, we had no cumulative gross unrealized holding gains (losses) or gross realized gains
   (losses) from these investments. All income generated from these investments was recorded as
   interest income. We have not recorded any losses relating to municipal variable rate demand notes.
  (was, 2010-11-02, similarity 0.9664):
[0000950123-10-099391:note_history:17]
At September 30, 2010, we held $107.4 million of municipal variable rate demand notes, all of which
   are classified as available-for-sale short-term investments. At September 30, 2010, 33% of our
   municipal variable rate demand notes had a credit rating of AAA, 59% had a credit rating of AA, 8%
   had a credit rating of A, and all contained put options of seven days. Despite the long-term
   nature of their stated contractual maturities, we routinely buy and sell these securities and we
   believe that we have the ability to quickly liquidate them. Our investments in these securities
   are recorded at fair value, and the interest rates reset every seven days. We believe we have the
   ability to sell our variable rate demand notes to the remarketing agent, tender agent or issuer at
   par value plus accrued interest in the event we decide to liquidate our investment in a particular
   variable rate demand note. At September 30, 2010, approximately 32% of our variable rate demand
   notes were supported by letters of credit from banks that we believe to be in good financial
   condition. The remaining 68% of our variable rate demand notes were supported by standby purchase
   agreements. As a result of these factors, we had no cumulative gross unrealized holding gains
   (losses) or gross realized gains (losses) from these investments. All income generated from these
   investments was recorded as interest income. We have not been required to record any losses
   relating to municipal variable rate demand notes.

- changed (2011-05-05):
[0000950123-11-045439:note_history:18]
At March 31, 2011, we held $0.8 million of a fixed income bond fund.
  (was, 2010-11-02, similarity 0.9194):
[0000950123-10-099391:note_history:18]
At September 30, 2010, we held $0.7 million of a fixed income bond fund.

- added (2011-05-05):
[0000950123-11-045439:note_history:19]
At March 31, 2011, we held $44.8 million of marketable equity securities, including a single
   security, of which we held 1.4 million shares, carried at a fair value of $29.8 million. We sold
   93 thousand shares of this security during the three months ended March 31, 2011. The sale of this
   security resulted in proceeds of $2.1 million and a realized gain of $2.0 million. This single
   security traded approximately 1.1 million shares per day in the first quarter of 2011 in an active
   market on a European stock exchange. This single security comprises $29.3 million of the gross
   unrealized gains included in the fair value of our marketable equity securities at March 31, 2011.
   The remaining $3.7 million of gross unrealized gains and $0.1 million of gross unrealized losses at
   March 31, 2011 were spread amongst more than 400 equity securities.

- changed (2011-05-05):
[0000950123-11-045439:note_history:20]
At March 31, 2011, we held a $48.3 million restricted certificate of deposit, which is carried at
   cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At March 31, 2011, the estimated fair value of the Bond was approximately $43.7
   million, based on a debt security with a comparable interest rate and maturity and a Standard and
   Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.
  (was, 2010-11-02, similarity 0.9836):
[0000950123-10-099391:note_history:20]
At September 30, 2010, we held a $48.3 million restricted certificate of deposit, which is carried
   at cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At September 30, 2010, the estimated fair value of the Bond was approximately
   $47.1 million, based on a debt security with a comparable interest rate and maturity and a Standard
   and Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.

- changed (2011-05-05):
[0000950123-11-045439:note_history:21]
At March 31, 2011, we held $2.1 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.8 million at March 31, 2011, based on unobservable inputs including information supplied by the
   company and the fund managers. We have committed to invest up to an aggregate of $7.9 million in
   the two private equity funds, and we have contributed $8.0 million as of March 31, 2011, of which
   $7.4 million has been applied toward these commitments. As of March 31, 2011, we have received
   distributions related to these two private equity funds of $7.2 million, of which $0.9 million was
   recorded as investment income. These investments are
   carried at cost, net of distributions, with distributions in excess of our investment recorded as
   investment income. The duration of each of these commitments is ten years with $0.4 million
   expiring in 2013 and $0.1 million expiring in 2012. We have not been required to record any
   impairment losses related to these investments during the three months ended March 31, 2011.
  (was, 2010-11-02, similarity 0.9133):
[0000950123-10-099391:note_history:21]
At September 30, 2010, we held $2.2 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.2 million at September 30, 2010, based on unobservable inputs including information supplied by
   the company and the fund managers. We have committed to invest up to an aggregate of $7.9 million
   in the two private equity funds, and we have contributed $8.0 million as of September 30, 2010, of
   which $7.5 million has been applied toward these commitments. As of September 30, 2010, we have
   received distributions related to these two private equity funds of $6.7 million, of which $0.9
   million was recorded as a realized investment gain. These investments are carried at cost, net of
   distributions, with distributions in excess of our investment recorded as a realized investment
   gain. The duration of each of these commitments is ten years with $0.1 million expiring in 2010
   and $0.3 million expiring in 2012. We have not been required to record any impairment losses
   related to these investments during the nine months ended September 30, 2010.

- changed (2011-05-05):
[0000950123-11-045439:note_history:22]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $4 thousand during the first
   quarter of 2011 related to one marketable equity security. For the three months ended March 31,
   2010, we recorded an other-than-temporary impairment charge of $2 thousand related to one
   marketable equity security.
  (was, 2010-11-02, similarity 0.7747):
[0000950123-10-099391:note_history:22]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to
   the following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $43 thousand during the nine
   months ending September 30, 2010 related to five marketable equity securities. For the nine months
   ended September 30, 2009, we recorded an other-than-temporary impairment charge of $2.0 million
   related to 117 marketable equity securities. In addition to the impairment charge we recorded on
   our marketable equity securities, we recorded an impairment charge of $0.4 million related to our
   investment in a fixed income bond fund and $0.5 million related to our deferred compensation plan
   assets during the first nine months of 2009 as a result of similar reviews. There were no
   impairment charges related to the fixed income bond fund or deferred compensation plan assets
   during the nine months ended September 30, 2010.

- changed (2011-05-05):
[0000950123-11-045439:note_history:23]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have
   categorized our cash equivalents held in money market funds and our investments held at fair value
   into a three-level fair value hierarchy based on the priority of the inputs to the valuation
   technique for the cash equivalents and investments as follows: Level 1 — Values based on
   unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 — Values
   based on quoted prices in markets that are not active or model inputs that are observable either
   directly or indirectly; Level 3 — Values based on prices or valuation techniques that require
   inputs that are both unobservable and significant to the overall fair value measurement. These
   inputs include information supplied by investees.
  (was, 2010-11-02, similarity 0.9926):
[0000950123-10-099391:note_history:23]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have
   categorized our cash equivalents held in money market funds and our investments held at fair value
   into a three-level fair value hierarchy based on the priority of the inputs to the valuation
   technique for the cash equivalents and investments as follows: Level 1 — Values based on
   unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 — Values
   based on quoted prices in markets that are not active or model inputs that are observable either
   directly or indirectly; Level 3 — Values based on prices or valuation techniques that require
   inputs that are both unobservable and significant to the overall fair value measurement. These
   inputs include information supplied by issuers.

- added (2011-05-05):
[0000950123-11-045439:note_history:24]
|  |  | Fair Value Measurements at March 31, 2011 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 14,276 |  |  | $ | 14,276 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 6,577 |  |  |  | 6,577 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 184,135 |  |  |  | — |  |  |  | 184,135 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 134,018 |  |  |  | — |  |  |  | 134,018 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 58,710 |  |  |  | — |  |  |  | 58,710 |  |  |  | — |  |
| Fixed income bond fund |  |  | 759 |  |  |  | 759 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 31,201 |  |  |  | 31,201 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 13,600 |  |  |  | 13,600 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 429,000 |  |  |  | 52,137 |  |  |  | 376,863 |  |  |  | — |  |
| Total |  | $ | 443,276 |  |  | $ | 66,413 |  |  | $ | 376,863 |  |  | $ | — |  |

- added (2011-05-05):
[0000950123-11-045439:note_history:25]
|  |  | Fair Value Measurements at December 31, 2010 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 14,532 |  |  | $ | 14,532 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 4,246 |  |  |  | 4,246 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 127,072 |  |  |  | — |  |  |  | 127,072 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 71,467 |  |  |  | — |  |  |  | 71,467 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | 116,745 |  |  |  | — |  |
| Fixed income bond fund |  |  | 746 |  |  |  | 746 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 35,596 |  |  |  | 35,596 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 12,414 |  |  |  | 12,414 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 368,286 |  |  |  | 53,002 |  |  |  | 315,284 |  |  |  | — |  |
| Total |  | $ | 382,818 |  |  | $ | 67,534 |  |  | $ | 315,284 |  |  | $ | — |  |

- changed (2011-05-05):
[0000950123-11-045439:note_history:26]
As of March 31, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 corporate bonds and municipal fixed-rate bonds was $318.2 million and $198.5 million,
   respectively. The fair value of these securities is calculated using a weighted average market
   price for each security. Market prices are obtained from a variety of industry standard data
   providers, security master files from large financial institutions, and other third-party sources.
   These multiple market prices are used as inputs into a distribution-curve-based algorithm to
   determine the daily market value of each security.
  (was, 2010-11-02, similarity 0.9885):
[0000950123-10-099391:note_history:26]
As of September 30, 2010 and December 31, 2009, the fair value of the investments in
   available-for-sale Level 2 corporate bonds and municipal fixed-rate bonds was $194.1 million and
   $161.7 million, respectively. The fair value of these securities is calculated using a weighted
   average market price for each security. Market prices are obtained from a variety of industry
   standard data providers, security master files from large financial institutions, and other
   third-party sources. These multiple market prices are used as inputs into a
   distribution-curve-based algorithm to determine the daily market value of each security.

- changed (2011-05-05):
[0000950123-11-045439:note_history:27]
As of March 31, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 municipal variable rate demand notes was $58.7 million and $116.7 million, respectively.
   These securities have a structure that implies a standard expected market price. The frequent
   interest rate resets make it reasonable to expect the price to stay at par. These securities are
   priced at the expected market price.
  (was, 2010-11-02, similarity 0.9828):
[0000950123-10-099391:note_history:27]
As of September 30, 2010 and December 31, 2009, the fair value of the investments in
   available-for-sale Level 2 municipal variable rate demand notes was $107.4 million and $84.4
   million, respectively. These securities have a structure that implies a standard expected market
   price. The frequent interest rate resets make it reasonable to expect the price to stay at par.
   These securities are priced at the expected market price.

- removed (2011-05-05):
[0000950123-10-099391:note_history:28]
At September 30, 2010, we held $38.6 million of marketable equity securities, including a single
   security, of which we held 1.6 million shares, carried at a fair value of $26.6 million. We sold
   416 thousand shares of this security during the nine months ended September 30, 2010. The sales
   resulted in proceeds of $6.2 million and a realized gain of $6.0 million. This single security
   traded approximately 1.1 million shares per day in the first nine months of 2010 in an active
   market on a European stock exchange. This single security comprises $26.1 million of the gross
   unrealized gains included in the fair value of our marketable equity securities at September 30,
   2010. The remaining $2.5 million of gross unrealized gains and $0.3 million of gross unrealized
   losses at September 30, 2010 were spread among 397 equity securities.

- removed (2011-05-05):
[0000950123-10-099391:note_history:29]
|  |  | Fair Value Measurements at September 30, 2010 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 12,569 |  |  | $ | 12,569 |  |  | $ | — |  |  | $ | — |  |
| Deferred compensation plan assets |  |  | 3,911 |  |  |  | 3,911 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 110,348 |  |  |  | — |  |  |  | 110,348 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 83,782 |  |  |  | — |  |  |  | 83,782 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 107,420 |  |  |  | — |  |  |  | 107,420 |  |  |  | — |  |
| Fixed income bond fund |  |  | 742 |  |  |  | 742 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities — technology industry |  |  | 27,802 |  |  |  | 27,802 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities — other |  |  | 10,767 |  |  |  | 10,767 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 344,772 |  |  |  | 43,222 |  |  |  | 301,550 |  |  |  | — |  |
| Total |  | $ | 357,341 |  |  | $ | 55,791 |  |  | $ | 301,550 |  |  | $ | — |  |

- removed (2011-05-05):
[0000950123-10-099391:note_history:30]
|  |  | Fair Value Measurements at December 31, 2009 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 18,370 |  |  | $ | 18,370 |  |  | $ | — |  |  | $ | — |  |
| Deferred compensation plan assets |  |  | 3,424 |  |  |  | 3,424 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,414 |  |  |  | — |  |  |  | 20,414 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 141,285 |  |  |  | — |  |  |  | 141,285 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 84,359 |  |  |  | — |  |  |  | 84,359 |  |  |  | — |  |
| Fixed income bond fund |  |  | 1,163 |  |  |  | 1,163 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities — technology industry |  |  | 23,491 |  |  |  | 23,491 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities — other |  |  | 10,044 |  |  |  | 10,044 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 284,180 |  |  |  | 38,122 |  |  |  | 246,058 |  |  |  | — |  |
| Total |  | $ | 302,550 |  |  | $ | 56,492 |  |  | $ | 246,058 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2011-05-05):
[0000950123-11-045439:note_history:31]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three months ended March 31, 2011 and 2010, we incurred fees of $10 thousand per month
   for these legal services.
  (was, 2010-11-02, similarity 0.9317):
[0000950123-10-099391:note_history:31]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three and nine month periods ended September 30, 2010 and 2009, we incurred fees of
   $10 thousand per month for these legal services.


## us-gaap:ScheduleOfSubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2011-05-05):
[0000950123-11-045439:note_history:32]
On April 12, 2011, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on April 28,
   2011. The payment date will be May 12, 2011. The quarterly dividend payment will be approximately
   $5.8 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends
   on our common stock considering the tax treatment of dividends and adequate levels of Company
   liquidity.
  (was, 2010-11-02, similarity 0.953):
[0000950123-10-099391:note_history:32]
On October 12, 2010, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on October 28,
   2010. The payment date will be November 11, 2010. The quarterly dividend payment will be
   approximately $5.7 million. In July 2003, our Board of Directors elected to begin declaring
   quarterly dividends on our common stock considering the favorable tax treatment of dividends and
   adequate levels of Company liquidity.
