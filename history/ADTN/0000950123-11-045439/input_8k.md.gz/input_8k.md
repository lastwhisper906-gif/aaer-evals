# ADTN 8-K — 0001157523-11-002001 filed 2011-04-13

## item codes, every 8-K on or before 2011-05-05

- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2011-05-05

- none on or before 2011-05-05

## item 2.02 — earnings release, exhibit 99.1

[0001157523-11-002001:8k_2_02:1]
EX-99.1
2
a6682016ex99_1.htm
EXHIBIT 99.1

[0001157523-11-002001:8k_2_02:2]
Exhibit 99.1

[0001157523-11-002001:8k_2_02:3]
ADTRAN,
      Inc. Reports Record Results for First Quarter 2011 and Declares
      Quarterly Cash Dividend

[0001157523-11-002001:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--April 12, 2011--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the first quarter of 2011. Sales
      increased 30% to an all time record level of $165,522,000 for the
      quarter, compared to $127,027,000 for the first quarter of 2010.
      Operating income increased 80% to $45,606,000 for the quarter compared
      to $25,345,000 for the first quarter of 2010. Net income increased 88%
      to $34,258,000 for the quarter, compared to $18,194,000 for the first
      quarter of 2010. Earnings per share, assuming dilution, increased 79% to
      $0.52 for the quarter, compared to $0.29 for the first quarter of 2010.

[0001157523-11-002001:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “For the quarter our
      combined growth areas grew 51% over the previous year, allowing the
      company to achieve its fourth consecutive quarterly revenue record.
      Moreover, each of the individual segments within this category achieved
      new records. Broadband Access saw revenue growth of 42% over first
      quarter 2010, led by the continued success of our Total Access 5000
      platform. Our Internetworking category grew 48%, fueled by channel
      expansion and growing acceptance of new applications. Optical Access
      grew an impressive 86%, driven by the increasing demand for mobile data.
      We are pleased with the long term prospects of the markets we serve and
      our company’s position to deliver positive results.”

[0001157523-11-002001:8k_2_02:6]
The Company reported that stock-based compensation expense for the first
      quarter of 2011 reduced diluted earnings per share by $0.03 compared to
      a reduction of $0.02 for the first quarter of 2010.

[0001157523-11-002001:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash
      dividend for the first quarter of 2011. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on April 28, 2011. The ex-dividend date is April 26, 2011 and
      the payment date is May 12, 2011.

[0001157523-11-002001:8k_2_02:8]
The Company confirmed that its first quarter conference call will be
      held Wednesday, April 13, 2011 at 9:30 a.m. Central Time. This
      conference call will be web cast live through StreetEvents.com. To
      listen, simply visit the Investor Relations site at http://www.adtran.com
      or http://streetevents.com approximately 10 minutes prior to the
      start of the call and click on the conference call link provided.

[0001157523-11-002001:8k_2_02:9]
An online replay of the conference call will be available for seven days
      at http://streetevents.com. In addition, an online replay of the
      conference call, as well as the text of the Company's earnings release,
      will be available on the Investor Relations site at http://www.adtran.com
      for at least 12 months following the call.

[0001157523-11-002001:8k_2_02:10]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment, with a portfolio of more than 1,700 solutions
      for use in the last mile of today's telecommunications networks. Widely
      deployed by carriers and enterprises alike, ADTRAN solutions enable
      voice, data, video, and Internet communications across a variety of
      network infrastructures. ADTRAN solutions are currently in use by every
      major U.S. service provider and many global ones, as well as by
      thousands of public, private and governmental organizations worldwide.

[0001157523-11-002001:8k_2_02:11]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-11-002001:8k_2_02:12]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2010. These risks and uncertainties could cause actual results to
      differ materially from those in the forward-looking statements included
      in this press release.

[0001157523-11-002001:8k_2_02:13]
| Condensed Consolidated Balance Sheet Unaudited (In thousands) |
|  |  | March 31,2011 |  | December 31,2010 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 37,321 |  | $ | 31,677 |
| Short-term investments |  |  | 99,522 |  |  | 157,479 |
| Accounts receivable, net |  |  | 84,455 |  |  | 70,893 |
| Other receivables |  |  | 12,687 |  |  | 3,962 |
| Income tax receivable, net |  |  | - |  |  | 2,741 |
| Inventory |  |  | 79,034 |  |  | 74,274 |
| Prepaid expenses |  |  | 3,410 |  |  | 3,270 |
| Deferred tax assets, net |  |  | 12,084 |  |  | 10,617 |
| Total current assets |  |  | 328,513 |  |  | 354,913 |
| Property, plant and equipment, net |  |  | 74,382 |  |  | 73,986 |
| Other assets |  |  | 1,904 |  |  | 1,915 |
| Long-term investments |  |  | 379,831 |  |  | 261,160 |
| Total assets |  | $ | 784,630 |  | $ | 691,974 |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Accounts payable |  | $ | 33,902 |  | $ | 22,785 |
| Unearned revenue |  |  | 17,516 |  |  | 10,138 |
| Accrued expenses |  |  | 5,248 |  |  | 4,913 |
| Accrued wages and benefits |  |  | 11,237 |  |  | 12,125 |
| Income tax payable, net |  |  | 1,699 |  |  | - |
| Total current liabilities |  |  | 69,602 |  |  | 49,961 |
| Deferred tax liabilities, net |  |  | 11,978 |  |  | 10,350 |
| Other non-current liabilities |  |  | 14,632 |  |  | 11,841 |
| Bonds payable |  |  | 46,500 |  |  | 47,500 |
| Total liabilities |  |  | 142,712 |  |  | 119,652 |
| Stockholders' equity |  |  | 641,918 |  |  | 572,322 |
| Total liabilities and stockholders' equity |  | $ | 784,630 |  | $ | 691,974 |

[0001157523-11-002001:8k_2_02:14]
| Consolidated Statements of Income Unaudited (In thousands, except per share data) |
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  |  | 2011 |  |  |  | 2010 |  |
| Sales |  | $ | 165,522 |  |  | $ | 127,027 |  |
| Cost of Sales |  |  | 66,727 |  |  |  | 51,699 |  |
| Gross Profit |  |  | 98,795 |  |  |  | 75,328 |  |
| Selling, general and administrative expenses |  |  | 29,552 |  |  |  | 27,204 |  |
| Research and development expenses |  |  | 23,637 |  |  |  | 22,779 |  |
| Operating Income |  |  | 45,606 |  |  |  | 25,345 |  |
| Interest and dividend income |  |  | 1,789 |  |  |  | 1,527 |  |
| Interest expense |  |  | (602 | ) |  |  | (603 | ) |
| Net realized investment gain |  |  | 2,767 |  |  |  | 2,192 |  |
| Other expense, net |  |  | (125 | ) |  |  | (187 | ) |
| Income before provision for income taxes |  |  | 49,435 |  |  |  | 28,274 |  |
| Provision for income taxes |  |  | (15,177 | ) |  |  | (10,080 | ) |
| Net Income |  | $ | 34,258 |  |  | $ | 18,194 |  |
| Weighted average shares outstanding - basic |  |  | 64,189 |  |  |  | 61,999 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 65,957 |  |  |  | 63,060 |  |
| Earnings per common share - basic |  | $ | 0.53 |  |  | $ | 0.29 |  |
| Earnings per common share - diluted (1) |  | $ | 0.52 |  |  | $ | 0.29 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001157523-11-002001:8k_2_02:15]
| Supplemental Information Stock-based Compensation Expense Unaudited (In thousands) |
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  |  | 2011 |  |  |  | 2010 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 91 |  |  | $ | 68 |  |
| Selling, general and administrative expense |  |  | 1,007 |  |  |  | 750 |  |
| Research and development expense |  |  | 991 |  |  |  | 871 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,998 |  |  |  | 1,621 |  |
| Total stock-based compensation expense |  |  | 2,089 |  |  |  | 1,689 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (440 | ) |  |  | (177 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,649 |  |  | $ | 1,512 |  |

[0001157523-11-002001:8k_2_02:16]
| Consolidated Statements of Cash Flow Unaudited (In thousands) |
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  |  | 2011 |  |  |  | 2010 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 34,258 |  |  | $ | 18,194 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 2,724 |  |  |  | 2,593 |  |
| Amortization of net premium on available-for-sale investments |  |  | 1,299 |  |  |  | 1,102 |  |
| Net realized gain on long-term investments |  |  | (2,767 | ) |  |  | (2,192 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | 12 |  |  |  | (3 | ) |
| Stock-based compensation expense |  |  | 2,089 |  |  |  | 1,689 |  |
| Deferred income taxes |  |  | 877 |  |  |  | (1,768 | ) |
| Tax benefit from stock option exercises |  |  | 9,942 |  |  |  | 437 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (8,847 | ) |  |  | (373 | ) |
| Change in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | (13,562 | ) |  |  | (6,096 | ) |
| Other receivables |  |  | (8,725 | ) |  |  | (5,955 | ) |
| Income tax receivable, net |  |  | 2,741 |  |  |  | - |  |
| Inventory |  |  | (4,760 | ) |  |  | (2,125 | ) |
| Prepaid expenses and other assets |  |  | (216 | ) |  |  | (371 | ) |
| Accounts payable |  |  | 10,117 |  |  |  | 8,989 |  |
| Accrued expenses and other liabilities |  |  | 9,606 |  |  |  | 4,211 |  |
| Income tax payable, net |  |  | 1,699 |  |  |  | 8,688 |  |
| Net cash provided by operating activities |  |  | 36,487 |  |  |  | 27,020 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (3,045 | ) |  |  | (2,329 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 161,687 |  |  |  | 56,095 |  |
| Purchases of available-for-sale investments |  |  | (224,459 | ) |  |  | (64,956 | ) |
| Net cash used in investing activities |  |  | (65,817 | ) |  |  | (11,190 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from stock option exercises |  |  | 31,815 |  |  |  | 2,340 |  |
| Purchases of treasury stock |  |  | - |  |  |  | (10,330 | ) |
| Dividend payments |  |  | (5,775 | ) |  |  | (5,577 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | 8,847 |  |  |  | 373 |  |
| Net cash provided by (used in) financing activities |  |  | 34,887 |  |  |  | (13,194 | ) |
| Net increase in cash and cash equivalents |  |  | 5,557 |  |  |  | 2,636 |  |
| Effect of exchange rate changes |  |  | 87 |  |  |  | 168 |  |
| Cash and cash equivalents, beginning of period |  |  | 31,677 |  |  |  | 24,135 |  |
| Cash and cash equivalents, end of period |  | $ | 37,321 |  |  | $ | 26,939 |  |

[0001157523-11-002001:8k_2_02:17]
CONTACT:
ADTRAN, Inc.
Jim Matthews, 256-963-8775
Senior Vice
      President/CFO
or
INVESTOR SERVICES/ASSISTANCE:
Gayle
      Ellis, 256-963-8220
