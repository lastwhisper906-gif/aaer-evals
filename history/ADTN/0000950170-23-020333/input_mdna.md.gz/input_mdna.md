# ADTN MD&A — 0000950170-23-020333


## mdna

[0000950170-23-020333:mdna:1]
[same as prior period, unchanged from 0000950170-22-023803:mdna:1]

[0000950170-23-020333:mdna:2]
The following discussion should be read in conjunction with the Condensed Consolidated Financial Statements and the related notes that appear in Part I, Item 1 of this document. In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2022, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1, Business, and Item 1A, Risk Factors, included in our 2022 Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023.

[0000950170-23-020333:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our Condensed Consolidated Financial Statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our Condensed Consolidated Financial Statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 3 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part 1, Item 1A, Risk Factors, of the 2022 Form 10‑K and Part II, Item 1A, Risk Factors of this Form 10-Q.

[0000950170-23-020333:mdna:4]
[same as prior period, unchanged from 0000950170-22-023803:mdna:4]

[0000950170-23-020333:mdna:5]
[same as prior period, unchanged from 0000950170-22-023803:mdna:5]

[0000950170-23-020333:mdna:6]
The Company is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales, administrative and research and development facilities in strategic global locations.

[0000950170-23-020333:mdna:7]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of ADVA Optical Networking SE ("ADVA"). ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. ADVA is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge.

[0000950170-23-020333:mdna:8]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. In addition to the Company's reportable segments, revenue is also reported for the following three categories – Subscriber Solutions, Access & Aggregation Solutions, and Optical Networking Solutions.

[0000950170-23-020333:mdna:9]
Prior to the Business Combination with ADVA on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with ADVA, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable ADVA solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable ADVA solutions to create Subscriber Solutions and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of ADVA’s portfolio.

[0000950170-23-020333:mdna:10]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at the customer premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers and cloud software solutions covering a mix of subscriber types.

[0000950170-23-020333:mdna:11]
Our Access & Aggregation Solutions are solutions that are used by communications Service Providers to connect residential subscribers, business subscribers and mobile radio networks to the Service Providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions and access orchestration solutions that ensure highly reliable and efficient network performance.

[0000950170-23-020333:mdna:12]
Our Optical Networking Solutions are used by communications Service Providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems and automation platforms that are used to build high-scale, secure and assured optical networks.

[0000950170-23-020333:mdna:13]
ADVA DOMINATION AND PROFIT AND LOSS TRANSFER AGREEMENT

[0000950170-23-020333:mdna:14]
The DPLTA between the Company, as the controlling company, and ADVA Optical Networking SE, as the controlled company, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of ADVA (Jena).

[0000950170-23-020333:mdna:15]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is
entitled to issue binding instructions to the management board of ADVA, (ii) ADVA will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by ADVA. The obligation of ADVA to transfer its annual profit to the Company applies for the first time to the profit, if any, generated in the ADVA fiscal year 2023. The obligation of the Company to absorb ADVA’s annual net loss applies for the first time to the loss, if any, generated in the ADVA fiscal year 2023.

[0000950170-23-020333:mdna:16]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that ADVA shareholders (other than the Company) be offered, at their election, (i) to put their ADVA shares to the Company in exchange for compensation in cash of EUR 17.21 per share (the “Exit Compensation”), or (ii) to remain ADVA shareholders and receive a recurring compensation in cash of EUR 0.59 (EUR 0.52 net under the current tax regime) per share for each full fiscal year of ADVA (the “Annual Recurring Compensation”). The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of ADVA for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of ADVA in 2024. The adequacy of both forms of compensation has been challenged by minority shareholders of ADVA via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

[0000950170-23-020333:mdna:17]
The opportunity for outside ADVA shareholders to tender ADVA shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-020333:mdna:18]
We currently hold 33,957,538 no-par value bearer shares of ADVA, representing 65.37% of ADVA’s outstanding shares as of March 31, 2023.

[0000950170-23-020333:mdna:19]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which is incorporated by reference to Exhibit 10.5 of the 2022 Form 10-K filed with the SEC on March 1, 2023.

[0000950170-23-020333:mdna:20]
During the three months ended March 31, 2023, we did not incur transaction costs related to the Business Combination. During the three months ended March 31, 2022, we recognized $1.5 million of transaction costs relating to the Business Combination.

[0000950170-23-020333:mdna:21]
MULTI-YEAR INTEGRATION PROGRAM

[0000950170-23-020333:mdna:22]
During the fourth quarter of 2022, the Company initiated a multi-year integration program designed to optimize the assets, business processes, and information technology systems of the Company.

[0000950170-23-020333:mdna:23]
The program has identified several potential cost synergies, including:

[0000950170-23-020333:mdna:24]
•
realizing operational scale;

[0000950170-23-020333:mdna:25]
•
combined sales channels;

[0000950170-23-020333:mdna:26]
•
streamlining corporate and general and administrative functions; and

[0000950170-23-020333:mdna:27]
•
combined sourcing and production costs.

[0000950170-23-020333:mdna:28]
We have and will continue to invest significant dollars to restructure the workforce, optimize legacy systems, streamline legal entities and consolidate real estate holdings. By executing these integration activities, we expect to deliver greater innovation for customers, career enrichment opportunities for employees, and enhanced value for shareholders. During the three months ended March 31, 2023, we recognized $0.8 million of integration costs related to the Business Combination that are included in selling, general and administrative expenses in the Condensed Consolidated Statement of Loss. We expect to incur integration costs and costs associated with the implementation of the DPLTA during 2023 and such costs are expected to be material.

[0000950170-23-020333:mdna:29]
During the three months ended March 31, 2023, we recognized $2.4 million of restructuring costs relating to the Business Combination that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss. See Note 21 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-23-020333:mdna:30]
[same as prior period, unchanged from 0000950170-22-023803:mdna:19]

[0000950170-23-020333:mdna:31]
We ended the first quarter of 2023 with a year-over-year revenue increase of 109.6% as compared to the three months ended March 31, 2022, driven by increased volume of sales activity due to the Business Combination with ADVA and to Service Provider customers. During the first quarter of 2023, we had two 10% revenue customers, both of which were international Service Provider customers and our five largest customers comprised 40.0% of our revenue. Our year-over-year domestic revenue increased by 32.7%, driven by increased sales volume due to the Business Combination with ADVA, partially offset by decreases due to customer inventory corrections which impacted our Subscriber Solutions and Access & Aggregation product lines. Internationally, our revenue increased by 246.9% compared to the prior year period, primarily driven by increased volume of sales activity due to the Business Combination with ADVA, partially offset by decreases due to customer inventory corrections which primarily impacted our Subscriber Solutions product line.

[0000950170-23-020333:mdna:32]
Growing customer concerns over inventory stocking levels affected our first quarter Subscriber Solutions category. We believe that this over-supply of CPE products will continue into the second quarter of 2023. Revenue for our Access and Optical Networking products

[0000950170-23-020333:mdna:33]
grew sequentially. Supply constraints, however, limited our flexibility to clear past-due backlog across all product categories. We believe that the inventory impact is transitory, and we expect to see some improvement to both the over-supply of CPE products and the backlog of products across all categories in the coming quarters. We plan to adjust operating expenditures in the near term to reflect current market conditions; however, we do not see any material changes to our near-term opportunities and our long-term growth catalysts as carriers around the world race to upgrade their networks to fiber. Although we expect our revenue growth and profitability in the near-term to continue to be negatively impacted by supply chain issues, our outlook continues to strengthen given the increased demand for our products and our expectation of an improving supply chain over the longer term.

[0000950170-23-020333:mdna:34]
The coronavirus ("COVID-19") pandemic and related countermeasures previously impacted our operations. Notwithstanding improvement in many markets in which we operate due to a return to more normalized business operations, certain markets continue to be adversely impacted by COVID-19 or as a result of policies relating to COVID-19.

[0000950170-23-020333:mdna:35]
Additionally, due to the pandemic and a global semiconductor chip shortage, we experienced disruption and delays in our supply chain and significant price increases with certain of our manufacturing partners, and those disruptions, delays and price increases may continue. For example, throughout 2022, our results of operations were negatively impacted by increased expenses resulting from supply chain disruptions. The current global supply chain and transportation constraints, including delays in supply chain deliveries and the related global semi-conductor chip shortage, may continue to have a material adverse effect on our operating results and could have a material adverse effect on customer relations and our financial condition. These supply chain challenges and their adverse impact on our industry began to ease during the first quarter of 2023. However, there can be no assurance that the ongoing disruptions due to COVID-19, the related global semiconductor chip shortage or other supply chain constraints or price increases will be resolved in the near term, which could continue to adversely affect our business, financial condition, and results of operations.

[0000950170-23-020333:mdna:36]
Our operating results have fluctuated and may continue to fluctuate on a quarterly basis due to several factors, including customer order activity, supply chain constraints, component availability, the Company's consolidation, purchase accounting, and integration with ADVA. Further, a significant percentage of orders require delivery within a few days requiring us to maintain higher inventory levels. These factors may result in limited order flow visibility. However, with the current global supply chain and limited availability of semiconductor chips and other components of our products, we have experienced and may continue to experience extended lead times, increased logistics intervals and costs, and lower volume of products deliveries, which have had and may continue to have a material adverse effect on our operating results and could have a material adverse effect on customer relations and our financial condition. We believe these supply chain challenges and their adverse impact on our industry will continue at least through fiscal 2023 and expect that the extended lead times and elevated supply chain costs experienced by our industry will persist for the reasonably foreseeable future. It is unclear when the supply environment will become less volatile and what impacts the supply environment will have on the industry in future periods. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0000950170-23-020333:mdna:37]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, inflation, regional conflicts, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Specifically, we expect inflationary pressures on input costs, such as raw materials and labor, and distribution costs to increase. We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors, and customers to address and to limit the disruption to our operations and order fulfillment. Our attempts to offset these cost pressures, such as through increases in the selling prices of some of our products and services, may not be successful and could negatively affect our operating results. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to ensure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results.

[0000950170-23-020333:mdna:38]
We are exposed to changes in foreign currencies relative to the U.S. dollar, which are references to the differences between the foreign-exchanges rates we use to convert the financial results of our international operations from local currencies into U.S. dollars for financial reporting purposes. This impact of foreign-exchange rate changes is calculated based on the difference between the current period’s currency exchange rates and that of the comparable prior period. Our primary exposures to foreign currency exchange rate movements are with the Euro and the British pound sterling. As a result of our global operations, our revenue, gross margins, operating expense and operating income (loss) in some international markets have been and may continue to be affected by foreign currency fluctuations.

[0000950170-23-020333:mdna:39]
Our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Part I, Item 1A of the 2022 Form 10-K and Part II, Item 1A of this Form 10-Q.

[0000950170-23-020333:mdna:40]
[same as prior period, unchanged from 0000950170-22-023803:mdna:35]

[0000950170-23-020333:mdna:41]
[same as prior period, unchanged from 0000950170-22-023803:mdna:36]

[0000950170-23-020333:mdna:42]
42

[0000950170-23-020333:mdna:43]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2023 COMPARED TO THE THREE MONTHS ENDED MARCH 31, 2022

[0000950170-23-020333:mdna:44]
[same as prior period, unchanged from 0000950170-22-023803:mdna:38]

[0000950170-23-020333:mdna:45]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2023 |  |  | 2022 |  |  |
| Revenue |  |  |  |  |  |  |  |
| Network Solutions |  |  | 87.2 |  | % |  | 89.6 |  | % |
| Services & Support |  |  | 12.8 |  |  |  | 10.4 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |
| Network Solutions |  |  | 67.7 |  |  |  | 58.7 |  |  |
| Services & Support |  |  | 5.2 |  |  |  | 6.2 |  |  |
| Total Cost of Revenue |  |  | 72.9 |  |  |  | 64.8 |  |  |
| Gross Profit |  |  | 27.1 |  |  |  | 35.2 |  |  |
| Selling, general and administrative expenses |  |  | 20.8 |  |  |  | 18.1 |  |  |
| Research and development expenses |  |  | 21.7 |  |  |  | 17.1 |  |  |
| Operating Loss |  |  | (15.4 | ) |  |  | — |  |  |
| Interest and dividend income |  |  | 0.1 |  |  |  | 0.1 |  |  |
| Interest expense |  |  | (1.0 | ) |  |  | — |  |  |
| Net investment gain (loss) |  |  | 0.4 |  |  |  | (2.2 | ) |  |
| Other expense, net |  |  | (0.1 | ) |  |  | (0.1 | ) |  |
| Loss Before Income Taxes |  |  | (16.0 | ) |  |  | (2.3 | ) |  |
| Income tax benefit |  |  | 3.5 |  |  |  | 1.6 |  |  |
| Net Loss |  |  | (12.5 | ) | % |  | (0.7 | ) | % |
| Less: Net Loss attributable to non-controlling interest |  |  | (1.8 | ) |  |  | — |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | (10.6 | ) | % |  | (0.7 | ) | % |

[0000950170-23-020333:mdna:46]
[same as prior period, unchanged from 0000950170-22-023803:mdna:40]

[0000950170-23-020333:mdna:47]
Our revenue increased 109.6% from $154.5 million for the three months ended March 31, 2022 to $323.9 million for the three months ended March 31, 2023. The increase in revenue for the three months ended March 31, 2023 is primarily attributable to a $192.3 million increase in volume of sales activity due to the Business Combination with ADVA partially offset by a $22.9 million decrease in volume of sales activity related to our ADTRAN, Inc. operations. The increase in revenue by category for the three months ended March 31, 2023 was primarily attributable to a $147.8 million increase in Optical Networking Solutions products due to the Business Combination with ADVA, and a $22.6 million increase in Subscriber Solutions products, partially offset by a $1.0 million decrease in Access & Aggregation Solutions revenue. Growing customer concerns over inventory stocking levels affected our first quarter Subscriber Solutions category. We believe that this over-supply of CPE products will continue into the second quarter of 2023. Revenue for our Access and Optical Networking products grew sequentially. Supply constraints, however, limited our flexibility to clear past-due backlog across all product categories. We believe that the inventory impact is transitory, and we expect to see some improvement to both the over-supply of CPE products and the backlog of products across all categories in the coming quarters. We do not see any material changes to our near-term opportunities and our long-term growth catalysts as carriers around the world upgrade their networks to fiber.

[0000950170-23-020333:mdna:48]
Network Solutions segment revenue increased 104.1% from $138.4 million for the three months ended March 31, 2022 to $282.4 million for the three months ended March 31, 2023. The increase in revenue for the three months ended March 31, 2023 was due primarily to the increase of $167.0 million in volume of sales activity due to the Business Combination with ADVA, partially offset by a decrease of $11.1 million and $11.8 million in Subscriber Solutions products and Access & Aggregation Solutions in our ADTRAN, Inc. operations, respectively.

[0000950170-23-020333:mdna:49]
Services & Support segment revenue increased 157.0% from $16.1 million for the three months ended March 31, 2022 to $41.5 million for the three months ended March 31, 2023. The increase in revenue for the three months ended March 31, 2023 was primarily attributable to the increase of $25.3 million in volume of sales activity from the Business Combination with ADVA and a $0.8 million increase in revenue for Subscriber Solutions services in our ADTRAN, Inc. operations, partially offset by a decrease of $0.7 million of Access & Aggregation Solutions services in our ADTRAN, Inc. operations.

[0000950170-23-020333:mdna:50]
Domestic revenue increased by 32.7% from $99.0 million for the three months ended March 31, 2022 to $131.5 million for the three months ended March 31, 2023, driven by increased volume of network termination and fiber CPE in our Network Solutions segment.

[0000950170-23-020333:mdna:51]
In addition, such growth was a result of increased revenue to Tier-2 and Tier-3 customers with diversified businesses among our fiber access and CPE, Service Provider CPE and services.

[0000950170-23-020333:mdna:52]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., increased by 246.9% from $55.5 million for the three months ended March 31, 2022 to $192.4 million for the three months ended March 31, 2023. International revenue, as a percentage of total revenue, increased from 35.9% for the three months ended March 31, 2022 to 59.4% for the three months ended March 31, 2023. This change was primarily attributable to the increase in volume of $130.4 million in sales activity from the Business Combination with ADVA and increased shipments to a Tier-1 network operator and multiple alternative network operators in Europe. While international revenue has increased to approximately 59% of total revenues for the three months ended March 31, 2023, the mix of our Network Solutions and Services & Support segments as a percentage of total international revenue remains relatively linear. For the three months ended March 31, 2023 as compared to the three months ended March 31, 2022, changes in foreign currencies relative to the U.S. dollar decreased our net revenue by approximately $10.1 million.

[0000950170-23-020333:mdna:53]
Our ADTRAN, Inc. international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and, in some instances, regionally – whether of a multi-country region or a more local region within a country. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income. Our ADVA international revenue is largely focused on the manufacture and selling of networking solutions that are based on three core areas of expertise: fiber-optic transmission technology (cloud interconnect), cloud access technology for rapid creation of innovative services around the network edge and solutions for precise timing and synchronization of networks. In addition, ADVA's international operations offers a comprehensive portfolio of network design, implementation and maintenance services to assist operators in the deployment of market-leading networks while reducing costs to maintain these networks.

[0000950170-23-020333:mdna:54]
[same as prior period, unchanged from 0000950170-22-023803:mdna:48]

[0000950170-23-020333:mdna:55]
As a percentage of revenue, cost of revenue increased from 64.8% for the three months ended March 31, 2022 to 72.9% for the three months ended March 31, 2023. The increase was primarily attributable to $32.6 million of adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with ADVA, acquisition related expenses, and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations. As the current inventory that was acquired in the Business Combination with ADVA is sold, we expect that our cost of revenue as a percentage of revenue will return to more normalized levels. For the three months ended March 31, 2023 as compared to the three months ended March 31, 2022, changes in foreign currencies relative to the U.S. dollar decreased our cost of revenue by approximately $2.0 million. See additional information related to amortization lives and expense in Notes 2 and 10 of Notes to the Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-23-020333:mdna:56]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 65.5% for the three months ended March 31, 2022 to 77.6% for the three months ended March 31, 2023. The increase in cost of revenue as a percentage of revenue was primarily attributable to acquisition related expenses, amortizations and adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with ADVA and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations.

[0000950170-23-020333:mdna:57]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 59.1% for the three months ended March 31, 2022 to 40.9% for the three months ended March 31, 2023. The decrease in cost of revenue as a percentage of revenue was primarily attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with ADVA.

[0000950170-23-020333:mdna:58]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0000950170-23-020333:mdna:59]
GROSS PROFIT

[0000950170-23-020333:mdna:60]
As a percentage of revenue, gross profit decreased from 35.2% for the three months ended March 31, 2022 to 27.1% for the three months ended March 31, 2023. The decrease was primarily attributable to increases in cost of revenue related to $32.6 million of adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through

[0000950170-23-020333:mdna:61]
to cost of revenue as a result of the Business Combination with ADVA, acquisition related expenses and a decrease in volume of sales activity related to our ADTRAN, Inc. operations partially offset by a decrease in cost of revenue.

[0000950170-23-020333:mdna:62]
As a percentage of that segment's revenue, Network Solutions gross profit decreased from 34.5% for the three months ended March 31, 2022 to 22.4% for the three months ended March 31, 2023. The decrease was primarily attributable to increases in cost of revenue related to acquisition related expenses, adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with ADVA and a decrease in volume of sales activity related to our ADTRAN, Inc. operations partially offset by an increase in volume of sales activity due to the Business Combination with ADVA.

[0000950170-23-020333:mdna:63]
As a percentage of that segment's revenue, Services & Support gross profit increased from 40.9% for the three months ended March 31, 2022 to 59.1% for the three months ended March 31, 2023. The increase was primarily attributable to an crease in volume of sales activity due to the Business Combination with ADVA, an increase in volume of sales activity related to our ADTRAN, Inc. and a decrease in cost of revenue attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with ADVA.

[0000950170-23-020333:mdna:64]
[same as prior period, unchanged from 0000950170-22-023803:mdna:54]

[0000950170-23-020333:mdna:65]
As a percentage of revenue, selling, general and administrative expenses increased from 18.1% for the three months ended March 31, 2022 to 20.8% for the three months ended March 31, 2023. While selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared, in the first quarter we saw a more significant increase due to increased expenses related to the Business Combination with ADVA and other items described below. Our restructuring and integration programs are in the process of consolidating, streamlining and integrating the workforce, systems and processes of ADTRAN and ADVA, which we expect will lower selling, general and administrative expense as a percentage of revenue over time.

[0000950170-23-020333:mdna:66]
Selling, general and administrative expenses increased 141.6% from $27.9 million for the three months ended March 31, 2022 to $67.4 million for the three months ended March 31, 2023. Although selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The increase in selling, general and administrative expenses was primarily attributable to increased expenses related to the Business Combination with ADVA such as employee-related costs due to an increase in the number of employees, costs related to our restructuring program, amortization of intangible assets, depreciation of property, plant and equipment, restructuring expenses, stock-based compensation expense and transactions costs. For the three months ended March 31, 2023 as compared to the three months ended March 31, 2022, changes in foreign currencies relative to the U.S dollar decreased our selling, general and administrative expenses by approximately $1.5 million.

[0000950170-23-020333:mdna:67]
[same as prior period, unchanged from 0000950170-22-023803:mdna:57]

[0000950170-23-020333:mdna:68]
As a percentage of revenue, research and development expenses increased from 17.1% for the three months ended March 31, 2022 to 21.7% for the three months ended March 31, 2023. Although, research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared, in the first quarter we saw a more significant increase due to increased expenses related to the Business Combination with ADVA and other items described below.

[0000950170-23-020333:mdna:69]
Research and development expenses increased 164.8% from $26.5 million for the three months ended March 31, 2022 to $70.1 million for the three months ended March 31, 2023. The increase in research and development expenses was primarily attributable to increased expenses related to the Business Combination with ADVA such as employee-related costs due to an increase in the number of employees and expenses related to our multi-year integration program, amortization of intangible assets, depreciation of property, plant and equipment and stock-based compensation expense. For the three months ended March 31, 2023 as compared to the three months ended March 31, 2022, changes in foreign currencies relative to the U.S. dollar decreased our research and development expenses by approximately $2.2 million.

[0000950170-23-020333:mdna:70]
ADVA has arrangements with governmental entities for the purpose of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the three months ended March 31, 2023, the Company recognized $0.6 million as a reduction of research and development expense.

[0000950170-23-020333:mdna:71]
[same as prior period, unchanged from 0000950170-22-023803:mdna:61]

[0000950170-23-020333:mdna:72]
[same as prior period, unchanged from 0000950170-22-023803:mdna:64]

[0000950170-23-020333:mdna:73]
Interest and dividend income increased from $0.2 million for the three months ended March 31, 2022 to $0.3 million for the three months ended March 31, 2023. Interest and dividend income was up due to increased income related to the Business Combination with ADVA for the three months ended March 31, 2023.

[0000950170-23-020333:mdna:74]
[same as prior period, unchanged from 0000950170-22-023803:mdna:66]

[0000950170-23-020333:mdna:75]
Interest expense increased from less than $0.1 million for the three months ended March 31, 2022 to $3.3 million for the three months ended March 31, 2023. The increase in interest expense during the three months ended March 31, 2023 was primarily related to an increase in the new Wells Fargo Credit Agreement and the assumed debt associated with the Business Combination with ADVA. See Note 12 and Note 13 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-23-020333:mdna:76]
[same as prior period, unchanged from 0000950170-22-023803:mdna:68]

[0000950170-23-020333:mdna:77]
We recognized a net investment loss of $3.4 million and a gain of $1.3 million for the three months ended March 31, 2022 and 2023, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See Note 6 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-23-020333:mdna:78]
OTHER EXPENSE, NET

[0000950170-23-020333:mdna:79]
Other expense, net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, increased from an expense of $0.2 million for the three months ended March 31, 2022 to expense of $0.3 million for the three months ended March 31, 2023.

[0000950170-23-020333:mdna:80]
INCOME TAX BENEFIT

[0000950170-23-020333:mdna:81]
Our effective tax rate changed from a benefit of 68.1% of pre-tax income for the three months ended March 31, 2022, to a benefit of 21.9% of pre-tax income for the three months ended March 31, 2023. In 2022, we benefited from a change in our annual estimated tax rate as a result of the requirement to begin capitalizing research and development expenses for U.S. tax purposes beginning in 2022 as previously passed as part of the Tax Cuts and Jobs Act in December 2017, and the associated impact of those changes on our previously established valuation allowance. The change in the effective tax rate for the three months ended March 31, 2023, was driven primarily by a change in our estimated tax rate as a result of the closing of the Business Combination with ADVA during the third quarter of 2022 as well as the release of our domestic valuation allowance during the fourth quarter of 2022.

[0000950170-23-020333:mdna:82]
[same as prior period, unchanged from 0000950170-22-023803:mdna:74]

[0000950170-23-020333:mdna:83]
As a result of the above factors, net loss attributable to ADTRAN Holdings, Inc. increased from $1.1 million for the three months ended March 31, 2022 to $34.5 million for the three months ended March 31, 2023. Upon the DPLTA becoming effective on January 16, 2023, the Company began absorbing all ADVA losses rather than just the loss related to the Company's ownership percentage in ADVA.

[0000950170-23-020333:mdna:84]
[same as prior period, unchanged from 0000950170-22-023803:mdna:76]

[0000950170-23-020333:mdna:85]
[same as prior period, unchanged from 0000950170-22-023803:mdna:77]

[0000950170-23-020333:mdna:86]
We have historically financed our ongoing business with existing cash, investments and cash flow from operations. In the current supply environment we also expect to utilize our credit arrangements to manage our working capital needs. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital, business acquisitions, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures. As of March 31, 2023, the Company has incurred a total of $26.1 million of transaction costs related to the Business Combination. We are also obligated to compensate any annual net loss of ADVA under the DPLTA. Additionally, pursuant to the terms of the DPLTA, each ADVA shareholder (other than the Company) has received an offer to elect either (1) to remain an ADVA shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation. Assuming all of the minority holders of currently outstanding ADVA shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments of approximately EUR 309.5 million or approximately $335.6 million, based on an exchange rate as of March 31, 2023. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside ADVA shareholders to tender ADVA shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-020333:mdna:87]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately EUR 10.5 million or $11.3 million (based on the current exchange rate) per year assuming none of the minority ADVA shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2023, we accrued $2.8 million in Annual Recurring Compensation, which was reflected as a reduction to retained earnings.

[0000950170-23-020333:mdna:88]
We believe that our cash and cash equivalents, investments, cash generated from operations and access to funds under the new Wells Fargo credit facility (described below) will be adequate to meet our operating and capital needs and our obligations under the Business Combination and the DPLTA for at least the next 12 months.

[0000950170-23-020333:mdna:89]
As of March 31, 2023, our cash on hand was $136.5 million and short-term investments were $1.0 million, which resulted in available short-term liquidity of $137.5 million, of which $112.5 million was held by our foreign subsidiaries. As of December 31, 2022, cash on hand was $108.6 million and short-term investments were $0.3 million, which resulted in available short-term liquidity of $108.9 million, of which $86.3 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax.

[0000950170-23-020333:mdna:90]
In addition to our cash and cash equivalents and the credit facility, we may fund a portion or all of the Exit Compensation through the sale of securities. There can be no assurances that we would be successful in effecting these actions on commercially reasonable terms or at all.

[0000950170-23-020333:mdna:91]
[same as prior period, unchanged from 0000950170-22-023803:mdna:80]

[0000950170-23-020333:mdna:92]
Net cash used in operating activities of $19.9 million during the three months ended March 31, 2023 decreased by $24.8 million compared to net cash provided of $4.9 million during the three months ended March 31, 2022. This decrease was primarily due to the net loss for the period, for the reasons discussed above, as adjusted primarily for depreciation and deferred taxes, and net cash outflows from working capital, specifically, a decrease in the average number of days payable to our trade suppliers. Additional details related to our working capital and its drivers are discussed below.

[0000950170-23-020333:mdna:93]
Net accounts receivable decreased 6.2% from $279.4 million as of December 31, 2022 to $262.0 million as of March 31, 2023. There was an allowance for credit losses of $0.1 million as of March 31, 2023 and an allowance for credit losses of less than $0.1 million as of December 31, 2022. The decrease in net accounts receivable was due primarily to customer and geographical mix. Quarterly accounts receivable DSO increased from 72 days as of December 31, 2022 to 73 days as of March 31, 2023. The increase in DSO was due to customer and geographical mix associated with the Business Combination with ADVA and timing of sales within the quarter.

[0000950170-23-020333:mdna:94]
Other receivables decreased 5.8% from $32.8 million as of December 31, 2022 to $30.9 million as of March 31, 2023. The decrease in other receivables was primarily attributable to a decrease for sales of raw materials.

[0000950170-23-020333:mdna:95]
Quarterly inventory turnover was 2.5 turns as of December 31, 2022 and 2.2 turns as of March 31, 2023. Inventory decreased 2.6% from $427.5 million as of December 31, 2022 to $416.3 million as of March 31, 2023. The decrease in inventory was due to a reduction in component purchases due to improved lead times as well as utilization of buffer stock. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to supply chain uncertainties.

[0000950170-23-020333:mdna:96]
Accounts payable decreased 16.5% from $237.7 million as of December 31, 2022 to $198.6 million as of March 31, 2023. The decrease in accounts payable was primarily due to a decrease in the average number of days payable to our trade suppliers. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-23-020333:mdna:97]
[same as prior period, unchanged from 0000950170-22-023803:mdna:86]

[0000950170-23-020333:mdna:98]
Capital expenditures totaled approximately $8.4 million and $1.5 million for the three months ended March 31, 2023 and 2022, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements.

[0000950170-23-020333:mdna:99]
Our combined short-term and long-term investments increased $1.1 million from $33.0 million as of December 31, 2022 to $34.1 million as of March 31, 2023. This increase reflects the impact of the net unrealized and realized gains and losses on our investments.

[0000950170-23-020333:mdna:100]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 6 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0000950170-23-020333:mdna:101]
As of March 31, 2023, our corporate bonds, municipal bonds, asset-backed bonds, mortgage/agency bonds, U.S. government bonds and other government bonds were classified as available-for-sale and had a combined duration of 1.43 years with an average Standard & Poor’s credit rating of AA. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0000950170-23-020333:mdna:102]
Our long-term investments increased 1.0% from $32.7 million as of December 31, 2022 to $33.0 million as of March 31, 2023. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $0.8 million as of March 31, 2023 and December 31, 2022. Long-term investments as of March 31, 2023 and December 31, 2022 also included $24.0 million and $22.9 million, respectively, related to our deferred compensation plans.

[0000950170-23-020333:mdna:103]
48

[0000950170-23-020333:mdna:104]
[same as prior period, unchanged from 0000950170-22-023803:mdna:92]

[0000950170-23-020333:mdna:105]
[same as prior period, unchanged from 0000950170-22-023803:mdna:93]

[0000950170-23-020333:mdna:106]
During the three month periods ended March 31, 2023 and 2022, we paid dividends totaling $7.1 million and $4.4 million, respectively. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0000950170-23-020333:mdna:107]
Stock Repurchase Program

[0000950170-23-020333:mdna:108]
There were no stock repurchases during the periods ended March 31, 2023 and 2022, and there currently is no authorized stock repurchase plan.

[0000950170-23-020333:mdna:109]
[same as prior period, unchanged from 0000950170-22-023803:mdna:95]

[0000950170-23-020333:mdna:110]
To accommodate employee stock option exercises, the Company issued 6 thousand and 33 thousand shares of common stock and treasury stock which resulted in proceeds of $58 thousand and $0.6 million during the three months ended March 31, 2023 and 2022, respectively.

[0000950170-23-020333:mdna:111]
[same as prior period, unchanged from 0000950170-22-023803:mdna:97]

[0000950170-23-020333:mdna:112]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0000950170-23-020333:mdna:113]
[same as prior period, unchanged from 0000950170-22-023803:mdna:99]

[0000950170-23-020333:mdna:114]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of March 31, 2023, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA and currency hedging arrangements, which are discussed below).

[0000950170-23-020333:mdna:115]
| (In thousands) |  | Total |  |  | 2023 |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | After 2027 |  |
| Wells Fargo credit agreement(1) |  | $ | 180,000 |  |  | $ | 180,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Nord/LB revolving line of credit(2) |  |  | 10,843 |  |  |  | 10,843 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations(3) |  |  | 459,313 |  |  |  | 404,351 |  |  |  | 52,307 |  |  |  | 2,648 |  |  |  | 7 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations(4) |  |  | 33,494 |  |  |  | 6,741 |  |  |  | 8,397 |  |  |  | 6,914 |  |  |  | 4,089 |  |  |  | 2,864 |  |  |  | 4,489 |  |
| Totals |  | $ | 683,650 |  |  | $ | 601,935 |  |  | $ | 60,704 |  |  | $ | 9,562 |  |  | $ | 4,096 |  |  | $ | 2,864 |  |  | $ | 4,489 |  |

[0000950170-23-020333:mdna:116]
(1) See description below.

[0000950170-23-020333:mdna:117]
(2) See description below.

[0000950170-23-020333:mdna:118]
(3) We have purchase obligations related to open purchase orders to our contract manufacturers, ODMs, component suppliers, service

[0000950170-23-020333:mdna:119]
partners and other vendors. The settlement of our purchase obligations will occur at various dates beginning in 2023 and going

[0000950170-23-020333:mdna:120]
through 2026. See Note 20 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report

[0000950170-23-020333:mdna:121]
for more information.

[0000950170-23-020333:mdna:122]
(4) We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international

[0000950170-23-020333:mdna:123]
locations. Our operating leases had remaining lease terms ranging from two month to 116 months as of March 31, 2023.

[0000950170-23-020333:mdna:124]
Wells Fargo Credit Agreement

[0000950170-23-020333:mdna:125]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100 million in aggregate principal amount, but the borrowings increased to up to $400 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.

[0000950170-23-020333:mdna:126]
As of March 31, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $180.0 million in tranches that mature during the second and third quarters of 2023 and can either be repaid or borrowed again for a one month, three month or six month period. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million dollar total facility. As of March 31, 2023, we had a total of $3.4 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $216.6 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exit Compensation consideration.

[0000950170-23-020333:mdna:127]
[same as prior period, unchanged from 0000950170-22-023803:mdna:108]

[0000950170-23-020333:mdna:128]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-23-020333:mdna:129]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the Consolidated Interest Coverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions.

[0000950170-23-020333:mdna:130]
[same as prior period, unchanged from 0000950170-22-023803:mdna:111]

[0000950170-23-020333:mdna:131]
New Nord/LB Revolving Line of Credit

[0000950170-23-020333:mdna:132]
On March 29, 2023, ADVA entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of March 31, 2023 ADVA borrowed $10.8 million under this facility.

[0000950170-23-020333:mdna:133]
Currency Hedging Arrangements

[0000950170-23-020333:mdna:134]
On November 3, 2022, the Company entered into a Euro/U.S. forward contract arrangement (the “Initial Forward”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enables the Company to convert a portion of its Euro denominated payment obligations under the DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of $160.0 million is divided into eight quarterly tranches of $20.0 million, commencing in the fourth quarter of 2022. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-23-020333:mdna:135]
On March 21, 2023, the Company entered into a Euro/U.S. dollar forward contract arrangement (the “Forward”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate of $1.085 per €1.00 in average. During the three months ended March 31, 2023, the Company settled one $20.0 million forward contract tranche and the remaining will be divided into seven quarterly tranches of $20.0 million. These new forward contracts transacted on March 21, 2023 (to sell EUR/buy USD) were entered into for the purpose of unwinding the previously transacted forward contracts (to buy EUR/sell USD), transacted in November 2022. The drawdown dates of the original ratchet forwards are set to the same date as the maturity of the new offsetting forward contracts.

[0000950170-23-020333:mdna:136]
ADVA Domination and Profit and Loss Transfer Agreement

[0000950170-23-020333:mdna:137]
On December 1, 2022, we, as the controlling company, entered into the DPLTA with ADVA, as the controlled company. The DPLTA, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of ADVA (Jena).

[0000950170-23-020333:mdna:138]
Under the DPLTA, subject to certain limitations pursuant to applicable law, (i) we are entitled to issue binding instructions to the management board of ADVA, (ii) ADVA will transfer all of its annual profits to us, subject to, among other things, the creation or dissolution of certain reserves, and (iii) we will generally absorb all annual losses incurred by ADVA. The obligation of ADVA to transfer its annual profit to us, as well as our obligation to absorb ADVA’s annual net loss, applies for the first time to the profits or losses generated in the ADVA fiscal year 2023.

[0000950170-23-020333:mdna:139]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that ADVA shareholders (other than us) be offered, at their election, (i) to put their ADVA shares to the Company in exchange for compensation in cash of EUR 17.21 per share (the “Exit Compensation”), or (ii) to remain ADVA shareholders and receive a recurring compensation in cash of EUR 0.59 (EUR 0.52 net under the current tax regime) per share for each full fiscal year of ADVA (the “Annual Recurring Compensation”). The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of ADVA for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of ADVA in 2024. The adequacy of both forms of compensation have been challenged by minority shareholders of ADVA via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA. Our aggregate potential payment obligations under the DPLTA are discussed above under "Liquidity".

[0000950170-23-020333:mdna:140]
The opportunity for outside ADVA shareholders to tender ADVA shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-020333:mdna:141]
We currently hold 33,957,538 no-par value bearer shares of ADVA, representing 65.38% of ADVA’s outstanding shares as of March 31, 2023.

[0000950170-23-020333:mdna:142]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which incorporated by reference to Exhibit 10.5 of the 2022 Form 10-K.

[0000950170-23-020333:mdna:143]
During the three months ended March 31, 2023, we did not incur transaction costs related to the Business Combination. During the three months ended March 31, 2022, we recognized $1.5 million of transaction costs relating to the Business Combination.

[0000950170-23-020333:mdna:144]
During the three months ended March 31, 2023, we recognized $0.8 million of integration costs related to the Business Combination that are included in selling, general and administrative expenses in the Condensed Consolidated Statement of Loss. We expect to incur integration costs and costs associated with the implementation of the DPLTA during 2023 and such costs are expected to be material.

[0000950170-23-020333:mdna:145]
During the three months ended March 31, 2023, we recognized $2.4 million of restructuring costs relating to the Business Combination that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss. See Note 21 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-23-020333:mdna:146]
[same as prior period, unchanged from 0000950170-22-023803:mdna:121]

[0000950170-23-020333:mdna:147]
During the three months ended March 31, 2023, other than the Exit Compensation payments and Annual Recurring Compensation under the DPLTA, there have been no other material changes in cash requirements from those discussed in the 2022 Form 10-K.

[0000950170-23-020333:mdna:148]
[same as prior period, unchanged from 0000950170-22-023803:mdna:124]

[0000950170-23-020333:mdna:149]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2023 and December 31, 2022, we had commitments related to these bonds totaling $11.7 million and $21.1 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-23-020333:mdna:150]
[same as prior period, unchanged from 0000950170-22-023803:mdna:126]

[0000950170-23-020333:mdna:151]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part I, Item 1 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the critical accounting policies affect our more significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements. During the three months ended March 31, 2023, other than the change in accounting policy regarding non-controlling interests as outlined in Note 1 and Note 16 to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report, there were no significant changes to our critical accounting policies and estimates as described in the financial statements contained in the 2022 Form 10-K.

[0000950170-23-020333:mdna:152]
52
