# ADTN notes — 0000950170-23-020333


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-23-020333:notes:1]
[same as prior period, unchanged from 0000950170-22-023803:notes:1]

[0000950170-23-020333:notes:2]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-23-020333:notes:3]
In 2022, following the business combination (the “Business Combination”) with ADVA Optical Networking SE (“ADVA”), which included the Merger, we became the sole owner of and successor to ADTRAN, Inc. and the majority shareholder of ADVA. ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video, and internet communications across any network infrastructure. Its award-winning end-to-end fiber broadband solutions portfolio spans from OLTs to in-home services and intelligent SaaS solutions. ADVA is a global provider of open networking solutions with over 25 years of experience in optical networking, carrier Ethernet access and network synchronization. ADVA has led the industry for over two decades with open and secure networking solutions that carefully balance space, power and cost. Together, we serve customers in a broad range of industries in over 100 countries.

[0000950170-23-020333:notes:4]
Effectiveness of the Domination and Profit and Loss Transfer Agreement

[0000950170-23-020333:notes:5]
The DPLTA between the Company, as the controlling company, and ADVA Optical Networking SE, as the controlled company as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of ADVA (Jena).

[0000950170-23-020333:notes:6]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of ADVA, (ii) ADVA will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by ADVA. The obligation of ADVA to transfer its annual profit to the Company applies for the first time to the profit generated subsequent to January 16, 2023.

[0000950170-23-020333:notes:7]
Subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that ADVA preferred shareholders be offered, at their election, (i) to put their ADVA shares to the Company in exchange for a compensation in cash of EUR 17.21 per share (the “Exit Compensation”), or (ii) to remain ADVA preferred shareholders and receive a recurring compensation in cash of EUR 0.59 (EUR 0.52 net under the current tax regime) per share for each full fiscal year of ADVA (the “Annual Recurring Compensation”). The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of ADVA for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of ADVA in 2024. The Annual Recurring Compensation payment is similar to a cumulative dividend, which does not require Board of Director approval as it is guaranteed under the DPLTA, and is accrued as a dividend liability when it is earned.

[0000950170-23-020333:notes:8]
The adequacy of both forms of compensation have been challenged by the preferred shareholders of ADVA via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

[0000950170-23-020333:notes:9]
The opportunity for the ADVA preferred shareholders to tender ADVA preferred shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-020333:notes:10]
Board Approval Purchase of ADVA Common Stock

[0000950170-23-020333:notes:11]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of ADVA through open market purchases not to exceed 15,346,544 shares.

[0000950170-23-020333:notes:12]
[same as prior period, unchanged from 0000950170-22-023803:notes:4]

[0000950170-23-020333:notes:13]
[same as prior period, unchanged from 0000950170-22-023803:notes:5]

[0000950170-23-020333:notes:14]
The accompanying unaudited Condensed Consolidated Financial Statements of ADTRAN Holdings, Inc. and its subsidiaries have been prepared pursuant to the rules and regulations of the SEC applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2022 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

[0000950170-23-020333:notes:15]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023.

[0000950170-23-020333:notes:16]
[same as prior period, unchanged from 0000950170-22-023803:notes:8]

[0000950170-23-020333:notes:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

[0000950170-23-020333:notes:18]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of March 31, 2023 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to supply chain constraints, inflationary pressures, the energy crisis, rising interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.

[0000950170-23-020333:notes:19]
Revision of Previously Issued Financial Statements

[0000950170-23-020333:notes:20]
During the first quarter of 2023, the Company determined that it understated total assets and total liabilities as of the year ended December 31, 2022, due to netting of deferred tax assets and deferred tax liabilities as of December 31, 2022. While the net amount of deferred tax assets and liabilities remains unchanged, the Company reported the deferred tax assets and liabilities balances without properly applying jurisdictional net reporting disclosure rules. The jurisdictional netting error was a result of the consolidation of financial statements with ADVA following the business combination, which closed on July 15, 2022. The Company revised the December 31, 2022 Consolidated Balance Sheet presented in this report by increasing deferred tax assets and total assets by $61.6 million and increasing deferred tax liability, total liabilities, and total liabilities, redeemable non-controlling interest and equity by $61.6 million. Management has determined that this misstatement was not material to any of its previously issued financial statements.

[0000950170-23-020333:notes:21]
The following table reflects the impact of the revision to the specific line items presented in the Company’s previously reported consolidated financial statements as of and for the year-ended December 31, 2022:

[0000950170-23-020333:notes:22]
| (In thousands) |  | As Reported |  |  | Adjustment |  |  | As Revised |  |
| Deferred tax assets |  | $ | 6,210 |  |  | $ | 61,629 |  |  | $ | 67,839 |  |
| Total assets |  | $ | 1,881,865 |  |  | $ | 61,629 |  |  | $ | 1,943,494 |  |
| Deferred tax liabilities |  | $ | — |  |  | $ | 61,629 |  |  | $ | 61,629 |  |
| Total liabilities |  | $ | 578,252 |  |  | $ | 61,629 |  |  | $ | 639,881 |  |

[0000950170-23-020333:notes:23]
Redeemable Non-Controlling Interest

[0000950170-23-020333:notes:24]
As of March 31, 2023 and December 31, 2022, the ADVA stockholders’ equity ownership percentage in ADVA was approximately 34.6% and 34.7%, respectively.

[0000950170-23-020333:notes:25]
As a result of the effectiveness of the DPLTA on January 16, 2023, the ADVA shares, representing the equity interest in ADVA held by holders other than the Company, can be tendered at any time and are, therefore, redeemable and must be classified outside stockholders’ equity. Therefore, the permanent equity noncontrolling interest balance was reclassified to redeemable non-controlling interest ("RNCI") on January 16, 2023 and was remeasured to fair value based on the trading market price of the ADVA shares.

[0000950170-23-020333:notes:26]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the redeemable noncontrolling interest. However, the RNCI will be remeasured using the current exchange rate at each reporting date as long as the RNCI is currently redeemable. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as redeemable non-controlling interest outside of stockholders’ equity in the condensed consolidated balance sheets.

[0000950170-23-020333:notes:27]
See Note 16 for additional information on RNCI.

[0000950170-23-020333:notes:28]
Recently Adopted Accounting Pronouncements

[0000950170-23-020333:notes:29]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. The Company early adopted ASU 2021-08 on July 1, 2022 and the standard was applied retrospectively beginning with January 1, 2022.

[0000950170-23-020333:notes:30]
[same as prior period, unchanged from 0000950170-22-023803:notes:13]

[0000950170-23-020333:notes:31]
There are currently no accounting pronouncements not yet adopted that are expected to have a material effect on the Condensed Consolidated Financial Statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-020333:notes:32]
[same as prior period, unchanged from 0000950170-22-023803:notes:15]

[0000950170-23-020333:notes:33]
[same as prior period, unchanged from 0000950170-22-023803:notes:16]

[0000950170-23-020333:notes:34]
On August 30, 2021, ADTRAN and ADVA, entered into a Business Combination Agreement, pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, ADTRAN Holdings, Inc. (formerly known as Acorn HoldCo, Inc.) which was formed as a wholly-owned subsidiary of ADTRAN in order to consummate the transactions under the Business Combination Agreement. Under the terms of the Business Combination Agreement, on July 8, 2022, Acorn MergeCo, Inc, a Delaware corporation and wholly-owned direct subsidiary of the Company, merged with and into ADTRAN Holdings, Inc. leaving ADTRAN Holdings, Inc. surviving the Business Combination as a wholly-owned direct subsidiary of the Company.

[0000950170-23-020333:notes:35]
Additionally, pursuant to the Business Combination Agreement, on July 15, 2022, the Company made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of Company Common Stock, par value $0.01 per share of the Company. The Exchange Offer was settled on Exchange Offer Settlement Date, on which date the Company acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of Company Common Stock. Additionally, pursuant to the Business Combination Agreement, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN, Inc. The fair value of the ADVA stock options assumed by ADTRAN, Inc. was $12.8 million, estimated using the Monte Carlo method.

[0000950170-23-020333:notes:36]
ADTRAN, Inc. and ADVA became subsidiaries of ADTRAN Holdings, Inc. as a result of the Business Combination. ADTRAN was determined to be the accounting acquirer of ADVA based on ADTRAN shareholders’ majority equity stake in the combined company, the composition of the board of directors and senior management of the combined company, among other factors. The Business Combination with ADVA has been accounted for using the acquisition method of accounting as per the provisions of Accounting Standards Codification 805, “Business Combinations” (“ASC 805”). The Business Combination Agreement used a fixed exchange ratio of Company Common Stock for ADVA shares of common stock, which resulted in a 36% equity stake for ADVA stockholders and a 64% equity stake for ADTRAN stockholders in the post-closing combined company (calculated on a fully diluted basis and utilizing the tender of 65.43% of ADVA’s current issued and outstanding share capital) as of July 15, 2022. Therefore, ADTRAN shareholders continued to hold a majority interest in the combined company following the completion of the Business Combination. Additionally, the Board of Directors is comprised of six members from ADTRAN and three members from ADVA; the current ADTRAN chief executive officer acts as the chairman of the Board of Directors and the former ADVA chief executive officer as the vice chairman of the Board of Directors. Additionally, the current ADTRAN chief executive officer and ADTRAN chief financial officer held these positions within the combined company immediately following the completion of the Business Combination. Based upon these and other considerations as outlined in ASC 805, ADTRAN represents the accounting acquirer.

[0000950170-23-020333:notes:37]
[same as prior period, unchanged from 0000950170-22-023803:notes:20]

[0000950170-23-020333:notes:38]
[same as prior period, unchanged from 0000950170-22-023803:notes:21]

[0000950170-23-020333:notes:39]
[same as prior period, unchanged from 0000950170-22-023803:notes:22]

[0000950170-23-020333:notes:40]
Assets acquired and liabilities assumed were recognized at their respective fair values as of July 15, 2022. In determining the fair value, the Company utilized various methods of the income, cost and market approaches depending on the asset or liability being fair valued. The estimation of fair value required significant judgment related to future net cash flows reflecting the risk inherent in each cash flow stream, competitive trends, market comparables and other factors. Inputs were generally determined by taking into account historical data, current and anticipated market conditions, and growth rates.

[0000950170-23-020333:notes:41]
Developed technology and customer relationships were valued using the multi-period excess earnings method. Backlog was valued using the distributor method. Significant assumptions used in the discounted cash flow analysis for (i) developed technology were the revenue growth rates, long-term revenue growth rate, discount rate, and earnings before interest, taxes, depreciation and amortization (“EBITDA”) margins, obsolescence factors, income tax rate, tax depreciation, and economic depreciation; (ii) customer relationships were earnings before interest and taxes (“EBIT”) margins, contributory asset charges, and customer attrition rate; and (iii) backlog were EBIT margins, adjusted EBIT margins, and contributory asset charges.

[0000950170-23-020333:notes:42]
The allocation of the purchase price to the assets acquired and liabilities assumed was subject to adjustment within the measurement period (up to one year from the acquisition date). The measurement period adjustments since initial preliminary estimates resulted from changes to the fair value estimates of the acquired assets and assumed liabilities based on finalizing the valuations of inventory, prepaid expenses and other current assets, property plant and equipment, intangible assets, other non-current assets and deferred tax assets and liabilities. The cumulative effect of all measurement period adjustments resulted in a decrease to recognized goodwill of $8.7 million.

[0000950170-23-020333:notes:43]
The following table summarizes the purchase price allocation for each major class of assets acquired and liabilities assumed in the acquisition of ADVA (in thousands):

[0000950170-23-020333:notes:44]
| (In thousands) |  |  |  |
| Total purchase price |  | $ | 578,260 |  |
| Non-controlling interest |  | $ | 316,415 |  |
| Net Assets: |  |  |  |
| Cash and cash equivalents |  | $ | 44,003 |  |
| Accounts receivable |  |  | 114,659 |  |
| Other receivables |  |  | 1,457 |  |
| Inventory |  |  | 200,331 |  |
| Prepaid expenses and other current assets |  |  | 28,208 |  |
| Property plant and equipment |  |  | 55,480 |  |
| Deferred tax assets |  |  | 1,759 |  |
| Intangibles |  |  | 403,780 |  |
| Other non-current assets |  |  | 31,074 |  |
| Accounts payable |  |  | (98,587 | ) |
| Current unearned revenue |  |  | (26,047 | ) |
| Accrued expenses and other liabilities |  |  | (59,600 | ) |
| Current portion of notes payable |  |  | (25,254 | ) |
| Income tax payable, net |  |  | (4,898 | ) |
| Tax liabilities |  |  | (1,400 | ) |
| Non-current unearned revenue |  |  | (11,498 | ) |
| Pension liability |  |  | (6,820 | ) |
| Other non-current liabilities |  |  | (6,094 | ) |
| Non-current portion of revolving credit agreements and notes payable |  |  | (15,250 | ) |
| Non-current lease obligations |  |  | (20,046 | ) |
| Deferred tax liabilities |  |  | (61,040 | ) |
| Total net assets acquired |  | $ | 544,217 |  |
| Goodwill |  | $ | 350,458 |  |

[0000950170-23-020333:notes:45]
The fair value of the assets acquired include accounts receivable of $114.7 million and other receivables of $1.5 million. The unpaid principal balance under these receivables is $118.5 million and $1.5 million, respectively. The difference between the fair value and the unpaid principal balance primarily represents amounts expected to be uncollectible.

[0000950170-23-020333:notes:46]
The fair value of the identifiable intangible assets acquired as of the acquisition date:

[0000950170-23-020333:notes:47]
| (In thousands) | Estimated-average useful life (in years) (1) |  |  | Fair value |  |  | Income Statement Amortization Classification |
| Developed technology |  | 8.5 |  |  | $ | 291,925 |  |  | Cost of revenue - Network Solutions |
| Backlog |  | 1.4 |  |  |  | 52,165 |  |  | Cost of revenue - Network Solutions and Services & Support |
| Customer relationships |  | 10.5 |  |  |  | 32,704 |  |  | Selling, general and administrative expenses |
| Trade name |  | 2.8 |  |  |  | 26,986 |  |  | Selling, general and administrative expenses |
| Total |  |  |  | $ | 403,780 |  |  |  |

[0000950170-23-020333:notes:48]
[same as prior period, unchanged from 0000950170-22-023803:notes:29]

[0000950170-23-020333:notes:49]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and intangible assets acquired. The ADVA acquisition resulted in the recognition of goodwill of $350.5 million, which the Company believes is attributable to the value driven by the Company’s expected growth of the business, synergies, and expanded market and product opportunities. Goodwill created as a result of the ADVA acquisition is not deductible for tax purposes.

[0000950170-23-020333:notes:50]
After the Business Combination, the chief operating decision maker assessed and will continue to assess the Company’s performance and allocate resources to its two segments (1) Network Solutions and (2) Services & Support. The goodwill resulting from the Business Combination of $272.8 million was allocated to the Network Solutions segment, and $77.7 million was allocated to the Services & Support segment. See Note 18 of the Notes to Consolidated Financial Statements, included in this report for more information about the Company’s segments.

[0000950170-23-020333:notes:51]
[same as prior period, unchanged from 0000950170-22-023803:notes:32]

[0000950170-23-020333:notes:52]
The Company included the financial results of ADVA in its consolidated financial statements since July 15, 2022, the acquisition date. The net revenue and net loss from the ADVA business for the period January 1, 2023 to March 31, 2023, were $192.3 million and $25.4 million, respectively, which are included in the Company’s Consolidated Statement of Loss. The net loss attributable to non-controlling interest from the ADVA business for the three months ended March 31, 2023 was $6.0 million.

[0000950170-23-020333:notes:53]
As of March 31, 2023, the Company has incurred $26.1 million of transaction costs related to the Business Combination. During the three months ended March 31, 2023, we did not incur transaction costs related to the Business Combination. During the three months ended March 31, 2022, $1.5 million of transaction costs were incurred. These transaction costs are recorded in selling, general and administrative expense in the Consolidated Statements of Loss.

[0000950170-23-020333:notes:54]
[same as prior period, unchanged from 0000950170-22-023803:notes:35]

[0000950170-23-020333:notes:55]
The unaudited pro forma financial information in the table below summarizes the combined results of operations for ADTRAN and ADVA as though the Business Combination had occurred on January 1, 2022. The pro forma amounts have been adjusted for differences in basis of accounting which are determined before taking into effect the impacts of purchase accounting and Business Combination accounting impacts.

[0000950170-23-020333:notes:56]
The following unaudited pro forma information is presented for illustrative purposes only. It is not necessarily indicative of the results of operations of future periods, the results of operations that actually would have been realized had the entities been a single company as of January 1, 2022, or the future operating results of the combined entities. The unaudited pro forma information does not give effect to the potential impact of current financial conditions, regulatory matters or any anticipated synergies, operating efficiencies or cost savings that may be associated with the acquisition. The unaudited pro forma information also does not include any integration costs that the Company may incur related to the acquisition as part of combining the operations of the companies.

[0000950170-23-020333:notes:57]
|  | Three Months Ended |  |
| (In thousands) | March 31, 2022 |  |
| Revenue | $ | 345,844 |  |
| Net loss | $ | (73,489 | ) |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-23-020333:notes:58]
3. REVENUE

[0000950170-23-020333:notes:59]
[same as prior period, unchanged from 0000950170-22-023803:notes:44]

[0000950170-23-020333:notes:60]
Network Solutions Segment - Includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

[0000950170-23-020333:notes:61]
[same as prior period, unchanged from 0000950170-22-023803:notes:46]

[0000950170-23-020333:notes:62]
[same as prior period, unchanged from 0000950170-22-023803:notes:47]

[0000950170-23-020333:notes:63]
[same as prior period, unchanged from 0000950170-22-023803:notes:48]

[0000950170-23-020333:notes:64]
[same as prior period, unchanged from 0000950170-22-023803:notes:49]

[0000950170-23-020333:notes:65]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at the customer premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

[0000950170-23-020333:notes:66]
Our Access & Aggregation Solutions are solutions that are used by communications Service Providers to connect residential subscribers, business subscribers and mobile radio networks to the Service Providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions, and access orchestration solutions that ensure highly reliable and efficient network performance.

[0000950170-23-020333:notes:67]
Our Optical Networking Solutions are used by communications Service Providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems, and automation platforms that are used to build high-scale, secure and assured optical networks.

[0000950170-23-020333:notes:68]
The following table disaggregates revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

[0000950170-23-020333:notes:69]
|  |  | Three Months Ended |  |
|  |  | March 31, 2023 |  |  | March 31, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 70,287 |  |  | $ | 9,049 |  |  | $ | 79,336 |  |  | $ | 52,390 |  |  | $ | 4,332 |  |  | $ | 56,722 |  |
| Access & Aggregation Solutions |  |  | 84,554 |  |  |  | 12,266 |  |  |  | 96,820 |  |  |  | 85,984 |  |  |  | 11,812 |  |  |  | 97,796 |  |
| Optical Networking Solutions |  |  | 127,577 |  |  |  | 20,179 |  |  |  | 147,756 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 282,418 |  |  | $ | 41,494 |  |  | $ | 323,912 |  |  | $ | 138,374 |  |  | $ | 16,144 |  |  | $ | 154,518 |  |

[0000950170-23-020333:notes:70]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2023 and December 31, 2022 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $389.0 million and $277.2 million, respectively. As of March 31, 2023, approximately 68% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of March 31, 2023 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-23-020333:notes:71]
[same as prior period, unchanged from 0000950170-22-023803:notes:57]

[0000950170-23-020333:notes:72]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Accounts receivable, net |  | $ | 262,043 |  |  | $ | 279,435 |  |
| Contract assets(1) |  | $ | 1,972 |  |  | $ | 1,852 |  |
| Unearned revenue |  | $ | 55,611 |  |  | $ | 41,193 |  |
| Non-current unearned revenue |  | $ | 24,907 |  |  | $ | 19,239 |  |

[0000950170-23-020333:notes:73]
[same as prior period, unchanged from 0000950170-22-023803:notes:59]

[0000950170-23-020333:notes:74]
The Company is party to a receivables purchase agreement with a third party financial institution (the “Factor”). As of March 31, 2023 and December 31, 2022, accounts receivable totaling $15.6 million and $14.9 million, respectively, were sold, of which $1.2 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of March 31, 2023 and December 31, 2022, the Company had an allowance for doubtful accounts related to factored accounts receivable totaling less than $0.1 million. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months ended March 31, 2023.

[0000950170-23-020333:notes:75]
Of the outstanding unearned revenue balances as of December 31, 2022, $25.6 million was recognized as revenue during the three months ended March 31, 2023. Of the $17.7 million of outstanding unearned revenue balances as of December 31, 2021, $5.4 million was recognized as revenue during the three months ended March 31, 2022.

[0000950170-23-020333:notes:76]
[same as prior period, unchanged from 0000950170-22-023803:notes:62]

[0000950170-23-020333:notes:77]
[same as prior period, unchanged from 0000950170-22-023803:notes:63]

[0000950170-23-020333:notes:78]
As of March 31, 2023 and December 31, 2022, the Company’s outstanding accounts receivable balance was $262.0 million and $279.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0000950170-23-020333:notes:79]
The allowance for credit losses was $0.1 million and $49 thousand as of March 31, 2023 and December 31, 2022, respectively, related to accounts receivable.

[0000950170-23-020333:notes:80]
[same as prior period, unchanged from 0000950170-22-023803:notes:66]

[0000950170-23-020333:notes:81]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of March 31, 2023 and December 31, 2022, the Company’s outstanding contract asset balance was $2.0 million and $1.9 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0000950170-23-020333:notes:82]
No allowance for credit losses was recorded for the three months ended March 31, 2023 and 2022 related to contract assets.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000950170-23-020333:notes:83]
[same as prior period, unchanged from 0000950170-22-023803:notes:69]

[0000950170-23-020333:notes:84]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Subscriber Solutions |  | $ | 79,336 |  |  | $ | 56,722 |  |
| Access & Aggregation Solutions |  |  | 96,820 |  |  |  | 97,796 |  |
| Optical Networking Solutions |  |  | 147,756 |  |  |  | — |  |
| Total |  | $ | 323,912 |  |  | $ | 154,518 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-020333:notes:85]
4. INCOME TAXES

[0000950170-23-020333:notes:86]
The Company's effective tax rate changed from a benefit of 68.1% of pre-tax income for the three months ended March 31, 2022, to a benefit of 21.9% of pre-tax income for the three months ended March 31, 2023. The change in the effective tax rate for the three months ended March 31, 2023, was driven primarily by a change in our estimated tax rate as a result of the closing of the Business Combination with ADVA during the third quarter of 2022, as well as the release of our domestic valuation allowance during the fourth quarter of 2022.

[0000950170-23-020333:notes:87]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of March 31, 2023, the Company had net deferred tax assets totaling $35.0 million, and a valuation allowance totaling $5.2 million against those deferred tax assets. The remaining $29.8 million in deferred tax assets are primarily related to capitalized R&D expenses in the U.S., partially offset by net purchase price intangibles from the Business Combination closed with ADVA during the third quarter of 2022. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results as well as the evaluation of evidence which requires significant judgment, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance, or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.

[0000950170-23-020333:notes:88]
[same as prior period, unchanged from 0000950170-22-023803:notes:74]

[0000950170-23-020333:notes:89]
|  |  | As of March 31, 2023 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Assets (Liabilities), net |  |
| Domestic |  | $ | 75,432 |  |  | $ | (3,177 | ) |  | $ | 72,255 |  |
| International |  |  | (40,450 | ) |  |  | (2,024 | ) |  |  | (42,474 | ) |
| Total |  | $ | 34,982 |  |  | $ | (5,201 | ) |  | $ | 29,781 |  |

[0000950170-23-020333:notes:90]
|  |  | As of December 31, 2022 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Assets (Liabilities), net |  |
| Domestic |  | $ | 61,726 |  |  | $ | (3,177 | ) |  | $ | 58,549 |  |
| International |  |  | (50,315 | ) |  |  | (2,024 | ) |  |  | (52,339 | ) |
| Total |  | $ | 11,411 |  |  | $ | (5,201 | ) |  | $ | 6,210 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-020333:notes:91]
5. STOCK-BASED COMPENSATION

[0000950170-23-020333:notes:92]
For the three months ended March 31, 2023 and 2022, stock-based compensation expense was $2.6 million and $1.9 million, respectively.

[0000950170-23-020333:notes:93]
[same as prior period, unchanged from 0000950170-22-023803:notes:79]

[0000950170-23-020333:notes:94]
The following table summarizes the RSUs and restricted stock outstanding as of December 31, 2022 and March 31, 2023 and the changes that occurred during the three months ended March 31, 2023:

[0000950170-23-020333:notes:95]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2022 |  |  | 1,086 |  |  | $ | 17.54 |  |
| RSUs and restricted stock granted |  |  | 1,296 |  |  | $ | 17.60 |  |
| RSUs and restricted stock vested |  |  | (12 | ) |  | $ | 20.51 |  |
| RSUs and restricted stock forfeited |  |  | (10 | ) |  | $ | 15.32 |  |
| Unvested RSUs and restricted stock outstanding, March 31, 2023 |  |  | 2,360 |  |  | $ | 17.65 |  |

[0000950170-23-020333:notes:96]
During the three months ended March 31, 2023, the Company granted 0.7 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over a three-year period, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 150% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0000950170-23-020333:notes:97]
During the three months ended March 31, 2023, the Company granted 0.1 million performance-based PSUs to its executive officers. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over a two-year period, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 100% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0000950170-23-020333:notes:98]
[same as prior period, unchanged from 0000950170-22-023803:notes:84]

[0000950170-23-020333:notes:99]
As of March 31, 2023, total unrecognized compensation expense related to non-vested market-based RSUs and restricted stock was approximately $24.6 million, which will be recognized over the remaining weighted-average period of 2.6 years. There was $11.9 million of unrecognized compensation expense related to unvested 2023 performance-based PSUs, which will be recognized over the remaining requisite service period of 2.6 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0000950170-23-020333:notes:100]
As of March 31, 2023, 2.0 million shares were available for issuance under stockholder-approved equity plans.

[0000950170-23-020333:notes:101]
[same as prior period, unchanged from 0000950170-22-023803:notes:87]

[0000950170-23-020333:notes:102]
The following table summarizes ADTRAN Holdings, Inc. stock options outstanding as of December 31, 2022 and March 31, 2023 and the changes that occurred during the three months ended March 31, 2023:

[0000950170-23-020333:notes:103]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2022 |  |  | 3,148 |  |  | $ | 14.37 |  |  |  | 3.42 |  |  | $ | 16,251 |  |
| Stock options exercised |  |  | (6 | ) |  | $ | 9.82 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (21 | ) |  | $ | 12.21 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (7 | ) |  | $ | 19.00 |  |  |  |  |  |  |  |
| Stock options outstanding, March 31, 2023 |  |  | 3,114 |  |  | $ | 14.38 |  |  |  | 3.17 |  |  | $ | 10,198 |  |
| Stock options exercisable, March 31, 2023 |  |  | 1,698 |  |  | $ | 15.96 |  |  |  | 1.70 |  |  | $ | 4,436 |  |

[0000950170-23-020333:notes:104]
As of March 31, 2023, there was $7.3 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 2.2 years.

[0000950170-23-020333:notes:105]
Pursuant to the Business Combination, which closed on July 15, 2022, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter

[0000950170-23-020333:notes:106]
representing options to acquire stock of ADTRAN Holdings, Inc. The maximum number of shares of ADTRAN Holdings, Inc. stock potentially issuable upon such assumption was 2.3 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.1 million shares of ADTRAN Holdings, Inc. stock could be subject to assumed ADVA options. The determination of the fair value of stock options assumed by ADTRAN Holdings, Inc. was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors.

[0000950170-23-020333:notes:107]
[same as prior period, unchanged from 0000950170-22-023803:notes:93]

[0000950170-23-020333:notes:108]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on March 31, 2023. The amount of aggregate intrinsic value was $10.2 million as of March 31, 2023 and will change based on the fair market value of ADTRAN’s stock. The total pre-tax intrinsic value of options exercised during the three months ended March 31, 2023 was $43 thousand.

[0000950170-23-020333:notes:109]
[same as prior period, unchanged from 0000950170-22-023803:notes:95]

[0000950170-23-020333:notes:110]
The following table summarizes ADVA Optical Networking SE stock options outstanding as of December 31, 2022 and March 31, 2023 and the changes that occurred during the three months ended March 31, 2023:

[0000950170-23-020333:notes:111]
|  |  | Number ofOptions(In thousands) |  |  | WeightedAverageExercise Price(Per share) |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | AggregateIntrinsic Value(In thousands) |  |
| Stock options outstanding, December 31, 2022 |  |  | 81 |  |  | $ | 8.58 |  |  |  | 4.00 |  |  | $ | 1,222 |  |
| Stock options exercised |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |
| Stock options outstanding, March 31, 2023 |  |  | 81 |  |  | $ | 8.67 |  |  |  | 3.75 |  |  | $ | 1,198 |  |
| Stock options exercisable, March 31, 2023 |  |  | 27 |  |  | $ | 7.45 |  |  |  | 2.14 |  |  | $ | 424 |  |

[0000950170-23-020333:notes:112]
As of March 31, 2023, there was $0.1 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 3.8 years.

[0000950170-23-020333:notes:113]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADVA's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on March 31, 2023. The amount of aggregate intrinsic value was $1.2 million as of March 31, 2023 and will change based on the fair market value of ADVA's stock.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-23-020333:notes:114]
6. INVESTMENTS

[0000950170-23-020333:notes:115]
Debt Securities and Other Investments

[0000950170-23-020333:notes:116]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value:

[0000950170-23-020333:notes:117]
|  |  | As of March 31, 2023 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,218 |  |  | $ | 4 |  |  | $ | (63 | ) |  | $ | 2,159 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (4 | ) |  |  | 181 |  |
| Asset-backed bonds |  |  | 734 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 715 |  |
| Mortgage/Agency-backed bonds |  |  | 1,699 |  |  |  | 1 |  |  |  | (82 | ) |  |  | 1,618 |  |
| U.S. government bonds |  |  | 4,299 |  |  |  | 5 |  |  |  | (151 | ) |  |  | 4,153 |  |
| Foreign government bonds |  |  | 406 |  |  |  | — |  |  |  | (19 | ) |  |  | 387 |  |
| Available-for-sale debt securities held at fair value |  | $ | 9,541 |  |  | $ | 11 |  |  | $ | (339 | ) |  | $ | 9,213 |  |

[0000950170-23-020333:notes:118]
|  |  | As of December 31, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,538 |  |  | $ | 5 |  |  | $ | (81 | ) |  | $ | 2,462 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (5 | ) |  |  | 180 |  |
| Asset-backed bonds |  |  | 818 |  |  |  | 1 |  |  |  | (24 | ) |  |  | 795 |  |
| Mortgage/Agency-backed bonds |  |  | 1,853 |  |  |  | — |  |  |  | (105 | ) |  |  | 1,748 |  |
| U.S. government bonds |  |  | 3,870 |  |  |  | 3 |  |  |  | (188 | ) |  |  | 3,685 |  |
| Foreign government bonds |  |  | 407 |  |  |  | — |  |  |  | (24 | ) |  |  | 383 |  |
| Available-for-sale debt securities held at fair value |  | $ | 9,671 |  |  | $ | 9 |  |  | $ | (427 | ) |  | $ | 9,253 |  |

[0000950170-23-020333:notes:119]
The contractual maturities related to debt securities and other investments were as follows:

[0000950170-23-020333:notes:120]
|  |  | As of March 31, 2023 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 369 |  |  | $ | 181 |  |  | $ | — |  |  | $ | — |  |  | $ | 508 |  |  | $ | — |  |  |
| One to two years |  |  | 966 |  |  |  | — |  |  |  | 169 |  |  |  | 166 |  |  |  | 3,174 |  |  |  | 387 |  |  |
| Two to three years |  |  | 824 |  |  |  | — |  |  |  | 49 |  |  |  | 600 |  |  |  | 348 |  |  |  | — |  |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 337 |  |  |  | 242 |  |  |  | 123 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 238 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 160 |  |  |  | 372 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 2,159 |  |  | $ | 181 |  |  | $ | 715 |  |  | $ | 1,618 |  |  | $ | 4,153 |  |  | $ | 387 |  |  |

[0000950170-23-020333:notes:121]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0000950170-23-020333:notes:122]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to its debt securities:

[0000950170-23-020333:notes:123]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Gross realized gain on debt securities |  | $ | 4 |  |  | $ | 12 |  |
| Gross realized loss on debt securities |  |  | (11 | ) |  |  | (40 | ) |
| Total (loss) gain recognized, net |  | $ | (7 | ) |  | $ | (28 | ) |

[0000950170-23-020333:notes:124]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. No allowance for credit losses was recorded for the three months ended March 31, 2023 and 2022 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2023.

[0000950170-23-020333:notes:125]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0000950170-23-020333:notes:126]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Realized (loss) gain on equity securities sold |  | $ | 13 |  |  | $ | (25 | ) |
| Unrealized (loss) gain on equity securities held |  |  | 1,246 |  |  |  | (3,362 | ) |
| Total (loss) gain recognized, net |  | $ | 1,259 |  |  | $ | (3,387 | ) |

[0000950170-23-020333:notes:127]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-23-020333:notes:128]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-23-020333:notes:129]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-23-020333:notes:130]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-23-020333:notes:131]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-23-020333:notes:132]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| US government securities |  | $ | 175 |  |  | $ | 175 |  |  | $ | — |  |  | $ | — |  |
| Money market funds |  |  | 243 |  |  |  | 243 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 2,159 |  |  |  | — |  |  |  | 2,159 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 181 |  |  |  | — |  |  |  | 181 |  |  |  | — |  |
| Asset-backed bonds |  |  | 715 |  |  |  | — |  |  |  | 715 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,618 |  |  |  | — |  |  |  | 1,618 |  |  |  | — |  |
| U.S. government bonds |  |  | 4,153 |  |  |  | 4,153 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 387 |  |  |  | — |  |  |  | 387 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 821 |  |  |  | 821 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 24,013 |  |  |  | 24,013 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 34,465 |  |  | $ | 29,405 |  |  | $ | 5,060 |  |  | $ | — |  |

[0000950170-23-020333:notes:133]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 2,462 |  |  |  | — |  |  |  | 2,462 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 180 |  |  |  | — |  |  |  | 180 |  |  |  | — |  |
| Asset-backed bonds |  |  | 795 |  |  |  | — |  |  |  | 795 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,748 |  |  |  | — |  |  |  | 1,748 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,685 |  |  |  | 3,685 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 383 |  |  |  | — |  |  |  | 383 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 804 |  |  |  | 804 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,942 |  |  |  | 22,942 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,227 |  |  | $ | 27,659 |  |  | $ | 5,568 |  |  | $ | — |  |

[0000950170-23-020333:notes:134]
The fair value of its Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-23-020333:notes:135]
7. INVENTORY

[0000950170-23-020333:notes:136]
[same as prior period, unchanged from 0000950170-22-023803:notes:122]

[0000950170-23-020333:notes:137]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Raw materials |  | $ | 167,086 |  |  | $ | 186,346 |  |
| Work in process |  |  | 7,383 |  |  |  | 12,087 |  |
| Finished goods |  |  | 241,822 |  |  |  | 229,098 |  |
| Total inventory, net |  | $ | 416,291 |  |  | $ | 427,531 |  |

[0000950170-23-020333:notes:138]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which considers historical usage, known trends, inventory age and market conditions. As of March 31, 2023 and December 31, 2022, inventory reserves were $73.3 million and $57.0 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-23-020333:notes:139]
8. PROPERTY, PLANT AND EQUIPMENT

[0000950170-23-020333:notes:140]
[same as prior period, unchanged from 0000950170-22-023803:notes:126]

[0000950170-23-020333:notes:141]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Engineering and other equipment |  | $ | 173,968 |  |  | $ | 170,785 |  |
| Building |  |  | 83,287 |  |  |  | 82,932 |  |
| Computer hardware and software |  |  | 82,682 |  |  |  | 80,455 |  |
| Building and land improvements |  |  | 51,081 |  |  |  | 47,861 |  |
| Furniture and fixtures |  |  | 23,525 |  |  |  | 22,403 |  |
| Land |  |  | 5,367 |  |  |  | 5,364 |  |
| Total property, plant and equipment |  |  | 419,910 |  |  |  | 409,800 |  |
| Less: accumulated depreciation |  |  | (307,941 | ) |  |  | (299,101 | ) |
| Total property, plant and equipment, net |  | $ | 111,969 |  |  | $ | 110,699 |  |

[0000950170-23-020333:notes:142]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. During the three months ended March 31, 2023 and 2022, no impairment charges were recognized.

[0000950170-23-020333:notes:143]
Depreciation expense was $7.6 million and $2.8 million for the three months ended March 31, 2023 and 2022, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-23-020333:notes:144]
9. GOODWILL

[0000950170-23-020333:notes:145]
The changes in the carrying amount of goodwill for the three months ended March 31, 2023 are as follows:

[0000950170-23-020333:notes:146]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2022 |  | $ | 298,280 |  |  | $ | 83,444 |  |  | $ | 381,724 |  |
| Foreign currency translation adjustments |  |  | 3,139 |  |  |  | 892 |  |  |  | 4,031 |  |
| As of March 31, 2023 |  | $ | 301,419 |  |  | $ | 84,336 |  |  | $ | 385,755 |  |

[0000950170-23-020333:notes:147]
Related to the Business Combination with ADVA the Company recognized $350.5 million of goodwill upon the merger on July 15, 2022. Goodwill represents the excess purchase price over the fair value of net assets acquired. We qualitatively assess the carrying value of goodwill each reporting period for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Based on its assessment of certain qualitative factors such as macro-economic conditions, industry and market considerations, costs factors and overall financial performance, management concluded that no such events or circumstance changes were identified that would suggest that the fair value of the goodwill was more likely than not greater than it's

[0000950170-23-020333:notes:148]
carrying amount as of March 31, 2023. No impairment of goodwill was recorded during the three months ended March 31, 2023 and 2022.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-23-020333:notes:149]
10. INTANGIBLE ASSETS

[0000950170-23-020333:notes:150]
[same as prior period, unchanged from 0000950170-22-023803:notes:135]

[0000950170-23-020333:notes:151]
|  |  |  |  | As of March 31, 2023 |  |  | As of December 31, 2022 |  |
| (In thousands) | Weighted Average Useful Life(in years) |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | 10.9 |  |  | $ | 54,103 |  |  | $ | (12,180 | ) |  | $ | 41,923 |  |  | $ | 55,517 |  |  | $ | (12,772 | ) |  | $ | 42,745 |  |
| Backlog |  | 1.6 |  |  |  | 56,382 |  |  |  | (35,348 | ) |  |  | 21,034 |  |  |  | 55,782 |  |  |  | (22,725 | ) |  |  | 33,057 |  |
| Developed technology |  | 8.5 |  |  |  | 323,723 |  |  |  | (31,604 | ) |  |  | 292,119 |  |  |  | 320,364 |  |  |  | (21,856 | ) |  |  | 298,508 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (3,305 | ) |  |  | 2,595 |  |  |  | 5,900 |  |  |  | (3,141 | ) |  |  | 2,759 |  |
| Licensing agreements |  | 8.5 |  |  |  | 560 |  |  |  | (316 | ) |  |  | 244 |  |  |  | 560 |  |  |  | (298 | ) |  |  | 262 |  |
| Patents |  | 7.3 |  |  |  | 500 |  |  |  | (449 | ) |  |  | 51 |  |  |  | 500 |  |  |  | (431 | ) |  |  | 69 |  |
| Trade names |  | 3.0 |  |  |  | 29,167 |  |  |  | (7,847 | ) |  |  | 21,320 |  |  |  | 29,066 |  |  |  | (5,255 | ) |  |  | 23,811 |  |
| Total |  |  |  | $ | 470,335 |  |  | $ | (91,049 | ) |  | $ | 379,286 |  |  | $ | 467,689 |  |  | $ | (66,478 | ) |  | $ | 401,211 |  |

[0000950170-23-020333:notes:152]
Intangible assets are reviewed for impairment whenever events and circumstances indicate impairment may have occurred. The Company assessed impairment triggers related to intangible assets during each financial period in 2023 and 2022. As a result, no quantitative impairment test of long-lived assets was performed as of March 31, 2023 and 2022, and no impairment losses of intangible assets were recorded during the three months ended March 31, 2023 and 2022.

[0000950170-23-020333:notes:153]
Amortization expense was $25.8 million and $0.9 million in the three months ended March 31, 2023 and 2022, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.

[0000950170-23-020333:notes:154]
[same as prior period, unchanged from 0000950170-22-023803:notes:139]

[0000950170-23-020333:notes:155]
|  |  | As of |  |
| (In thousands) |  | March 31, 2023 |  |
| 2023 |  | $ | 56,855 |  |
| 2024 |  |  | 58,129 |  |
| 2025 |  |  | 46,558 |  |
| 2026 |  |  | 43,292 |  |
| 2027 |  |  | 41,922 |  |
| Thereafter |  |  | 132,530 |  |
| Total |  | $ | 379,286 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-020333:notes:156]
11. HEDGING

[0000950170-23-020333:notes:157]
The Company has certain forward rate agreements to hedge foreign currency exposure of expected future cash flows in foreign currency. The Company does not hold or issue derivative instruments for trading or other speculative purposes. Derivatives are initially recognized at fair value on the date a derivative contract is entered into and are subsequently re-measured to their fair value at the end of each reporting period. All changes in the fair value of derivative instruments are recognized as other income (expense) in the Consolidated Statements of Income. The derivative instruments are not subject to master netting agreements and are not offset in the Consolidated Balance Sheets. We are exposed to risk from credit-related losses resulting from nonperformance by counterparties to our financial instruments. We perform credit evaluations of our counterparties under forward exchange contracts and expect all counterparties to meet their obligations. We have not experienced credit losses from our counterparties. As of March 31, 2023, the Company had 53 forward rate contracts outstanding.

[0000950170-23-020333:notes:158]
Foreign Currency Hedging Agreement

[0000950170-23-020333:notes:159]
On November 3, 2022, the Company entered into a Euro/U.S. forward contract arrangement (the “Initial Forward”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enables the Company to convert a portion of its Euro denominated payment obligations under the DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of $160.0 million is divided into eight quarterly tranches of $20.0 million, commencing in the fourth quarter of 2022. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-23-020333:notes:160]
On March 21, 2023, the Company entered into a Euro/U.S. dollar forward contract arrangement (the “Forward”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate of $1.085 per €1.00 in average. During the three months ended March 31, 2023, the Company settled one $20.0 million forward contract tranche and the remaining will be divided into seven quarterly tranches of $20.0 million. These new forward contracts transacted on March 21, 2023 (to sell EUR/buy USD) were entered into for the purpose of unwinding the previously transacted forward contracts (to buy EUR/sell USD), transacted in November 2022. The drawdown dates of the original ratchet forwards are set to the same date as the maturity of the new offsetting forward contracts.

[0000950170-23-020333:notes:161]
The fair values of the Company's derivative instruments recorded in the Condensed Consolidated Balance Sheet as of March 31, 2023 and December 31, 2022 were as follows:

[0000950170-23-020333:notes:162]
| (In thousands) |  | Balance Sheet Location |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  | $ | 11,831 |  |  | $ | 11,992 |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  | $ | (351 | ) |  | $ | (633 | ) |
| Total derivatives |  |  |  | $ | 11,480 |  |  | $ | 11,359 |  |

[0000950170-23-020333:notes:163]
The change in the fair values of the Company's derivative instruments recorded in the Condensed Consolidated Statements of Income during the three months ended March 31, 2023 and 2022 were as follows:

[0000950170-23-020333:notes:164]
|  |  |  |  | Three Months Ended |  |
|  |  |  |  | March 31, |  |
| (In thousands) |  | Income StatementLocation |  | 2023 |  |  | 2022 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense), net |  | $ | (69 | ) |  | $ | — |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-020333:notes:165]
12. REVOLVING CREDIT AGREEMENTS

[0000950170-23-020333:notes:166]
The carrying amounts of the Company's revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-23-020333:notes:167]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Wells Fargo credit agreement |  | $ | 180,000 |  |  | $ | 60,000 |  |
| New Nord/LB revolving line of credit |  |  | 10,843 |  |  |  | — |  |
| Nord/LB revolving line of credit |  |  | — |  |  |  | 16,091 |  |
| Syndicated credit agreement working capital line of credit |  |  | — |  |  |  | 10,727 |  |
| DZ bank revolving line of credit |  |  | — |  |  |  | 9,118 |  |
| Total revolving credit agreements |  | $ | 190,843 |  |  | $ | 95,936 |  |

[0000950170-23-020333:notes:168]
As of March 31, 2023, the weighted average interest rate on our revolving credit agreements was 6.2%.

[0000950170-23-020333:notes:169]
Wells Fargo Credit Agreement

[0000950170-23-020333:notes:170]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100 million in aggregate principal amount, but the borrowings increased to up to $400 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.

[0000950170-23-020333:notes:171]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

[0000950170-23-020333:notes:172]
As of March 31, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $180.0 million in tranches that mature during the second and third quarters of 2023 and can either be repaid or borrowed again for a one month, three month or six month period. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million dollar total facility. As of March 31, 2023, we had a total of $3.4 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $216.6 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-23-020333:notes:173]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-23-020333:notes:174]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-23-020333:notes:175]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or

[0000950170-23-020333:notes:176]
consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the consolidated total net leverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the consolidated interest coverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of March 31, 2023, the Company was in compliance with all material covenants. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions.

[0000950170-23-020333:notes:177]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

[0000950170-23-020333:notes:178]
New Nord/LB Revolving Line of Credit

[0000950170-23-020333:notes:179]
On March 29, 2023, ADVA entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of March 31, 2023, ADVA borrowed $10.8 million under this facility.

[0000950170-23-020333:notes:180]
Nord/LB Revolving Line of Credit

[0000950170-23-020333:notes:181]
On August 8, 2022, ADVA entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and which matures in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit. No amounts are available for future borrowings.

[0000950170-23-020333:notes:182]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-23-020333:notes:183]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement working capital line of credit. No amounts are available for future borrowings.

[0000950170-23-020333:notes:184]
DZ Bank Revolving Line of Credit

[0000950170-23-020333:notes:185]
In the fourth quarter of 2022, ADVA entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings under the DZ Bank revolving line of credit. No amounts are available for future borrowings.


## adtn:NotesPayableDisclosureTextBlock

[0000950170-23-020333:notes:186]
13. NOTES PAYABLE

[0000950170-23-020333:notes:187]
The carrying amounts of the Company's notes payable in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-23-020333:notes:188]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | March 31, 2023 |  |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |

[0000950170-23-020333:notes:189]
Syndicated Credit Agreement Note Payable

[0000950170-23-020333:notes:190]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement note payable. No amounts are available for future borrowings.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-23-020333:notes:191]
14. EMPLOYEE BENEFIT PLANS

[0000950170-23-020333:notes:192]
We maintain a defined benefit pension plan covering employees in certain foreign countries.

[0000950170-23-020333:notes:193]
In connection with the Business Combination, we acquired $29.6 million of additional obligations and $22.3 million of assets related to post-employment benefit plans for certain groups of employees at our new operations outside of the U.S. Plans vary depending on the legal, economic, and tax environments of the respective country. For defined benefit plans, accruals for pensions and similar commitments have been included in the results for this year. The new defined benefit plans are for employees in Switzerland, Italy, Israel and India:

[0000950170-23-020333:notes:194]
•
In Switzerland, there are two defined benefit pension plans. Both plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service, salary and on a participants old age account. The plans are financed by contributions paid by the participants and by the Company.

[0000950170-23-020333:notes:195]
•
In Italy, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis. Employees receive their pension payments as a function of salary, inflation and a notional account.

[0000950170-23-020333:notes:196]
•
In Israel, there is a defined benefit pension plan that provides benefits in the event of a participant being dismissed involuntarily, retirement or death. The plan's benefits are based on the higher of the severance benefit required by law or the cash surrender value of the severance benefit component of any qualifying insurance policy or long-term employee benefit fund that is registered in the participants' name. The plan is financed by contributions paid by the Company.

[0000950170-23-020333:notes:197]
•
In India, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis.

[0000950170-23-020333:notes:198]
The Company's net pension liability totaled $10.7 million and $10.6 million as of March 31, 2023 and December 31, 2022, respectively.

[0000950170-23-020333:notes:199]
[same as prior period, unchanged from 0000950170-22-023803:notes:189]

[0000950170-23-020333:notes:200]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Service cost |  | $ | 398 |  |  | $ | 257 |  |
| Interest cost |  |  | (32 | ) |  |  | 222 |  |
| Expected return on plan assets |  |  | 58 |  |  |  | (470 | ) |
| Amortization of actuarial losses |  |  | 6 |  |  |  | 89 |  |
| Net periodic pension cost |  | $ | 430 |  |  | $ | 98 |  |

[0000950170-23-020333:notes:201]
The components of net periodic pension cost, other than the service cost component, are included in other income, net in the Condensed Consolidated Statements of Loss. Service cost is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss. The Company made contributions to the defined benefit pension plans totaling $1.0 million and $0.5 million during the three months ending March 31, 2023 and 2022, respectively. Contributions to the defined benefit pension plans for the remainder of 2023 will be limited to benefit payments to retirees which are paid out of the operating cash flows of the Company and are expected to be approximately $3.3 million.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-23-020333:notes:202]
15. EQUITY

[0000950170-23-020333:notes:203]
Accumulated Other Comprehensive Income (Loss)

[0000950170-23-020333:notes:204]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component:

[0000950170-23-020333:notes:205]
|  |  | Three Months Ended March 31, 2023 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2022 |  | $ | (836 | ) |  | $ | (1,016 | ) |  | $ | 48,180 |  |  | $ | 385 |  |  | $ | 46,713 |  |
| Other comprehensive income before reclassifications |  |  | 83 |  |  |  | — |  |  |  | 8,678 |  |  |  | — |  |  |  | 8,761 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (14 | ) |  |  | 35 |  |  |  | — |  |  |  | — |  |  |  | 21 |  |
| Net current period other comprehensive income |  |  | 69 |  |  |  | 35 |  |  |  | 8,678 |  |  |  | — |  |  |  | 8,782 |  |
| Less: Comprehensive income attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | 244 |  |  |  | — |  |  |  | 244 |  |
| Balance as of March 31, 2023 |  | $ | (767 | ) |  | $ | (981 | ) |  | $ | 56,614 |  |  | $ | 385 |  |  | $ | 55,251 |  |

[0000950170-23-020333:notes:206]
|  |  | Three Months Ended March 31, 2022 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2021 |  | $ | (552 | ) |  | $ | (5,613 | ) |  | $ | (6,134 | ) |  | $ | 385 |  |  | $ | (11,914 | ) |
| Other comprehensive loss before reclassifications |  |  | (975 | ) |  |  | — |  |  |  | (905 | ) |  |  | — |  |  |  | (1,880 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 251 |  |  |  | (13 | ) |  |  | — |  |  |  | — |  |  |  | 238 |  |
| Net current period other comprehensive income (loss) |  |  | (724 | ) |  |  | (13 | ) |  |  | (905 | ) |  |  | — |  |  |  | (1,642 | ) |
| Balance as of March 31, 2022 |  | $ | (1,276 | ) |  | $ | (5,626 | ) |  | $ | (7,039 | ) |  | $ | 385 |  |  | $ | (13,556 | ) |

[0000950170-23-020333:notes:207]
[same as prior period, unchanged from 0000950170-22-023803:notes:203]

[0000950170-23-020333:notes:208]
|  |  | Three Months Ended March 31, 2023 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in theStatement Where Net(Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 18 |  |  | Net investment (loss) gain |
| Defined benefit plan adjustments – actuarial loss |  |  | (51 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (33 | ) |  |  |
| Tax benefit |  |  | 12 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (21 | ) |  |  |

[0000950170-23-020333:notes:209]
[same as prior period, unchanged from 0000950170-22-023803:notes:205]

[0000950170-23-020333:notes:210]
|  |  | Three Months Ended March 31, 2022 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where Net (Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (330 | ) |  | Net investment (loss) gain |
| Defined benefit plan adjustments – actuarial gain |  |  | 19 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (311 | ) |  |  |
| Tax benefit |  |  | 73 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (238 | ) |  |  |

[0000950170-23-020333:notes:211]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss):

[0000950170-23-020333:notes:212]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | March 31, 2023 |  |  | March 31, 2022 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | 109 |  |  | $ | (26 | ) |  | $ | 83 |  |  | $ | (1,283 | ) |  | $ | 308 |  |  | $ | (975 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) gain |  |  | (18 | ) |  |  | 4 |  |  |  | (14 | ) |  |  | 330 |  |  |  | (79 | ) |  |  | 251 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) gain |  |  | 51 |  |  |  | (16 | ) |  |  | 35 |  |  |  | (19 | ) |  |  | 6 |  |  |  | (13 | ) |
| Foreign currency translation adjustments |  |  | 8,678 |  |  |  | — |  |  |  | 8,678 |  |  |  | (905 | ) |  |  | — |  |  |  | (905 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 8,820 |  |  | $ | (38 | ) |  | $ | 8,782 |  |  | $ | (1,877 | ) |  | $ | 235 |  |  | $ | (1,642 | ) |


## us-gaap:RedeemableNoncontrollingInterestTableTextBlock

[0000950170-23-020333:notes:213]
The following table summarizes the redeemable non-controlling interest activity for the three months ended March 31, 2023:

[0000950170-23-020333:notes:214]
|  |  | Three Months Ended |  |
| (In thousands) |  | March 31, 2023 |  |
| Balance at beginning of period |  | $ | — |  |
| Reclassification of non-controlling interests |  |  | 443,757 |  |
| Redemption of redeemable non-controlling interest |  |  | (1,519 | ) |
| Net income attributable to redeemable non-controlling interests |  |  | 2,809 |  |
| Annual recurring compensation earned |  |  | (2,809 | ) |
| Translation adjustment |  |  | 430 |  |
| Balance as of March 31, 2023 |  | $ | 442,668 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-020333:notes:215]
[same as prior period, unchanged from 0000950170-22-023803:notes:212]

[0000950170-23-020333:notes:216]
[same as prior period, unchanged from 0000950170-22-023803:notes:213]

[0000950170-23-020333:notes:217]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2023 |  |  | 2022 |  |
| Numerator |  |  |  |  |  |  |
| Net loss attributable to ADTRAN Holdings, Inc. |  | $ | (34,464 | ) |  | $ | (1,127 | ) |
| Denominator |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 78,358 |  |  |  | 49,113 |  |
| Effect of dilutive securities |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 78,358 |  |  |  | 49,113 |  |
| Loss per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.44 | ) |  | $ | (0.02 | ) |
| Loss per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.44 | ) |  | $ | (0.02 | ) |

[0000950170-23-020333:notes:218]
For the three months ended March 31, 2023 and 2022, 0.1 million and five thousand shares, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0000950170-23-020333:notes:219]
For the three months ended March 31, 2023 and 2022, 0.4 million and 0.1 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the applicable period, making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-020333:notes:220]
[same as prior period, unchanged from 0000950170-22-023803:notes:217]

[0000950170-23-020333:notes:221]
[same as prior period, unchanged from 0000950170-22-023803:notes:218]

[0000950170-23-020333:notes:222]
The Network Solutions segment includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions. The Company's cloud-managed Wi-Fi gateways, virtualization software, and switches provide a mix of wired and wireless connectivity at the customer premises. In addition, its Carrier Ethernet products support a variety of applications at the network edge ranging from mobile backhaul to connecting enterprise customers (“Subscriber Solutions"). The Company's portfolio includes products for multi-gigabit service delivery over fiber or alternative media to homes and businesses.

[0000950170-23-020333:notes:223]
The Services & Support segment offers a comprehensive portfolio of network design, implementation, maintenance and cloud-hosted services supporting its Subscriber, Access and Aggregation, and Optical Networking Solutions. These services assist operators in the deployment of multi-vendor networks while reducing their cost to maintain these networks. The cloud-hosted services include a suite of SaaS applications under the Company's Mosaic One platform that manages end-to-end network and service optimization for both fiber access infrastructure and mesh Wi-Fi connectivity. The Company backs these services with a global support organization that offers on-site and off-site support services with varying SLAs.

[0000950170-23-020333:notes:224]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment (loss) gain, other income (loss), net and income tax benefit (expense) are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-23-020333:notes:225]
The following table presents information about the revenue and gross profit of its reportable segments:

[0000950170-23-020333:notes:226]
|  |  | Three Months Ended |  |
|  |  | March 31, 2023 |  |  | March 31, 2022 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 282,418 |  |  | $ | 63,288 |  |  | $ | 138,374 |  |  | $ | 47,721 |  |
| Services & Support |  |  | 41,494 |  |  |  | 24,520 |  |  |  | 16,144 |  |  |  | 6,595 |  |
| Total |  | $ | 323,912 |  |  | $ | 87,808 |  |  | $ | 154,518 |  |  | $ | 54,316 |  |

[0000950170-23-020333:notes:227]
For the three months ended March 31, 2023 and 2022, $1.5 million and $0.2 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the three months ended March 31, 2023 and 2022, $2 thousand and $3 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0000950170-23-020333:notes:228]
[same as prior period, unchanged from 0000950170-22-023803:notes:225]

[0000950170-23-020333:notes:229]
Prior to the Business Combination with ADVA on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with ADVA, the Company has recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable ADVA solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable ADVA solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of ADVA’s portfolio.

[0000950170-23-020333:notes:230]
[same as prior period, unchanged from 0000950170-22-023803:notes:226]

[0000950170-23-020333:notes:231]
[same as prior period, unchanged from 0000950170-22-023803:notes:227]

[0000950170-23-020333:notes:232]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| United States |  | $ | 131,466 |  |  | $ | 99,048 |  |
| Germany |  |  | 76,286 |  |  |  | 10,920 |  |
| United Kingdom |  |  | 57,397 |  |  |  | 30,388 |  |
| Other international |  |  | 58,763 |  |  |  | 14,162 |  |
| Total |  | $ | 323,912 |  |  | $ | 154,518 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-23-020333:notes:233]
[same as prior period, unchanged from 0000950170-22-023803:notes:229]

[0000950170-23-020333:notes:234]
The Company's products generally include warranties of 90 days to five years for product defects. The Company accrues for warranty returns at the time of product shipment based on its historical return rate and estimate of the cost to repair or replace the defective products. The Company engages in extensive product quality programs and processes, including actively monitoring and evaluating the quality of its component suppliers. The increasing complexity of the Company's products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should the Company's actual experience relative to these factors be worse than its estimates, the Company will be required to record additional warranty expense. The liability for warranty obligations totaled $7.2 million and $7.2 million as of March 31, 2023 and December 31, 2022, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. The warranty expense and write-off activity for the three months ended March 31, 2023 and 2022 are summarized as follows:

[0000950170-23-020333:notes:235]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 7,196 |  |  | $ | 5,403 |  |
| Plus: Amounts charged to cost and expenses |  |  | 1,077 |  |  |  | 344 |  |
| Plus: Foreign currency translation adjustments |  |  | 26 |  |  |  | — |  |
| Less: Deductions |  |  | (1,099 | ) |  |  | (604 | ) |
| Balance at end of period |  | $ | 7,200 |  |  | $ | 5,143 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-020333:notes:236]
20. COMMITMENTS AND CONTINGENCIES

[0000950170-23-020333:notes:237]
Legal Matters

[0000950170-23-020333:notes:238]
From time to time the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

[0000950170-23-020333:notes:239]
DPLTA Exit Costs

[0000950170-23-020333:notes:240]
Pursuant to the terms of the DPLTA, each ADVA shareholder (other than the Company) has received an offer to elect either (1) to remain an ADVA shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation. Assuming all of the minority holders of currently outstanding ADVA shares were to elect the second option, we are obligated to make aggregate Exit Compensation payments of approximately EUR 309.5 million or approximately $335.6 million, based on an exchange rate as of March 31, 2023. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside ADVA shareholders to tender ADVA shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-020333:notes:241]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately EUR 10.5 million or $11.3 million (based on the current exchange rate) per year assuming none of the minority ADVA shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2023, we accrued $2.8 million in Annual Recurring Compensation, which was reflected as a reduction to retained earnings.

[0000950170-23-020333:notes:242]
Performance Bonds

[0000950170-23-020333:notes:243]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2023 and December 31, 2022, we had commitments related to these bonds totaling $11.7 million and $22.0 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-23-020333:notes:244]
Purchase Commitments

[0000950170-23-020333:notes:245]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of March 31, 2023, purchase commitments totaled $459.3 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-020333:notes:246]
21. RESTRUCTURING

[0000950170-23-020333:notes:247]
During the fourth quarter of 2022, the Company initiated a restructuring program designed to optimize the assets and business processes, and information technology systems of the Company in relation to the Business Combination with ADVA. The restructuring program is expected to maximize cost synergies by realizing operation scale, combining sales channels, streamlining corporate and general and administrative functions, including human capital resources and combining sourcing and production costs.

[0000950170-23-020333:notes:248]
In February 2019, the Company announced the restructuring of a certain portion of its workforce predominantly in Germany, which included the closure of the Company’s office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. Voluntary early retirement was offered to certain other employees and was announced in March 2019 and again in August 2020. This plan was completed in 2021 and all amounts were paid in 2022.

[0000950170-23-020333:notes:249]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Condensed Consolidated Balance Sheets as of March 31, 2023 and December 31, 2022, is as follows:

[0000950170-23-020333:notes:250]
|  |  | Three Months Ended |  |
| (In thousands) |  | March 31, 2023 |  |
| Balance at beginning of period |  | $ | 159 |  |
| Plus: Amounts charged to cost and expense |  |  | 2,437 |  |
| Less: Amounts paid |  |  | (1,574 | ) |
| Balance as of March 31, 2023 |  | $ | 1,022 |  |

[0000950170-23-020333:notes:251]
|  |  | For the Year Ended |  |
| (In thousands) |  | December 31, 2022 |  |
| Balance as of December 31, 2021 |  | $ | 1,514 |  |
| Plus: Amounts charged to cost and expense |  |  | 1,629 |  |
| Less: Amounts paid |  |  | (2,984 | ) |
| Balance as of December 31, 2022 |  | $ | 159 |  |

[0000950170-23-020333:notes:252]
Restructuring expenses included in the Condensed Consolidated Statements of (Loss) Income are for the three months ended March 31, 2023 and 2022:

[0000950170-23-020333:notes:253]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Network Solutions - Cost of revenue |  | $ | 58 |  |  | $ | — |  |
| Services & Support - Cost of revenue |  |  | 18 |  |  |  | — |  |
| Cost of revenue |  | $ | 76 |  |  | $ | — |  |
| Selling, general and administrative expenses (1) |  |  | 2,180 |  |  |  | 2 |  |
| Research and development expenses (1) |  |  | 181 |  |  |  | — |  |
| Total restructuring expenses |  | $ | 2,437 |  |  | $ | 2 |  |

[0000950170-23-020333:notes:254]
The following table represents the components of restructuring expense by geographic area for the three months ended March 31, 2023 and 2022:

[0000950170-23-020333:notes:255]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| United States |  | $ | 1,119 |  |  | $ | 2 |  |
| International |  |  | 1,318 |  |  |  | — |  |
| Total restructuring expenses |  | $ | 2,437 |  |  | $ | 2 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-23-020333:notes:256]
22. SUBSEQUENT EVENTS

[0000950170-23-020333:notes:257]
Dividend Approval

[0000950170-23-020333:notes:258]
On May 8, 2023, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 23, 2023. The payment date will be June 6, 2023 in the aggregate amount of approximately $7.1 million.

[0000950170-23-020333:notes:259]
Appointment of Ulrich Dopfer as Principal Accounting Officer

[0000950170-23-020333:notes:260]
As previously disclosed on the Company’s Form 8-K filed on March 30, 2023, Michael Foliano, formerly Senior Vice President of Finance and Chief Financial Officer of the Company, notified the Company of his intent to retire, effective June 28, 2023. Mr. Foliano served in his role as Chief Financial Officer of the Company through April 30, 2023. In connection with his transition, the Board of Directors appointed Ulrich Dopfer as Senior Vice President and Chief Financial Officer of the Company, effective May 1, 2023; however, Mr. Foliano continued to serve as the Company’s “principal accounting officer” within the meaning of the rules of the SEC under the Exchange Act (the “Principal Accounting Officer”), and as the Company’s Treasurer and Secretary. On May 10, 2023, the Board of Directors removed Mr. Foliano from such roles, designated Mr. Dopfer as the Company’s Principal Accounting Officer, and elected Mr. Dopfer as Treasurer and Secretary of the Company, effective as of such date.

[0000950170-23-020333:notes:261]
ADVA Legal Matter

[0000950170-23-020333:notes:262]
On May 8, 2023, ADVA and its U.S. subsidiary, ADVA Optical Networking North America Inc., filed a lawsuit in the U.S District Court for the Eastern District of Texas against Huawei Technologies Co. Ltd (“Huawei”) seeking a declaration from the court that Huawei violated contractual commitments to negotiate in good faith and to license patents, to the extent any patents are practiced by ADVA, on Fair, Reasonable and Non-Discriminatory (“FRAND”) terms and conditions. The case also seeks to obtain a ruling by the court that ADVA has complied with its own commitments and requests that the Court establish FRAND terms and conditions for obtaining a FRAND license on any standard essential patents that ADVA does in fact practice. The lawsuit also seeks to enjoin Huawei from enforcing certain of its patents against ADVA and its affiliates in other jurisdictions, and includes allegations by ADVA that it does not infringe five Huawei patents and that Huawei has infringed an ADVA patent. Huawei has not yet filed an answer in this matter. Given the current status of this matter, the Company is unable predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.
