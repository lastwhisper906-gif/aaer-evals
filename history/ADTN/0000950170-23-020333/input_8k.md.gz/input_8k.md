# ADTN 8-K — 0000950170-23-019145 filed 2023-05-09

## item codes, every 8-K on or before 2023-05-10

- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2023-05-10

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-23-019145:8k_2_02:1]
EX-99
2
adt-ex99_1.htm
EX-99.1

[0000950170-23-019145:8k_2_02:2]
EX-99

[0000950170-23-019145:8k_2_02:3]
EXHIBIT 99.1

[0000950170-23-019145:8k_2_02:4]
ADTRAN Holdings, Inc. Reports Earnings for the First Quarter of 2023 and Declares Quarterly Cash Dividend

[0000950170-23-019145:8k_2_02:5]
HUNTSVILLE, Ala. — (May 8, 2023) — ADTRAN Holdings, Inc., (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” or the “Company”), today announced its financial results for the first quarter of 2023. For the quarter, revenue was $323.9 million. Net loss inclusive of the non-controlling interest for the first quarter of 2023 was $40.5 million. Net loss attributable to the Company for the first quarter of 2023 was $34.5 million and diluted loss per share attributable to the Company was $0.44. Inclusive of non-controlling interest, non-GAAP net loss was $9.5 million. Non-GAAP net loss attributable to the Company was $5.0 million and non-GAAP diluted loss per share attributable to the Company was $0.06. Non-GAAP net (loss) income and non-GAAP diluted (loss) earnings per share exclude acquisition related expenses, amortizations, adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments), stock-based compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, asset impairments, integration expenses, restructuring expenses, changes in valuation allowance related to our deferred tax assets, and the tax effect of these adjustments to net (loss) income. The reconciliations between the non-GAAP net (loss) income measures presented herein and the respective equivalent GAAP financial measures are set forth in the tables provided below.

[0000950170-23-019145:8k_2_02:6]
ADTRAN Holdings Chairman and Chief Executive Officer Tom Stanton stated, “As mentioned in our pre-release, the results of the quarter were impacted by slowing sales predominately in our Subscriber Solutions category. Although we expect customer inventory management efforts to continue to affect our near-term results, the underlying demand to upgrade and deploy fiber networks is at an unprecedented high and we are ideally positioned to capitalize on this opportunity.”

[0000950170-23-019145:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the first quarter of 2023. The quarterly cash dividend of $0.09 per common share is to be paid to the Company’s stockholders of record as of the close of business on May 23, 2023. The ex-dividend date is May 22, 2023, and the payment date will be June 6, 2023.

[0000950170-23-019145:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its first quarter results on Tuesday, May 9, 2023, at 9:30 a.m. Central Time, or 4:30 p.m. Central European Time. ADTRAN Holdings will webcast this conference call. To listen, simply visit our Investor Relations site at investors.adtran.com approximately 10 minutes prior to the start of the call, click on the event “ADTRAN Holdings Releases 1st Quarter 2023 Financial Results and Earnings Call”, and click on the webcast link.

[0000950170-23-019145:8k_2_02:9]
An online replay of the Company’s conference call, as well as the transcript of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit investors.adtran.com or email investor.relations@adtran.com.

[0000950170-23-019145:8k_2_02:10]
Cautionary Note Regarding Forward-Looking Statements

[0000950170-23-019145:8k_2_02:11]
Explanation of Use of Non-GAAP Financial Measures

[0000950170-23-019145:8k_2_02:12]
Set forth in the tables below are reconciliations of gross profit, gross margin, operating expenses, operating loss, other income (expense), net (loss) income inclusive of the non-controlling interest, net (loss) income attributable to the Company, net loss attributable to the non-controlling interest, and (loss) earnings per share - basic and diluted, attributable to the Company, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating (loss) income, non-GAAP other (expense) income, non-GAAP net (loss) income inclusive of the non-controlling interest, non-GAAP net (loss) income attributable to the Company, non-GAAP net (loss) income attributable to the non-controlling interest, and non-GAAP (loss) earnings per share - basic and diluted, attributable to the Company, respectively. Such non-GAAP measures exclude acquisition related expenses, amortizations and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments), stock-based compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, asset impairments, integration expenses, restructuring expenses, changes in valuation allowance related to our deferred tax assets, and the tax effect of these adjustments to net income. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating (loss) income, non-GAAP other (expense) income, non-GAAP net (loss) income inclusive of the non-controlling interest, non-GAAP net (loss) income attributable to the Company, non-GAAP net (loss) income attributable to the non-controlling interest, and non-GAAP (loss) earnings per share - basic and diluted, attributable to the Company, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0000950170-23-019145:8k_2_02:13]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0000950170-23-019145:8k_2_02:14]
About Adtran

[0000950170-23-019145:8k_2_02:15]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises, government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the largest shareholder of ADVA. Find more at Adtran, LinkedIn and Twitter.

[0000950170-23-019145:8k_2_02:16]
Published by

[0000950170-23-019145:8k_2_02:17]
ADTRAN Holdings, Inc.

[0000950170-23-019145:8k_2_02:18]
www.adtran.com

[0000950170-23-019145:8k_2_02:19]
For media

[0000950170-23-019145:8k_2_02:20]
Gareth Spence

[0000950170-23-019145:8k_2_02:21]
+44 1904 699 358

[0000950170-23-019145:8k_2_02:22]
public-relations@adva.com

[0000950170-23-019145:8k_2_02:23]
For investors

[0000950170-23-019145:8k_2_02:24]
Steven Williams

[0000950170-23-019145:8k_2_02:25]
+49 89 890 665 918

[0000950170-23-019145:8k_2_02:26]
investor.relations@adtran.com

[0000950170-23-019145:8k_2_02:27]
Condensed Consolidated Balance Sheets

[0000950170-23-019145:8k_2_02:28]
(Unaudited)

[0000950170-23-019145:8k_2_02:29]
(In thousands)

[0000950170-23-019145:8k_2_02:30]
|  | March 31, |  |  | December 31, |  |
|  | 2023 |  |  | 2022 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 136,457 |  |  | $ | 108,644 |  |
| Short-term investments |  | 1,058 |  |  |  | 340 |  |
| Accounts receivable, net |  | 262,043 |  |  |  | 279,435 |  |
| Other receivables |  | 30,938 |  |  |  | 32,831 |  |
| Inventory, net |  | 416,291 |  |  |  | 427,531 |  |
| Prepaid expenses and other current assets |  | 37,021 |  |  |  | 33,577 |  |
| Total Current Assets |  | 883,808 |  |  |  | 882,358 |  |
| Property, plant and equipment, net |  | 111,969 |  |  |  | 110,699 |  |
| Deferred tax assets |  | 81,631 |  |  |  | 67,839 |  |
| Goodwill |  | 385,755 |  |  |  | 381,724 |  |
| Intangibles, net |  | 379,286 |  |  |  | 401,211 |  |
| Other non-current assets |  | 63,152 |  |  |  | 66,998 |  |
| Long-term investments |  | 32,994 |  |  |  | 32,665 |  |
| Total Assets | $ | 1,938,595 |  |  | $ | 1,943,494 |  |
| Liabilities, Redeemable Non-Controlling Interest and Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 198,596 |  |  | $ | 237,699 |  |
| Revolving credit agreements outstanding |  | 190,843 |  |  |  | 95,936 |  |
| Notes payable |  | — |  |  |  | 24,598 |  |
| Unearned revenue |  | 55,611 |  |  |  | 41,193 |  |
| Accrued expenses and other liabilities |  | 27,424 |  |  |  | 35,235 |  |
| Accrued wages and benefits |  | 30,333 |  |  |  | 44,882 |  |
| Income tax payable, net |  | 19,397 |  |  |  | 9,032 |  |
| Total Current Liabilities |  | 522,204 |  |  |  | 488,575 |  |
| Deferred tax liabilities |  | 51,850 |  |  |  | 61,629 |  |
| Non-current unearned revenue |  | 24,907 |  |  |  | 19,239 |  |
| Pension liability |  | 10,698 |  |  |  | 10,624 |  |
| Deferred compensation liability |  | 28,674 |  |  |  | 26,668 |  |
| Non-current lease obligations |  | 21,446 |  |  |  | 22,807 |  |
| Other non-current liabilities |  | 15,986 |  |  |  | 10,339 |  |
| Total Liabilities |  | 675,765 |  |  |  | 639,881 |  |
| Redeemable Non-Controlling Interest |  | 442,668 |  |  |  | — |  |
| Equity |  |  |  |  |  |
| Common stock |  | 787 |  |  |  | 781 |  |
| Additional paid-in capital |  | 762,035 |  |  |  | 895,834 |  |
| Accumulated other comprehensive income |  | 55,251 |  |  |  | 46,713 |  |
| Retained earnings |  | 8,006 |  |  |  | 55,338 |  |
| Treasury stock |  | (5,917 | ) |  |  | (4,125 | ) |
| Non-controlling interest |  | — |  |  |  | 309,072 |  |
| Total Equity |  | 820,162 |  |  |  | 1,303,613 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity | $ | 1,938,595 |  |  | $ | 1,943,494 |  |

[0000950170-23-019145:8k_2_02:31]
Condensed Consolidated Statements of Loss

[0000950170-23-019145:8k_2_02:32]
(Unaudited)

[0000950170-23-019145:8k_2_02:33]
(In thousands, except per share amounts)

[0000950170-23-019145:8k_2_02:34]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2023 |  |  | 2022 |  |  |
| Revenue |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 282,418 |  |  | $ | 138,374 |  |  |
| Services & Support |  |  | 41,494 |  |  |  | 16,144 |  |  |
| Total Revenue |  |  | 323,912 |  |  |  | 154,518 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |
| Network Solutions |  |  | 219,130 |  |  |  | 90,653 |  |  |
| Services & Support |  |  | 16,974 |  |  |  | 9,549 |  |  |
| Total Cost of Revenue |  |  | 236,104 |  |  |  | 100,202 |  |  |
| Gross Profit |  |  | 87,808 |  |  |  | 54,316 |  |  |
| Selling, general and administrative expenses |  |  | 67,397 |  |  |  | 27,893 |  |  |
| Research and development expenses |  |  | 70,143 |  |  |  | 26,491 |  |  |
| Operating Loss |  |  | (49,732 | ) |  |  | (68 | ) |  |
| Interest and dividend income |  |  | 304 |  |  |  | 204 |  |  |
| Interest expense |  |  | (3,287 | ) |  |  | (30 | ) |  |
| Net investment gain (loss) |  |  | 1,252 |  |  |  | (3,415 | ) |  |
| Other expense, net |  |  | (303 | ) |  |  | (226 | ) |  |
| Loss Before Income Taxes |  |  | (51,766 | ) |  |  | (3,535 | ) |  |
| Income tax benefit |  |  | 11,313 |  |  |  | 2,408 |  |  |
| Net Loss |  | $ | (40,453 | ) |  | $ | (1,127 | ) |  |
| Less: Net Loss attributable to non-controlling interest(1) |  |  | (5,989 | ) |  |  | — |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (34,464 | ) |  | $ | (1,127 | ) |  |
| Weighted average shares outstanding – basic |  |  | 78,358 |  |  |  | 49,113 |  |  |
| Weighted average shares outstanding – diluted |  |  | 78,358 |  |  |  | 49,113 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.44 | ) |  | $ | (0.02 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.44 | ) |  | $ | (0.02 | ) |  |

[0000950170-23-019145:8k_2_02:35]
(1) Includes $3.2 million of net loss attributable to non-controlling interests pre-DPLTA and $2.8 million of annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0000950170-23-019145:8k_2_02:36]
Condensed Consolidated Statements of Cash Flows

[0000950170-23-019145:8k_2_02:37]
(Unaudited)

[0000950170-23-019145:8k_2_02:38]
(In thousands)

[0000950170-23-019145:8k_2_02:39]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net loss |  | $ | (40,453 | ) |  | $ | (1,127 | ) |
| Adjustments to reconcile net loss to net cash (used in) provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 33,402 |  |  |  | 3,661 |  |
| Amortization of debt issuance cost |  |  | 146 |  |  |  | — |  |
| (Gain) loss on investments |  |  | (3,154 | ) |  |  | 3,304 |  |
| Stock-based compensation expense |  |  | 3,812 |  |  |  | 1,893 |  |
| Deferred income taxes |  |  | (24,019 | ) |  |  | — |  |
| Other, net |  |  | (1 | ) |  |  | (62 | ) |
| Inventory reserves |  |  | 16,051 |  |  |  | (1,754 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 17,658 |  |  |  | 8,697 |  |
| Other receivables |  |  | 1,980 |  |  |  | (6,205 | ) |
| Inventory |  |  | (2,764 | ) |  |  | (29,685 | ) |
| Prepaid expenses, other current assets and other assets |  |  | 1,118 |  |  |  | (1,170 | ) |
| Accounts payable |  |  | (40,367 | ) |  |  | 24,818 |  |
| Accrued expenses and other liabilities |  |  | 6,349 |  |  |  | 3,803 |  |
| Income taxes payable, net |  |  | 10,316 |  |  |  | (1,304 | ) |
| Net cash (used in) provided by operating activities |  |  | (19,926 | ) |  |  | 4,869 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (8,439 | ) |  |  | (1,461 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 930 |  |  |  | 10,265 |  |
| Purchases of available-for-sale investments |  |  | (516 | ) |  |  | (11,504 | ) |
| Proceeds from beneficial interests in securitized accounts receivable |  |  | 1,231 |  |  |  | — |  |
| Net cash used in investing activities |  |  | (6,794 | ) |  |  | (2,700 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (6,258 | ) |  |  | (54 | ) |
| Proceeds from stock option exercises |  |  | 58 |  |  |  | 568 |  |
| Dividend payments |  |  | (7,076 | ) |  |  | (4,438 | ) |
| Proceeds from draw on revolving credit agreements |  |  | 138,236 |  |  |  | 8,000 |  |
| Repayment of revolving credit agreements |  |  | (43,464 | ) |  |  | (8,000 | ) |
| Non-controlling interest put option buyback |  |  | (1,176 | ) |  |  | — |  |
| Repayment of notes payable |  |  | (24,692 | ) |  |  | — |  |
| Net cash provided by (used in) financing activities |  |  | 55,628 |  |  |  | (3,924 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 28,908 |  |  |  | (1,755 | ) |
| Effect of exchange rate changes |  |  | (1,095 | ) |  |  | (1,032 | ) |
| Cash and cash equivalents, beginning of period |  |  | 108,644 |  |  |  | 56,818 |  |
| Cash and cash equivalents, end of period |  | $ | 136,457 |  |  | $ | 54,031 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 1,610 |  |  | $ | 30 |  |
| Cash used in operating activities related to operating leases |  | $ | 4,057 |  |  | $ | 482 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 486 |  |  | $ | 332 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 4,354 |  |  | $ | 392 |  |

[0000950170-23-019145:8k_2_02:40]
Supplemental Information

[0000950170-23-019145:8k_2_02:41]
Reconciliation of Gross Profit and Gross Margin to

[0000950170-23-019145:8k_2_02:42]
Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0000950170-23-019145:8k_2_02:43]
(Unaudited)

[0000950170-23-019145:8k_2_02:44]
(In thousands)

[0000950170-23-019145:8k_2_02:45]
|  |  | Three Months Ended |  |
|  |  | March 31, 2023 |  |  | December 31, 2022 |  |  | March 31, 2022 |  |
| Total Revenue |  | $ | 323,912 |  |  | $ | 358,271 |  |  | $ | 154,518 |  |
| Cost of Revenue |  | $ | 236,104 |  |  | $ | 250,868 |  |  | $ | 100,202 |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | (32,578 | ) | (1) |  | (31,577 | ) | (3) |  | — |  |
| Stock-based compensation expense |  |  | (240 | ) | (2) |  | (1,287 | ) | (4) |  | (159 | ) |
| Pension adjustments |  |  | — |  |  |  | 144 |  |  |  | — |  |
| Restructuring expenses |  |  | (76 | ) |  |  | (8 | ) |  |  | — |  |
| Non-GAAP Cost of Revenue |  | $ | 203,210 |  |  | $ | 218,140 |  |  | $ | 100,043 |  |
| Gross Profit |  | $ | 87,808 |  |  | $ | 107,403 |  |  | $ | 54,316 |  |
| Non-GAAP Gross Profit |  | $ | 120,702 |  |  | $ | 140,131 |  |  | $ | 54,475 |  |
| Gross Margin |  |  | 27.1 | % |  |  | 30.0 | % |  |  | 35.2 | % |
| Non-GAAP Gross Margin |  |  | 37.3 | % |  |  | 39.1 | % |  |  | 35.3 | % |

[0000950170-23-019145:8k_2_02:46]
(1)  Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $32.6 million is included in total cost of revenue, on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:47]
(2) Includes $0.2 million in cost of revenue expenses incremental stock-based award modification expense related to the business combination on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:48]
(3)  Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $31.6 million is included in total cost of revenue, on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:49]
(4) Includes $1.3 million in cost of revenue expenses incremental stock-based award modification expense related to the business combination on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:50]
Supplemental Information

[0000950170-23-019145:8k_2_02:51]
Reconciliation of Operating Expenses to Non-GAAP Operating Expenses

[0000950170-23-019145:8k_2_02:52]
(Unaudited)

[0000950170-23-019145:8k_2_02:53]
(In thousands)

[0000950170-23-019145:8k_2_02:54]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |  |
|  |  | 2023 |  |  | 2022 |  |  | 2022 |  |  |
| Operating Expenses |  | $ | 137,540 |  |  | $ | 139,813 |  |  | $ | 54,384 |  |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | (4,584 | ) | (1) |  | (8,328 | ) | (6) |  | (2,330 | ) | (10) |
| Stock-based compensation expense |  |  | (3,458 | ) | (2) |  | (11,095 | ) | (7) |  | (1,734 | ) | (11) |
| Restructuring expenses |  |  | (2,361 | ) | (3) |  | (1,618 | ) | (8) |  | (2 | ) | (12) |
| Integration expenses |  |  | (849 | ) | (4) |  | — |  |  |  | — |  |  |
| Pension adjustments |  |  | — |  |  |  | 43 |  | (9) |  | — |  |  |
| Deferred compensation adjustments |  |  | (394 | ) | (5) |  | (168 | ) | (5) |  | 2,696 |  | (5) |
| Non-GAAP Operating Expenses |  | $ | 125,894 |  |  | $ | 118,647 |  |  | $ | 53,014 |  |  |

[0000950170-23-019145:8k_2_02:55]
(1)  Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $4.1 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of  loss.

[0000950170-23-019145:8k_2_02:56]
(2) $2.5 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:57]
(3) $2.2 million is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:58]
(4) $0.8 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at ADVA and the implementation of the DPLTA.

[0000950170-23-019145:8k_2_02:59]
(5) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-23-019145:8k_2_02:60]
(6)  Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $7.8 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:61]
(7) $9.4 million is included in selling, general and administrative expenses and $1.7 million is included in research and development expenses on the condensed consolidated statements of loss.  Includes $7.3 million of in selling, general and administrative expenses and $0.6 million is included in research and development expenses incremental stock-based award modification expense related to the business combination.

[0000950170-23-019145:8k_2_02:62]
(8) $0.1 is included in selling, general and administrative expenses and $1.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:63]
(9)  $0.2 million is included in selling, general and administrative expenses and ($0.3) million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:64]
(10) $0.5 million is included in selling, general and administrative expenses and $1.8 million is included in research and development expenses on the condensed consolidated statements of loss .

[0000950170-23-019145:8k_2_02:65]
(11) $0.6 million is included in selling, general and administrative expenses and $1.1 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:66]
(12) Less than $0.1 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss.

[0000950170-23-019145:8k_2_02:67]
Supplemental Information

[0000950170-23-019145:8k_2_02:68]
Reconciliation of Operating Loss to Non-GAAP Operating (Loss) Income

[0000950170-23-019145:8k_2_02:69]
(Unaudited)

[0000950170-23-019145:8k_2_02:70]
(In thousands)

[0000950170-23-019145:8k_2_02:71]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |  |
|  |  | 2023 |  |  | 2022 |  |  | 2022 |  |  |
| Operating Loss |  | $ | (49,732 | ) |  | $ | (32,874 | ) |  | $ | (68 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 37,162 |  |  |  | 39,904 |  |  |  | 2,330 |  |  |
| Asset impairments |  |  | — |  |  |  | 463 |  |  |  | — |  |  |
| Stock-based compensation expense |  |  | 3,698 |  |  |  | 12,383 |  |  |  | 1,893 |  |  |
| Pension adjustments |  |  | — |  |  |  | (187 | ) |  |  | — |  |  |
| Restructuring expenses |  |  | 2,437 |  |  |  | 1,627 |  |  |  | 2 |  |  |
| Integration expenses |  |  | 849 |  |  |  | — |  |  |  | — |  |  |
| Deferred compensation adjustments(1) |  |  | 394 |  |  |  | 168 |  |  |  | (2,696 | ) |  |
| Non-GAAP Operating (Loss) Income |  | $ | (5,192 | ) |  | $ | 21,484 |  |  | $ | 1,461 |  |  |

[0000950170-23-019145:8k_2_02:72]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-23-019145:8k_2_02:73]
Supplemental Information

[0000950170-23-019145:8k_2_02:74]
Reconciliation of Other (Expense) Income to Non-GAAP Other (Expense) Income

[0000950170-23-019145:8k_2_02:75]
(Unaudited)

[0000950170-23-019145:8k_2_02:76]
(In thousands)

[0000950170-23-019145:8k_2_02:77]
|  |  | Three Months Ended |  |  |
|  |  | March 31, 2023 |  |  | December 31, 2022 |  |  | March 31, 2022 |  |  |
| Interest and dividend income |  | $ | 304 |  |  | $ | 1,355 |  |  | $ | 204 |  |  |
| Interest expense |  |  | (3,287 | ) |  |  | (2,010 | ) |  |  | (30 | ) |  |
| Net investment gain (loss) |  |  | 1,252 |  |  |  | (587 | ) |  |  | (3,415 | ) |  |
| Other (expense) income, net |  |  | (303 | ) |  |  | 11,568 |  |  |  | (226 | ) |  |
| Total Other (Expense) Income |  | $ | (2,034 | ) |  | $ | 10,326 |  |  | $ | (3,467 | ) |  |
| Deferred compensation adjustments (1) |  |  | (1,250 | ) |  |  | (349 | ) |  |  | 1,841 |  |  |
| Pension expense (2) |  |  | 7 |  |  |  | 77 |  |  |  | 89 |  |  |
| Non-GAAP Other (Expense) Income |  | $ | (3,277 | ) |  | $ | 10,054 |  |  | $ | (1,537 | ) |  |

[0000950170-23-019145:8k_2_02:78]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0000950170-23-019145:8k_2_02:79]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-23-019145:8k_2_02:80]
Supplemental Information

[0000950170-23-019145:8k_2_02:81]
Reconciliation of Net (Loss) Income inclusive of Non-Controlling Interest to

[0000950170-23-019145:8k_2_02:82]
Non-GAAP Net (Loss) Income inclusive of Non-Controlling Interest

[0000950170-23-019145:8k_2_02:83]
(Unaudited)

[0000950170-23-019145:8k_2_02:84]
and

[0000950170-23-019145:8k_2_02:85]
Reconciliation of Net Loss attributable to Non-Controlling Interest to

[0000950170-23-019145:8k_2_02:86]
Non-GAAP Net (Loss) Income attributable to Non-Controlling Interest

[0000950170-23-019145:8k_2_02:87]
(Unaudited)

[0000950170-23-019145:8k_2_02:88]
and

[0000950170-23-019145:8k_2_02:89]
Reconciliation of Net (Loss) Income attributable to ADTRAN Holdings, Inc. and

[0000950170-23-019145:8k_2_02:90]
(Loss) Earnings per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0000950170-23-019145:8k_2_02:91]
Non-GAAP Net (Loss) Income attributable to ADTRAN Holdings, Inc. and

[0000950170-23-019145:8k_2_02:92]
Non-GAAP (Loss) Earnings per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0000950170-23-019145:8k_2_02:93]
(Unaudited)

[0000950170-23-019145:8k_2_02:94]
(In thousands, except per share amounts)

[0000950170-23-019145:8k_2_02:95]
|  |  | Three Months Ended |  |  |
|  |  | March 31,2023 |  |  | December 31,2022 |  |  | March 31,2022 |  |  |
| Net (Loss) Income attributable to ADTRAN Holdings, Inc. |  | $ | (34,464 | ) |  | $ | 38,881 |  |  | $ | (1,127 | ) |  |
| Plus: Net Loss attributable to non-controlling interest (1) |  |  | (5,989 | ) |  |  | (3,926 | ) |  |  | — |  |  |
| Net (Loss) Income inclusive of non-controlling interest |  | $ | (40,453 | ) |  | $ | 34,955 |  |  | $ | (1,127 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 37,162 |  |  |  | 39,904 |  |  |  | 2,330 |  |  |
| Asset impairments |  |  | — |  |  |  | 463 |  |  |  | — |  |  |
| Stock-based compensation expense |  |  | 3,698 |  |  |  | 12,383 |  |  |  | 1,893 |  |  |
| Valuation allowance |  |  | — |  |  |  | (60,908 | ) |  |  | 8,079 |  |  |
| Deferred compensation adjustments (2) |  |  | (856 | ) |  |  | (182 | ) |  |  | (855 | ) |  |
| Pension adjustments (3) |  |  | 7 |  |  |  | (109 | ) |  |  | 89 |  |  |
| Restructuring expenses |  |  | 2,437 |  |  |  | 1,627 |  |  |  | 2 |  |  |
| Integration expenses |  |  | 849 |  |  |  | — |  |  |  | — |  |  |
| Tax effect of adjustments to net income (loss) |  |  | (12,307 | ) |  |  | (12,463 | ) |  |  | (505 | ) |  |
| Non-GAAP Net (Loss) Income inclusive of non-controlling interest |  | $ | (9,463 | ) |  | $ | 15,670 |  |  | $ | 9,906 |  |  |
| Less: Non-GAAP Net (Loss) Income attributable to non-controlling interest (1) |  |  | (4,460 | ) |  |  | 5,769 |  |  |  | — |  |  |
| Non-GAAP Net (Loss) Income attributable to ADTRAN Holdings, Inc. |  | $ | (5,003 | ) |  | $ | 9,901 |  |  | $ | 9,906 |  |  |
| GAAP Net Loss attributable to non-controlling interest (1) |  | $ | (5,989 | ) |  | $ | (3,926 | ) |  | $ | — |  |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,457 |  |  |  | 9,039 |  |  |  | — |  |  |
| Restructuring expenses |  |  | 29 |  |  |  | 402 |  |  |  | — |  |  |
| Integration expenses |  |  | 6 |  |  |  | — |  |  |  | — |  |  |
| Stock-based compensation expense |  |  | 37 |  |  |  | 300 |  |  |  | — |  |  |
| Pension adjustments (3) |  |  | — |  |  |  | (46 | ) |  |  | — |  |  |
| Non-GAAP Net (Loss) Income attributable to non-controlling interest (1) |  | $ | (4,460 | ) |  | $ | 5,769 |  |  | $ | — |  |  |
| Weighted average shares outstanding – basic |  |  | 78,358 |  |  |  | 77,659 |  |  |  | 49,113 |  |  |
| Weighted average shares outstanding – diluted |  |  | 78,358 |  |  |  | 79,243 |  |  |  | 49,113 |  |  |
| (Loss) Earnings per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.44 | ) |  | $ | 0.50 |  |  | $ | (0.02 | ) |  |
| (Loss) Earnings per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.44 | ) |  | $ | 0.49 |  |  | $ | (0.02 | ) |  |
| Non-GAAP (Loss) Earnings per common share attributable to ADTRAN – basic |  | $ | (0.06 | ) |  | $ | 0.13 |  |  | $ | 0.20 |  |  |
| Non-GAAP (Loss) Earnings per common share attributable to ADTRAN – diluted |  | $ | (0.06 | ) |  | $ | 0.12 |  |  | $ | 0.20 |  |  |

[0000950170-23-019145:8k_2_02:96]
(1) Represents the non-controlling interest portion of the Company's ownership of ADVA pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0000950170-23-019145:8k_2_02:97]
(2) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-23-019145:8k_2_02:98]
(3) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.
