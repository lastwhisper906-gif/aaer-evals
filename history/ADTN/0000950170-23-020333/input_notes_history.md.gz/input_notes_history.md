# ADTN note change history — 0000950170-22-023803 → 0000950170-23-020333


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000950170-23-020333:note_history:1]
Legal Matters
  (was, 2022-11-09, similarity 0.96):
[0000950170-22-023803:note_history:1]
Legal Maters

- changed (2023-05-10):
[0000950170-23-020333:note_history:2]
From time to time the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.
  (was, 2022-11-09, similarity 0.8881):
[0000950170-22-023803:note_history:2]
From time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

- added (2023-05-10):
[0000950170-23-020333:note_history:3]
DPLTA Exit Costs

- added (2023-05-10):
[0000950170-23-020333:note_history:4]
Pursuant to the terms of the DPLTA, each ADVA shareholder (other than the Company) has received an offer to elect either (1) to remain an ADVA shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation. Assuming all of the minority holders of currently outstanding ADVA shares were to elect the second option, we are obligated to make aggregate Exit Compensation payments of approximately EUR 309.5 million or approximately $335.6 million, based on an exchange rate as of March 31, 2023. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside ADVA shareholders to tender ADVA shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- added (2023-05-10):
[0000950170-23-020333:note_history:5]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately EUR 10.5 million or $11.3 million (based on the current exchange rate) per year assuming none of the minority ADVA shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2023, we accrued $2.8 million in Annual Recurring Compensation, which was reflected as a reduction to retained earnings.

- changed (2023-05-10):
[0000950170-23-020333:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2023 and December 31, 2022, we had commitments related to these bonds totaling $11.7 million and $22.0 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2022-11-09, similarity 0.7285):
[0000950170-22-023803:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2022 and December 31, 2021, we had commitments related to these bonds totaling $21.1 million and $22.9 million, respectively, which expire at various dates through April 2025. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2023-05-10):
[0000950170-23-020333:note_history:7]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of March 31, 2023, purchase commitments totaled $459.3 million.
  (was, 2022-11-09, similarity 0.9604):
[0000950170-22-023803:note_history:7]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2022, purchase commitments totaled $454.1 million.

- removed (2023-05-10):
[0000950170-22-023803:note_history:8]
Investment Commitment

- removed (2023-05-10):
[0000950170-22-023803:note_history:9]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of September 30, 2022.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-05-10):
[0000950170-23-020333:note_history:10]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

- added (2023-05-10):
[0000950170-23-020333:note_history:11]
In 2022, following the business combination (the “Business Combination”) with ADVA Optical Networking SE (“ADVA”), which included the Merger, we became the sole owner of and successor to ADTRAN, Inc. and the majority shareholder of ADVA. ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video, and internet communications across any network infrastructure. Its award-winning end-to-end fiber broadband solutions portfolio spans from OLTs to in-home services and intelligent SaaS solutions. ADVA is a global provider of open networking solutions with over 25 years of experience in optical networking, carrier Ethernet access and network synchronization. ADVA has led the industry for over two decades with open and secure networking solutions that carefully balance space, power and cost. Together, we serve customers in a broad range of industries in over 100 countries.

- added (2023-05-10):
[0000950170-23-020333:note_history:12]
Effectiveness of the Domination and Profit and Loss Transfer Agreement

- added (2023-05-10):
[0000950170-23-020333:note_history:13]
The DPLTA between the Company, as the controlling company, and ADVA Optical Networking SE, as the controlled company as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of ADVA (Jena).

- added (2023-05-10):
[0000950170-23-020333:note_history:14]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of ADVA, (ii) ADVA will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by ADVA. The obligation of ADVA to transfer its annual profit to the Company applies for the first time to the profit generated subsequent to January 16, 2023.

- added (2023-05-10):
[0000950170-23-020333:note_history:15]
Subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that ADVA preferred shareholders be offered, at their election, (i) to put their ADVA shares to the Company in exchange for a compensation in cash of EUR 17.21 per share (the “Exit Compensation”), or (ii) to remain ADVA preferred shareholders and receive a recurring compensation in cash of EUR 0.59 (EUR 0.52 net under the current tax regime) per share for each full fiscal year of ADVA (the “Annual Recurring Compensation”). The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of ADVA for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of ADVA in 2024. The Annual Recurring Compensation payment is similar to a cumulative dividend, which does not require Board of Director approval as it is guaranteed under the DPLTA, and is accrued as a dividend liability when it is earned.

- added (2023-05-10):
[0000950170-23-020333:note_history:16]
The adequacy of both forms of compensation have been challenged by the preferred shareholders of ADVA via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

- added (2023-05-10):
[0000950170-23-020333:note_history:17]
The opportunity for the ADVA preferred shareholders to tender ADVA preferred shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- added (2023-05-10):
[0000950170-23-020333:note_history:18]
Board Approval Purchase of ADVA Common Stock

- added (2023-05-10):
[0000950170-23-020333:note_history:19]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of ADVA through open market purchases not to exceed 15,346,544 shares.

- changed (2023-05-10):
[0000950170-23-020333:note_history:20]
The accompanying unaudited Condensed Consolidated Financial Statements of ADTRAN Holdings, Inc. and its subsidiaries have been prepared pursuant to the rules and regulations of the SEC applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2022 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.
  (was, 2022-11-09, similarity 0.9287):
[0000950170-22-023803:note_history:20]
The accompanying unaudited Condensed Consolidated Financial Statements of ADTRAN Holdings, Inc. and its subsidiaries have been prepared pursuant to the rules and regulations of the SEC applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. Certain prior year amounts have been reclassified to conform to the current period presentation. The December 31, 2021 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

- changed (2023-05-10):
[0000950170-23-020333:note_history:21]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023.
  (was, 2022-11-09, similarity 0.9786):
[0000950170-22-023803:note_history:21]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN, Inc. Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022.

- changed (2023-05-10):
[0000950170-23-020333:note_history:22]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.
  (was, 2022-11-09, similarity 0.9662):
[0000950170-22-023803:note_history:22]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

- changed (2023-05-10):
[0000950170-23-020333:note_history:23]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of March 31, 2023 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to supply chain constraints, inflationary pressures, the energy crisis, rising interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.
  (was, 2022-11-09, similarity 0.8333):
[0000950170-22-023803:note_history:23]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus), supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of September 30, 2022 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints and inflationary pressures could result in further impacts to the Company's consolidated financial statements in future reporting periods.

- added (2023-05-10):
[0000950170-23-020333:note_history:24]
Revision of Previously Issued Financial Statements

- added (2023-05-10):
[0000950170-23-020333:note_history:25]
During the first quarter of 2023, the Company determined that it understated total assets and total liabilities as of the year ended December 31, 2022, due to netting of deferred tax assets and deferred tax liabilities as of December 31, 2022. While the net amount of deferred tax assets and liabilities remains unchanged, the Company reported the deferred tax assets and liabilities balances without properly applying jurisdictional net reporting disclosure rules. The jurisdictional netting error was a result of the consolidation of financial statements with ADVA following the business combination, which closed on July 15, 2022. The Company revised the December 31, 2022 Consolidated Balance Sheet presented in this report by increasing deferred tax assets and total assets by $61.6 million and increasing deferred tax liability, total liabilities, and total liabilities, redeemable non-controlling interest and equity by $61.6 million. Management has determined that this misstatement was not material to any of its previously issued financial statements.

- added (2023-05-10):
[0000950170-23-020333:note_history:26]
The following table reflects the impact of the revision to the specific line items presented in the Company’s previously reported consolidated financial statements as of and for the year-ended December 31, 2022:

- added (2023-05-10):
[0000950170-23-020333:note_history:27]
| (In thousands) |  | As Reported |  |  | Adjustment |  |  | As Revised |  |
| Deferred tax assets |  | $ | 6,210 |  |  | $ | 61,629 |  |  | $ | 67,839 |  |
| Total assets |  | $ | 1,881,865 |  |  | $ | 61,629 |  |  | $ | 1,943,494 |  |
| Deferred tax liabilities |  | $ | — |  |  | $ | 61,629 |  |  | $ | 61,629 |  |
| Total liabilities |  | $ | 578,252 |  |  | $ | 61,629 |  |  | $ | 639,881 |  |

- added (2023-05-10):
[0000950170-23-020333:note_history:28]
Redeemable Non-Controlling Interest

- added (2023-05-10):
[0000950170-23-020333:note_history:29]
As of March 31, 2023 and December 31, 2022, the ADVA stockholders’ equity ownership percentage in ADVA was approximately 34.6% and 34.7%, respectively.

- added (2023-05-10):
[0000950170-23-020333:note_history:30]
As a result of the effectiveness of the DPLTA on January 16, 2023, the ADVA shares, representing the equity interest in ADVA held by holders other than the Company, can be tendered at any time and are, therefore, redeemable and must be classified outside stockholders’ equity. Therefore, the permanent equity noncontrolling interest balance was reclassified to redeemable non-controlling interest ("RNCI") on January 16, 2023 and was remeasured to fair value based on the trading market price of the ADVA shares.

- added (2023-05-10):
[0000950170-23-020333:note_history:31]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the redeemable noncontrolling interest. However, the RNCI will be remeasured using the current exchange rate at each reporting date as long as the RNCI is currently redeemable. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as redeemable non-controlling interest outside of stockholders’ equity in the condensed consolidated balance sheets.

- added (2023-05-10):
[0000950170-23-020333:note_history:32]
See Note 16 for additional information on RNCI.

- changed (2023-05-10):
[0000950170-23-020333:note_history:33]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. The Company early adopted ASU 2021-08 on July 1, 2022 and the standard was applied retrospectively beginning with January 1, 2022.
  (was, 2022-11-09, similarity 0.8503):
[0000950170-22-023803:note_history:33]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. The Company early adopted ASU 2021-08 on July 1, 2022 and the standard was applied retrospectively beginning with January 1, 2022. The effect of the adoption of this standard on the Company's Condensed Consolidated Financial Statements as of the date of this report is included in Note 2 of the Notes to Condensed Consolidated Financial Statements.

- changed (2023-05-10):
[0000950170-23-020333:note_history:34]
There are currently no accounting pronouncements not yet adopted that are expected to have a material effect on the Condensed Consolidated Financial Statements.
  (was, 2022-11-09, similarity 0.9373):
[0000950170-22-023803:note_history:34]
There are currently no accounting pronouncements not yet adopted that had a material effect on the Condensed Consolidated Financial Statements.

- removed (2023-05-10):
[0000950170-22-023803:note_history:35]
On July 8, 2022, Acorn MergeCo, Inc. (“Merger Sub”), a Delaware corporation and wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (f/k/a Acorn HoldCo, Inc.), merged with and into ADTRAN, Inc., with ADTRAN, Inc. surviving the merger as a wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (the “Merger”). The Merger was consummated pursuant to the Business Combination Agreement, dated as of August 30, 2021 (the “Business Combination Agreement”), by and among ADTRAN Holdings, Inc., ADTRAN, Inc., ADVA Optical Networking SE, a company organized and existing under the laws of Germany (“ADVA”), and Merger Sub. In accordance with the Business Combination Agreement, ADTRAN Holdings, Inc. made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of common stock, par value $0.01 per share (the “Company Common Stock”), of ADTRAN Holdings, Inc. (the “Exchange Offer” and, together with the Merger, the “Business Combination”). On July 15, 2022 (the “Exchange Offer Settlement Date”), ADTRAN Holdings, Inc. completed the Exchange Offer, in which ADTRAN Holdings, Inc. acquired 34.0 million bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 28.0 million shares of Company Common Stock. See Note 2 for additional information.

- removed (2023-05-10):
[0000950170-22-023803:note_history:36]
On October 18, 2022, the Board of Directors of the Company and the management board of ADVA agreed on a final draft of a domination and profit and loss transfer agreement (the “DPLTA”) between the Company, as the controlling company, and ADVA, as the controlled company. The parties’ execution of the DPLTA remains subject to approval of the DPLTA by shareholders of ADVA with 75% of the votes cast in an extraordinary general meeting, which is scheduled to be held on November 30, 2022. If and when signed, effectiveness of the DPLTA is subject to the subsequent registration of the DPLTA with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered offices of ADVA, with such effectiveness to occur no earlier than January 1, 2023. The Company currently holds 33,957,538 shares of ADVA, representing 65.35% of ADVA’s outstanding shares on September 30, 2022. Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to “ADTRAN,” the “Company,” “we,” “us” and “our” refer to ADTRAN, Inc. and its consolidated subsidiaries prior to the Merger on July 8, 2022, and to ADTRAN Holdings, Inc. and its consolidated subsidiaries following the Merger.


## adtn:NotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-10):
[0000950170-23-020333:note_history:37]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | March 31, 2023 |  |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |

- added (2023-05-10):
[0000950170-23-020333:note_history:38]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement note payable. No amounts are available for future borrowings.

- removed (2023-05-10):
[0000950170-22-023803:note_history:39]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | September 30, 2022 |  |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Syndicated credit agreement note payable |  | $ | 29,611 |  |  | $ | 29,782 |  |  | $ | — |  |
| Deutsche Bank term loan |  |  | — |  |  |  | — |  |  |  | — |  |
| Total Notes Payable |  | $ | 29,611 |  |  | $ | 29,782 |  |  | $ | — |  |

- removed (2023-05-10):
[0000950170-22-023803:note_history:40]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. The interest rate for the note payable is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of September 30, 2022. The note payable matures in September 2023.

- removed (2023-05-10):
[0000950170-22-023803:note_history:41]
Deutsche Bank Term Loan

- removed (2023-05-10):
[0000950170-22-023803:note_history:42]
In October 2019, ADVA entered into a $9.8 million revolving line of credit with Deutsche Bank that bears interest of EURIBOR plus 1.1%. The line of credit matured in September 2022 and was repaid as of September 30, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-10):
[0000950170-23-020333:note_history:43]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Wells Fargo credit agreement |  | $ | 180,000 |  |  | $ | 60,000 |  |
| New Nord/LB revolving line of credit |  |  | 10,843 |  |  |  | — |  |
| Nord/LB revolving line of credit |  |  | — |  |  |  | 16,091 |  |
| Syndicated credit agreement working capital line of credit |  |  | — |  |  |  | 10,727 |  |
| DZ bank revolving line of credit |  |  | — |  |  |  | 9,118 |  |
| Total revolving credit agreements |  | $ | 190,843 |  |  | $ | 95,936 |  |

- changed (2023-05-10):
[0000950170-23-020333:note_history:44]
As of March 31, 2023, the weighted average interest rate on our revolving credit agreements was 6.2%.
  (was, 2022-11-09, similarity 0.9418):
[0000950170-22-023803:note_history:44]
As of September 30, 2022, the weighted average interest rate on our revolving credit agreements was 4.05%

- changed (2023-05-10):
[0000950170-23-020333:note_history:45]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100 million in aggregate principal amount, but the borrowings increased to up to $400 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.
  (was, 2022-11-09, similarity 0.6396):
[0000950170-22-023803:note_history:45]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allows for borrowings of up to $100 million in aggregate principal amount, subject to being increased to up to $400 million in aggregate principal amount upon the Company or Borrower’s execution of a DPLTA with ADVA or a parent of ADVA, among other conditions (the “Senior Credit Facilities Increase”). On October 18, 2022, the Board of Directors of the Company. and the management board of ADVA, agreed on a final draft of a DPLTA between the Company, as the controlling company, and ADVA, as the controlled company. See Note 21 of the Notes to Condensed Consolidated Financial Statements for further information.

- changed (2023-05-10):
[0000950170-23-020333:note_history:46]
As of March 31, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $180.0 million in tranches that mature during the second and third quarters of 2023 and can either be repaid or borrowed again for a one month, three month or six month period. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million dollar total facility. As of March 31, 2023, we had a total of $3.4 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $216.6 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.
  (was, 2022-11-09, similarity 0.9625):
[0000950170-22-023803:note_history:46]
As of September 30, 2022, ADTRAN, Inc.’s borrowings under the revolving line of credit were $60.0 million in tranches that mature during the fourth quarter of 2022 and can either be repaid or borrowed again for a one month, three month or six month period. In addition, we may issue up to $25 million in letters of credit against our $100 million dollar total facility. As of September 30, 2022, we had a total of $16.0 million in letters of credit with ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $24.0 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

- changed (2023-05-10):
[0000950170-23-020333:note_history:47]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for SOFR Loans.
  (was, 2022-11-09, similarity 0.9993):
[0000950170-22-023803:note_history:47]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participations in letters of credit at the then applicable rate for SOFR Loans.

- added (2023-05-10):
[0000950170-23-020333:note_history:48]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or

- changed (2023-05-10):
[0000950170-23-020333:note_history:49]
consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the consolidated total net leverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the consolidated interest coverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of March 31, 2023, the Company was in compliance with all material covenants. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions.
  (was, 2022-11-09, similarity 0.7469):
[0000950170-22-023803:note_history:49]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the consolidated total net leverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the consolidated interest coverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of September 30, 2022, the Company was in compliance with all material covenants. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions.

- added (2023-05-10):
[0000950170-23-020333:note_history:50]
New Nord/LB Revolving Line of Credit

- added (2023-05-10):
[0000950170-23-020333:note_history:51]
On March 29, 2023, ADVA entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of March 31, 2023, ADVA borrowed $10.8 million under this facility.

- added (2023-05-10):
[0000950170-23-020333:note_history:52]
On August 8, 2022, ADVA entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and which matures in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit. No amounts are available for future borrowings.

- added (2023-05-10):
[0000950170-23-020333:note_history:53]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement working capital line of credit. No amounts are available for future borrowings.

- added (2023-05-10):
[0000950170-23-020333:note_history:54]
DZ Bank Revolving Line of Credit

- added (2023-05-10):
[0000950170-23-020333:note_history:55]
In the fourth quarter of 2022, ADVA entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings under the DZ Bank revolving line of credit. No amounts are available for future borrowings.

- removed (2023-05-10):
[0000950170-22-023803:note_history:56]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Wells Fargo credit agreement |  | $ | 60,000 |  |  | $ | — |  |
| Nord/LB revolving line of credit |  |  | 14,702 |  |  |  | — |  |
| Syndicated credit agreement working capital line of credit |  |  | 9,801 |  |  |  | — |  |
| Wells Fargo revolving credit agreement |  |  | — |  |  |  | — |  |
| Cadence revolving credit agreement |  |  | — |  |  |  | — |  |
| Total revolving credit agreements |  | $ | 84,503 |  |  | $ | — |  |

- removed (2023-05-10):
[0000950170-22-023803:note_history:57]
August 8, 2022, ADVA entered into a $14.7 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate + 1.4% and which matures in August 2023. During the term of the loan, ADVA is obligated to maintain an adjusted net debt to cover ratio that is equal to or less than 2.75. As of September 30, 2022, The Company was in compliance with the adjusted net debt to cover ratio. The revolving line of credit grants Nord/LB a lien on assets of any kind which come into the possession of ADVA. Assets of any kind includes goods, foreign exchange, securities including interest, annuity and

- removed (2023-05-10):
[0000950170-22-023803:note_history:58]
profit notes, collective securities deposits, subscription rights, checks, bills of exchange, bills of lading, storage and loading slips. As of September 30, 2022, ADVA’s borrowings under the revolving line of credit were $14.7 million, with no amounts available for future borrowings.

- removed (2023-05-10):
[0000950170-22-023803:note_history:59]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $9.8 million as part of a working capital line of credit. The interest rate for the working capital line of credit is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of September 30, 2022. The working capital line of credit matures in September 2023. As of September 30, 2022, borrowings under the working capital line of credit totaled $9.8 million, with no amounts available for future borrowings.

- removed (2023-05-10):
[0000950170-22-023803:note_history:60]
Prior Wells Fargo Revolving Credit Agreement

- removed (2023-05-10):
[0000950170-22-023803:note_history:61]
On April 1, 2022, ADTRAN, Inc. entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Prior Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provided the Company with a $25.0 million secured revolving credit facility. During the first nine months of 2022, the Company made draws totaling $10.0 million under the Prior Wells Revolving Credit Agreement all of which had been repaid as of September 30, 2022. The Wells Fargo Credit Agreement replaced the Prior Wells Fargo Revolving Credit Agreement and all outstanding borrowings have been repaid and the prior agreement was terminated.

- removed (2023-05-10):
[0000950170-22-023803:note_history:62]
Prior Cadence Revolving Credit Agreement

- removed (2023-05-10):
[0000950170-22-023803:note_history:63]
On May 19, 2022, ADTRAN, Inc., as borrower, modified its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The modified Prior Cadence Revolving Credit Agreement provided the Company with a $25.0 million secured revolving credit facility. During the first nine months of 2022, the Company made draws totaling $18.0 million under the Prior Cadence Revolving Credit Agreement all of which had been repaid as of September 30, 2022. The Wells Fargo Credit Agreement replaced the Prior Cadence Revolving Credit Agreement and all outstanding borrowings have been repaid and the prior agreement was terminated.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000950170-23-020333:note_history:64]
|  |  | As of March 31, 2023 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,218 |  |  | $ | 4 |  |  | $ | (63 | ) |  | $ | 2,159 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (4 | ) |  |  | 181 |  |
| Asset-backed bonds |  |  | 734 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 715 |  |
| Mortgage/Agency-backed bonds |  |  | 1,699 |  |  |  | 1 |  |  |  | (82 | ) |  |  | 1,618 |  |
| U.S. government bonds |  |  | 4,299 |  |  |  | 5 |  |  |  | (151 | ) |  |  | 4,153 |  |
| Foreign government bonds |  |  | 406 |  |  |  | — |  |  |  | (19 | ) |  |  | 387 |  |
| Available-for-sale debt securities held at fair value |  | $ | 9,541 |  |  | $ | 11 |  |  | $ | (339 | ) |  | $ | 9,213 |  |
  (was, 2022-11-09, similarity 0.9905):
[0000950170-22-023803:note_history:64]
|  |  | As of December 31, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,776 |  |  | $ | 6 |  |  | $ | (35 | ) |  | $ | 10,747 |  |
| Municipal fixed-rate bonds |  |  | 1,553 |  |  |  | 2 |  |  |  | (4 | ) |  |  | 1,551 |  |
| Asset-backed bonds |  |  | 322 |  |  |  | 3 |  |  |  | (3 | ) |  |  | 322 |  |
| Mortgage/Agency-backed bonds |  |  | 4,754 |  |  |  | 15 |  |  |  | (33 | ) |  |  | 4,736 |  |
| U.S. government bonds |  |  | 12,251 |  |  |  | 12 |  |  |  | (92 | ) |  |  | 12,171 |  |
| Foreign government bonds |  |  | 543 |  |  |  | — |  |  |  | (4 | ) |  |  | 539 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,199 |  |  | $ | 38 |  |  | $ | (171 | ) |  | $ | 30,066 |  |

- changed (2023-05-10):
[0000950170-23-020333:note_history:65]
|  |  | As of December 31, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,538 |  |  | $ | 5 |  |  | $ | (81 | ) |  | $ | 2,462 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (5 | ) |  |  | 180 |  |
| Asset-backed bonds |  |  | 818 |  |  |  | 1 |  |  |  | (24 | ) |  |  | 795 |  |
| Mortgage/Agency-backed bonds |  |  | 1,853 |  |  |  | — |  |  |  | (105 | ) |  |  | 1,748 |  |
| U.S. government bonds |  |  | 3,870 |  |  |  | 3 |  |  |  | (188 | ) |  |  | 3,685 |  |
| Foreign government bonds |  |  | 407 |  |  |  | — |  |  |  | (24 | ) |  |  | 383 |  |
| Available-for-sale debt securities held at fair value |  | $ | 9,671 |  |  | $ | 9 |  |  | $ | (427 | ) |  | $ | 9,253 |  |
  (was, 2022-11-09, similarity 0.7546):
[0000950170-22-023803:note_history:65]
|  |  | As of September 30, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,358 |  |  | $ | — |  |  | $ | (374 | ) |  | $ | 8,984 |  |
| Municipal fixed-rate bonds |  |  | 1,411 |  |  |  | — |  |  |  | (54 | ) |  |  | 1,357 |  |
| Asset-backed bonds |  |  | 2,988 |  |  |  | — |  |  |  | (77 | ) |  |  | 2,911 |  |
| Mortgage/Agency-backed bonds |  |  | 4,720 |  |  |  | — |  |  |  | (280 | ) |  |  | 4,440 |  |
| U.S. government bonds |  |  | 11,231 |  |  |  | — |  |  |  | (642 | ) |  |  | 10,589 |  |
| Foreign government bonds |  |  | 409 |  |  |  | — |  |  |  | (27 | ) |  |  | 382 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,117 |  |  | $ | — |  |  | $ | (1,454 | ) |  | $ | 28,663 |  |

- changed (2023-05-10):
[0000950170-23-020333:note_history:66]
|  |  | As of March 31, 2023 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 369 |  |  | $ | 181 |  |  | $ | — |  |  | $ | — |  |  | $ | 508 |  |  | $ | — |  |  |
| One to two years |  |  | 966 |  |  |  | — |  |  |  | 169 |  |  |  | 166 |  |  |  | 3,174 |  |  |  | 387 |  |  |
| Two to three years |  |  | 824 |  |  |  | — |  |  |  | 49 |  |  |  | 600 |  |  |  | 348 |  |  |  | — |  |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 337 |  |  |  | 242 |  |  |  | 123 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 238 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 160 |  |  |  | 372 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 2,159 |  |  | $ | 181 |  |  | $ | 715 |  |  | $ | 1,618 |  |  | $ | 4,153 |  |  | $ | 387 |  |  |
  (was, 2022-11-09, similarity 0.9249):
[0000950170-22-023803:note_history:66]
|  |  | As of September 30, 2022 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 96 |  |  | $ | 525 |  |  | $ | — |  |  | $ | 182 |  |  | $ | — |  |  | $ | — |  |  |
| One to two years |  |  | 5,371 |  |  |  | 722 |  |  |  | 95 |  |  |  | 464 |  |  |  | 7,421 |  |  |  | 275 |  |  |
| Two to three years |  |  | 3,517 |  |  |  | 110 |  |  |  | 715 |  |  |  | 1,321 |  |  |  | 2,889 |  |  |  | 107 |  |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 1,306 |  |  |  | 166 |  |  |  | 279 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 382 |  |  |  | 810 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 413 |  |  |  | 1,497 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 8,984 |  |  | $ | 1,357 |  |  | $ | 2,911 |  |  | $ | 4,440 |  |  | $ | 10,589 |  |  | $ | 382 |  |  |

- changed (2023-05-10):
[0000950170-23-020333:note_history:67]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Gross realized gain on debt securities |  | $ | 4 |  |  | $ | 12 |  |
| Gross realized loss on debt securities |  |  | (11 | ) |  |  | (40 | ) |
| Total (loss) gain recognized, net |  | $ | (7 | ) |  | $ | (28 | ) |
  (was, 2022-11-09, similarity 0.7677):
[0000950170-22-023803:note_history:67]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Gross realized gain on debt securities |  | $ | 1 |  |  | $ | 22 |  |  | $ | 14 |  |  | $ | 206 |  |
| Gross realized loss on debt securities |  |  | (116 | ) |  |  | (17 | ) |  |  | (242 | ) |  |  | (53 | ) |
| Total (loss) gain recognized, net |  | $ | (115 | ) |  | $ | 5 |  |  | $ | (228 | ) |  | $ | 153 |  |

- changed (2023-05-10):
[0000950170-23-020333:note_history:68]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. No allowance for credit losses was recorded for the three months ended March 31, 2023 and 2022 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2023.
  (was, 2022-11-09, similarity 0.9197):
[0000950170-22-023803:note_history:68]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. No allowance for credit losses was recorded for the nine months ended September 30, 2022 and 2021 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the nine months ended September 30, 2022.

- added (2023-05-10):
[0000950170-23-020333:note_history:69]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Realized (loss) gain on equity securities sold |  | $ | 13 |  |  | $ | (25 | ) |
| Unrealized (loss) gain on equity securities held |  |  | 1,246 |  |  |  | (3,362 | ) |
| Total (loss) gain recognized, net |  | $ | 1,259 |  |  | $ | (3,387 | ) |

- changed (2023-05-10):
[0000950170-23-020333:note_history:70]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| US government securities |  | $ | 175 |  |  | $ | 175 |  |  | $ | — |  |  | $ | — |  |
| Money market funds |  |  | 243 |  |  |  | 243 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 2,159 |  |  |  | — |  |  |  | 2,159 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 181 |  |  |  | — |  |  |  | 181 |  |  |  | — |  |
| Asset-backed bonds |  |  | 715 |  |  |  | — |  |  |  | 715 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,618 |  |  |  | — |  |  |  | 1,618 |  |  |  | — |  |
| U.S. government bonds |  |  | 4,153 |  |  |  | 4,153 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 387 |  |  |  | — |  |  |  | 387 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 821 |  |  |  | 821 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 24,013 |  |  |  | 24,013 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 34,465 |  |  | $ | 29,405 |  |  | $ | 5,060 |  |  | $ | — |  |
  (was, 2022-11-09, similarity 0.7334):
[0000950170-22-023803:note_history:70]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 698 |  |  | $ | 698 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 8,984 |  |  |  | — |  |  |  | 8,984 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,357 |  |  |  | — |  |  |  | 1,357 |  |  |  | — |  |
| Asset-backed bonds |  |  | 2,911 |  |  |  | — |  |  |  | 2,911 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,440 |  |  |  | — |  |  |  | 4,440 |  |  |  | — |  |
| U.S. government bonds |  |  | 10,589 |  |  |  | 10,589 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 382 |  |  |  | — |  |  |  | 382 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 760 |  |  |  | 760 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,511 |  |  |  | 21,511 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 51,632 |  |  | $ | 33,558 |  |  | $ | 18,074 |  |  | $ | — |  |

- removed (2023-05-10):
[0000950170-22-023803:note_history:71]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Realized (loss) gain on equity securities sold |  | $ | (1,358 | ) |  | $ | — |  |  | $ | (1,675 | ) |  | $ | (55 | ) |
| Unrealized (loss) gain on equity securities held |  |  | (1,217 | ) |  |  | (68 | ) |  |  | (8,849 | ) |  |  | 2,844 |  |
| Total (loss) gain recognized, net |  | $ | (2,575 | ) |  | $ | (68 | ) |  | $ | (10,524 | ) |  | $ | 2,789 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-10):
[0000950170-23-020333:note_history:72]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | March 31, 2023 |  |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |

- removed (2023-05-10):
[0000950170-22-023803:note_history:73]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | September 30, 2022 |  |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Syndicated credit agreement note payable |  | $ | 29,611 |  |  | $ | 29,782 |  |  | $ | — |  |
| Deutsche Bank term loan |  |  | — |  |  |  | — |  |  |  | — |  |
| Total Notes Payable |  | $ | 29,611 |  |  | $ | 29,782 |  |  | $ | — |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000950170-23-020333:note_history:74]
The following table disaggregates revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:
  (was, 2022-11-09, similarity 0.9324):
[0000950170-22-023803:note_history:74]
The following tables disaggregate revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

- changed (2023-05-10):
[0000950170-23-020333:note_history:75]
|  |  | Three Months Ended |  |
|  |  | March 31, 2023 |  |  | March 31, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 70,287 |  |  | $ | 9,049 |  |  | $ | 79,336 |  |  | $ | 52,390 |  |  | $ | 4,332 |  |  | $ | 56,722 |  |
| Access & Aggregation Solutions |  |  | 84,554 |  |  |  | 12,266 |  |  |  | 96,820 |  |  |  | 85,984 |  |  |  | 11,812 |  |  |  | 97,796 |  |
| Optical Networking Solutions |  |  | 127,577 |  |  |  | 20,179 |  |  |  | 147,756 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 282,418 |  |  | $ | 41,494 |  |  | $ | 323,912 |  |  | $ | 138,374 |  |  | $ | 16,144 |  |  | $ | 154,518 |  |
  (was, 2022-11-09, similarity 0.9601):
[0000950170-22-023803:note_history:75]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 125,338 |  |  | $ | 8,337 |  |  | $ | 133,675 |  |  | $ | 42,704 |  |  | $ | 4,163 |  |  | $ | 46,867 |  |
| Access & Aggregation Solutions |  |  | 76,591 |  |  |  | 11,598 |  |  |  | 88,189 |  |  |  | 78,063 |  |  |  | 13,151 |  |  |  | 91,214 |  |
| Optical Networking Solutions |  |  | 103,011 |  |  |  | 15,834 |  |  |  | 118,845 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 304,940 |  |  | $ | 35,769 |  |  | $ | 340,709 |  |  | $ | 120,767 |  |  | $ | 17,314 |  |  | $ | 138,081 |  |

- changed (2023-05-10):
[0000950170-23-020333:note_history:76]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Subscriber Solutions |  | $ | 79,336 |  |  | $ | 56,722 |  |
| Access & Aggregation Solutions |  |  | 96,820 |  |  |  | 97,796 |  |
| Optical Networking Solutions |  |  | 147,756 |  |  |  | — |  |
| Total |  | $ | 323,912 |  |  | $ | 154,518 |  |
  (was, 2022-11-09, similarity 0.7666):
[0000950170-22-023803:note_history:76]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Subscriber Solutions |  | $ | 133,675 |  |  | $ | 46,867 |  |  | $ | 270,147 |  |  | $ | 152,489 |  |
| Access & Aggregation Solutions |  |  | 88,189 |  |  |  | 91,214 |  |  |  | 278,273 |  |  |  | 256,357 |  |
| Optical Networking Solutions |  |  | 118,845 |  |  |  | — |  |  |  | 118,845 |  |  |  | — |  |
| Total |  | $ | 340,709 |  |  | $ | 138,081 |  |  | $ | 667,265 |  |  | $ | 408,846 |  |

- removed (2023-05-10):
[0000950170-22-023803:note_history:77]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 252,899 |  |  | $ | 17,248 |  |  | $ | 270,147 |  |  | $ | 140,257 |  |  | $ | 12,232 |  |  | $ | 152,489 |  |
| Access & Aggregation Solutions |  |  | 243,396 |  |  |  | 34,877 |  |  |  | 278,273 |  |  |  | 219,768 |  |  |  | 36,589 |  |  |  | 256,357 |  |
| Optical Networking Solutions |  |  | 103,011 |  |  |  | 15,834 |  |  |  | 118,845 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 599,306 |  |  | $ | 67,959 |  |  | $ | 667,265 |  |  | $ | 360,025 |  |  | $ | 48,821 |  |  | $ | 408,846 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000950170-23-020333:note_history:78]
Network Solutions Segment - Includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.
  (was, 2022-11-09, similarity 0.6667):
[0000950170-22-023803:note_history:78]
Network Solutions Segment - Includes hardware and software products that enable a digital future.

- changed (2023-05-10):
[0000950170-23-020333:note_history:79]
The following table disaggregates revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:
  (was, 2022-11-09, similarity 0.9324):
[0000950170-22-023803:note_history:79]
The following tables disaggregate revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

- changed (2023-05-10):
[0000950170-23-020333:note_history:80]
|  |  | Three Months Ended |  |
|  |  | March 31, 2023 |  |  | March 31, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 70,287 |  |  | $ | 9,049 |  |  | $ | 79,336 |  |  | $ | 52,390 |  |  | $ | 4,332 |  |  | $ | 56,722 |  |
| Access & Aggregation Solutions |  |  | 84,554 |  |  |  | 12,266 |  |  |  | 96,820 |  |  |  | 85,984 |  |  |  | 11,812 |  |  |  | 97,796 |  |
| Optical Networking Solutions |  |  | 127,577 |  |  |  | 20,179 |  |  |  | 147,756 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 282,418 |  |  | $ | 41,494 |  |  | $ | 323,912 |  |  | $ | 138,374 |  |  | $ | 16,144 |  |  | $ | 154,518 |  |
  (was, 2022-11-09, similarity 0.9601):
[0000950170-22-023803:note_history:80]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 125,338 |  |  | $ | 8,337 |  |  | $ | 133,675 |  |  | $ | 42,704 |  |  | $ | 4,163 |  |  | $ | 46,867 |  |
| Access & Aggregation Solutions |  |  | 76,591 |  |  |  | 11,598 |  |  |  | 88,189 |  |  |  | 78,063 |  |  |  | 13,151 |  |  |  | 91,214 |  |
| Optical Networking Solutions |  |  | 103,011 |  |  |  | 15,834 |  |  |  | 118,845 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 304,940 |  |  | $ | 35,769 |  |  | $ | 340,709 |  |  | $ | 120,767 |  |  | $ | 17,314 |  |  | $ | 138,081 |  |

- changed (2023-05-10):
[0000950170-23-020333:note_history:81]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2023 and December 31, 2022 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $389.0 million and $277.2 million, respectively. As of March 31, 2023, approximately 68% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of March 31, 2023 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.
  (was, 2022-11-09, similarity 0.9767):
[0000950170-22-023803:note_history:81]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of September 30, 2022 and December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $276.5 million and $101.1 million, respectively. As of September 30, 2022, approximately 82% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at September 30, 2022 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2023-05-10):
[0000950170-23-020333:note_history:82]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Accounts receivable, net |  | $ | 262,043 |  |  | $ | 279,435 |  |
| Contract assets(1) |  | $ | 1,972 |  |  | $ | 1,852 |  |
| Unearned revenue |  | $ | 55,611 |  |  | $ | 41,193 |  |
| Non-current unearned revenue |  | $ | 24,907 |  |  | $ | 19,239 |  |
  (was, 2022-11-09, similarity 0.9263):
[0000950170-22-023803:note_history:82]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Accounts receivable, net |  | $ | 302,401 |  |  | $ | 158,742 |  |
| Contract assets(1) |  | $ | 1,790 |  |  | $ | 464 |  |
| Unearned revenue |  | $ | 40,993 |  |  | $ | 17,737 |  |
| Non-current unearned revenue |  | $ | 18,269 |  |  | $ | 9,271 |  |

- added (2023-05-10):
[0000950170-23-020333:note_history:83]
The Company is party to a receivables purchase agreement with a third party financial institution (the “Factor”). As of March 31, 2023 and December 31, 2022, accounts receivable totaling $15.6 million and $14.9 million, respectively, were sold, of which $1.2 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of March 31, 2023 and December 31, 2022, the Company had an allowance for doubtful accounts related to factored accounts receivable totaling less than $0.1 million. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months ended March 31, 2023.

- added (2023-05-10):
[0000950170-23-020333:note_history:84]
Of the outstanding unearned revenue balances as of December 31, 2022, $25.6 million was recognized as revenue during the three months ended March 31, 2023. Of the $17.7 million of outstanding unearned revenue balances as of December 31, 2021, $5.4 million was recognized as revenue during the three months ended March 31, 2022.

- changed (2023-05-10):
[0000950170-23-020333:note_history:85]
As of March 31, 2023 and December 31, 2022, the Company’s outstanding accounts receivable balance was $262.0 million and $279.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.
  (was, 2022-11-09, similarity 0.9948):
[0000950170-22-023803:note_history:85]
As of September 30, 2022 and December 31, 2021, the Company’s outstanding accounts receivable balance was $302.4 million, and $158.7 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

- changed (2023-05-10):
[0000950170-23-020333:note_history:86]
The allowance for credit losses was $0.1 million and $49 thousand as of March 31, 2023 and December 31, 2022, respectively, related to accounts receivable.
  (was, 2022-11-09, similarity 0.6412):
[0000950170-22-023803:note_history:86]
No allowance for credit losses was recorded for the year ended September 30, 2022 and December 31, 2021 related to contract assets.

- changed (2023-05-10):
[0000950170-23-020333:note_history:87]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of March 31, 2023 and December 31, 2022, the Company’s outstanding contract asset balance was $2.0 million and $1.9 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.
  (was, 2022-11-09, similarity 0.9959):
[0000950170-22-023803:note_history:87]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of September 30, 2022 and December 31, 2021, the Company’s outstanding contract asset balance was $1.8 million and $0.5 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

- added (2023-05-10):
[0000950170-23-020333:note_history:88]
No allowance for credit losses was recorded for the three months ended March 31, 2023 and 2022 related to contract assets.

- removed (2023-05-10):
[0000950170-22-023803:note_history:89]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 252,899 |  |  | $ | 17,248 |  |  | $ | 270,147 |  |  | $ | 140,257 |  |  | $ | 12,232 |  |  | $ | 152,489 |  |
| Access & Aggregation Solutions |  |  | 243,396 |  |  |  | 34,877 |  |  |  | 278,273 |  |  |  | 219,768 |  |  |  | 36,589 |  |  |  | 256,357 |  |
| Optical Networking Solutions |  |  | 103,011 |  |  |  | 15,834 |  |  |  | 118,845 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 599,306 |  |  | $ | 67,959 |  |  | $ | 667,265 |  |  | $ | 360,025 |  |  | $ | 48,821 |  |  | $ | 408,846 |  |

- removed (2023-05-10):
[0000950170-22-023803:note_history:90]
The Company is party to a receivables purchase agreement with a financial institution (the “Factor”). Pursuant to the terms of the arrangement, the Company, on a revolving basis, sells to the Factor certain of its accounts receivable balances without recourse. On each sale date, the Factor retains from the sale price a default reserve, up to a required balance, which are held by the Factor in a reserve account and pledged to the Company. The Factor is entitled to withdraw from the reserve account the sale price of a defaulted receivable. As of September 30, 2022, accounts receivable totaling $16.1 million were sold, of which $1.3 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of September 30, 2022, the Company has an allowance for doubtful accounts related to factored accounts receivable totaling $0.1 million. As of September 30, 2022, accounts receivables include $31.1 million related to the existing sale of receivables for which the transfer of the receivable has not taken place. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three and nine months ended September 30, 2022.

- removed (2023-05-10):
[0000950170-22-023803:note_history:91]
Of the outstanding unearned revenue balances as of December 31, 2021, $2.8 million and $12.3 million was recognized as revenue during the three and nine months ended September 30, 2022, respectively. Of the $14.1 million of outstanding unearned revenue balances as of December 31, 2020, $2.0 million and $9.8 million was recognized as revenue during the three and nine months ended September 30, 2021, respectively.

- removed (2023-05-10):
[0000950170-22-023803:note_history:92]
The allowance for credit losses was $0.2 million as of September 30, 2022 related to accounts receivable. No allowance for credit losses was recorded as of December 31, 2021 related to accounts receivable.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0000950170-23-020333:note_history:93]
On May 8, 2023, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 23, 2023. The payment date will be June 6, 2023 in the aggregate amount of approximately $7.1 million.
  (was, 2022-11-09, similarity 0.9437):
[0000950170-22-023803:note_history:93]
On November 7, 2022, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 22, 2022. The payment date will be December 6, 2022 in the aggregate amount of approximately $7.0 million.

- added (2023-05-10):
[0000950170-23-020333:note_history:94]
Appointment of Ulrich Dopfer as Principal Accounting Officer

- added (2023-05-10):
[0000950170-23-020333:note_history:95]
As previously disclosed on the Company’s Form 8-K filed on March 30, 2023, Michael Foliano, formerly Senior Vice President of Finance and Chief Financial Officer of the Company, notified the Company of his intent to retire, effective June 28, 2023. Mr. Foliano served in his role as Chief Financial Officer of the Company through April 30, 2023. In connection with his transition, the Board of Directors appointed Ulrich Dopfer as Senior Vice President and Chief Financial Officer of the Company, effective May 1, 2023; however, Mr. Foliano continued to serve as the Company’s “principal accounting officer” within the meaning of the rules of the SEC under the Exchange Act (the “Principal Accounting Officer”), and as the Company’s Treasurer and Secretary. On May 10, 2023, the Board of Directors removed Mr. Foliano from such roles, designated Mr. Dopfer as the Company’s Principal Accounting Officer, and elected Mr. Dopfer as Treasurer and Secretary of the Company, effective as of such date.

- added (2023-05-10):
[0000950170-23-020333:note_history:96]
ADVA Legal Matter

- added (2023-05-10):
[0000950170-23-020333:note_history:97]
On May 8, 2023, ADVA and its U.S. subsidiary, ADVA Optical Networking North America Inc., filed a lawsuit in the U.S District Court for the Eastern District of Texas against Huawei Technologies Co. Ltd (“Huawei”) seeking a declaration from the court that Huawei violated contractual commitments to negotiate in good faith and to license patents, to the extent any patents are practiced by ADVA, on Fair, Reasonable and Non-Discriminatory (“FRAND”) terms and conditions. The case also seeks to obtain a ruling by the court that ADVA has complied with its own commitments and requests that the Court establish FRAND terms and conditions for obtaining a FRAND license on any standard essential patents that ADVA does in fact practice. The lawsuit also seeks to enjoin Huawei from enforcing certain of its patents against ADVA and its affiliates in other jurisdictions, and includes allegations by ADVA that it does not infringe five Huawei patents and that Huawei has infringed an ADVA patent. Huawei has not yet filed an answer in this matter. Given the current status of this matter, the Company is unable predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

- removed (2023-05-10):
[0000950170-22-023803:note_history:98]
Assumed ADVA Options

- removed (2023-05-10):
[0000950170-22-023803:note_history:99]
Pursuant to the Business Combination which closed on July 15, 2022, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings, Inc. The period in which such options could be assumed ended July 22, 2022. However, that period was subsequently extended and a total of 0.1 million shares of ADTRAN Holdings, Inc. stock are subject to additional assumed ADVA options. The fair value of the stock options assumed by ADTRAN Holdings, Inc. will be estimated using a Black-Scholes model. The valuation of this component of consideration is not yet complete.

- removed (2023-05-10):
[0000950170-22-023803:note_history:100]
Approval of Proposed Domination and Profit and Loss Transfer Agreement

- removed (2023-05-10):
[0000950170-22-023803:note_history:101]
On October 18, 2022, the Board of Directors of the Company and the management board of ADVA, agreed on a final draft of a domination and profit and loss transfer agreement (the “DPLTA”) between the Company, as the controlling company, and ADVA, as the controlled company. The parties’ execution of the DPLTA remains subject to the approval of the DPLTA by shareholders of ADVA with 75% of the votes cast in an extraordinary general meeting, which is scheduled to be held on November 30, 2022. The Company currently holds 33,957,538 shares of ADVA, representing 65.35% of ADVA’s outstanding shares as of September 30, 2022.

- removed (2023-05-10):
[0000950170-22-023803:note_history:102]
Subject to the approval of the DPLTA shareholders and the subsequent registration of the DPLTA with the commercial register of the local court at ADVA’s registered offices, the Company will offer, at the election of each shareholder of ADVA (other than the Company), (i) to acquire the shares of such shareholder for a compensation (Abfindung) of EUR 17.21 per share pursuant to Sec. 305 German Stock Corporation Akt (Aktiengesetz, “AktG”), or (ii) to pay such shareholder a fixed annual recurring compensation payment (Ausgleichszahlung) pursuant to Sec. 304 AktG in an amount of EUR 0.59 (EUR 0.52 net under the current taxation regime), subject to adjustment prior to execution of the DPLTA due to changes in interest rates and borrowing costs prior to November 30, 2022, which is the reference date for the valuation of ADVA shares ("Annual Recurring Compensation").

- removed (2023-05-10):
[0000950170-22-023803:note_history:103]
The amount of the Annual Recurring Compensation payment of EUR 0.59 (EUR 0.52 net) is determined on the basis of a rounded annuity interest rate (Verrentungszinssatz) of 3.00% and still subject to an adjustment in case of a change of interest rates and borrowing costs prior to November 30, 2022 which is the reference date for the valuation. An increase of borrowing costs could lead to an increase of the Annual Recurring Compensation payment. The potential increase ranges from EUR 0.62 (EUR 0.54 net), if the annuity interest rate is increased by 25 basis points to 3.25%, up to an Annual Recurring Compensation payment at the amount of EUR 1.00 (EUR 0.87 net), if the annuity interest rate is increased by 250 basis points to 5.50%.

- removed (2023-05-10):
[0000950170-22-023803:note_history:104]
Board Approval Purchase of ADVA Common Stock

- removed (2023-05-10):
[0000950170-22-023803:note_history:105]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of ADVA through open market purchases not to exceed 15,346,544 shares.

- removed (2023-05-10):
[0000950170-22-023803:note_history:106]
Foreign Currency Hedging Agreement

- removed (2023-05-10):
[0000950170-22-023803:note_history:107]
On November 3, 2022, the Company entered into a Euro/U.S. dollar cross-currency swap arrangement (the “Swap”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Swap, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its Euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Swap, the Company will exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of $160.0 million will be divided into eight quarterly tranches of $20.0 million. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Swap may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.
