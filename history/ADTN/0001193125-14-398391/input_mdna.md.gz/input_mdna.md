# ADTN MD&A — 0001193125-14-398391


## mdna

[0001193125-14-398391:mdna:1]
[same as prior period, unchanged from 0001193125-14-297927:mdna:1]

[0001193125-14-398391:mdna:2]
[same as prior period, unchanged from 0001193125-14-297927:mdna:2]

[0001193125-14-398391:mdna:3]
[same as prior period, unchanged from 0001193125-14-297927:mdna:3]

[0001193125-14-398391:mdna:4]
[same as prior period, unchanged from 0001193125-14-297927:mdna:4]

[0001193125-14-398391:mdna:5]
[same as prior period, unchanged from 0001193125-14-297927:mdna:5]

[0001193125-14-398391:mdna:6]
[same as prior period, unchanged from 0001193125-14-297927:mdna:6]

[0001193125-14-398391:mdna:7]
[same as prior period, unchanged from 0001193125-14-297927:mdna:7]

[0001193125-14-398391:mdna:8]
[same as prior period, unchanged from 0001193125-14-297927:mdna:8]

[0001193125-14-398391:mdna:9]
[same as prior period, unchanged from 0001193125-14-297927:mdna:9]

[0001193125-14-398391:mdna:10]
[same as prior period, unchanged from 0001193125-14-297927:mdna:10]

[0001193125-14-398391:mdna:11]
[same as prior period, unchanged from 0001193125-14-297927:mdna:11]

[0001193125-14-398391:mdna:12]
[same as prior period, unchanged from 0001193125-14-297927:mdna:12]

[0001193125-14-398391:mdna:13]
[same as prior period, unchanged from 0001193125-14-297927:mdna:13]

[0001193125-14-398391:mdna:14]
[same as prior period, unchanged from 0001193125-14-297927:mdna:14]

[0001193125-14-398391:mdna:15]
[same as prior period, unchanged from 0001193125-14-297927:mdna:15]

[0001193125-14-398391:mdna:16]
[same as prior period, unchanged from 0001193125-14-297927:mdna:16]

[0001193125-14-398391:mdna:17]
[same as prior period, unchanged from 0001193125-14-297927:mdna:17]

[0001193125-14-398391:mdna:18]
[same as prior period, unchanged from 0001193125-14-297927:mdna:18]

[0001193125-14-398391:mdna:19]
[same as prior period, unchanged from 0001193125-14-297927:mdna:19]

[0001193125-14-398391:mdna:20]
[same as prior period, unchanged from 0001193125-14-297927:mdna:20]

[0001193125-14-398391:mdna:21]
[same as prior period, unchanged from 0001193125-14-297927:mdna:21]

[0001193125-14-398391:mdna:22]
[same as prior period, unchanged from 0001193125-14-297927:mdna:22]

[0001193125-14-398391:mdna:23]
[same as prior period, unchanged from 0001193125-14-297927:mdna:23]

[0001193125-14-398391:mdna:24]
[same as prior period, unchanged from 0001193125-14-297927:mdna:24]

[0001193125-14-398391:mdna:25]
[same as prior period, unchanged from 0001193125-14-297927:mdna:25]

[0001193125-14-398391:mdna:26]
|  | - | Multiservice Routers |

[0001193125-14-398391:mdna:27]
|  | - | Managed Ethernet Switches |

[0001193125-14-398391:mdna:28]
|  | - | IP Business Gateways |

[0001193125-14-398391:mdna:29]
|  | - | Unified Communications (UC) solutions |

[0001193125-14-398391:mdna:30]
|  | - | Carrier Ethernet Network Terminating Equipment (NTE) |

[0001193125-14-398391:mdna:31]
[same as prior period, unchanged from 0001193125-14-297927:mdna:31]

[0001193125-14-398391:mdna:32]
[same as prior period, unchanged from 0001193125-14-297927:mdna:32]

[0001193125-14-398391:mdna:33]
Loop Access products are used by carrier and enterprise customers for
access to copper-based communications networks. This category includes the following product areas and related services:

[0001193125-14-398391:mdna:34]
[same as prior period, unchanged from 0001193125-14-297927:mdna:34]

[0001193125-14-398391:mdna:35]
[same as prior period, unchanged from 0001193125-14-297927:mdna:35]

[0001193125-14-398391:mdna:36]
[same as prior period, unchanged from 0001193125-14-297927:mdna:36]

[0001193125-14-398391:mdna:37]
[same as prior period, unchanged from 0001193125-14-297927:mdna:37]

[0001193125-14-398391:mdna:38]
[same as prior period, unchanged from 0001193125-14-297927:mdna:38]

[0001193125-14-398391:mdna:39]
[same as prior period, unchanged from 0001193125-14-297927:mdna:39]

[0001193125-14-398391:mdna:40]
See Note 11 of Notes to Consolidated Financial Statements in this report for further
information regarding these product categories.

[0001193125-14-398391:mdna:41]
Sales were $162.9 million and $486.0 million for the three and nine months ended September 30, 2014
compared to $177.4 million and $482.7 million for the three and nine months ended September 30, 2013. Product revenues for our three core areas, Broadband Access, Optical and Internetworking, were $148.4 million and $444.8 million for the three
and nine months ended September 30, 2014 compared to $158.1 million and $417.7 million for the three and nine months ended September 30, 2013. Our gross margin increased to 48.0% and 50.0% for the three and nine months ended
September 30, 2014 from 46.5% and 48.1% for the three and nine months ended September 30, 2013. Our operating income margin decreased to 7.7% for the three months ended September 30, 2014 from 9.7% for the three months ended
September 30, 2013, and increased to 8.9% for the nine months ended September 30, 2014 from 7.8% for the nine months ended September 30, 2013. Net income was $11.3 million and $35.3 million for the three and nine months ended
September 30, 2014 compared to $16.2 million and $34.0 million for the three and nine months ended September 30, 2013. Our effective tax rate increased to 24.8% for the three months ended September 30, 2014 from 18.9% for the three
months ended September 30, 2013 and increased to 31.5% for the nine months ended September 30, 2014 from 27.0% for the nine months ended September 30, 2013. Earnings per share, assuming dilution, were $0.21 and $0.63 for the three and
nine months ended September 30, 2014 compared to $0.28 and $0.57 for the three and nine months ended September 30, 2013.

[0001193125-14-398391:mdna:42]
[same as prior period, unchanged from 0001193125-14-297927:mdna:42]

[0001193125-14-398391:mdna:43]
[same as prior period, unchanged from 0001193125-14-297927:mdna:43]

[0001193125-14-398391:mdna:44]
[same as prior period, unchanged from 0001193125-14-297927:mdna:44]

[0001193125-14-398391:mdna:45]
[same as prior period, unchanged from 0001193125-14-297927:mdna:45]

[0001193125-14-398391:mdna:46]
[same as prior period, unchanged from 0001193125-14-297927:mdna:46]

[0001193125-14-398391:mdna:47]
[same as prior period, unchanged from 0001193125-14-297927:mdna:47]

[0001193125-14-398391:mdna:48]
[same as prior period, unchanged from 0001193125-14-297927:mdna:48]

[0001193125-14-398391:mdna:49]
[same as prior period, unchanged from 0001193125-14-297927:mdna:49]

[0001193125-14-398391:mdna:50]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2014 COMPARED TO THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2013

[0001193125-14-398391:mdna:51]
[same as prior period, unchanged from 0001193125-14-297927:mdna:51]

[0001193125-14-398391:mdna:52]
ADTRAN’s sales decreased 8.2% from
$177.4 million in the three months ended September 30, 2013 to $162.9 million in the three months ended September 30, 2014, and increased 0.7% from $482.7 million in the nine months ended September 30, 2013 to $486.0 million in the
nine months ended September 30, 2014. The decrease in sales for the three months ended September 30, 2014 is primarily attributable to a $4.7 million decrease in sales of our Internetworking products, a $3.0 million decrease in sales of
our Optical products, a $2.0 million decrease in sales of our Broadband Access products, and a $4.8 million decrease in sales of our HDSL and other legacy products. The increase in sales for the nine months ended September 30, 2014 is primarily
attributable to a $33.9 million increase in sales of our Broadband Access products, partially offset by a $23.8 million decrease in sales of our HDSL and other legacy products and a $7.6 million decrease in sales of our Internetworking products.

[0001193125-14-398391:mdna:53]
Carrier Networks sales decreased 5.9% from $141.3 million in the three months ended September 30, 2013 to
$133.0 million in the three months ended September 30, 2014, and increased 5.4% from $374.5 million in the nine months ended September 30, 2013 to $394.6 million in the nine months ended September 30, 2014. The decrease in sales for
the three months ended September 30, 2014 is primarily attributable to decreases in sales of our Broadband Access products, Optical products, and HDSL and other legacy products, partially offset by an increase in sales of our Internetworking
products. The decrease in sales of our Broadband Access products for the three months ended September 30, 2014 is primarily attributable to lower international sales, partially offset by an increase in our domestic carrier business. The
decrease in sales of our Optical products for the three months ended September 30, 2014 is primarily attributable to lower international sales, partially offset by higher domestic sales. The decrease in sales of HDSL and other legacy products
for the three months ended September 30, 2014 has been expected as customers continue to upgrade their networks to deliver higher bandwidth services by migrating to newer technologies, including to our core products from our Broadband Access,
Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to decline over time, these revenues may continue for years because of the time required for our customers to transition
to newer technologies. The increase in sales of our Internetworking products for the three months ended September 30, 2014 is primarily attributable to increases in FTTP ONT sales to carriers.

[0001193125-14-398391:mdna:54]
The increase in sales for the nine months ended September 30, 2014 is primarily attributable to increases in sales of our Broadband Access products,
Internetworking products, and Optical products, partially offset by decreases in sales of our HDSL and other legacy products. The increase in sales of our Broadband Access products for the nine months ended September 30, 2014 is primarily
attributable to an increase in hiX product sales. The increase in sales of our Internetworking products for the nine months ended September 30, 2014 is primarily attributable to increases in Carrier Ethernet sales and FTTP ONT sales to
carriers. The increase in sales of our Optical products for the nine months ended September 30, 2014 is primarily attributable to increased sales of Optical products for broadband access and increased sales of our OPTI-6100 products to a
domestic tier 1 carrier for Ethernet services to enterprises and wireless backhaul that occurred during the first quarter. The decrease in sales of HDSL and other legacy products for the nine months ended September 30, 2014 was expected and
discussed further above.

[0001193125-14-398391:mdna:55]
Enterprise Networks sales decreased 17.2% from $36.1 million in the three months ended September 30, 2013 to $29.9 million
in the three months ended September 30, 2014, and decreased 15.5% from $108.2 million in the nine months ended September 30, 2013 to $91.4 million in the nine months ended September 30, 2014. The decrease in sales for the three and
nine months ended September 30, 2014 is primarily attributable to decreases in sales of our Internetworking products and sales of our legacy products. The decrease in sales of our Internetworking products for this division was attributable to
softer demand and an inventory reduction, primarily at two distribution partners. The decrease in legacy products was expected and discussed further above. Internetworking product sales attributable to Enterprise Networks were 93.4% and 94.2% of the
division’s sales in the three and nine months ended September 30, 2014, compared to 93.7% in the three and nine months ended September 30, 2013. Legacy products primarily comprise the remainder of Enterprise Networks sales. Enterprise
Networks sales as a percentage of total sales decreased from 20.4% and 22.4% for the three and nine months ended September 30, 2013 to 18.4% and 18.8% for the three and nine months ended September 30, 2014.

[0001193125-14-398391:mdna:56]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, increased 0.1% from $64.2 million in the
three months ended September 30, 2013 to $64.3 million in the three months ended September 30, 2014, and increased 47.7% from $133.8 million in the nine months ended September 30, 2013 to $197.7 million in the nine months ended
September 30, 2014. International sales, as a percentage of total sales, increased from 36.2% and 27.7% for the three and nine months ended September 30, 2013 to 39.5% and 40.7% for the three and nine months ended September 30, 2014.
International sales increased in the three months ended September 30, 2014 compared to the three months ended September 30, 2013 primarily due to an increase in sales in Latin America, partially offset by a decrease in sales in the
Asia-Pacific region. International sales increased in the nine months ended September 30, 2014 compared to the nine months ended September 30, 2013 primarily due to an increase in hiX product sales in the EMEA region and an increase in
sales in Latin America, partially offset by a decrease in sales in the Asia-Pacific region.

[0001193125-14-398391:mdna:57]
[same as prior period, unchanged from 0001193125-14-297927:mdna:58]

[0001193125-14-398391:mdna:58]
Carrier System product sales decreased $6.8 million in the three months ended September 30, 2014 compared to
the three months ended September 30, 2013, and increased $23.2 million in the nine months ended September 30, 2014 compared to the nine months ended September 30, 2013. The decrease for the three months ended September 30, 2014
is primarily attributable to a $3.0 million decrease in Optical product sales, a $2.0 million decrease in Broadband Access product sales, and a $1.8 million decrease in sales of our legacy products. The increase for the nine months ended
September 30, 2014 is primarily attributable to a $33.9 million increase in Broadband Access product sales, partially offset by an $11.5 million decrease in sales of our legacy products. The changes for the three and nine months ended
September 30, 2014 are primarily attributable to the factors discussed above.

[0001193125-14-398391:mdna:59]
Business Networking product sales decreased $4.5 million and $8.0
million in the three and nine months ended September 30, 2014 compared to the three and nine months ended September 30, 2013. The decrease for the three and nine months ended September 30, 2014 is primarily due to a $4.7 million and a
$7.6 million decrease, respectively, in Internetworking product sales. The decreases for the three and nine months ended September 30, 2014 are primarily attributable to the factors discussed above.

[0001193125-14-398391:mdna:60]
Loop Access product sales decreased $3.2 million and $11.8 million in the three and nine months ended September 30, 2014 compared to the three and nine
months ended September 30, 2013. The decrease for the three and nine months ended September 30, 2014 is primarily due to a $3.1 million and an $11.1 million decrease, respectively, in HDSL product sales, which is discussed further above.

[0001193125-14-398391:mdna:61]
[same as prior period, unchanged from 0001193125-14-297927:mdna:60]

[0001193125-14-398391:mdna:62]
As a percentage of sales, cost
of sales decreased from 53.5% in the three months ended September 30, 2013 to 52.0% in the three months ended September 30, 2014 and decreased from 51.9% in the nine months ended September 30, 2013 to 50.0% in the nine months ended
September 30, 2014. The decrease for the three and nine months ended September 30, 2014 is primarily attributable to improving gross margins in our international business, partially offset by shifts in domestic customer mix and a higher
services mix.

[0001193125-14-398391:mdna:63]
Carrier Networks cost of sales, as a percent of division sales, decreased from 55.4% in the three months ended September 30, 2013 to
53.6% in the three months ended September 30, 2014 and decreased from 53.9% in the nine months ended September 30, 2013 to 51.6% in the nine months ended September 30, 2014. The decrease for the three and nine months ended
September 30, 2014 is primarily attributable to improving gross margins in our international business, partially offset by shifts in domestic customer mix and a higher services mix.

[0001193125-14-398391:mdna:64]
Enterprise Networks cost of sales, as a percent of division sales, decreased from 46.1% in the three months ended September 30, 2013 to 44.6% in the
three months ended September 30, 2014 and decreased from 45.0% in the nine months ended September 30, 2013 to 43.4% in the nine months ended September 30, 2014. The decrease for the three and nine months ended September 30, 2014
is primarily attributable to shifts in customer mix and manufacturing cost reductions.

[0001193125-14-398391:mdna:65]
An important part of our strategy is to reduce the product cost of
each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the
lowering of product selling prices.

[0001193125-14-398391:mdna:66]
[same as prior period, unchanged from 0001193125-14-297927:mdna:65]

[0001193125-14-398391:mdna:67]
Selling, general and administrative expenses decreased 1.1% from $32.8 million in the three months ended September 30, 2013 to $32.4 million in the three
months ended September 30, 2014 and increased 4.2% from $96.1 million in the nine months ended September 30, 2013 to $100.2 million in the nine months ended September 30, 2014. The decrease in selling, general and administrative
expenses for the three months ended September 30, 2014 is primarily attributable to a decrease in compensation expense, partially offset by an increase in travel expenses and marketing expenses. The increase in selling, general and
administrative expenses for the nine months ended September 30, 2014 is primarily attributable to increases in legal expenses, travel expenses and marketing expenses, partially offset by a decrease in compensation expense.

[0001193125-14-398391:mdna:68]
Selling, general and administrative expenses as a percentage of sales increased from 18.5% in the three months
ended September 30, 2013 to 19.9% in the three months ended September 30, 2014 and increased from 19.9% in the nine months ended September 30, 2013 to 20.6% in the nine months ended September 30, 2014. Selling, general and
administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-14-398391:mdna:69]
[same as prior period, unchanged from 0001193125-14-297927:mdna:68]

[0001193125-14-398391:mdna:70]
Research and
development expenses increased 2.4% from $32.5 million in the three months ended September 30, 2013 to $33.3 million in the three months ended September 30, 2014 and increased 1.5% from $98.1 million in the nine months ended
September 30, 2013 to $99.5 million in the nine months ended September 30, 2014. The increase in research and development expenses for the three months ended September 30, 2014 is primarily related to increases in compensation costs
and independent contractor expense. The increase in research and development expenses for the nine months ended September 30, 2014 is primarily related to increases in compensation costs and travel expenses, partially offset by a decrease in
independent contractor expense.

[0001193125-14-398391:mdna:71]
As a percentage of sales, research and development expenses increased from 18.3% in the three months ended
September 30, 2013 to 20.5% in the three months ended September 30, 2014 and increased from 20.3% in the nine months ended September 30, 2013 to 20.5% in the nine months ended September 30, 2014. Research and development expenses
as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-14-398391:mdna:72]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international
markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products and product cost reductions. We may incur
significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-14-398391:mdna:73]
[same as prior period, unchanged from 0001193125-14-297927:mdna:72]

[0001193125-14-398391:mdna:74]
Interest and dividend income decreased 37.2% from $1.6 million in the three months ended September 30, 2013 to $1.0 million in the three
months ended September 30, 2014 and decreased 33.5% from $5.0 million in the nine months ended September 30, 2013 to $3.3 million in the nine months ended September 30, 2014. The decrease in interest and dividend income is primarily
attributable to an $18.3 million reduction of restricted funds that serves as a collateral deposit against our taxable revenue bond during the first quarter and a reduction in the interest rate of that investment from 4.8% to 1.6% (see
“Interest Expense” below for corresponding decrease in the interest rate of our taxable revenue bond). See “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001193125-14-398391:mdna:75]
[same as prior period, unchanged from 0001193125-14-297927:mdna:74]

[0001193125-14-398391:mdna:76]
Interest expense, which is
primarily related to our taxable revenue bond, decreased 74.2% from $0.6 million in the three months ended September 30, 2013 to $0.2 million in the three months ended September 30, 2014 and decreased 69.8% from $1.7 million in the nine
months ended September 30, 2013 to $0.5 million in the nine months ended September 30, 2014. The decrease is primarily attributable to a $16.5 million principal payment made on our taxable revenue bond during the first quarter. In
connection with this payment, we negotiated a reduction in the interest rate of that bond from 5.0% to 2.0%, and, as noted above, a reduction in the interest rate on the collateral supporting the bond. See “Liquidity and Capital Resources”
below for additional information on our revenue bond.

[0001193125-14-398391:mdna:77]
[same as prior period, unchanged from 0001193125-14-297927:mdna:76]

[0001193125-14-398391:mdna:78]
Net realized investment gain increased 53.5% from $1.8 million in the three months ended September 30, 2013 to $2.7 million in the three months ended
September 30, 2014 and increased 3.9% from $6.9 million in the nine months ended September 30, 2013 to $7.2 million in the nine months ended September 30, 2014. The increase in realized investment gains for the three months ended
September 30, 2014 is primarily attributable to higher gains from the sale of equity securities compared to the same period in 2013. The increase in realized investment gains for the nine months ended September 30, 2014 is primarily
attributable to higher gains from the sale of equity securities during 2014. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-14-398391:mdna:79]
[same as prior period, unchanged from 0001193125-14-297927:mdna:78]

[0001193125-14-398391:mdna:80]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management
fees, scrap raw material sales, and gains and losses on the disposal of property, plant and equipment occurring in the normal course of business, changed from $22 thousand of income in the three months ended September 30, 2013 to $1.0 million
of expense in the three months ended September 30, 2014. The change in the three months ended September 30, 2014 is primarily attributable to losses on foreign currency transactions during the third quarter of 2014. Other income (expense)
changed from $1.5 million of expense in the nine months ended September 30, 2013 to $1.6 million of expense in the nine months ended September 30, 2014. The change in the nine months ended September 30, 2014 is primarily attributable
to losses on foreign currency transactions.

[0001193125-14-398391:mdna:81]
[same as prior period, unchanged from 0001193125-14-297927:mdna:80]

[0001193125-14-398391:mdna:82]
Our effective tax rate increased from 27.0% in the nine months ended September 30, 2013 to 31.5% in the nine months ended September 30, 2014. The
increase in the effective tax rate between the two periods is primarily attributable to the net effect of the exclusion of a benefit for the research tax credit, which expired on December 31, 2013, partially offset by the release of a valuation
allowance attributable to a foreign subsidiary in 2014.

[0001193125-14-398391:mdna:83]
[same as prior period, unchanged from 0001193125-14-297927:mdna:82]

[0001193125-14-398391:mdna:84]
As a result of the above factors, net income decreased $4.9 million from $16.2 million in the three months ended September 30, 2013 to $11.3 million in
the three months ended September 30, 2014 and increased $1.4 million from $34.0 million in the nine months ended September 30, 2013 to $35.3 million in the nine months ended September 30, 2014.

[0001193125-14-398391:mdna:85]
As a percentage of sales, net income decreased from 9.1% in the three months ended September 30, 2013 to 7.0% in the three months ended
September 30, 2014 and increased from 7.0% in the nine months ended September 30, 2013 to 7.3% in the nine months ended September 30, 2014.

[0001193125-14-398391:mdna:86]
[same as prior period, unchanged from 0001193125-14-297927:mdna:85]

[0001193125-14-398391:mdna:87]
[same as prior period, unchanged from 0001193125-14-297927:mdna:86]

[0001193125-14-398391:mdna:88]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working
capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and
marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001193125-14-398391:mdna:89]
At September 30, 2014, cash on hand was $58.4 million and short-term investments were $55.6 million, which resulted in available short-term liquidity of
$114.0 million. At December 31, 2013, our cash on hand of $58.3 million and short-term investments of $105.8 million resulted in available short-term liquidity of $164.1 million. The decrease in short-term liquidity from December 31, 2013
to September 30, 2014 primarily reflects funds used for equipment acquisitions, payments on long-term debt, share repurchases and dividends, partially offset by funds provided by our operating activities and stock option exercises by our
employees.

[0001193125-14-398391:mdna:90]
[same as prior period, unchanged from 0001193125-14-297927:mdna:89]

[0001193125-14-398391:mdna:91]
Our working
capital, which consists of current assets less current liabilities, decreased 16.4% from $277.3 million as of December 31, 2013 to $231.8 million as of September 30, 2014. The quick ratio, defined as cash, cash equivalents, short-term
investments, and net accounts receivable, divided by current liabilities, decreased from 2.44 as of December 31, 2013 to 1.82 as of September 30, 2014. The current ratio, defined as current assets divided by current liabilities, decreased
from 3.71 as of December 31, 2013 to 2.98 as of September 30, 2014. The decreases in our working capital, quick ratio and current ratio are primarily attributable to a decrease in short-term investments and an increase in accrued wages and
benefits and income tax payable, partially offset by an increase in accounts receivable and other receivables during the nine months ended September 30, 2014. Short-term investments were used to fund share repurchases during 2014.

[0001193125-14-398391:mdna:92]
Net accounts receivable increased 15.8% from $85.8 million at December 31, 2013 to $99.3 million at
September 30, 2014. Our allowance for doubtful accounts was $130 thousand at December 31, 2013 and $116 thousand at September 30, 2014. Quarterly accounts receivable days sales outstanding (DSO) increased from 50 days as of
December 31, 2013 to 56 days as of September 30, 2014. The change in net accounts receivable and DSO is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have
longer payment terms than U.S. customers. Other receivables increased from $18.2 million at December 31, 2013 to $27.3 million at September 30, 2014. The increase in other receivables is primarily attributable to the timing of filing
returns and collections of VAT receivables in our international subsidiaries. Other receivables will also fluctuate due to the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001193125-14-398391:mdna:93]
Quarterly inventory turnover increased from 3.6 turns as of December 31, 2013 to 3.8 turns as of September 30, 2014. Inventory decreased 3.6% from
December 31, 2013 to September 30, 2014. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing the risk of
inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-14-398391:mdna:94]
Accounts payable increased 3.5% from $48.3 million at
December 31, 2013 to $50.0 million at September 30, 2014. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-14-398391:mdna:95]
[same as prior period, unchanged from 0001193125-14-297927:mdna:94]

[0001193125-14-398391:mdna:96]
Capital expenditures totaled
approximately $8.2 million and $6.1 million for the nine months ended September 30, 2014 and 2013, respectively. These expenditures were primarily used to purchase manufacturing and test equipment and computer software and hardware.

[0001193125-14-398391:mdna:97]
Our combined short-term and long-term investments decreased $60.9 million from $415.0 million at December 31, 2013 to $354.1 million at
September 30, 2014. This decrease reflects the impact of our cash needs for equipment acquisitions, payments on long-term debt, share repurchases, dividends, as well as net realized and unrealized losses and amortization of net premiums on our
combined investments, partially offset by additional funds available for investment provided by our operating activities and stock option exercises by our employees.

[0001193125-14-398391:mdna:98]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At
September 30, 2014 these investments included corporate bonds of $102.5 million, municipal fixed-rate bonds of $150.8 million, and municipal variable rate demand notes of $18.0 million. At December 31, 2013, these investments included
corporate bonds of $166.9 million, municipal fixed-rate bonds of $136.3 million, and municipal variable rate demand notes of $8.3 million. As of September 30, 2014, our corporate bonds, municipal fixed-rate bonds, and municipal variable rate
demand notes were classified as available-for-sale and had a combined duration of 1.0 years with an average credit rating of AA-. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to
obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-14-398391:mdna:99]
Our
long-term investments decreased 3.5% from $309.2 million at December 31, 2013 to $298.5 million at September 30, 2014. Long-term investments at September 30, 2014 and December 31, 2013 included an investment in a certificate of
deposit of $30.0 million and $48.3 million, respectively, which serves as collateral for our revenue bond, as discussed below. We have various equity investments included in long-term investments at a cost of $26.5 million and $24.7 million, and
with a fair value of $35.8 million and $38.5 million, at September 30, 2014 and December 31, 2013, respectively.

[0001193125-14-398391:mdna:100]
Long-term investments at
September 30, 2014 and December 31, 2013 also included $15.5 million and $15.1 million, respectively, related to our deferred compensation plans, and $1.6 million and $1.7 million, respectively, of other investments carried at cost,
consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001193125-14-398391:mdna:101]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such
investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or
adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and nine months ended
September 30, 2014 and 2013, other-than-temporary impairment charges were not significant.

[0001193125-14-398391:mdna:102]
Financing Activities

[0001193125-14-398391:mdna:103]
[same as prior period, unchanged from 0001193125-14-297927:mdna:102]

[0001193125-14-398391:mdna:104]
In July 2003, our Board of Directors elected to
begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the nine months ended September 30, 2014, we paid dividends totaling $15.1 million.

[0001193125-14-398391:mdna:105]
[same as prior period, unchanged from 0001193125-14-297927:mdna:104]

[0001193125-14-398391:mdna:106]
We have amounts outstanding under loans made
pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $30.0 million and $46.5 million at September 30, 2014 and December 31, 2013, respectively. At September 30, 2014, the estimated
fair value of the Bond was approximately $29.8 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in
the amount of $30.0 million and $48.3 million at September 30, 2014 and December 31, 2013, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the
collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic
incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to
pay the interest on the amounts currently outstanding. During the first quarter of 2014, we made a principal payment on the Bond of $16.5 million.

[0001193125-14-398391:mdna:107]
[same as prior period, unchanged from 0001193125-14-297927:mdna:107]

[0001193125-14-398391:mdna:108]
[same as prior period, unchanged from 0001193125-14-297927:mdna:108]

[0001193125-14-398391:mdna:109]
During the nine months ended September 30, 2014, we
repurchased 2.7 million shares of our common stock at an average price of $22.68 per share. We currently have the authority to purchase an additional 5.7 million shares of our common stock under the current plans approved by the Board of
Directors.

[0001193125-14-398391:mdna:110]
[same as prior period, unchanged from 0001193125-14-297927:mdna:110]

[0001193125-14-398391:mdna:111]
To accommodate
employee stock option exercises, we issued 0.1 million shares of treasury stock for $2.3 million during the nine months ended September 30, 2014. During the nine months ended September 30, 2013, we issued 0.1 million shares of
treasury stock for $2.3 million.

[0001193125-14-398391:mdna:112]
[same as prior period, unchanged from 0001193125-14-297927:mdna:112]

[0001193125-14-398391:mdna:113]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or
other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the nine months ended September 30, 2014, the only material change in contractual obligations and
commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2013 filed on February 27, 2014 with the SEC was due to a $16.5 million principal payment on our taxable revenue
bond.

[0001193125-14-398391:mdna:114]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of
September 30, 2014, of which $7.7 million has been applied to these commitments.

[0001193125-14-398391:mdna:115]
[same as prior period, unchanged from 0001193125-14-297927:mdna:115]

[0001193125-14-398391:mdna:116]
[same as prior period, unchanged from 0001193125-14-297927:mdna:116]

[0001193125-14-398391:mdna:117]
[same as prior period, unchanged from 0001193125-14-297927:mdna:117]

[0001193125-14-398391:mdna:118]
[same as prior period, unchanged from 0001193125-14-297927:mdna:118]

[0001193125-14-398391:mdna:119]
[same as prior period, unchanged from 0001193125-14-297927:mdna:119]

[0001193125-14-398391:mdna:120]
[same as prior period, unchanged from 0001193125-14-297927:mdna:120]

[0001193125-14-398391:mdna:121]
[same as prior period, unchanged from 0001193125-14-297927:mdna:121]

[0001193125-14-398391:mdna:122]
[same as prior period, unchanged from 0001193125-14-297927:mdna:122]

[0001193125-14-398391:mdna:123]
[same as prior period, unchanged from 0001193125-14-297927:mdna:123]

[0001193125-14-398391:mdna:124]
[same as prior period, unchanged from 0001193125-14-297927:mdna:124]

[0001193125-14-398391:mdna:125]
[same as prior period, unchanged from 0001193125-14-297927:mdna:125]

[0001193125-14-398391:mdna:126]
[same as prior period, unchanged from 0001193125-14-297927:mdna:126]

[0001193125-14-398391:mdna:127]
[same as prior period, unchanged from 0001193125-14-297927:mdna:127]

[0001193125-14-398391:mdna:128]
[same as prior period, unchanged from 0001193125-14-297927:mdna:128]

[0001193125-14-398391:mdna:129]
[same as prior period, unchanged from 0001193125-14-297927:mdna:129]

[0001193125-14-398391:mdna:130]
[same as prior period, unchanged from 0001193125-14-297927:mdna:130]

[0001193125-14-398391:mdna:131]
[same as prior period, unchanged from 0001193125-14-297927:mdna:131]

[0001193125-14-398391:mdna:132]
[same as prior period, unchanged from 0001193125-14-297927:mdna:132]

[0001193125-14-398391:mdna:133]
[same as prior period, unchanged from 0001193125-14-297927:mdna:133]

[0001193125-14-398391:mdna:134]
[same as prior period, unchanged from 0001193125-14-297927:mdna:134]

[0001193125-14-398391:mdna:135]
[same as prior period, unchanged from 0001193125-14-297927:mdna:135]

[0001193125-14-398391:mdna:136]
[same as prior period, unchanged from 0001193125-14-297927:mdna:136]

[0001193125-14-398391:mdna:137]
[same as prior period, unchanged from 0001193125-14-297927:mdna:137]

[0001193125-14-398391:mdna:138]
[same as prior period, unchanged from 0001193125-14-297927:mdna:152]

[0001193125-14-398391:mdna:139]
[same as prior period, unchanged from 0001193125-14-297927:mdna:138]

[0001193125-14-398391:mdna:140]
[same as prior period, unchanged from 0001193125-14-297927:mdna:139]

[0001193125-14-398391:mdna:141]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-14-398391:mdna:142]
[same as prior period, unchanged from 0001193125-14-297927:mdna:141]

[0001193125-14-398391:mdna:143]
[same as prior period, unchanged from 0001193125-14-297927:mdna:142]

[0001193125-14-398391:mdna:144]
[same as prior period, unchanged from 0001193125-14-297927:mdna:143]

[0001193125-14-398391:mdna:145]
[same as prior period, unchanged from 0001193125-14-297927:mdna:144]

[0001193125-14-398391:mdna:146]
[same as prior period, unchanged from 0001193125-14-297927:mdna:145]

[0001193125-14-398391:mdna:147]
[same as prior period, unchanged from 0001193125-14-297927:mdna:146]

[0001193125-14-398391:mdna:148]
[same as prior period, unchanged from 0001193125-14-297927:mdna:147]

[0001193125-14-398391:mdna:149]
[same as prior period, unchanged from 0001193125-14-297927:mdna:148]

[0001193125-14-398391:mdna:150]
[same as prior period, unchanged from 0001193125-14-297927:mdna:149]

[0001193125-14-398391:mdna:151]
[same as prior period, unchanged from 0001193125-14-297927:mdna:150]

[0001193125-14-398391:mdna:152]
[same as prior period, unchanged from 0001193125-14-297927:mdna:151]
