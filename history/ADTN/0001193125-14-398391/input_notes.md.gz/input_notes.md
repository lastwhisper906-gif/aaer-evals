# ADTN notes — 0001193125-14-398391


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-398391:notes:1]
14. COMMITMENTS AND CONTINGENCIES

[0001193125-14-398391:notes:2]
In the ordinary course of business, we may be subject to various
 legal proceedings and claims, including employment disputes, patent
 claims, disputes over contract agreements and other commercial
 disputes. In some cases, claimants seek damages or other relief,
 such as royalty payments related to patents, which, if granted,
 could require significant expenditures. Although the outcome of any
 claim or litigation can never be certain, it is our opinion that
 the outcome of all contingencies of which we are currently aware
 will not materially affect our business, operations, financial
 condition or cash flows.

[0001193125-14-398391:notes:3]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of September 30, 2014, of which $7.7 million has been applied
 to these commitments.


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-398391:notes:4]
10. EARNINGS PER SHARE

[0001193125-14-398391:notes:5]
A summary of the calculation of basic and diluted earnings per
 share for the three and nine months ended September 30, 2014
 and 2013 is as follows:

[0001193125-14-398391:notes:6]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 11,326 |  |  | $ | 16,205 |  |  | $ | 35,328 |  |  | $ | 33,954 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 54,521 |  |  |  | 57,947 |  |  |  | 55,552 |  |  |  | 59,561 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 266 |  |  |  | 613 |  |  |  | 402 |  |  |  | 321 |  |
| Restricted stock and restricted stock units |  |  | 37 |  |  |  | 57 |  |  |  | 22 |  |  |  | 47 |  |
| Weighted average number of shares – diluted |  |  | 54,824 |  |  |  | 58,617 |  |  |  | 55,976 |  |  |  | 59,929 |  |
| Net income per share – basic |  | $ | 0.21 |  |  | $ | 0.28 |  |  | $ | 0.64 |  |  | $ | 0.57 |  |
| Net income per share – diluted |  | $ | 0.21 |  |  | $ | 0.28 |  |  | $ | 0.63 |  |  | $ | 0.57 |  |

[0001193125-14-398391:notes:7]
Anti-dilutive options to purchase common stock outstanding were
 excluded from the above calculations. Anti-dilutive options totaled
 4.5 million and 2.5 million for the three months ended
 September 30, 2014 and 2013, respectively, and
 3.1 million and 3.3 million for the nine months ended
 September 30, 2014 and 2013, respectively.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001193125-14-398391:notes:8]
We evaluate the carrying value of goodwill, generated from our
 acquisition of Bluesocket, Inc. and assigned to our Enterprise
 Networks division, during the fourth quarter of each year. We may
 perform additional evaluations if events occur or circumstances
 change that would more likely than not reduce the fair value of the
 reporting unit below its carrying amount. When evaluating whether
 goodwill is impaired, we compare the fair value of the reporting
 unit to which the goodwill is assigned to the reporting
 unit’s carrying amount, including goodwill. If the carrying
 amount of the reporting unit exceeds its fair value, then the
 amount of the impairment loss is measured. There have been no
 impairment losses recorded since acquisition.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001193125-14-398391:notes:9]
The weighted-average assumptions and value of options granted for
 the nine months ended September 30, 2014 are summarized as
 follows:

[0001193125-14-398391:notes:10]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2014 |  |
| Expected volatility |  |  | 39.57 | % |
| Risk-free interest rate |  |  | 1.86 | % |
| Expected dividend yield |  |  | 1.38 | % |
| Expected life (in years) |  |  | 6.25 |  |
| Weighted-average estimated value |  | $ | 9.28 |  |


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001193125-14-398391:notes:11]
[same as prior period, unchanged from 0001193125-14-297927:notes:11]

[0001193125-14-398391:notes:12]
[same as prior period, unchanged from 0001193125-14-297927:notes:12]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-14-398391:notes:13]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1 - Values based on unadjusted quoted prices for
 identical assets or liabilities in an active market; Level 2 -
 Values based on quoted prices in markets that are not active or
 model inputs that are observable either directly or indirectly;
 Level 3 - Values based on prices or valuation techniques that
 require inputs that are both unobservable and significant to the
 overall fair value measurement. These inputs include information
 supplied by investees.

[0001193125-14-398391:notes:14]
|  |  | Fair Value Measurements at September 30, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 9,861 |  |  | $ | 9,861 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,498 |  |  |  | 15,498 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 102,520 |  |  |  | — |  |  |  | 102,520 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 150,773 |  |  |  | — |  |  |  | 150,773 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 18,000 |  |  |  | — |  |  |  | 18,000 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 8,879 |  |  |  | 8,879 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 26,902 |  |  |  | 26,902 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 322,572 |  |  |  | 51,279 |  |  |  | 271,293 |  |  |  | — |  |
| Total |  | $ | 332,433 |  |  | $ | 61,140 |  |  | $ | 271,293 |  |  | $ | — |  |

[0001193125-14-398391:notes:15]
[same as prior period, unchanged from 0001193125-14-297927:notes:15]


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-14-398391:notes:16]
At September 30, 2014, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-14-398391:notes:17]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 12,852 |  |  | $ | 2,660 |  |  | $ | (14 | ) |  | $ | 15,498 |  |
| Corporate bonds |  |  | 102,196 |  |  |  | 345 |  |  |  | (21 | ) |  |  | 102,520 |  |
| Municipal fixed-rate bonds |  |  | 150,098 |  |  |  | 691 |  |  |  | (16 | ) |  |  | 150,773 |  |
| Municipal variable rate demand notes |  |  | 18,000 |  |  |  | — |  |  |  | — |  |  |  | 18,000 |  |
| Marketable equity securities |  |  | 26,542 |  |  |  | 9,996 |  |  |  | (757 | ) |  |  | 35,781 |  |
| Available-for-sale securities held at fair value |  | $ | 309,688 |  |  | $ | 13,692 |  |  | $ | (808 | ) |  | $ | 322,572 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,557 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 354,129 |  |

[0001193125-14-398391:notes:18]
[same as prior period, unchanged from 0001193125-14-297927:notes:18]

[0001193125-14-398391:notes:19]
[same as prior period, unchanged from 0001193125-14-297927:notes:19]


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-14-398391:notes:20]
The fair values of our derivative instruments recorded in the
 Consolidated Balance Sheet as of September 30, 2014 and
 December 31, 2013 were as follows:

[0001193125-14-398391:notes:21]
|  |  | Balance Sheet |  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | Location |  |  | 2014 |  |  | 2013 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  |  | Other receivables |  |  | $ | 99 |  |  | $ | 18 |  |
| Foreign exchange contracts – liability derivatives |  |  | Accounts payable |  |  | $ | (22 | ) |  | $ | (15 | ) |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-398391:notes:22]
At September 30, 2014 and December 31, 2013, inventory
 consisted of the following:

[0001193125-14-398391:notes:23]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Raw materials |  | $ | 37,856 |  |  | $ | 44,093 |  |
| Work in process |  |  | 3,920 |  |  |  | 3,484 |  |
| Finished goods |  |  | 45,103 |  |  |  | 42,534 |  |
| Total |  | $ | 86,879 |  |  | $ | 90,111 |  |


## us-gaap:ScheduleOfRealizedGainLossTableTextBlock

[0001193125-14-398391:notes:24]
[same as prior period, unchanged from 0001193125-14-297927:notes:24]

[0001193125-14-398391:notes:25]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Gross realized gains |  | $ | 2,728 |  |  | $ | 1,797 |  |  | $ | 7,363 |  |  | $ | 7,252 |  |
| Gross realized losses |  | $ | (41 | ) |  | $ | (46 | ) |  | $ | (144 | ) |  | $ | (303 | ) |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-14-398391:notes:26]
The following table is a summary of our stock options outstanding
 as of December 31, 2013 and September 30, 2014 and the
 changes that occurred during the nine months ended
 September 30, 2014:

[0001193125-14-398391:notes:27]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2013 |  |  | 6,358 |  |  | $ | 24.43 |  |  |  | 6.60 |  |  | $ | 25,878 |  |
| Options granted |  |  | 2 |  |  | $ | 26.03 |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (203 | ) |  | $ | 25.86 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (117 | ) |  | $ | 19.66 |  |  |  |  |  |  |  |  |  |
| Options outstanding, September 30, 2014 |  |  | 6,040 |  |  | $ | 24.47 |  |  |  | 5.85 |  |  | $ | 5,699 |  |
| Options exercisable, September 30, 2014 |  |  | 3,961 |  |  | $ | 25.14 |  |  |  | 4.59 |  |  | $ | 3,295 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-398391:notes:28]
11. SEGMENT INFORMATION

[0001193125-14-398391:notes:29]
[same as prior period, unchanged from 0001193125-14-297927:notes:29]

[0001193125-14-398391:notes:30]
The following tables present information about the reported sales
 and gross profit of our reportable segments for the three and nine
 months ended September 30, 2014 and 2013. Asset information by
 reportable segment is not reported, since we do not produce such
 information internally.

[0001193125-14-398391:notes:31]
|  |  | Three Months Ended |  |
|  |  | September 30, 2014 |  |  | September 30, 2013 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 132,972 |  |  | $ | 61,687 |  |  | $ | 141,278 |  |  | $ | 63,066 |  |
| Enterprise Networks |  |  | 29,920 |  |  |  | 16,570 |  |  |  | 36,126 |  |  |  | 19,481 |  |
| Total |  | $ | 162,892 |  |  | $ | 78,257 |  |  | $ | 177,404 |  |  | $ | 82,547 |  |

[0001193125-14-398391:notes:32]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2014 |  |  | September 30, 2013 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 394,589 |  |  | $ | 191,093 |  |  | $ | 374,498 |  |  | $ | 172,570 |  |
| Enterprise Networks |  |  | 91,436 |  |  |  | 51,751 |  |  |  | 108,152 |  |  |  | 59,452 |  |
| Total |  | $ | 486,025 |  |  | $ | 242,844 |  |  | $ | 482,650 |  |  | $ | 232,022 |  |

[0001193125-14-398391:notes:33]
[same as prior period, unchanged from 0001193125-14-297927:notes:33]

[0001193125-14-398391:notes:34]
[same as prior period, unchanged from 0001193125-14-297927:notes:34]

[0001193125-14-398391:notes:35]
Carrier Systems products are used by communications service
 providers to provide data, voice and video services to consumers
 and enterprises. This category includes the following product areas
 and related services:

[0001193125-14-398391:notes:36]
[same as prior period, unchanged from 0001193125-14-297927:notes:36]

[0001193125-14-398391:notes:37]
[same as prior period, unchanged from 0001193125-14-297927:notes:37]

[0001193125-14-398391:notes:38]
[same as prior period, unchanged from 0001193125-14-297927:notes:38]

[0001193125-14-398391:notes:39]
[same as prior period, unchanged from 0001193125-14-297927:notes:39]

[0001193125-14-398391:notes:40]
[same as prior period, unchanged from 0001193125-14-297927:notes:40]

[0001193125-14-398391:notes:41]
[same as prior period, unchanged from 0001193125-14-297927:notes:41]

[0001193125-14-398391:notes:42]
[same as prior period, unchanged from 0001193125-14-297927:notes:42]

[0001193125-14-398391:notes:43]
[same as prior period, unchanged from 0001193125-14-297927:notes:43]

[0001193125-14-398391:notes:44]
[same as prior period, unchanged from 0001193125-14-297927:notes:44]

[0001193125-14-398391:notes:45]
[same as prior period, unchanged from 0001193125-14-297927:notes:45]

[0001193125-14-398391:notes:46]
[same as prior period, unchanged from 0001193125-14-297927:notes:46]

[0001193125-14-398391:notes:47]
[same as prior period, unchanged from 0001193125-14-297927:notes:47]

[0001193125-14-398391:notes:48]
Business Networking products provide access to communication
 services and facilitate the delivery of cloud connectivity and
 enterprise communications to distributed enterprises and small and
 medium-sized businesses. This category includes the following
 product areas and related services:

[0001193125-14-398391:notes:49]
[same as prior period, unchanged from 0001193125-14-297927:notes:49]

[0001193125-14-398391:notes:50]
[same as prior period, unchanged from 0001193125-14-297927:notes:50]

[0001193125-14-398391:notes:51]
[same as prior period, unchanged from 0001193125-14-297927:notes:51]

[0001193125-14-398391:notes:52]
[same as prior period, unchanged from 0001193125-14-297927:notes:52]

[0001193125-14-398391:notes:53]
[same as prior period, unchanged from 0001193125-14-297927:notes:53]

[0001193125-14-398391:notes:54]
|  | - | Multiservice Routers |

[0001193125-14-398391:notes:55]
|  | - | Managed Ethernet Switches |

[0001193125-14-398391:notes:56]
|  | - | IP Business Gateways |

[0001193125-14-398391:notes:57]
|  | - | Unified Communications (UC) solutions |

[0001193125-14-398391:notes:58]
|  | - | Carrier Ethernet Network Terminating Equipment (NTE) |

[0001193125-14-398391:notes:59]
[same as prior period, unchanged from 0001193125-14-297927:notes:59]

[0001193125-14-398391:notes:60]
[same as prior period, unchanged from 0001193125-14-297927:notes:60]

[0001193125-14-398391:notes:61]
Loop Access products are used by carrier and enterprise
 customers for access to copper-based communications networks. This
 category includes the following product areas and related
 services:

[0001193125-14-398391:notes:62]
[same as prior period, unchanged from 0001193125-14-297927:notes:62]

[0001193125-14-398391:notes:63]
[same as prior period, unchanged from 0001193125-14-297927:notes:63]

[0001193125-14-398391:notes:64]
[same as prior period, unchanged from 0001193125-14-297927:notes:64]

[0001193125-14-398391:notes:65]
[same as prior period, unchanged from 0001193125-14-297927:notes:65]

[0001193125-14-398391:notes:66]
[same as prior period, unchanged from 0001193125-14-297927:notes:66]

[0001193125-14-398391:notes:67]
The table below presents sales information by product category for
 the three and nine months ended September 30, 2014 and
 2013:

[0001193125-14-398391:notes:68]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Carrier Systems |  | $ | 113,950 |  |  | $ | 120,778 |  |  | $ | 342,327 |  |  | $ | 319,119 |  |
| Business Networking |  |  | 39,746 |  |  |  | 44,213 |  |  |  | 119,634 |  |  |  | 127,668 |  |
| Loop Access |  |  | 9,196 |  |  |  | 12,413 |  |  |  | 24,064 |  |  |  | 35,863 |  |
| Total |  | $ | 162,892 |  |  | $ | 177,404 |  |  | $ | 486,025 |  |  | $ | 482,650 |  |

[0001193125-14-398391:notes:69]
[same as prior period, unchanged from 0001193125-14-297927:notes:69]

[0001193125-14-398391:notes:70]
The table below presents subcategory revenues for the three and
 nine months ended September 30, 2014 and 2013:

[0001193125-14-398391:notes:71]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 96,084 |  |  | $ | 98,132 |  |  | $ | 285,920 |  |  | $ | 251,994 |  |
| Optical (included in Carrier Systems) |  |  | 13,686 |  |  |  | 16,640 |  |  |  | 42,308 |  |  |  | 41,500 |  |
| Internetworking (included in Business Networking) |  |  | 38,630 |  |  |  | 43,329 |  |  |  | 116,562 |  |  |  | 124,163 |  |
| Subtotal |  |  | 148,400 |  |  |  | 158,101 |  |  |  | 444,790 |  |  |  | 417,657 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 8,400 |  |  |  | 11,487 |  |  |  | 22,075 |  |  |  | 33,183 |  |
| Other products (excluding HDSL) |  |  | 6,092 |  |  |  | 7,816 |  |  |  | 19,160 |  |  |  | 31,810 |  |
| Subtotal |  |  | 14,492 |  |  |  | 19,303 |  |  |  | 41,235 |  |  |  | 64,993 |  |
| Total |  | $ | 162,892 |  |  | $ | 177,404 |  |  | $ | 486,025 |  |  | $ | 482,650 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-14-398391:notes:72]
7. INVENTORY

[0001193125-14-398391:notes:73]
We establish reserves for estimated excess, obsolete, or
 unmarketable inventory equal to the difference between the cost of
 the inventory and the estimated fair value of the inventory based
 upon assumptions about future demand and market conditions. At
 September 30, 2014 and December 31, 2013, raw materials
 reserves totaled $17.1 million and $16.9 million, respectively, and
 finished goods inventory reserves totaled $6.3 million and $6.1
 million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-14-398391:notes:74]
13. RELATED PARTY TRANSACTIONS

[0001193125-14-398391:notes:75]
We employ the law firm of our director emeritus for legal services.
 All bills for services rendered by this firm are reviewed and
 approved by our Chief Financial Officer. We believe that the fees
 for such services are comparable to those charged by other firms
 for services rendered to us. The services of our director emeritus
 ended with his death on September 7, 2014. We incurred fees of
 $10 thousand and $30 thousand for the three months ended
 September 30, 2014 and 2013, respectively, and $70 thousand
 and $90 thousand for the nine months ended September 30, 2014
 and 2013, respectively, for these legal services.


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-14-398391:notes:76]
The following table summarizes the stock-based compensation expense
 related to stock options, restricted stock units (RSUs) and
 restricted stock for the three and nine months ended
 September 30, 2014 and 2013, which was recognized as
 follows:

[0001193125-14-398391:notes:77]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 124 |  |  | $ | 118 |  |  | $ | 359 |  |  | $ | 334 |  |
| Selling, general and administrative expense |  |  | 1,048 |  |  |  | 1,024 |  |  |  | 3,089 |  |  |  | 3,129 |  |
| Research and development expense |  |  | 975 |  |  |  | 1,034 |  |  |  | 2,848 |  |  |  | 3,053 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,023 |  |  |  | 2,058 |  |  |  | 5,937 |  |  |  | 6,182 |  |
| Total stock-based compensation expense |  |  | 2,147 |  |  |  | 2,176 |  |  |  | 6,296 |  |  |  | 6,516 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (298 | ) |  |  | (307 | ) |  |  | (878 | ) |  |  | (924 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,849 |  |  | $ | 1,869 |  |  | $ | 5,418 |  |  | $ | 5,592 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-14-398391:notes:78]
As of September 30, 2014, the estimated future amortization
 expense of our intangible assets is as follows:

[0001193125-14-398391:notes:79]
| (In thousands) |  | Amount |  |
| Remainder of 2014 |  | $ | 548 |  |
| 2015 |  |  | 2,071 |  |
| 2016 |  |  | 1,800 |  |
| 2017 |  |  | 1,235 |  |
| 2018 |  |  | 748 |  |
| Thereafter |  |  | 1,840 |  |
| Total |  | $ | 8,242 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-14-398391:notes:80]
A summary of the changes in stockholders’ equity for the nine
 months ended September 30, 2014 is as follows:

[0001193125-14-398391:notes:81]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2013 |  | $ | 604,606 |  |
| Net income |  |  | 35,328 |  |
| Dividend payments |  |  | (15,060 | ) |
| Dividends accrued for unvested restricted stock units |  |  | 1 |  |
| Net unrealized gains (losses) on available-for-sale securities (net of tax) |  |  | (2,850 | ) |
| Foreign currency translation adjustment |  |  | (2,182 | ) |
| Proceeds from stock option exercises |  |  | 2,311 |  |
| Purchase of treasury stock |  |  | (62,144 | ) |
| Income tax benefit from exercise of stock options |  |  | 71 |  |
| Stock-based compensation expense |  |  | 6,296 |  |
| Balance, September 30, 2014 |  | $ | 566,377 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-14-398391:notes:82]
8. GOODWILL AND INTANGIBLE ASSETS

[0001193125-14-398391:notes:83]
Intangible assets are included in other assets in the accompanying
 Consolidated Balance Sheets and include intangibles acquired in
 conjunction with our acquisitions of Objectworld Communications
 Corporation on September 15, 2009, Bluesocket, Inc. on
 August 4, 2011, and the NSN BBA business on May 4,
 2012.

[0001193125-14-398391:notes:84]
The following table presents our intangible assets as of
 September 30, 2014 and December 31, 2013:

[0001193125-14-398391:notes:85]
| (In thousands) |  | September 30, 2014 |  |  | December 31, 2013 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,515 |  |  | $ | (2,013 | ) |  | $ | 4,502 |  |  | $ | 6,996 |  |  | $ | (1,555 | ) |  | $ | 5,441 |  |
| Developed technology |  |  | 6,127 |  |  |  | (3,374 | ) |  |  | 2,753 |  |  |  | 6,537 |  |  |  | (2,692 | ) |  |  | 3,845 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,436 | ) |  |  | 904 |  |  |  | 2,340 |  |  |  | (1,185 | ) |  |  | 1,155 |  |
| Trade names |  |  | 270 |  |  |  | (190 | ) |  |  | 80 |  |  |  | 270 |  |  |  | (145 | ) |  |  | 125 |  |
| Other |  |  | 13 |  |  |  | (10 | ) |  |  | 3 |  |  |  | 14 |  |  |  | (8 | ) |  |  | 6 |  |
| Total |  | $ | 15,265 |  |  | $ | (7,023 | ) |  | $ | 8,242 |  |  | $ | 16,157 |  |  | $ | (5,585 | ) |  | $ | 10,572 |  |

[0001193125-14-398391:notes:86]
Amortization expense, all of which relates to business
 acquisitions, was $0.6 million for the three months ended
 September 30, 2014 and 2013, and $1.7 million and $1.8 million
 for the nine months ended September 30, 2014 and 2013,
 respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-398391:notes:87]
6. DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001193125-14-398391:notes:88]
We have certain customers and suppliers who are invoiced or pay in
 a non-functional currency. Changes in the monetary exchange rates
 may adversely affect our results of operations and financial
 condition. When appropriate, we enter into various derivative
 transactions to enhance our ability to manage the volatility
 relating to these typical business exposures. We do not hold or
 issue derivative instruments for trading or other speculative
 purposes. Our derivative instruments are recorded in the
 Consolidated Balance Sheets at their fair values. Our derivative
 instruments do not qualify for hedge accounting, and accordingly,
 all changes in the fair value of the instruments are recognized as
 other income (expense) in the Consolidated Statements of Income.
 The maximum contractual period for our derivatives is currently
 less than twelve months. Our derivative instruments are not subject
 to master netting arrangements and are not offset in the
 Consolidated Balance Sheets.

[0001193125-14-398391:notes:89]
As of September 30, 2014, we had forward contracts outstanding
 with notional amounts totaling €20.1 million ($25.4
 million), which mature through 2014.

[0001193125-14-398391:notes:90]
The change in the fair values of our derivative instruments
 recorded in the Consolidated Statements of Income during the three
 and nine months ended September 30, 2014 were as follows:

[0001193125-14-398391:notes:91]
|  |  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Income Statement |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | Location |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | (191 | ) |  | $ | 52 |  |  | $ | (739 | ) |  | $ | (34 | ) |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-14-398391:notes:92]
5. INVESTMENTS

[0001193125-14-398391:notes:93]
As of September 30, 2014, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

[0001193125-14-398391:notes:94]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 4,643 |  |  | $ | 31,631 |  |
| One to two years |  |  | 64,168 |  |  |  | 69,253 |  |
| Two to three years |  |  | 33,709 |  |  |  | 39,809 |  |
| Three to five years |  |  | — |  |  |  | 10,080 |  |
| Total |  | $ | 102,520 |  |  | $ | 150,773 |  |

[0001193125-14-398391:notes:95]
Actual maturities may differ from contractual maturities because
 some borrowers have the right to call or prepay obligations with or
 without call or prepayment penalties.

[0001193125-14-398391:notes:96]
Our investment policy provides limitations for issuer
 concentration, which limits, at the time of purchase, the
 concentration in any one issuer to 5% of the market value of our
 total investment portfolio.

[0001193125-14-398391:notes:97]
At September 30, 2014, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). During
 the first quarter of 2014, we made a principal payment on the Bond
 of $16.5 million. At September 30, 2014, the estimated fair
 value of the Bond using a level 2 valuation technique was
 approximately $29.8 million, based on a debt security with a
 comparable interest rate and maturity and a Standard and
 Poor’s credit rating of AAA. For more information on the
 Bond, see “Debt” under “Liquidity and Capital
 Resources” in the “Management’s Discussion and
 Analysis of Financial Condition and Results of Operations”
 contained in Item 2 of Part I of this report.

[0001193125-14-398391:notes:98]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and nine months
 ended September 30, 2014 and 2013, other-than-temporary
 impairment charges were not significant.

[0001193125-14-398391:notes:99]
Realized gains and losses on sales of securities are computed under
 the specific identification method. The following table presents
 gross realized gains and losses related to our investments.

[0001193125-14-398391:notes:100]
As of September 30, 2014 and 2013, gross unrealized losses
 related to individual securities in a continuous loss position for
 12 months or longer were not significant.

[0001193125-14-398391:notes:101]
The fair value of our Level 2 securities is calculated using a
 weighted average market price for each security. Market prices are
 obtained from a variety of industry standard data providers,
 security master files from large financial institutions, and other
 third-party sources. These multiple market prices are used as
 inputs into a distribution-curve-based algorithm to determine the
 daily market value of each security.

[0001193125-14-398391:notes:102]
Our municipal variable rate demand notes have a structure that
 implies a standard expected market price. The frequent interest
 rate resets make it reasonable to expect the price to stay at par.
 These securities are priced at the expected market price.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-398391:notes:103]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the three months
 ended September 30, 2014 and 2013:

[0001193125-14-398391:notes:104]
|  |  | Three Months Ended September 30, 2014 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 11,035 |  |  | $ | (891 | ) |  | $ | 1,293 |  |  | $ | 11,437 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (1,602 | ) |  |  | — |  |  |  | (2,568 | ) |  |  | (4,170 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,546 | ) |  |  | — |  |  |  | — |  |  |  | (1,546 | ) |
| Net current period other comprehensive income(loss) |  |  | (3,148 | ) |  |  | — |  |  |  | (2,568 | ) |  |  | (5,716 | ) |
| Ending balance |  | $ | 7,887 |  |  | $ | (891 | ) |  | $ | (1,275 | ) |  | $ | 5,721 |  |

[0001193125-14-398391:notes:105]
|  |  | Three Months Ended September 30, 2013 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 6,766 |  |  | $ | (1,952 | ) |  | $ | 1,722 |  |  | $ | 6,536 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 3,522 |  |  |  | — |  |  |  | (108 | ) |  |  | 3,414 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (960 | ) |  |  | — |  |  |  | — |  |  |  | (960 | ) |
| Net current period other comprehensive income(loss) |  |  | 2,562 |  |  |  | — |  |  |  | (108 | ) |  |  | 2,454 |  |
| Ending balance |  | $ | 9,328 |  |  | $ | (1,952 | ) |  | $ | 1,614 |  |  | $ | 8,990 |  |

[0001193125-14-398391:notes:106]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the nine months
 ended September 30, 2014 and 2013:

[0001193125-14-398391:notes:107]
|  |  | Nine Months Ended September 30, 2014 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,737 |  |  | $ | (891 | ) |  | $ | 907 |  |  | $ | 10,753 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 1,316 |  |  |  | — |  |  |  | (2,182 | ) |  |  | (866 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (4,166 | ) |  |  | — |  |  |  | — |  |  |  | (4,166 | ) |
| Net current period other comprehensive income(loss) |  |  | (2,850 | ) |  |  | — |  |  |  | (2,182 | ) |  |  | (5,032 | ) |
| Ending balance |  | $ | 7,887 |  |  | $ | (891 | ) |  | $ | (1,275 | ) |  | $ | 5,721 |  |
|  |  | Nine Months Ended September 30, 2013 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,108 |  |  | $ | (1,952 | ) |  | $ | 3,112 |  |  | $ | 11,268 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 3,174 |  |  |  | — |  |  |  | (1,498 | ) |  |  | 1,676 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (3,954 | ) |  |  | — |  |  |  | — |  |  |  | (3,954 | ) |
| Net current period other comprehensive income(loss) |  |  | (780 | ) |  |  | — |  |  |  | (1,498 | ) |  |  | (2,278 | ) |
| Ending balance |  | $ | 9,328 |  |  | $ | (1,952 | ) |  | $ | 1,614 |  |  | $ | 8,990 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-14-398391:notes:108]
9. STOCKHOLDERS’ EQUITY

[0001193125-14-398391:notes:109]
[same as prior period, unchanged from 0001193125-14-297927:notes:117]

[0001193125-14-398391:notes:110]
[same as prior period, unchanged from 0001193125-14-297927:notes:118]

[0001193125-14-398391:notes:111]
During the nine months ended September 30, 2014, we
 repurchased 2.7 million shares of our common stock at an
 average price of $22.68 per share. We currently have the authority
 to purchase an additional 5.7 million shares of our common
 stock under the current plans approved by the Board of
 Directors.

[0001193125-14-398391:notes:112]
[same as prior period, unchanged from 0001193125-14-297927:notes:120]

[0001193125-14-398391:notes:113]
We issued 0.1 million shares of treasury stock during the nine
 months ended September 30, 2014 to accommodate employee stock
 option exercises. The stock options had exercise prices ranging
 from $15.29 to $23.46. We received proceeds totaling $2.3 million
 from the exercise of these stock options during the nine months
 ended September 30, 2014.

[0001193125-14-398391:notes:114]
[same as prior period, unchanged from 0001193125-14-297927:notes:122]

[0001193125-14-398391:notes:115]
During the nine months ended September 30, 2014, we paid cash
 dividends as follows (in thousands except per share amounts):

[0001193125-14-398391:notes:116]
| Record Date |  | Payment Date |  | Per Share Amount |  | Total Dividend Paid |
| February 6, 2014 |  | February 20, 2014 |  | $0.09 |  | $5,102 |
| May 1, 2014 |  | May 15, 2014 |  | $0.09 |  | $5,035 |
| July 31, 2014 |  | August 14, 2014 |  | $0.09 |  | $4,923 |

[0001193125-14-398391:notes:117]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the three months
 ended September 30, 2014 and 2013:

[0001193125-14-398391:notes:118]
| (In thousands) |  | Three Months Ended September 30, 2014 |  |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |  |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 2,565 |  |  |  | Net realized investment gain |  |
| Impairment expense |  |  | (30 | ) |  |  | Net realized investment gain |  |
| Total reclassifications for the period, before tax |  |  | 2,535 |  |  |  |  |  |
| Tax (expense) benefit |  |  | (989 | ) |  |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,546 |  |  |  |  |  |

[0001193125-14-398391:notes:119]
| (In thousands) |  | Three Months Ended September 30, 2013 |  |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |  |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,583 |  |  |  | Net realized investment gain |  |
| Impairment expense |  |  | (9 | ) |  |  | Net realized investment gain |  |
| Total reclassifications for the period, before tax |  |  | 1,574 |  |  |  |  |  |
| Tax (expense) benefit |  |  | (614 | ) |  |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 960 |  |  |  |  |  |

[0001193125-14-398391:notes:120]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the nine months ended
 September 30, 2014 and 2013:

[0001193125-14-398391:notes:121]
| (In thousands) |  | Nine Months Ended September 30, 2014 |  |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |  |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 6,895 |  |  |  | Net realized investment gain |  |
| Impairment expense |  |  | (64 | ) |  |  | Net realized investment gain |  |
| Total reclassifications for the period, before tax |  |  | 6,831 |  |  |  |  |  |
| Tax (expense) benefit |  |  | (2,665 | ) |  |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 4,166 |  |  |  |  |  |

[0001193125-14-398391:notes:122]
| (In thousands) |  | Nine Months Ended September 30, 2013 |  |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |  |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 6,496 |  |  |  | Net realized investment gain |  |
| Impairment expense |  |  | (13 | ) |  |  | Net realized investment gain |  |
| Total reclassifications for the period, before tax |  |  | 6,483 |  |  |  |  |  |
| Tax (expense) benefit |  |  | (2,529 | ) |  |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 3,954 |  |  |  |  |  |

[0001193125-14-398391:notes:123]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the three
 months ended September 30, 2014 and 2013:

[0001193125-14-398391:notes:124]
|  |  | Three Months Ended September 30, 2014 |  |  | Three Months Ended September 30, 2013 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (2,626 | ) |  | $ | 1,024 |  |  | $ | (1,602 | ) |  | $ | 5,774 |  |  | $ | (2,252 | ) |  | $ | 3,522 |  |
| Reclassification adjustment for amounts included in net income |  |  | (2,535 | ) |  |  | 989 |  |  |  | (1,546 | ) |  |  | (1,574 | ) |  |  | 614 |  |  |  | (960 | ) |
| Foreign currency translation adjustment |  |  | (2,568 | ) |  |  | — |  |  |  | (2,568 | ) |  |  | (108 | ) |  |  | — |  |  |  | (108 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (7,729 | ) |  | $ | 2,013 |  |  | $ | (5,716 | ) |  | $ | 4,092 |  |  | $ | (1,638 | ) |  | $ | 2,454 |  |

[0001193125-14-398391:notes:125]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the nine months
 ended September 30, 2014 and 2013:

[0001193125-14-398391:notes:126]
|  |  | Nine Months Ended September 30, 2014 |  |  | Nine Months Ended September 30, 2013 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 2,157 |  |  | $ | (841 | ) |  | $ | 1,316 |  |  | $ | 5,203 |  |  | $ | (2,029 | ) |  | $ | 3,174 |  |
| Reclassification adjustment for amounts included in net income |  |  | (6,831 | ) |  |  | 2,665 |  |  |  | (4,166 | ) |  |  | (6,483 | ) |  |  | 2,529 |  |  |  | (3,954 | ) |
| Foreign currency translation adjustment |  |  | (2,182 | ) |  |  | — |  |  |  | (2,182 | ) |  |  | (1,498 | ) |  |  | — |  |  |  | (1,498 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (6,856 | ) |  | $ | 1,824 |  |  | $ | (5,032 | ) |  | $ | (2,778 | ) |  | $ | 500 |  |  | $ | (2,278 | ) |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-14-398391:notes:127]
[same as prior period, unchanged from 0001193125-14-297927:notes:132]

[0001193125-14-398391:notes:128]
[same as prior period, unchanged from 0001193125-14-297927:notes:133]

[0001193125-14-398391:notes:129]
[same as prior period, unchanged from 0001193125-14-297927:notes:134]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-398391:notes:130]
2. INCOME TAXES

[0001193125-14-398391:notes:131]
Our effective tax rate increased from 27.0% in the nine months
 ended September 30, 2013 to 31.5% in the nine months ended
 September 30, 2014. The increase in the effective tax rate
 between the two periods is primarily attributable to the net effect
 of the exclusion of a benefit for the research tax credit, which
 expired on December 31, 2013, partially offset by the release
 of a valuation allowance attributable to a foreign subsidiary in
 2014.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-14-398391:notes:132]
12. LIABILITY FOR WARRANTY RETURNS

[0001193125-14-398391:notes:133]
Our products generally include warranties of 90 days to ten years
 for product defects. We accrue for warranty returns at the time
 revenue is recognized based on our estimate of the cost to repair
 or replace the defective products. We engage in extensive product
 quality programs and processes, including actively monitoring and
 evaluating the quality of our component suppliers. Our products
 continue to become more complex in both size and functionality as
 many of our product offerings migrate from line card applications
 to systems products. The increasing complexity of our products will
 cause warranty incidences, when they arise, to be more costly. Our
 estimates regarding future warranty obligations may change due to
 product failure rates, material usage, and other rework costs
 incurred in correcting a product failure. In addition, from time to
 time, specific warranty accruals may be recorded if unforeseen
 problems arise. Should our actual experience relative to these
 factors be worse than our estimates, we will be required to record
 additional warranty expense. Alternatively, if we provide for more
 reserves than we require, we will reverse a portion of such
 provisions in future periods. The liability for warranty
 obligations totaled $8.6 million at September 30, 2014 and
 $9.0 million at December 31, 2013. The decrease from
 December 31, 2013 to September 30, 2014 includes a $1.5
 million decrease related to the settlement of an outstanding
 warranty claim, which corresponds to a reduction in Other
 Receivables. These liabilities are included in accrued expenses in
 the accompanying Consolidated Balance Sheets.

[0001193125-14-398391:notes:134]
A summary of warranty expense and write-off activity for the nine
 months ended September 30, 2014 and 2013 is as follows:

[0001193125-14-398391:notes:135]
|  |  | Nine Months Ended |  |
|  |  | September 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period |  | $ | 8,977 |  |  | $ | 9,653 |  |
| Plus: Amounts charged to cost and expenses |  |  | 2,770 |  |  |  | 2,078 |  |
| Less: Deductions |  |  | (3,099 | ) |  |  | (3,120 | ) |
| Balance at end of period |  | $ | 8,648 |  |  | $ | 8,611 |  |

[0001193125-14-398391:notes:136]
Deductions for the nine months ended September 30, 2014
 include a $1.5 million reduction that relates to the settlement of
 an outstanding warranty claim, which corresponds to a reduction in
 Other Receivables.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-14-398391:notes:137]
1. SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001193125-14-398391:notes:138]
Changes in Classifications

[0001193125-14-398391:notes:139]
We corrected immaterial misclassifications between the operating
 and investing sections of our consolidated statements of cash flows
 and adjusted our cash flows for the nine months ended
 September 30, 2013 in these categories by $0.4 million in
 order to be consistent with the 2014 presentation.

[0001193125-14-398391:notes:140]
Out of Period Adjustment

[0001193125-14-398391:notes:141]
During the year ended December 31, 2013, we identified two
 adjustments in the acquired NSN (formerly Nokia Siemens Networks)
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.5 million
 understatement of net income in the first two quarters of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for each of the prior
 periods affected and concluded that the impact was not material. We
 also evaluated the impact of the cumulative effect of the
 adjustments in 2013 and concluded that the impact is not material
 to our results for the year 2013. Accordingly, during the three
 months ended September 30, 2013 we recorded an out of period
 adjustment to correct these issues.

[0001193125-14-398391:notes:142]
Use of Estimates

[0001193125-14-398391:notes:143]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated working capital
 adjustments under negotiation related to the NSN BBA business
 acquisition, estimated pension liability, fair value of
 investments, and the evaluation of other-than-temporary declines in
 the value of investments. Actual amounts could differ significantly
 from these estimates.

[0001193125-14-398391:notes:144]
Recent Accounting Pronouncements

[0001193125-14-398391:notes:145]
In May 2014, the Financial Accounting Standards Board issued
 Accounting Standards Update No. 2014-09, Revenue from
 Contracts with Customers (ASU 2014-09), which supersedes the
 revenue recognition requirements in Topic 605, Revenue
 Recognition, including most industry-specific revenue
 recognition guidance throughout the Industry Topics of the
 Codification. The core principle of ASU 2014-09 is to recognize
 revenues when promised goods or services are transferred to
 customers in an amount that reflects the consideration that is
 expected to be received for those goods or services. ASU 2014-09 is
 effective for annual reporting periods beginning after
 December 15, 2016, including interim periods within that
 reporting period, and early application is not permitted. ASU
 2014-09 allows for either full retrospective or modified
 retrospective adoption. We are currently evaluating the transition
 method that will be elected and the impact that the adoption of ASU
 2014-09 will have on our financial position, results of operations
 and cash flows.


## us-gaap:SubsequentEventsTextBlock

[0001193125-14-398391:notes:146]
15. SUBSEQUENT EVENTS

[0001193125-14-398391:notes:147]
On October 14, 2014, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 October 30, 2014. The payment date will be November 13,
 2014. The quarterly dividend payment will be approximately $4.9
 million. In July 2003, our Board of Directors elected to begin
 declaring quarterly dividends on our common stock considering the
 tax treatment of dividends and adequate levels of Company
 liquidity.

[0001193125-14-398391:notes:148]
During the fourth quarter and as of November 5, 2014, we have
 repurchased 0.2 million shares of our common stock
 through open market purchases at an average cost of $20.47 per
 share. We currently have the authority to purchase an additional
 5.5 million shares of our common stock under the current plan
 approved by the Board of Directors.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-14-398391:notes:149]
4. STOCK-BASED COMPENSATION

[0001193125-14-398391:notes:150]
The fair value of our stock options is estimated using the
 Black-Scholes model. The determination of the fair value of stock
 options on the date of grant using the Black-Scholes model is
 affected by our stock price as well as assumptions regarding a
 number of complex and subjective variables that may have a
 significant impact on the fair value estimate.

[0001193125-14-398391:notes:151]
There were no options granted during the three months ended
 September 30, 2014 or the three and nine months ended
 September 30, 2013. The weighted-average assumptions and value
 of options granted for the nine months ended September 30,
 2014 are summarized as follows:

[0001193125-14-398391:notes:152]
The fair value of our RSUs is calculated using a Monte Carlo
 Simulation valuation method. No RSUs were granted, forfeited, or
 vested during the three and nine months ended September 30,
 2014 or 2013.

[0001193125-14-398391:notes:153]
The fair value of restricted stock is equal to the closing price of
 our stock on the date of grant. We granted four thousand shares of
 restricted stock during the nine months ended September 30,
 2014 at a fair value of $21.30 per share. No restricted stock was
 forfeited or vested during the three and nine months ended
 September 30, 2014 or 2013.

[0001193125-14-398391:notes:154]
Stock-based compensation expense recognized in our Consolidated
 Statements of Income for the three and nine months ended
 September 30, 2014 and 2013 is based on options, RSUs and
 restricted stock ultimately expected to vest, and has been reduced
 for estimated forfeitures. Estimated forfeitures for stock options
 are based upon historical experience and approximate 2.5% annually.
 We estimated a 0% forfeiture rate for our RSUs and restricted stock
 due to the limited number of recipients and historical experience
 for these awards.

[0001193125-14-398391:notes:155]
As of September 30, 2014, total compensation expense related
 to non-vested stock options, RSUs and restricted stock not yet
 recognized was approximately $11.6 million, which is expected to be
 recognized over an average remaining recognition period of 2.3
 years.

[0001193125-14-398391:notes:156]
The aggregate intrinsic values in the table above represent the
 total pre-tax intrinsic value (the difference between the closing
 price of our stock on the last trading day of the quarter and the
 exercise price, multiplied by the number of in-the-money options)
 that would have been received by the option holders had all option
 holders exercised their options on September 30, 2014. The
 aggregate intrinsic value will change based on the fair market
 value of our stock.

[0001193125-14-398391:notes:157]
The total pre-tax intrinsic value of options exercised during the
 three and nine months ended September 30, 2014 was $0.1
 million and $0.6 million, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-14-398391:notes:158]
3. PENSION BENEFIT PLAN

[0001193125-14-398391:notes:159]
[same as prior period, unchanged from 0001193125-14-297927:notes:164]

[0001193125-14-398391:notes:160]
The following table summarizes the components of net periodic
 pension cost for the three and nine months ended September 30,
 2014 and 2013:

[0001193125-14-398391:notes:161]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Service cost |  | $ | 299 |  |  | $ | 297 |  |  | $ | 910 |  |  | $ | 891 |  |
| Interest cost |  |  | 209 |  |  |  | 185 |  |  |  | 640 |  |  |  | 554 |  |
| Expected return on plan assets |  |  | (272 | ) |  |  | (250 | ) |  |  | (831 | ) |  |  | (751 | ) |
| Net periodic pension cost |  | $ | 236 |  |  | $ | 232 |  |  | $ | 719 |  |  | $ | 694 |  |
