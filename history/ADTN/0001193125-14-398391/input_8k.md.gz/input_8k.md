# ADTN 8-K — 0001193125-14-372076 filed 2014-10-15

## item codes, every 8-K on or before 2014-11-05

- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2014-11-05

- none on or before 2014-11-05

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-372076:8k_2_02:1]
EX-99.1
2
d804459dex991.htm
EX-99.1

[0001193125-14-372076:8k_2_02:2]
EX-99.1

[0001193125-14-372076:8k_2_02:3]
EXHIBIT 99.1

[0001193125-14-372076:8k_2_02:4]
ADTRAN, INC.

[0001193125-14-372076:8k_2_02:5]
REPORTS RESULTS for the THIRD QUARTER 2014 and DECLARES QUARTERLY CASH DIVIDEND

[0001193125-14-372076:8k_2_02:6]
HUNTSVILLE, Ala.—(BUSINESS WIRE)—October 14, 2014—ADTRAN, Inc. (NASDAQ:ADTN) reported results for the third quarter 2014. For the
quarter, sales were $162,892,000 compared to $177,404,000 for the third quarter of 2013. Net income was $11,326,000 compared to $16,205,000 for the third quarter of 2013. Earnings per share, assuming dilution, were $0.21 compared to $0.28 for the
third quarter of 2013. Non-GAAP earnings per share were $0.25 compared to $0.32 for the third quarter of 2013. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-14-372076:8k_2_02:7]
ADTRAN Chief Executive Officer Tom Stanton stated, “Revenue came in as we anticipated in our press release of October 2, 2014 with a sequential
decrease in our European business and a soft enterprise spending environment. Our domestic carrier business saw a sequential revenue increase. We believe our company is well positioned to take advantage of a re-acceleration of carrier spending in
both Europe and the US we expect to begin in 2015.”

[0001193125-14-372076:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash dividend for the third
quarter of 2014. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on October 30, 2014. The ex-dividend date is October 28, 2014 and the payment date is November 13, 2014.

[0001193125-14-372076:8k_2_02:9]
The Company confirmed that its third quarter conference call will be held Wednesday, October 15, 2014 at 9:30 a.m. Central Time. This conference
call will be web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the call and click on the conference call
link provided.

[0001193125-14-372076:8k_2_02:10]
An online replay of the conference call will be available for seven days at www.streetevents.com. In addition, an online replay of
the conference call, as well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following the call.

[0001193125-14-372076:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet
communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit
www.adtran.com.

[0001193125-14-372076:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web, visit
www.adtran.com.

[0001193125-14-372076:8k_2_02:13]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently
known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs,
manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2013 and on Form 10-Q for the quarter ended June 30, 2014. These risks and uncertainties could cause actual results to
differ materially from those in the forward-looking statements included in this press release.

[0001193125-14-372076:8k_2_02:14]
| CONTACT: Jim Matthews Senior Vice President/CFO 256-963-8775 |  | INVESTOR SERVICES/ASSISTANCE: Gayle Ellis 256-963-8220 |

[0001193125-14-372076:8k_2_02:15]
Condensed Consolidated Balance Sheet

[0001193125-14-372076:8k_2_02:16]
(Unaudited)

[0001193125-14-372076:8k_2_02:17]
(In
thousands)

[0001193125-14-372076:8k_2_02:18]
|  |  | September 30,2014 |  |  | December 31,2013 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 58,415 |  |  | $ | 58,298 |  |
| Short-term investments |  |  | 55,587 |  |  |  | 105,760 |  |
| Accounts receivable, net |  |  | 99,341 |  |  |  | 85,814 |  |
| Other receivables |  |  | 27,262 |  |  |  | 18,249 |  |
| Inventory |  |  | 86,879 |  |  |  | 90,111 |  |
| Prepaid expenses |  |  | 5,579 |  |  |  | 4,325 |  |
| Deferred tax assets, net |  |  | 15,697 |  |  |  | 17,083 |  |
| Total Current Assets |  |  | 348,760 |  |  |  | 379,640 |  |
| Property, plant and equipment, net |  |  | 75,201 |  |  |  | 76,739 |  |
| Deferred tax assets, net |  |  | 12,991 |  |  |  | 9,622 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 11,748 |  |  |  | 11,180 |  |
| Long-term investments |  |  | 298,542 |  |  |  | 309,225 |  |
| Total Assets |  | $ | 750,734 |  |  | $ | 789,898 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 49,972 |  |  | $ | 48,282 |  |
| Unearned revenue |  |  | 23,418 |  |  |  | 22,205 |  |
| Accrued expenses |  |  | 12,356 |  |  |  | 12,776 |  |
| Accrued wages and benefits |  |  | 17,591 |  |  |  | 14,040 |  |
| Income tax payable, net |  |  | 13,650 |  |  |  | 5,002 |  |
| Total Current Liabilities |  |  | 116,987 |  |  |  | 102,305 |  |
| Non-current unearned revenue |  |  | 13,822 |  |  |  | 14,643 |  |
| Other non-current liabilities |  |  | 23,548 |  |  |  | 22,144 |  |
| Bonds payable |  |  | 30,000 |  |  |  | 46,200 |  |
| Total Liabilities |  |  | 184,357 |  |  |  | 185,292 |  |
| Stockholders’ Equity |  |  | 566,377 |  |  |  | 604,606 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 750,734 |  |  | $ | 789,898 |  |

[0001193125-14-372076:8k_2_02:19]
Consolidated Statements of Income

[0001193125-14-372076:8k_2_02:20]
(Unaudited)

[0001193125-14-372076:8k_2_02:21]
(In
thousands, except per share data)

[0001193125-14-372076:8k_2_02:22]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Sales |  | $ | 162,892 |  |  | $ | 177,404 |  |  | $ | 486,025 |  |  | $ | 482,650 |  |
| Cost of sales |  |  | 84,635 |  |  |  | 94,857 |  |  |  | 243,181 |  |  |  | 250,628 |  |
| Gross Profit |  |  | 78,257 |  |  |  | 82,547 |  |  |  | 242,844 |  |  |  | 232,022 |  |
| Selling, general and administrative expenses |  |  | 32,438 |  |  |  | 32,794 |  |  |  | 100,165 |  |  |  | 96,082 |  |
| Research and development expenses |  |  | 33,324 |  |  |  | 32,543 |  |  |  | 99,547 |  |  |  | 98,114 |  |
| Operating Income |  |  | 12,495 |  |  |  | 17,210 |  |  |  | 43,132 |  |  |  | 37,826 |  |
| Interest and dividend income |  |  | 992 |  |  |  | 1,579 |  |  |  | 3,340 |  |  |  | 5,021 |  |
| Interest expense |  |  | (150 | ) |  |  | (581 | ) |  |  | (525 | ) |  |  | (1,737 | ) |
| Net realized investment gain |  |  | 2,687 |  |  |  | 1,751 |  |  |  | 7,219 |  |  |  | 6,949 |  |
| Other income (expense), net |  |  | (963 | ) |  |  | 22 |  |  |  | (1,615 | ) |  |  | (1,521 | ) |
| Income before provision for income taxes |  |  | 15,061 |  |  |  | 19,981 |  |  |  | 51,551 |  |  |  | 46,538 |  |
| Provision for income taxes |  |  | (3,735 | ) |  |  | (3,776 | ) |  |  | (16,223 | ) |  |  | (12,584 | ) |
| Net Income |  | $ | 11,326 |  |  | $ | 16,205 |  |  | $ | 35,328 |  |  | $ | 33,954 |  |
| Weighted average shares outstanding - basic |  |  | 54,521 |  |  |  | 57,947 |  |  |  | 55,552 |  |  |  | 59,561 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 54,824 |  |  |  | 58,617 |  |  |  | 55,976 |  |  |  | 59,929 |  |
| Earnings per common share - basic |  | $ | 0.21 |  |  | $ | 0.28 |  |  | $ | 0.64 |  |  | $ | 0.57 |  |
| Earnings per common share - diluted (1) |  | $ | 0.21 |  |  | $ | 0.28 |  |  | $ | 0.63 |  |  | $ | 0.57 |  |

[0001193125-14-372076:8k_2_02:23]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001193125-14-372076:8k_2_02:24]
Consolidated Statements of Comprehensive Income

[0001193125-14-372076:8k_2_02:25]
(Unaudited)

[0001193125-14-372076:8k_2_02:26]
(In
thousands)

[0001193125-14-372076:8k_2_02:27]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net Income |  | $ | 11,326 |  |  | $ | 16,205 |  |  | $ | 35,328 |  |  | $ | 33,954 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | (3,148 | ) |  |  | 2,562 |  |  |  | (2,850 | ) |  |  | (780 | ) |
| Foreign currency translation |  |  | (2,568 | ) |  |  | (108 | ) |  |  | (2,182 | ) |  |  | (1,498 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  | (5,716 | ) |  |  | 2,454 |  |  |  | (5,032 | ) |  |  | (2,278 | ) |
| Comprehensive Income, net of tax |  | $ | 5,610 |  |  | $ | 18,659 |  |  | $ | 30,296 |  |  | $ | 31,676 |  |

[0001193125-14-372076:8k_2_02:28]
Consolidated Statements of Cash Flows

[0001193125-14-372076:8k_2_02:29]
(Unaudited)

[0001193125-14-372076:8k_2_02:30]
(In
thousands)

[0001193125-14-372076:8k_2_02:31]
|  |  | Nine Months Ended |  |
|  |  | September 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 35,328 |  |  | $ | 33,954 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 11,127 |  |  |  | 11,021 |  |
| Amortization of net premium on available-for-sale investments |  |  | 3,363 |  |  |  | 4,688 |  |
| Net realized gain on long-term investments |  |  | (7,219 | ) |  |  | (6,949 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 109 |  |  |  | 6 |  |
| Stock-based compensation expense |  |  | 6,296 |  |  |  | 6,516 |  |
| Deferred income taxes |  |  | (122 | ) |  |  | (1,296 | ) |
| Tax benefit from stock option exercises |  |  | 71 |  |  |  | 113 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (53 | ) |  |  | (106 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (15,957 | ) |  |  | (25,844 | ) |
| Other receivables |  |  | (10,576 | ) |  |  | (3,724 | ) |
| Inventory |  |  | 2,413 |  |  |  | 8,584 |  |
| Prepaid expenses and other assets |  |  | (4,095 | ) |  |  | (417 | ) |
| Accounts payable |  |  | 3,563 |  |  |  | 30,073 |  |
| Accrued expenses and other liabilities |  |  | 7,507 |  |  |  | (4,339 | ) |
| Income tax payable, net |  |  | 9,265 |  |  |  | (678 | ) |
| Net cash provided by operating activities |  |  | 41,020 |  |  |  | 51,602 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (8,162 | ) |  |  | (6,123 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 1 |  |  |  | — |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 187,013 |  |  |  | 275,581 |  |
| Purchases of available-for-sale investments |  |  | (127,074 | ) |  |  | (216,129 | ) |
| Net cash provided by investing activities |  |  | 51,778 |  |  |  | 53,329 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 2,311 |  |  |  | 2,332 |  |
| Purchases of treasury stock |  |  | (62,144 | ) |  |  | (104,147 | ) |
| Dividend payments |  |  | (15,060 | ) |  |  | (16,220 | ) |
| Payments on long-term debt |  |  | (16,500 | ) |  |  | — |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | 53 |  |  |  | 106 |  |
| Net cash used in financing activities |  |  | (91,340 | ) |  |  | (117,929 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 1,458 |  |  |  | (12,998 | ) |
| Effect of exchange rate changes |  |  | (1,341 | ) |  |  | (1,148 | ) |
| Cash and cash equivalents, beginning of period |  |  | 58,298 |  |  |  | 68,457 |  |
| Cash and cash equivalents, end of period |  | $ | 58,415 |  |  | $ | 54,311 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 598 |  |  | $ | 494 |  |

[0001193125-14-372076:8k_2_02:32]
Supplemental Information

[0001193125-14-372076:8k_2_02:33]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-14-372076:8k_2_02:34]
(Unaudited)

[0001193125-14-372076:8k_2_02:35]
(In
thousands)

[0001193125-14-372076:8k_2_02:36]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the
Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and nine months ended September 30, 2014 and 2013 for both transactions are as follows:

[0001193125-14-372076:8k_2_02:37]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 227 |  |  | $ | 283 |  |  | $ | 699 |  |  | $ | 863 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 287 |  |  |  | 291 |  |  |  | 884 |  |  |  | 873 |  |
| Amortization of other purchase accounting adjustments |  |  | 240 |  |  |  | 235 |  |  |  | 895 |  |  |  | 987 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 24 |  |  |  | 93 |  |  |  | 89 |  |  |  | 329 |  |
| Subtotal |  |  | 551 |  |  |  | 619 |  |  |  | 1,868 |  |  |  | 2,189 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 778 |  |  |  | 902 |  |  |  | 2,567 |  |  |  | 3,052 |  |
| Provision for income taxes |  |  | (259 | ) |  |  | (302 | ) |  |  | (851 | ) |  |  | (1,015 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 519 |  |  | $ | 600 |  |  | $ | 1,716 |  |  | $ | 2,037 |  |

[0001193125-14-372076:8k_2_02:38]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three and nine months ended September 30, 2014 and 2013:

[0001193125-14-372076:8k_2_02:39]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 105 |  |  | $ | 221 |  |  | $ | 528 |  |  | $ | 718 |  |
| Cost of goods sold |  |  | 47 |  |  |  | (57 | ) |  |  | 104 |  |  |  | 94 |  |
| Subtotal |  |  | 152 |  |  |  | 164 |  |  |  | 632 |  |  |  | 812 |  |
| Selling, general and administrative expenses |  |  | 31 |  |  |  | 101 |  |  |  | 110 |  |  |  | 375 |  |
| Research and development expenses |  |  | 595 |  |  |  | 637 |  |  |  | 1,825 |  |  |  | 1,865 |  |
| Subtotal |  |  | 626 |  |  |  | 738 |  |  |  | 1,935 |  |  |  | 2,240 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 778 |  |  |  | 902 |  |  |  | 2,567 |  |  |  | 3,052 |  |
| Provision for income taxes |  |  | (259 | ) |  |  | (302 | ) |  |  | (851 | ) |  |  | (1,015 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 519 |  |  | $ | 600 |  |  | $ | 1,716 |  |  | $ | 2,037 |  |

[0001193125-14-372076:8k_2_02:40]
Supplemental Information

[0001193125-14-372076:8k_2_02:41]
Stock-based Compensation Expense

[0001193125-14-372076:8k_2_02:42]
(Unaudited)

[0001193125-14-372076:8k_2_02:43]
(In
thousands)

[0001193125-14-372076:8k_2_02:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 124 |  |  | $ | 118 |  |  | $ | 359 |  |  | $ | 334 |  |
| Selling, general and administrative expense |  |  | 1,048 |  |  |  | 1,024 |  |  |  | 3,089 |  |  |  | 3,129 |  |
| Research and development expense |  |  | 975 |  |  |  | 1,034 |  |  |  | 2,848 |  |  |  | 3,053 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,023 |  |  |  | 2,058 |  |  |  | 5,937 |  |  |  | 6,182 |  |
| Total stock-based compensation expense |  |  | 2,147 |  |  |  | 2,176 |  |  |  | 6,296 |  |  |  | 6,516 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (298 | ) |  |  | (307 | ) |  |  | (878 | ) |  |  | (924 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,849 |  |  | $ | 1,869 |  |  | $ | 5,418 |  |  | $ | 5,592 |  |

[0001193125-14-372076:8k_2_02:45]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-14-372076:8k_2_02:46]
Non-GAAP net income per share, diluted

[0001193125-14-372076:8k_2_02:47]
(Unaudited)

[0001193125-14-372076:8k_2_02:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| GAAP earnings per common share – diluted |  | $ | 0.21 |  |  | $ | 0.28 |  |  | $ | 0.63 |  |  | $ | 0.57 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.03 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.10 |  |  |  | 0.09 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.25 |  |  | $ | 0.32 |  |  | $ | 0.76 |  |  | $ | 0.69 |  |
