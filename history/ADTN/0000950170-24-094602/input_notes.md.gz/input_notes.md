# ADTN notes — 0000950170-24-094602


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-24-094602:notes:1]
[same as prior period, unchanged from 0000950170-24-057628:notes:1]

[0000950170-24-094602:notes:2]
[same as prior period, unchanged from 0000950170-24-057628:notes:2]

[0000950170-24-094602:notes:3]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks SE (formerly ADVA Optical Networking SE). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer and in particular upon the convergence of solutions at the network edge.

[0000950170-24-094602:notes:4]
Liquidity, Domination and Profit and Loss Transfer Agreement and Credit Facility

[0000950170-24-094602:notes:5]
[same as prior period, unchanged from 0000950170-24-057628:notes:5]

[0000950170-24-094602:notes:6]
[same as prior period, unchanged from 0000950170-24-057628:notes:6]

[0000950170-24-094602:notes:7]
[same as prior period, unchanged from 0000950170-24-057628:notes:7]

[0000950170-24-094602:notes:8]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of June 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €345.6 million or approximately $371.3 million, based on an exchange rate as of June 30, 2024, and reflecting interest accrued through June 30, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-094602:notes:9]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.4 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three and six months ended June 30, 2024, and 2023, we accrued $2.9 million and $5.7 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

[0000950170-24-094602:notes:10]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or approximately $20 thousand and $25 thousand, respectively, based on an exchange rate as of June 30, 2024, were paid to Adtran Networks shareholders. For the three and six months ended June 30, 2023, approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €0.8 thousand and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

[0000950170-24-094602:notes:11]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. Pursuant to the terms of the Credit Agreement, as amended, the Company, ADTRAN, Inc., and the subsidiary guarantors (together, the “Credit Parties”) are subject to a liquidity covenant, which provides that, during the fourth quarter of 2023 through and including the third quarter of 2024 (“Covenant Relief Period”) or a Springing Covenant Period (i.e., the period beginning upon the purchase by the Company of at least 60% of the outstanding shares of Adtran Networks not owned by the Company as of August 9, 2023 and the three consecutive quarterly test periods after such date), as of the last day of any fiscal quarter, the cash and cash equivalents of the Credit Parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million, limiting our ability to pay the obligations under the DPLTA. The Company had access to $206.0 million on its Credit Facility for future borrowings; however, as of June 30, 2024, the Company was limited to additional borrowings of $16.4 million based on debt covenant compliance metrics. See Note 11, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

[0000950170-24-094602:notes:12]
As of June 30, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-32 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks shares.

[0000950170-24-094602:notes:13]
The Company experienced revenue declines in the year ended December 31, 2023, and during the three and six months ended June 30, 2024. To the extent that the Company is further impacted by customers' inventory reduction initiatives, the Company is implementing plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a business efficiency program, which includes, but is not limited to ongoing reductions in

[0000950170-24-094602:notes:14]
operating expenses and a site consolidation plan. In connection with the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditure and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

[0000950170-24-094602:notes:15]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and to support our ability to continue to comply with our debt covenants under the Credit Facility, for at least the next twelve months, from the issuance of these financial statements. See Note 11, Revolving Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo Credit agreement.

[0000950170-24-094602:notes:16]
[same as prior period, unchanged from 0000950170-24-057628:notes:16]

[0000950170-24-094602:notes:17]
[same as prior period, unchanged from 0000950170-24-057628:notes:17]

[0000950170-24-094602:notes:18]
The accompanying unaudited Condensed Consolidated Financial Statements of ADTRAN Holdings, Inc. and its subsidiaries have been prepared pursuant to the rules and regulations of the SEC applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2023, Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP for annual financial statements.

[0000950170-24-094602:notes:19]
[same as prior period, unchanged from 0000950170-24-057628:notes:19]

[0000950170-24-094602:notes:20]
[same as prior period, unchanged from 0000950170-24-057628:notes:20]

[0000950170-24-094602:notes:21]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

[0000950170-24-094602:notes:22]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions as of June 30, 2024, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.

[0000950170-24-094602:notes:23]
[same as prior period, unchanged from 0000950170-24-057628:notes:23]

[0000950170-24-094602:notes:24]
[same as prior period, unchanged from 0000950170-24-057628:notes:24]

[0000950170-24-094602:notes:25]
On December 19, 2023, the Company entered into a new factoring agreement with a third-party financial institution to replace the Company’s prior accounts receivable purchase agreement, to sell on a revolving basis, undivided interests in the Company’s accounts receivable. The new factoring agreement qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company is considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retains a residual claim on reserves related to the factored receivables. Within the Condensed Consolidated Balance Sheets, the receivables factored continue to be carried in accounts receivable, less allowance for credit losses, and the secured borrowings are carried as a current liability within accounts payable. The proceeds and repayments of secured borrowings are reflected as cash flows (used in) provided by financing activities within the Condensed Consolidated Statements of Cash Flows, and program fees are recorded as interest expense in the Consolidated Statements of Loss. The short-term liability classification of the secured borrowings is based on the estimated timing of the collection of the accounts receivable which are expected to be received within 12 months. See Note 2 for additional information.

[0000950170-24-094602:notes:26]
[same as prior period, unchanged from 0000950170-24-057628:notes:26]

[0000950170-24-094602:notes:27]
The Company had previously entered into a factoring agreement to sell certain receivables to an unrelated third-party financial institution on a non-recourse basis. These transactions were accounted for in accordance with ASC Topic 860 and resulted in a reduction in accounts receivable because the agreement transferred effective control over, and risk related to the receivables to the buyers. Trade accounts receivables balances sold were removed from the Condensed Consolidated Balance Sheets and cash received was reflected as cash flows provided by (used in) operating activities in the Condensed Consolidated Statements of Cash Flow. Factoring related interest expense was recorded to interest expense on the Condensed Consolidated Statements of Loss. On each sale date, the financial institution retained from the sale price a default reserve, up to a required balance, which was held by the financial institution in a reserve account and pledged to the Company. The financial institution was entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account was included in other assets on the Condensed Consolidated Balance Sheets.

[0000950170-24-094602:notes:28]
[same as prior period, unchanged from 0000950170-24-057628:notes:28]

[0000950170-24-094602:notes:29]
As of June 30, 2024 and December 31, 2023, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.6% for each period.

[0000950170-24-094602:notes:30]
As a result of the effectiveness of the DPLTA on January 16, 2023, the Adtran Networks shares, representing the equity interest in Adtran Networks held by holders other than the Company, can be tendered at any time and are, therefore, redeemable and must be classified outside stockholders’ equity. Therefore, the permanent equity noncontrolling interest balance was reclassified to redeemable non-controlling interest on January 16, 2023, and was remeasured to fair value based on the trading market price of the Adtran Networks shares.

[0000950170-24-094602:notes:31]
[same as prior period, unchanged from 0000950170-24-057628:notes:31]

[0000950170-24-094602:notes:32]
[same as prior period, unchanged from 0000950170-24-057628:notes:32]

[0000950170-24-094602:notes:33]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2023-09 will have on our disclosures.

[0000950170-24-094602:notes:34]
In November 2023, the FASB issued ASU 2023-7, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures", which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses, allowing financial statement users to better understand the components of a segment's profit or loss to assess potential future cash flows for each reportable segment and the entity as a whole. The amendments expand a public entity's segment disclosures by requiring disclosure of significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), clarifying when an entity may report one or more additional measures to assess segment performance, requiring enhanced interim disclosures, providing new disclosure requirements for entities with a single reportable segment, and requiring other new disclosures. The amendments are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, and early adoption is permitted. The Company expects to adopt the new disclosures as required for the year ended December 31, 2024. The Company is currently evaluating the impact on the related disclosures.

[0000950170-24-094602:notes:35]
[same as prior period, unchanged from 0000950170-24-057628:notes:35]

[0000950170-24-094602:notes:36]
[same as prior period, unchanged from 0000950170-24-057628:notes:36]

[0000950170-24-094602:notes:37]
Recently Adopted Accounting Pronouncements

[0000950170-24-094602:notes:38]
There are currently no recently adopted accounting pronouncements that are expected to have a material effect on the Condensed Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-24-094602:notes:39]
[same as prior period, unchanged from 0000950170-24-057628:notes:39]

[0000950170-24-094602:notes:40]
[same as prior period, unchanged from 0000950170-24-057628:notes:40]

[0000950170-24-094602:notes:41]
[same as prior period, unchanged from 0000950170-24-057628:notes:41]

[0000950170-24-094602:notes:42]
[same as prior period, unchanged from 0000950170-24-057628:notes:42]

[0000950170-24-094602:notes:43]
[same as prior period, unchanged from 0000950170-24-057628:notes:43]

[0000950170-24-094602:notes:44]
[same as prior period, unchanged from 0000950170-24-057628:notes:44]

[0000950170-24-094602:notes:45]
[same as prior period, unchanged from 0000950170-24-057628:notes:45]

[0000950170-24-094602:notes:46]
[same as prior period, unchanged from 0000950170-24-057628:notes:46]

[0000950170-24-094602:notes:47]
[same as prior period, unchanged from 0000950170-24-057628:notes:47]

[0000950170-24-094602:notes:48]
The following tables disaggregate revenue by reportable segment and revenue category:

[0000950170-24-094602:notes:49]
|  |  | Three Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 51,467 |  |  | $ | 22,220 |  |  | $ | 73,687 |  |  | $ | 120,221 |  |  | $ | 22,775 |  |  | $ | 142,996 |  |
| Access & Aggregation Solutions |  |  | 54,112 |  |  |  | 15,795 |  |  |  | 69,907 |  |  |  | 89,263 |  |  |  | 13,454 |  |  |  | 102,717 |  |
| Subscriber Solutions |  |  | 73,615 |  |  |  | 8,782 |  |  |  | 82,397 |  |  |  | 73,518 |  |  |  | 8,147 |  |  |  | 81,665 |  |
| Total |  | $ | 179,194 |  |  | $ | 46,797 |  |  | $ | 225,991 |  |  | $ | 283,002 |  |  | $ | 44,376 |  |  | $ | 327,378 |  |

[0000950170-24-094602:notes:50]
|  |  | Six Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 104,594 |  |  | $ | 44,186 |  |  | $ | 148,780 |  |  | $ | 247,798 |  |  | $ | 42,954 |  |  | $ | 290,752 |  |
| Access & Aggregation Solutions |  |  | 121,889 |  |  |  | 29,330 |  |  |  | 151,219 |  |  |  | 173,817 |  |  |  | 25,720 |  |  |  | 199,537 |  |
| Subscriber Solutions |  |  | 133,984 |  |  |  | 18,181 |  |  |  | 152,165 |  |  |  | 143,805 |  |  |  | 17,196 |  |  |  | 161,001 |  |
| Total |  | $ | 360,467 |  |  | $ | 91,697 |  |  | $ | 452,164 |  |  | $ | 565,420 |  |  | $ | 85,870 |  |  | $ | 651,290 |  |

[0000950170-24-094602:notes:51]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2024, and December 31, 2023, related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $276.9 million and $314.8 million, respectively. As of June 30, 2024, approximately 57% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of June 30, 2024, are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-24-094602:notes:52]
[same as prior period, unchanged from 0000950170-24-057628:notes:51]

[0000950170-24-094602:notes:53]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Accounts receivable, net |  | $ | 186,176 |  |  | $ | 216,445 |  |
| Contract assets(1) |  | $ | 719 |  |  | $ | 691 |  |
| Unearned revenue |  | $ | 55,107 |  |  | $ | 46,731 |  |
| Non-current unearned revenue |  | $ | 26,584 |  |  | $ | 25,109 |  |

[0000950170-24-094602:notes:54]
[same as prior period, unchanged from 0000950170-24-057628:notes:53]

[0000950170-24-094602:notes:55]
[same as prior period, unchanged from 0000950170-24-057628:notes:54]

[0000950170-24-094602:notes:56]
The allowance for credit losses was $0.2 million and $0.4 million as of June 30, 2024, and December 31, 2023, respectively, related to accounts receivable.

[0000950170-24-094602:notes:57]
[same as prior period, unchanged from 0000950170-24-057628:notes:56]

[0000950170-24-094602:notes:58]
No allowance for credit losses was recorded for the three and six months ended June 30, 2024 and 2023 related to contract assets.

[0000950170-24-094602:notes:59]
[same as prior period, unchanged from 0000950170-24-057628:notes:58]

[0000950170-24-094602:notes:60]
The Company was party to a receivable purchase agreement with a third-party financial institution (“Factor”), which accelerates receivable collection and helps to better manage cash flow. As of December 31, 2023, no accounts receivable were factored under the agreement or held in the reserve account. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million and $0.6 million for the three and six months ended June 30, 2023.

[0000950170-24-094602:notes:61]
On December 19, 2023, the agreement with the Factor was terminated and the Company, entered into a receivables purchase agreement with a third-party financial institution (“New Factor”) to replace the Company’s prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The New Factor provides for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The New Factor qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. Total secured borrowings under the agreement were $17.3 million and $14.3 million as of June 30, 2024 and December 31, 2023, respectively, leaving $22.4 million and $25.4 million available for future borrowings as of June 30, 2024 and December 31, 2023, respectively. Accounts receivable pledged as collateral related to the secured borrowings were $21.2 million and $16.8 million as of June 30, 2024 and December 31, 2023, respectively. For the three and six months ended June 30, 2024, the Company incurred program fee expenses of $0.3 million and $0.6 million, respectively. As of June 30, 2024, the program fee rate was 6.88% percent.

[0000950170-24-094602:notes:62]
Of the outstanding unearned revenue balances as of December 31, 2023, $13.7 million and $33.1 million were recognized as revenue during the three and six months ended June 30, 2024, respectively. Of the $60.4 million of outstanding unearned revenue balances as of December 31, 2022, $24.8 million and $50.5 million were recognized as revenue during the three and six months ended June 30, 2023, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-094602:notes:63]
[same as prior period, unchanged from 0000950170-24-057628:notes:62]

[0000950170-24-094602:notes:64]
The Company’s effective tax rate changed from a benefit of 18.8% of pre-tax loss for the three months ended June 30, 2023, to an expense of 4.8% of pre-tax loss for the three months ended June 30, 2024, and changed from a benefit of 20.4% of pre-tax income for the six months ended June 30, 2023, to a benefit of 4.3% of pre-tax loss for the six months ended June 30, 2024. The change in the effective tax rate for the three and six months ended June 30, 2024, was driven primarily by non-deductible impairment charges and a loss jurisdiction for which no tax benefits were recognized on its pre-tax losses incurred during the six months ended June 30, 2024.

[0000950170-24-094602:notes:65]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of June 30, 2024, the Company had net deferred tax assets totaling $91.1 million, and a valuation allowance totaling $87.2 million against those deferred tax assets. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results, as well as the evaluation of evidence which requires significant judgment, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance, or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-094602:notes:66]
[same as prior period, unchanged from 0000950170-24-057628:notes:65]

[0000950170-24-094602:notes:67]
2024 Stock Incentive Plans

[0000950170-24-094602:notes:68]
At the annual meeting of stockholders held on May 8, 2024, the Company’s stockholders approved, upon recommendation of the Board of Directors, the adoption of the ADTRAN Holdings, Inc. 2024 Employee Stock Incentive Plan (“2024 Employee Plan”) and the ADTRAN Holdings, Inc. 2024 Directors Stock Plan (“2024 Directors Plan”). No additional awards will be granted under the Company’s previous stock incentive plans, including the 2020 Employee Stock Incentive Plan, the 2020 Directors Stock Plan, or the 2015 Employee Stock Incentive Plan. Outstanding awards granted under the Company's prior equity incentive plans will remain subject to the terms of such applicable plans, and shares under such plans that are cancelled or forfeited will be available for issuance under the 2024 Employee Plan or the 2024 Directors Plan, as applicable.

[0000950170-24-094602:notes:69]
Under the 2024 Employee Plan, the Company is authorized to issue 4.0 million shares of common stock to certain employees, key service providers and advisors through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock, any of which may be subject to performance-based conditions. RSUs and restricted stock granted under the 2024 Employee Plan will typically vest pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date. Stock options granted under the 2024 Employee Plan will typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Stock options, RSUs and restricted stock granted under the 2024 Employee Plan reduce the shares authorized for issuance under the 2024 Employee Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the prior employee stock incentive plans increase the shares authorized for issuance under the 2024 Employee Plan by one share of common stock for each share underlying the award.

[0000950170-24-094602:notes:70]
Under the 2024 Directors Plan, the Company is authorized to issue 0.7 million shares of common stock through stock options, restricted stock and RSUs to non-employee directors. Stock awards issued under the 2024 Directors Plan typically will become vested in full on the first anniversary of the grant date. Stock options issued under the 2024 Directors Plan will have a ten-year contractual term. Stock options, restricted stock and RSUs granted under the 2024 Directors Plan reduce the shares authorized for issuance under the 2024 Directors Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the prior directors stock plan increase the shares authorized for issuance under the 2024 Directors Plan by one share of common stock for each share underlying the award.

[0000950170-24-094602:notes:71]
As of June 30, 2024, 4.7 million shares were available for issuance pursuant to awards that may be made in the future under shareholder-approved equity plans.

[0000950170-24-094602:notes:72]
For the three months ended June 30, 2024 and 2023, stock-based compensation expense was $3.8 million and $4.3 million, respectively, and for the six months ended June 30, 2024 and 2023, stock-based compensation expense was $7.8 million and $8.0 million, respectively.

[0000950170-24-094602:notes:73]
[same as prior period, unchanged from 0000950170-24-057628:notes:67]

[0000950170-24-094602:notes:74]
The following table summarizes the PSUs, RSUs and restricted stock outstanding as of December 31, 2023, and June 30, 2024 and the changes that occurred during the six months ended June 30, 2024:

[0000950170-24-094602:notes:75]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2023 |  |  | 1,942 |  |  | $ | 17.46 |  |
| PSUs, RSUs and restricted stock granted |  |  | 1,097 |  |  | $ | 7.85 |  |
| PSUs, RSUs and restricted stock vested |  |  | (110 | ) |  | $ | 18.13 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (78 | ) |  | $ | 16.10 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, June 30, 2024 |  |  | 2,851 |  |  | $ | 13.79 |  |

[0000950170-24-094602:notes:76]
[same as prior period, unchanged from 0000950170-24-057628:notes:70]

[0000950170-24-094602:notes:77]
As of June 30, 2024, total unrecognized compensation expense related to non-vested portion of performance-based PSUs (considered probable), market-based PSUs, RSUs and restricted stock was approximately $16.2 million, which will be recognized over the remaining weighted-average period of 2.3 years. As of June 30, 2024, there was $11.1 million of unrecognized compensation expense related to unvested performance-based PSUs (not-considered probable), which will be recognized over the remaining requisite service period of 1.5 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0000950170-24-094602:notes:78]
[same as prior period, unchanged from 0000950170-24-057628:notes:73]

[0000950170-24-094602:notes:79]
The following table summarizes the ADTRAN Holdings, Inc. stock options outstanding as of December 31, 2023, and June 30, 2024, and the changes that occurred during the six months ended June 30, 2024:

[0000950170-24-094602:notes:80]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2023 |  |  | 3,894 |  |  | $ | 10.32 |  |  |  | 5.25 |  |  | $ | 3,087 |  |
| Stock options exercised |  |  | (36 | ) |  | $ | 6.06 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (140 | ) |  | $ | 6.45 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (217 | ) |  | $ | 8.39 |  |  |  |  |  |  |  |
| Stock options outstanding, June 30, 2024 |  |  | 3,501 |  |  | $ | 10.64 |  |  |  | 4.88 |  |  | $ | 36 |  |
| Stock options exercisable, June 30, 2024 |  |  | 1,369 |  |  | $ | 12.72 |  |  |  | 1.34 |  |  | $ | — |  |

[0000950170-24-094602:notes:81]
As of June 30, 2024, there was $5.3 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 1.4 years.

[0000950170-24-094602:notes:82]
[same as prior period, unchanged from 0000950170-24-057628:notes:77]

[0000950170-24-094602:notes:83]
[same as prior period, unchanged from 0000950170-24-057628:notes:78]

[0000950170-24-094602:notes:84]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between the Company's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on June 30, 2024. The amount of aggregate intrinsic value was $36 thousand as of June 30, 2024, which will change based on the fair market value of the Company's stock. The total pre-tax intrinsic value of options exercised during the six months ended June 30, 2024, and 2023 were $34 thousand and $43 thousand, respectively. During the three and six months ended June 30, 2024, 0.1 million stock options vested. No stock options vested during the three and six months ended June 30, 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-24-094602:notes:85]
5. INVESTMENTS

[0000950170-24-094602:notes:86]
Debt Securities and Other Investments

[0000950170-24-094602:notes:87]
The Company did not have any debt securities and other investments as of June 30, 2024.

[0000950170-24-094602:notes:88]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to its debt securities:

[0000950170-24-094602:notes:89]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4 |  |
| Gross realized loss on debt securities |  |  | — |  |  |  | (27 | ) |  |  | — |  |  |  | (39 | ) |
| Total loss recognized, net |  | $ | — |  |  | $ | (27 | ) |  | $ | — |  |  | $ | (35 | ) |

[0000950170-24-094602:notes:90]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0000950170-24-094602:notes:91]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Unrealized gain on equity securities held |  | $ | 4 |  |  | $ | 1,288 |  |  | $ | 127 |  |  | $ | 2,535 |  |
| Realized gain on equity securities sold |  |  | 868 |  |  |  | 1 |  |  |  | 2,998 |  |  |  | 14 |  |
| Total gain recognized, net |  | $ | 872 |  |  | $ | 1,289 |  |  | $ | 3,125 |  |  | $ | 2,549 |  |

[0000950170-24-094602:notes:92]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-24-094602:notes:93]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-24-094602:notes:94]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly and

[0000950170-24-094602:notes:95]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-24-094602:notes:96]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-24-094602:notes:97]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,433 |  |  | $ | 5,433 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 955 |  |  |  | 955 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 29,204 |  |  |  | 29,204 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,592 |  |  | $ | 35,592 |  |  | $ | — |  |  | $ | — |  |

[0000950170-24-094602:notes:98]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,302 |  |  | $ | 5,302 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 905 |  |  |  | 905 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,838 |  |  |  | 26,838 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,045 |  |  | $ | 33,045 |  |  | $ | — |  |  | $ | — |  |

[0000950170-24-094602:notes:99]
Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-24-094602:notes:100]
[same as prior period, unchanged from 0000950170-24-057628:notes:95]

[0000950170-24-094602:notes:101]
[same as prior period, unchanged from 0000950170-24-057628:notes:96]

[0000950170-24-094602:notes:102]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Raw materials |  | $ | 120,873 |  |  | $ | 152,140 |  |
| Work in process |  |  | 12,231 |  |  |  | 17,239 |  |
| Finished goods |  |  | 154,756 |  |  |  | 192,916 |  |
| Total inventory, net |  | $ | 287,860 |  |  | $ | 362,295 |  |

[0000950170-24-094602:notes:103]
[same as prior period, unchanged from 0000950170-24-057628:notes:98]

[0000950170-24-094602:notes:104]
During the three and six months ended June 30, 2024, we incurred total charges of $0.1 million and $8.9 million, respectively, as a result of a strategy shift which included discontinuance of certain product lines in connection with the Business Efficiency Program of which, $0.1 million and $4.1 million, respectively, relates to inventory write-downs and zero and $4.8 million, respectively, relates to other charges all of which are included in cost of revenue in the Condensed Consolidated Statements of Loss.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-24-094602:notes:105]
[same as prior period, unchanged from 0000950170-24-057628:notes:100]

[0000950170-24-094602:notes:106]
[same as prior period, unchanged from 0000950170-24-057628:notes:101]

[0000950170-24-094602:notes:107]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Engineering and other equipment |  | $ | 183,253 |  |  | $ | 183,336 |  |
| Building |  |  | 79,433 |  |  |  | 79,215 |  |
| Computer hardware and software |  |  | 122,273 |  |  |  | 101,572 |  |
| Building and land improvements |  |  | 58,324 |  |  |  | 58,238 |  |
| Furniture and fixtures |  |  | 21,451 |  |  |  | 21,368 |  |
| Land |  |  | 5,224 |  |  |  | 5,242 |  |
| Total property, plant and equipment |  |  | 469,958 |  |  |  | 448,971 |  |
| Less: accumulated depreciation |  |  | (335,380 | ) |  |  | (325,951 | ) |
| Total property, plant and equipment, net |  | $ | 134,578 |  |  | $ | 123,020 |  |

[0000950170-24-094602:notes:108]
[same as prior period, unchanged from 0000950170-24-057628:notes:103]

[0000950170-24-094602:notes:109]
Depreciation expense was $8.1 million and $6.2 million for the three months ended June 30, 2024 and 2023, respectively, and $15.8 million and $13.8 million for the six months ended June 30, 2024 and 2023, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-24-094602:notes:110]
[same as prior period, unchanged from 0000950170-24-057628:notes:105]

[0000950170-24-094602:notes:111]
The changes in the carrying amount of goodwill for the six months ended June 30, 2024, are as follows:

[0000950170-24-094602:notes:112]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2023 |  | $ | 297,031 |  |  | $ | 56,384 |  |  | $ | 353,415 |  |
| Goodwill impairment |  |  | (290,528 | ) |  |  | — |  |  |  | (290,528 | ) |
| Foreign currency translation adjustments |  |  | (6,503 | ) |  |  | (1,487 | ) |  |  | (7,990 | ) |
| As of June 30, 2024 |  | $ | — |  |  | $ | 54,897 |  |  | $ | 54,897 |  |

[0000950170-24-094602:notes:113]
[same as prior period, unchanged from 0000950170-24-057628:notes:108]

[0000950170-24-094602:notes:114]
[same as prior period, unchanged from 0000950170-24-057628:notes:109]

[0000950170-24-094602:notes:115]
[same as prior period, unchanged from 0000950170-24-057628:notes:110]

[0000950170-24-094602:notes:116]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of each reporting unit using a combination of an income approach and a market-based peer group analysis. The significant inputs and assumptions used in the determination of the fair value of our reporting units based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to cash flow projections, discount rate, peer group determination and market multiple selection. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the first quarter of 2024.

[0000950170-24-094602:notes:117]
No impairment of goodwill was recognized during the three months ended June 30, 2024. Goodwill impairment recognized during the six months ended June 30, 2024, was $292.6 million. No impairment of goodwill was recognized during the three and six months ended June 30, 2023. As of June 30, 2024, accumulated goodwill impairment losses totaled $330.5 million.

[0000950170-24-094602:notes:118]
The Company will continue to monitor its stock price, operating results and other macroeconomic factors to determine if there is indication of a decline in fair value requiring an event driven assessment of the recoverability of its remaining goodwill prior to the annual assessment.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-24-094602:notes:119]
[same as prior period, unchanged from 0000950170-24-057628:notes:113]

[0000950170-24-094602:notes:120]
[same as prior period, unchanged from 0000950170-24-057628:notes:114]

[0000950170-24-094602:notes:121]
|  |  |  |  | As of June 30, 2024 |  |  | As of December 31, 2023 |  |
| (In thousands) | Weighted Average Useful Life(in years) |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Developed technology |  | 8.5 |  |  | $ | 320,849 |  |  | $ | (78,762 | ) |  | $ | 242,087 |  |  | $ | 329,369 |  |  | $ | (61,271 | ) |  | $ | 268,098 |  |
| Customer relationships |  | 10.9 |  |  | $ | 52,587 |  |  | $ | (16,863 | ) |  | $ | 35,724 |  |  | $ | 54,856 |  |  | $ | (15,943 | ) |  | $ | 38,913 |  |
| Trade names |  | 3.0 |  |  |  | 28,901 |  |  |  | (21,391 | ) |  |  | 7,510 |  |  |  | 29,689 |  |  |  | (16,379 | ) |  |  | 13,310 |  |
| Backlog |  | 1.6 |  |  |  | 55,868 |  |  |  | (52,343 | ) |  |  | 3,525 |  |  |  | 57,391 |  |  |  | (52,022 | ) |  |  | 5,369 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (4,125 | ) |  |  | 1,775 |  |  |  | 5,900 |  |  |  | (3,797 | ) |  |  | 2,103 |  |
| Licensing agreements |  | 8.5 |  |  |  | 560 |  |  |  | (388 | ) |  |  | 172 |  |  |  | 560 |  |  |  | (368 | ) |  |  | 192 |  |
| Patents |  | 7.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 500 |  |  |  | (500 | ) |  |  | — |  |
| Total |  |  |  | $ | 464,665 |  |  | $ | (173,872 | ) |  | $ | 290,793 |  |  | $ | 478,265 |  |  | $ | (150,280 | ) |  | $ | 327,985 |  |

[0000950170-24-094602:notes:122]
Intangible assets are reviewed for impairment whenever events and circumstances indicate impairment may have occurred. In connection with the preparation of the financial statements for each period in 2024 and 2023, the Company assessed impairment triggers related to intangible assets. No impairment losses related to intangible assets were recorded during the three and six months ended June 30, 2024 and 2023.

[0000950170-24-094602:notes:123]
Amortization expense was $14.4 million and $26.5 million in the three months ended June 30, 2024 and 2023, respectively, and $29.0 million and $52.3 million in the six months ended June 30, 2024 and 2023, respectively and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.

[0000950170-24-094602:notes:124]
[same as prior period, unchanged from 0000950170-24-057628:notes:118]

[0000950170-24-094602:notes:125]
|  |  | As of |  |
| (In thousands) |  | June 30, 2024 |  |
| 2024 |  | $ | 28,814 |  |
| 2025 |  |  | 46,163 |  |
| 2026 |  |  | 42,915 |  |
| 2027 |  |  | 41,554 |  |
| 2028 |  |  | 41,408 |  |
| Thereafter |  |  | 89,939 |  |
| Total |  | $ | 290,793 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-24-094602:notes:126]
[same as prior period, unchanged from 0000950170-24-057628:notes:120]

[0000950170-24-094602:notes:127]
The Company has certain forward rate agreements to hedge foreign currency exposure of expected future cash flows in foreign currency. The Company does not hold or issue derivative instruments for trading or other speculative purposes. Derivatives are initially recognized at fair value on the date a derivative contract is entered into and are subsequently re-measured to their fair value at the end of each reporting period. All changes in the fair value of derivative instruments are recognized as other (expense) income in the Consolidated Statements of Loss and are classified as Level II under the fair value hierarchy. The derivative instruments are not subject to master netting agreements and are not offset in the Consolidated Balance Sheets. We are exposed to risk from credit-related losses resulting from nonperformance by counterparties to our financial instruments. We perform credit evaluations of our counterparties under forward exchange contracts and expect all counterparties to meet their obligations. We have not experienced credit losses from our counterparties. As of June 30, 2024, the Company had 43 forward rate contracts outstanding.

[0000950170-24-094602:notes:128]
[same as prior period, unchanged from 0000950170-24-057628:notes:122]

[0000950170-24-094602:notes:129]
On November 3, 2022, the Company entered into a euro/U.S. dollar forward contract arrangement ("Initial Forward") with Wells Fargo Bank, N.A. (“Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million converted to U.S. dollars at a daily fixed forward rate averaging EUR/USD 1.03. The aggregate amount of €160.0 million is divided into eight quarterly tranches of €20.0 million, which commenced in the fourth quarter of 2022. During the six months ended June 30, 2024, the Company settled two €20.0 million forward contract tranches and the remaining amount will be divided into two quarterly tranches of €20.0 million over the remainder of 2024. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-24-094602:notes:130]
On March 21, 2023, the Company entered into a Euro/U.S. dollar forward contract arrangements (“Forward”) with the Hedge Counterparty. Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of €160.0 million converted to U.S. dollars at a daily fixed forward rate ranging from $1.09 to $1.10 per €1.00. During the six months ended June 30, 2024, the Company settled two $20.0 million forward contract tranches and the remaining amount will be divided into two quarterly tranches of $20.0 million. These forward contracts were executed on March 21, 2023 (to sell EUR/buy USD) and were entered into for the purpose of unwinding the Initial Forward (to buy EUR/sell USD). The drawdown dates of the Initial Forward are set to the same date as the maturity of the new offsetting Forward.

[0000950170-24-094602:notes:131]
The fair values of the Company's derivative instruments recorded in the Condensed Consolidated Balance Sheet as of June 30, 2024 and December 31, 2023 were as follows:

[0000950170-24-094602:notes:132]
| (In thousands) |  | Balance Sheet Location |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  | $ | 2,700 |  |  | $ | 7,125 |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  | $ | (80 | ) |  | $ | (2,277 | ) |
| Total derivatives |  |  |  | $ | 2,620 |  |  | $ | 4,848 |  |

[0000950170-24-094602:notes:133]
The change in the fair values of the Company's derivative instruments recorded in the Condensed Consolidated Statements of Loss during the three and six months ended June 30, 2024 and 2023 were as follows:

[0000950170-24-094602:notes:134]
|  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  |  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | Income StatementLocation |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other (expense) income, net |  | $ | (735 | ) |  | $ | 158 |  |  | $ | 31 |  |  | $ | 89 |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-24-094602:notes:135]
11. CREDIT AGREEMENTS

[0000950170-24-094602:notes:136]
The carrying amounts of the Company's non-current revolving credit facility in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-24-094602:notes:137]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Wells Fargo credit agreement |  | $ | 190,273 |  |  | $ | 195,000 |  |
| Total non-current revolving credit facility |  | $ | 190,273 |  |  | $ | 195,000 |  |

[0000950170-24-094602:notes:138]
As of June 30, 2024, the weighted average interest rate on our revolving credit agreements was 8.51%.

[0000950170-24-094602:notes:139]
Wells Fargo Credit Agreement

[0000950170-24-094602:notes:140]
On July 18, 2022, ADTRAN, Inc., as the borrower ("US Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (as amended from time to time, the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount ($100.0 million of which is available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below), as well as the $50.0 million delayed draw term loan facility described below. The term of the delayed draw term loan facility expires on August 9, 2024.

[0000950170-24-094602:notes:141]
On August 9, 2023, ("First Amendment Effective Date") the Company and ADTRAN, Inc. entered into a First Amendment to Credit Agreement (“First Amendment”).

[0000950170-24-094602:notes:142]
The First Amendment among other things, provided for a new $50.0 million delayed draw term loan facility (“DDTL”), which (subject to certain conditions) is available for borrowing in the event that at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date have been tendered (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase shares of Adtran Networks. The DDTL is available for borrowing from the occurrence of a Springing Covenant Event through August 9, 2024.

[0000950170-24-094602:notes:143]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-24-094602:notes:144]
On January 16, 2024 ("Second Amendment Effective Date"), the Company and ADTRAN, Inc. entered into a Second Amendment to Credit Agreement and First Amendment to Collateral Agreement ("Second Amendment"). The Second Amendment, among other things, provided the Company and its subsidiaries with additional covenant headroom for the fourth quarter of 2023 through and including the third quarter of 2024 ("Covenant Relief Period") and revised and/or added certain other financial covenants which (as later modified by the Fourth Amendment) are described below.

[0000950170-24-094602:notes:145]
On March 12, 2024, the Company and ADTRAN, Inc. entered into a Third Amendment to Credit Agreement ("Third Amendment"). The Third Amendment, among other things, amended the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024, and June 30, 2024.

[0000950170-24-094602:notes:146]
On June 4, 2024, the Company, ADTRAN, Inc., and Adtran Networks entered into a Fourth Amendment to Credit Agreement ("Fourth Amendment"). The Fourth Amendment, among other things, created a new sublimit under the existing $400.0 million revolving commitments, in an aggregate amount of $100.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold is initially $75 million and may be lowered from time to time pursuant to the terms of the Fourth Amendment. The existing swing line sublimit and letter of credit sublimit under the Credit Agreement remained available to the US Borrower (and not to Adtran Networks) after giving effect to the Fourth Amendment. Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

[0000950170-24-094602:notes:147]
As of June 30, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $190.3 million, of which $115.0 million were borrowed by ADTRAN, Inc. and $75.3 million were borrowed under the Subline by Adtran Networks. As of June 30, 2024, there were no borrowings under the DDTL. The credit facilities provided under the Credit Agreement mature in July 2027, but the US Borrower has an option to request extensions subject to customary conditions. In addition, the US Borrower may utilize up to $50.0 million of the $400.0 million total revolving facility for the issuance of letters of credit. As of June 30, 2024, we had a total of $3.7 million in letters of credit under ADTRAN, Inc. outstanding under the Credit Agreement, leaving a net amount (after giving effect to the $190.3 million of outstanding borrowings described above) of $206.0 million available for future borrowings; however, as of June 30, 2024, the Company was limited to additional borrowings of $16.4 million based on debt covenant compliance metrics. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of June 30, 2024, the Company was in compliance with all covenants.

[0000950170-24-094602:notes:148]
Revolving Line of Credit Interest Rate

[0000950170-24-094602:notes:149]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin), at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period (as defined below), an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.15% per annum).

[0000950170-24-094602:notes:150]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.

[0000950170-24-094602:notes:151]
“Adjusted Term SOFR” means Term SOFR for the applicable interest period plus 0.10% per annum. Adjusted Term SOFR is subject to a floor of 0.00% per annum.

[0000950170-24-094602:notes:152]
All Euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.25% per annum).

[0000950170-24-094602:notes:153]
In addition, (x) if on or prior to December 31, 2024, we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-094602:notes:154]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

[0000950170-24-094602:notes:155]
The “Applicable Margin Interest Period” means the period commencing on the Second Amendment Effective Date and ending on the first date when each of the following conditions have been met: (a) the Covenant Relief Period has ended, (b) since the Second Amendment Effective Date, the borrowers have repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the borrowers have reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million, and (d) the borrowers are in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-24-094602:notes:156]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

[0000950170-24-094602:notes:157]
DDTL Interest Rate

[0000950170-24-094602:notes:158]
All U.S. dollar borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to either (a) the Base Rate plus an applicable margin ranging from 0.90% to 1.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 2.40% per annum), or (b) Adjusted Term SOFR plus an applicable margin ranging from 1.90% to 2.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.40% per annum).

[0000950170-24-094602:notes:159]
In addition, (x) if on or prior to December 31, 2024, we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025, we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-094602:notes:160]
In addition to paying interest on outstanding principal under the DDTL loan, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment.

[0000950170-24-094602:notes:161]
Covenants Under the Credit Agreement

[0000950170-24-094602:notes:162]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable):

[0000950170-24-094602:notes:163]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Total Net Leverage Ratio may not exceed 5.00x.

[0000950170-24-094602:notes:164]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

[0000950170-24-094602:notes:165]
•
In the fiscal quarter in which a Springing Covenant Event occurs and the three consecutive quarterly test periods thereafter, (“Springing Covenant Period”), the following covenant levels:

[0000950170-24-094602:notes:166]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

[0000950170-24-094602:notes:167]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

[0000950170-24-094602:notes:168]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

[0000950170-24-094602:notes:169]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

[0000950170-24-094602:notes:170]
•
If a Springing Covenant Period is not in effect, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

[0000950170-24-094602:notes:171]
•
From December 31, 2023, through and including March 31, 2024: 3.25x.

[0000950170-24-094602:notes:172]
•
From April 1, 2024, through and including June 30, 2024: 3.50x.

[0000950170-24-094602:notes:173]
•
From July 1, 2024, and thereafter: 3.25x.

[0000950170-24-094602:notes:174]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not be less than 1.25x.

[0000950170-24-094602:notes:175]
•
During the Covenant Relief Period or a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million.

[0000950170-24-094602:notes:176]
All obligations under the Credit Agreement (including under the Subline) are guaranteed by ADTRAN, Inc., the Company and certain subsidiaries of ADTRAN, Inc. (“Full Facility Guarantors”). To secure such guarantees, ADTRAN, Inc. and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and ADTRAN, Inc. has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries ("Subline Guarantors") have provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Adtran Networks has also granted security interests in favor of the Administrative Agent over substantially all of its tangible and intangible assets, to secure solely its obligations under the Subline. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

[0000950170-24-094602:notes:177]
During the Covenant Relief Period, the Company is not permitted to make certain dividend payments to the Company's Stockholders or certain other Restricted Payments. However, the Company is permitted to make the Recurring Compensation Payment to each Adtran Networks shareholder (other than the Company), pursuant to the terms of the DPLTA.

[0000950170-24-094602:notes:178]
Furthermore, the Credit Agreement, as amended, contain customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts; however, certain of the exceptions and carveouts are not permitted to be used during the Covenant Relief Period. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-24-094602:notes:179]
[same as prior period, unchanged from 0000950170-24-057628:notes:172]

[0000950170-24-094602:notes:180]
[same as prior period, unchanged from 0000950170-24-057628:notes:173]

[0000950170-24-094602:notes:181]
We maintain a defined benefit pension plan covering employees in certain foreign countries. The Company's net non-current pension liability for all defined benefit pension plans totaled $11.5 million and $12.5 million as of June 30, 2024, and December 31, 2023, respectively, and the net current pension liability for all defined benefit pension plans totaled $0.1 million as of June 30, 2024, and December 31, 2023, which is included in accounts payable on the Condensed Consolidated Balance Sheets. The Company's defined benefit pension liability represents the projected benefit obligation, which is the actuarial present value of the vested benefits to which the employee is currently entitled based on the employee's expected date of retirement.

[0000950170-24-094602:notes:182]
[same as prior period, unchanged from 0000950170-24-057628:notes:175]

[0000950170-24-094602:notes:183]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Service cost |  | $ | 333 |  |  | $ | 404 |  |  | $ | 673 |  |  | $ | 802 |  |
| Interest cost |  |  | 281 |  |  |  | (33 | ) |  |  | 566 |  |  |  | (66 | ) |
| Expected return on plan assets |  |  | (354 | ) |  |  | 59 |  |  |  | (713 | ) |  |  | 118 |  |
| Amortization of actuarial losses |  |  | 2 |  |  |  | 6 |  |  |  | 5 |  |  |  | 13 |  |
| Net periodic pension cost |  | $ | 262 |  |  | $ | 436 |  |  | $ | 531 |  |  | $ | 867 |  |

[0000950170-24-094602:notes:184]
The components of net periodic pension cost, other than the service cost component, are included in other (expense) income, net in the Condensed Consolidated Statements of Loss. Service cost is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss. The Company made contributions to the defined benefit pension plans totaling $2.2 million and $1.8 million during the six months ended June 30, 2024 and 2023, respectively. Contributions to the defined benefit pension plans for the remainder of 2024 will be limited to benefit payments to retirees which are paid out of the operating cash flows of the Company and are expected to be approximately $2.2 million.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-24-094602:notes:185]
[same as prior period, unchanged from 0000950170-24-057628:notes:178]

[0000950170-24-094602:notes:186]
[same as prior period, unchanged from 0000950170-24-057628:notes:179]

[0000950170-24-094602:notes:187]
[same as prior period, unchanged from 0000950170-24-057628:notes:180]

[0000950170-24-094602:notes:188]
|  |  | Three Months Ended June 30, 2024 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of March 31, 2024 |  | $ | (382 | ) |  | $ | (2,566 | ) |  | $ | 32,219 |  |  | $ | 385 |  |  | $ | 29,656 |  |
| Other comprehensive loss before reclassifications |  |  | (5 | ) |  |  | — |  |  |  | (1,375 | ) |  |  | — |  |  |  | (1,380 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 5 |  |  |  | (7 | ) |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| Net current period other comprehensive loss |  |  | — |  |  |  | (7 | ) |  |  | (1,375 | ) |  |  | — |  |  |  | (1,382 | ) |
| Balance as of June 30, 2024 |  | $ | (382 | ) |  | $ | (2,573 | ) |  | $ | 30,844 |  |  | $ | 385 |  |  | $ | 28,274 |  |

[0000950170-24-094602:notes:189]
|  |  | Three Months Ended June 30, 2023 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of March 31, 2023 |  | $ | (767 | ) |  | $ | (981 | ) |  | $ | 35,889 |  |  | $ | 385 |  |  | $ | 34,526 |  |
| Other comprehensive income before reclassifications |  |  | 15 |  |  |  | — |  |  |  | 6,940 |  |  |  | — |  |  |  | 6,955 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (21 | ) |  |  | 23 |  |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Net current period other comprehensive income |  |  | (6 | ) |  |  | 23 |  |  |  | 6,940 |  |  |  | — |  |  |  | 6,957 |  |
| Less: Comprehensive income attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Balance as of June 30, 2023 |  | $ | (773 | ) |  | $ | (958 | ) |  | $ | 42,829 |  |  | $ | 385 |  |  | $ | 41,483 |  |

[0000950170-24-094602:notes:190]
|  |  | Six Months Ended June 30, 2024 |  |
| (In thousands) |  | UnrealizedGains (Losses)onAvailable-for-SaleSecurities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2023 |  | $ | (382 | ) |  | $ | (2,506 | ) |  | $ | 49,964 |  |  | $ | 385 |  |  | $ | 47,461 |  |
| Other comprehensive loss before reclassifications |  |  | (124 | ) |  |  | — |  |  |  | (19,120 | ) |  |  | — |  |  |  | (19,244 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 124 |  |  |  | (67 | ) |  |  | — |  |  |  | — |  |  |  | 57 |  |
| Net current period other comprehensive loss |  |  | — |  |  |  | (67 | ) |  |  | (19,120 | ) |  |  | — |  |  |  | (19,187 | ) |
| Less: Comprehensive Loss attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Balance as of June 30, 2024 |  | $ | (382 | ) |  | $ | (2,573 | ) |  | $ | 30,844 |  |  | $ | 385 |  |  | $ | 28,274 |  |

[0000950170-24-094602:notes:191]
|  |  | Six Months Ended June 30, 2023 |  |
| (In thousands) |  | UnrealizedGains (Losses) on Available-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2022 |  | $ | (836 | ) |  | $ | (1,016 | ) |  | $ | 27,593 |  |  | $ | 385 |  |  | $ | 26,126 |  |
| Other comprehensive loss before reclassifications |  |  | 98 |  |  |  | — |  |  |  | 15,618 |  |  |  | — |  |  |  | 15,716 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (35 | ) |  |  | 58 |  |  |  | — |  |  |  | — |  |  |  | 23 |  |
| Net current period other comprehensive (loss) income |  |  | 63 |  |  |  | 58 |  |  |  | 15,618 |  |  |  | — |  |  |  | 15,739 |  |
| Less: Comprehensive income attributable to non-controllinginterest, net of tax |  |  | — |  |  |  | — |  |  |  | 382 |  |  |  | — |  |  |  | 382 |  |
| Balance as of June 30, 2023 |  | $ | (773 | ) |  | $ | (958 | ) |  | $ | 42,829 |  |  | $ | 385 |  |  | $ | 41,483 |  |

[0000950170-24-094602:notes:192]
[same as prior period, unchanged from 0000950170-24-057628:notes:183]

[0000950170-24-094602:notes:193]
|  |  | Three Months Ended June 30, 2024 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in theStatement Where NetLoss Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (7 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial gain |  |  | 10 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | 3 |  |  |  |
| Tax expense |  |  | (1 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2 |  |  |  |

[0000950170-24-094602:notes:194]
(1)
A part of the computation of net periodic pension cost, which is included in other (expense) income, net in the Condensed Consolidated Statements of Loss.

[0000950170-24-094602:notes:195]
|  |  | Three Months Ended June 30, 2023 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Loss Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 28 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial loss |  |  | (33 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (5 | ) |  |  |
| Tax benefit |  |  | 3 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (2 | ) |  |  |

[0000950170-24-094602:notes:196]
|  |  | Six Months Ended June 30, 2024 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Loss |  |  | Affected Line Item in the Statement Where Net LossIs Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (168 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial gain |  |  | 97 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (71 | ) |  |  |
| Tax benefit |  |  | 14 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (57 | ) |  |  |

[0000950170-24-094602:notes:197]
|  |  | Six Months Ended June 30, 2023 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net LossIs Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 46 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial loss |  |  | (84 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (38 | ) |  |  |
| Tax benefit |  |  | 15 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (23 | ) |  |  |

[0000950170-24-094602:notes:198]
[same as prior period, unchanged from 0000950170-24-057628:notes:187]

[0000950170-24-094602:notes:199]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized (loss) gain on available-for-sale securities |  | $ | (7 | ) |  | $ | 2 |  |  | $ | (5 | ) |  | $ | 20 |  |  | $ | (5 | ) |  | $ | 15 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net gain (loss) |  |  | 7 |  |  |  | (2 | ) |  |  | 5 |  |  |  | (28 | ) |  |  | 7 |  |  |  | (21 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) gain |  |  | (10 | ) |  |  | 3 |  |  |  | (7 | ) |  |  | 33 |  |  |  | (10 | ) |  |  | 23 |  |
| Foreign currency translation adjustments |  |  | (1,375 | ) |  |  | — |  |  |  | (1,375 | ) |  |  | 6,940 |  |  |  | — |  |  |  | 6,940 |  |
| Total Other Comprehensive (Loss) Income |  | $ | (1,385 | ) |  | $ | 3 |  |  | $ | (1,382 | ) |  | $ | 6,965 |  |  | $ | (8 | ) |  | $ | 6,957 |  |

[0000950170-24-094602:notes:200]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized (loss) gain on available-for-sale securities |  | $ | (168 | ) |  | $ | 44 |  |  | $ | (124 | ) |  | $ | 129 |  |  | $ | (31 | ) |  | $ | 98 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net gain (loss) |  |  | 168 |  |  |  | (44 | ) |  |  | 124 |  |  |  | (46 | ) |  |  | 12 |  |  |  | (34 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) gain |  |  | (97 | ) |  |  | 30 |  |  |  | (67 | ) |  |  | 84 |  |  |  | (27 | ) |  |  | 57 |  |
| Foreign currency translation adjustments |  |  | (19,120 | ) |  |  | — |  |  |  | (19,120 | ) |  |  | 15,618 |  |  |  | — |  |  |  | 15,618 |  |
| Total Other Comprehensive (Loss) Income |  | $ | (19,217 | ) |  | $ | 30 |  |  | $ | (19,187 | ) |  | $ | 15,785 |  |  | $ | (46 | ) |  | $ | 15,739 |  |


## us-gaap:RedeemableNoncontrollingInterestTableTextBlock

[0000950170-24-094602:notes:201]
The following table summarizes the redeemable non-controlling interest activity for the six months ended June 30, 2024 and for the year ended December 31, 2023:

[0000950170-24-094602:notes:202]
|  |  | Six Months Ended |  |  | For the Year Ended |  |
| (In thousands) |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Balance at beginning of period |  | $ | 451,756 |  |  | $ | — |  |
| Reclassification of non-controlling interests |  |  | — |  |  |  | 443,757 |  |
| Fair value on redemption of redeemable non-controlling interest |  |  | (30 | ) |  |  | (1,657 | ) |
| Net income attributable to redeemable non-controlling interests |  |  | 5,734 |  |  |  | 11,525 |  |
| Annual recurring compensation earned |  |  | (5,734 | ) |  |  | (11,525 | ) |
| Adtran Networks stock option exercises |  |  | — |  |  |  | 52 |  |
| Translation adjustment |  |  | (11,983 | ) |  |  | 9,604 |  |
| Balance at end of period |  | $ | 439,743 |  |  | $ | 451,756 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-094602:notes:203]
[same as prior period, unchanged from 0000950170-24-057628:notes:191]

[0000950170-24-094602:notes:204]
[same as prior period, unchanged from 0000950170-24-057628:notes:192]

[0000950170-24-094602:notes:205]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss attributable to ADTRAN Holdings, Inc. |  | $ | (49,865 | ) |  | $ | (39,097 | ) |  | $ | (374,415 | ) |  | $ | (79,180 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 78,852 |  |  |  | 78,366 |  |  |  | 78,803 |  |  |  | 78,364 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 78,852 |  |  |  | 78,366 |  |  |  | 78,803 |  |  |  | 78,364 |  |
| Loss per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.63 | ) |  | $ | (0.50 | ) |  | $ | (4.75 | ) |  | $ | (1.01 | ) |
| Loss per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.63 | ) |  | $ | (0.50 | ) |  | $ | (4.75 | ) |  | $ | (1.01 | ) |

[0000950170-24-094602:notes:206]
For the three months ended June 30, 2024 and 2023, 1.4 million and 0.8 million shares, respectively, and for the six months ended June 30, 2024 and 2023, 1.3 million and 0.3 million, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0000950170-24-094602:notes:207]
For the three months ended June 30, 2024 and 2023, 5.0 million and 2.2 million stock options, respectively, and for the six months ended June 30, 2024 and 2023, 4.2 million and 1.0 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the applicable period, making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-094602:notes:208]
[same as prior period, unchanged from 0000950170-24-057628:notes:196]

[0000950170-24-094602:notes:209]
[same as prior period, unchanged from 0000950170-24-057628:notes:197]

[0000950170-24-094602:notes:210]
[same as prior period, unchanged from 0000950170-24-057628:notes:198]

[0000950170-24-094602:notes:211]
[same as prior period, unchanged from 0000950170-24-057628:notes:199]

[0000950170-24-094602:notes:212]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain, other income (expense), net and income tax benefit are reported on a consolidated basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-24-094602:notes:213]
[same as prior period, unchanged from 0000950170-24-057628:notes:201]

[0000950170-24-094602:notes:214]
|  |  | Three Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 179,194 |  |  | $ | 54,594 |  |  | $ | 283,002 |  |  | $ | 66,042 |  |
| Services & Support |  |  | 46,797 |  |  |  | 26,981 |  |  |  | 44,376 |  |  |  | 26,511 |  |
| Total |  | $ | 225,991 |  |  | $ | 81,575 |  |  | $ | 327,378 |  |  | $ | 92,553 |  |

[0000950170-24-094602:notes:215]
|  |  | Six Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 360,467 |  |  | $ | 100,759 |  |  | $ | 565,420 |  |  | $ | 129,330 |  |
| Services & Support |  |  | 91,697 |  |  |  | 53,071 |  |  |  | 85,870 |  |  |  | 51,031 |  |
| Total |  | $ | 452,164 |  |  | $ | 153,830 |  |  | $ | 651,290 |  |  | $ | 180,361 |  |

[0000950170-24-094602:notes:216]
For each of the three months ended June 30, 2024 and 2023, $2.4 million and $1.5 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the six months ended June 30, 2024 and 2023, $4.5 million and $2.9 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the three months ended June 30, 2024 and 2023, $0.1 million and $2 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment. For the six months ended June 30, 2024 and 2023, $0.1 million and $5 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0000950170-24-094602:notes:217]
[same as prior period, unchanged from 0000950170-24-057628:notes:204]

[0000950170-24-094602:notes:218]
[same as prior period, unchanged from 0000950170-24-057628:notes:205]

[0000950170-24-094602:notes:219]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| United States |  | $ | 107,604 |  |  | $ | 132,294 |  |  | $ | 190,894 |  |  | $ | 263,760 |  |
| United Kingdom |  |  | 43,560 |  |  |  | 52,071 |  |  |  | 96,300 |  |  |  | 109,468 |  |
| Germany |  |  | 24,542 |  |  |  | 75,538 |  |  |  | 64,283 |  |  |  | 151,824 |  |
| Other international |  |  | 50,285 |  |  |  | 67,475 |  |  |  | 100,687 |  |  |  | 126,238 |  |
| Total |  | $ | 225,991 |  |  | $ | 327,378 |  |  | $ | 452,164 |  |  | $ | 651,290 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-24-094602:notes:220]
[same as prior period, unchanged from 0000950170-24-057628:notes:207]

[0000950170-24-094602:notes:221]
The Company's products generally include warranties of 90 days to five years for product defects. The Company accrues for warranty returns at the time of product shipment based on its historical return rate and estimate of the cost to repair or replace the defective products. The Company engages in extensive product quality programs and processes, including actively monitoring and evaluating the quality of its component suppliers. The increasing complexity of the Company's products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should the Company's actual experience relative to these factors be worse than its estimates, the Company will record additional warranty expense. The liability for warranty obligations totaled $6.0 million and $6.4 million as of June 30, 2024 and December 31, 2023, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. The warranty expense and write-off activity for the three and six months ended June 30, 2024 and 2023 are summarized as follows:

[0000950170-24-094602:notes:222]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 6,221 |  |  | $ | 7,200 |  |  | $ | 6,445 |  |  | $ | 7,196 |  |
| Plus: Amounts charged to cost and expenses |  |  | 738 |  |  |  | 459 |  |  |  | 1,384 |  |  |  | 1,539 |  |
| Plus: Foreign currency translation adjustments |  |  | (9 | ) |  |  | 14 |  |  |  | (63 | ) |  |  | 40 |  |
| Less: Deductions |  |  | (926 | ) |  |  | (842 | ) |  |  | (1,742 | ) |  |  | (1,944 | ) |
| Balance at end of period |  | $ | 6,024 |  |  | $ | 6,831 |  |  | $ | 6,024 |  |  | $ | 6,831 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-094602:notes:223]
18. COMMITMENTS AND CONTINGENCIES 
Legal Matters

[0000950170-24-094602:notes:224]
From time to time, the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. The Company records an accrual for any Legal Matters that arise whenever it considers that it is probable that it is exposed to a loss contingency and the amount of the loss contingency can be reasonably estimated. Although the ultimate disposition of asserted claims cannot be predicted with certainty, it is our belief that the outcome of any such claims, either individually or on a combined basis, will not have a material adverse effect on our consolidated financial position.

[0000950170-24-094602:notes:225]
DPLTA Exit and Recurring Compensation Costs

[0000950170-24-094602:notes:226]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of June 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €345.6 million or approximately $371.3 million, based on an exchange rate as of June 30, 2024, and reflecting interest accrued through June 30, 2024, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-094602:notes:227]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.4 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three and six months ended June 30, 2024, and 2023, we accrued $2.9 million and $5.7 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

[0000950170-24-094602:notes:228]
For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or approximately $20 thousand and $25 thousand, respectively, based on an exchange rate as of June 30, 2024, were paid to Adtran Networks shareholders. For the three and six months ended June 30, 2023, approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €0.8 thousand and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

[0000950170-24-094602:notes:229]
Performance Bonds

[0000950170-24-094602:notes:230]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2024, and December 31, 2023, we had commitments related to these bonds totaling $13.9 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-24-094602:notes:231]
Purchase Obligations

[0000950170-24-094602:notes:232]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for short-term product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of June 30, 2024, purchase obligations totaled $280.9 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-094602:notes:233]
[same as prior period, unchanged from 0000950170-24-057628:notes:221]

[0000950170-24-094602:notes:234]
During the fourth quarter of 2022, the Company initiated a restructuring program designed to optimize the assets, business processes, and information technology systems of the Company in relation to the Business Combination with Adtran Networks. The restructuring program is expected to maximize cost synergies by realizing operation scale, combining sales channels, streamlining corporate and general and administrative functions, including human capital resources and combining sourcing and production costs. This restructuring program is expected to be completed in late 2024 and includes expenses specifically associated with achieving run-rate synergies, as well as Business Efficiency Program expenses described below.

[0000950170-24-094602:notes:235]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (“Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expands upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment. Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). On October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze. Additionally, on April 11, 2024, Management determined to close a facility in Greifswald, Germany. The closure of the facility is expected to be completed by December 31, 2024.

[0000950170-24-094602:notes:236]
During the three and six months ended June 30, 2024, we recognized $17.5 million and $34.6 million of costs related to the Business Efficiency Program, respectively. The costs recognized during the six months ended June 30, 2024, included charges of $8.9 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.1 million relates to inventory write-downs and $4.8 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss. Since the inception of the Business Efficiency Program, we recognized $59.7 million of costs. We expect costs in the third quarter 2024 and thereafter relating to the Business Efficiency Program to range between $8.1 million and $19.1 million. Management expects these planned costs to include severance costs ranging from $4.6 million to $11.4 million in

[0000950170-24-094602:notes:237]
connection with reductions in workforce and site consolidation transaction expenses (primarily brokers fees and Greifswald exit costs) ranging from $3.5 million to $7.7 million. The broker fees related to our site consolidation expenses will be netted against proceeds upon the sale of the building(s). Future cash payments include: severance costs and outplacement fees that are anticipated to be in the range of $21.3 million to $28.1 million, payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $3.4 million to $7.6 million and remaining payments related to the inventory strategy shift of $2.0 million. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures.  However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing. If required, we will amend this disclosure at such time as management is able in good faith to estimate the amount, or range of amounts, of these charges.

[0000950170-24-094602:notes:238]
For the three and six months ended June 30, 2023, we recognized $5.9 million and $8.3 million of restructuring costs relating to the Business Combination under the multi-year integration program and synergy realization that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss, respectively.

[0000950170-24-094602:notes:239]
A reconciliation of the beginning and ending restructuring liabilities, which is included in accrued wages and benefits and accounts payable in the Condensed Consolidated Balance Sheets as of June 30, 2024, and December 31, 2023, is as follows:

[0000950170-24-094602:notes:240]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (In thousands) |  | June 30, 2024 |  |  | June 30, 2024 |  |
| Balance at beginning of period |  | $ | 10,352 |  |  | $ | 8,309 |  |
| Plus: Amounts charged to cost and expense |  |  | 17,387 |  |  |  | 30,505 |  |
| Less: Amounts paid |  |  | (9,081 | ) |  |  | (20,156 | ) |
| Balance as of June 30, 2024 |  | $ | 18,658 |  |  | $ | 18,658 |  |

[0000950170-24-094602:notes:241]
[same as prior period, unchanged from 0000950170-24-057628:notes:228]

[0000950170-24-094602:notes:242]
Restructuring expenses included in the Condensed Consolidated Statements of Loss are for the three and six months ended June 30, 2024 and 2023:

[0000950170-24-094602:notes:243]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Network Solutions - Cost of revenue |  | $ | 524 |  |  | $ | — |  |  | $ | 2,842 |  |  | $ | 58 |  |
| Network Solutions - inventory write-down |  |  | 143 |  |  |  | — |  |  | $ | 8,925 |  |  | $ | — |  |
| Services & Support - Cost of revenue |  |  | 2,121 |  |  |  | — |  |  |  | 2,268 |  |  |  | 18 |  |
| Cost of revenue |  | $ | 2,788 |  |  | $ | — |  |  | $ | 14,035 |  |  | $ | 76 |  |
| Selling, general and administrative expenses |  |  | 3,497 |  |  |  | 1,393 |  |  |  | 5,299 |  |  |  | 3,573 |  |
| Research and development expenses |  |  | 11,245 |  |  |  | 4,475 |  |  |  | 15,306 |  |  |  | 4,656 |  |
| Total restructuring expenses |  | $ | 17,530 |  |  | $ | 5,868 |  |  | $ | 34,640 |  |  | $ | 8,305 |  |

[0000950170-24-094602:notes:244]
The following table represents the components of restructuring expenses by geographic area for the three and six months ended June 30, 2024 and 2023:

[0000950170-24-094602:notes:245]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| United States |  | $ | 1,226 |  |  | $ | 1,501 |  |  | $ | 16,286 |  |  | $ | 2,619 |  |
| International |  |  | 16,304 |  |  |  | 4,367 |  |  |  | 18,354 |  |  |  | 5,686 |  |
| Total restructuring expenses |  | $ | 17,530 |  |  | $ | 5,868 |  |  | $ | 34,640 |  |  | $ | 8,305 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-24-094602:notes:246]
20. SUBSEQUENT EVENTS

[0000950170-24-094602:notes:247]
On July 1, 2024, the Company renegotiated our receivables purchase agreement which is currently treated as a secured borrowing. The renegotiated receivables purchase agreement will result in a derecognition of the accounts receivable sold and the removal of the secured borrowing liability given the agreement transfers effective control over, and risk related to the receivables to the buyers. See Note 1 and Note 2 above for additional information on the accounting treatment of our receivable purchase agreements.

[0000950170-24-094602:notes:248]
Annual Recurring Compensation Payment

[0000950170-24-094602:notes:249]
On July 3, 2024, the Annual Recurring Compensation was paid with respect to the 2023 fiscal year. See Note 1 and Note 18 for additional information on the Annual Recurring Compensation payment.
