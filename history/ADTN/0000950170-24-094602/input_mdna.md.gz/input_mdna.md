# ADTN MD&A — 0000950170-24-094602


## mdna

[0000950170-24-094602:mdna:1]
[same as prior period, unchanged from 0000950170-24-057628:mdna:1]

[0000950170-24-094602:mdna:2]
[same as prior period, unchanged from 0000950170-24-057628:mdna:2]

[0000950170-24-094602:mdna:3]
[same as prior period, unchanged from 0000950170-24-057628:mdna:3]

[0000950170-24-094602:mdna:4]
[same as prior period, unchanged from 0000950170-24-057628:mdna:4]

[0000950170-24-094602:mdna:5]
[same as prior period, unchanged from 0000950170-24-057628:mdna:5]

[0000950170-24-094602:mdna:6]
The Company is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Large, Medium and Small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies.

[0000950170-24-094602:mdna:7]
Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands while enabling them to transition to the fully converged, scalable, highly automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-24-094602:mdna:8]
[same as prior period, unchanged from 0000950170-24-057628:mdna:8]

[0000950170-24-094602:mdna:9]
[same as prior period, unchanged from 0000950170-24-057628:mdna:9]

[0000950170-24-094602:mdna:10]
[same as prior period, unchanged from 0000950170-24-057628:mdna:10]

[0000950170-24-094602:mdna:11]
[same as prior period, unchanged from 0000950170-24-057628:mdna:11]

[0000950170-24-094602:mdna:12]
[same as prior period, unchanged from 0000950170-24-057628:mdna:12]

[0000950170-24-094602:mdna:13]
[same as prior period, unchanged from 0000950170-24-057628:mdna:13]

[0000950170-24-094602:mdna:14]
[same as prior period, unchanged from 0000950170-24-057628:mdna:14]

[0000950170-24-094602:mdna:15]
[same as prior period, unchanged from 0000950170-24-057628:mdna:15]

[0000950170-24-094602:mdna:16]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest ("Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.59 (€0.52 net under the current tax regime) per share for each full fiscal year of Adtran Networks (“Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component that was 3.62% as of June 30, 2024. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024, and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. The adequacy of both forms of compensation has been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

[0000950170-24-094602:mdna:17]
The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or approximately $20 thousand and $25 thousand, respectively, based on an exchange rate as of June 30, 2024, were paid to Adtran Networks shareholders.

[0000950170-24-094602:mdna:18]
In addition to our cash and cash equivalents and the credit facility, we may fund a portion or all of the Exit Compensation through the sale of securities or additional alternative funding sources, if available. There can be no assurances that we would be successful in effecting these actions on commercially reasonable terms or at all. If we cannot raise additional funds as needed, it could have a material adverse impact on our financial results and financial condition.

[0000950170-24-094602:mdna:19]
We currently hold 34,026,174 no-par value bearer shares of Adtran Networks, representing 65.37% of Adtran Networks outstanding shares as of June 30, 2024.

[0000950170-24-094602:mdna:20]
[same as prior period, unchanged from 0000950170-24-057628:mdna:20]

[0000950170-24-094602:mdna:21]
[same as prior period, unchanged from 0000950170-24-057628:mdna:21]

[0000950170-24-094602:mdna:22]
During the fourth quarter of 2022, the Company initiated a multi-year integration program designed to optimize the assets, business processes, and information technology systems of the Company. During the three and six months ended June 30, 2023, we recognized $0.6 million and $1.4 million, respectively, of integration costs related to the Business Combination that are included in selling, general and administrative expenses in the Condensed Consolidated Statement of Loss. We did not incur any costs related to our multi-year integration program in the three and six months ended June 30, 2024, respectively. The Company does not anticipate additional material expenses to be incurred in connection with this integration program. See Note 19 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-094602:mdna:23]
[same as prior period, unchanged from 0000950170-24-057628:mdna:23]

[0000950170-24-094602:mdna:24]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (“Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expands upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment. Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). On October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze. Additionally, on April 11, 2024, management determined to close a facility in Greifswald, Germany. The closure of the facility is expected to be completed by December 31, 2024.

[0000950170-24-094602:mdna:25]
During the three and six months ended June 30, 2024, we recognized $17.5 million and $34.6 million of costs related to the Business Efficiency Program, respectively. The costs recognized during the six months ended June 30, 2024, included charges of $8.9 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.1 million relates to inventory write-downs and $4.8 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss. Since the inception of the Business Efficiency Program, we recognized $59.7 million of costs. We expect costs in the third quarter 2024 and thereafter relating to the Business Efficiency Program to range between $8.1 million and $19.1 million. Management expects these planned costs to include severance costs ranging from $4.6 million to $11.4 million in connection with reductions in workforce and site consolidation transaction expenses (primarily brokers fees and Greifswald exit costs) ranging from $3.5 million to $7.7 million. The broker fees related to our site consolidation expenses will be netted against proceeds upon the sale of the building(s). Future cash payments include: severance costs and outplacement fees that are anticipated to be in the range of $21.3 million to $28.1 million, payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $3.4 million to $7.6 million and remaining payments related to the inventory strategy shift of $2.0 million. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures.  However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing. If required, we will amend this disclosure at such time as management is able in good faith to estimate the amount, or range of amounts, of these charges.

[0000950170-24-094602:mdna:26]
[same as prior period, unchanged from 0000950170-24-057628:mdna:26]

[0000950170-24-094602:mdna:27]
During the three and six months ended June 30, 2024, we recognized $0.7 million and $1.2 million of integration costs related to the Business Combination were incurred. During the three and six months ended June 30, 2023, $0.6 million and $1.4 million of integration costs related to the Business Combination were incurred, respectively. These transaction costs are included in selling, general and administrative expenses, research & development expenses and cost of revenue in the Condensed Consolidated Statement of Loss. We expect to incur additional integration costs and expenses associated with the implementation of the DPLTA throughout 2024 and such costs are expected to be material. These costs are separate and apart from the costs associated with the integration program discussed above.

[0000950170-24-094602:mdna:28]
[same as prior period, unchanged from 0000950170-24-057628:mdna:28]

[0000950170-24-094602:mdna:29]
We ended the second quarter of 2024 with a year-over-year revenue decrease of 31.0% as compared to the three months ended June 30, 2023, driven by decreased volume of sales activity due to customers' focus on reducing inventory levels and continuing uncertain macroeconomic conditions related to ongoing inflationary pressures, continued elevated interest rates, currency fluctuations and political tensions which impacted the spending behavior of our customers. During the second quarter of 2024, we had no customers with revenues greater than 10.0% and our five largest customers comprised 28.0% of our revenue. Our year-over-year domestic revenue decreased by 18.7% and continued to be impacted by elevated customer inventory levels, continuing effects of uncertain macroeconomic conditions and decreased shipments to distributor customers. Internationally, our year-over-year revenue decreased by 39.3%, primarily driven by the unfavorable impact on revenue as a result of the strengthened U.S. dollar and decreased shipments to network operators in Europe.

[0000950170-24-094602:mdna:30]
Access & Aggregation and Optical Networking revenue categories experienced a general slowdown in revenue as a result of reduced spending by our Service Provider customers as they continue to reduce excess inventory levels and monitor the uncertain macroeconomic conditions. Despite these challenges, we have maintained our emphasis on product development to enable us to respond to rapidly changing technology and evolving industry standards. For example, we expect public funding through projects such as IPCEI ME/CT to further our research and development for new communication technologies. Additionally, public funding through the Broadband Equity, Access and Deployment Program is expected to commence in late 2024 through 2026, which provides a positive outlook for the future. In Europe, we continue to see increased activity from high-risk vendor replacement and broadband subsidy programs.

[0000950170-24-094602:mdna:31]
Our operating results have fluctuated and may continue to fluctuate on a quarterly basis due to several factors, including customer order activity, prior supply chain constraints, component availability, and the Company's consolidation and integration with Adtran Networks. Further, a significant percentage of orders require delivery within a few days, requiring us to maintain higher inventory levels. These factors may result in limited order flow visibility. We have taken decisive steps to transform our business into a leaner, more efficient and more profitable company, including through the implementation of a Business Efficiency Program, which includes a significant cost efficiency program targeting a reduction of ongoing operating expenses and a capital efficiency program inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. Nevertheless, our operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues has and may again in the future significantly impact on our financial results in any given quarter.

[0000950170-24-094602:mdna:32]
Our operating results have significantly fluctuated and may do so in the future as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, inflation, regional conflicts, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. In recent years, inflationary pressures on input costs, such as raw materials and labor, and distribution costs had a negative impact on our operating results. However, inflationary pressures on our supply chain have eased somewhat, which has led to reductions in cost premiums on raw material costs and freight. We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors and customers to address and to limit the disruption to our operations and order fulfillment. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an additional adverse effect on our business and operating results beyond the effects of the most recent inventory write-downs. Also, not maintaining sufficient inventory levels to ensure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results.

[0000950170-24-094602:mdna:33]
We are exposed to changes in foreign currencies relative to the U.S. dollar, which are references to the differences between the foreign-exchanges rates we use to convert the financial results of our international operations from local currencies into U.S. dollars for financial reporting purposes. This impact of foreign-exchange rate changes is calculated based on the difference between the current period’s currency exchange rates and that of the comparable prior period. Our primary exposures to foreign currency exchange rate movements are with the Euro and the British pound sterling. As a result of our global operations, our revenue, gross margin, operating expense and operating loss in some international markets has been and may continue to be affected by foreign currency fluctuations.

[0000950170-24-094602:mdna:34]
The Company’s policy is to assess the realizability of assets (long-lived assets, intangibles and goodwill) held within our reporting units and to evaluate such assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. During the third quarter of 2023, the Company identified a triggering event due to a decrease in its market capitalization and changes in projections (decrease in estimated cash flows). While the quantitative impairment analysis indicated that there was no impairment of Network Solutions goodwill, the Company determined a $37.9 million non-cash impairment charge for goodwill was warranted for the Services & Support reporting unit. During the fourth quarter of 2023, the Company completed its annual impairment test. There were no significant market changes or changes to cash flow projections, as such no triggering event was identified during the fourth quarter of 2023.

[0000950170-24-094602:mdna:35]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of the Network Solutions reporting unit using a combination of an income approach and a market-based peer group analysis. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit during the three months ended March 31, 2024. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the three months ended March 31, 2024.

[0000950170-24-094602:mdna:36]
During the second quarter of 2024, the Company qualitatively assessed the carrying value of our Services & Support reporting unit for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Based on our assessment of certain qualitative factors such as macroeconomic conditions, industry and market considerations, cost factors and overall financial performance, management concluded that the fair value of the Services & Support reporting unit was more likely than not greater than its carrying amount as of June 30, 2024. Therefore, no impairment of goodwill was recorded during the three months ended June 30, 2024.

[0000950170-24-094602:mdna:37]
[same as prior period, unchanged from 0000950170-24-057628:mdna:35]

[0000950170-24-094602:mdna:38]
[same as prior period, unchanged from 0000950170-24-057628:mdna:36]

[0000950170-24-094602:mdna:39]
[same as prior period, unchanged from 0000950170-24-057628:mdna:37]

[0000950170-24-094602:mdna:40]
[same as prior period, unchanged from 0000950170-24-057628:mdna:90]

[0000950170-24-094602:mdna:41]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2024, COMPARED TO THE THREE AND SIX MONTHS ENDED JUNE 30, 2023

[0000950170-24-094602:mdna:42]
[same as prior period, unchanged from 0000950170-24-057628:mdna:39]

[0000950170-24-094602:mdna:43]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 79.3 |  | % |  | 86.4 |  | % |  | 79.7 |  | % |  | 86.8 |  | % |
| Services & Support |  |  | 20.7 |  |  |  | 13.6 |  |  |  | 20.3 |  |  |  | 13.2 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 55.1 |  |  |  | 66.3 |  |  |  | 55.5 |  |  |  | 67.0 |  |  |
| Network Solutions - inventory write-down and other charges |  |  | 0.1 |  |  |  | — |  |  |  | 2.0 |  |  |  | — |  |  |
| Services & Support |  |  | 8.8 |  |  |  | 5.5 |  |  |  | 8.5 |  |  |  | 5.3 |  |  |
| Total Cost of Revenue |  |  | 63.9 |  |  |  | 71.7 |  |  |  | 66.0 |  |  |  | 72.3 |  |  |
| Gross Profit |  |  | 36.1 |  |  |  | 28.3 |  |  |  | 34.0 |  |  |  | 27.7 |  |  |
| Selling, general and administrative expenses |  |  | 26.3 |  |  |  | 20.3 |  |  |  | 26.2 |  |  |  | 20.6 |  |  |
| Research and development expenses |  |  | 26.7 |  |  |  | 21.6 |  |  |  | 26.7 |  |  |  | 21.6 |  |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | 64.7 |  |  |  | — |  |  |
| Operating Loss |  |  | (17.0 | ) |  |  | (13.6 | ) |  |  | (83.6 | ) |  |  | (14.5 | ) |  |
| Interest and dividend income |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.1 |  |  |
| Interest expense |  |  | (3.1 | ) |  |  | (1.2 | ) |  |  | (2.5 | ) |  |  | (1.1 | ) |  |
| Net investment gain |  |  | 0.4 |  |  |  | 0.4 |  |  |  | 0.7 |  |  |  | 0.4 |  |  |
| Other (expense) income, net |  |  | (0.4 | ) |  |  | 0.8 |  |  |  | 0.1 |  |  |  | 0.3 |  |  |
| Loss Before Income Taxes |  |  | (19.9 | ) |  |  | (13.6 | ) |  |  | (85.2 | ) |  |  | (14.8 | ) |  |
| Income tax (expense) benefit |  |  | (0.9 | ) |  |  | 2.6 |  |  |  | 3.7 |  |  |  | 3.0 |  |  |
| Net Loss |  |  | (20.8 | ) | % |  | (11.1 | ) | % |  | (81.5 | ) | % |  | (11.8 | ) | % |
| Less: Net Income attributable to non-controlling interest |  |  | 1.3 |  |  |  | 0.9 |  |  |  | 1.3 |  |  |  | 0.4 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | (22.1 | ) | % |  | (11.9 | ) | % |  | (82.8 | ) | % |  | (12.2 | ) | % |

[0000950170-24-094602:mdna:44]
[same as prior period, unchanged from 0000950170-24-057628:mdna:41]

[0000950170-24-094602:mdna:45]
Our revenue decreased 31.0% from $327.4 million for the three months ended June 30, 2023, to $226.0 million for the three months ended June 30, 2024, and decreased 30.6% from $651.3 million for the six months ended June 30, 2023, to $452.2 million for the six months ended June 30, 2024. The decrease in revenue for the three and six months ended June 30, 2024, is primarily driven by a decrease in volume of sales activity due to customers’ focus on reducing inventory levels and the completion of significant customer projects. The decrease in revenue by category for the three months ended June 30, 2024, was primarily attributable to a $69.3 million decrease in Optical Networking Solutions products, a $32.8 million decrease in Access & Aggregation revenue partially offset by a $0.7 million increase in Subscriber Solutions products. The decrease in revenue by category for the six months ended June 30, 2024, was primarily attributable to a $142.0 million decrease in Optical Networking Solutions products, a $48.3 million decrease in Access & Aggregation revenue and a $8.8 million decrease in Subscriber Solutions products. Continued customer concerns over inventory stocking levels have affected our revenue in the first half of 2024 in our Optical Networking Solutions category, Access & Aggregation category and our Subscriber Solutions category.

[0000950170-24-094602:mdna:46]
Network Solutions segment revenue decreased 36.7% from $283.0 million for the three months ended June 30, 2023, to $179.2 million for the three months ended June 30, 2024, and decreased 36.2% from $565.4 million for the six months ended June 30, 2023, to $360.5 million for the six months ended June 30, 2024. The decrease in Network Solutions revenue for the three months ended June 30, 2024, was due to a decrease of $68.8 million in volume of sales activity in Optical Networking products, a decrease of $35.2 million in volume of sales activity in Access & Aggregation products partially offset by an increase of $0.1 million in volume of sales activity in Subscriber Solutions products. The decrease in Network Solutions revenue for the six months ended June 30, 2024, was due to a decrease of $143.2 million in volume of sales activity in Optical Networking products, a decrease of $51.9 million in volume of sales activity in Access & Aggregation products and a decrease of $9.8 million in volume of sales activity in Subscriber Solutions products.

[0000950170-24-094602:mdna:47]
Services & Support segment revenue increased 5.5% from $44.4 million for the three months ended June 30, 2023, to $46.8 million for the three months ended June 30, 2024, and increased 6.8% from $85.9 million for the six months ended June 30, 2023, to $91.7 million for the six months ended June 30, 2024. The increase in revenue for the three months ended June 30, 2024, was primarily attributable a $2.3 million increase in revenue for Access & Aggregation revenue and a $0.6 million increase in revenue for Subscriber Solutions services, partially offset by a $0.6 million decrease in revenue for Optical Networking products. The increase in revenue for the six

[0000950170-24-094602:mdna:48]
months ended June 30, 2024, was primarily attributable a $3.6 million increase in revenue for Access & Aggregation revenue a $1.2 million increase in revenue for Optical Networking products, and a $1.0 million increase in revenue for Subscriber Solutions services. More specifically, the increase in revenue for the three and six months ended June 30, 2024, of our ADTRAN, Inc. operations was primarily due to higher volume of sales of our software services and business solutions services.

[0000950170-24-094602:mdna:49]
Domestic revenue decreased by 18.7% from $132.3 million for the three months ended June 30, 2023, to $107.6 million for the three months ended June 30, 2024, and decreased by 27.6% from $263.8 million for the six months ended June 30, 2023, to $190.9 million for the six months ended June 30, 2024. The decrease in domestic revenue for the three and six months ended June 30, 2024, was primarily due to lower volume of sales of our residential solutions products as a result of customers focus on reducing inventory levels across all revenue categories.

[0000950170-24-094602:mdna:50]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., decreased by 39.3% from $195.1 million for the three months ended June 30, 2023 to $118.4 million for the three months ended June 30, 2024 and decreased by 32.6% from $387.5 million for the six months ended June 30, 2023 to $261.3 million for the six months ended June 30, 2024. International revenue, as a percentage of total revenue, decreased from 59.6% for the three months ended June 30, 2023, to 52.4% for the three months ended June 30, 2024, and decreased from 59.5% for the six months ended June 30, 2023, to 57.8% for the six months ended June 30, 2024. The decrease in international revenue for the three and six months ended June 30, 2024, was primarily due to the conclusion of specific customer projects and customer concerns over inventory stocking levels. While international revenue has decreased to approximately 52.4% and 57.8% of total revenues for the three and six months ended June 30, 2024, respectively, the mix of our Network Solutions and Services & Support segments as a percentage of total international revenue remains relatively linear. For the three and six months ended June 30, 2024, as compared to the three and six months ended June 30, 2023, changes in foreign currencies relative to the U.S. dollar decreased our net revenue by approximately $0.3 million and increased our net revenue by approximately $1.9 million, respectively.

[0000950170-24-094602:mdna:51]
[same as prior period, unchanged from 0000950170-24-057628:mdna:47]

[0000950170-24-094602:mdna:52]
[same as prior period, unchanged from 0000950170-24-057628:mdna:48]

[0000950170-24-094602:mdna:53]
As a percentage of revenue, cost of revenue decreased from 71.7% for the three months ended June 30, 2023, to 63.9% for the three months ended June 30, 2024, and decreased from 72.3% for the six months ended June 30, 2023, to 66.0% for the six months ended June 30, 2024. The decrease for the three months ended June 30, 2024 was attributable to a 5.1% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, and a 5.3% decrease in expense as a percentage of revenue related to decreased acquisition costs, partially offset by a 1.2% increase in expense as a percentage of revenue in connection with our Business Efficiency Program, which resulted in an inventory write down and other charges of $0.1 million incurred as a result of a strategy shift which included discontinuance of certain product lines and a 1.3% increase in expense as a percentage of revenue attributable to changes in customer and product mix. The decrease for the six months ended June 30, 2024 was attributable to a 5.0% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, and a 5.1% decrease in expense as a percentage of revenue related to decreased acquisition costs, partially offset by a 3.1% increase in expense as a percentage of revenue in connection with our Business Efficiency Program, which resulted in an inventory write down and other charges of $8.9 million incurred as a result of a strategy shift which included discontinuance of certain product lines and a 0.7% increase in expense as a percentage of revenue attributable to changes in customer and product mix. For the three and six months ended June 30, 2024, as compared to the three and six months ended June 30, 2023, changes in foreign currencies relative to the U.S. dollar decreased our cost of revenue by approximately $0.1 million and increased our cost of revenue by approximately $0.4 million, respectively.

[0000950170-24-094602:mdna:54]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, decreased from 76.7% for the three months ended June 30, 2023, to 69.5% for the three months ended June 30, 2024, and decreased from 77.1% for the six months ended June 30, 2023 to 72.0% for the six months ended June 30, 2024. The decrease in cost of revenue as a percentage of revenue for the three months ended June 30, 2024 was attributable to a 6.4% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks and a 6.7% decrease in expense as a percentage of revenue related to decreased acquisition costs,

[0000950170-24-094602:mdna:55]
partially offset by a 0.4% increase in expense as a percentage of revenue in connection with our Business Efficiency Program, which resulted in an inventory write down and other charges of $0.1 million incurred as a result of a strategy shift which included discontinuance of certain product lines and a 5.5% increase in expense as a percentage of revenue attributable to changes in customer and product mix. The decrease in cost of revenue as a percentage of revenue for the six months ended June 30, 2024 was attributable to a 6.3% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks and a 6.4% decrease in expense as a percentage of revenue related to decreased acquisition costs, partially offset by a 3.2% increase in expense as a percentage of revenue in connection with our Business Efficiency Program, which resulted in an inventory write down and other charges of $8.9 million incurred as a result of a strategy shift which included discontinuance of certain product lines and a 4.4% increase in expense as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-24-094602:mdna:56]
Services & Support cost of revenue, as a percentage of that segment’s revenue, increased from 40.3% for the three months ended June 30, 2023, to 42.3% for the three months ended June 30, 2024, and increased from 40.6% for the six months ended June 30, 2023 to 42.1% for the six months ended June 30, 2024. The increase in cost of revenue as a percentage of revenue for the three and six months ended June 30, 2024, was primarily attributable to changes in customer and product mix.

[0000950170-24-094602:mdna:57]
[same as prior period, unchanged from 0000950170-24-057628:mdna:52]

[0000950170-24-094602:mdna:58]
[same as prior period, unchanged from 0000950170-24-057628:mdna:53]

[0000950170-24-094602:mdna:59]
As a percentage of revenue, gross profit increased from 28.3% for the three months ended June 30, 2023, to 36.1% for the three months ended June 30, 2024, and increased from 27.7% for the six months ended June 30, 2023 to 34.0% for the six months ended June 30, 2024. The increase for the three months ended June 30, 2024 was attributable to a 5.1% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, and a 5.3% increase in gross profit as a percentage of revenue related to decreased acquisition costs, partially offset by a 1.2% decrease in gross profit as a percentage of revenue in connection with increased expenses with our Business Efficiency Program, which resulted in an inventory write down and other charges of $0.1 million incurred as a result of a strategy shift which included discontinuance of certain product lines and a 1.3% decrease in gross profit as a percentage of revenue attributable to changes in customer and product mix. The increase for the six months ended June 30, 2024 was attributable to a 5.0% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, and a 5.1% increase in gross profit as a percentage of revenue related to decreased acquisition costs, partially offset by a 3.1% decrease in gross profit as a percentage of revenue in connection with increased expenses with our Business Efficiency Program, which resulted in an inventory write down and other charges of $8.9 million incurred as a result of a strategy shift which included discontinuance of certain product lines and a 0.7% decrease in gross profit as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-24-094602:mdna:60]
As a percentage of that segment's revenue, Network Solutions gross profit increased from 23.3% for the three months ended June 30, 2023, to 30.5% for the three months ended June 30, 2024, and increased from 22.9% for the six months ended June 30, 2023 to 28.0% for the six months ended June 30, 2024. The increase for the three months ended June 30, 2024 was attributable to a 6.4% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks and a 6.7% increase in gross profit as a percentage of revenue related to decreased acquisition costs, partially offset by a 0.4% decrease in gross profit as a percentage of revenue in connection with increased expenses with our Business Efficiency Program, which resulted in an inventory write down and other charges of $0.1 million incurred as a result of a strategy shift which included discontinuance of certain product lines and a 5.5% decrease in gross profit as a percentage of revenue attributable to changes in customer and product mix. The increase for the six months ended June 30, 2024 was attributable to a 6.3% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks and a 6.4% increase in gross profit as a percentage of revenue related to decreased acquisition costs, partially offset by a 3.2% decrease in gross profit as a percentage of revenue in connection with increased expenses with our Business Efficiency Program, which resulted in an inventory write down and other charges of $8.9 million incurred as a result of a strategy shift which included discontinuance of certain product lines and a 4.4% decrease in gross profit as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-24-094602:mdna:61]
As a percentage of that segment's revenue, Services & Support gross profit decreased from 59.7% for the three months ended June 30, 2023, to 57.7% for the three months ended June 30, 2024, and decreased from 59.4% for the six months ended June 30, 2023, to 57.9% for the six months ended June 30, 2024. The decrease was primarily attributable to changes in customer and product mix.

[0000950170-24-094602:mdna:62]
[same as prior period, unchanged from 0000950170-24-057628:mdna:58]

[0000950170-24-094602:mdna:63]
As a percentage of revenue, selling, general and administrative expenses increased from 20.3% for the three months ended June 30, 2023, to 26.3% for the three months ended June 30, 2024, and increased from 20.6% for the six months ended June 30, 2023, to 26.2% for the six months ended June 30, 2024. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared. We are still in the process of implementing our Business Efficiency Program, which we expect will lower selling, general and administrative expenses as a percentage of revenue over time.

[0000950170-24-094602:mdna:64]
Selling, general and administrative expenses decreased 10.6% from $66.6 million for the three months ended June 30, 2023, to $59.5 million for the three months ended June 30, 2024, and decreased 11.5% from $134.0 million for the six months ended June 30, 2023, to $118.6 million for the six months ended June 30, 2024. Selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The decrease in selling, general and administrative expenses for the three months ended June 30, 2024, compared to the three months ended June 30, 2023, was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $6.7 million, and travel expenses by $0.7 million. The decrease for the six months ended June 30, 2024, compared to the six months ended June 30, 2023, was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $13.5 million, and travel expenses by $2.1 million. For the three and six months ended June 30, 2024, as compared to the three and six months ended June 30, 2023, changes in foreign currencies relative to the U.S dollar decreased our selling, general and administrative expenses by approximately $0.1 million and increased our selling, general and administrative expenses by approximately $0.9 million, respectively.

[0000950170-24-094602:mdna:65]
[same as prior period, unchanged from 0000950170-24-057628:mdna:61]

[0000950170-24-094602:mdna:66]
As a percentage of revenue, research and development expenses increased from 21.6% for the three months ended June 30, 2023, to 26.7% for the three months ended June 30, 2024, and increased from 21.6% for the six months ended June 30, 2023, to 26.7% for the six months ended June 30, 2024. Research and development expenses as a percentage of revenue will generally fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared. We are still in the process of implementing our Business Efficiency Program, which we expect will lower research and development expense as a percentage of revenue over time.

[0000950170-24-094602:mdna:67]
Research and development expenses decreased 14.5% from $70.6 million for the three months ended June 30, 2023, to $60.4 million for the three months ended June 30, 2024, and decreased 14.3% from $140.7 million for the six months ended June 30, 2023, to $120.6 million for the six months ended June 30, 2024. The decrease in research and development expenses for the three months ended June 30, 2024, was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $2.5 million and contract services by $1.6 million. The decrease for the six months ended June 30, 2024, was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its contract services by $4.3 million and employee-related costs by $3.8 million. For the three and six months ended June 30, 2024, as compared to the three and six months ended June 30, 2023, changes in foreign currencies relative to the U.S. dollar increased our research and development expenses by approximately $0.2 million and increased our research and development expenses by approximately $0.9 million, respectively.

[0000950170-24-094602:mdna:68]
Adtran Networks has arrangements with governmental entities for the purpose of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expenses incurred. For the three and six months ended June 30, 2024, the Company recognized $1.9 million and $2.1 million as a reduction of research and development expense, respectively.

[0000950170-24-094602:mdna:69]
[same as prior period, unchanged from 0000950170-24-057628:mdna:65]

[0000950170-24-094602:mdna:70]
[same as prior period, unchanged from 0000950170-24-057628:mdna:66]

[0000950170-24-094602:mdna:71]
There was no goodwill impairment recognized during the three months ended June 30, 2024, and for the three and six months ended June 30, 2023. During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer focus on inventory adjustments, triggered a quantitative impairment assessment for our reporting units. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit during the six months ended June 30, 2024. For additional information, see Note 8 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-24-094602:mdna:72]
[same as prior period, unchanged from 0000950170-24-057628:mdna:69]

[0000950170-24-094602:mdna:73]
Interest and dividend income remained flat at $0.4 million for the three months ended June 30, 2023, and 2024 and increased from $0.7 million for the six months ended June 30, 2023, to $0.8 million for the six months ended June 30, 2024. The increase in interest and dividend income is primarily attributable to fluctuations in investment balances and an increase in the rate of return on those investments due to interest rate movements.

[0000950170-24-094602:mdna:74]
[same as prior period, unchanged from 0000950170-24-057628:mdna:71]

[0000950170-24-094602:mdna:75]
Interest expense increased from $4.1 million for the three months ended June 30, 2023, to $6.9 million for the three months ended June 30, 2024, and increased from $7.4 million for the six months ended June 30, 2023, to $11.5 million for the six months ended June 30, 2024. The increase in interest expense during the three and six months ended June 30, 2024, was primarily driven by higher amortization of debt issuance costs as well as higher interest rates associated with the amendments of the Credit Agreement and higher average borrowings outstanding versus the three and six months ending June 30, 2023. See Note 11 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-24-094602:mdna:76]
[same as prior period, unchanged from 0000950170-24-057628:mdna:73]

[0000950170-24-094602:mdna:77]
We recognized a net investment gain of $1.3 million and $0.9 million for the three months ended June 30, 2023, and 2024, respectively and recognized a net investment gain of $2.5 million and $3.1 million for the six months ended June 30, 2023, and 2024, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See Note 5 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-24-094602:mdna:78]
[same as prior period, unchanged from 0000950170-24-057628:mdna:75]

[0000950170-24-094602:mdna:79]
Other (expense) income, net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, decreased from income of $2.5 million for the three months ended June 30, 2023 to expense of $0.9 million for the three months ended June 30, 2024 and decreased from income of $2.2 million for the six months ended June 30, 2023 to income of $0.4 million for the six months ended June 30, 2024.

[0000950170-24-094602:mdna:80]
[same as prior period, unchanged from 0000950170-24-057628:mdna:77]

[0000950170-24-094602:mdna:81]
The Company's effective tax rate changed from a benefit of 18.8% of pre-tax income for the three months ended June 30, 2023, to a expense of 4.8% of pre-tax loss for the three months ended June 30, 2024 and changed from a benefit of 20.4% of pre-tax income for the six months ended June 30, 2023, to a benefit of 4.3% of pre-tax income for the six months ended June 30, 2024. The changes in the effective tax rate for the three and six months ended June 30, 2024, were driven primarily by non-deductible impairment charges and a loss jurisdiction for which no tax benefits were recognized on its pre-tax losses incurred during the six months ended June 30, 2024.

[0000950170-24-094602:mdna:82]
[same as prior period, unchanged from 0000950170-24-057628:mdna:79]

[0000950170-24-094602:mdna:83]
As a result of the above factors, net loss attributable to ADTRAN Holdings, Inc. increased from net loss of $39.1 million for the three months ended June 30, 2023, to a net loss of $49.9 million for the three months ended June 30, 2024, and increased from net loss of $79.2 million for the six months ended June 30, 2023, to a net loss of $374.4 million for the six months ended June 30, 2024.

[0000950170-24-094602:mdna:84]
[same as prior period, unchanged from 0000950170-24-057628:mdna:81]

[0000950170-24-094602:mdna:85]
We have historically financed our ongoing business with existing cash, investments and cash flow from operations. We had a positive cash flow from operating activities of $56.0 million in the six months ended June 30, 2024. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures. In addition, we have increasingly relied upon our credit arrangements to manage our working capital needs.

[0000950170-24-094602:mdna:86]
As of June 30, 2024, our cash on hand was $111.2 million of which $81.7 million was held by our foreign subsidiaries. The Company had access to $206.0 million on its Credit Facility for future borrowings; however, as of June 30, 2024, the Company was limited to additional borrowings of $16.4 million based on debt covenant compliance metrics. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax. As of December 31, 2023, our cash on hand was $87.2 million, of which $73.0 million was held by our foreign subsidiaries.

[0000950170-24-094602:mdna:87]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of June 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €345.6 million or approximately $371.3 million, based on an exchange rate as of June 30, 2024, and reflecting interest accrued through June 30, 2024, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-094602:mdna:88]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.4 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three and six months ended June 30, 2024, and 2023, we accrued $2.9 million and $5.7 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

[0000950170-24-094602:mdna:89]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. Pursuant to the terms of the Credit Agreement, as amended, the Company, ADTRAN, Inc., and the subsidiary guarantors (together the, “Credit Parties”) are subject to a liquidity covenant, which provides that, during the fourth quarter of 2023 through and including the third quarter of 2024 ("Covenant Relief Period") or a Springing Covenant Period, (i.e., the period beginning upon the purchase by the Company of at least 60% of the outstanding shares of Adtran Networks not owned by the Company as of August 9, 2023 and the three consecutive quarterly test periods after such date), as of the last day of any fiscal quarter, the cash and cash equivalents of the Credit Parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million, limiting our ability to pay the obligations under the DPLTA. See below, as well as Note 11 of Notes to Condensed Consolidated Financial Statements included in Part I, Item, 1 for additional information regarding the terms of each amendment to the Wells Fargo Credit Agreement.

[0000950170-24-094602:mdna:90]
As of June 30, 2024, and as of the date of issuance of the condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or approximately $20 thousand and $25 thousand, respectively, based on an exchange rate as of June 30, 2024, were paid to Adtran Networks shareholders. For the three and six months ended June 30, 2023, approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €0.8 thousand and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-32 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks shares.

[0000950170-24-094602:mdna:91]
The Company experienced revenue declines in the year ended December 31, 2023, and during the three and six months ended June 30, 2024. To the extent that the Company is further impacted by customers' inventory reduction initiatives, the Company is implementing plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a Business Efficiency Program, which includes, but is not limited to ongoing reductions in operating expenses and a site consolidation plan. In connection with the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action

[0000950170-24-094602:mdna:92]
50

[0000950170-24-094602:mdna:93]
on commercially reasonable terms or at all. We may need to further reduce capital expenditure and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

[0000950170-24-094602:mdna:94]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo Credit Facility (described below), will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and ability to continue to comply with our debt covenants under the Credit Facility for at least the next twelve months, from the issuance of these condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q. See Note 11, Revolving Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo Credit agreement and Notes to Condensed Consolidated Financial Statements included in Part I, Item, 1 for additional information regarding the terms of the Wells Fargo Credit Agreement, as amended.

[0000950170-24-094602:mdna:95]
Wells Fargo Credit Facility

[0000950170-24-094602:mdna:96]
On July 18, 2022, ADTRAN, Inc., as the borrower ("US Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (as amended from time to time, the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount ($100.0 million of which is available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below), as well as the $50.0 million delayed draw term loan facility described below. The term of the delayed draw term loan facility expires on August 9, 2024.

[0000950170-24-094602:mdna:97]
On August 9, 2023, ("First Amendment Effective Date") the Company and ADTRAN, Inc. entered into a First Amendment to Credit Agreement (“First Amendment”).

[0000950170-24-094602:mdna:98]
The First Amendment among other things, provided for a new $50.0 million delayed draw term loan facility (“DDTL”), which (subject to certain conditions) is available for borrowing in the event that at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date have been tendered (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase shares of Adtran Networks. The DDTL is available for borrowing from the occurrence of a Springing Covenant Event through August 9, 2024.

[0000950170-24-094602:mdna:99]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-24-094602:mdna:100]
On January 16, 2024 ("Second Amendment Effective Date"), the Company and ADTRAN, Inc. entered into a Second Amendment to Credit Agreement and First Amendment to Collateral Agreement ("Second Amendment"). The Second Amendment, among other things, provided the Company and its subsidiaries with additional covenant headroom for the fourth quarter of 2023 through and including the third quarter of 2024 ("Covenant Relief Period") and revised and/or added certain other financial covenants which (as later modified by the Fourth Amendment) are described below.

[0000950170-24-094602:mdna:101]
On March 12, 2024, the Company and ADTRAN, Inc. entered into a Third Amendment to Credit Agreement ("Third Amendment"). The Third Amendment, among other things, amended the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain receivables purchase arrangements when calculated for the fiscal quarters ending March 31, 2024, and June 30, 2024. On July 1, 2024, the Company renegotiated our receivables purchase agreement which is currently treated as a secured borrowing. The renegotiated receivables purchase agreement will result in a derecognition of the accounts receivable sold and the removal of the secured borrowing liability given the agreement transfers effective control over, and risk related to the receivables to the buyers.

[0000950170-24-094602:mdna:102]
On June 4, 2024, the Company, ADTRAN, Inc., and Adtran Networks entered into a Fourth Amendment to Credit Agreement ("Fourth Amendment"). The Fourth Amendment, among other things, created a new sublimit under the existing $400.0 million revolving commitments, in an aggregate amount of $100.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold is initially $75 million and may be lowered from time to time pursuant to the terms of the Fourth Amendment. The existing swing line sublimit and letter of credit sublimit under the Credit Agreement remained available to the US Borrower (and not to Adtran Networks) after giving effect to the Fourth Amendment. Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

[0000950170-24-094602:mdna:103]
As of June 30, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $190.3 million, of which $115.0 million were borrowed by ADTRAN, Inc. and $75.3 million were borrowed under the Subline by Adtran Networks. As of June 30, 2024, there were no borrowings under the DDTL. The credit facilities provided under the Credit Agreement mature in July 2027, but the US Borrower has an option to request extensions subject to customary conditions. In addition, the US Borrower may utilize up to $50.0 million of the $400.0 million total revolving facility for the issuance of letters of credit. As of June 30, 2024, we had a total of $3.7 million in letters of credit under ADTRAN, Inc. outstanding under the Credit Agreement, leaving a net amount (after giving effect to the $190.3 million of outstanding borrowings described above) of $206.0 million available for future borrowings; however, as of June 30, 2024, the Company was limited to additional borrowings of $16.4 million based on debt covenant compliance metrics. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of June 30, 2024, the Company was in compliance with all covenants.

[0000950170-24-094602:mdna:104]
[same as prior period, unchanged from 0000950170-24-057628:mdna:100]

[0000950170-24-094602:mdna:105]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin), at the Company’s option, at a rate per annum equal to either (a) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period (as defined below), an applicable margin of 2.15% per annum), or (b) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.15% per annum).

[0000950170-24-094602:mdna:106]
[same as prior period, unchanged from 0000950170-24-057628:mdna:102]

[0000950170-24-094602:mdna:107]
[same as prior period, unchanged from 0000950170-24-057628:mdna:103]

[0000950170-24-094602:mdna:108]
All Euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.25% per annum).

[0000950170-24-094602:mdna:109]
In addition, (x) if on or prior to December 31, 2024, we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025, we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-094602:mdna:110]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

[0000950170-24-094602:mdna:111]
The “Applicable Margin Interest Period” means the period commencing on the Second Amendment Effective Date and ending on the first date when each of the following conditions have been met: (a) the Covenant Relief Period has ended, (b) since the Second Amendment Effective Date, the borrowers have repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the borrowers have reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million, and (d) the borrowers are in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-24-094602:mdna:112]
[same as prior period, unchanged from 0000950170-24-057628:mdna:108]

[0000950170-24-094602:mdna:113]
[same as prior period, unchanged from 0000950170-24-057628:mdna:109]

[0000950170-24-094602:mdna:114]
All U.S. dollar borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to either (a) the Base Rate plus an applicable margin ranging from 0.90% to 1.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 2.40% per annum), or (b) Adjusted Term SOFR plus an applicable margin ranging from 1.90% to 2.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.40% per annum).

[0000950170-24-094602:mdna:115]
In addition, (x) if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025, we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-24-094602:mdna:116]
[same as prior period, unchanged from 0000950170-24-057628:mdna:112]

[0000950170-24-094602:mdna:117]
[same as prior period, unchanged from 0000950170-24-057628:mdna:114]

[0000950170-24-094602:mdna:118]
Covenants Under the Credit Agreement

[0000950170-24-094602:mdna:119]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable):

[0000950170-24-094602:mdna:120]
[same as prior period, unchanged from 0000950170-24-057628:mdna:117]

[0000950170-24-094602:mdna:121]
[same as prior period, unchanged from 0000950170-24-057628:mdna:118]

[0000950170-24-094602:mdna:122]
•
In the fiscal quarter in which a Springing Covenant Event occurs and the three consecutive quarterly test periods thereafter, (“Springing Covenant Period”), the following covenant levels:

[0000950170-24-094602:mdna:123]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

[0000950170-24-094602:mdna:124]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

[0000950170-24-094602:mdna:125]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

[0000950170-24-094602:mdna:126]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

[0000950170-24-094602:mdna:127]
•
If a Springing Covenant Period is not in effect, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

[0000950170-24-094602:mdna:128]
•
From December 31, 2023, through and including March 31, 2024: 3.25x.

[0000950170-24-094602:mdna:129]
•
From April 1, 2024, through and including June 30, 2024: 3.50x.

[0000950170-24-094602:mdna:130]
•
From July 1, 2024, and thereafter: 3.25x.

[0000950170-24-094602:mdna:131]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not be less than 1.25x.

[0000950170-24-094602:mdna:132]
•
During the Covenant Relief Period or a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million.

[0000950170-24-094602:mdna:133]
All obligations under the Credit Agreement (including under the Subline) are guaranteed by ADTRAN, Inc., the Company and certain subsidiaries of ADTRAN, Inc. (“Full Facility Guarantors”). To secure such guarantees, ADTRAN, Inc. and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and ADTRAN, Inc. has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries ("Subline Guarantors") have provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Adtran Networks has also granted security interests in favor of the Administrative Agent over substantially all of its tangible and intangible assets, to secure solely its obligations under the Subline. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

[0000950170-24-094602:mdna:134]
During the Covenant Relief Period, the Company is not permitted to make certain dividend payments to the Company's Stockholders or certain other Restricted Payments. However, the Company is permitted to make the Recurring Compensation Payment to each Adtran Networks shareholder (other than the Company), pursuant to the terms of the DPLTA.

[0000950170-24-094602:mdna:135]
Furthermore, the Credit Agreement, as amended, contain customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts; however, certain of the exceptions and carveouts are not permitted to be used during the Covenant Relief Period. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.

[0000950170-24-094602:mdna:136]
[same as prior period, unchanged from 0000950170-24-057628:mdna:134]

[0000950170-24-094602:mdna:137]
Net cash provided by operating activities of $56.5 million during the six months ended June 30, 2024, improved by $92.7 million compared to net cash used in operating activities of $36.2 million during the six months ended June 30, 2023. The increase was primarily due to the net loss for the six months ended June 30, 2024, and 2023 remaining flat, excluding the goodwill impairment charge of $292.6 million, as adjusted primarily for decreased depreciation and amortization, decreased deferred taxes and increased net cash inflows from working capital. Additional details related to our working capital and its drivers are discussed below.

[0000950170-24-094602:mdna:138]
Net accounts receivable decreased 14.0% from $216.4 million as of December 31, 2023, to $186.2 million as of June 30, 2024. There was an allowance for credit losses of $0.2 million as of June 30, 2024, and $0.4 million December 31, 2023. The decrease in net accounts receivable was due primarily to improved collections. Quarterly accounts receivable DSO decreased from 88 days as of December 31, 2023, to 75 days as of June 30, 2024. The decrease in DSO was primarily driven by customer and geographical mix of commercial terms.

[0000950170-24-094602:mdna:139]
Other receivables decreased 34.5% from $17.5 million as of December 31, 2023, to $11.4 million as of June 30, 2024. The decrease in other receivables was primarily attributable to a decrease in sales of raw materials.

[0000950170-24-094602:mdna:140]
Quarterly inventory turnover was 2.07 turns as of December 31, 2023, and 1.9 turns as of June 30, 2024. Inventory decreased 20.6% from $362.3 million as of December 31, 2023, to $287.9 million as of June 30, 2024. The decrease in inventory was primarily due to  a reduction in component purchases due to improved lead time, utilization of buffer stock and a $4.1 million write down of inventory due to a restructuring discontinuation of certain product lines within our Network Solutions segment. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory for customer demand and improve working capital.

[0000950170-24-094602:mdna:141]
Accounts payable decreased 2.7% from $162.9 million as of December 31, 2023, to $158.6 million as of June 30, 2024. The decrease in accounts payable was primarily due to a decrease in the average number of days payable to our trade suppliers from 67 days as of December 31, 2023 to 60 days as of June 30, 2024. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-24-094602:mdna:142]
[same as prior period, unchanged from 0000950170-24-057628:mdna:140]

[0000950170-24-094602:mdna:143]
Capital expenditures totaled approximately $29.4 million and $20.1 million for the six months ended June 30, 2024 and 2023, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements. The increase in capital expenditures for the three and six months ended June 30, 2024, is primarily attributable to increases in expenditures related to software and building renovation projects.

[0000950170-24-094602:mdna:144]
Our long-term investments increased 8.7% from $27.7 million as of December 31, 2023, to $30.2 million as of June 30, 2024. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $1.0 million and $1.0 million as of June 30, 2024, and December 31, 2023, respectively. Long-term investments as of June 30, 2024, and December 31, 2023, also included $29.2 million and $26.8 million, respectively, related to our deferred compensation plans. See Note 5 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0000950170-24-094602:mdna:145]
[same as prior period, unchanged from 0000950170-24-057628:mdna:143]

[0000950170-24-094602:mdna:146]
During the six month period ended June 30, 2023, we paid dividends totaling $14.2 million. On November 6, 2023, the Board of Directors suspended the Company’s quarterly cash dividend in order to reduce debt and interest expense and support the Company's capital efficiency program. We consequently did not pay any dividends during the six months ended June 30, 2024. The payment of any future dividends will be at the discretion of the Board of Directors and will depend on the Company’s financial condition, results of operations, capital requirements, and any other factors deemed relevant by the Board of Directors. In addition, the Wells Fargo Credit Agreement currently does not allow for the payment of dividends to shareholders. For additional information, see Note 11 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report and Liquidity & Capital Resources above.

[0000950170-24-094602:mdna:147]
[same as prior period, unchanged from 0000950170-24-057628:mdna:145]

[0000950170-24-094602:mdna:148]
There were no stock repurchases during the periods ended June 30, 2024, and 2023, and there currently is no authorized stock repurchase program.

[0000950170-24-094602:mdna:149]
[same as prior period, unchanged from 0000950170-24-057628:mdna:147]

[0000950170-24-094602:mdna:150]
To accommodate employee stock option exercises, the Company issued 36 thousand and 6 thousand shares of common stock which resulted in proceeds of $0.2 million and $0.1 million during the six months ended June 30, 2024, and 2023, respectively. Additionally, to accommodate Adtran Networks stock option exercises, Adtran Networks issued 13 thousand shares of Adtran Networks common stock which resulted in proceeds of $0.1 million, for the six months ended June 30, 2023. No Adtran Networks stock options were exercised in the six months ended June 30, 2024.

[0000950170-24-094602:mdna:151]
[same as prior period, unchanged from 0000950170-24-057628:mdna:149]

[0000950170-24-094602:mdna:152]
We maintain defined benefit pension plans covering employees in certain foreign countries. The Company's net non-current pension liability for all defined benefit pension plans totaled $11.5 million and $12.5 million as of June 30, 2024, and December 31, 2023, respectively and the net current pension liability for all defined benefit pension plans totaled $0.1 million as of June 30, 2024, and December 31, 2023, which is included in accounts payable on the Condensed Consolidated Balance Sheets. For additional information, see Note 12 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-24-094602:mdna:153]
[same as prior period, unchanged from 0000950170-24-057628:mdna:151]

[0000950170-24-094602:mdna:154]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors. The fair value of the assets held by the deferred compensation programs totaled $29.2 million and $26.8 million as of June 30, 2024, and December 31, 2023, respectively, and is included in long-term investments on the Condensed Consolidated Balance Sheets. The amounts payable to the deferred compensation program participants totaled $30.6 million and $29.0 million as of June 30, 2024, and December 31, 2023, respectively. For additional information, see Note 5 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-24-094602:mdna:155]
[same as prior period, unchanged from 0000950170-24-057628:mdna:153]

[0000950170-24-094602:mdna:156]
We have exposure to credit losses from off-balance sheet exposures, to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of June 30, 2024. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 18 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-094602:mdna:157]
[same as prior period, unchanged from 0000950170-24-057628:mdna:155]

[0000950170-24-094602:mdna:158]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of June 30, 2024, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA and currency hedging arrangements, which are discussed below). Other than operating lease obligations, the cash requirements table excludes interest payments.

[0000950170-24-094602:mdna:159]
| (In thousands) |  | Total |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | 2028 |  |  | Thereafter |  |
| Wells Fargo credit agreement(1) |  | $ | 190,273 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 190,273 |  |  | $ | — |  |  | $ | — |  |
| Secured borrowings related to accounts receivable(2) |  |  | 17,316 |  |  |  | 17,316 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations(3) |  |  | 280,889 |  |  |  | 228,386 |  |  |  | 48,338 |  |  |  | 4,110 |  |  |  | 55 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations(4) |  |  | 39,295 |  |  |  | 4,605 |  |  |  | 8,400 |  |  |  | 6,332 |  |  |  | 4,865 |  |  |  | 3,486 |  |  |  | 11,607 |  |
| Totals |  | $ | 527,773 |  |  | $ | 250,307 |  |  | $ | 56,738 |  |  | $ | 10,442 |  |  | $ | 195,193 |  |  | $ | 3,486 |  |  | $ | 11,607 |  |

[0000950170-24-094602:mdna:160]
55

[0000950170-24-094602:mdna:161]
[same as prior period, unchanged from 0000950170-24-057628:mdna:158]

[0000950170-24-094602:mdna:162]
[same as prior period, unchanged from 0000950170-24-057628:mdna:159]

[0000950170-24-094602:mdna:163]
[same as prior period, unchanged from 0000950170-24-057628:mdna:160]

[0000950170-24-094602:mdna:164]
[same as prior period, unchanged from 0000950170-24-057628:mdna:161]

[0000950170-24-094602:mdna:165]
through 2027. See Note 18 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report

[0000950170-24-094602:mdna:166]
[same as prior period, unchanged from 0000950170-24-057628:mdna:163]

[0000950170-24-094602:mdna:167]
[same as prior period, unchanged from 0000950170-24-057628:mdna:164]

[0000950170-24-094602:mdna:168]
locations. Our operating leases had remaining lease terms ranging from 6 months to 173 months as of June 30, 2024.

[0000950170-24-094602:mdna:169]
[same as prior period, unchanged from 0000950170-24-057628:mdna:166]

[0000950170-24-094602:mdna:170]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into the Credit Agreement with the Administrative Agent and the other lenders named therein. The Credit Agreement was subsequently amended on August 9, 2023, January 16, 2024, March 12, 2024, and June 4, 2024. The Credit Agreement provides for a revolving line of credit and a DDTL. As of June 30, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $190.3 million. As of June 30, 2024, there were no borrowings under the DDTL. The term of the DDTL facility expires on August 9, 2024. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. See Note 11 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report and “Liquidity and Capital Resources” in Part I, Item 2 of this report for additional information.

[0000950170-24-094602:mdna:171]
[same as prior period, unchanged from 0000950170-24-057628:mdna:168]

[0000950170-24-094602:mdna:172]
On November 3, 2022, the Company entered into a euro/U.S. dollar forward contract arrangement ("Initial Forward") with Wells Fargo Bank, N.A. (“Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million converted to U.S. dollars at a daily fixed forward rate averaging EUR/USD 1.03. The aggregate amount of €160.0 million is divided into eight quarterly tranches of €20.0 million, which commenced in the fourth quarter of 2022. During the six months ended June 30, 2024, the Company settled two €20.0 million forward contract tranches and the remaining amount will be divided into two quarterly tranches of €20.0 million over the remainder of 2024. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-24-094602:mdna:173]
On March 21, 2023, the Company entered into a Euro/U.S. dollar forward contract arrangements (“Forward”) with the Hedge Counterparty. Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of €160.0 million converted to U.S. dollars at a daily fixed forward rate ranging from $1.09 to $1.10 per €1.00. During the six months ended June 30, 2024, the Company settled two $20.0 million forward contract tranches and the remaining amount will be divided into two quarterly tranches of $20.0 million. These forward contracts were executed on March 21, 2023 (to sell EUR/buy USD) and were entered into for the purpose of unwinding the Initial Forward (to buy EUR/sell USD). The drawdown dates of the Initial Forward are set to the same date as the maturity of the new offsetting Forward.

[0000950170-24-094602:mdna:174]
[same as prior period, unchanged from 0000950170-24-057628:mdna:171]

[0000950170-24-094602:mdna:175]
The Company was party to a receivable purchase agreement with a third-party financial institution (“Factor”), which accelerates receivable collection and helps to better manage cash flow. As of December 31, 2023, no accounts receivable were factored under the agreement or held in the reserve account.

[0000950170-24-094602:mdna:176]
On December 19, 2023, the agreement with the Factor was terminated and the Company, entered into a receivables purchase agreement with a third-party financial institution (“New Factor”) to replace the Company’s prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The New Factor provides for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The New Factor qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. See Note 2 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-094602:mdna:177]
[same as prior period, unchanged from 0000950170-24-057628:mdna:174]

[0000950170-24-094602:mdna:178]
[same as prior period, unchanged from 0000950170-24-057628:mdna:175]

[0000950170-24-094602:mdna:179]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated in 2023.

[0000950170-24-094602:mdna:180]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of June 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €345.6 million or approximately $371.3 million, based on an exchange rate as of June 30, 2024, and reflecting interest accrued through June 30, 2024, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-24-094602:mdna:181]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.4 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three and six months ended June 30, 2024, and 2023, we accrued $2.9 million and $5.7 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

[0000950170-24-094602:mdna:182]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or approximately $20 thousand and $25 thousand, respectively, based on an exchange rate as of June 30, 2024, were paid to Adtran Networks shareholders. For the three and six months ended June 30, 2023, approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €0.8 thousand and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

[0000950170-24-094602:mdna:183]
We currently hold 34,026,174 no-par value bearer shares of Adtran Networks, representing 65.37% of Adtran Networks outstanding shares as of June 30, 2024.

[0000950170-24-094602:mdna:184]
[same as prior period, unchanged from 0000950170-24-057628:mdna:182]

[0000950170-24-094602:mdna:185]
[same as prior period, unchanged from 0000950170-24-057628:mdna:183]

[0000950170-24-094602:mdna:186]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (“Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expands upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment.

[0000950170-24-094602:mdna:187]
Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). On October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze. Additionally, on April 11, 2024, management determined to close a facility in Greifswald, Germany. The closure of the facility is expected to be completed by December 31, 2024.

[0000950170-24-094602:mdna:188]
During the three and six months ended June 30, 2024, we recognized $17.5 million and $34.6 million of costs related to the Business Efficiency Program, respectively. The costs recognized during the six months ended June 30, 2024, included charges of $8.9 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.1 million relates to inventory write-downs and $4.8 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss. Since the inception of the Business Efficiency Program, we recognized $59.7 million of costs. We expect costs in the third quarter of 2024 and thereafter relating to the Business Efficiency Program to range between $8.1 million and $19.1 million. Management expects these planned costs to include severance costs ranging from $4.6 million to $11.4 million in connection with reductions in workforce and site consolidation transaction expenses (primarily brokers fees and Greifswald exit costs) ranging from $3.5 million to $7.7 million. The broker fees related to our site consolidation expenses will be netted against proceeds upon the sale of the building(s). Future cash payments include: severance costs and outplacement fees that are anticipated to be in the range of $21.3 million to $28.1 million, payments relating to the site consolidation transaction expenses that are anticipated to be in the range of $3.4 million to $7.6 million and remaining payments related to the inventory strategy shift of $2.0 million. We may also incur other charges or cash expenditures not currently contemplated due to events that may occur as a result of, or associated with, the Business Efficiency Program, including potential impairment charges related to the discontinuance of additional product lines, regulatory requirements related to personnel measures, and site closures.  However, we are not able to estimate the amount or range of amounts of such potential incremental charges as of the date of this filing.

[0000950170-24-094602:mdna:189]
[same as prior period, unchanged from 0000950170-24-057628:mdna:187]

[0000950170-24-094602:mdna:190]
During the three and six months ended June 30, 2024, and 2023, we recognized $0.7 million and $1.2 million of integration costs related to the Business Combination, respectively, that are included in selling, general and administrative expenses, research & development expenses and cost of revenue in the Condensed Consolidated Statement of Loss. We expect to incur additional integration costs and expenses associated with the implementation of the DPLTA throughout 2024 and such costs are expected to be material. These costs are separate and apart from the costs associated with the integration program discussed below.

[0000950170-24-094602:mdna:191]
[same as prior period, unchanged from 0000950170-24-057628:mdna:189]

[0000950170-24-094602:mdna:192]
During the fourth quarter of 2022, the Company initiated a multi-year integration program designed to optimize the assets, business processes, and information technology systems of the Company. During the three and six months ended June 30, 2023, we recognized $0.6 million and $1.4 million, respectively, of integration costs related to the Business Combination, of restructuring costs relating to the Business Combination under the multi-year integration program that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss. We did not incur any costs related to our multi-year integration program in the three and six months ended June 30, 2024. The Company does not anticipate additional material expenses to be incurred in connection with this integration program. See Note 19 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-24-094602:mdna:193]
58

[0000950170-24-094602:mdna:194]
[same as prior period, unchanged from 0000950170-24-057628:mdna:192]

[0000950170-24-094602:mdna:195]
During the six months ended June 30, 2024, other than the Exit Compensation payments, Annual Recurring Compensation under the DPLTA, restructuring costs and increased debt service costs, there have been no other material changes in cash requirements from those discussed in the 2023 Form 10-K and our cash requirements table shown in Liquidity and Capital Resources above.

[0000950170-24-094602:mdna:196]
[same as prior period, unchanged from 0000950170-24-057628:mdna:194]

[0000950170-24-094602:mdna:197]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2024, and December 31, 2023, we had commitments related to these bonds totaling $13.9 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-24-094602:mdna:198]
[same as prior period, unchanged from 0000950170-24-057628:mdna:196]

[0000950170-24-094602:mdna:199]
[same as prior period, unchanged from 0000950170-24-057628:mdna:197]

[0000950170-24-094602:mdna:200]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part I, Item 1 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the critical accounting policies affect our more significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements. During the six months ended June 30, 2024, there were no significant changes to our critical accounting policies and estimates as described in the financial statements contained in the 2023 Form 10-K, except for goodwill as discussed below.

[0000950170-24-094602:mdna:201]
[same as prior period, unchanged from 0000950170-24-057628:mdna:199]

[0000950170-24-094602:mdna:202]
[same as prior period, unchanged from 0000950170-24-057628:mdna:200]

[0000950170-24-094602:mdna:203]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of the Network Solutions reporting unit using a combination of an income approach and a market-based peer group analysis. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit during the three months ended March 31, 2024. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the three months ended March 31, 2024.

[0000950170-24-094602:mdna:204]
During the second quarter of 2024, the Company qualitatively assessed the carrying value of our Services & Support reporting unit for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Based on our assessment of certain qualitative factors such as macroeconomic conditions, industry and market considerations, cost factors and overall financial performance, management concluded that the fair value of the Services & Support reporting unit was more likely than not greater than its carrying amount as of June 30, 2024. Therefore, no impairment of goodwill was recorded during the three months ended June 30, 2024. Our Network Solutions reporting unit had no remaining goodwill and our Services & Support reporting unit had $54.9 million of goodwill as of June 30, 2024, respectively.
