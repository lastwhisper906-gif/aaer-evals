# ADTN 8-K — 0000950170-24-091207 filed 2024-08-06

## item codes, every 8-K on or before 2024-08-09

- 2024-08-06 0000950170-24-091207 — 2.02, 7.01, 9.01
- 2024-08-02 0000950170-24-089974 — 5.02
- 2024-06-10 0001193125-24-158388 — 1.01, 2.03, 9.01
- 2024-05-09 0000950170-24-056830 — 5.02, 5.07, 9.01
- 2024-05-07 0000950170-24-053920 — 2.02, 7.01, 9.01
- 2024-05-03 0001193125-24-130896 — 2.02, 7.01, 9.01
- 2024-04-17 0000950170-24-045151 — 2.05, 9.01
- 2024-03-15 0000950170-24-031864 — 2.02, 9.01
- 2024-02-27 0000950170-24-020613 — 2.02, 7.01, 9.01
- 2024-02-20 0001193125-24-040068 — 4.02
- 2024-01-22 0001193125-24-011697 — 1.01, 2.03, 9.01
- 2023-12-06 0001193125-23-289895 — 5.02, 9.01
- 2023-12-05 0001193125-23-289150 — 5.02, 9.01
- 2023-11-07 0001193125-23-271842 — 2.02, 7.01, 9.01
- 2023-10-24 0001193125-23-261665 — 5.02, 5.03, 9.01
- 2023-10-17 0001193125-23-257289 — 2.02, 7.01, 9.01
- 2023-09-29 0001193125-23-246498 — 5.02
- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2024-08-09

- 2024-02-29 0000950170-24-023141 — NT 10-K, for the period ended 2023-12-31
- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-24-091207:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0000950170-24-091207:8k_2_02:2]
EX-99.1

[0000950170-24-091207:8k_2_02:3]
ADTRAN Holdings, Inc. reports second quarter 2024 financial results

[0000950170-24-091207:8k_2_02:4]
Huntsville, Alabama, USA. — August 05, 2024 — ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” or the “Company”) today announced its unaudited financial results for the second quarter of 2024.

[0000950170-24-091207:8k_2_02:5]
•
Revenue: $226.0 million

[0000950170-24-091207:8k_2_02:6]
•
Gross margin:

[0000950170-24-091207:8k_2_02:7]
o
GAAP gross margin: 36.1%; Non-GAAP gross margin: 41.9%

[0000950170-24-091207:8k_2_02:8]
•
Operating margin:

[0000950170-24-091207:8k_2_02:9]
o
GAAP operating margin negative 17.0%; Non-GAAP operating margin positive 0.7%

[0000950170-24-091207:8k_2_02:10]
•
Net Income (Loss):

[0000950170-24-091207:8k_2_02:11]
o
GAAP net loss attributable to the Company: $49.9 million; Non-GAAP net loss attributable to the Company: $18.8 million

[0000950170-24-091207:8k_2_02:12]
•
Earnings (Loss) per share:

[0000950170-24-091207:8k_2_02:13]
o
GAAP diluted loss per share attributable to the Company: $0.63; Non-GAAP diluted loss per share attributable to the Company: $0.24.

[0000950170-24-091207:8k_2_02:14]
ADTRAN Holdings’ Chairman and Chief Executive Officer Tom Stanton stated, "We had a solid second quarter, during which we saw improvements across all our major operating metrics, including profitability and working capital. During the quarter, we saw growth in our customer base across the U.S. and Europe as customers continue to adopt our latest fiber networking solutions”.

[0000950170-24-091207:8k_2_02:15]
For the third quarter of 2024, the Company expects revenue in a range of $215.0 million to $235.0 million. Non-GAAP operating margin is expected in a range of -1.0% to +3.0%.

[0000950170-24-091207:8k_2_02:16]
Furthermore, non-GAAP operating margin (which is calculated as non-GAAP operating loss divided by revenue) is a non-GAAP financial measure. The Company has provided third quarter guidance with regard to non-GAAP operating margin. This measure excludes from the corresponding GAAP financial measure the effect of adjustments as described below. The Company has not provided a reconciliation of such non-GAAP guidance to guidance presented on a GAAP basis because it cannot predict and quantify without unreasonable effort all of the adjustments that may occur during the period due to the difficulty of predicting the timing and amounts of various items within a reasonable range. In particular, non-GAAP operating margin excludes certain items, including continued restructuring and integration expenses that will continue to evolve as our business efficiency program is implemented, that the Company is unable to quantitatively predict. Depending on the materiality of these items, they could have a significant impact on the Company's GAAP financial results.

[0000950170-24-091207:8k_2_02:17]
The Company will hold a conference call to discuss its second quarter results on Tuesday, August 06, 2024, at 9:30 a.m. Central Time, or 4:30 p.m. Central European Summer Time. The Company will webcast this conference call. To listen, simply visit our Investor Relations site at investors.adtran.com approximately 10 minutes prior to the start of the call, click on the event “ADTRAN Holdings Releases 2nd Quarter 2024 Financial Results and Earnings Call”, and click on the webcast link.

[0000950170-24-091207:8k_2_02:18]
An online replay of the Company’s conference call, as well as the transcript of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit investors.adtran.com or email investor.relations@adtran.com.

[0000950170-24-091207:8k_2_02:19]
Cautionary Note Regarding Forward-Looking Statements

[0000950170-24-091207:8k_2_02:20]
Statements contained in this press release which are not historical facts, such as those relating to expectations regarding future revenues; ADTRAN Holdings ability to reduce its inventory levels; ADTRAN Holdings’ potential funding opportunities; and ADTRAN Holdings’

[0000950170-24-091207:8k_2_02:21]
Explanation of Use of Non-GAAP Financial Measures

[0000950170-24-091207:8k_2_02:22]
Set forth in the tables below are reconciliations of gross profit, gross margin, operating expenses, operating loss, other (expense) income, net loss inclusive of the non-controlling interest, net loss attributable to the Company, net income attributable to the non-controlling interest, and loss per share - basic and diluted, attributable to the Company, and net cash provided by (used in) operating activities, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income (loss), non-GAAP other expense, non-GAAP net loss inclusive of the non-controlling interest, non-GAAP net loss attributable to the Company, non-GAAP net income attributable to the non-controlling interest, non-GAAP loss per share - basic and diluted, attributable to the Company, respectively, and non-GAAP free cash flow. Such non-GAAP measures exclude acquisition-related expenses, amortization and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments as well as legal and advisory fees related to a potential significant transaction), stock-based compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, integration expenses, restructuring expenses,  goodwill impairments, the tax effect of these adjustments to net loss and purchases of property, plant and equipment. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of these non-GAAP measures, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0000950170-24-091207:8k_2_02:23]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0000950170-24-091207:8k_2_02:24]
About Adtran

[0000950170-24-091207:8k_2_02:25]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises, government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the largest shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE. Find more at Adtran, LinkedIn and Twitter.

[0000950170-24-091207:8k_2_02:26]
Published by

[0000950170-24-091207:8k_2_02:27]
ADTRAN Holdings, Inc.

[0000950170-24-091207:8k_2_02:28]
www.adtran.com

[0000950170-24-091207:8k_2_02:29]
For media

[0000950170-24-091207:8k_2_02:30]
Gareth Spence

[0000950170-24-091207:8k_2_02:31]
+44 1904 699 358

[0000950170-24-091207:8k_2_02:32]
public.relations@adtran.com

[0000950170-24-091207:8k_2_02:33]
For investors

[0000950170-24-091207:8k_2_02:34]
Rhonda Lambert

[0000950170-24-091207:8k_2_02:35]
investor@adtran.com

[0000950170-24-091207:8k_2_02:36]
Condensed Consolidated Balance Sheets

[0000950170-24-091207:8k_2_02:37]
(Unaudited)

[0000950170-24-091207:8k_2_02:38]
(In thousands)

[0000950170-24-091207:8k_2_02:39]
|  | June 30, |  |  | December 31, |  |
|  | 2024 |  |  | 2023 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 111,185 |  |  | $ | 87,167 |  |
| Accounts receivable, net |  | 186,176 |  |  |  | 216,445 |  |
| Other receivables |  | 11,436 |  |  |  | 17,450 |  |
| Income tax receivable |  | 13,050 |  |  |  | 7,933 |  |
| Inventory, net |  | 287,860 |  |  |  | 362,295 |  |
| Prepaid expenses and other current assets |  | 58,612 |  |  |  | 45,566 |  |
| Total Current Assets |  | 668,319 |  |  |  | 736,856 |  |
| Property, plant and equipment, net |  | 134,578 |  |  |  | 123,020 |  |
| Deferred tax assets |  | 24,931 |  |  |  | 25,787 |  |
| Goodwill |  | 54,897 |  |  |  | 353,415 |  |
| Intangibles, net |  | 290,793 |  |  |  | 327,985 |  |
| Other non-current assets |  | 87,105 |  |  |  | 87,706 |  |
| Long-term investments |  | 30,159 |  |  |  | 27,743 |  |
| Total Assets | $ | 1,290,782 |  |  | $ | 1,682,512 |  |
| Liabilities, Redeemable Non-Controlling Interest and Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 158,550 |  |  | $ | 162,922 |  |
| Unearned revenue |  | 55,107 |  |  |  | 46,731 |  |
| Accrued expenses and other liabilities |  | 36,307 |  |  |  | 37,607 |  |
| Accrued wages and benefits |  | 37,520 |  |  |  | 27,030 |  |
| Income tax payable, net |  | 2,228 |  |  |  | 5,221 |  |
| Total Current Liabilities |  | 289,712 |  |  |  | 279,511 |  |
| Non-current revolving credit agreement outstanding |  | 190,273 |  |  |  | 195,000 |  |
| Deferred tax liabilities |  | 21,077 |  |  |  | 35,655 |  |
| Non-current unearned revenue |  | 26,584 |  |  |  | 25,109 |  |
| Non-current pension liability |  | 11,505 |  |  |  | 12,543 |  |
| Deferred compensation liability |  | 30,601 |  |  |  | 29,039 |  |
| Non-current lease obligations |  | 26,613 |  |  |  | 31,420 |  |
| Other non-current liabilities |  | 34,445 |  |  |  | 28,657 |  |
| Total Liabilities |  | 630,810 |  |  |  | 636,934 |  |
| Redeemable Non-Controlling Interest |  | 439,743 |  |  |  | 451,756 |  |
| Equity |  |  |  |  |  |
| Common stock |  | 791 |  |  |  | 790 |  |
| Additional paid-in capital |  | 802,737 |  |  |  | 795,304 |  |
| Accumulated other comprehensive income |  | 28,274 |  |  |  | 47,461 |  |
| Retained deficit |  | (606,375 | ) |  |  | (243,908 | ) |
| Treasury stock |  | (5,198 | ) |  |  | (5,825 | ) |
| Total Equity |  | 220,229 |  |  |  | 593,822 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity | $ | 1,290,782 |  |  | $ | 1,682,512 |  |

[0000950170-24-091207:8k_2_02:40]
Condensed Consolidated Statements of Loss

[0000950170-24-091207:8k_2_02:41]
(Unaudited)

[0000950170-24-091207:8k_2_02:42]
(In thousands, except per share amounts)

[0000950170-24-091207:8k_2_02:43]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 179,194 |  |  | $ | 283,002 |  |  | $ | 360,467 |  |  | $ | 565,420 |  |  |
| Services & Support |  |  | 46,797 |  |  |  | 44,376 |  |  |  | 91,697 |  |  |  | 85,870 |  |  |
| Total Revenue |  |  | 225,991 |  |  |  | 327,378 |  |  |  | 452,164 |  |  |  | 651,290 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 124,457 |  |  |  | 216,960 |  |  |  | 250,783 |  |  |  | 436,090 |  |  |
| Network Solutions - inventory write-down and other charges |  |  | 143 |  |  |  | — |  |  |  | 8,925 |  |  |  | — |  |  |
| Services & Support |  |  | 19,816 |  |  |  | 17,865 |  |  |  | 38,626 |  |  |  | 34,839 |  |  |
| Total Cost of Revenue |  |  | 144,416 |  |  |  | 234,825 |  |  |  | 298,334 |  |  |  | 470,929 |  |  |
| Gross Profit |  |  | 81,575 |  |  |  | 92,553 |  |  |  | 153,830 |  |  |  | 180,361 |  |  |
| Selling, general and administrative expenses |  |  | 59,493 |  |  |  | 66,583 |  |  |  | 118,593 |  |  |  | 133,980 |  |  |
| Research and development expenses |  |  | 60,388 |  |  |  | 70,598 |  |  |  | 120,639 |  |  |  | 140,741 |  |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | 292,583 |  |  |  | — |  |  |
| Operating Loss |  |  | (38,306 | ) |  |  | (44,628 | ) |  |  | (377,985 | ) |  |  | (94,360 | ) |  |
| Interest and dividend income |  |  | 366 |  |  |  | 358 |  |  |  | 763 |  |  |  | 662 |  |  |
| Interest expense |  |  | (6,906 | ) |  |  | (4,064 | ) |  |  | (11,504 | ) |  |  | (7,351 | ) |  |
| Net investment gain |  |  | 872 |  |  |  | 1,262 |  |  |  | 3,125 |  |  |  | 2,514 |  |  |
| Other (expense) income, net |  |  | (901 | ) |  |  | 2,494 |  |  |  | 409 |  |  |  | 2,191 |  |  |
| Loss Before Income Taxes |  |  | (44,875 | ) |  |  | (44,578 | ) |  |  | (385,192 | ) |  |  | (96,344 | ) |  |
| Income tax (expense) benefit |  |  | (2,136 | ) |  |  | 8,363 |  |  |  | 16,511 |  |  |  | 19,676 |  |  |
| Net Loss |  | $ | (47,011 | ) |  | $ | (36,215 | ) |  | $ | (368,681 | ) |  | $ | (76,668 | ) |  |
| Less: Net Income attributable to non-controlling interest |  |  | 2,854 |  |  |  | 2,882 |  |  |  | 5,734 |  |  |  | 2,512 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (49,865 | ) |  | $ | (39,097 | ) |  | $ | (374,415 | ) |  | $ | (79,180 | ) |  |
| Weighted average shares outstanding – basic |  |  | 78,852 |  |  |  | 78,366 |  |  |  | 78,803 |  |  |  | 78,364 |  |  |
| Weighted average shares outstanding – diluted |  |  | 78,852 |  |  |  | 78,366 |  |  |  | 78,803 |  |  |  | 78,364 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.63 | ) |  | $ | (0.50 | ) |  | $ | (4.75 | ) |  | $ | (1.01 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.63 | ) |  | $ | (0.50 | ) |  | $ | (4.75 | ) |  | $ | (1.01 | ) |  |

[0000950170-24-091207:8k_2_02:44]
Condensed Consolidated Statements of Cash Flows

[0000950170-24-091207:8k_2_02:45]
(Unaudited)

[0000950170-24-091207:8k_2_02:46]
(In thousands)

[0000950170-24-091207:8k_2_02:47]
|  |  | Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net loss |  | $ | (368,681 | ) |  | $ | (76,668 | ) |
| Adjustments to reconcile net loss to net cash provided by (used in) operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 45,156 |  |  |  | 67,467 |  |
| Goodwill impairment |  |  | 292,583 |  |  |  | — |  |
| Amortization of debt issuance cost |  |  | 1,013 |  |  |  | 291 |  |
| Gain on investments, net |  |  | (2,867 | ) |  |  | (4,530 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 185 |  |  |  | — |  |
| Stock-based compensation expense |  |  | 7,793 |  |  |  | 8,103 |  |
| Deferred income taxes |  |  | (13,684 | ) |  |  | (31,962 | ) |
| Other, net |  |  | (126 | ) |  |  | 130 |  |
| Inventory write down - business efficiency program |  |  | 4,135 |  |  |  | — |  |
| Inventory reserves |  |  | 3,722 |  |  |  | 20,885 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 26,913 |  |  |  | 40,975 |  |
| Other receivables |  |  | 6,279 |  |  |  | 561 |  |
| Income taxes receivable, net |  |  | (5,653 | ) |  |  | — |  |
| Inventory |  |  | 62,151 |  |  |  | (6,920 | ) |
| Prepaid expenses, other current assets and other assets |  |  | (14,731 | ) |  |  | 7,105 |  |
| Accounts payable |  |  | (3,966 | ) |  |  | (67,923 | ) |
| Accrued expenses and other liabilities |  |  | 19,152 |  |  |  | 110 |  |
| Income taxes payable, net |  |  | (2,878 | ) |  |  | 6,216 |  |
| Net cash provided by (used in) operating activities |  |  | 56,496 |  |  |  | (36,160 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (29,369 | ) |  |  | (20,118 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 956 |  |  |  | 2,074 |  |
| Purchases of available-for-sale investments |  |  | (121 | ) |  |  | (580 | ) |
| Proceeds from beneficial interests in securitized accounts receivable |  |  | — |  |  |  | 1,156 |  |
| Net cash used in investing activities |  |  | (28,534 | ) |  |  | (17,468 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (189 | ) |  |  | (6,315 | ) |
| Proceeds from stock option exercises |  |  | 219 |  |  |  | 163 |  |
| Dividend payments |  |  | — |  |  |  | (14,156 | ) |
| Proceeds from receivables purchase agreement |  |  | 68,556 |  |  |  | — |  |
| Repayments on receivables purchase agreement |  |  | (66,399 | ) |  |  | — |  |
| Proceeds from draw on revolving credit agreements |  |  | — |  |  |  | 163,729 |  |
| Repayment of revolving credit agreements |  |  | (5,000 | ) |  |  | (49,155 | ) |
| Payment of redemption of redeemable non-controlling interest |  |  | (25 | ) |  |  | (1,202 | ) |
| Payment of debt issuance cost |  |  | (1,994 | ) |  |  | — |  |
| Repayment of notes payable |  |  | — |  |  |  | (24,885 | ) |
| Net cash (used in) provided by financing activities |  |  | (4,832 | ) |  |  | 68,179 |  |
| Net increase in cash and cash equivalents |  |  | 23,130 |  |  |  | 14,551 |  |
| Effect of exchange rate changes |  |  | 888 |  |  |  | 1,099 |  |
| Cash and cash equivalents, beginning of period |  |  | 87,167 |  |  |  | 108,644 |  |
| Cash and cash equivalents, end of period |  | $ | 111,185 |  |  | $ | 124,294 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 6,554 |  |  | $ | 4,719 |  |
| Cash paid for income taxes |  | $ | 7,433 |  |  | $ | — |  |
| Cash used in operating activities related to operating leases |  | $ | 4,780 |  |  | $ | 5,082 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 1,999 |  |  | $ | 515 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 1,059 |  |  | $ | 2,662 |  |

[0000950170-24-091207:8k_2_02:48]
Supplemental Information

[0000950170-24-091207:8k_2_02:49]
Reconciliation of Gross Profit and Gross Margin to

[0000950170-24-091207:8k_2_02:50]
Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0000950170-24-091207:8k_2_02:51]
(Unaudited)

[0000950170-24-091207:8k_2_02:52]
(In thousands)

[0000950170-24-091207:8k_2_02:53]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |  | June 30, 2023 |  |  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| Total Revenue |  | $ | 225,991 |  |  | $ | 226,173 |  |  | $ | 327,378 |  |  |  | $ | 452,164 |  |  | $ | 651,290 |  |
| Cost of Revenue |  | $ | 144,416 |  |  | $ | 153,918 |  |  | $ | 234,825 |  |  |  | $ | 298,334 |  |  | $ | 470,929 |  |
| Acquisition-related expenses, amortizations and adjustments(1) |  |  | (10,064 | ) |  |  | (10,177 | ) |  |  | (33,439 | ) |  |  |  | (20,241 | ) |  |  | (66,017 | ) |
| Stock-based compensation expense |  |  | (280 | ) |  |  | (275 | ) |  |  | (335 | ) |  |  |  | (555 | ) |  |  | (575 | ) |
| Restructuring expenses(2) |  |  | (2,788 | ) |  |  | (11,247 | ) |  |  | — |  |  |  |  | (14,035 | ) |  |  | (76 | ) |
| Integration expenses(3) |  |  | (35 | ) |  |  | (35 | ) |  |  | — |  |  |  |  | (70 | ) |  |  | — |  |
| Non-GAAP Cost of Revenue |  | $ | 131,249 |  |  | $ | 132,184 |  |  | $ | 201,051 |  |  |  | $ | 263,433 |  |  | $ | 404,261 |  |
| Gross Profit |  | $ | 81,575 |  |  | $ | 72,255 |  |  | $ | 92,553 |  |  |  | $ | 153,830 |  |  | $ | 180,361 |  |
| Non-GAAP Gross Profit |  | $ | 94,742 |  |  | $ | 93,989 |  |  | $ | 126,327 |  |  |  | $ | 188,731 |  |  | $ | 247,029 |  |
| Gross Margin |  |  | 36.1 | % |  |  | 31.9 | % |  |  | 28.3 | % |  |  |  | 34.0 | % |  |  | 27.7 | % |
| Non-GAAP Gross Margin |  |  | 41.9 | % |  |  | 41.6 | % |  |  | 38.6 | % |  |  |  | 41.7 | % |  |  | 37.9 | % |

[0000950170-24-091207:8k_2_02:54]
(1)  Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations.

[0000950170-24-091207:8k_2_02:55]
(2)  Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. These expenses include inventory write down and other charges of $8.9 million for the six months ended June 30, 2024, incurred as a result of a strategy shift which included discontinuance of certain product lines in connection with the Business Efficiency Program. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and is expected to be substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany. These expenses include restructuring wage charges of $2.3 million for the three and six months ended June 30, 2024, respectively. The closure of the facility is expected to be completed by December 31, 2024.

[0000950170-24-091207:8k_2_02:56]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE. Includes fees incurred for the expansion of internal controls at Adtran Networks SE and the implementation of the DPTLA.

[0000950170-24-091207:8k_2_02:57]
Supplemental Information

[0000950170-24-091207:8k_2_02:58]
Reconciliation of Operating Expenses to Non-GAAP Operating Expenses

[0000950170-24-091207:8k_2_02:59]
(Unaudited)

[0000950170-24-091207:8k_2_02:60]
(In thousands)

[0000950170-24-091207:8k_2_02:61]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | March 31, |  |  | June 30, |  |  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2024 |  |  | 2024 |  |  | 2023 |  |  |  | 2024 |  |  | 2023 |  |  |
| Operating Expenses |  | $ | 119,881 |  |  | $ | 411,934 |  |  | $ | 137,181 |  |  |  | $ | 531,815 |  |  | $ | 274,721 |  |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | (7,233 | ) | (1) |  | (4,881 | ) | (6) |  | (4,398 | ) | (11) |  |  | (12,114 | ) | (15) |  | (8,982 | ) | (19) |
| Stock-based compensation expense |  |  | (3,321 | ) | (2) |  | (3,447 | ) | (7) |  | (3,974 | ) | (12) |  |  | (6,768 | ) | (16) |  | (7,432 | ) | (20) |
| Restructuring expenses |  |  | (14,742 | ) | (3) |  | (5,862 | ) | (8) |  | (5,868 | ) | (13) |  |  | (20,604 | ) | (17) |  | (8,229 | ) | (21) |
| Integration expenses |  |  | (531 | ) | (4) |  | (480 | ) | (9) |  | (563 | ) | (14) |  |  | (1,011 | ) | (18) |  | (1,412 | ) | (22) |
| Deferred compensation adjustments(5) |  |  | (848 | ) |  |  | (1,940 | ) |  |  | 307 |  |  |  |  | (2,788 | ) |  |  | (87 | ) |  |
| Goodwill impairment |  |  | — |  |  |  | (292,583 | ) | (10) |  | — |  |  |  |  | (292,583 | ) | (10) |  | — |  |  |
| Non-GAAP Operating Expenses |  | $ | 93,206 |  |  | $ | 102,741 |  |  | $ | 122,685 |  |  |  | $ | 195,947 |  |  | $ | 248,579 |  |  |

[0000950170-24-091207:8k_2_02:62]
(1) Includes $3.9M of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations and $2.8 million of legal and advisory fees related to a potential strategic transaction which are both included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:63]
(2) $2.4 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:64]
(3) $3.5 million is included in selling, general and administrative expenses and $11.3 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses of $13.5 million of wage related and other charges due to the Greifswald facility closure of which $2.6 million is included in selling, general and administrative and $10.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:65]
(4) $0.5 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE.

[0000950170-24-091207:8k_2_02:66]
(5) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-24-091207:8k_2_02:67]
(6) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $4.4 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:68]
(7) $2.5 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:69]
(8) $1.8 million is included in selling, general and administrative expenses and $4.1 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:70]
(9) $0.5 million is included in selling, general and administrative expenses and $0.02 million is included in research and development expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE.

[0000950170-24-091207:8k_2_02:71]
(10) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company's market capitalization, cautious service provider spending due to economic uncertainty and continued elevated customer inventory adjustments.

[0000950170-24-091207:8k_2_02:72]
(11) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $3.9 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:73]
(12) $2.7 million is included in selling, general and administrative expenses and $1.3 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:74]
(13) $1.4 million is included in selling, general and administrative expenses and $4.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:75]
(14) $0.6 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at Adtran Networks SE and the implementation of the DPLTA.

[0000950170-24-091207:8k_2_02:76]
(15) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $11.2 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:77]
(16) $4.9 million is included in selling, general and administrative expenses and $1.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:78]
(17) $5.3 million is included in selling, general and administrative expenses and $15.3 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses of $13.5 million of wage related and other charges due to the Greifswald facility closure of which $2.6 million is included in selling, general and administrative and $10.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:79]
(18) $1.0 million is included in selling, general and administrative expenses and less than $0.1 million is included in research and development expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE.

[0000950170-24-091207:8k_2_02:80]
(19) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $8.0 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:81]
(20) $5.1 million is included in selling, general and administrative expenses and $2.3 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:82]
(21) $3.5 million is included in selling, general and administrative expenses and $4.7 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-24-091207:8k_2_02:83]
(22) $1.4 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at Adtran Networks SE and the implementation of the DPLTA.

[0000950170-24-091207:8k_2_02:84]
Supplemental Information

[0000950170-24-091207:8k_2_02:85]
Reconciliation of Operating Loss to Non-GAAP Operating Income (Loss)

[0000950170-24-091207:8k_2_02:86]
(Unaudited)

[0000950170-24-091207:8k_2_02:87]
(In thousands)

[0000950170-24-091207:8k_2_02:88]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | March 31, |  |  | June 30, |  |  |  | June 30 |  |  | June 30 |  |  |
|  |  | 2024 |  |  | 2024 |  |  | 2023 |  |  |  | 2024 |  |  | 2023 |  |  |
| Operating Loss |  | $ | (38,306 | ) |  | $ | (339,679 | ) |  | $ | (44,628 | ) |  |  | $ | (377,985 | ) |  | $ | (94,360 | ) |  |
| Acquisition related expenses, amortizations and adjustments(1) |  |  | 17,297 |  |  |  | 15,058 |  |  |  | 37,837 |  |  |  |  | 32,355 |  |  |  | 74,999 |  |  |
| Stock-based compensation expense |  |  | 3,601 |  |  |  | 3,722 |  |  |  | 4,309 |  |  |  |  | 7,323 |  |  |  | 8,007 |  |  |
| Restructuring expenses(2) |  |  | 17,530 |  |  |  | 17,110 |  |  |  | 5,868 |  |  |  |  | 34,640 |  |  |  | 8,305 |  |  |
| Integration expenses(3) |  |  | 566 |  |  |  | 514 |  |  |  | 563 |  |  |  |  | 1,080 |  |  |  | 1,412 |  |  |
| Deferred compensation adjustments(4) |  |  | 848 |  |  |  | 1,940 |  |  |  | (307 | ) |  |  |  | 2,788 |  |  |  | 87 |  |  |
| Goodwill impairment(5) |  |  | — |  |  |  | 292,583 |  |  |  | — |  |  |  |  | 292,583 |  |  |  | — |  |  |
| Non-GAAP Operating Income (Loss) |  | $ | 1,536 |  |  | $ | (8,752 | ) |  | $ | 3,642 |  |  |  | $ | (7,216 | ) |  | $ | (1,550 | ) |  |

[0000950170-24-091207:8k_2_02:89]
(1)  Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations.

[0000950170-24-091207:8k_2_02:90]
(2) Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. These expenses include inventory write down and other charges incurred as a result of a strategic shift in certain product lines in connection with the restructuring program. Additionally, includes expenses related to the closure of the Greifswald facility.

[0000950170-24-091207:8k_2_02:91]
(3)  Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks SE. Includes fees incurred for the expansion of internal controls at Adtran Networks SE and the implementation of the DPTLA.

[0000950170-24-091207:8k_2_02:92]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-24-091207:8k_2_02:93]
(5) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer inventory adjustments.

[0000950170-24-091207:8k_2_02:94]
Supplemental Information

[0000950170-24-091207:8k_2_02:95]
Reconciliation of Other (Expense) Income to Non-GAAP Other Expense

[0000950170-24-091207:8k_2_02:96]
(Unaudited)

[0000950170-24-091207:8k_2_02:97]
(In thousands)

[0000950170-24-091207:8k_2_02:98]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |
|  |  | June 30, 2024 |  |  | March 31, 2024 |  |  | June 30, 2023 |  |  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| Interest and dividend income |  | $ | 366 |  |  | $ | 397 |  |  | $ | 358 |  |  |  | $ | 763 |  |  | $ | 662 |  |
| Interest expense |  |  | (6,906 | ) |  |  | (4,598 | ) |  |  | (4,064 | ) |  |  |  | (11,504 | ) |  |  | (7,351 | ) |
| Net investment gain |  |  | 872 |  |  |  | 2,253 |  |  |  | 1,262 |  |  |  |  | 3,125 |  |  |  | 2,514 |  |
| Other (expense) income, net |  |  | (901 | ) |  |  | 1,310 |  |  |  | 2,494 |  |  |  |  | 409 |  |  |  | 2,191 |  |
| Total Other (Expense) Income |  | $ | (6,569 | ) |  | $ | (638 | ) |  | $ | 50 |  |  |  | $ | (7,207 | ) |  | $ | (1,984 | ) |
| Deferred compensation adjustments (1) |  |  | (896 | ) |  |  | (2,439 | ) |  |  | (1,254 | ) |  |  |  | (3,335 | ) |  |  | (2,504 | ) |
| Pension expense (2) |  |  | 7 |  |  |  | 7 |  |  |  | 6 |  |  |  |  | 14 |  |  |  | 13 |  |
| Non-GAAP Other Expense |  | $ | (7,458 | ) |  | $ | (3,070 | ) |  | $ | (1,198 | ) |  |  | $ | (10,528 | ) |  | $ | (4,475 | ) |

[0000950170-24-091207:8k_2_02:99]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0000950170-24-091207:8k_2_02:100]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-24-091207:8k_2_02:101]
Supplemental Information

[0000950170-24-091207:8k_2_02:102]
Reconciliation of Net Loss inclusive of Non-Controlling Interest to

[0000950170-24-091207:8k_2_02:103]
Non-GAAP Net (Loss) Income inclusive of Non-Controlling Interest

[0000950170-24-091207:8k_2_02:104]
(Unaudited)

[0000950170-24-091207:8k_2_02:105]
and

[0000950170-24-091207:8k_2_02:106]
Reconciliation of Net Income attributable to Non-Controlling Interest to

[0000950170-24-091207:8k_2_02:107]
Non-GAAP Net Income attributable to Non-Controlling Interest

[0000950170-24-091207:8k_2_02:108]
(Unaudited)

[0000950170-24-091207:8k_2_02:109]
and

[0000950170-24-091207:8k_2_02:110]
Reconciliation of Net Loss attributable to ADTRAN Holdings, Inc. and

[0000950170-24-091207:8k_2_02:111]
Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0000950170-24-091207:8k_2_02:112]
Non-GAAP Net Loss attributable to ADTRAN Holdings, Inc. and

[0000950170-24-091207:8k_2_02:113]
Non-GAAP Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0000950170-24-091207:8k_2_02:114]
(Unaudited)

[0000950170-24-091207:8k_2_02:115]
(In thousands, except per share amounts)

[0000950170-24-091207:8k_2_02:116]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |
|  |  | June 30,2024 |  |  | March 31,2024 |  |  | June 30,2023 |  |  |  | June 30,2024 |  |  | June 30,2023 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (49,865 | ) |  | $ | (324,550 | ) |  | $ | (39,097 | ) |  |  | $ | (374,415 | ) |  | $ | (79,180 | ) |
| Plus: Net Income attributable to non-controlling interest (1) |  |  | 2,854 |  |  |  | 2,880 |  |  |  | 2,882 |  |  |  |  | 5,734 |  |  |  | 2,512 |  |
| Net Loss inclusive of non-controlling interest |  | $ | (47,011 | ) |  | $ | (321,670 | ) |  | $ | (36,215 | ) |  |  | $ | (368,681 | ) |  | $ | (76,668 | ) |
| Acquisition related expenses, amortizations and adjustments |  |  | 17,297 |  |  |  | 15,058 |  |  |  | 37,837 |  |  |  |  | 32,355 |  |  |  | 74,999 |  |
| Stock-based compensation expense |  |  | 3,601 |  |  |  | 3,722 |  |  |  | 4,309 |  |  |  |  | 7,323 |  |  |  | 8,007 |  |
| Deferred compensation adjustments (2) |  |  | (48 | ) |  |  | (499 | ) |  |  | (1,561 | ) |  |  |  | (547 | ) |  |  | (2,417 | ) |
| Pension adjustments (3) |  |  | 7 |  |  |  | 7 |  |  |  | 6 |  |  |  |  | 14 |  |  |  | 13 |  |
| Restructuring expenses |  |  | 17,530 |  |  |  | 17,110 |  |  |  | 5,868 |  |  |  |  | 34,640 |  |  |  | 8,305 |  |
| Integration expenses |  |  | 566 |  |  |  | 514 |  |  |  | 563 |  |  |  |  | 1,080 |  |  |  | 1,412 |  |
| Goodwill impairment |  |  | — |  |  |  | 292,583 |  |  |  | — |  |  |  |  | 292,583 |  |  |  | — |  |
| Tax effect of adjustments to net loss |  |  | (7,880 | ) |  |  | (5,614 | ) |  |  | (13,426 | ) |  |  |  | (13,494 | ) |  |  | (25,733 | ) |
| Non-GAAP Net (Loss) Income inclusive of non-controlling interest |  | $ | (15,938 | ) |  | $ | 1,211 |  |  | $ | (2,619 | ) |  |  | $ | (14,727 | ) |  | $ | (12,082 | ) |
| Less: Non-GAAP Net Income attributable to non-controlling interest (1) |  |  | 2,854 |  |  |  | 2,880 |  |  |  | 2,882 |  |  |  |  | 5,734 |  |  |  | 4,041 |  |
| Non-GAAP Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (18,792 | ) |  | $ | (1,669 | ) |  | $ | (5,501 | ) |  |  | $ | (20,461 | ) |  | $ | (16,123 | ) |
| GAAP Net Income attributable to non-controlling interest (1) |  | $ | 2,854 |  |  | $ | 2,880 |  |  | $ | 2,882 |  |  |  | $ | 5,734 |  |  | $ | 2,512 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 1,457 |  |
| Restructuring expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 29 |  |
| Integration expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 6 |  |
| Stock-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 37 |  |
| Non-GAAP Net Income attributable to non-controlling interest (1) |  | $ | 2,854 |  |  | $ | 2,880 |  |  | $ | 2,882 |  |  |  | $ | 5,734 |  |  | $ | 4,041 |  |
| Weighted average shares outstanding – basic |  |  | 78,852 |  |  |  | 78,814 |  |  |  | 78,366 |  |  |  |  | 78,803 |  |  |  | 78,364 |  |
| Weighted average shares outstanding – diluted |  |  | 78,852 |  |  |  | 78,814 |  |  |  | 78,366 |  |  |  |  | 78,803 |  |  |  | 78,364 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.63 | ) |  | $ | (4.12 | ) |  | $ | (0.50 | ) |  |  | $ | (4.75 | ) |  | $ | (1.01 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.63 | ) |  | $ | (4.12 | ) |  | $ | (0.50 | ) |  |  | $ | (4.75 | ) |  | $ | (1.01 | ) |
| Non-GAAP Loss per common share attributable to ADTRAN – basic |  | $ | (0.24 | ) |  | $ | (0.02 | ) |  | $ | (0.07 | ) |  |  | $ | (0.26 | ) |  | $ | (0.21 | ) |
| Non-GAAP Loss per common share attributable to ADTRAN – diluted |  | $ | (0.24 | ) |  | $ | (0.02 | ) |  | $ | (0.07 | ) |  |  | $ | (0.26 | ) |  | $ | (0.21 | ) |

[0000950170-24-091207:8k_2_02:117]
(1) Represents the non-controlling interest portion of the Company's ownership of Adtran Networks SE pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0000950170-24-091207:8k_2_02:118]
(2) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-24-091207:8k_2_02:119]
(3) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-24-091207:8k_2_02:120]
Supplemental Information

[0000950170-24-091207:8k_2_02:121]
Reconciliation of Net Cash Provided By (Used In) Operating Activities to Free Cash Flow

[0000950170-24-091207:8k_2_02:122]
(Unaudited)

[0000950170-24-091207:8k_2_02:123]
(In thousands)

[0000950170-24-091207:8k_2_02:124]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | March 31, |  |  | June 30, |  |  |  | June 30, |  |  | June 30, |  |
|  |  | 2024 |  |  | 2024 |  |  | 2023 |  |  |  | 2024 |  |  | 2023 |  |
| Net Cash provided by (used in) operating activities |  | $ | 19,898 |  |  | $ | 36,598 |  |  | $ | (16,234 | ) |  |  | $ | 56,496 |  |  | $ | (36,160 | ) |
| Purchases of property, plant and equipment |  |  | (15,995 | ) |  |  | (13,374 | ) |  |  | (11,679 | ) |  |  |  | (29,369 | ) |  |  | (20,118 | ) |
| Free cash flow |  | $ | 3,903 |  |  | $ | 23,224 |  |  | $ | (27,913 | ) |  |  | $ | 27,127 |  |  | $ | (56,278 | ) |
