# ADTN note change history — 0000950170-24-057628 → 0000950170-24-094602


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-08-09):
[0000950170-24-094602:note_history:1]
18. COMMITMENTS AND CONTINGENCIES 
Legal Matters
  (was, 2024-05-10, similarity 0.8158):
[0000950170-24-057628:note_history:1]
18. COMMITMENTS AND CONTINGENCIES

- changed (2024-08-09):
[0000950170-24-094602:note_history:2]
From time to time, the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. The Company records an accrual for any Legal Matters that arise whenever it considers that it is probable that it is exposed to a loss contingency and the amount of the loss contingency can be reasonably estimated. Although the ultimate disposition of asserted claims cannot be predicted with certainty, it is our belief that the outcome of any such claims, either individually or on a combined basis, will not have a material adverse effect on our consolidated financial position.
  (was, 2024-05-10, similarity 0.7174):
[0000950170-24-057628:note_history:2]
From time to time, the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

- changed (2024-08-09):
[0000950170-24-094602:note_history:3]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of June 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €345.6 million or approximately $371.3 million, based on an exchange rate as of June 30, 2024, and reflecting interest accrued through June 30, 2024, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).
  (was, 2024-05-10, similarity 0.992):
[0000950170-24-057628:note_history:3]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of March 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.9 million or approximately $365.7 million, based on an exchange rate as of March 31, 2024 and reflecting interest accrued through March 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- added (2024-08-09):
[0000950170-24-094602:note_history:4]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.4 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three and six months ended June 30, 2024, and 2023, we accrued $2.9 million and $5.7 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

- added (2024-08-09):
[0000950170-24-094602:note_history:5]
For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or approximately $20 thousand and $25 thousand, respectively, based on an exchange rate as of June 30, 2024, were paid to Adtran Networks shareholders. For the three and six months ended June 30, 2023, approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €0.8 thousand and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

- changed (2024-08-09):
[0000950170-24-094602:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2024, and December 31, 2023, we had commitments related to these bonds totaling $13.9 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2024-05-10, similarity 0.9913):
[0000950170-24-057628:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2024 and December 31, 2023, we had commitments related to these bonds totaling $10.6 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2024-08-09):
[0000950170-24-094602:note_history:7]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for short-term product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of June 30, 2024, purchase obligations totaled $280.9 million.
  (was, 2024-05-10, similarity 0.9911):
[0000950170-24-057628:note_history:7]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for short-term product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of March 31, 2024, purchase obligations totaled $238.0 million.

- removed (2024-08-09):
[0000950170-24-057628:note_history:8]
Legal Matters

- removed (2024-08-09):
[0000950170-24-057628:note_history:9]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.5 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2024 and 2023, we accrued $2.9 million and $2.8 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit. With respect to the year ended December 31, 2023, we are obligated to pay $11.5 million in Annual Recurring Compensation on the third banking day following the 2024 ordinary general shareholders’ meeting of Adtran Networks, which is expected to occur on June 28, 2024 (but in any event within eight months following December 31, 2023).

- removed (2024-08-09):
[0000950170-24-057628:note_history:10]
For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or

- removed (2024-08-09):
[0000950170-24-057628:note_history:11]
approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-08-09):
[0000950170-24-094602:note_history:12]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks SE (formerly ADVA Optical Networking SE). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer and in particular upon the convergence of solutions at the network edge.
  (was, 2024-05-10, similarity 0.9974):
[0000950170-24-057628:note_history:12]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer and in particular upon the convergence of solutions at the network edge.

- changed (2024-08-09):
[0000950170-24-094602:note_history:13]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of June 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €345.6 million or approximately $371.3 million, based on an exchange rate as of June 30, 2024, and reflecting interest accrued through June 30, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).
  (was, 2024-05-10, similarity 0.992):
[0000950170-24-057628:note_history:13]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.62% as of March 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.9 million or approximately $365.7 million, based on an exchange rate as of March 31, 2024 and reflecting interest accrued through March 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- added (2024-08-09):
[0000950170-24-094602:note_history:14]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.4 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three and six months ended June 30, 2024, and 2023, we accrued $2.9 million and $5.7 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

- added (2024-08-09):
[0000950170-24-094602:note_history:15]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or approximately $20 thousand and $25 thousand, respectively, based on an exchange rate as of June 30, 2024, were paid to Adtran Networks shareholders. For the three and six months ended June 30, 2023, approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €0.8 thousand and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

- changed (2024-08-09):
[0000950170-24-094602:note_history:16]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. Pursuant to the terms of the Credit Agreement, as amended, the Company, ADTRAN, Inc., and the subsidiary guarantors (together, the “Credit Parties”) are subject to a liquidity covenant, which provides that, during the fourth quarter of 2023 through and including the third quarter of 2024 (“Covenant Relief Period”) or a Springing Covenant Period (i.e., the period beginning upon the purchase by the Company of at least 60% of the outstanding shares of Adtran Networks not owned by the Company as of August 9, 2023 and the three consecutive quarterly test periods after such date), as of the last day of any fiscal quarter, the cash and cash equivalents of the Credit Parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million, limiting our ability to pay the obligations under the DPLTA. The Company had access to $206.0 million on its Credit Facility for future borrowings; however, as of June 30, 2024, the Company was limited to additional borrowings of $16.4 million based on debt covenant compliance metrics. See Note 11, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.
  (was, 2024-05-10, similarity 0.9916):
[0000950170-24-057628:note_history:16]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”), which has since been amended three times. Pursuant to the terms of the Credit Agreement, as amended, the Company, ADTRAN, Inc., and the subsidiary guarantors (together, the “Credit Parties”) are subject to a liquidity covenant, which provides that, during the fourth quarter of 2023 through and including the third quarter of 2024 (the “Covenant Relief Period”) or a Springing Covenant Period (i.e., the period beginning upon the purchase by the Company of at least 60% of the outstanding shares of Adtran Networks not owned by the Company as of August 9, 2023 and the three consecutive quarterly test periods after such date), as of the last day of any fiscal quarter, the cash and cash equivalents of the Credit Parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $75.0 million, limiting our ability to pay the obligations under the DPLTA. The Company had access to $203.0 million on its Credit Facility for future borrowings; however, as of March 31, 2024, the Company was limited to additional borrowings of $22.7 million based on debt covenant compliance metrics. See Note 11, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

- changed (2024-08-09):
[0000950170-24-094602:note_history:17]
As of June 30, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-32 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks shares.
  (was, 2024-05-10, similarity 0.7854):
[0000950170-24-057628:note_history:17]
As of March 31, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-32 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks shares.

- changed (2024-08-09):
[0000950170-24-094602:note_history:18]
The Company experienced revenue declines in the year ended December 31, 2023, and during the three and six months ended June 30, 2024. To the extent that the Company is further impacted by customers' inventory reduction initiatives, the Company is implementing plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a business efficiency program, which includes, but is not limited to ongoing reductions in
  (was, 2024-05-10, similarity 0.6871):
[0000950170-24-057628:note_history:18]
The Company experienced revenue declines in the year ended December 31, 2023 and during the three months ended March 31, 2024. To the extent that the Company is further impacted by the uncertain macroeconomic environment related to continued elevated interest rates and ongoing inflationary pressures, the Company has established plans to preserve cash liquidity and maintain compliance with the Company’s covenants. The Company has suspended dividend payments and is continuing to implement a business efficiency program, which includes, but is not limited to planned reductions in operating expenses and a site consolidation plan. In connection with

- added (2024-08-09):
[0000950170-24-094602:note_history:19]
operating expenses and a site consolidation plan. In connection with the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditure and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

- added (2024-08-09):
[0000950170-24-094602:note_history:20]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and to support our ability to continue to comply with our debt covenants under the Credit Facility, for at least the next twelve months, from the issuance of these financial statements. See Note 11, Revolving Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo Credit agreement.

- changed (2024-08-09):
[0000950170-24-094602:note_history:21]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions as of June 30, 2024, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.
  (was, 2024-05-10, similarity 0.6326):
[0000950170-24-057628:note_history:21]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, the energy crisis, currency fluctuations and political tensions as of March 31, 2024, and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to ongoing inflationary pressures, the energy crisis, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.

- changed (2024-08-09):
[0000950170-24-094602:note_history:22]
On December 19, 2023, the Company entered into a new factoring agreement with a third-party financial institution to replace the Company’s prior accounts receivable purchase agreement, to sell on a revolving basis, undivided interests in the Company’s accounts receivable. The new factoring agreement qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company is considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retains a residual claim on reserves related to the factored receivables. Within the Condensed Consolidated Balance Sheets, the receivables factored continue to be carried in accounts receivable, less allowance for credit losses, and the secured borrowings are carried as a current liability within accounts payable. The proceeds and repayments of secured borrowings are reflected as cash flows (used in) provided by financing activities within the Condensed Consolidated Statements of Cash Flows, and program fees are recorded as interest expense in the Consolidated Statements of Loss. The short-term liability classification of the secured borrowings is based on the estimated timing of the collection of the accounts receivable which are expected to be received within 12 months. See Note 2 for additional information.
  (was, 2024-05-10, similarity 0.7185):
[0000950170-24-057628:note_history:22]
On December 19, 2023, the Company entered into a new factoring agreement with a third-party financial institution to replace the Company’s prior accounts receivable purchase agreement, to sell on a revolving basis, undivided interests in the Company’s accounts receivable. The new factoring agreement qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company is considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retains a residual claim on reserves related to the factored receivables. Within the Condensed Consolidated Balance Sheets, the receivables factored continue to be carried in accounts receivable, less allowance for credit losses, and the secured borrowings are carried as a current liability within accounts payable. The proceeds and repayments of secured borrowings are reflected as cash flows provided by (used in) financing activities within the Condensed Consolidated Statements of Cash Flows, and program fees are recorded as interest expense in the Consolidated Statements of Loss. The short-term liability classification of the secured borrowings is based on the estimated timing of the collection of the accounts receivable which are expected to be received within 12 months. See Note 2 for additional information.

- changed (2024-08-09):
[0000950170-24-094602:note_history:23]
The Company had previously entered into a factoring agreement to sell certain receivables to an unrelated third-party financial institution on a non-recourse basis. These transactions were accounted for in accordance with ASC Topic 860 and resulted in a reduction in accounts receivable because the agreement transferred effective control over, and risk related to the receivables to the buyers. Trade accounts receivables balances sold were removed from the Condensed Consolidated Balance Sheets and cash received was reflected as cash flows provided by (used in) operating activities in the Condensed Consolidated Statements of Cash Flow. Factoring related interest expense was recorded to interest expense on the Condensed Consolidated Statements of Loss. On each sale date, the financial institution retained from the sale price a default reserve, up to a required balance, which was held by the financial institution in a reserve account and pledged to the Company. The financial institution was entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account was included in other assets on the Condensed Consolidated Balance Sheets.
  (was, 2024-05-10, similarity 0.9996):
[0000950170-24-057628:note_history:23]
The Company had previously entered into a factoring agreement to sell certain receivables to an unrelated third-party financial institution on a non-recourse basis. These transactions were accounted for in accordance with ASC Topic 860 and resulted in a reduction in accounts receivable because the agreement transferred effective control over and risk related to the receivables to the buyers. Trade accounts receivables balances sold were removed from the Condensed Consolidated Balance Sheets and cash received was reflected as cash flows provided by (used in) operating activities in the Condensed Consolidated Statements of Cash Flow. Factoring related interest expense was recorded to interest expense on the Condensed Consolidated Statements of Loss. On each sale date, the financial institution retained from the sale price a default reserve, up to a required balance, which was held by the financial institution in a reserve account and pledged to the Company. The financial institution was entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account was included in other assets on the Condensed Consolidated Balance Sheets.

- changed (2024-08-09):
[0000950170-24-094602:note_history:24]
As of June 30, 2024 and December 31, 2023, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.6% for each period.
  (was, 2024-05-10, similarity 0.973):
[0000950170-24-057628:note_history:24]
As of March 31, 2024 and December 31, 2023, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.7% for each period.

- changed (2024-08-09):
[0000950170-24-094602:note_history:25]
In November 2023, the FASB issued ASU 2023-7, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures", which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses, allowing financial statement users to better understand the components of a segment's profit or loss to assess potential future cash flows for each reportable segment and the entity as a whole. The amendments expand a public entity's segment disclosures by requiring disclosure of significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), clarifying when an entity may report one or more additional measures to assess segment performance, requiring enhanced interim disclosures, providing new disclosure requirements for entities with a single reportable segment, and requiring other new disclosures. The amendments are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, and early adoption is permitted. The Company expects to adopt the new disclosures as required for the year ended December 31, 2024. The Company is currently evaluating the impact on the related disclosures.
  (was, 2024-05-10, similarity 0.9996):
[0000950170-24-057628:note_history:25]
In November 2023, the FASB issued ASU 2023-7, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures", which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses, allowing financial statement users to better understand the components of a segment's profit or loss to assess potential future cash flows for each reportable segment and the entity as a whole. The amendments expand a public entity's segment disclosures by requiring disclosure of significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), clarifying when an entity may report one or more additional measures to assess segment performance, requiring enhanced interim disclosures, providing new disclosure requirements for entities with a single reportable segment, and requiring other new disclosures. The amendments are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, and early adoption is permitted. The Company expect to adopt the new disclosures as required for the year ended December 31, 2024. The Company is currently evaluating the impact on the related disclosures.

- removed (2024-08-09):
[0000950170-24-057628:note_history:26]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.5 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2024 and 2023, we accrued $2.9 million and $2.8 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit. With respect to the year ended December 31, 2023, we are obligated to pay $11.5 million in Annual Recurring Compensation on the third banking day following the 2024 ordinary general shareholders’ meeting of Adtran Networks, which is expected to occur on June 28, 2024 (but in any event within eight months following December 31, 2023).

- removed (2024-08-09):
[0000950170-24-057628:note_history:27]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three months ended March 31, 2024 and 2023, less than one thousand and 62 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €4 thousand and €1.1 million, respectively, or approximately $5 thousand and $1.2 million based on an exchange rate as of March 31, 2024 and 2023, respectively, were paid to Adtran Networks shareholders.

- removed (2024-08-09):
[0000950170-24-057628:note_history:28]
the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

- removed (2024-08-09):
[0000950170-24-057628:note_history:29]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility, including (i) the additional funding provided for under the First Amendment to the Wells Fargo Credit Facility that was signed on August 9, 2023, (ii) the additional covenant headroom during the Covenant Relief Period provided for under the Second Amendment to Wells Fargo Credit Facility, and (iii) the exclusion of the Factoring Agreement as debt for purposes of the Credit Facility’s financial covenants as provided for under the Third Amendment to the Wells Fargo Credit Facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and ability to continue to comply with our debt covenants under the Credit Facility, for at least the next twelve months, from the issuance of these financial statements. See Note 11, Revolving Credit Agreements, for additional information regarding the terms of the First, Second and Third Amendments of the Wells Fargo Credit agreement.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-09):
[0000950170-24-094602:note_history:30]
11. CREDIT AGREEMENTS
  (was, 2024-05-10, similarity 0.7917):
[0000950170-24-057628:note_history:30]
11. REVOLVING CREDIT AGREEMENTS

- changed (2024-08-09):
[0000950170-24-094602:note_history:31]
The carrying amounts of the Company's non-current revolving credit facility in its Condensed Consolidated Balance Sheets were as follows:
  (was, 2024-05-10, similarity 0.9493):
[0000950170-24-057628:note_history:31]
The carrying amounts of the Company's non-current revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:

- added (2024-08-09):
[0000950170-24-094602:note_history:32]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Wells Fargo credit agreement |  | $ | 190,273 |  |  | $ | 195,000 |  |
| Total non-current revolving credit facility |  | $ | 190,273 |  |  | $ | 195,000 |  |

- changed (2024-08-09):
[0000950170-24-094602:note_history:33]
As of June 30, 2024, the weighted average interest rate on our revolving credit agreements was 8.51%.
  (was, 2024-05-10, similarity 0.9514):
[0000950170-24-057628:note_history:33]
As of March 31, 2024, the weighted average interest rate on our revolving credit agreements was 8.46%.

- changed (2024-08-09):
[0000950170-24-094602:note_history:34]
On July 18, 2022, ADTRAN, Inc., as the borrower ("US Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (as amended from time to time, the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount ($100.0 million of which is available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below), as well as the $50.0 million delayed draw term loan facility described below. The term of the delayed draw term loan facility expires on August 9, 2024.
  (was, 2024-05-10, similarity 0.6763):
[0000950170-24-057628:note_history:34]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount, as well as the $50.0 million delayed draw term loan facility described below.

- added (2024-08-09):
[0000950170-24-094602:note_history:35]
On August 9, 2023, ("First Amendment Effective Date") the Company and ADTRAN, Inc. entered into a First Amendment to Credit Agreement (“First Amendment”).

- changed (2024-08-09):
[0000950170-24-094602:note_history:36]
The First Amendment among other things, provided for a new $50.0 million delayed draw term loan facility (“DDTL”), which (subject to certain conditions) is available for borrowing in the event that at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date have been tendered (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase shares of Adtran Networks. The DDTL is available for borrowing from the occurrence of a Springing Covenant Event through August 9, 2024.
  (was, 2024-05-10, similarity 0.7438):
[0000950170-24-057628:note_history:36]
The First Amendment, provided for, among other things, a new $50.0 million delayed draw term loan (“DDTL”), which (subject to certain conditions) is available for borrowing in the event of the purchase by the Company of at least sixty percent (60.0%) of the outstanding shares of Adtran Networks SE that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks SE. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through August 9, 2024.

- changed (2024-08-09):
[0000950170-24-094602:note_history:37]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.
  (was, 2024-05-10, similarity 0.9936):
[0000950170-24-057628:note_history:37]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

- added (2024-08-09):
[0000950170-24-094602:note_history:38]
On January 16, 2024 ("Second Amendment Effective Date"), the Company and ADTRAN, Inc. entered into a Second Amendment to Credit Agreement and First Amendment to Collateral Agreement ("Second Amendment"). The Second Amendment, among other things, provided the Company and its subsidiaries with additional covenant headroom for the fourth quarter of 2023 through and including the third quarter of 2024 ("Covenant Relief Period") and revised and/or added certain other financial covenants which (as later modified by the Fourth Amendment) are described below.

- changed (2024-08-09):
[0000950170-24-094602:note_history:39]
On March 12, 2024, the Company and ADTRAN, Inc. entered into a Third Amendment to Credit Agreement ("Third Amendment"). The Third Amendment, among other things, amended the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024, and June 30, 2024.
  (was, 2024-05-10, similarity 0.7715):
[0000950170-24-057628:note_history:39]
On March 12, 2024, the Company entered into a Third Amendment to the Credit Agreement. The Third Amendment, among other things, amends the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024 and June 30, 2024.

- added (2024-08-09):
[0000950170-24-094602:note_history:40]
On June 4, 2024, the Company, ADTRAN, Inc., and Adtran Networks entered into a Fourth Amendment to Credit Agreement ("Fourth Amendment"). The Fourth Amendment, among other things, created a new sublimit under the existing $400.0 million revolving commitments, in an aggregate amount of $100.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold is initially $75 million and may be lowered from time to time pursuant to the terms of the Fourth Amendment. The existing swing line sublimit and letter of credit sublimit under the Credit Agreement remained available to the US Borrower (and not to Adtran Networks) after giving effect to the Fourth Amendment. Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

- added (2024-08-09):
[0000950170-24-094602:note_history:41]
As of June 30, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $190.3 million, of which $115.0 million were borrowed by ADTRAN, Inc. and $75.3 million were borrowed under the Subline by Adtran Networks. As of June 30, 2024, there were no borrowings under the DDTL. The credit facilities provided under the Credit Agreement mature in July 2027, but the US Borrower has an option to request extensions subject to customary conditions. In addition, the US Borrower may utilize up to $50.0 million of the $400.0 million total revolving facility for the issuance of letters of credit. As of June 30, 2024, we had a total of $3.7 million in letters of credit under ADTRAN, Inc. outstanding under the Credit Agreement, leaving a net amount (after giving effect to the $190.3 million of outstanding borrowings described above) of $206.0 million available for future borrowings; however, as of June 30, 2024, the Company was limited to additional borrowings of $16.4 million based on debt covenant compliance metrics. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of June 30, 2024, the Company was in compliance with all covenants.

- changed (2024-08-09):
[0000950170-24-094602:note_history:42]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin), at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period (as defined below), an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.15% per annum).
  (was, 2024-05-10, similarity 0.7771):
[0000950170-24-057628:note_history:42]
All U.S. dollar borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.90% to 1.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.40% per annum), or (B) Adjusted Term SOFR plus an applicable margin ranging from 1.90% to 2.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.40% per annum).

- changed (2024-08-09):
[0000950170-24-094602:note_history:43]
All Euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.25% per annum).
  (was, 2024-05-10, similarity 0.9463):
[0000950170-24-057628:note_history:43]
All Euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.25% per annum).

- changed (2024-08-09):
[0000950170-24-094602:note_history:44]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.
  (was, 2024-05-10, similarity 0.9762):
[0000950170-24-057628:note_history:44]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

- added (2024-08-09):
[0000950170-24-094602:note_history:45]
The “Applicable Margin Interest Period” means the period commencing on the Second Amendment Effective Date and ending on the first date when each of the following conditions have been met: (a) the Covenant Relief Period has ended, (b) since the Second Amendment Effective Date, the borrowers have repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the borrowers have reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million, and (d) the borrowers are in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

- changed (2024-08-09):
[0000950170-24-094602:note_history:46]
All U.S. dollar borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to either (a) the Base Rate plus an applicable margin ranging from 0.90% to 1.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 2.40% per annum), or (b) Adjusted Term SOFR plus an applicable margin ranging from 1.90% to 2.90% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.40% per annum).
  (was, 2024-05-10, similarity 0.8127):
[0000950170-24-057628:note_history:46]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin) bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.15% per annum).

- changed (2024-08-09):
[0000950170-24-094602:note_history:47]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable):
  (was, 2024-05-10, similarity 0.998):
[0000950170-24-057628:note_history:47]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable)::

- changed (2024-08-09):
[0000950170-24-094602:note_history:48]
•
In the fiscal quarter in which a Springing Covenant Event occurs and the three consecutive quarterly test periods thereafter, (“Springing Covenant Period”), the following covenant levels:
  (was, 2024-05-10, similarity 0.6081):
[0000950170-24-057628:note_history:48]
•
In the event of the purchase by the Company of at least sixty percent (60%) of the outstanding shares of Adtran Networks SE not owned by the Company as of August 9, 2023 that have been tendered (such event, a “Springing Covenant Event” and the fiscal quarter in which the Springing Covenant Event Occurs and the three consecutive quarterly test periods thereafter, the “Springing Covenant Period”), the following covenant levels:

- added (2024-08-09):
[0000950170-24-094602:note_history:49]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

- changed (2024-08-09):
[0000950170-24-094602:note_history:50]
•
If a Springing Covenant Period is not in effect, the Consolidated Senior Secured Net Leverage Ratio may not exceed:
  (was, 2024-05-10, similarity 0.6768):
[0000950170-24-057628:note_history:50]
•
If a Springing Covenant Period is not in effect, the following covenant levels:

- changed (2024-08-09):
[0000950170-24-094602:note_history:51]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not be less than 1.25x.
  (was, 2024-05-10, similarity 0.9573):
[0000950170-24-057628:note_history:51]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not exceed 1.25x.

- added (2024-08-09):
[0000950170-24-094602:note_history:52]
All obligations under the Credit Agreement (including under the Subline) are guaranteed by ADTRAN, Inc., the Company and certain subsidiaries of ADTRAN, Inc. (“Full Facility Guarantors”). To secure such guarantees, ADTRAN, Inc. and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and ADTRAN, Inc. has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries ("Subline Guarantors") have provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Adtran Networks has also granted security interests in favor of the Administrative Agent over substantially all of its tangible and intangible assets, to secure solely its obligations under the Subline. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

- removed (2024-08-09):
[0000950170-24-057628:note_history:53]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Wells Fargo credit agreement |  | $ | 195,000 |  |  | $ | 195,000 |  |
| Total non-current revolving credit agreement |  | $ | 195,000 |  |  | $ | 195,000 |  |

- removed (2024-08-09):
[0000950170-24-057628:note_history:54]
On August 9, 2023, (the "First Amendment Effective Date") the Company, its wholly-owned direct subsidiary, ADTRAN, Inc. and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and together with the Credit Agreement, the "Credit Facility").

- removed (2024-08-09):
[0000950170-24-057628:note_history:55]
On January 16, 2024, the Company entered into a Second Amendment to the Credit Agreement and First Amendment to the Collateral Agreement. The Second Amendment, among other things, provides the Company and its subsidiaries with additional covenant headroom for the fourth quarter of 2023 through the third quarter of 2024 (the "Covenant Relief Period") and adds certain other financial covenants which are described below.

- removed (2024-08-09):
[0000950170-24-057628:note_history:56]
As of March 31, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $195.0 million. As of March 31, 2024, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. In addition, we may issue up to $50.0 million in letters of credit against our $400.0 million total facility. As of March 31, 2024, we had a total of $2.0 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $203.0 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of March 31, 2024, the Company was in compliance with all covenants.

- removed (2024-08-09):
[0000950170-24-057628:note_history:57]
The increases in the commitment fee and margin rates during the Covenant Relief Period (referenced above) continue until the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the “Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, the Company has repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the Company has reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) the Company is in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

- removed (2024-08-09):
[0000950170-24-057628:note_history:58]
The increases in the commitment fee and margin rates during the Covenant Relief Period (referenced above) continue until the first date when each of the following conditions have been met (the period during which such increases are in place is hereinafter referred to as the “Applicable Margin Interest Period”): (a) the Covenant Relief Period has ended, (b) since the Second Amendment effective date, the Company has repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the Company has reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million and (d) the Company is in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

- removed (2024-08-09):
[0000950170-24-057628:note_history:59]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50,000,000 in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

- removed (2024-08-09):
[0000950170-24-057628:note_history:60]
The Credit Agreement is guaranteed by certain domestic subsidiaries of the Company, and the Company is also required to add certain additional domestic and international subsidiaries as guarantors under the Credit Agreement (such existing and new guarantors, collectively, the “Guarantors”). In addition to the guarantees provided by the Guarantors, the Guarantors have granted (or will grant) security interests in favor of the Administrative Agent over substantially all tangible and intangible assets, and the Borrower will grant mortgages in favor of the Administrative Agent over certain owned real estate assets. The Company is currently in negotiations with the Administrative Agent regarding a potential further amendment to the Credit Agreement to address the addition of certain foreign subsidiary guarantors.

- removed (2024-08-09):
[0000950170-24-057628:note_history:61]
The Credit Agreement provides for revolving borrowings of up to $400.0 million in aggregate principal amount, as well as an additional $50.0 million delayed draw term loan tranche that would be available upon a Springing Covenant Event. It also continues to permit the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement subject to certain limitations and minimum payment thresholds.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-09):
[0000950170-24-094602:note_history:62]
The Company did not have any debt securities and other investments as of June 30, 2024.
  (was, 2024-05-10, similarity 0.9448):
[0000950170-24-057628:note_history:62]
The Company did not have any debt securities and other investments as of March 31, 2024.

- added (2024-08-09):
[0000950170-24-094602:note_history:63]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4 |  |
| Gross realized loss on debt securities |  |  | — |  |  |  | (27 | ) |  |  | — |  |  |  | (39 | ) |
| Total loss recognized, net |  | $ | — |  |  | $ | (27 | ) |  | $ | — |  |  | $ | (35 | ) |

- changed (2024-08-09):
[0000950170-24-094602:note_history:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Unrealized gain on equity securities held |  | $ | 4 |  |  | $ | 1,288 |  |  | $ | 127 |  |  | $ | 2,535 |  |
| Realized gain on equity securities sold |  |  | 868 |  |  |  | 1 |  |  |  | 2,998 |  |  |  | 14 |  |
| Total gain recognized, net |  | $ | 872 |  |  | $ | 1,289 |  |  | $ | 3,125 |  |  | $ | 2,549 |  |
  (was, 2024-05-10, similarity 0.6798):
[0000950170-24-057628:note_history:64]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Realized gain on equity securities sold |  | $ | 123 |  |  | $ | 13 |  |
| Unrealized gain on equity securities held |  |  | 2,130 |  |  |  | 1,246 |  |
| Total gain recognized, net |  | $ | 2,253 |  |  | $ | 1,259 |  |

- changed (2024-08-09):
[0000950170-24-094602:note_history:65]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly and
  (was, 2024-05-10, similarity 0.9861):
[0000950170-24-057628:note_history:65]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

- changed (2024-08-09):
[0000950170-24-094602:note_history:66]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,433 |  |  | $ | 5,433 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 955 |  |  |  | 955 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 29,204 |  |  |  | 29,204 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,592 |  |  | $ | 35,592 |  |  | $ | — |  |  | $ | — |  |
  (was, 2024-05-10, similarity 0.9932):
[0000950170-24-057628:note_history:66]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,375 |  |  | $ | 5,375 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 987 |  |  |  | 987 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 28,265 |  |  |  | 28,265 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 34,627 |  |  | $ | 34,627 |  |  | $ | — |  |  | $ | — |  |

- removed (2024-08-09):
[0000950170-24-057628:note_history:67]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | 4 |  |
| Gross realized loss on debt securities |  |  | — |  |  |  | (11 | ) |
| Total loss recognized, net |  | $ | — |  |  | $ | (7 | ) |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-09):
[0000950170-24-094602:note_history:68]
The following tables disaggregate revenue by reportable segment and revenue category:
  (was, 2024-05-10, similarity 0.9882):
[0000950170-24-057628:note_history:68]
The following table disaggregates revenue by reportable segment and revenue category:

- changed (2024-08-09):
[0000950170-24-094602:note_history:69]
|  |  | Three Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 51,467 |  |  | $ | 22,220 |  |  | $ | 73,687 |  |  | $ | 120,221 |  |  | $ | 22,775 |  |  | $ | 142,996 |  |
| Access & Aggregation Solutions |  |  | 54,112 |  |  |  | 15,795 |  |  |  | 69,907 |  |  |  | 89,263 |  |  |  | 13,454 |  |  |  | 102,717 |  |
| Subscriber Solutions |  |  | 73,615 |  |  |  | 8,782 |  |  |  | 82,397 |  |  |  | 73,518 |  |  |  | 8,147 |  |  |  | 81,665 |  |
| Total |  | $ | 179,194 |  |  | $ | 46,797 |  |  | $ | 225,991 |  |  | $ | 283,002 |  |  | $ | 44,376 |  |  | $ | 327,378 |  |
  (was, 2024-05-10, similarity 0.6462):
[0000950170-24-057628:note_history:69]
|  |  | Three Months Ended |  |
|  |  | March 31, 2024 |  |  | March 31, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 60,369 |  |  | $ | 9,399 |  |  | $ | 69,767 |  |  | $ | 70,287 |  |  | $ | 9,049 |  |  | $ | 79,336 |  |
| Access & Aggregation Solutions |  |  | 67,777 |  |  |  | 13,535 |  |  |  | 81,312 |  |  |  | 84,554 |  |  |  | 12,266 |  |  |  | 96,820 |  |
| Optical Networking Solutions |  |  | 53,127 |  |  |  | 21,966 |  |  |  | 75,094 |  |  |  | 127,577 |  |  |  | 20,179 |  |  |  | 147,756 |  |
| Total |  | $ | 181,273 |  |  | $ | 44,900 |  |  | $ | 226,173 |  |  | $ | 282,418 |  |  | $ | 41,494 |  |  | $ | 323,912 |  |

- added (2024-08-09):
[0000950170-24-094602:note_history:70]
|  |  | Six Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 104,594 |  |  | $ | 44,186 |  |  | $ | 148,780 |  |  | $ | 247,798 |  |  | $ | 42,954 |  |  | $ | 290,752 |  |
| Access & Aggregation Solutions |  |  | 121,889 |  |  |  | 29,330 |  |  |  | 151,219 |  |  |  | 173,817 |  |  |  | 25,720 |  |  |  | 199,537 |  |
| Subscriber Solutions |  |  | 133,984 |  |  |  | 18,181 |  |  |  | 152,165 |  |  |  | 143,805 |  |  |  | 17,196 |  |  |  | 161,001 |  |
| Total |  | $ | 360,467 |  |  | $ | 91,697 |  |  | $ | 452,164 |  |  | $ | 565,420 |  |  | $ | 85,870 |  |  | $ | 651,290 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-09):
[0000950170-24-094602:note_history:71]
The following tables disaggregate revenue by reportable segment and revenue category:
  (was, 2024-05-10, similarity 0.9882):
[0000950170-24-057628:note_history:71]
The following table disaggregates revenue by reportable segment and revenue category:

- changed (2024-08-09):
[0000950170-24-094602:note_history:72]
|  |  | Three Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 51,467 |  |  | $ | 22,220 |  |  | $ | 73,687 |  |  | $ | 120,221 |  |  | $ | 22,775 |  |  | $ | 142,996 |  |
| Access & Aggregation Solutions |  |  | 54,112 |  |  |  | 15,795 |  |  |  | 69,907 |  |  |  | 89,263 |  |  |  | 13,454 |  |  |  | 102,717 |  |
| Subscriber Solutions |  |  | 73,615 |  |  |  | 8,782 |  |  |  | 82,397 |  |  |  | 73,518 |  |  |  | 8,147 |  |  |  | 81,665 |  |
| Total |  | $ | 179,194 |  |  | $ | 46,797 |  |  | $ | 225,991 |  |  | $ | 283,002 |  |  | $ | 44,376 |  |  | $ | 327,378 |  |
  (was, 2024-05-10, similarity 0.6462):
[0000950170-24-057628:note_history:72]
|  |  | Three Months Ended |  |
|  |  | March 31, 2024 |  |  | March 31, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 60,369 |  |  | $ | 9,399 |  |  | $ | 69,767 |  |  | $ | 70,287 |  |  | $ | 9,049 |  |  | $ | 79,336 |  |
| Access & Aggregation Solutions |  |  | 67,777 |  |  |  | 13,535 |  |  |  | 81,312 |  |  |  | 84,554 |  |  |  | 12,266 |  |  |  | 96,820 |  |
| Optical Networking Solutions |  |  | 53,127 |  |  |  | 21,966 |  |  |  | 75,094 |  |  |  | 127,577 |  |  |  | 20,179 |  |  |  | 147,756 |  |
| Total |  | $ | 181,273 |  |  | $ | 44,900 |  |  | $ | 226,173 |  |  | $ | 282,418 |  |  | $ | 41,494 |  |  | $ | 323,912 |  |

- added (2024-08-09):
[0000950170-24-094602:note_history:73]
|  |  | Six Months Ended |  |
|  |  | June 30, 2024 |  |  | June 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 104,594 |  |  | $ | 44,186 |  |  | $ | 148,780 |  |  | $ | 247,798 |  |  | $ | 42,954 |  |  | $ | 290,752 |  |
| Access & Aggregation Solutions |  |  | 121,889 |  |  |  | 29,330 |  |  |  | 151,219 |  |  |  | 173,817 |  |  |  | 25,720 |  |  |  | 199,537 |  |
| Subscriber Solutions |  |  | 133,984 |  |  |  | 18,181 |  |  |  | 152,165 |  |  |  | 143,805 |  |  |  | 17,196 |  |  |  | 161,001 |  |
| Total |  | $ | 360,467 |  |  | $ | 91,697 |  |  | $ | 452,164 |  |  | $ | 565,420 |  |  | $ | 85,870 |  |  | $ | 651,290 |  |

- changed (2024-08-09):
[0000950170-24-094602:note_history:74]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2024, and December 31, 2023, related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $276.9 million and $314.8 million, respectively. As of June 30, 2024, approximately 57% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of June 30, 2024, are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.
  (was, 2024-05-10, similarity 0.9871):
[0000950170-24-057628:note_history:74]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2024 and December 31, 2023 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $346.9 million and $314.8 million, respectively. As of March 31, 2024, approximately 61.0% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of March 31, 2024 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2024-08-09):
[0000950170-24-094602:note_history:75]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Accounts receivable, net |  | $ | 186,176 |  |  | $ | 216,445 |  |
| Contract assets(1) |  | $ | 719 |  |  | $ | 691 |  |
| Unearned revenue |  | $ | 55,107 |  |  | $ | 46,731 |  |
| Non-current unearned revenue |  | $ | 26,584 |  |  | $ | 25,109 |  |
  (was, 2024-05-10, similarity 0.9841):
[0000950170-24-057628:note_history:75]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Accounts receivable, net |  | $ | 187,554 |  |  | $ | 216,445 |  |
| Contract assets(1) |  | $ | 815 |  |  | $ | 691 |  |
| Unearned revenue |  | $ | 55,124 |  |  | $ | 46,731 |  |
| Non-current unearned revenue |  | $ | 22,884 |  |  | $ | 25,109 |  |

- changed (2024-08-09):
[0000950170-24-094602:note_history:76]
The allowance for credit losses was $0.2 million and $0.4 million as of June 30, 2024, and December 31, 2023, respectively, related to accounts receivable.
  (was, 2024-05-10, similarity 0.848):
[0000950170-24-057628:note_history:76]
The allowance for credit losses was $0.4 million as of March 31, 2024 and December 31, 2023, related to accounts receivable.

- changed (2024-08-09):
[0000950170-24-094602:note_history:77]
No allowance for credit losses was recorded for the three and six months ended June 30, 2024 and 2023 related to contract assets.
  (was, 2024-05-10, similarity 0.9277):
[0000950170-24-057628:note_history:77]
No allowance for credit losses was recorded for the three months ended March 31, 2024 and 2023 related to contract assets.

- changed (2024-08-09):
[0000950170-24-094602:note_history:78]
The Company was party to a receivable purchase agreement with a third-party financial institution (“Factor”), which accelerates receivable collection and helps to better manage cash flow. As of December 31, 2023, no accounts receivable were factored under the agreement or held in the reserve account. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million and $0.6 million for the three and six months ended June 30, 2023.
  (was, 2024-05-10, similarity 0.9065):
[0000950170-24-057628:note_history:78]
The Company was party to a receivable purchase agreement with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. As of December 31, 2023 no accounts receivable were factored under the agreement or held in the reserve account. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months ended March 31, 2023.

- changed (2024-08-09):
[0000950170-24-094602:note_history:79]
On December 19, 2023, the agreement with the Factor was terminated and the Company, entered into a receivables purchase agreement with a third-party financial institution (“New Factor”) to replace the Company’s prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The New Factor provides for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The New Factor qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. Total secured borrowings under the agreement were $17.3 million and $14.3 million as of June 30, 2024 and December 31, 2023, respectively, leaving $22.4 million and $25.4 million available for future borrowings as of June 30, 2024 and December 31, 2023, respectively. Accounts receivable pledged as collateral related to the secured borrowings were $21.2 million and $16.8 million as of June 30, 2024 and December 31, 2023, respectively. For the three and six months ended June 30, 2024, the Company incurred program fee expenses of $0.3 million and $0.6 million, respectively. As of June 30, 2024, the program fee rate was 6.88% percent.
  (was, 2024-05-10, similarity 0.9217):
[0000950170-24-057628:note_history:79]
On December 19, 2023, the agreement with the Factor was terminated and the Company, entered into a receivables purchase agreement with a third-party financial institution (the “New Factor”) to replace the Company’s prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The New Factor provides for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The New Factor qualifies for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. Total secured borrowings under the agreement were $12.6 million and $14.3 million as of March 31, 2024 and December 31, 2023, respectively, leaving $27.2 million and $25.4 million available for future borrowings as of March 31, 2024 and December 31, 2023, respectively. Accounts receivable pledged as collateral related to the secured borrowings were $16.4 million and $16.8 million as of March 31, 2024 and December 31, 2023, respectively. For the three months ended March 31, 2024, the Company incurred program fee expenses of $0.3 million. As of March 31, 2024, the program fee rate was 6.88% percent.

- added (2024-08-09):
[0000950170-24-094602:note_history:80]
Of the outstanding unearned revenue balances as of December 31, 2023, $13.7 million and $33.1 million were recognized as revenue during the three and six months ended June 30, 2024, respectively. Of the $60.4 million of outstanding unearned revenue balances as of December 31, 2022, $24.8 million and $50.5 million were recognized as revenue during the three and six months ended June 30, 2023, respectively.

- removed (2024-08-09):
[0000950170-24-057628:note_history:81]
Of the outstanding unearned revenue balances as of December 31, 2023, $19.7 million were recognized as revenue during the three months ended March 31, 2024. Of the $60.4 million of outstanding unearned revenue balances as of December 31, 2022, $25.6 million were recognized as revenue during the three months ended March 31, 2023.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-08-09):
[0000950170-24-094602:note_history:82]
Receivables Purchase Agreement

- added (2024-08-09):
[0000950170-24-094602:note_history:83]
On July 1, 2024, the Company renegotiated our receivables purchase agreement which is currently treated as a secured borrowing. The renegotiated receivables purchase agreement will result in a derecognition of the accounts receivable sold and the removal of the secured borrowing liability given the agreement transfers effective control over, and risk related to the receivables to the buyers. See Note 1 and Note 2 above for additional information on the accounting treatment of our receivable purchase agreements.

- added (2024-08-09):
[0000950170-24-094602:note_history:84]
Annual Recurring Compensation Payment

- added (2024-08-09):
[0000950170-24-094602:note_history:85]
On July 3, 2024, the Annual Recurring Compensation was paid with respect to the 2023 fiscal year. See Note 1 and Note 18 for additional information on the Annual Recurring Compensation payment.

- removed (2024-08-09):
[0000950170-24-057628:note_history:86]
Facility Closure

- removed (2024-08-09):
[0000950170-24-057628:note_history:87]
In connection with the Business Efficiency Program, management of the Company determined on April 11, 2024 to close the Company’s facility in Greifswald, Germany. The closure of the facility is expected to be substantially completed by June 30, 2024.
