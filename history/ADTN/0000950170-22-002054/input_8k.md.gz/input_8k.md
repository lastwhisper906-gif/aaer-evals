# ADTN 8-K — 0000950170-22-000705 filed 2022-02-03

## item codes, every 8-K on or before 2022-02-25

- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2022-02-25

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-22-000705:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0000950170-22-000705:8k_2_02:2]
EX-99.1

[0000950170-22-000705:8k_2_02:3]
EXHIBIT 99.1

[0000950170-22-000705:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the Fourth Quarter of 2021 and Declares Quarterly Cash Dividend

[0000950170-22-000705:8k_2_02:5]
HUNTSVILLE, Ala. — (February 2, 2022) — ADTRAN, Inc., (NASDAQ:ADTN) (“ADTRAN” or the “Company”), today announced financial results for the fourth quarter of 2021. For the quarter, revenue was $154.2 million. Earnings for the fourth quarter of 2021 were a net loss of $4.2 million and earnings per share was a loss of $0.09. Non-GAAP net income was $4.7 million and non-GAAP earnings per share was $0.10. Non-GAAP net income and non-GAAP earnings per share exclude stock-based compensation expense, acquisition related expenses, amortizations and adjustments, restructuring expenses, amortization of pension actuarial losses, asset impairments, deferred compensation related adjustments, change in valuation allowance related to our deferred tax assets, and the tax effect of these adjustments to net income (loss). The reconciliations between GAAP net income (loss) and earnings (loss) per share to non-GAAP net income and non-GAAP earnings per share are set forth in the table provided below.

[0000950170-22-000705:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “We continue to experience unprecedented demand for our solutions with another record-setting quarter for bookings. These record bookings were combined with record product revenue for both our fiber access platforms, up 48% year-over-year, and residential Wi-Fi platforms, up 72% year-over-year. The growth in these strategic segments was across a diverse mix of large and small service providers in the U.S. and Europe, highlighting the success we have had with customer diversification. Our success in capturing fiber footprint, bundling mesh Wi-Fi platforms and cloud software with fiber access, and the portfolio synergies offered by the announced ADVA combination provide an optimistic outlook for continued growth.”

[0000950170-22-000705:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the fourth quarter of 2021. The quarterly cash dividend of $0.09 per common share is to be paid to the Company’s stockholders of record as of the close of business on February 17, 2022. The payment date will be March 3, 2022.

[0000950170-22-000705:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its fourth quarter results on Thursday, February 3, 2022, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, simply visit ADTRAN’s Investor Relations site at www.adtran.com/investor approximately ten minutes prior to the start of the call, click on the event “ADTRAN Releases 4th Quarter 2021 Financial Results and Earnings Call”, and click on the Webcast link.

[0000950170-22-000705:8k_2_02:9]
An online replay of the Company’s conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or email at investor.relations@adtran.com.

[0000950170-22-000705:8k_2_02:10]
About ADTRAN

[0000950170-22-000705:8k_2_02:11]
At ADTRAN, we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help communications service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking. Find more at ADTRAN.com, LinkedIn and Twitter.

[0000950170-22-000705:8k_2_02:12]
This press release contains forward-looking statements, generally identified by the use of words such as “believe,” “expect,” “intend,” “estimate,” “anticipate,” “will,” “may,” “could” and similar expressions, which forward-looking statements reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including: (i) risks and uncertainties related to the continued impact of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus, including the Delta and Omicron variants), including the severity and duration of the pandemic and the delivery, acceptance and effectiveness of vaccines, which could lead to a decrease in demand for the Company’s products and services, and which has disrupted, and could lead to further disruptions in, the Company’s supply chain, adversely impacting the operations and financial condition of the Company and its customers; actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for employees, which may delay the timing of some orders and expected deliveries and which may impact the Company’s ability to mitigate inefficiencies, delays and additional costs in the Company’s product development, sales, marketing and customer service efforts; the legal, regulatory and administrative developments that have occurred and may continue to occur at the federal, state and local levels and in foreign jurisdictions in response to the pandemic, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns; potential disruptions, breaches, or other incidents affecting the proper operation, availability or security of the Company’s or its partners’ information systems; potential declines in revenues due to declining customer demand and deteriorating macroeconomic conditions; increased expenses related to labor, raw materials, freight or other expenditures; the impact of the COVID-19 pandemic on the Company’s liquidity, as well as risks associated with disruptions in the financial markets and the business of financial institutions as a result of the COVID-19 pandemic which could impact the Company from a financial perspective; the pace of recovery in our markets when the COVID-19 pandemic subsides, which could affect demand for our products; (ii) risks and uncertainties related to the anticipated business combination between the Company and ADVA Optical Networking SE (“ADVA”), including the timing,

[0000950170-22-000705:8k_2_02:13]
receipt and terms and conditions of any required governmental and regulatory approvals of the contemplated business combination that could reduce anticipated benefits or cause the parties to abandon the transaction; the occurrence of any event, change or other circumstances that could give rise to the termination of the business combination agreement; the ability to successfully complete the proposed business combination; regulatory or other limitations imposed as a result of the proposed business combination; the success of the business following the proposed business combination; the ability to successfully integrate the ADTRAN and ADVA businesses; the risk that the parties may not be able to satisfy the conditions to closing of the proposed business combination in a timely manner or at all; risks related to disruption of management time from ongoing business operations due to the proposed business combination; the risk that the publicity surrounding or consummation of the proposed business combination could have adverse effects on the market price of ADTRAN’s common stock or ADVA’s common shares or the ability of ADTRAN and ADVA to retain customers, retain or hire key personnel, maintain relationships with their respective suppliers and customers, and on their operating results and businesses generally; the risk that the successor issuer (“Acorn HoldCo”), may be unable to achieve expected synergies or that it may take longer or be more costly than expected to achieve those synergies; the risk of fluctuations in revenue due to lengthy sales and approval process required by major and other service providers for new products; the risk posed by potential breaches of information systems and cyber-attacks; the risks that ADTRAN, ADVA or the post-combination company may not be able to effectively compete, including through product improvements and development, and (iii) the other risks detailed in the Company’s Annual Report on Form 10-K for the year ended December 31, 2020 and the Company’s quarterly report on Form 10-Q for the quarter ended September 30, 2021. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0000950170-22-000705:8k_2_02:14]
To provide additional transparency, we have disclosed in the tables below non-GAAP operating income, which has been reconciled to operating (loss), and non-GAAP net income and non-GAAP earnings per share - basic and diluted, which have been reconciled to net (loss) income and (loss) earnings per share - basic and diluted, in each case as reported based on Generally Accepted Accounting Principles in the United States (“U.S. GAAP”). These non-GAAP financial measures exclude certain items which management believes are not reflective of the ongoing operating performance of the business. We believe this information is useful in providing period-to-period comparisons of the results of our ongoing operations. Additionally, these measures are used by management in our ongoing planning and annual budgeting processes. We believe the presentation of non-GAAP operating income, non-GAAP net income and non-GAAP earnings per share - basic and diluted, when combined with the U.S. GAAP presentation of operating (loss), net (loss) income and (loss) earnings per share - basic and diluted, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0000950170-22-000705:8k_2_02:15]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, U.S. GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under U.S. GAAP. Additionally, our calculation of non-GAAP operating income, non-GAAP net income and non-GAAP earnings per share - basic and diluted, may not be comparable to similar measures calculated by other companies.

[0000950170-22-000705:8k_2_02:16]
Investor Services/Assistance:
Rhonda Lambert/256-963-7450
investor@adtran.com

[0000950170-22-000705:8k_2_02:17]
Condensed Consolidated Balance Sheets

[0000950170-22-000705:8k_2_02:18]
(Unaudited)

[0000950170-22-000705:8k_2_02:19]
(In thousands)

[0000950170-22-000705:8k_2_02:20]
|  | December 31, |  |  | December 31, |  |
|  | 2021 |  |  | 2020 |  |
| Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 56,603 |  |  | $ | 60,161 |  |
| Restricted cash |  | 215 |  |  |  | 18 |  |
| Short-term investments |  | 350 |  |  |  | 3,131 |  |
| Accounts receivable, net |  | 158,742 |  |  |  | 98,827 |  |
| Other receivables |  | 11,228 |  |  |  | 21,531 |  |
| Inventory, net |  | 139,891 |  |  |  | 125,457 |  |
| Prepaid expenses and other current assets |  | 9,296 |  |  |  | 8,293 |  |
| Total Current Assets |  | 376,325 |  |  |  | 317,418 |  |
| Property, plant and equipment, net |  | 55,766 |  |  |  | 62,399 |  |
| Deferred tax assets, net |  | 9,079 |  |  |  | 9,869 |  |
| Goodwill |  | 6,968 |  |  |  | 6,968 |  |
| Intangibles, net |  | 19,293 |  |  |  | 23,470 |  |
| Other non-current assets |  | 30,971 |  |  |  | 25,425 |  |
| Long-term investments |  | 70,615 |  |  |  | 80,130 |  |
| Total Assets | $ | 569,017 |  |  | $ | 525,679 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |
| Accounts payable | $ | 102,489 |  |  | $ | 49,929 |  |
| Unearned revenue |  | 17,737 |  |  |  | 14,092 |  |
| Accrued expenses and other liabilities |  | 13,673 |  |  |  | 13,609 |  |
| Accrued wages and benefits |  | 14,900 |  |  |  | 15,262 |  |
| Income tax payable, net |  | 6,560 |  |  |  | 1,301 |  |
| Total Current Liabilities |  | 155,359 |  |  |  | 94,193 |  |
| Non-current unearned revenue |  | 9,271 |  |  |  | 6,888 |  |
| Pension liability |  | 11,402 |  |  |  | 18,664 |  |
| Deferred compensation liability |  | 31,383 |  |  |  | 25,866 |  |
| Other non-current liabilities |  | 4,500 |  |  |  | 7,124 |  |
| Total Liabilities |  | 211,915 |  |  |  | 152,735 |  |
| Stockholders' Equity |  | 357,102 |  |  |  | 372,944 |  |
| Total Liabilities and Stockholders' Equity | $ | 569,017 |  |  | $ | 525,679 |  |

[0000950170-22-000705:8k_2_02:21]
Condensed Consolidated Statements of (Loss) Income

[0000950170-22-000705:8k_2_02:22]
(Unaudited)

[0000950170-22-000705:8k_2_02:23]
(In thousands, except per share amounts)

[0000950170-22-000705:8k_2_02:24]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |  |
|  |  | December 31, |  |  | December 31, |  |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 138,809 |  |  | $ | 114,091 |  |  | $ | 498,834 |  |  | $ | 438,015 |  |  |
| Services & Support |  |  | 15,349 |  |  |  | 16,038 |  |  |  | 64,170 |  |  |  | 68,495 |  |  |
| Total Revenue |  |  | 154,158 |  |  |  | 130,129 |  |  |  | 563,004 |  |  |  | 506,510 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 91,797 |  |  |  | 65,734 |  |  |  | 307,841 |  |  |  | 244,226 |  |  |
| Services & Support |  |  | 7,926 |  |  |  | 10,878 |  |  |  | 36,786 |  |  |  | 44,733 |  |  |
| Total Cost of Revenue |  |  | 99,723 |  |  |  | 76,612 |  |  |  | 344,627 |  |  |  | 288,959 |  |  |
| Gross Profit |  |  | 54,435 |  |  |  | 53,517 |  |  |  | 218,377 |  |  |  | 217,551 |  |  |
| Selling, general and administrative expenses |  |  | 35,141 |  |  |  | 29,348 |  |  |  | 124,414 |  |  |  | 113,972 |  |  |
| Research and development expenses |  |  | 26,532 |  |  |  | 27,493 |  |  |  | 108,663 |  |  |  | 113,287 |  |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 65 |  |  |
| Operating Loss |  |  | (7,238 | ) |  |  | (3,324 | ) |  |  | (14,700 | ) |  |  | (9,773 | ) |  |
| Interest and dividend income |  |  | 1,957 |  |  |  | 905 |  |  |  | 2,844 |  |  |  | 1,936 |  |  |
| Interest expense |  |  | (16 | ) |  |  | (4 | ) |  |  | (34 | ) |  |  | (5 | ) |  |
| Net investment gain (loss) |  |  | (1,181 | ) |  |  | 3,031 |  |  |  | 1,761 |  |  |  | 4,850 |  |  |
| Other income (expense), net |  |  | 1,151 |  |  |  | (947 | ) |  |  | 3,824 |  |  |  | (3,254 | ) |  |
| Loss Before Income Taxes |  |  | (5,327 | ) |  |  | (339 | ) |  |  | (6,305 | ) |  |  | (6,246 | ) |  |
| Income tax benefit (expense) |  |  | 1,137 |  |  |  | 6,453 |  |  |  | (2,330 | ) |  |  | 8,624 |  |  |
| Net (Loss) Income |  | $ | (4,190 | ) |  | $ | 6,114 |  |  | $ | (8,635 | ) |  | $ | 2,378 |  |  |
| Weighted average shares outstanding – basic |  |  | 48,914 |  |  |  | 48,111 |  |  |  | 48,582 |  |  |  | 47,996 |  |  |
| Weighted average shares outstanding – diluted |  |  | 48,914 |  |  |  | 48,532 |  | (1) |  | 48,582 |  |  |  | 48,288 |  | (1) |
| (Loss) earnings per common share – basic |  | $ | (0.09 | ) |  | $ | 0.13 |  |  | $ | (0.18 | ) |  | $ | 0.05 |  |  |
| (Loss) earnings per common share – diluted |  | $ | (0.09 | ) |  | $ | 0.13 |  | (1) | $ | (0.18 | ) |  | $ | 0.05 |  | (1) |

[0000950170-22-000705:8k_2_02:25]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0000950170-22-000705:8k_2_02:26]
Condensed Consolidated Statements of Cash Flows

[0000950170-22-000705:8k_2_02:27]
(Unaudited)

[0000950170-22-000705:8k_2_02:28]
(In thousands)

[0000950170-22-000705:8k_2_02:29]
|  |  | Twelve Months Ended |  |
|  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net (loss) income |  | $ | (8,635 | ) |  | $ | 2,378 |  |
| Adjustments to reconcile net (loss) income to net cash provided by (used in) operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 16,084 |  |  |  | 16,627 |  |
| Asset impairments |  |  | — |  |  |  | 65 |  |
| Gain on investments |  |  | (5,127 | ) |  |  | (5,802 | ) |
| Stock-based compensation expense |  |  | 7,480 |  |  |  | 6,834 |  |
| Deferred income taxes |  |  | (1,784 | ) |  |  | (1,356 | ) |
| Other |  |  | 112 |  |  |  | 216 |  |
| Change in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (60,864 | ) |  |  | (7,269 | ) |
| Other receivables |  |  | 9,752 |  |  |  | (4,732 | ) |
| Inventory, net |  |  | (15,667 | ) |  |  | (25,582 | ) |
| Prepaid expenses and other assets |  |  | (7,146 | ) |  |  | (5,239 | ) |
| Accounts payable, net |  |  | 53,270 |  |  |  | 4,543 |  |
| Accrued expenses and other liabilities |  |  | 10,063 |  |  |  | 5,093 |  |
| Income taxes payable |  |  | 5,470 |  |  |  | (2,294 | ) |
| Net cash provided by (used in) operating activities |  |  | 3,008 |  |  |  | (16,518 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (5,669 | ) |  |  | (6,413 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 2 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 50,466 |  |  |  | 105,100 |  |
| Purchases of available-for-sale investments |  |  | (35,031 | ) |  |  | (56,767 | ) |
| Acquisition of note receivable |  |  | — |  |  |  | (523 | ) |
| Life insurance proceeds received |  |  | 500 |  |  |  | — |  |
| Net cash provided by investing activities |  |  | 10,266 |  |  |  | 41,399 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Dividend payments |  |  | (17,529 | ) |  |  | (17,334 | ) |
| Repayment of bonds payable |  |  | — |  |  |  | (24,600 | ) |
| Proceeds from draw on line of credit |  |  | 10,000 |  |  |  | — |  |
| Repayment of line of credit |  |  | (10,000 | ) |  |  | — |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (1,860 | ) |  |  | (1,043 | ) |
| Proceeds from stock option exercises |  |  | 6,431 |  |  |  | — |  |
| Net cash used in financing activities |  |  | (12,958 | ) |  |  | (42,977 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 316 |  |  |  | (18,096 | ) |
| Effect of exchange rate changes |  |  | (3,677 | ) |  |  | 4,502 |  |
| Cash, cash equivalents and restricted cash, beginning of year |  |  | 60,179 |  |  |  | 73,773 |  |
| Cash, cash equivalents and restricted cash, end of year |  | $ | 56,818 |  |  | $ | 60,179 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |
| Cash paid during the year for interest |  | $ | 13 |  |  | $ | 24 |  |
| Cash paid during the year for income taxes |  | $ | 1,780 |  |  | $ | 7,609 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 638 |  |  | $ | 108 |  |

[0000950170-22-000705:8k_2_02:30]
Supplemental Information

[0000950170-22-000705:8k_2_02:31]
Reconciliation of Operating Loss to Non-GAAP Operating Income

[0000950170-22-000705:8k_2_02:32]
(Unaudited)

[0000950170-22-000705:8k_2_02:33]
(Amounts in table in thousands)

[0000950170-22-000705:8k_2_02:34]
|  | Three Months Ended December 31, |  |  | Twelve Months Ended December 31, |  |  |
|  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |  |
| Operating Loss | $ | (7,238 | ) |  | $ | (3,324 | ) |  | $ | (14,700 | ) |  | $ | (9,773 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  | 6,529 |  | (1) |  | 1,051 |  | (5) |  | 15,999 |  | (8) |  | 4,550 |  | (11) |
| Stock-based compensation expense |  | 2,023 |  | (2) |  | 1,778 |  | (6) |  | 7,480 |  | (9) |  | 6,834 |  | (12) |
| Restructuring expenses |  | 102 |  | (3) |  | 2,581 |  | (7) |  | 411 |  | (10) |  | 6,229 |  | (13) |
| Deferred compensation adjustments |  | (2 | ) | (4) |  | 2,172 |  | (4) |  | 2,089 |  | (4) |  | 2,937 |  | (4) |
| Asset impairments |  | — |  |  |  | — |  |  |  | — |  |  |  | 65 |  | (14) |
| Settlement income |  | — |  |  |  | — |  |  |  | — |  |  |  | (28 | ) | (15) |
| Non-GAAP Operating Income | $ | 1,414 |  |  | $ | 4,258 |  |  | $ | 11,279 |  |  | $ | 10,814 |  |  |

[0000950170-22-000705:8k_2_02:35]
(1) $6.0 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:36]
(2) $0.2 million is included in total cost of revenue, $1.2 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:37]
(3) Less than $0.1 million is included in selling, general and administrative expenses and less than $0.1 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:38]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of (loss) income.

[0000950170-22-000705:8k_2_02:39]
(5) $0.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:40]
(6) $0.1 million is included in total cost of revenue, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:41]
(7) $0.2 million is included in total cost of revenue, $0.2 million is included in selling, general and administrative expenses and $2.2 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:42]
(8) Less than $0.1 million is included in total cost of revenue, $14.1 million is included in selling, general and administrative expenses and $1.9 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:43]
(9) $0.5 million is included in total cost of revenue, $4.6 million is included in selling, general and administrative expenses and $2.4 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:44]
(10) Less than $0.1 million is included in total cost of revenue, $0.2 million is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:45]
(11) $0.3 million is included in total cost of sales, $2.3 million is included in selling, general and administrative expenses and $1.9 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:46]
(12)  $0.4 million is included in total cost of sales, $4.0 million is included in selling, general and administrative expenses and $2.4 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:47]
(13) $0.5 million is included in total cost of sales, $1.8 million is included in selling, general and administrative expenses and $3.9 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:48]
(14) Includes abandonment of certain information technology projects.

[0000950170-22-000705:8k_2_02:49]
(15) Includes income related to certain freight forward claims settlements, all of which is included in total cost of sales on the condensed consolidated statements of (loss) income.

[0000950170-22-000705:8k_2_02:50]
Supplemental Information

[0000950170-22-000705:8k_2_02:51]
Reconciliation of Net (Loss) Income and (Loss) Earnings per Common Share – Basic and Diluted

[0000950170-22-000705:8k_2_02:52]
to Non-GAAP Net Income and Non-GAAP Earnings per Common Share – Basic and Diluted

[0000950170-22-000705:8k_2_02:53]
(Unaudited)

[0000950170-22-000705:8k_2_02:54]
(Amounts in table in thousands, except per share amounts)

[0000950170-22-000705:8k_2_02:55]
|  |  | Three Months ended December 31, |  |  |  | Twelve Months ended December 31, |  |  |
|  |  | 2021 |  |  | 2020 |  |  |  | 2021 |  |  | 2020 |  |  |
| Net (Loss) Income |  | $ | (4,190 | ) |  | $ | 6,114 |  |  |  | $ | (8,635 | ) |  | $ | 2,378 |  |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 6,529 |  |  |  | 1,051 |  |  |  |  | 15,999 |  |  |  | 4,550 |  |  |
| Stock-based compensation expense |  |  | 2,023 |  |  |  | 1,778 |  |  |  |  | 7,480 |  |  |  | 6,834 |  |  |
| Restructuring expenses |  |  | 102 |  |  |  | 2,581 |  |  |  |  | 411 |  |  |  | 6,229 |  |  |
| Deferred compensation adjustments(1) |  |  | 673 |  |  |  | 601 |  |  |  |  | 1,225 |  |  |  | (831 | ) | (3) |
| Pension expense(2) |  |  | 263 |  |  |  | 250 |  |  |  |  | 1,088 |  |  |  | 970 |  |  |
| Valuation allowance |  |  | 333 |  |  |  | (5,420 | ) |  |  |  | 4,746 |  |  |  | (2,798 | ) |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 65 |  |  |
| Settlement income |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | (28 | ) |  |
| Tax effect of adjustments to net (loss) income |  |  | (1,016 | ) |  |  | (1,716 | ) |  |  |  | (3,947 | ) |  |  | (4,805 | ) |  |
| Non-GAAP Net Income |  | $ | 4,717 |  |  | $ | 5,239 |  |  |  | $ | 18,367 |  |  | $ | 12,564 |  |  |
| Weighted average shares outstanding – basic |  |  | 48,914 |  |  |  | 48,111 |  |  |  |  | 48,582 |  |  |  | 47,996 |  |  |
| Weighted average shares outstanding – diluted |  |  | 48,914 |  |  |  | 48,532 |  |  |  |  | 48,582 |  |  |  | 48,288 |  |  |
| (Loss) earnings per common share - basic |  | $ | (0.09 | ) |  | $ | 0.13 |  |  |  | $ | (0.18 | ) |  | $ | 0.05 |  |  |
| (Loss) earnings per common share - diluted |  | $ | (0.09 | ) |  | $ | 0.13 |  |  |  | $ | (0.18 | ) |  | $ | 0.05 |  |  |
| Non-GAAP earnings per common share - basic |  | $ | 0.10 |  |  | $ | 0.11 |  |  |  | $ | 0.38 |  |  | $ | 0.26 |  |  |
| Non-GAAP earnings per common share - diluted |  | $ | 0.10 |  |  | $ | 0.11 |  |  |  | $ | 0.38 |  |  | $ | 0.26 |  |  |

[0000950170-22-000705:8k_2_02:56]
(1) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-22-000705:8k_2_02:57]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-22-000705:8k_2_02:58]
(3) Includes net investment gain of $1.5 million related to the out-of-period remeasurement to historical cost basis of certain long-term investments held in the Company's stock as part of one of the Company's deferred compensation plans.
