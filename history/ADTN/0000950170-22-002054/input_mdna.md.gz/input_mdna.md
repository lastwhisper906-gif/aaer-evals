# ADTN MD&A — 0000950170-22-002054


## mdna

[0000950170-22-002054:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000950170-22-002054:mdna:2]
The following discussion should be read in conjunction with our audited consolidated financial statements and the related notes included in Part II, Item 8 of this report. We have omitted discussion of the earliest of the three years of financial condition and results of operations and this information can be found in Part I, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the fiscal year ended December 31, 2020, filed with the SEC on February 26, 2021, which is available free of charge on the SEC's website at http://www.sec.gov and on our website at www.adtran.com.

[0000950170-22-002054:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 2 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part I, Item 1A, Risk Factors, of this Form 10-K.

[0000950170-22-002054:mdna:4]
Overview

[0000950170-22-002054:mdna:5]
ADTRAN is a leading global provider of networking and communications platforms, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, alternative service providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. In order to service our customers and grow revenue, we are continually conducting research and development of new products addressing customer needs and testing those products for the specific requirements of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have sales and research and development facilities in strategic global locations.

[0000950170-22-002054:mdna:6]
We ended 2021 with a year-over-year revenue increase of 11.2%, driven by increased shipments to a diverse mix of global Tier-1 and regional service providers. During 2021, we had one 10% revenue customer which was a distributor located in the U.S. Our year-over-year domestic revenue increased by 6.4%, driven by increased volume of network termination and Fiber CPE in our Network Solutions segment. Internationally, our revenue increased by 22.0% compared to the prior year period, primarily driven by increased shipments to alternative network operators and a Tier-1 operator in Europe. We experienced strong demand for our solutions in the second half of 2021 and achieved significant year-over-year bookings growth. Bookings are defined as orders received for a product or service during a fiscal period that will be delivered or performed sometime in the future and is a forward looking metric that we utilize to help us understand future revenue growth for the Company. Bookings are generally subject to modification and or cancellation per the terms of the order. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing nonbinding purchase commitments. Our increase in demand comes from service providers planning to deploy our fiber access platforms, in-home service delivery platforms and SaaS applications. We expect this growth to accelerate. During 2021, we secured several Tier-1 next-generation fiber customers, and previously announced Tier-1 fiber customers significantly increased their bookings for our fiber access platforms. Although we expect our revenue growth and profitability in the near-term to continue to be negatively impacted by supply chain issues, our outlook continues to strengthen given the record demand for our products and our expectation of an improving supply chain over the long-term.

[0000950170-22-002054:mdna:7]
In March 2020, the World Health Organization declared the novel coronavirus (COVID-19) outbreak a global pandemic. The SARS-CoV-2 coronavirus (or variants of the SARS-CoV-2 coronavirus, including the Delta and Omicron variant) continues to spread throughout the U.S. and the world and has resulted in authorities implementing varying measures to contain the virus, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns. While the rollout of COVID-19 vaccines throughout 2021 mitigated mortality risk, new COVID-19 variants proved to remain a threat. The lifting of lockdowns in certain areas started a slow economic recovery, but it cannot be predicted how long it will take before market conditions return to normal and there can be no assurance that the economic recovery will offset the uncertainty and instability triggered by the pandemic. New and potentially more contagious variants of the COVID-19 virus are developing in several countries, including regions in which we have significant operations. The COVID-19 variants could further amplify the impact of the pandemic. While we are unable to accurately predict the full impact that the COVID-19 global pandemic will have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time.

[0000950170-22-002054:mdna:8]
We have experienced a significant impact to our supply chain given COVID-19 and the related global semiconductor chip shortage, including delays in supply chain deliveries, extended lead times and shortages of some key components, some raw material cost increases and slowdowns at certain production facilities. We have also had to increase our volume of inventory to ensure supply continuity during the pandemic. In addition, we have experienced significant increases in freight-related costs due to the global shipping crisis. During the second half of 2021, the Company incurred supply chain constraint expenses which lowered our gross margins and decreased our profitability. While throughout the pandemic we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments, as well as COVID-19 related reductions in travel and infrastructure expenses, it is possible that we could experience some slowdown in demand, further supply chain issues and an increased impact from the ongoing semiconductor shortage and shortages of certain other key components as the pandemic continues. If the impacts of this shortage are more severe than we expect, it could result in longer lead times, inventory supply challenges and further increased costs, all of which could result in the deterioration of our results, potentially for a longer period than currently anticipated. To support the health and well-being of our employees, customers, partners and communities, many of our employees are working remotely as of the date of filing this report. However, there is risk that a number of our employees could be infected with COVID-19, including our key personnel. In addition, actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for certain employees, as well as the impacts to our supply chain, including delays in supply chain deliveries and the related global semiconductor chip shortage, have delayed and may continue to delay the timing of some orders and expected deliveries. Lastly, even after the COVID-19 pandemic has subsided, we may continue to experience adverse impacts to our business as a result of any economic recession that has occurred or may occur in the future as a result of the COVID-19 pandemic.

[0000950170-22-002054:mdna:9]
Among our customers, we made progress with our fiber, fiber-extension, in-home service delivery platforms and cloud services while also continuing to engage in value-added service opportunities that we expect will contribute to 2022 revenue and beyond. In addition, we believe that we are at the beginning of a significant investment cycle for fiber deployment and in-home Wi-Fi connectivity driven by technology advancements and regulatory influences. The transition to next-generation network architectures is beginning, and we are seeing demand for our next-generation fiber access and connected home solutions. In 2021, FCC RDOF government funding programs commenced with our service providers and we believe that we are well positioned in 2022 to receive orders.

[0000950170-22-002054:mdna:10]
In addition to classifying our operations into two reportable segments, we report revenue across three categories of products and services – (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products.

[0000950170-22-002054:mdna:11]
Our Access & Aggregation platforms are used by CSPs to connect their network infrastructure to subscribers. This revenue category includes hardware- and software-based products and services that aggregate and/or originate access technologies. ADTRAN solutions within this category include a wide array of modular or fixed platforms designed to deliver the best technology and economy based on subscriber density and environmental conditions.

[0000950170-22-002054:mdna:12]
Our Subscriber Solutions & Experience portfolio is used by service providers to terminate their infrastructure at the customer’s premises while providing an immersive and interactive experience for the subscriber. These solutions include copper and fiber WAN termination, LAN switching, Wi-Fi access, and cloud software services, for both residential and business markets.

[0000950170-22-002054:mdna:13]
Our Traditional & Other Products category generally includes a mix of prior-generation technologies’ products and services, as well as other products and services that do not fit within the other revenue categories.

[0000950170-22-002054:mdna:14]
Our operating results have fluctuated, and may continue to fluctuate, on a quarterly basis due to several factors, including customer order activity, supply chain constraints, component availability, and backlog. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days requiring us to maintain higher inventory levels. These factors normally result in a varying order backlog and limited order flow visibility; however, with the current global supply chain and transportation constraints, and limited availability of semiconductor chips and other components of our products, we have experienced and may continue to experience extended lead times, increased logistics intervals and costs, and lower volume of products deliveries, which have and may continue to have a material adverse effect on our operating results and could have a material adverse effect on customer relations and our financial condition. We expect that the supply chain constraints and semiconductor shortage will continue to affect our operating results through the end of 2022, although we cannot predict such factors with certainty. Normal operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenue could significantly impact our financial results in a given quarter.

[0000950170-22-002054:mdna:15]
We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, ODMs, distributors, and customers to address and to limit the disruption to our operations and order fulfillment.

[0000950170-22-002054:mdna:16]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that initially resulted from the COVID-19 pandemic and that may recur, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, domestic and international geographical mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results. In recent years, the Company initiated restructuring plans to realign its expense structure with the reduction in revenue experienced and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and implemented certain cost savings initiatives, where possible. See Note 20 of the Notes to Consolidated Financial Statements included in Part 1I, Item 8 of this report for additional information on this restructuring.

[0000950170-22-002054:mdna:17]
Our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. See Note 21 of Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report, for additional information on quarterly results for 2021 and 2020. For a discussion of risks associated with our operating results, see Part I, Item 1A, Risk Factors of this report.

[0000950170-22-002054:mdna:18]
Business Combination Agreement

[0000950170-22-002054:mdna:19]
On August 30, 2021, the Company and ADVA, entered into a business combination agreement (the “Business Combination Agreement”), pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, Acorn HoldCo, a Delaware corporation and currently a wholly-owned direct subsidiary of the Company.

[0000950170-22-002054:mdna:20]
Under the terms of the Business Combination Agreement, Acorn MergeCo, Inc., a newly formed Delaware corporation and wholly-owned direct subsidiary of Acorn HoldCo (“Merger Sub”), will merge with and into ADTRAN, with ADTRAN surviving the merger (the “Merger”) as a wholly-owned direct subsidiary of Acorn HoldCo. Pursuant to the Merger, each outstanding share of common stock of the Company will be converted into the right to receive one share of common stock of Acorn HoldCo. Acorn HoldCo has also made a public exchange offer to exchange each issued and outstanding no-par value bearer share of ADVA, pursuant to which each ADVA share tendered and accepted for exchange will be exchanged for 0.8244 shares of common stock of Acorn HoldCo (the “Exchange Offer”, and together with the Merger, the “Business Combination”). Upon completion of the Business Combination, and assuming that all of the outstanding ADVA shares are exchanged in the Exchange Offer, former ADTRAN stockholders and former ADVA shareholders will own approximately 54% and 46%, respectively, of the outstanding Acorn HoldCo shares.

[0000950170-22-002054:mdna:21]
The Business Combination Agreement was unanimously approved by the Board of Directors of the Company and by the supervisory board and management board of ADVA. On January 6, 2022, the Company's stockholders approved the Business Combination by an overwhelming majority. The end of the ADVA shareholder tender offer acceptance period was on January 26, 2022, which resulted in the acceptance of the Exchange Offer by more than 60% of all shares of ADVA entitled to voting rights existing as of October 31, 2021, thus exceeding the required minimum acceptance threshold. According to the rules of the German Securities Acquisition and Takeover Act, ADVA shareholders who did not tender their shares during the initial acceptance period could do so during a two-week additional acceptance period that began on February 1, 2022 and ended February 14, 2022. This resulted in the acceptance of the Exchange Offer by approximately 66% of all shares of ADVA entitled to voting rights existing as of November 30, 2021. On January 24, 2022, the CFIUS completed its review of the Business Combination and determined that the transaction was not a “covered transaction” subject to CFIUS’ jurisdiction, satisfying the condition of the Business Combination Agreement related to CFIUS notification. On February 16, 2022, the U.K. Secretary of State  for Business, Energy and Industrial Strategy completed its review of the Business Combination and determined that the Secretary of State will be taking no further action under the NS&I Act, satisfying the condition of the Business Combination Agreement related to NS&I approval. Cooperative proceedings continue with the foreign direct investment authority in Germany.

[0000950170-22-002054:mdna:22]
The Company anticipates the consummation of the Business Combination around the middle of 2022, subject to customary closing conditions, and regulatory approvals from the foreign direct investment authority in Germany.

[0000950170-22-002054:mdna:23]
Additional information about the Business Combination Agreement and proposed Business Combination is set forth in the Company’s filings with the SEC, as well as in the registration statement on Form S-4 that Acorn HoldCo filed with the SEC, which was declared effective December 2, 2021 (the “Acorn HoldCo Registration Statement”).

[0000950170-22-002054:mdna:24]
Results of Operations

[0000950170-22-002054:mdna:25]
The following table presents selected financial information derived from our Consolidated Statements of (Loss) Income expressed as a percentage of revenue for the years indicated. Amounts may not foot due to rounding.

[0000950170-22-002054:mdna:26]
|  |  | Year Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Revenue |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 88.6 | % |  |  | 86.5 | % |  |  | 85.9 | % |
| Services & Support |  |  | 11.4 |  |  |  | 13.5 |  |  |  | 14.1 |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 54.7 |  |  |  | 48.2 |  |  |  | 49.7 |  |
| Services & Support |  |  | 6.5 |  |  |  | 8.8 |  |  |  | 8.9 |  |
| Total Cost of Revenue |  |  | 61.2 |  |  |  | 57.0 |  |  |  | 58.7 |  |
| Gross Profit |  |  | 38.8 |  |  |  | 43.0 |  |  |  | 41.3 |  |
| Selling, general and administrative expenses |  |  | 22.1 |  |  |  | 22.5 |  |  |  | 24.6 |  |
| Research and development expenses |  |  | 19.3 |  |  |  | 22.4 |  |  |  | 23.8 |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  | 0.7 |  |
| Gain on contingency |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |
| Operating Loss |  |  | (2.6 | ) |  |  | (1.9 | ) |  |  | (7.5 | ) |
| Interest and dividend income |  |  | 0.5 |  |  |  | 0.4 |  |  |  | 0.5 |  |
| Interest expense |  |  | — |  |  |  | — |  |  |  | (0.1 | ) |
| Net investment gain |  |  | 0.3 |  |  |  | 1.0 |  |  |  | 2.2 |  |
| Other income (expense), net |  |  | 0.7 |  |  |  | (0.6 | ) |  |  | 0.3 |  |
| Loss Before Income Taxes |  |  | (1.1 | ) |  |  | (1.2 | ) |  |  | (4.7 | ) |
| Income tax (expense) benefit |  |  | (0.4 | ) |  |  | 1.7 |  |  |  | (5.3 | ) |
| Net (Loss) Income |  |  | (1.5 | )% |  |  | 0.5 | % |  |  | (10.0 | )% |

[0000950170-22-002054:mdna:27]
The following discussion and financial information are presented to aid in an understanding of our current consolidated financial position, changes in financial position, results of operations and cash flows and should be read in conjunction with the audited consolidated financial statements and notes thereto included herein. The emphasis of the discussion is a comparison of the years ended December 31, 2021 and December 31, 2020. For a discussion of a comparison of the years ended December 31, 2020 and December 31, 2019, please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 26, 2021.

[0000950170-22-002054:mdna:28]
Comparison of Years Ended December 31, 2021 and December 31, 2020

[0000950170-22-002054:mdna:29]
Revenue

[0000950170-22-002054:mdna:30]
Our revenue increased 11.2% from $506.5 million for the year ended December 31, 2020 to $563.0 million for the year ended December 31, 2021. Our Network Solutions revenue increased by $60.8 million compared to 2020 and our Services & Support revenue decreased by $4.3 million versus the prior year. The increase in our 2021 revenue was primarily attributable to increases in Access & Aggregation revenue of $31.1 million and Subscriber Solutions & Experience revenue of $28.5 million, partially offset by decreases in Traditional & Other Products revenue of $3.1 million. Although our revenue increased, supply of semiconductor chips and other components of our products has become constrained resulting in extended lead times and increased costs. Transportation constraints, including shortages for both air and surface freight, as well as labor shortages in the transportation industry, have also affected the timing and the cost of obtaining raw materials and production supplies. Although our revenue growth and profitability in the near-term may be impacted by these global supply chain issues, our long-term outlook continues to strengthen given the strong customer order bookings during the last half of 2021.

[0000950170-22-002054:mdna:31]
Network Solutions revenue increased by 13.9% from $438.0 million in 2020 to $498.8 million in 2021, due primarily to increases in Access & Aggregation revenue and Subscriber Solutions & Experience revenue, partially offset by a decrease in Traditional & Other Products revenue. The increase in revenue of 9.9% of our Access & Aggregation products for 2021 was due to increased volume of fiber access. The increase of 16.7% in 2021 for revenue of our Subscriber Solutions & Experience products was primarily attributable to increased volume of network termination and fiber CPE. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate, and continue to fluctuate, for years because of the time required for our customers to transition to newer technologies.

[0000950170-22-002054:mdna:32]
Services & Support revenue decreased by 6.3% from $68.5 million in 2020 to $64.2 million in 2021. The decrease in revenue for 2021 was primarily attributable to decreased network planning and implementation services partially offset by an increase in maintenance and managed services.

[0000950170-22-002054:mdna:33]
Domestic revenue increased by 6.4% from $352.1 million in 2020 to $374.6 million in 2021, driven by increased volume of network termination and fiber CPE in our Network Solutions segment. In addition, such growth was a result of increased revenue to Tier-2 and Tier-3 customers with diversified business among our fiber access and CPE, service provider CPE and services.

[0000950170-22-002054:mdna:34]
International revenue, which is included in the amounts for the Network Solutions and Services & Support segments discussed above, increased by 22.0% from $154.4 million for the year ended December 31, 2020 to $188.4 million for the year ended December 31, 2021. International revenue, as a percentage of total revenue, increased from 30.5% for the year ended December 31, 2020 to 33.5% for the year ended December 31, 2021. The increase in international revenue for 2021 was primarily driven by increased shipments to alternative network operators and a Tier-1 operator in Europe.

[0000950170-22-002054:mdna:35]
Our international revenue is largely focused on broadband infrastructure and is affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country.

[0000950170-22-002054:mdna:36]
As a result of our global operations, our revenue and operating income in some international markets can be affected by foreign currency fluctuations. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income. However, for the year ended December 31, 2021, foreign currency fluctuations did not materially impact the Company's results of operations.

[0000950170-22-002054:mdna:37]
Cost of Revenue

[0000950170-22-002054:mdna:38]
As a percentage of revenue, cost of revenue increased from 57.0% for the year ended December 31, 2020 to 61.2% for the year ended December 31, 2021. The increase was primarily attributable to supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift.

[0000950170-22-002054:mdna:39]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 55.8% of revenue in 2020 to 61.7% of revenue in 2021. The increase in Network Solutions cost of revenue as a percentage of that segment’s revenue was primarily attributable to supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift.

[0000950170-22-002054:mdna:40]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 65.3% of revenue in 2020 to 57.3% of revenue in 2021. The decrease in Services & Support cost of revenue as a percentage of that segment’s revenue in 2021 was primarily attributable to customer mix, changes in services and support mix.

[0000950170-22-002054:mdna:41]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0000950170-22-002054:mdna:42]
Selling, General and Administrative Expenses

[0000950170-22-002054:mdna:43]
Selling, general and administrative expenses as a percentage of revenue decreased from 22.5% for the year ended December 31, 2020 to 22.1% for the year ended December 31, 2021. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared as these costs are relatively fixed in the short term.

[0000950170-22-002054:mdna:44]
Selling, general and administrative expenses increased by 9.2% from $114.0 million for the year ended December 31, 2020 to $124.4 million for the year ended December 31, 2021. Selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The increase in selling, general and administrative expenses was primarily attributable to increased acquisition expenses, deferred compensation related costs and insurance expense, partially offset by decreases in restructuring expenses, travel related expense and legal expense.

[0000950170-22-002054:mdna:45]
Research and Development Expenses

[0000950170-22-002054:mdna:46]
Research and development expenses as a percentage of revenue decreased from 22.4% for the year ended December 31, 2020 to 19.3% for the year ended December 31, 2021. Research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared as these costs are relatively fixed in the short term.

[0000950170-22-002054:mdna:47]
Research and development expenses decreased by 4.1% from $113.3 million for the year ended December 31, 2020 to $108.7 million for the year ended December 31, 2021. The decrease in research and development expenses was primarily attributable to lower personnel costs which were mainly the result of our restructuring programs, partially offset by increased contract services.

[0000950170-22-002054:mdna:48]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product and market opportunities and engage in significant research and development efforts which provide for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0000950170-22-002054:mdna:49]
Asset Impairments

[0000950170-22-002054:mdna:50]
Asset impairments relate to the abandonment of certain information technology implementation projects in which we had previously capitalized costs. No impairments incurred in the year ended December 31, 2021. Impairments were less than $0.1 million for the year ended December 31, 2020.

[0000950170-22-002054:mdna:51]
Interest and Dividend Income

[0000950170-22-002054:mdna:52]
Interest and dividend income increased by 46.9% from $1.9 million for the year ended December 31, 2020 to $2.8 million for the year ended December 31, 2021. The increase in interest and dividend income was primarily attributable to an increase in the rate of return on our investments. Our investments decreased from $83.3 million as of December 31, 2020 to $71.0 million as of December 31, 2021.

[0000950170-22-002054:mdna:53]
Interest Expense

[0000950170-22-002054:mdna:54]
Interest expense was less than $0.1 million for each of the years ended December 31, 2021 and 2020. Interest expense during 2021 was primarily related to our Revolving Credit Agreement that we entered into during the fourth quarter of 2020. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our revolving credit agreement.

[0000950170-22-002054:mdna:55]
Net Investment Gain

[0000950170-22-002054:mdna:56]
We recognized a net investment gain of $4.9 million and $1.8 million for the years ended December 31, 2020 and 2021, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See “Investing Activities” in “Liquidity and Capital Resources” of this report and Note 1 and Note 6 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-22-002054:mdna:57]
Other Income (Expense), net

[0000950170-22-002054:mdna:58]
Other income (expense), net, increased from expense of $3.3 million for the year ended December 31, 2020 to income of $3.8 million for the year ended December 31, 2021. For the years ended December 31, 2021 and 2020, other income (expense), net, is comprised primarily of gains and losses on foreign currency transactions and income from excess material sales.

[0000950170-22-002054:mdna:59]
Income Tax (Expense) Benefit

[0000950170-22-002054:mdna:60]
Our effective tax rate decreased from a benefit of 138.1%, for the year ended December 31, 2020 to an expense of 37.0% for the year ended December 31, 2021. The change in the effective tax rate for the year ended December 31, 2021 was primarily driven by a tax benefit in the amount of $10.8 million during 2020, $7.9 million of which related to the utilization of deferred tax assets which had previously been offset with a valuation allowance and $2.9 million primarily related to the tax rate differential on carrying back losses from 2018 and 2019 tax years to prior years in which the U.S. Corporate tax rate was 35% versus the current 21% federal tax rate. See Note 14 of the Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-22-002054:mdna:61]
Net (Loss) Income

[0000950170-22-002054:mdna:62]
As a result of the above factors, our net income decreased from $2.4 million for the year ended December 31, 2020 to a net loss of $8.6 million for the year ended December 31, 2021. As a percentage of revenue, net income was 0.5% for the year ended December 31, 2020 and net loss was 1.5% for the year ended December 31, 2021.

[0000950170-22-002054:mdna:63]
Liquidity and Capital Resources

[0000950170-22-002054:mdna:64]
Liquidity

[0000950170-22-002054:mdna:65]
We have historically financed, and currently expect to continue to finance, our ongoing business with existing cash, investments and cash flow from operations. We have used, and expect to continue to use, existing cash, investments and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures. Under the Business Combination Agreement, the Company will bear the transaction costs of the Business Combination attributable to Acorn HoldCo and the Company. As of December 31, 2021, the Company will incur an estimated $9.5 million of additional transaction costs related to the Business Combination Agreement. We believe that our cash and cash equivalents, investments and cash generated from operations will be adequate to meet our operating needs, capital needs and obligations under the Business Combination for at least the next 12 months.

[0000950170-22-002054:mdna:66]
As of December 31, 2021, cash on hand was $56.6 million and short-term investments were $0.4 million, which resulted in available short-term liquidity of $57.0 million, of which $47.7 million was held by our foreign subsidiaries. As of December 31, 2020, cash on hand was $60.2 million and short-term investments were $3.1 million, which resulted in available short-term liquidity of $63.3 million, of which $49.7 million was held by our foreign subsidiaries. The decrease in short-term liquidity from December 31, 2020 to December 31, 2021 was primarily attributable to the sale of certain equity and fixed income investments for working capital and other purposes.

[0000950170-22-002054:mdna:67]
Operating Activities

[0000950170-22-002054:mdna:68]
Net cash provided by operating activities of $3.0 million during the year ended December 31, 2021 increased by $19.5 million compared to net cash used of $16.5 million during the year ended December 31, 2020. This increase was primarily due to net cash inflows from working capital, specifically, an increase in the average number days payable to our trade suppliers and a decrease in other receivables, partially offset by an inventory build related to component availability, an increase in accounts receivable, and an increase in the average number of days it takes the Company to collect cash payment for sales. Additional details related to our working capital and its drivers are discussed below.

[0000950170-22-002054:mdna:69]
Net accounts receivable increased 60.6% from $98.8 million as of December 31, 2020 to $158.7 million as of December 31, 2021. We had no allowance for credit losses as of December 31, 2021 and less than $0.1 million as of December 31, 2020. Quarterly accounts receivable DSO increased from 70 days as of December 31, 2020 to 95 days as of December 31, 2021. The increase in DSO was due to the higher sales volume and timing of shipments late in the quarter tied to supply chain constraints and customer mix.

[0000950170-22-002054:mdna:70]
Other receivables decreased 47.9% from $21.5 million as of December 31, 2020 to $11.2 million as of December 31, 2021. The decrease in other receivables was primarily attributable to decreases in income tax receivables related to the CARES Act.

[0000950170-22-002054:mdna:71]
Annual inventory turnover increased from 2.58 turns as of December 31, 2020 to 2.60 turns as of December 31, 2021. Inventory increased 11.5% from $125.5 million as of December 31, 2020 to $139.9 million as of December 31, 2021. The increase in inventory was due to increased purchases in preparation for strategic inventory buffer purchases as well as new product ramp ups to ensure supply continuity during the COVID-19 pandemic. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to COVID-19 uncertainties related to supply chain and supply, seasonal cycles of our business and ensuring competitive lead times while managing the risk of inventory.

[0000950170-22-002054:mdna:72]
Accounts payable increased 105.3% from $49.9 million as of December 31, 2020 to $102.5 million as of December 31, 2021. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases. The significant increase in the fourth quarter was due to higher sales volume and additional purchases of raw material inventory buffer stock.

[0000950170-22-002054:mdna:73]
Investing Activities

[0000950170-22-002054:mdna:74]
Capital expenditures totaled approximately $5.7 million and $6.4 million for the years ended December 31, 2021 and 2020, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements.

[0000950170-22-002054:mdna:75]
Our combined short-term and long-term investments decreased $12.3 million from $83.3 million as of December 31, 2020 to $71.0 million as of December 31, 2021. This decrease reflects the sale of certain fixed income investments for working capital and other purposes.

[0000950170-22-002054:mdna:76]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 6 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-22-002054:mdna:77]
As of December 31, 2021, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds were classified as available-for-sale and had a combined duration of 1.61 years with an average Standard & Poor’s credit rating of AA. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0000950170-22-002054:mdna:78]
Our long-term investments decreased 11.9% from $80.1 million as of December 31, 2020 to $70.6 million as of December 31, 2021. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $12.6 million and $11.0 million, as of December 31, 2021 and 2020, respectively. Long-term investments as of December 31, 2021 and 2020 also included $26.9 million and $23.9 million, respectively, related to our deferred compensation plan, and $0.2 million of other investments, consisting of interests in a private equity fund, as of December 31, 2020.

[0000950170-22-002054:mdna:79]
Financing Activities

[0000950170-22-002054:mdna:80]
Revolving Credit Agreement

[0000950170-22-002054:mdna:81]
On November 2, 2021, the Company renewed its Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 3, 2022, subject to earlier termination upon the occurrence of certain events of default. The Company entered into the Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. During the fourth quarter of 2021, the Company made draws totaling $10.0 million under the Revolving Credit Agreement all of which had been repaid as of December 31, 2021. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company. The Company must be in compliance with all covenants to be able to draw on the line of credit. As of December 31, 2021, the Company was in compliance with all covenants. See Note 12 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-22-002054:mdna:82]
Alabama State Industrial Development Authority Financing

[0000950170-22-002054:mdna:83]
In conjunction with the 1995 expansion of our Huntsville, Alabama facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, in January 1995, the Authority issued $20.0 million of its taxable revenue bonds (the “Taxable Revenue Bonds”) and loaned the proceeds from the sale of the Taxable Revenue Bonds to the Company. Further advances on the Taxable Revenue Bonds were made by the Authority, bringing the total amount to $50.0 million. The Taxable Revenue Bonds bore interest, payable monthly with an interest rate of 2% per annum. The Taxable Revenue Bonds aggregate principal amount of $24.6 million matured on January 1, 2020 and was repaid in full on January 2, 2020, using the funds held in a certificate of deposit by the Company. See Note 13 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-22-002054:mdna:84]
Dividends

[0000950170-22-002054:mdna:85]
During 2021 and 2020, we paid shareholder dividends totaling $17.5 million and $17.3 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained. The following table shows dividends per common share paid to our shareholders in each quarter of 2021 and 2020:

[0000950170-22-002054:mdna:86]
| Dividends per Common Share |  |
|  |  | 2021 |  |  | 2020 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0000950170-22-002054:mdna:87]
Stock Repurchase Program

[0000950170-22-002054:mdna:88]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. There were no stock repurchases during the years ended December 31, 2021 and 2020. For the year ended December 31, 2019, we repurchased less than 0.1 million shares for $0.2 million at an average price of $14.06 per share. We currently have authorization to repurchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0000950170-22-002054:mdna:89]
Stock Option Exercises

[0000950170-22-002054:mdna:90]
To accommodate employee stock option exercises, we issued 0.4 million shares of treasury stock for $6.4 million during the year ended December 31, 2021 and less than 0.1 million shares of treasury stock for $0.5 million during the year ended December 31, 2019. There

[0000950170-22-002054:mdna:91]
were no stock option exercises during the year ended December 31, 2020. The increase in stock option exercises in 2021 is related to the increase in the Company's stock price.

[0000950170-22-002054:mdna:92]
Employee Pension Plan

[0000950170-22-002054:mdna:93]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations.

[0000950170-22-002054:mdna:94]
Our defined benefit plan assets consist of a balanced portfolio of equity funds, bond funds, real estate funds and managed futures. Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. Central to the policy are target allocation ranges by asset class, which is currently 50% for bond funds, 40% for equity funds and 10% cash, real estate and managed futures. The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies. The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations. At December 31, 2021, the estimated fair market value of our defined benefit pension plans assets increased to $32.7 million from $32.3 million at December 31, 2020.

[0000950170-22-002054:mdna:95]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations. The projected benefit obligation for our defined benefit pension plans was $44.2 million and $50.9 million as of December 31, 2021 and 2020, respectively.

[0000950170-22-002054:mdna:96]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Consolidated Statements of (Loss) Income. The components of net periodic pension cost and amounts recognized in other comprehensive (loss) income for the years ended December 31, 2021 and 2020 were ($5.0) million and $1.6 million, respectively.

[0000950170-22-002054:mdna:97]
Actuarial gains and losses are recorded in accumulated other comprehensive (loss) income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants. We estimate that $0.3 million will be amortized from accumulated other comprehensive (loss) income into net periodic pension cost in 2022 for the net actuarial loss. The net actuarial loss recognized in accumulated other comprehensive (loss) income as of December 31, 2021 and 2020 was $7.7 million and $13.5 million, respectively.

[0000950170-22-002054:mdna:98]
See Note 15 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-22-002054:mdna:99]
Off-Balance Sheet Arrangements

[0000950170-22-002054:mdna:100]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect our financial condition, revenue or expenses, results of operations, liquidity, capital expenditures, or the availability of, or requirements for, capital resources.

[0000950170-22-002054:mdna:101]
Cash Requirements

[0000950170-22-002054:mdna:102]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of December 31, 2021, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied.

[0000950170-22-002054:mdna:103]
| (In thousands) |  | Total |  |  | 2022 |  |  | 2023 |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | After 2026 |  |
| Pledged collateral(1) |  | $ | 15,000 |  |  | $ | 15,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Purchase obligations(2) |  |  | 361,626 |  |  |  | 340,770 |  |  |  | 15,859 |  |  |  | 4,997 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Operating lease obligations(3) |  |  | 5,084 |  |  |  | 1,767 |  |  |  | 1,419 |  |  |  | 1,188 |  |  |  | 710 |  |  |  | — |  |  |  | — |  |
| Business combination transaction costs(4) |  |  | 9,540 |  |  |  | 9,540 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Totals |  | $ | 391,250 |  |  | $ | 367,077 |  |  | $ | 17,278 |  |  | $ | 6,185 |  |  | $ | 710 |  |  | $ | — |  |  | $ | — |  |

[0000950170-22-002054:mdna:104]
(1) We are required to maintain a pledged collateral amount related to a letter of credit agreement with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.3 million as of December 31, 2021, of which $0.2 million is included in restricted cash and $18.1 million is included in long-term investments on the Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of December 31, 2021, the Company was in compliance with all contractual requirements under the letter of credit.

[0000950170-22-002054:mdna:105]
(2) We have purchase obligations related to open purchase orders to our contract manufacturers, ODMs, component suppliers, service partners and other vendors, including those assisting with the implementation of our new ERP system. The settlement of our purchase obligations will occur at various dates beginning in 2022 and going through 2024.

[0000950170-22-002054:mdna:106]
(3) We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Our operating leases had remaining lease terms of one month to 44 months as of December 31, 2021, The remaining future minimum rental payments under non-cancelable operating leases, including renewals determined to be reasonably assured, with original maturities of greater than 12 months totaled $5.1 million as of December 31, 2021. See Note 9 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-22-002054:mdna:107]
(4) Under the Business Combination Agreement, the Company will bear the transaction costs of the Business Combination attributable to Acorn HoldCo and the Company. For additional information on the Business Combination, see Note 3 of Notes to Consolidated Financial Statements included in Part II, Item 8 and Part I, Item 1 of this report.

[0000950170-22-002054:mdna:108]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been applied to these commitments. We are uncertain as to when the additional $0.1 million commitment will be applied.

[0000950170-22-002054:mdna:109]
Certain contracts, customers and/or jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2021, we had commitments related to these bonds totaling $22.9 million, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default in our performance under each contract, the probability of which we believe is remote.

[0000950170-22-002054:mdna:110]
We also have obligations related to uncertain income tax positions that have uncertainty as to when the related expense will be recognized. See Note 14 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-22-002054:mdna:111]
On November 2, 2021, the Company renewed its Revolving Credit Agreement with Cadence Bank, N.A., as lender. See Liquidity and Capital Resources – Liquidity for further information.

[0000950170-22-002054:mdna:112]
Critical Accounting Policies and Estimates

[0000950170-22-002054:mdna:113]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part II, Item 8 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000950170-22-002054:mdna:114]
55

[0000950170-22-002054:mdna:115]
Revenue

[0000950170-22-002054:mdna:116]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. Review of contracts with customers, for both direct customers and distributors, are performed and assessed for principal versus agent considerations to determine primary responsibility for delivery of performance obligation, presumed inventory risk, and discretion in establishing pricing, when applicable. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost which we have elected to account for as a cost of fulfilling the related contract is included in cost of revenue. Revenue, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract, if material, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0000950170-22-002054:mdna:117]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0000950170-22-002054:mdna:118]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales.

[0000950170-22-002054:mdna:119]
Hardware and Software Revenue

[0000950170-22-002054:mdna:120]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenue from software license sales is recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects.

[0000950170-22-002054:mdna:121]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services.

[0000950170-22-002054:mdna:122]
Services & Support Segment – Includes a complete portfolio of maintenance, network implementation and solutions integration and managed services, including hosted cloud services and subscription services which complement our Network Solutions segment.

[0000950170-22-002054:mdna:123]
Maintenance Revenue

[0000950170-22-002054:mdna:124]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenue, when applicable, is recorded in unearned revenue and non-current unearned revenue. The total balance of our unearned revenue was $27.0 million and $21.0 million as of December 30, 2021 and December 31, 2020, respectively.

[0000950170-22-002054:mdna:125]
Network Implementation Revenue

[0000950170-22-002054:mdna:126]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0000950170-22-002054:mdna:127]
Inventory

[0000950170-22-002054:mdna:128]
We carry our inventory at the lower of cost and net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor, and manufacturing overhead are used to value inventory and are updated at least quarterly. Most variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. If actual trends and market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $44.6 million and $39.6 million at December 31, 2021 and 2020, respectively. Inventory disposals charged against the reserve were $1.0 million and $6.0 million for the years ended December 31, 2021 and December 31, 2020, respectively.

[0000950170-22-002054:mdna:129]
Stock-Based Compensation

[0000950170-22-002054:mdna:130]
For purposes of determining the estimated fair value of market-based PSU awards on the date of grant, the Monte Carlo Simulation valuation method is used. These PSUs are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of performance-based PSUs, RSUs and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. Compensation expense related to unvested performance-based PSUs is recognized over the requisite service period of two to three years as the achievement of the performance obligation becomes probable. For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable, single measure of the fair value of our stock option awards. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. As of December 31, 2021, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $17.5 million.

[0000950170-22-002054:mdna:131]
Goodwill

[0000950170-22-002054:mdna:132]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We qualitatively assess the carrying value of goodwill each reporting period for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Based on our assessment of certain qualitative factors such as macro-economic conditions, industry and market considerations, costs factors and overall financial performance, management concluded that the fair value of the goodwill was more likely than not greater than its carrying amount as of December 31, 2021. No impairment charges on goodwill were recognized during the years ended December 31, 2021 and December 31, 2020. The balance of our goodwill was $7.0 million as of December 31, 2021 and December 31, 2020.

[0000950170-22-002054:mdna:133]
Income Taxes

[0000950170-22-002054:mdna:134]
We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. We continually review the adequacy of our valuation allowance and recognize the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes. Due to a decrease in revenue and profitability for 2019, and all other positive and negative objective evidence considered as part of our analysis, our ability to consider other subjective evidence such as projections for future growth is limited when evaluating whether our deferred tax assets will be realized. As such, the Company was and is no longer able to conclude that it is more likely than not that our domestic deferred tax assets will be realized and a valuation allowance against our domestic deferred tax assets was established in 2019. However, the amount of the deferred tax assets considered realizable could be adjusted in future periods in the event sufficient evidence is present to support a conclusion that it is more likely than not that all or a portion of our domestic deferred tax assets will be realized.

[0000950170-22-002054:mdna:135]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0000950170-22-002054:mdna:136]
Liability for Warranty

[0000950170-22-002054:mdna:137]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and an estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $5.4 million and $7.1 million at December 31, 2021 and 2020, respectively. These liabilities are included in accrued expenses and other liabilities in the accompanying Consolidated Balance Sheets.

[0000950170-22-002054:mdna:138]
Pension Benefit Plan Obligations

[0000950170-22-002054:mdna:139]
Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $11.4 million and $18.7 million at December 31, 2021 and December 31, 2020, respectively. This liability is included in pension liability in the accompanying Consolidated Balance Sheets.

[0000950170-22-002054:mdna:140]
Recently Issued Accounting Pronouncements

[0000950170-22-002054:mdna:141]
For a discussion of recently issued accounting pronouncements, see Note 1 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-22-002054:mdna:142]
Subsequent Events

[0000950170-22-002054:mdna:143]
On February 2, 2022, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record at the close of business on February 17, 2022. The dividends will be paid on March 3, 2022 in the aggregate amount of approximately $4.4 million.

[0000950170-22-002054:mdna:144]
On January 6, 2022, the Company's stockholders approved the Business Combination by an overwhelming majority. On January 26, 2022, the ADVA shareholder tender offer acceptance period ended, with the required minimum acceptance threshold having been met. According to the rules of the German Securities Acquisition and Takeover Act, ADVA shareholders who did not tender their shares during the initial acceptance period could do so during a two-week additional acceptance period that began on February 1, 2022 and ended February 14, 2022. This resulted in the acceptance of the Exchange Offer by approximately 66% of all shares of ADVA entitled to voting rights existing as of November 30, 2021. On January 24, 2022, CFIUS completed its review of the Business Combination and determined that the transaction was not a “covered transaction” subject to CFIUS’ jurisdiction, satisfying the condition of the Business Combination Agreement related to CFIUS notification. On February 16, 2022, the U.K. Secretary of State for Business, Energy and Industrial Strategy completed its review of the Business Combination and determined that the Secretary of State will be taking no further action under NS&I Act, satisfying the condition of the Business Combination Agreement related to NS&I Act approval. For additional information on the Business Combination, see Note 3 of Notes to Consolidated Financial Statements included in Part II, Item 8 and Part I, Item 1 of this report.
