# ADTN note change history — 0001564590-21-042027 → 0000950170-21-003219


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-11-05):
[0000950170-21-003219:note_history:1]
Business Combination Agreement

- added (2021-11-05):
[0000950170-21-003219:note_history:2]
On August 30, 2021, the Company, and ADVA Optical Networking SE, a European stock corporation incorporated under the laws of the European Union and Germany (“ADVA”), entered into a business combination agreement (the “Business Combination Agreement”), pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, Acorn HoldCo, Inc. (the "surviving corporation"), a Delaware corporation and currently a wholly-owned direct subsidiary of the Company.

- added (2021-11-05):
[0000950170-21-003219:note_history:3]
Under the terms of the Business Combination Agreement, Acorn MergeCo, Inc., a newly formed Delaware corporation and wholly-owned direct subsidiary of Acorn HoldCo (“Merger Sub”), will merge with and into ADTRAN, with ADTRAN surviving the merger (the “Merger”) as a wholly-owned direct subsidiary of Acorn HoldCo. Pursuant to the Merger, each outstanding share of common stock of the Company will be converted into the right to receive one share of common stock of Acorn HoldCo. Acorn HoldCo will also make a public exchange offer to exchange each issued and outstanding no-par value bearer share of ADVA, pursuant to which each ADVA share tendered and accepted for exchange will be exchanged for 0.8244 shares of common stock of Acorn HoldCo (the “Exchange Offer”, and together with the Merger, the “Business Combination”). Upon completion of the Business Combination, and assuming that all of the outstanding ADVA shares are exchanged in the Exchange Offer, former ADTRAN stockholders and former ADVA shareholders will own approximately 54% and 46%, respectively, of the outstanding Acorn HoldCo shares.

- added (2021-11-05):
[0000950170-21-003219:note_history:4]
The Business Combination Agreement was unanimously approved by the Board of Directors of the Company and by the supervisory board and management board of ADVA. The Company anticipates consummation of the Business Combination during mid-2022, subject to customary closing conditions as well as regulatory and shareholder approvals.

- added (2021-11-05):
[0000950170-21-003219:note_history:5]
Acorn HoldCo has entered into an irrevocable undertaking agreement (the “Irrevocable Undertaking”) with EGORA Holding GmbH and Egora Investments GmbH (collectively, the “Supporting Shareholders”) to validly accept the public exchange offer with respect to 7,000,000 shares held by them, representing 13.7% of the share capital of ADVA. The Irrevocable Undertaking includes other customary provisions, including certain restrictions on the Supporting Shareholders from disposing of the relevant shares.

- added (2021-11-05):
[0000950170-21-003219:note_history:6]
Additional information about the Business Combination Agreement and proposed Business Combination is set forth in the Company’s filings with the SEC, as well as in the registration statement on Form S-4 that Acorn HoldCo filed with the SEC, which has not yet become effective.

- changed (2021-11-05):
[0000950170-21-003219:note_history:7]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2021 and December 31, 2020, we had commitments related to these bonds totaling $20.9 million and $15.2 million, respectively, which expire at various dates through August 2024. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2021-08-06, similarity 0.745):
[0001564590-21-042027:note_history:7]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2021 and December 31, 2020, we had commitments related to these bonds totaling $21.2 million and $15.2 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2021-11-05):
[0000950170-21-003219:note_history:8]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.4 million as of September 30, 2021, of which $0.1 million is included in restricted cash and $18.3 million is included in long-term investments on the Condensed Consolidated Balance Sheets. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the
  (was, 2021-08-06, similarity 0.9341):
[0001564590-21-042027:note_history:8]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.2 million as of June 30, 2021, of which less than $0.1 million is included in restricted cash and $18.2 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of June 30, 2021, the Company was in compliance with all contractual requirements under the letter of credit.

- added (2021-11-05):
[0000950170-21-003219:note_history:9]
customer contract have been met. As of September 30, 2021, the Company was in compliance with all contractual requirements under the letter of credit.

- changed (2021-11-05):
[0000950170-21-003219:note_history:10]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of September 30, 2021.
  (was, 2021-08-06, similarity 0.9611):
[0001564590-21-042027:note_history:10]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of June 30, 2021.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2021-11-05):
[0000950170-21-003219:note_history:11]
The change in the unrecognized income tax benefits for the nine months ended September 30, 2021 and year ended December 31, 2020, is reconciled below:

- added (2021-11-05):
[0000950170-21-003219:note_history:12]
| (In thousands) |  | For the Nine Months Ended September 30, 2021 |  |  | For the Year Ended December 31, 2020 |  |
| Balance at beginning of period |  | $ | 1,078 |  |  | $ | 1,487 |  |
| Increases for tax position related to: |  |  |  |  |  |  |
| Prior years |  |  | 17,025 |  |  |  | 4 |  |
| Current year |  |  | 102 |  |  |  | 165 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |
| Prior years |  |  | (27 | ) |  |  | — |  |
| Expiration of applicable statute of limitations |  |  | — |  |  |  | (578 | ) |
| Balance at end of period |  | $ | 18,178 |  |  | $ | 1,078 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000950170-21-003219:note_history:13]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus, including the Delta variant) as well as supply chain constraints as of September 30, 2021 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for expected credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints, could result in further impacts to our consolidated financial statements in future reporting periods.
  (was, 2021-08-06, similarity 0.7511):
[0001564590-21-042027:note_history:13]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus, including the Delta variant) as of June 30, 2021 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for expected credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the six months ended June 30, 2021 resulting from these assessments, future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

- removed (2021-11-05):
[0001564590-21-042027:note_history:14]
There are currently no recent accounting pronouncements that have not yet been adopted and that would have a material effect, once adopted, on the condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000950170-21-003219:note_history:15]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company had not made any draws under the Revolving Credit Agreement as of September 30, 2021.
  (was, 2021-08-06, similarity 0.9951):
[0001564590-21-042027:note_history:15]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company had not made any draws under the Revolving Credit Agreement as of June 30, 2021.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000950170-21-003219:note_history:16]
|  |  | As of September 30, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 13,381 |  |  | $ | 39 |  |  | $ | (6 | ) |  | $ | 13,414 |  |
| Municipal fixed-rate bonds |  |  | 2,236 |  |  |  | 13 |  |  |  | (1 | ) |  |  | 2,248 |  |
| Asset-backed bonds |  |  | 3,497 |  |  |  | 17 |  |  |  | (1 | ) |  |  | 3,513 |  |
| Mortgage/Agency-backed bonds |  |  | 9,194 |  |  |  | 35 |  |  |  | (17 | ) |  |  | 9,212 |  |
| U.S. government bonds |  |  | 16,031 |  |  |  | 34 |  |  |  | (13 | ) |  |  | 16,052 |  |
| Foreign government bonds |  |  | 544 |  |  |  | 1 |  |  |  | (2 | ) |  |  | 543 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 45,416 |  |  | $ | 139 |  |  | $ | (40 | ) |  | $ | 45,515 |  |
  (was, 2021-08-06, similarity 0.9912):
[0001564590-21-042027:note_history:16]
|  |  | As of June 30, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 14,954 |  |  | $ | 53 |  |  | $ | (6 | ) |  | $ | 15,001 |  |
| Municipal fixed-rate bonds |  |  | 2,523 |  |  |  | 15 |  |  |  | (1 | ) |  |  | 2,537 |  |
| Asset-backed bonds |  |  | 3,983 |  |  |  | 20 |  |  |  | (2 | ) |  |  | 4,001 |  |
| Mortgage/Agency-backed bonds |  |  | 11,004 |  |  |  | 50 |  |  |  | (15 | ) |  |  | 11,039 |  |
| U.S. government bonds |  |  | 10,777 |  |  |  | 51 |  |  |  | (5 | ) |  |  | 10,823 |  |
| Foreign government bonds |  |  | 546 |  |  |  | 1 |  |  |  | (1 | ) |  |  | 546 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,320 |  |  | $ | 190 |  |  | $ | (30 | ) |  | $ | 44,480 |  |

- changed (2021-11-05):
[0000950170-21-003219:note_history:17]
|  |  | As of September 30, 2021 |  |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Other |  |
| Less than one year |  | $ | 275 |  |  | $ | 652 |  |  | $ | — |  |  | $ | 638 |  |  | $ | 2,593 |  |  | $ | — |  |  | $ | 533 |  |
| One to two years |  |  | 4,494 |  |  |  | 534 |  |  |  | — |  |  |  | 1,005 |  |  |  | 4,021 |  |  |  | 246 |  |  |  | — |  |
| Two to three years |  |  | 6,616 |  |  |  | 761 |  |  |  | 93 |  |  |  | 1,102 |  |  |  | 5,810 |  |  |  | 297 |  |  |  | — |  |
| Three to five years |  |  | 2,029 |  |  |  | 301 |  |  |  | 1,573 |  |  |  | 235 |  |  |  | 3,628 |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 785 |  |  |  | 1,322 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,062 |  |  |  | 4,910 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 13,414 |  |  | $ | 2,248 |  |  | $ | 3,513 |  |  | $ | 9,212 |  |  | $ | 16,052 |  |  | $ | 543 |  |  | $ | 533 |  |
  (was, 2021-08-06, similarity 0.9894):
[0001564590-21-042027:note_history:17]
|  |  | As of June 30, 2021 |  |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage/ Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Other |  |
| Less than one year |  | $ | 436 |  |  | $ | 529 |  |  | $ | 1 |  |  | $ | 254 |  |  | $ | 735 |  |  | $ | — |  |  | $ | 533 |  |
| One to two years |  |  | 4,575 |  |  |  | 496 |  |  |  | — |  |  |  | 1,865 |  |  |  | 7,240 |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 7,518 |  |  |  | 1,103 |  |  |  | 50 |  |  |  | 1,199 |  |  |  | 1,188 |  |  |  | 546 |  |  |  | — |  |
| Three to five years |  |  | 2,472 |  |  |  | 409 |  |  |  | 1,749 |  |  |  | 165 |  |  |  | 1,660 |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 866 |  |  |  | 2,213 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,335 |  |  |  | 5,343 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 15,001 |  |  | $ | 2,537 |  |  | $ | 4,001 |  |  | $ | 11,039 |  |  | $ | 10,823 |  |  | $ | 546 |  |  | $ | 533 |  |

- added (2021-11-05):
[0000950170-21-003219:note_history:18]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Gross realized gain on debt securities |  | $ | 22 |  |  | $ | 70 |  |  | $ | 206 |  |  | $ | 303 |  |
| Gross realized loss on debt securities |  |  | (17 | ) |  |  | (6 | ) |  |  | (53 | ) |  |  | (45 | ) |
| Total gain recognized, net |  | $ | 5 |  |  | $ | 64 |  |  | $ | 153 |  |  | $ | 258 |  |

- added (2021-11-05):
[0000950170-21-003219:note_history:19]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income (Loss). No allowance for credit loss was recorded for the nine months ended September 30, 2021 and 2020 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the nine months ended September 30, 2021.

- changed (2021-11-05):
[0000950170-21-003219:note_history:20]
In March 2019, an outstanding note receivable of $4.3 million owed to the Company was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment. The Company elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. During the year ended December 31, 2020, impairment charges totaling $2.6 million were recorded related to this equity investment, which was included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $0.8 million as of September 30, 2021 and December 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of September 30, 2021 and December 31, 2020. No impairment charge was recognized related to the note receivable as it is a secured loan.
  (was, 2021-08-06, similarity 0.7268):
[0001564590-21-042027:note_history:20]
In March 2019, an outstanding note receivable of $4.3 million owed to the Company was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment. The Company elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. During the year ended December 31, 2020, impairment charges totaling $2.6 million were recorded related to this equity investment, which was included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result the carrying value of this investment was $0.8 million as of June 30, 2021 and December 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of June 30, 2021 and December 31, 2020. No impairment charge was recognized related to the note receivable as it is a secured loan.

- changed (2021-11-05):
[0000950170-21-003219:note_history:21]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Realized gain (loss) on equity securities sold |  | $ | — |  |  | $ | 623 |  |  | $ | (55 | ) |  | $ | (1,485 | ) |
| Unrealized (loss) gain on equity securities held |  |  | (68 | ) |  |  | 2,157 |  |  |  | 2,844 |  |  |  | 3,046 |  |
| Total gain (loss) recognized, net |  | $ | (68 | ) |  | $ | 2,780 |  |  | $ | 2,789 |  |  | $ | 1,561 |  |
  (was, 2021-08-06, similarity 0.8066):
[0001564590-21-042027:note_history:21]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Realized gain (loss) on equity securities sold |  | $ | (79 | ) |  | $ | 328 |  |  | $ | (55 | ) |  | $ | (2,108 | ) |
| Unrealized gain on equity securities held |  |  | 2,011 |  |  |  | 9,353 |  |  |  | 2,912 |  |  |  | 889 |  |
| Total gain (loss) recognized, net |  | $ | 1,932 |  |  | $ | 9,681 |  |  | $ | 2,857 |  |  | $ | (1,219 | ) |

- changed (2021-11-05):
[0000950170-21-003219:note_history:22]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income (Loss). U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:
  (was, 2021-08-06, similarity 0.6652):
[0001564590-21-042027:note_history:22]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

- changed (2021-11-05):
[0000950170-21-003219:note_history:23]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;
  (was, 2021-08-06, similarity 0.9922):
[0001564590-21-042027:note_history:23]
• Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

- changed (2021-11-05):
[0000950170-21-003219:note_history:24]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;
  (was, 2021-08-06, similarity 0.9944):
[0001564590-21-042027:note_history:24]
• Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

- changed (2021-11-05):
[0000950170-21-003219:note_history:25]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.
  (was, 2021-08-06, similarity 0.9961):
[0001564590-21-042027:note_history:25]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

- changed (2021-11-05):
[0000950170-21-003219:note_history:26]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 532 |  |  | $ | 532 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 400 |  |  |  | — |  |  |  | 400 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,414 |  |  |  | — |  |  |  | 13,414 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,248 |  |  |  | — |  |  |  | 2,248 |  |  |  | — |  |
| Asset-backed bonds |  |  | 3,513 |  |  |  | — |  |  |  | 3,513 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 9,212 |  |  |  | — |  |  |  | 9,212 |  |  |  | — |  |
| U.S. government bonds |  |  | 16,052 |  |  |  | 16,052 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 543 |  |  |  | — |  |  |  | 543 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 12,144 |  |  |  | 12,144 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 25,733 |  |  |  | 25,733 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 85,724 |  |  | $ | 55,861 |  |  | $ | 29,330 |  |  | $ | 533 |  |
  (was, 2021-08-06, similarity 0.8144):
[0001564590-21-042027:note_history:26]
|  |  |  |  |  |  | Fair Value Measurements as of June 30, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 615 |  |  | $ | 615 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 1,250 |  |  |  | — |  |  |  | 1,250 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 15,001 |  |  |  | — |  |  |  | 15,001 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,537 |  |  |  | — |  |  |  | 2,537 |  |  |  | — |  |
| Asset-backed bonds |  |  | 4,001 |  |  |  | — |  |  |  | 4,001 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,039 |  |  |  | — |  |  |  | 11,039 |  |  |  | — |  |
| U.S. government bonds |  |  | 10,823 |  |  |  | 10,823 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 546 |  |  |  | — |  |  |  | 546 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 12,057 |  |  |  | 12,057 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 25,917 |  |  |  | 25,917 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 85,719 |  |  | $ | 50,812 |  |  | $ | 34,374 |  |  | $ | 533 |  |

- changed (2021-11-05):
[0000950170-21-003219:note_history:27]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 497 |  |  | $ | 497 |  |  | $ | — |  |  | $ | — |  |
| U.S. government bonds |  |  | 350 |  |  |  | 350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,885 |  |  |  | — |  |  |  | 11,885 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,884 |  |  |  | — |  |  |  | 2,884 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,708 |  |  |  | — |  |  |  | 6,708 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,644 |  |  |  | — |  |  |  | 11,644 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,875 |  |  |  | 9,875 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,337 |  |  |  | — |  |  |  | 1,337 |  |  |  | — |  |
| Commercial paper |  |  | 250 |  |  |  | — |  |  |  | 250 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 10,963 |  |  |  | 10,963 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 23,891 |  |  |  | 23,891 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,217 |  |  | $ | 46,976 |  |  | $ | 34,708 |  |  | $ | 533 |  |
  (was, 2021-08-06, similarity 0.9884):
[0001564590-21-042027:note_history:27]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 497 |  |  | $ | 497 |  |  | $ | — |  |  | $ | — |  |
| U.S. government bonds |  |  | 350 |  |  |  | 350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,885 |  |  |  | — |  |  |  | 11,885 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,884 |  |  |  | — |  |  |  | 2,884 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,708 |  |  |  | — |  |  |  | 6,708 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,644 |  |  |  | — |  |  |  | 11,644 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,875 |  |  |  | 9,875 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,337 |  |  |  | — |  |  |  | 1,337 |  |  |  | — |  |
| Commercial paper |  |  | 250 |  |  |  | — |  |  |  | 250 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 10,963 |  |  |  | 10,963 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 23,891 |  |  |  | 23,891 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,217 |  |  | $ | 46,976 |  |  | $ | 34,708 |  |  | $ | 533 |  |

- removed (2021-11-05):
[0001564590-21-042027:note_history:28]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Gross realized gain on debt securities |  | $ | 97 |  |  | $ | 190 |  |  | $ | 184 |  |  | $ | 233 |  |
| Gross realized loss on debt securities |  |  | (20 | ) |  |  | (19 | ) |  |  | (36 | ) |  |  | (39 | ) |
| Total gain recognized, net |  | $ | 77 |  |  | $ | 171 |  |  | $ | 148 |  |  | $ | 194 |  |

- removed (2021-11-05):
[0001564590-21-042027:note_history:29]
No allowance for credit loss was recorded for the six months ended June 30, 2021 or 2020 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the six months ended June 30, 2021.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000950170-21-003219:note_history:30]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 77,104 |  |  | $ | 12,069 |  |  | $ | 89,173 |  |  | $ | 71,919 |  |  | $ | 13,504 |  |  | $ | 85,423 |  |
| Subscriber Solutions & Experience |  |  | 42,093 |  |  |  | 2,819 |  |  |  | 44,912 |  |  |  | 40,843 |  |  |  | 2,282 |  |  |  | 43,125 |  |
| Traditional & Other Products |  |  | 1,570 |  |  |  | 2,426 |  |  |  | 3,996 |  |  |  | 2,467 |  |  |  | 2,128 |  |  |  | 4,595 |  |
| Total |  | $ | 120,767 |  |  | $ | 17,314 |  |  | $ | 138,081 |  |  | $ | 115,229 |  |  | $ | 17,914 |  |  | $ | 133,143 |  |
  (was, 2021-08-06, similarity 0.9585):
[0001564590-21-042027:note_history:30]
|  |  | Three Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 78,307 |  |  | $ | 12,657 |  |  | $ | 90,964 |  |  | $ | 69,721 |  |  | $ | 13,055 |  |  | $ | 82,776 |  |
| Subscriber Solutions & Experience |  |  | 45,097 |  |  |  | 2,713 |  |  |  | 47,810 |  |  |  | 38,081 |  |  |  | 2,312 |  |  |  | 40,393 |  |
| Traditional & Other Products |  |  | 2,045 |  |  |  | 2,413 |  |  |  | 4,458 |  |  |  | 3,521 |  |  |  | 2,025 |  |  |  | 5,546 |  |
| Total |  | $ | 125,449 |  |  | $ | 17,783 |  |  | $ | 143,232 |  |  | $ | 111,323 |  |  | $ | 17,392 |  |  | $ | 128,715 |  |

- changed (2021-11-05):
[0000950170-21-003219:note_history:31]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 215,464 |  |  | $ | 33,747 |  |  | $ | 249,211 |  |  | $ | 194,695 |  |  | $ | 39,470 |  |  | $ | 234,165 |  |
| Subscriber Solutions & Experience |  |  | 139,459 |  |  |  | 7,832 |  |  |  | 147,291 |  |  |  | 118,907 |  |  |  | 6,790 |  |  |  | 125,697 |  |
| Traditional & Other Products |  |  | 5,102 |  |  |  | 7,242 |  |  |  | 12,344 |  |  |  | 10,322 |  |  |  | 6,197 |  |  |  | 16,519 |  |
| Total |  | $ | 360,025 |  |  | $ | 48,821 |  |  | $ | 408,846 |  |  | $ | 323,924 |  |  | $ | 52,457 |  |  | $ | 376,381 |  |
  (was, 2021-08-06, similarity 0.9523):
[0001564590-21-042027:note_history:31]
|  |  | Six Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 138,360 |  |  | $ | 21,678 |  |  | $ | 160,038 |  |  | $ | 122,776 |  |  | $ | 25,966 |  |  | $ | 148,742 |  |
| Subscriber Solutions & Experience |  |  | 97,366 |  |  |  | 5,013 |  |  |  | 102,379 |  |  |  | 78,064 |  |  |  | 4,508 |  |  |  | 82,572 |  |
| Traditional & Other Products |  |  | 3,532 |  |  |  | 4,816 |  |  |  | 8,348 |  |  |  | 7,855 |  |  |  | 4,069 |  |  |  | 11,924 |  |
| Total |  | $ | 239,258 |  |  | $ | 31,507 |  |  | $ | 270,765 |  |  | $ | 208,695 |  |  | $ | 34,543 |  |  | $ | 243,238 |  |

- changed (2021-11-05):
[0000950170-21-003219:note_history:32]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Access & Aggregation |  | $ | 89,173 |  |  | $ | 85,423 |  |  | $ | 249,211 |  |  | $ | 234,165 |  |
| Subscriber Solutions & Experience |  |  | 44,912 |  |  |  | 43,125 |  |  |  | 147,291 |  |  |  | 125,697 |  |
| Traditional & Other Products |  |  | 3,996 |  |  |  | 4,595 |  |  |  | 12,344 |  |  |  | 16,519 |  |
| Total |  | $ | 138,081 |  |  | $ | 133,143 |  |  | $ | 408,846 |  |  | $ | 376,381 |  |
  (was, 2021-08-06, similarity 0.9392):
[0001564590-21-042027:note_history:32]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Access & Aggregation |  | $ | 90,964 |  |  | $ | 82,776 |  |  | $ | 160,038 |  |  | $ | 148,742 |  |
| Subscriber Solutions & Experience |  |  | 47,810 |  |  |  | 40,393 |  |  |  | 102,379 |  |  |  | 82,572 |  |
| Traditional & Other Products |  |  | 4,458 |  |  |  | 5,546 |  |  |  | 8,348 |  |  |  | 11,924 |  |
| Total |  | $ | 143,232 |  |  | $ | 128,715 |  |  | $ | 270,765 |  |  | $ | 243,238 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-05):
[0000950170-21-003219:note_history:33]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 77,104 |  |  | $ | 12,069 |  |  | $ | 89,173 |  |  | $ | 71,919 |  |  | $ | 13,504 |  |  | $ | 85,423 |  |
| Subscriber Solutions & Experience |  |  | 42,093 |  |  |  | 2,819 |  |  |  | 44,912 |  |  |  | 40,843 |  |  |  | 2,282 |  |  |  | 43,125 |  |
| Traditional & Other Products |  |  | 1,570 |  |  |  | 2,426 |  |  |  | 3,996 |  |  |  | 2,467 |  |  |  | 2,128 |  |  |  | 4,595 |  |
| Total |  | $ | 120,767 |  |  | $ | 17,314 |  |  | $ | 138,081 |  |  | $ | 115,229 |  |  | $ | 17,914 |  |  | $ | 133,143 |  |
  (was, 2021-08-06, similarity 0.9585):
[0001564590-21-042027:note_history:33]
|  |  | Three Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 78,307 |  |  | $ | 12,657 |  |  | $ | 90,964 |  |  | $ | 69,721 |  |  | $ | 13,055 |  |  | $ | 82,776 |  |
| Subscriber Solutions & Experience |  |  | 45,097 |  |  |  | 2,713 |  |  |  | 47,810 |  |  |  | 38,081 |  |  |  | 2,312 |  |  |  | 40,393 |  |
| Traditional & Other Products |  |  | 2,045 |  |  |  | 2,413 |  |  |  | 4,458 |  |  |  | 3,521 |  |  |  | 2,025 |  |  |  | 5,546 |  |
| Total |  | $ | 125,449 |  |  | $ | 17,783 |  |  | $ | 143,232 |  |  | $ | 111,323 |  |  | $ | 17,392 |  |  | $ | 128,715 |  |

- changed (2021-11-05):
[0000950170-21-003219:note_history:34]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 215,464 |  |  | $ | 33,747 |  |  | $ | 249,211 |  |  | $ | 194,695 |  |  | $ | 39,470 |  |  | $ | 234,165 |  |
| Subscriber Solutions & Experience |  |  | 139,459 |  |  |  | 7,832 |  |  |  | 147,291 |  |  |  | 118,907 |  |  |  | 6,790 |  |  |  | 125,697 |  |
| Traditional & Other Products |  |  | 5,102 |  |  |  | 7,242 |  |  |  | 12,344 |  |  |  | 10,322 |  |  |  | 6,197 |  |  |  | 16,519 |  |
| Total |  | $ | 360,025 |  |  | $ | 48,821 |  |  | $ | 408,846 |  |  | $ | 323,924 |  |  | $ | 52,457 |  |  | $ | 376,381 |  |
  (was, 2021-08-06, similarity 0.9523):
[0001564590-21-042027:note_history:34]
|  |  | Six Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 138,360 |  |  | $ | 21,678 |  |  | $ | 160,038 |  |  | $ | 122,776 |  |  | $ | 25,966 |  |  | $ | 148,742 |  |
| Subscriber Solutions & Experience |  |  | 97,366 |  |  |  | 5,013 |  |  |  | 102,379 |  |  |  | 78,064 |  |  |  | 4,508 |  |  |  | 82,572 |  |
| Traditional & Other Products |  |  | 3,532 |  |  |  | 4,816 |  |  |  | 8,348 |  |  |  | 7,855 |  |  |  | 4,069 |  |  |  | 11,924 |  |
| Total |  | $ | 239,258 |  |  | $ | 31,507 |  |  | $ | 270,765 |  |  | $ | 208,695 |  |  | $ | 34,543 |  |  | $ | 243,238 |  |

- added (2021-11-05):
[0000950170-21-003219:note_history:35]
Revenue allocated to remaining performance obligations represents contract revenue that has not yet been recognized for contracts with a duration of greater than one year. As of September 30, 2021, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $20.7 million and $17.7 million as of September 30, 2021 and December 31, 2020, respectively. The Company expects to recognize 64% of the $20.7 million as of September 30, 2021 over the next 12 months, with the remainder to be recognized thereafter.

- changed (2021-11-05):
[0000950170-21-003219:note_history:36]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2021 |  |  | December 31, 2020 |  |
| Accounts receivable, net |  | $ | 124,146 |  |  | $ | 98,827 |  |
| Contract assets(1) |  | $ | 999 |  |  | $ | 63 |  |
| Unearned revenue |  | $ | 16,394 |  |  | $ | 14,092 |  |
| Non-current unearned revenue |  | $ | 7,426 |  |  | $ | 6,888 |  |
  (was, 2021-08-06, similarity 0.9279):
[0001564590-21-042027:note_history:36]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2021 |  |  | December 31, 2020 |  |
| Accounts receivable, net |  | $ | 122,669 |  |  | $ | 98,827 |  |
| Contract assets(1) |  | $ | 1,036 |  |  | $ | 63 |  |
| Unearned revenue |  | $ | 15,889 |  |  | $ | 14,092 |  |
| Non-current unearned revenue |  | $ | 7,030 |  |  | $ | 6,888 |  |

- changed (2021-11-05):
[0000950170-21-003219:note_history:37]
(1)	Included in other receivables on the Condensed Consolidated Balance Sheets.
  (was, 2021-08-06, similarity 0.9518):
[0001564590-21-042027:note_history:37]
|  | (1) | Included in other receivables on the Condensed Consolidated Balance Sheets. |

- changed (2021-11-05):
[0000950170-21-003219:note_history:38]
Of the outstanding unearned revenue balances as of December 31, 2020, $2.0 million and $9.8 million were recognized as revenue during the three and nine months ended September 30, 2021, respectively.
  (was, 2021-08-06, similarity 0.9556):
[0001564590-21-042027:note_history:38]
Of the outstanding unearned revenue balances as of December 31, 2020 $2.9 million and $7.9 million were recognized as revenue during the three and six months ended June 30, 2021, respectively.

- removed (2021-11-05):
[0001564590-21-042027:note_history:39]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration of greater than one year. As of June 30, 2021, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $19.7 million and $17.7 million as of June 30, 2021 and December 31, 2020, respectively. The Company expects to recognize 64% of the $19.7 million as of June 30, 2021 over the next 12 months, with the remainder to be recognized thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-11-05):
[0000950170-21-003219:note_history:40]
On November 1, 2021, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 16, 2021. The payment date will be November 30, 2021 in the aggregate amount of approximately $4.4 million.

- added (2021-11-05):
[0000950170-21-003219:note_history:41]
On November 4, 2021, the Company entered into a loan modification agreement and amendment to loan documents to extend the maturity date of the Revolving Credit Agreement through November 3, 2022. See Item 5, Other Information, of this report for additional information regarding the loan modification agreement.

- removed (2021-11-05):
[0001564590-21-042027:note_history:42]
On August 4, 2021, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 19, 2021. The payment date will be September 2, 2021 in the aggregate amount of approximately $4.4 million.
