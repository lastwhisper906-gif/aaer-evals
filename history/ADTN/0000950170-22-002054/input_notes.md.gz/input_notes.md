# ADTN notes — 0000950170-22-002054


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-22-002054:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0000950170-22-002054:notes:2]
Portions of the Proxy Statement for the registrant's 2022 Annual Meeting of Stockholders are incorporated herein by reference in Part III to the extent described in Part III.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-22-002054:notes:3]
Note 1 – Nature of Business

[0000950170-22-002054:notes:4]
ADTRAN, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software and services focused on the broadband access market. Our vision is to enable a fully connected world where the power to communicate is available to everyone, everywhere. Our business approach, unmatched industry expertise and innovative solutions enable us to address almost any customer need. Our products and services are utilized by a diverse global customer base of network operators that range from those having regional or national reach and operating as telephone or cable television network operators to alternative network providers such as municipalities or utilities, as well as, managed service providers who serve small- and medium-sized businesses and distributed enterprises.

[0000950170-22-002054:notes:5]
Principles of Consolidation

[0000950170-22-002054:notes:6]
The accompanying Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the U.S. (“U.S. GAAP”) and include the financial position, results of operations, comprehensive (loss) income, changes in equity and cash flows of ADTRAN and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000950170-22-002054:notes:7]
Use of Estimates

[0000950170-22-002054:notes:8]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expenses during the reporting period. Significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenue and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability, fair value of investments, evaluation of other-than-temporary declines in the value of investments and our allowance for current expected credit losses. Actual amounts could differ significantly from these estimates.

[0000950170-22-002054:notes:9]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus, including the Omicron and Delta variants) as well as supply chain constraints as of December 31, 2021 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for expected credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints, could result in further impacts to our consolidated financial statements in future reporting periods.

[0000950170-22-002054:notes:10]
Correction of Immaterial Misstatements

[0000950170-22-002054:notes:11]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of revenue for the period. For the six and twelve months ended June 30, 2019 and December 31, 2019, respectively, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of revenue. Management determined that the correction of this misstatement was not material to any of its previously issued financial statements on both a quantitative and qualitative basis.

[0000950170-22-002054:notes:12]
During the first quarter of 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out-of-period adjustment in the three months ended March 31, 2020 and the twelve months ended December 31, 2020, by remeasuring the investment assets to their historical cost basis through the recording of a net investment gain of $1.5 million in the Consolidated Statement of (Loss) Income and then correcting the classification by decreasing the long-term investment balance at its remeasured cost basis of $2.8 million to treasury stock in the Consolidated 2020 Balance Sheet. Management has determined that this misstatement was not material to any of its previously issued financial statements and that correction of the misstatement was not material to the 2020 annual financial results on either a quantitative or qualitative basis.

[0000950170-22-002054:notes:13]
Summary of Significant Accounting Policies

[0000950170-22-002054:notes:14]
Cash and Cash Equivalents

[0000950170-22-002054:notes:15]
Cash and cash equivalents represent demand deposits, money market funds and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. As of December 31, 2021, $52.5 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions and determined the risk of material financial loss due to the exposure of such credit risk to be minimal.

[0000950170-22-002054:notes:16]
Restricted Cash

[0000950170-22-002054:notes:17]
Restricted cash consists of certain collateral which secures the Company’s performance obligation under a contract with a certain customer.

[0000950170-22-002054:notes:18]
Financial Instruments

[0000950170-22-002054:notes:19]
The carrying amounts reported in the Consolidated Balance Sheets for cash and cash equivalents, accounts receivable, and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments.

[0000950170-22-002054:notes:20]
Investments with contractual maturities beyond one year may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe we have the ability to quickly sell them to the remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. All income generated from these investments is recorded as interest income. We have not recorded any losses relating to variable rate demand notes.

[0000950170-22-002054:notes:21]
Long-term investments is comprised of deferred compensation plan assets, corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. and foreign government bonds, marketable equity securities and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Any changes in fair value are recognized in net investment gain (loss). Realized gains and losses on sales of debt securities are computed under the specific identification method and are included in other income (expense). See Note 6 for additional information.

[0000950170-22-002054:notes:22]
For financing receivables, the Company does not measure the allowance for credit losses for accrued interest receivables, as the  uncollectable accrued interest receivable is written off by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable).

[0000950170-22-002054:notes:23]
Accounts Receivable

[0000950170-22-002054:notes:24]
We record accounts receivable at amortized cost. Prior to establishing payment terms for a new customer, we evaluate the credit risk of the customer. Credit limits and payment terms established for new customers are re-evaluated periodically based on customer collection experience and other financial factors. As of December 31, 2021, single customers comprising more than 10% of our total accounts receivable balance included three customers, which accounted for 59.9% of our total accounts receivable. As of December 31, 2021, these three customers individually accounted for 35.8%, 12.1% and 12.0%, respectively, of our total accounts receivable. As of December 31, 2020, single customers comprising more than 10% of our total accounts receivable balance included three customers, which accounted for 41.5% of our total accounts receivable. As of December 31, 2020, these three customers individually accounted for 15.6%, 14.5% and 11.4%, respectively, of our total accounts receivable.

[0000950170-22-002054:notes:25]
On January 1, 2020, we adopted ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.

[0000950170-22-002054:notes:26]
Accounting Policy Under Topic 326

[0000950170-22-002054:notes:27]
We regularly review the need for an allowance for credit losses related to our outstanding accounts receivable balances using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition or credit rating by geographic location, as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. Based on this assessment, an allowance for credit losses would be recorded if the Company determined that, based on our historical write-offs, which have been immaterial, and such asset specific risks, there was risk in collectability of the full amount of any accounts receivable.

[0000950170-22-002054:notes:28]
Accounting Policy Prior to Adoption of Topic 326

[0000950170-22-002054:notes:29]
Prior to adoption of Topic 326 on January 1, 2020, we regularly reviewed the need to maintain an allowance for doubtful accounts and considered factors such as the age of accounts receivable balances, the current economic conditions that may affect a customer’s ability to pay, significant one-time events impacting these customers and our historical experience. If the financial condition of a customer deteriorated, resulting in an impairment of their ability to make payments, we may have been required to record an allowance for credit losses.

[0000950170-22-002054:notes:30]
Inventory

[0000950170-22-002054:notes:31]
Inventory is carried at the lower of cost and estimated net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory and are updated at least quarterly. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 7 for additional information.

[0000950170-22-002054:notes:32]
Property, Plant and Equipment

[0000950170-22-002054:notes:33]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. We depreciate building and land improvements from five to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years, and computer software from three to five years. Expenditures for repairs and maintenance are charged to expense as incurred. Major improvements that materially prolong the lives of the assets are capitalized. Gains and losses on the disposal of property, plant and equipment are recorded in operating loss. See Note 8 for additional information.

[0000950170-22-002054:notes:34]
Intangible Assets

[0000950170-22-002054:notes:35]
Purchased intangible assets with finite lives are carried at cost less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets, which is two to 14 years. See Note 11 for additional information.

[0000950170-22-002054:notes:36]
Impairment of Long-Lived Assets and Intangibles

[0000950170-22-002054:notes:37]
Long-lived assets used in operations and intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. An impairment loss would be recognized in the amount by which the recorded value of the asset exceeds the fair value of the asset, measured by the quoted market price of an asset or an estimate based on the best information available in the circumstances. During the year ended December 31, 2020, we recognized an impairment loss of less than $0.1 million related to the abandonment of certain information technology implementation projects for which we had previously capitalized expenses. There were no impairment losses for long-lived assets during the years ended December 31, 2021 and 2019, or for intangible assets recognized during the years ended December 31, 2021, 2020 or 2019.

[0000950170-22-002054:notes:38]
Goodwill

[0000950170-22-002054:notes:39]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We qualitatively assess the carrying value of goodwill each reporting period for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. During the fourth quarter of 2021, the Company completed its annual goodwill impairment test. Based on our assessment of certain qualitative factors such as macro-economic conditions, industry and market considerations, costs factors and overall financial performance, management concluded that the fair value of the goodwill was more likely than not greater than its carrying amount as of December 31, 2021. No impairment charges related to goodwill were recognized during the years ended December 31, 2021, 2020 and 2019.

[0000950170-22-002054:notes:40]
Other Non-Current Assets

[0000950170-22-002054:notes:41]
Implementation costs incurred for hosting arrangements that are related to service contracts are capitalized and amortized over the term of the arrangement. Capitalized implementation costs totaled $21.0 million and $13.5 million as of December 31, 2021 and 2020, respectively and are included in other non-current assets on the Consolidated Balance Sheets. We depreciate capitalized implementation costs on a straight-line basis over ten years. Amortization expense was $1.0 million for the year ended December 31, 2021, which is recorded almost entirely in selling, general and administrative expenses in the Consolidated Statements of (Loss) Income. No amortization expense was recognized for the years ended December 31, 2020 and 2019.

[0000950170-22-002054:notes:42]
Liability for Warranty

[0000950170-22-002054:notes:43]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $5.4 million and $7.1 million as of December 31, 2021 and 2020, respectively. These liabilities are included in accrued expenses and other liabilities in the accompanying Consolidated Balance Sheets.

[0000950170-22-002054:notes:44]
A summary of warranty expense and write-off activity for the years ended December 31, 2021, 2020 and 2019 is as follows:

[0000950170-22-002054:notes:45]
|  |  | Year Ended December 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 7,146 |  |  | $ | 8,394 |  |  | $ | 8,623 |  |
| Plus: Amounts charged to cost and expenses |  |  | 855 |  |  |  | 1,538 |  |  |  | 4,569 |  |
| Less: Deductions |  |  | (2,598 | ) |  |  | (2,786 | ) |  |  | (4,798 | ) |
| Balance at end of period |  | $ | 5,403 |  |  | $ | 7,146 |  |  | $ | 8,394 |  |

[0000950170-22-002054:notes:46]
Pension Benefit Plan Obligations

[0000950170-22-002054:notes:47]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $11.4 million and $18.7 million as of December 31, 2021 and 2020, respectively.

[0000950170-22-002054:notes:48]
Stock-Based Compensation

[0000950170-22-002054:notes:49]
We have two stock incentive plans from which stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock are available for grant to employees and directors. Costs related to these awards are recognized over their vesting periods.

[0000950170-22-002054:notes:50]
Stock-based compensation expense recognized for the years ended December 31, 2021, 2020 and 2019 was approximately $7.5 million, $6.8 million, and $7.0 million, respectively. See Note 5 for additional information.

[0000950170-22-002054:notes:51]
Research and Development Costs

[0000950170-22-002054:notes:52]
Research and development costs include compensation for engineers and support personnel, contracted services, depreciation and material costs associated with new product development, enhancement of current products and product cost reductions. We continually evaluate new product opportunities and engage in intensive research for product and software development efforts. Research and

[0000950170-22-002054:notes:53]
development costs totaled $108.7 million, $113.3 million and $126.2 million for the years ended December 31, 2021, 2020 and 2019, respectively.

[0000950170-22-002054:notes:54]
Other Comprehensive (Loss) Income

[0000950170-22-002054:notes:55]
The following table presents changes in accumulated other comprehensive (loss) income, net of tax, by components of accumulated other comprehensive (loss) income for the years ended December 31, 2021, 2020 and 2019:

[0000950170-22-002054:notes:56]
| (In thousands) |  | UnrealizedGains (Losses)on Available-for-SaleSecurities |  |  | DefinedBenefit PlanAdjustments |  |  | ForeignCurrencyAdjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| Balance as of December 31, 2018 |  | $ | (563 | ) |  | $ | (8,041 | ) |  | $ | (5,812 | ) |  | $ | — |  |  | $ | (14,416 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | 573 |  |  |  | (1,717 | ) |  |  | (1,480 | ) |  |  | — |  |  |  | (2,624 | ) |
| Amounts reclassified to retained earnings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |  |  | 385 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (294 | ) |  |  | 532 |  |  |  | — |  |  |  | — |  |  |  | 238 |  |
| Balance as of December 31, 2019 |  |  | (284 | ) |  |  | (9,226 | ) |  |  | (7,292 | ) |  |  | 385 |  |  |  | (16,417 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | 749 |  |  |  | (1,231 | ) |  |  | 4,857 |  |  |  | — |  |  |  | 4,375 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (433 | ) |  |  | 836 |  |  |  | — |  |  |  | — |  |  |  | 403 |  |
| Balance as of December 31, 2020 |  |  | 32 |  |  |  | (9,621 | ) |  |  | (2,435 | ) |  |  | 385 |  |  |  | (11,639 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (705 | ) |  |  | 3,439 |  |  |  | (3,699 | ) |  |  | — |  |  |  | (965 | ) |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | 121 |  |  |  | 569 |  |  |  | — |  |  |  | — |  |  |  | 690 |  |
| Balance as of December 31, 2021 |  | $ | (552 | ) |  | $ | (5,613 | ) |  | $ | (6,134 | ) |  | $ | 385 |  |  | $ | (11,914 | ) |

[0000950170-22-002054:notes:57]
(1)
With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings.

[0000950170-22-002054:notes:58]
The following tables present the details of reclassifications out of accumulated other comprehensive (loss) income for the years ended December 31, 2021, 2020 and 2019:

[0000950170-22-002054:notes:59]
| (In thousands) |  | For the year ended December 31, |  |  |  |
| Details about Accumulated Other Comprehensive (Loss)Income Components |  | 2021 |  |  | 2020 |  |  | 2019 |  |  | Affected Line Item in theStatement Where Net (Loss) Income Is Presented |
| Unrealized (loss) gains on available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |
| Net realized (loss) gain on sales of securities |  | $ | (164 | ) |  | $ | 585 |  |  | $ | 397 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (825 | ) |  |  | (1,212 | ) |  |  | (771 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (989 | ) |  |  | (627 | ) |  |  | (374 | ) |  |  |
| Tax benefit |  |  | 299 |  |  |  | 224 |  |  |  | 136 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (690 | ) |  | $ | (403 | ) |  | $ | (238 | ) |  |  |

[0000950170-22-002054:notes:60]
(1)
Included in the computation of net periodic pension cost. See Note 15 for additional information.

[0000950170-22-002054:notes:61]
The following tables present the tax effects related to the change in each component of other comprehensive (loss) income for the years ended December 31, 2021, 2020 and 2019:

[0000950170-22-002054:notes:62]
|  |  | 2021 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (953 | ) |  | $ | 248 |  |  | $ | (705 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 164 |  |  |  | (43 | ) |  |  | 121 |  |
| Defined benefit plan adjustments |  |  | 4,984 |  |  |  | (1,545 | ) |  |  | 3,439 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 825 |  |  |  | (256 | ) |  |  | 569 |  |
| Foreign currency translation adjustment |  |  | (3,699 | ) |  |  | — |  |  |  | (3,699 | ) |
| Total Other Comprehensive (Loss) Income |  | $ | 1,321 |  |  | $ | (1,596 | ) |  | $ | (275 | ) |

[0000950170-22-002054:notes:63]
|  |  | 2020 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 1,012 |  |  | $ | (263 | ) |  | $ | 749 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) income |  |  | (585 | ) |  |  | 152 |  |  |  | (433 | ) |
| Defined benefit plan adjustments |  |  | (1,784 | ) |  |  | 553 |  |  |  | (1,231 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) income |  |  | 1,212 |  |  |  | (376 | ) |  |  | 836 |  |
| Foreign currency translation adjustment |  |  | 4,857 |  |  |  | — |  |  |  | 4,857 |  |
| Total Other Comprehensive (Loss) Income |  | $ | 4,712 |  |  | $ | 66 |  |  | $ | 4,778 |  |

[0000950170-22-002054:notes:64]
|  |  | 2019 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 774 |  |  | $ | (201 | ) |  | $ | 573 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net loss |  |  | (397 | ) |  |  | 103 |  |  |  | (294 | ) |
| Defined benefit plan adjustments |  |  | (2,488 | ) |  |  | 771 |  |  |  | (1,717 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 771 |  |  |  | (239 | ) |  |  | 532 |  |
| Foreign currency translation adjustment |  |  | (1,480 | ) |  |  | — |  |  |  | (1,480 | ) |
| Total Other Comprehensive (Loss) Income |  | $ | (2,820 | ) |  | $ | 434 |  |  | $ | (2,386 | ) |

[0000950170-22-002054:notes:65]
Income Taxes

[0000950170-22-002054:notes:66]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax basis of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0000950170-22-002054:notes:67]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0000950170-22-002054:notes:68]
Foreign Currency

[0000950170-22-002054:notes:69]
Transactions with customers that are denominated in foreign currencies are recorded using the appropriate exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are remeasured at the balance sheet dates using the closing rates of exchange between those foreign currencies and the functional currency with any transaction gains or losses reported in other income (expense). Our primary exposures to foreign currency exchange rate movements are with our German subsidiary, whose functional currency is the Euro and our Australian subsidiary, whose functional currency is the Australian dollar. Adjustments resulting from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive (loss) income.

[0000950170-22-002054:notes:70]
Revenue

[0000950170-22-002054:notes:71]
Accounting Policy under Topic 606

[0000950170-22-002054:notes:72]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. Review of contracts with customers, for both direct customers and distributors, are performed and assessment made regarding principal versus agent considerations to determine primary responsibility for delivery of performance obligation, presumed inventory risk, and discretion in establishing pricing, when applicable. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost is included in cost of revenue. Revenue, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract, if material, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to account for shipping fees as a cost of fulfilling the related contract. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0000950170-22-002054:notes:73]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0000950170-22-002054:notes:74]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware revenue.

[0000950170-22-002054:notes:75]
Hardware and Software Revenue

[0000950170-22-002054:notes:76]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenue from software license sales is recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time products are delivered.

[0000950170-22-002054:notes:77]
Services & Support Segment - Includes a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services to complement our Network Solutions segment.

[0000950170-22-002054:notes:78]
Maintenance Revenue

[0000950170-22-002054:notes:79]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenue, when applicable, are recorded in current and non-current unearned revenue.

[0000950170-22-002054:notes:80]
Network Implementation Revenue

[0000950170-22-002054:notes:81]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0000950170-22-002054:notes:82]
See Notes 4 and 16 for additional information on reportable segments.

[0000950170-22-002054:notes:83]
Unearned Revenue

[0000950170-22-002054:notes:84]
Unearned revenue primarily represents customer billings on maintenance service programs and unearned revenue related to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one month to five years. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. In addition, we provide software maintenance and a variety of hardware maintenance services to customers under contracts with terms up to ten years. When we defer revenue related to multiple performance obligations where we still have contractual obligations, we also defer the related costs. Current deferred costs are included in prepaid expenses and other current assets on the accompanying Consolidated Balance Sheets and totaled $0.7 million and $1.1 million as of December 31, 2021 and 2020, respectively. Non-current deferred costs are included in other non-current assets on the accompanying Consolidated Balance Sheets and totaled $0.1 million as of December 31, 2021 and less than $0.1 million as of December 31, 2020.

[0000950170-22-002054:notes:85]
(Loss) Earnings per Share

[0000950170-22-002054:notes:86]
(Loss) earnings per common share and (loss) earnings per common share assuming dilution, are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year. See Note 19 for additional information.

[0000950170-22-002054:notes:87]
Business Combinations

[0000950170-22-002054:notes:88]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition subject to purchase accounting adjustments. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets and liabilities assumed or acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired and liabilities assumed exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying Consolidated Statements of (Loss) Income since their dates of acquisition. Costs incurred to complete the Business Combination, such as legal, accounting or other professional fees are charged to selling, general and administrative expenses as incurred.

[0000950170-22-002054:notes:89]
Recent Accounting Pronouncements Not Yet Adopted

[0000950170-22-002054:notes:90]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. ASU 2021-08 is effective for annual periods beginning after December 15, 2022, including interim periods within those fiscal years. Adoption of the ASU should be applied prospectively. Early adoption is also permitted, including adoption in an interim period. If early adopted, the amendments are applied retrospectively to all business combinations for which the acquisition date occurred during the fiscal year of adoption. We are currently assessing whether to early adopt ASU 2021-08 in anticipation of the closing of the Business Combination Agreement with ADVA. However, we are unable to estimate the effect on our Consolidated Financial Statements as of the date of this report. For additional information on the Business Combination Agreement, see Note 3.

[0000950170-22-002054:notes:91]
Recently Adopted Accounting Pronouncements

[0000950170-22-002054:notes:92]
In August 2018, the FASB issued Accounting Standards Update ASU 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 was effective for public business entities for fiscal years ending after December 15, 2020. The adoption of this standard did not have a material effect on the disclosures in the Consolidated Financial Statements. See Note 15 for additional information.

[0000950170-22-002054:notes:93]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive (loss) income, that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Consolidated Balance Sheets, Consolidated Statements of (Loss) Income or Consolidated Statements of Cash Flows.

[0000950170-22-002054:notes:94]
Note 2 – Cash, Cash Equivalents and Restricted Cash

[0000950170-22-002054:notes:95]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the Consolidated Balance Sheet that sum to the total of the same such amounts shown in the Consolidated Statement of Cash Flows:

[0000950170-22-002054:notes:96]
| (In thousands) |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Cash and cash equivalents |  | $ | 56,603 |  |  | $ | 60,161 |  |
| Restricted cash |  |  | 215 |  |  |  | 18 |  |
| Cash, cash equivalents and restricted cash |  | $ | 56,818 |  |  | $ | 60,179 |  |

[0000950170-22-002054:notes:97]
See Note 17 for additional information regarding restricted cash.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-22-002054:notes:98]
Note 3 – Business Combination Agreement

[0000950170-22-002054:notes:99]
On August 30, 2021, the Company and ADVA, entered into a business combination agreement (the “Business Combination Agreement”), pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, Acorn HoldCo, a Delaware corporation and currently a wholly-owned direct subsidiary of the Company.

[0000950170-22-002054:notes:100]
Under the terms of the Business Combination Agreement, Acorn MergeCo, Inc., a newly formed Delaware corporation and wholly-owned direct subsidiary of Acorn HoldCo (“Merger Sub”), will merge with and into ADTRAN, with ADTRAN surviving the merger (the “Merger”) as a wholly-owned direct subsidiary of Acorn HoldCo. Pursuant to the Merger, each outstanding share of common stock of the Company will be converted into the right to receive one share of common stock of Acorn HoldCo. Acorn HoldCo has also made a public exchange offer to exchange each issued and outstanding no-par value bearer share of ADVA, pursuant to which each ADVA share tendered and accepted for exchange will be exchanged for 0.8244 shares of common stock of Acorn HoldCo (the “Exchange Offer”, and together with the Merger, the “Business Combination”). Upon completion of the Business Combination, and assuming that all of the outstanding ADVA shares are exchanged in the Exchange Offer, former ADTRAN stockholders and former ADVA shareholders will own approximately 54% and 46%, respectively, of the outstanding Acorn HoldCo shares.

[0000950170-22-002054:notes:101]
The Business Combination Agreement was unanimously approved by the Board of Directors of the Company and by the supervisory board and management board of ADVA. On January 6, 2022, the Company's stockholders approved the Business Combination by an overwhelming majority. The end of the ADVA shareholder tender offer acceptance period was on January 26, 2022, which resulted in the acceptance of the Exchange Offer by more than 60% of all shares of ADVA entitled to voting rights existing as of October 31, 2021, thus exceeding the required minimum acceptance threshold. According to the rules of the German Securities Acquisition and Takeover Act, ADVA shareholders who did not tender their shares during the initial acceptance period could do so during a two-week additional acceptance period that began on February 1, 2022 and ended February 14, 2022. This resulted in the acceptance of the Exchange Offer by approximately 66% of all shares of ADVA entitled to voting rights existing as of November 30, 2021. On January 24, 2022, the Committee on Foreign Investment in the United States ("CFIUS") completed its review of the Business Combination and determined that the transaction was not a “covered transaction” subject to CFIUS’ jurisdiction, satisfying the condition of the Business Combination Agreement related to CFIUS notification. On February 16, 2022, the U.K. Secretary of State for Business, Energy and Industrial Strategy completed its review of the Business Combination and determined that the Secretary of State will be taking no further action under the NS&I Act, satisfying the condition of the Business Combination Agreement related to NS&I Act approval. Cooperative proceedings continue with the foreign direct investment authorities in Germany.

[0000950170-22-002054:notes:102]
The Company anticipates the consummation of the Business Combination around the middle of 2022, subject to customary closing conditions, and regulatory approvals from the foreign direct investment authorities in Germany.

[0000950170-22-002054:notes:103]
Additional information about the Business Combination Agreement and proposed Business Combination is set forth in the Company’s filings with the SEC, as well as in the registration statement on Form S-4 that Acorn HoldCo filed with the SEC, which was declared effective December 2, 2021 (the “Acorn HoldCo Registration Statement”).


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-22-002054:notes:104]
Note 4 - Revenue

[0000950170-22-002054:notes:105]
The following is a description of the principal activities from which revenue is generated by reportable segment:

[0000950170-22-002054:notes:106]
Network Solutions - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

[0000950170-22-002054:notes:107]
Services & Support - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

[0000950170-22-002054:notes:108]
Revenue by Category

[0000950170-22-002054:notes:109]
In addition to reportable segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

[0000950170-22-002054:notes:110]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2021:

[0000950170-22-002054:notes:111]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 300,343 |  |  | $ | 43,853 |  |  | $ | 344,196 |  |
| Subscriber Solutions & Experience |  |  | 189,121 |  |  |  | 10,500 |  |  |  | 199,621 |  |
| Traditional & Other Products |  |  | 9,370 |  |  |  | 9,817 |  |  |  | 19,187 |  |
| Total |  | $ | 498,834 |  |  | $ | 64,170 |  |  | $ | 563,004 |  |

[0000950170-22-002054:notes:112]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2020:

[0000950170-22-002054:notes:113]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 262,578 |  |  | $ | 50,560 |  |  | $ | 313,138 |  |
| Subscriber Solutions & Experience |  |  | 161,824 |  |  |  | 9,263 |  |  |  | 171,087 |  |
| Traditional & Other Products |  |  | 13,613 |  |  |  | 8,672 |  |  |  | 22,285 |  |
| Total |  | $ | 438,015 |  |  | $ | 68,495 |  |  | $ | 506,510 |  |

[0000950170-22-002054:notes:114]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2019:

[0000950170-22-002054:notes:115]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 289,980 |  |  | $ | 58,894 |  |  | $ | 348,874 |  |
| Subscriber Solutions & Experience |  |  | 144,651 |  |  |  | 8,269 |  |  |  | 152,920 |  |
| Traditional & Other Products |  |  | 20,595 |  |  |  | 7,672 |  |  |  | 28,267 |  |
| Total |  | $ | 455,226 |  |  | $ | 74,835 |  |  | $ | 530,061 |  |

[0000950170-22-002054:notes:116]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $101.1 million, with approximately 74.6% expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at December 31, 2021 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-22-002054:notes:117]
The following table provides information about accounts receivable, contract assets and unearned revenue from contracts with customers:

[0000950170-22-002054:notes:118]
| (In thousands) |  | December 31, 2021 |  |  | December 31, 2020 |  |
| Accounts receivable |  | $ | 158,742 |  |  | $ | 98,827 |  |
| Contract assets(1) |  | $ | 464 |  |  | $ | 63 |  |
| Unearned revenue |  | $ | 17,737 |  |  | $ | 14,092 |  |
| Non-current unearned revenue |  | $ | 9,271 |  |  | $ | 6,888 |  |

[0000950170-22-002054:notes:119]
(1) Included in other receivables on the Consolidated Balance Sheets.

[0000950170-22-002054:notes:120]
Of the outstanding unearned revenue balance as of December 31, 2020, 2019 and 2018, $11.2 million, $11.0 million and $12.7 million were recognized as revenue during the years ended December 31, 2021,  2020 and 2019, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000950170-22-002054:notes:121]
The following tables disaggregate our revenue by category for the years ended December 31, 2021, 2020 and 2019:

[0000950170-22-002054:notes:122]
|  |  | 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 300,343 |  |  | $ | 43,853 |  |  | $ | 344,196 |  |
| Subscriber Solutions & Experience |  |  | 189,121 |  |  |  | 10,500 |  |  |  | 199,621 |  |
| Traditional & Other Products |  |  | 9,370 |  |  |  | 9,817 |  |  |  | 19,187 |  |
| Total |  | $ | 498,834 |  |  | $ | 64,170 |  |  | $ | 563,004 |  |

[0000950170-22-002054:notes:123]
|  |  | 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 262,578 |  |  | $ | 50,560 |  |  | $ | 313,138 |  |
| Subscriber Solutions & Experience |  |  | 161,824 |  |  |  | 9,263 |  |  |  | 171,087 |  |
| Traditional & Other Products |  |  | 13,613 |  |  |  | 8,672 |  |  |  | 22,285 |  |
| Total |  | $ | 438,015 |  |  | $ | 68,495 |  |  | $ | 506,510 |  |

[0000950170-22-002054:notes:124]
|  |  | 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 289,980 |  |  | $ | 58,894 |  |  | $ | 348,874 |  |
| Subscriber Solutions & Experience |  |  | 144,651 |  |  |  | 8,269 |  |  |  | 152,920 |  |
| Traditional & Other Products |  |  | 20,595 |  |  |  | 7,672 |  |  |  | 28,267 |  |
| Total |  | $ | 455,226 |  |  | $ | 74,835 |  |  | $ | 530,061 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-22-002054:notes:125]
Note 5 – Stock-Based Compensation

[0000950170-22-002054:notes:126]
The following table summarizes stock-based compensation expense related to stock options, PSUs, RSUs and restricted stock for the years ended December 31, 2021, 2020 and 2019:

[0000950170-22-002054:notes:127]
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Stock-based compensation expense included in cost of revenue |  | $ | 543 |  |  | $ | 426 |  |  | $ | 369 |  |
| Selling, general and administrative expenses |  |  | 4,571 |  |  |  | 4,036 |  |  |  | 3,889 |  |
| Research and development expenses |  |  | 2,366 |  |  |  | 2,372 |  |  |  | 2,704 |  |
| Stock-based compensation expense included in operating expenses |  |  | 6,937 |  |  |  | 6,408 |  |  |  | 6,593 |  |
| Total stock-based compensation expense |  |  | 7,480 |  |  |  | 6,834 |  |  |  | 6,962 |  |
| Tax benefit for expense associated with non-qualified stock options, PSUs, RSUs and restricted stock |  |  | (1,849 | ) |  |  | (1,629 | ) |  |  | (1,659 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 5,631 |  |  | $ | 5,205 |  |  | $ | 5,303 |  |

[0000950170-22-002054:notes:128]
Stock Incentive Program Descriptions

[0000950170-22-002054:notes:129]
2020 Stock Incentive Plans

[0000950170-22-002054:notes:130]
At the annual meeting of stockholders held on May 13, 2020, the Company’s stockholders approved, upon recommendation of the Board of Directors, the adoption of the ADTRAN, Inc. 2020 Employee Stock Incentive Plan (the “2020 Employee Plan”) as well as the ADTRAN, Inc. 2020 Directors Stock Plan (the “2020 Directors Plan”). No additional awards will be granted under the Company’s previous stock incentive plans, the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (the “2015 Employee Plan”) or the 2010 Directors Stock Plan (the “2010 Directors Plan”) subsequent to the stockholders’ approval of these new stock plans. Outstanding awards granted under the 2015 Employee Plan and the 2010 Directors Plan will remain subject to the terms of such plans, and shares underlying awards granted under such plans that are cancelled or forfeited will be available for issuance under the 2020 Employee Plan or the 2020 Directors Plan, as applicable.

[0000950170-22-002054:notes:131]
Under the 2020 Employee Plan, the Company is authorized to issue 2.8 million shares of common stock to certain employees, key service providers and advisors through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock, any of which may be subject to performance-based conditions. RSUs and restricted stock granted under the 2020 Employee Plan will typically vest pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date. Stock options granted under the 2020 Employee Plan will typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Stock options, RSUs and restricted stock granted under the 2020 Employee Plan reduce the shares authorized for issuance under the 2020 Employee Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations or expirations of awards granted under the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan, with forfeitures, cancellations or expirations of RSUs and restricted stock increasing the shares authorized for issuance by 2.5 shares of common stock for each share underlying the award. Forfeitures, cancellations or expirations of stock options from the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan by one share of common stock for each share underlying the award.

[0000950170-22-002054:notes:132]
Under the 2020 Directors Plan, the Company is authorized to issue 0.4 million shares of common stock through stock options, restricted stock and RSUs to non-employee directors. Stock awards issued under the 2020 Directors Plan typically will become vested in full on the first anniversary of the grant date. Stock options issued under the 2020 Directors Plan will have a ten-year contractual term. Stock options, restricted stock and RSUs granted under the 2020 Directors Plan reduce the shares authorized for issuance under the 2020 Directors Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the 2010 Directors Stock Plan increase the shares authorized for issuance under the 2020 Directors Plan by one share of common stock for each share underlying the award.

[0000950170-22-002054:notes:133]
Previous Stock Incentive Plans

[0000950170-22-002054:notes:134]
In January 2015, the Board of Directors adopted the 2015 Employee Plan, which authorized 7.7 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, PSUs, RSUs and restricted stock. The 2015 Employee Plan was adopted by stockholder approval at our annual meeting of stockholders held in May 2015. PSUs, RSUs and restricted stock granted under the 2015 Plan reduce the shares authorized for issuance under the 2015 Employee Plan by 2.5 shares of common stock for each share underlying the award. Options granted under the 2015 Employee Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Expiration dates of options outstanding as of December 31, 2021 under the 2015 Employee Plan range from 2025 to 2026.

[0000950170-22-002054:notes:135]
In January 2006, the Board of Directors adopted the ADTRAN, Inc. 2006 Employee Stock Incentive Plan (the “2006 Plan”), which authorized 13.0 million shares of common stock for issuance to officers and certain employees through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock. Options granted under the 2006 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and had a ten-year contractual term. The 2006 Plan was replaced in May 2015 by the 2015 Employee Plan. Expiration dates of options outstanding as of December 31, 2021 under the 2006 Plan range from 2022 to 2024.

[0000950170-22-002054:notes:136]
In May 2010, the Company’s stockholders approved the 2010 Directors Plan, under which 0.5 million shares of common stock have been reserved for issuance. This plan replaced the 2005 Directors Stock Option Plan. Under the 2010 Directors Plan, the Company may issue stock options, restricted stock and RSUs to our non-employee directors. Stock awards issued under the 2010 Directors Plan become vested in full on the first anniversary of the grant date. Options issued under the 2010 Directors Plan had a ten-year contractual term. All remaining options under the 2010 Directors Plan expired in 2019.

[0000950170-22-002054:notes:137]
PSUs, RSUs and restricted stock

[0000950170-22-002054:notes:138]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2020 and 2021 and the changes that occurred during 2021:

[0000950170-22-002054:notes:139]
|  |  | Number ofshares (In thousands) |  |  | WeightedAverage GrantDate Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2020 |  |  | 1,846 |  |  | $ | 11.49 |  |
| PSUs, RSUs and restricted stock granted |  |  | 748 |  |  | $ | 20.17 |  |
| PSUs, RSUs and restricted stock vested |  |  | (552 | ) |  | $ | 13.67 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (112 | ) |  | $ | 11.70 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2021 |  |  | 1,930 |  |  | $ | 14.11 |  |

[0000950170-22-002054:notes:140]
The following table details the significant assumptions that impact the fair value estimate of the market-based PSUs:

[0000950170-22-002054:notes:141]
|  |  | 2021 |  |  | 2020 |  |  | 2019 |
| Estimated fair value per share |  | $26.07 |  |  | $14.43 |  |  | $9.53 to $18.05 |
| Expected volatility |  |  | 53.27 | % |  |  | 51.88 | % |  | 32.7% to 38.9% |
| Risk-free interest rate |  |  | 0.85 | % |  |  | 0.24 | % |  | 1.6% to 2.46% |
| Expected dividend yield |  |  | 1.63 | % |  |  | 2.85 | % |  | 2.3% to 4.09% |

[0000950170-22-002054:notes:142]
For market-based PSUs, the number of shares of common stock earned by a recipient is subject to a market condition based on ADTRAN’s relative total shareholder return against all companies in the NASDAQ Telecommunications Index at the end of a three-year performance period. Depending on the relative total shareholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the PSUs, with the shares earned distributed upon the vesting. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted PSUs vests and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of ADTRAN, as defined by the 2020 Employee Plan. The recipients of the PSUs receive dividend credits based on the shares of common stock underlying the PSUs. The dividend credits vest and are earned in the same manner as the PSUs and are paid in cash upon the issuance of common stock for the PSUs.

[0000950170-22-002054:notes:143]
During the first quarter of 2021 and 2020, the Company issued 0.6 million performance-based PSUs under the 2015 Employee Plan to its executive officers and certain other employees as noted. The grant-date fair value of these performance-based awards is based on the closing price of the Company’s stock on the date of grant. Subject to the grantee’s continued employment, the grantee has the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of a defined performance target at the end of a three-year period. If the Company achieves the performance target at the end of the first or second year during the vesting period, the grantee will be entitled to the target number of performance shares, which will be issued at the end of the three-year period. Equity-based compensation expense with respect to these awards will be adjusted over the vesting period to reflect the probability of achievement of the performance target defined in the award agreements.

[0000950170-22-002054:notes:144]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the grant date. RSUs and restricted stock vest ratably over four-year and one-year periods, respectively.

[0000950170-22-002054:notes:145]
We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0000950170-22-002054:notes:146]
As of December 31, 2021, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $17.5 million, which is expected to be recognized over an average remaining recognition period of 2.9 years and will be adjusted for actual forfeitures as they occur.

[0000950170-22-002054:notes:147]
As of December 31, 2021, 3.8 million shares were available for issuance under shareholder-approved equity plans in connection with the grant and exercise of stock options, PSU’s, RSU’s or restricted stock.

[0000950170-22-002054:notes:148]
Stock Options

[0000950170-22-002054:notes:149]
The following table is a summary of stock options outstanding as of December 31, 2021 and 2020 and the changes that occurred during 2021:

[0000950170-22-002054:notes:150]
|  |  | Number ofOptions(In thousands) |  |  | WeightedAverageExercise Price(Per share) |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | AggregateIntrinsic Value(In thousands) |  |
| Stock options outstanding, December 31, 2020 |  |  | 2,718 |  |  | $ | 21.17 |  |  |  | 2.86 |  |  | $ | — |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  | $ | — |  |
| Stock options exercised |  |  | (382 | ) |  | $ | 16.82 |  |  |  |  |  | $ | 1,491 |  |
| Stock options forfeited |  |  | — |  |  | $ | — |  |  |  |  |  | $ | — |  |
| Stock options expired |  |  | (615 | ) |  | $ | 28.89 |  |  |  |  |  | $ | 21 |  |
| Stock options outstanding, December 31, 2021 |  |  | 1,721 |  |  | $ | 19.37 |  |  |  | 2.39 |  |  | $ | 6,669 |  |
| Stock options exercisable, December 31, 2021 |  |  | 1,721 |  |  | $ | 19.37 |  |  |  | 2.39 |  |  | $ | 6,669 |  |

[0000950170-22-002054:notes:151]
All of these stock options were issued at exercise prices that approximated fair market value at the date of grant. As of December 31, 2021, there was no unrecognized compensation expense related to non-vested stock options.

[0000950170-22-002054:notes:152]
The aggregate intrinsic values represent the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of 2021 and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2021. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock and was $6.7 million as of December 31, 2021.

[0000950170-22-002054:notes:153]
The total pre-tax intrinsic value of options exercised during 2021, 2020 and 2019 was $1.5 million, $0 and $0.1 million, respectively. The fair value of options fully vesting during 2021, 2020 and 2019 was $0, less than $0.1 million and $0.9 million, respectively.

[0000950170-22-002054:notes:154]
The following table further describes our stock options outstanding as of December 31, 2021:

[0000950170-22-002054:notes:155]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range ofExercise Prices |  | OptionsOutstanding atDecember 31, 2021(In thousands) |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | WeightedAverageExercisePrice |  |  | OptionsExercisable atDecember 31, 2021(In thousands) |  |  | WeightedAverageExercisePrice |  |
| $15.33 – $16.97 |  |  | 703 |  |  |  | 2.75 |  |  | $ | 15.89 |  |  |  | 703 |  |  | $ | 15.89 |  |
| $16.98 – $18.97 |  |  | 463 |  |  |  | 2.77 |  |  | $ | 18.96 |  |  |  | 463 |  |  | $ | 18.96 |  |
| $18.98 – $30.36 |  |  | 555 |  |  |  | 1.64 |  |  | $ | 24.12 |  |  |  | 555 |  |  | $ | 24.12 |  |
|  |  |  | 1,721 |  |  |  |  |  |  |  |  |  | 1,721 |  |  |  |  |

[0000950170-22-002054:notes:156]
The Black-Scholes option pricing model (the “Black-Scholes Model”) is used to determine the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0000950170-22-002054:notes:157]
There were no stock options granted in during the years ended December 31, 2021, 2020 or 2019.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-22-002054:notes:158]
Note 6 – Investments

[0000950170-22-002054:notes:159]
Debt Securities and Other Investments

[0000950170-22-002054:notes:160]
As of December 31, 2021, the following debt securities and other investments were included in short-term investments and long-term investments on the Consolidated Balance Sheet and recorded at fair value:

[0000950170-22-002054:notes:161]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,776 |  |  | $ | 6 |  |  | $ | (35 | ) |  | $ | 10,747 |  |
| Municipal fixed-rate bonds |  |  | 1,553 |  |  |  | 2 |  |  |  | (4 | ) |  |  | 1,551 |  |
| Asset-backed bonds |  |  | 322 |  |  |  | 3 |  |  |  | (3 | ) |  |  | 322 |  |
| Mortgage/Agency-backed bonds |  |  | 4,754 |  |  |  | 15 |  |  |  | (33 | ) |  |  | 4,736 |  |
| U.S. government bonds |  |  | 12,251 |  |  |  | 12 |  |  |  | (92 | ) |  |  | 12,171 |  |
| Foreign government bonds |  |  | 543 |  |  |  | — |  |  |  | (4 | ) |  |  | 539 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,199 |  |  | $ | 38 |  |  | $ | (171 | ) |  | $ | 30,066 |  |

[0000950170-22-002054:notes:162]
As of December 31, 2020, the following debt securities and other investments were included in short-term investments and long-term investments on the Consolidated Balance Sheet and recorded at fair value:

[0000950170-22-002054:notes:163]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 11,762 |  |  | $ | 123 |  |  | $ | — |  |  | $ | 11,885 |  |
| Municipal fixed-rate bonds |  |  | 2,854 |  |  |  | 30 |  |  |  | — |  |  |  | 2,884 |  |
| Asset-backed bonds |  |  | 6,634 |  |  |  | 74 |  |  |  | — |  |  |  | 6,708 |  |
| Mortgage/Agency-backed bonds |  |  | 11,536 |  |  |  | 114 |  |  |  | (6 | ) |  |  | 11,644 |  |
| U.S. government bonds |  |  | 9,763 |  |  |  | 112 |  |  |  | — |  |  |  | 9,875 |  |
| Foreign government bonds |  |  | 1,334 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 1,337 |  |
| Commercial Paper |  |  | 250 |  |  |  | — |  |  |  | — |  |  |  | 250 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,666 |  |  | $ | 457 |  |  | $ | (7 | ) |  | $ | 45,116 |  |

[0000950170-22-002054:notes:164]
As of December 31, 2021, our debt securities had the following contractual maturities:

[0000950170-22-002054:notes:165]
| (In thousands) |  | Corporatebonds |  |  | Municipalfixed-ratebonds |  |  | Asset-backedbonds |  |  | Mortgage /Agency-backedbonds |  |  | U.S.governmentbonds |  |  | Foreigngovernmentbonds |  |
| Less than one year |  | $ | 681 |  |  | $ | 150 |  |  | $ | — |  |  | $ | 801 |  |  | $ | 1,884 |  |  | $ | — |  |
| One to two years |  |  | 4,902 |  |  |  | 1,018 |  |  |  | — |  |  |  | 868 |  |  |  | 5,320 |  |  |  | 245 |  |
| Two to three years |  |  | 4,333 |  |  |  | 265 |  |  |  | 29 |  |  |  | — |  |  |  | 4,421 |  |  |  | 294 |  |
| Three to five years |  |  | 831 |  |  |  | 118 |  |  |  | — |  |  |  | 324 |  |  |  | 546 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,125 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 293 |  |  |  | 1,618 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 10,747 |  |  | $ | 1,551 |  |  | $ | 322 |  |  | $ | 4,736 |  |  | $ | 12,171 |  |  | $ | 539 |  |

[0000950170-22-002054:notes:166]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0000950170-22-002054:notes:167]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities for the years ended December 31, 2021, 2020 and 2019:

[0000950170-22-002054:notes:168]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Gross realized gains on debt securities |  | $ | 241 |  |  | $ | 459 |  |  | $ | 108 |  |
| Gross realized losses on debt securities |  |  | (159 | ) |  |  | (58 | ) |  |  | (50 | ) |
| Total gain recognized, net |  | $ | 82 |  |  | $ | 401 |  |  | $ | 58 |  |

[0000950170-22-002054:notes:169]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt with credit deterioration during the years ended December 31, 2021, 2020 and 2019.

[0000950170-22-002054:notes:170]
The following table presents the breakdown of debt securities and other investments with unrealized losses as of December 31, 2021:

[0000950170-22-002054:notes:171]
|  |  | Continuous UnrealizedLoss Position for Lessthan 12 Months |  |  | Continuous UnrealizedLoss Position for 12Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |
| Corporate bonds |  | $ | 6,795 |  |  | $ | (35 | ) |  | $ | — |  |  | $ | — |  |  | $ | 6,795 |  |  | $ | (35 | ) |
| Municipal fixed-rate bonds |  |  | 1,129 |  |  |  | (4 | ) |  |  | — |  |  |  | — |  |  |  | 1,129 |  |  |  | (4 | ) |
| Asset-backed bonds |  |  | 198 |  |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | 198 |  |  |  | (3 | ) |
| Mortgage/Agency-backed bonds |  |  | 3,006 |  |  |  | (33 | ) |  |  | — |  |  |  | — |  |  |  | 3,006 |  |  |  | (33 | ) |
| U.S. government bonds |  |  | 10,552 |  |  |  | (92 | ) |  |  | — |  |  |  | — |  |  |  | 10,552 |  |  |  | (92 | ) |
| Foreign government bonds |  |  | 294 |  |  |  | (4 | ) |  |  | — |  |  |  | — |  |  |  | 294 |  |  |  | (4 | ) |
| Total |  | $ | 21,974 |  |  | $ | (171 | ) |  | $ | — |  |  | $ | — |  |  | $ | 21,974 |  |  | $ | (171 | ) |

[0000950170-22-002054:notes:172]
The following table presents the breakdown of debt securities and other investments with unrealized losses as of December 31, 2020:

[0000950170-22-002054:notes:173]
|  |  | Continuous UnrealizedLoss Position for Lessthan 12 Months |  |  | Continuous UnrealizedLoss Position for 12Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |
| Corporate bonds |  | $ | 336 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 336 |  |  | $ | — |  |
| Municipal fixed-rate bonds |  |  | 310 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 310 |  |  |  | — |  |
| Asset-backed bonds |  |  | 2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 2,078 |  |  |  | (6 | ) |  |  | — |  |  |  | — |  |  |  | 2,078 |  |  |  | (6 | ) |
| U.S. government bonds |  |  | 350 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 350 |  |  |  | — |  |
| Foreign government bonds |  |  | 302 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 302 |  |  |  | (1 | ) |
| Total |  | $ | 3,378 |  |  | $ | (7 | ) |  | $ | — |  |  | $ | — |  |  | $ | 3,378 |  |  | $ | (7 | ) |

[0000950170-22-002054:notes:174]
The increase in unrealized losses during 2021 resulted from changes in market positions associated with our fixed income portfolio.

[0000950170-22-002054:notes:175]
Marketable Equity Securities

[0000950170-22-002054:notes:176]
Marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost, where appropriate.

[0000950170-22-002054:notes:177]
The Company has an equity investment which does not have a readily determinable fair value, and is recorded using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of the equity investment as of  December 31, 2021 and 2020 was $1.0 million and $0.8 million, respectively. During the years ended December 31, 2021 and 2020, impairment charges totaling $0.4 million and $2.6 million, respectively, were recorded related to the equity investment and are included in net investment gain (loss) on the Consolidated Statement of (Loss) Income. There were no impairment charges during the year ended December 31, 2019. During the year ended December 31, 2021, an unsecured loan totaling $0.5 million was converted to equity which increased the Company's carrying value of the equity investment.

[0000950170-22-002054:notes:178]
The Company has a secured note receivable as of December 31, 2021 and 2020 which totaled $0.4 million and $0.9 million, respectively, and is included in long-term investments on the Consolidated Balance Sheets. During the year ended December 31, 2021, an impairment charge of $0.5 million was recognized against the secured note receivable is included in net investment gain (loss) on the Consolidated Statement of (Loss) Income. There were no impairment charges during the years ended December 31, 2020 and 2019.

[0000950170-22-002054:notes:179]
The Company had an unsecured loan as of December 31, 2020 totaling $0.5 million.

[0000950170-22-002054:notes:180]
Realized and unrealized gains and losses for our marketable equity securities for the year ended December 31, 2021, 2020 and 2019 were as follows:

[0000950170-22-002054:notes:181]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Realized losses on equity securities sold |  | $ | (992 | ) |  | $ | (2,382 | ) |  | $ | (96 | ) |
| Unrealized gains on equity securities held |  |  | 2,671 |  |  |  | 6,831 |  |  |  | 11,472 |  |
| Total gain (loss) recognized, net |  | $ | 1,679 |  |  | $ | 4,449 |  |  | $ | 11,376 |  |

[0000950170-22-002054:notes:182]
As of December 31, 2021 and 2020, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.

[0000950170-22-002054:notes:183]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-22-002054:notes:184]
•
Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-22-002054:notes:185]
•
Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-22-002054:notes:186]
•
Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement; inputs could include information supplied by investees.

[0000950170-22-002054:notes:187]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-22-002054:notes:188]
|  |  | Fair Value Measurements as of December 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 652 |  |  | $ | 652 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,747 |  |  |  | — |  |  |  | 10,747 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,551 |  |  |  | — |  |  |  | 1,551 |  |  |  | — |  |
| Asset-backed bonds |  |  | 322 |  |  |  | — |  |  |  | 322 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,736 |  |  |  | — |  |  |  | 4,736 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,171 |  |  |  | 12,171 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 539 |  |  |  | — |  |  |  | 539 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities - various industries |  |  | 12,606 |  |  |  | 12,606 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,935 |  |  |  | 26,935 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 70,259 |  |  | $ | 52,364 |  |  | $ | 17,895 |  |  | $ | — |  |

[0000950170-22-002054:notes:189]
|  |  | Fair Value Measurements as of December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 497 |  |  | $ | 497 |  |  | $ | — |  |  | $ | — |  |
| U.S. government bonds |  |  | 350 |  |  |  | 350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,885 |  |  |  | — |  |  |  | 11,885 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,884 |  |  |  | — |  |  |  | 2,884 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,708 |  |  |  | — |  |  |  | 6,708 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,644 |  |  |  | — |  |  |  | 11,644 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,875 |  |  |  | 9,875 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,337 |  |  |  | — |  |  |  | 1,337 |  |  |  | — |  |
| Commercial paper |  |  | 250 |  |  |  | — |  |  |  | 250 |  |  |  | — |  |
| Other investments |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 10,963 |  |  |  | 10,963 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 23,891 |  |  |  | 23,891 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,217 |  |  | $ | 46,976 |  |  | $ | 34,708 |  |  | $ | 533 |  |

[0000950170-22-002054:notes:190]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0000950170-22-002054:notes:191]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consisted of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.

[0000950170-22-002054:notes:192]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-22-002054:notes:193]
Note 7 – Inventory

[0000950170-22-002054:notes:194]
As of December 31, 2021 and 2020, inventory, net was comprised of the following:

[0000950170-22-002054:notes:195]
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Raw materials |  | $ | 74,709 |  |  | $ | 47,026 |  |
| Work in process |  |  | 2,143 |  |  |  | 776 |  |
| Finished goods |  |  | 63,039 |  |  |  | 77,655 |  |
| Total Inventory, net |  | $ | 139,891 |  |  | $ | 125,457 |  |

[0000950170-22-002054:notes:196]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. As of December 31, 2021 and 2020, our inventory reserve was $44.6 million and $39.6 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-22-002054:notes:197]
Note 8 – Property, Plant and Equipment

[0000950170-22-002054:notes:198]
As of December 31, 2021 and 2020, property, plant and equipment, net was comprised of the following:

[0000950170-22-002054:notes:199]
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 35,578 |  |  |  | 35,142 |  |
| Building |  |  | 68,157 |  |  |  | 68,169 |  |
| Furniture and fixtures |  |  | 19,917 |  |  |  | 19,965 |  |
| Computer hardware and software |  |  | 72,274 |  |  |  | 70,942 |  |
| Engineering and other equipment |  |  | 134,771 |  |  |  | 132,920 |  |
| Total Property, Plant and Equipment |  |  | 335,272 |  |  |  | 331,713 |  |
| Less: accumulated depreciation |  |  | (279,506 | ) |  |  | (269,314 | ) |
| Total Property, Plant and Equipment, net |  | $ | 55,766 |  |  | $ | 62,399 |  |

[0000950170-22-002054:notes:200]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. No impairment charges were recognized during the year ended December 31, 2021. During the years ended December 31, 2020 and December 31, 2019, the Company recognized impairment charges of $0.1 million and $3.9 million, respectively, related to the abandonment of certain information technology projects in which we had previously capitalized expenses related to these projects. The impairment charges were determined based on actual costs incurred as part of the projects.

[0000950170-22-002054:notes:201]
Depreciation expense was $12.0 million, $12.2 million and $12.5 million for the years ended December 31, 2021, 2020 and 2019, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of (Loss) Income.


## adtn:LeasesDisclosureTextBlock

[0000950170-22-002054:notes:202]
Note 9 – Leases

[0000950170-22-002054:notes:203]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain potential embedded leases. These other contracts are specifically reviewed to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease.

[0000950170-22-002054:notes:204]
As of December 31, 2021, our operating leases had remaining lease terms of one month to forty four months, some of which included options to extend the leases for up to two years, and some of which included options to terminate the leases within three months. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. Supplemental balance sheet information related to operating leases is as follows:

[0000950170-22-002054:notes:205]
|  |  |  |  | December 31, |  |  | December 31, |  |
| (In thousands) |  | Classification |  | 2021 |  |  | 2020 |  |
| Assets |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Other non-current assets |  | $ | 4,922 |  |  | $ | 5,309 |  |
| Total lease asset |  |  |  | $ | 4,922 |  |  | $ | 5,309 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses and other liabilities |  | $ | 1,730 |  |  | $ | 1,806 |  |
| Non-current operating lease liability |  | Other non-current liabilities |  |  | 3,269 |  |  |  | 3,574 |  |
| Total lease liability |  |  |  | $ | 4,999 |  |  | $ | 5,380 |  |

[0000950170-22-002054:notes:206]
Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. Lease expense related to these short-term leases was less than $0.1 million for the twelve months ended December 31, 2021 and 2020 and was $0.4 million of the twelve months ended December 31, 2019, and is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of (Loss) Income. Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.5 million, $0.7 million and $0.9 million for the twelve months ended December 31, 2021, 2020 and 2019, respectively. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. Our lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-22-002054:notes:207]
The components of lease expense included in the Consolidated Statements of (Loss) Income were as follows:

[0000950170-22-002054:notes:208]
|  |  | For the Year Ended December 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Cost of revenue |  | $ | 51 |  |  | $ | 113 |  |  | $ | 64 |  |
| Selling, general and administrative expenses |  |  | 883 |  |  |  | 1,311 |  |  |  | 1,400 |  |
| Research and development expenses |  |  | 1,071 |  |  |  | 1,121 |  |  |  | 2,417 |  |
| Total operating lease expense |  | $ | 2,005 |  |  | $ | 2,545 |  |  | $ | 3,881 |  |

[0000950170-22-002054:notes:209]
As of December 31, 2021, operating lease liabilities included on the Consolidated Balance Sheet by future maturity were as follows:

[0000950170-22-002054:notes:210]
| (In thousands) |  | Amount |  |
| 2022 |  |  | 1,767 |  |
| 2023 |  |  | 1,419 |  |
| 2024 |  |  | 1,188 |  |
| 2025 |  |  | 710 |  |
| Thereafter |  |  | — |  |
| Total lease payments |  |  | 5,084 |  |
| Less: Interest |  |  | (85 | ) |
| Present value of lease liabilities |  | $ | 4,999 |  |

[0000950170-22-002054:notes:211]
Future operating lease payments include $1.6 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0000950170-22-002054:notes:212]
An incremental borrowing rate is used based on information available at the commencement date in determining the present value of lease payments. The incremental borrowing rate is determined on a portfolio basis by grouping leases with similar terms as well as grouping leases based on a U.S. dollar or Euro functional currency. The actual rate is then determined based on a credit spread over LIBOR as well as the Bloomberg Curve Matrix for the U.S. Communications section. The following table provides information about our weighted average lease terms and weighted average discount rates:

[0000950170-22-002054:notes:213]
|  |  | As of December 31, |  |
| Weighted average remaining lease term (years) |  | 2021 |  |  | 2020 |  |
| Operating leases with USD functional currency |  |  | 1.8 |  |  |  | 2.4 |  |
| Operating leases with Euro functional currency |  |  | 3.5 |  |  |  | 3.6 |  |
| Weighted average discount rate |  |  |  |  |  |  |
| Operating leases with USD functional currency |  |  | 3.49 | % |  |  | 4.47 | % |
| Operating leases with Euro functional currency |  |  | 1.22 | % |  |  | 1.37 | % |

[0000950170-22-002054:notes:214]
Supplemental cash flow information related to operating leases is as follows:

[0000950170-22-002054:notes:215]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Cash used in operating activities related to operating leases |  | $ | 1,892 |  |  | $ | 2,632 |  |  | $ | 3,439 |  |
| Right-of-use assets obtained in exchange for operating lease obligations |  | $ | 1,875 |  |  | $ | 324 |  |  | $ | 11,615 |  |

[0000950170-22-002054:notes:216]
Sales-Type Leases

[0000950170-22-002054:notes:217]
We are the lessor in sales-type lease arrangements for network equipment, which have initial terms of up to five years. Our sales-type lease arrangements contain either a provision whereby the network equipment reverts back to us upon the expiration of the lease or a provision that allows the lessee to purchase the network equipment at a bargain purchase amount at the end of the lease. In addition, our sales-type lease arrangements do not contain any residual value guarantees or material restrictive covenants. The allocation of the consideration between lease and non-lease components is determined by stand-alone selling price by component. The net investment in sales-type leases consists of lease receivables less unearned income. Collectability of sales-type leases is evaluated periodically at an individual customer level. The Company has elected to exclude taxes related to sales-type leases from revenue and the associated expense of such taxes. As of December 31, 2021 and 2020, we did not have an allowance for credit losses for our net investment in sales-type leases. As of December 31, 2021 and 2020, the components of the net investment in sales-type leases were as follows:

[0000950170-22-002054:notes:218]
|  |  | As of December 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Current minimum lease payments receivable(1) |  | $ | 92 |  |  | $ | 702 |  |
| Non-current minimum lease payments receivable(2) |  |  | 4 |  |  |  | 347 |  |
| Total minimum lease payments receivable |  |  | 96 |  |  |  | 1,049 |  |
| Less: Current unearned revenue(1) |  |  | 70 |  |  |  | 218 |  |
| Less: Non-current unearned revenue(2) |  |  | 1 |  |  |  | 50 |  |
| Net investment in sales-type leases |  | $ | 25 |  |  | $ | 781 |  |

[0000950170-22-002054:notes:219]
(1)
Included in other receivables on the Consolidated Balance Sheets.

[0000950170-22-002054:notes:220]
(2)
Included in other non-current assets on the Consolidated Balance Sheets.

[0000950170-22-002054:notes:221]
Components of gross profit related to sales-type lease recognized at the lease commencement date and interest and dividend income, included in the Consolidated Statements of (Loss) Income for the twelve months ended December 31, 2021 and 2020 were as follows:

[0000950170-22-002054:notes:222]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Revenue - Network Solutions |  | $ | 22 |  |  | $ | 78 |  |  | $ | 1,723 |  |
| Cost of revenue - Network Solutions |  |  | 5 |  |  |  | 32 |  |  |  | 675 |  |
| Gross profit |  | $ | 17 |  |  | $ | 46 |  |  | $ | 1,048 |  |
| Interest and dividend income |  | $ | 27 |  |  | $ | 42 |  |  | $ | 357 |  |

[0000950170-22-002054:notes:223]
As of December 31, 2021 future minimum lease payments to be received from sales-type leases were as follows:

[0000950170-22-002054:notes:224]
| (In thousands) |  | Amount |  |
| 2022 |  | $ | 92 |  |
| 2023 |  |  | 4 |  |
| 2024 |  |  | — |  |
| 2025 |  |  | — |  |
| 2026 |  |  | — |  |
| Thereafter |  |  | — |  |
| Total |  | $ | 96 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-22-002054:notes:225]
Note 10 – Goodwill

[0000950170-22-002054:notes:226]
Goodwill was $7.0 million as of December 31, 2021 and December 31, 2020 of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-22-002054:notes:227]
Note 11 – Intangible Assets

[0000950170-22-002054:notes:228]
Intangible assets as of December 31, 2021 and 2020, consisted of the following:

[0000950170-22-002054:notes:229]
|  |  | 2021 |  |  | 2020 |  |
| (In thousands) |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |
| Customer relationships |  | $ | 20,796 |  |  | $ | (9,906 | ) |  | $ | 10,890 |  |  | $ | 21,123 |  |  | $ | (8,055 | ) |  | $ | 13,068 |  |
| Developed technology |  |  | 8,200 |  |  |  | (3,683 | ) |  |  | 4,517 |  |  |  | 8,200 |  |  |  | (2,546 | ) |  |  | 5,654 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (2,486 | ) |  |  | 3,414 |  |  |  | 5,900 |  |  |  | (1,830 | ) |  |  | 4,070 |  |
| Supplier relationships |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2,800 |  |  |  | (2,800 | ) |  |  | — |  |
| Licensing agreements |  |  | 560 |  |  |  | (225 | ) |  |  | 335 |  |  |  | 560 |  |  |  | (152 | ) |  |  | 408 |  |
| Patents |  |  | 500 |  |  |  | (363 | ) |  |  | 137 |  |  |  | 500 |  |  |  | (294 | ) |  |  | 206 |  |
| Trade names |  |  | 210 |  |  |  | (210 | ) |  |  | — |  |  |  | 210 |  |  |  | (146 | ) |  |  | 64 |  |
| Total |  | $ | 36,166 |  |  | $ | (16,873 | ) |  | $ | 19,293 |  |  | $ | 39,293 |  |  | $ | (15,823 | ) |  | $ | 23,470 |  |

[0000950170-22-002054:notes:230]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. No impairment losses of intangible assets were recorded during the year ended December 31, 2021, 2020 and 2019.

[0000950170-22-002054:notes:231]
Amortization expense was $4.1 million, $4.4 million and $5.3 million for the years ended December 31, 2021, 2020 and 2019, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of (Loss) Income.

[0000950170-22-002054:notes:232]
As of December 31, 2021, estimated future amortization expense of intangible assets was as follows:

[0000950170-22-002054:notes:233]
| (In thousands) |  | Amount |  |
| 2022 |  | $ | 3,475 |  |
| 2023 |  |  | 3,323 |  |
| 2024 |  |  | 3,229 |  |
| 2025 |  |  | 3,025 |  |
| 2026 |  |  | 1,986 |  |
| Thereafter |  |  | 4,255 |  |
| Total |  | $ | 19,293 |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-22-002054:notes:234]
Note 12 – Revolving Credit Agreement

[0000950170-22-002054:notes:235]
On November 2, 2021, the Company, as borrower, renewed its Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 3, 2022, subject to earlier termination upon the concurrence of certain events of default. The Company entered into the Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. During the fourth quarter of 2021, the Company made draws totaling $10.0 million under the Revolving Credit Agreement all of which had been repaid as of December 31, 2021. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company. The Company must be in compliance with all covenants to be able to draw on the line of credit.


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0000950170-22-002054:notes:236]
Note 13 – Alabama State Industrial Development Authority Financing

[0000950170-22-002054:notes:237]
In conjunction with the 1995 expansion of our Huntsville, Alabama facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, in January 1995, the Authority issued $20.0 million of its taxable revenue bonds (the “Taxable Revenue Bonds”) and loaned the proceeds from the sale of the Taxable Revenue Bonds to the Company. Further advances on the Taxable Revenue Bonds were made by the Authority, bringing the total amount to $50.0 million. The Taxable Revenue Bonds bore interest, payable monthly with an interest rate of 2% per annum. The Taxable Revenue Bonds aggregate principal amount of $24.6 million matured on January 1, 2020 and was repaid in full on January 2, 2020, using the funds held in a certificate of deposit by the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-22-002054:notes:238]
Note 14 – Income Taxes

[0000950170-22-002054:notes:239]
The components of income tax expense (benefit) for the years ended December 31, 2021, 2020 and 2019 are as follows:

[0000950170-22-002054:notes:240]
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Current |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 11 |  |  | $ | (10,574 | ) |  | $ | (518 | ) |
| State |  |  | (63 | ) |  |  | (329 | ) |  |  | (1,065 | ) |
| International |  |  | 4,166 |  |  |  | 3,635 |  |  |  | (282 | ) |
| Total Current |  |  | 4,114 |  |  |  | (7,268 | ) |  |  | (1,865 | ) |
| Deferred |  |  |  |  |  |  |  |  |  |
| Federal |  |  | — |  |  |  | — |  |  |  | 24,801 |  |
| State |  |  | — |  |  |  | — |  |  |  | 5,815 |  |
| International |  |  | (1,784 | ) |  |  | (1,356 | ) |  |  | (546 | ) |
| Total Deferred |  |  | (1,784 | ) |  |  | (1,356 | ) |  |  | 30,070 |  |
| Total Income Tax Expense (Benefit) |  | $ | 2,330 |  |  | $ | (8,624 | ) |  | $ | 28,205 |  |

[0000950170-22-002054:notes:241]
The effective income tax rate differs from the federal statutory rate due to the following:

[0000950170-22-002054:notes:242]
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Tax provision computed at the federal statutory rate |  |  | 21.00 | % |  |  | 21.00 | % |  |  | 21.00 | % |
| State income tax provision, net of federal benefit |  |  | 13.33 |  |  |  | 11.10 |  |  |  | 6.97 |  |
| Federal research credits |  |  | 53.77 |  |  |  | 57.63 |  |  |  | 15.53 |  |
| Foreign taxes |  |  | (4.69 | ) |  |  | (17.83 | ) |  |  | 2.83 |  |
| Tax-exempt income |  |  | 3.75 |  |  |  | 1.93 |  |  |  | 0.49 |  |
| State tax incentives |  |  | — |  |  |  | — |  |  |  | 3.85 |  |
| Change in valuation allowance |  |  | (75.26 | ) |  |  | 44.79 |  |  |  | (172.82 | ) |
| Non-deductible transaction costs |  |  | (39.48 | ) |  |  | — |  |  |  | — |  |
| Foreign tax credits |  |  | 0.14 |  |  |  | 17.90 |  |  |  | 16.69 |  |
| Stock-based compensation |  |  | 10.74 |  |  |  | (23.36 | ) |  |  | (6.01 | ) |
| Withholding taxes |  |  | 0.14 |  |  |  | (20.83 | ) |  |  | — |  |
| Alabama law change |  |  | (25.39 | ) |  |  | — |  |  |  | — |  |
| Impact of CARES Act |  |  | — |  |  |  | 45.65 |  |  |  | — |  |
| Return to accrual |  |  | 9.48 |  |  |  | — |  |  |  | — |  |
| Global intangible low-taxed income ("GILTI") |  |  | (4.29 | ) |  |  | (0.49 | ) |  |  | (1.87 | ) |
| Other, net |  |  | (0.19 | ) |  |  | 0.56 |  |  |  | (0.49 | ) |
| Effective Tax Rate |  |  | (36.95 | )% |  |  | 138.05 | % |  |  | (113.83 | )% |

[0000950170-22-002054:notes:243]
(Loss) income before expense (benefit) for income taxes for the years ended December 31, 2021, 2020 and 2019 is as follows:

[0000950170-22-002054:notes:244]
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| U.S. entities |  | $ | (14,982 | ) |  | $ | (12,833 | ) |  | $ | (29,829 | ) |
| International entities |  |  | 8,677 |  |  |  | 6,587 |  |  |  | 5,052 |  |
| Total |  | $ | (6,305 | ) |  | $ | (6,246 | ) |  | $ | (24,777 | ) |

[0000950170-22-002054:notes:245]
(Loss) income before expense (benefit) for income taxes for international entities reflects (loss) income based on statutory transfer pricing agreements. This amount does not correlate to consolidated international revenue, which occurs from our U.S. entity.

[0000950170-22-002054:notes:246]
Deferred income taxes on the Consolidated Balance Sheets result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The significant components of current and non-current deferred taxes as of December 31, 2021 and 2020 consist of the following:

[0000950170-22-002054:notes:247]
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Inventory |  | $ | 9,538 |  |  | $ | 8,882 |  |
| Accrued expenses |  |  | 3,851 |  |  |  | 2,331 |  |
| Deferred compensation |  |  | 7,027 |  |  |  | 6,714 |  |
| Stock-based compensation |  |  | 1,469 |  |  |  | 1,971 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 124 |  |  |  | 149 |  |
| Pensions |  |  | 6,061 |  |  |  | 8,554 |  |
| Foreign losses |  |  | 2,862 |  |  |  | 2,590 |  |
| State losses and credit carry-forwards |  |  | 5,914 |  |  |  | 5,509 |  |
| Federal loss and research carry-forwards |  |  | 21,606 |  |  |  | 17,323 |  |
| Lease liabilities |  |  | 1,471 |  |  |  | 1,588 |  |
| Capitalized research and development expenditures |  |  | 9,349 |  |  |  | 11,832 |  |
| Valuation allowance |  |  | (50,564 | ) |  |  | (45,818 | ) |
| Total Deferred Tax Assets |  |  | 18,708 |  |  |  | 21,625 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Property, plant and equipment |  |  | (3,590 | ) |  |  | (4,546 | ) |
| Intellectual property |  |  | (3,230 | ) |  |  | (4,375 | ) |
| Right of use lease assets |  |  | (1,459 | ) |  |  | (1,585 | ) |
| Investments |  |  | (1,350 | ) |  |  | (1,250 | ) |
| Total Deferred Tax Liabilities |  |  | (9,629 | ) |  |  | (11,756 | ) |
| Net Deferred Tax Assets |  | $ | 9,079 |  |  | $ | 9,869 |  |

[0000950170-22-002054:notes:248]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was signed into law. Subsequently, the Internal Revenue Service (“IRS”) released its final GILTI regulations on July 9, 2020. The passage of the CARES Act and subsequent issuance of the GILTI final regulations together resulted in the Company’s recognition of a tax benefit in the amount of $10.8 million during 2020, $7.9 million of which related to the utilization of deferred tax assets which had previously been offset with a valuation allowance and $2.9 million primarily related to the tax rate differential on carrying back losses from 2018 and 2019 tax years to prior years in which the U.S. Corporate tax rate was 35% versus the current 21% federal tax rate.

[0000950170-22-002054:notes:249]
On February 12, 2021, the Alabama Business Tax Competitiveness Act (the "Act") was signed into law. As a result of the Act, we recognized an expense of $1.6 million in the three months ended March 31, 2021 related to the revaluation of our deferred tax assets, which was offset by changes in our valuation allowance previously recorded against our domestic deferred tax assets.

[0000950170-22-002054:notes:250]
During the three months ended September 30, 2021, Management decided to pursue a claim for refund related to the revocation of our IRC Section 59(e) election that was made on our originally filed 2018 U.S. federal tax return. The Company filed a related carryback claim of net operating losses generated in 2018 to prior years as allowed under the CARES Act that was passed in 2020. An IRS Section 59(e) election is generally non-revocable except in cases for which IRS Commissioner’s approval is given. Approval is granted only in rare and unusual circumstances. We filed a private letter ruling (“PLR”) request to revoke our election. During the three months ended December 31, 2021, a response to our PLR was published denying our request to revoke the previously made 59(e). As a result of these filings, and Management’s position to pursue them through appeals, we have established a receivable in the amount of $15.2 million and a deferred tax asset related to additional research and development credit carryforward in the amount of $1.8 million that would be available if our revocation request is successful, offset with an uncertain tax liability of $17.0 million.

[0000950170-22-002054:notes:251]
As of December 31, 2021 and 2020, non-current deferred taxes reflected deferred taxes on net unrealized gains and losses on available-for-sale investments and deferred taxes on unrealized losses in our pension plan. The net change in non-current deferred taxes associated with these items, which resulted in a deferred tax expense of $1.6 million and a deferred tax benefit of $0.1 million in 2021 and 2020, respectively, was recorded as an adjustment to other comprehensive (loss) income, presented in the Consolidated Statements of Comprehensive (Loss) Income.

[0000950170-22-002054:notes:252]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. Our assessment of the realizability of our deferred tax assets includes the evaluation of evidence, some of which requires significant judgment, including historical operating results, the evaluation of a three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and additional valuation allowance or a partial or full release of the valuation allowance become necessary, it could have a material effect on our consolidated financial statements.

[0000950170-22-002054:notes:253]
As of December 31, 2021 and 2020, the Company had gross deferred tax assets totaling $59.6 million offset by a valuation allowance totaling $50.6 million and gross deferred tax assets totaling $55.7 million offset by a valuation allowance of $45.8 million, respectively. Of the current valuation allowance, $48.3 million was established against our domestic deferred tax assets and the remaining $2.3 million is related to foreign net operating loss and research and development credit carryforwards where we lacked sufficient activity to realize those deferred tax assets. The change in our valuation allowance for the year ending December 31, 2021 was an increase of $4.7 million. The change in the valuation allowance was primarily related to increases in our deferred tax assets during the year related to generated federal research and development credit carryforwards. As of December 31, 2021, the remaining $9.1 million in deferred tax assets that were not offset by a valuation allowance were located in various foreign jurisdictions where the Company believed it was more likely than not it will realize these deferred tax assets.

[0000950170-22-002054:notes:254]
Supplemental balance sheet information related to deferred tax assets as of December 31, 2021 and 2020 were as follows:

[0000950170-22-002054:notes:255]
|  |  | December 31, 2021 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 48,265 |  |  | $ | (48,265 | ) |  | $ | — |  |
| International |  |  | 11,378 |  |  |  | (2,299 | ) |  |  | 9,079 |  |
| Total |  | $ | 59,643 |  |  | $ | (50,564 | ) |  | $ | 9,079 |  |

[0000950170-22-002054:notes:256]
|  |  | December 31, 2020 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 43,791 |  |  | $ | (43,791 | ) |  | $ | — |  |
| International |  |  | 11,896 |  |  |  | (2,027 | ) |  |  | 9,869 |  |
| Total |  | $ | 55,687 |  |  | $ | (45,818 | ) |  | $ | 9,869 |  |

[0000950170-22-002054:notes:257]
As of December 31, 2021 and 2020, the deferred tax assets for foreign and domestic loss carry-forwards, research and development tax credits, unamortized research and development costs and state credit carry-forwards totaled $39.7 million and $37.3 million, respectively. As of December 31, 2021, $27.3 million of these deferred tax assets will expire at various times between 2022 and 2041. The remaining deferred tax assets will either amortize through 2029 or carryforward indefinitely.

[0000950170-22-002054:notes:258]
As of December 31, 2021 and 2020, respectively, our cash and cash equivalents were $56.6 million and $60.2 million and short-term investments were $0.4 million and $3.1 million, which provided available short-term liquidity of $57.0 million and $63.3 million. Of these amounts, our foreign subsidiaries held cash of $47.7 million and $49.7 million, respectively, representing approximately 83.5% and 78.5% of available short-term liquidity, which is used to fund ongoing liquidity needs of these subsidiaries. As part of our restructuring plan, the Company’s assertion on being indefinitely reinvested changed in a particular jurisdiction in a previous year. The Company has a withholding tax liability of $0.7 million as of December 31, 2021 and 2020. The Company maintains its assertion in all other jurisdictions that it is indefinitely reinvesting its funds held in foreign jurisdictions outside of the U.S., except to the extent any of these funds can be repatriated without withholding tax. However, if all of these funds were repatriated to the U.S., or used for U.S. operations, certain amounts could be subject to tax. Due to the timing and circumstances of repatriation of such earnings, if any, it is not practicable to determine the amount of funds subject to unrecognized deferred tax liability.

[0000950170-22-002054:notes:259]
During 2021, 2020 and 2019, no income tax benefit or expense was recorded for stock options exercised as an adjustment to equity.

[0000950170-22-002054:notes:260]
The change in the unrecognized income tax benefits for the years ended December 31, 2021, 2020 and 2019 were as follows:

[0000950170-22-002054:notes:261]
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 1,078 |  |  | $ | 1,487 |  |  | $ | 1,868 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | 17,025 |  |  |  | 4 |  |  |  | — |  |
| Current year |  |  | 136 |  |  |  | 165 |  |  |  | 161 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | (27 | ) |  |  | — |  |  |  | (71 | ) |
| Expiration of applicable statute of limitations |  |  | (376 | ) |  |  | (578 | ) |  |  | (471 | ) |
| Balance at end of period |  | $ | 17,836 |  |  | $ | 1,078 |  |  | $ | 1,487 |  |

[0000950170-22-002054:notes:262]
As of December 31, 2021, 2020 and 2019, our total liability for unrecognized tax benefits was $17.8 million, $1.1 million and $1.5 million, respectively, of which $17.8 million, $1.0 million and $1.4 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of December 31, 2021, 2020 and 2019, the balances of accrued interest and penalties were $0.2 million, $0.3 million and $0.5 million, respectively.

[0000950170-22-002054:notes:263]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date, unless a resolution is reached regarding the appeal of our PLR denial noted above. We file income tax returns in the U.S. for federal and various state jurisdictions and several foreign jurisdictions. We are not currently under audit by the Internal Revenue Service. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2018.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-22-002054:notes:264]
Note 15 – Employee Benefit Plans

[0000950170-22-002054:notes:265]
Pension Benefit Plan

[0000950170-22-002054:notes:266]
We maintain a defined benefit pension plan covering employees in certain foreign countries.

[0000950170-22-002054:notes:267]
The pension benefit plan obligations and funded status as of December 31, 2021 and 2020, were as follows:

[0000950170-22-002054:notes:268]
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 50,927 |  |  | $ | 43,902 |  |
| Service cost |  |  | 1,229 |  |  |  | 1,270 |  |
| Interest cost |  |  | 339 |  |  |  | 444 |  |
| Actuarial gain - experience |  |  | (750 | ) |  |  | (744 | ) |
| Actuarial (gain) loss - assumptions |  |  | (3,327 | ) |  |  | 2,458 |  |
| Benefit payments |  |  | (756 | ) |  |  | (509 | ) |
| Effects of foreign currency exchange rate changes |  |  | (3,498 | ) |  |  | 4,106 |  |
| Projected benefit obligation at end of period |  |  | 44,164 |  |  |  | 50,927 |  |
| Change in plan assets: |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  |  | 32,263 |  |  |  | 28,016 |  |
| Actual gain on plan assets |  |  | 2,943 |  |  |  | 1,744 |  |
| Contributions |  |  | — |  |  |  | 24 |  |
| Effects of foreign currency exchange rate changes |  |  | (2,444 | ) |  |  | 2,479 |  |
| Fair value of plan assets at end of period |  |  | 32,762 |  |  |  | 32,263 |  |
| Unfunded status at end of period |  | $ | (11,402 | ) |  | $ | (18,664 | ) |

[0000950170-22-002054:notes:269]
The accumulated benefit obligation was $44.2 million and $50.9 million as of December 31, 2021 and 2020, respectively. The decrease in the accumulated benefit obligation, projected benefit obligation and the actuarial loss was primarily attributable to an increase in the discount rate during 2021.

[0000950170-22-002054:notes:270]
The net amounts recognized in the Consolidated Balance Sheets for the unfunded pension liability as of December 31, 2021 and 2020 were as follows:

[0000950170-22-002054:notes:271]
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Current liability |  | $ | — |  |  | $ | — |  |
| Pension liability |  |  | 11,402 |  |  |  | 18,664 |  |
| Total |  | $ | 11,402 |  |  | $ | 18,664 |  |

[0000950170-22-002054:notes:272]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Consolidated Statements of (Loss) Income. The components of net periodic pension cost and amounts recognized in other comprehensive (loss) income for the years ended December 31, 2021, 2020 and 2019 were as follows:

[0000950170-22-002054:notes:273]
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,229 |  |  | $ | 1,270 |  |  | $ | 1,471 |  |
| Interest cost |  |  | 339 |  |  |  | 444 |  |  |  | 634 |  |
| Expected return on plan assets |  |  | (1,842 | ) |  |  | (1,679 | ) |  |  | (1,392 | ) |
| Amortization of actuarial losses |  |  | 1,088 |  |  |  | 970 |  |  |  | 795 |  |
| Net periodic benefit cost |  |  | 814 |  |  |  | 1,005 |  |  |  | 1,508 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive (loss) income: |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | (4,984 | ) |  |  | 1,784 |  |  |  | 2,488 |  |
| Amortization of actuarial losses |  |  | (825 | ) |  |  | (1,212 | ) |  |  | (771 | ) |
| Amount recognized in other comprehensive (loss) income |  |  | (5,809 | ) |  |  | 572 |  |  |  | 1,717 |  |
| Total recognized in net periodic benefit cost and other comprehensive (loss) income |  | $ | (4,995 | ) |  | $ | 1,577 |  |  | $ | 3,225 |  |

[0000950170-22-002054:notes:274]
The amounts recognized in accumulated other comprehensive (loss) income as of December 31, 2021 and 2020 were as follows:

[0000950170-22-002054:notes:275]
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Net actuarial loss |  | $ | (7,736 | ) |  | $ | (13,545 | ) |

[0000950170-22-002054:notes:276]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations.

[0000950170-22-002054:notes:277]
The weighted-average assumptions that were used to determine the net periodic benefit cost for the years ended December 31, 2021, 2020 and 2019 were as follows:

[0000950170-22-002054:notes:278]
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Discount rate |  |  | 1.16 | % |  |  | 1.00 | % |  |  | 1.75 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.00 | % |  |  | 2.00 | % |
| Expected long-term rates of return |  |  | 5.90 | % |  |  | 5.90 | % |  |  | 5.90 | % |

[0000950170-22-002054:notes:279]
The weighted-average assumptions that were used to determine the benefit obligation as of December 31, 2021 and 2020:

[0000950170-22-002054:notes:280]
|  |  | 2021 |  |  | 2020 |  |
| Discount rate |  |  | 1.16 | % |  |  | 0.69 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.00 | % |

[0000950170-22-002054:notes:281]
Actuarial gains and losses are recorded in accumulated other comprehensive (loss) income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants.

[0000950170-22-002054:notes:282]
We do not anticipate making any contributions to the pension plan in 2022.

[0000950170-22-002054:notes:283]
The following pension benefit payments, which reflect expected future service, as appropriate, are expected to be paid to participants:

[0000950170-22-002054:notes:284]
| (In thousands) |  |  |  |
| 2022 |  | $ | 1,088 |  |
| 2023 |  |  | 1,002 |  |
| 2024 |  |  | 1,204 |  |
| 2025 |  |  | 1,244 |  |
| 2026 |  |  | 1,370 |  |
| 2027 - 2031 |  |  | 8,894 |  |
| Total |  | $ | 14,802 |  |

[0000950170-22-002054:notes:285]
•
Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-22-002054:notes:286]
We have categorized our cash equivalents and our investments held at fair value into this hierarchy as follows:

[0000950170-22-002054:notes:287]
|  |  | Fair Value Measurements at December 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash and cash equivalents |  | $ | 801 |  |  | $ | 801 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 7,528 |  |  |  | 7,528 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 5,721 |  |  |  | 5,721 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |
| Global equity |  |  | 12,170 |  |  |  | 12,170 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 2,919 |  |  |  | 2,919 |  |  |  | — |  |  |  | — |  |
| Emerging markets |  |  | 2,259 |  |  |  | 2,259 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 235 |  |  |  | 235 |  |  |  | — |  |  |  | — |  |
| Global real estate fund |  |  | 1,129 |  |  |  | 1,129 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 31,961 |  |  |  | 31,961 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 32,762 |  |  | $ | 32,762 |  |  | $ | — |  |  | $ | — |  |

[0000950170-22-002054:notes:288]
|  |  | Fair Value Measurements at December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash and cash equivalents |  | $ | 1,935 |  |  | $ | 1,935 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 6,746 |  |  |  | 6,746 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 5,971 |  |  |  | 5,971 |  |  |  | — |  |  |  | — |  |
| Emerging markets bonds |  |  | 307 |  |  |  | 307 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |
| Global equity |  |  | 11,638 |  |  |  | 11,638 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 2,515 |  |  |  | 2,515 |  |  |  | — |  |  |  | — |  |
| Emerging markets |  |  | 1,848 |  |  |  | 1,848 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 198 |  |  |  | 198 |  |  |  | — |  |  |  | — |  |
| Global real estate fund |  |  | 799 |  |  |  | 799 |  |  |  | — |  |  |  | — |  |
| Managed futures fund |  |  | 306 |  |  |  | 306 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 30,328 |  |  |  | 30,328 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 32,263 |  |  | $ | 32,263 |  |  | $ | — |  |  | $ | — |  |

[0000950170-22-002054:notes:289]
Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. The current target allocation ranges by asset class are 50% for bond funds, 40% for equity funds and 10% for cash, real estate and managed futures. The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies.

[0000950170-22-002054:notes:290]
The investment policy is periodically reviewed by the Company and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations.

[0000950170-22-002054:notes:291]
401(k) Savings Plan

[0000950170-22-002054:notes:292]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (the “Savings Plan”) for the benefit of eligible employees. The Savings Plan is intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (the “Code”), and is intended to be a “safe harbor” 401(k) plan under Code Section 401(k)(12). The Savings Plan allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plan also requires us to contribute a “safe harbor” amount each year. We match up to 4% of employee contributions (100% of an employee’s first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s one-year anniversary date. In calculating our matching contribution, compensation up to the statutory maximum under the Code is used ($290,000 for 2021). All matching contributions under the Savings Plan vest immediately. Employer contribution expense and plan administration costs for the Savings Plan amounted to approximately $3.9 million, $4.0 million and $4.4 million in 2021, 2020 and 2019, respectively.

[0000950170-22-002054:notes:293]
Deferred Compensation Plans

[0000950170-22-002054:notes:294]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors.

[0000950170-22-002054:notes:295]
The ADTRAN, Inc. Deferred Compensation Program for Employees is offered as a supplement to our tax-qualified 401(k) plan and is available to certain executive management employees who have been designated by our Board of Directors. This deferred compensation plan allows participants to defer all or a portion of certain specified bonuses and up to 25% of remaining cash compensation and permits us to make matching contributions on a discretionary basis without the limitations that apply to the 401(k) plan. To date, we have not made any matching contributions under this plan. We also maintain the ADTRAN, Inc. Equity Deferral Program for Employees. Under this plan, participants may elect to defer all or a portion of their vested PSUs and RSUs to the plan. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the participant.

[0000950170-22-002054:notes:296]
For our Board of Directors, we maintain the ADTRAN, Inc. Deferred Compensation Program for Directors. This program allows our Board of Directors to defer all or a portion of monetary remuneration paid to the Director, including, but not limited to, meeting fees and annual retainers. We also maintain the ADTRAN, Inc. Equity Deferral Program for Directors. Under this plan, participants may elect to defer all or a portion of their vested restricted stock awards. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the director.

[0000950170-22-002054:notes:297]
We have set aside the plan assets for all plans in a rabbi trust (the “Trust”) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant and the participant’s bookkeeping account is credited with the earnings and losses attributable to those investments. Benefits are scheduled to be distributed six months after termination of employment in a single lump sum payment or annual installments paid over a three or ten-year term based on the participant’s election. Distributions will be made on a pro-rata basis from each of the hypothetical investments of the participant’s account in cash. Any whole shares of ADTRAN, Inc. common stock that are distributed will be distributed in-kind.

[0000950170-22-002054:notes:298]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging from equities to money market instruments. These mutual funds are publicly quoted and reported at fair value. The fair value of the assets held by the Trust and the amounts payable to the plan participants as of December 31, 2021 and 2020 were as follows:

[0000950170-22-002054:notes:299]
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |
| Long-term investments |  | $ | 26,935 |  |  | $ | 23,891 |  |
| Total Fair Value of Plan Assets |  | $ | 26,935 |  |  | $ | 23,891 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |
| Deferred compensation liability |  | $ | 31,383 |  |  | $ | 25,866 |  |
| Total Amounts Payable to Plan Participants |  | $ | 31,383 |  |  | $ | 25,866 |  |

[0000950170-22-002054:notes:300]
The Trust held $4.1 million and $2.8 million of common stock in the Company as of December 31, 2021 and 2020, respectively. Shares of the Company held by the Trust are recorded at cost and classified as treasury stock on the Consolidated Balance Sheet.

[0000950170-22-002054:notes:301]
Interest and dividend income of the Trust are included in interest and dividend income in the accompanying 2021, 2020 and 2019 Consolidated Statements of (Loss) Income. Changes in the fair value of the plan assets held by the Trust have been included in other income (expense) in the accompanying 2021, 2020 and 2019 Consolidated Statements of (Loss) Income. Changes in the fair value of the deferred compensation liability are included as selling, general and administrative expense in the accompanying 2021, 2020 and 2019 Consolidated Statements of (Loss) Income. Based on the changes in the total fair value of the Trust’s assets, we recorded deferred compensation income in 2021, 2020 and 2019 of $0.9 million, $4.3 million and $3.6 million, respectively.

[0000950170-22-002054:notes:302]
Retiree Medical Coverage

[0000950170-22-002054:notes:303]
Medical, dental and prescription drug coverage is provided to certain spouses and former spouses of current and former officers on the same terms as provided to our active officers for up to 30 years. As of December 31, 2021 and 2020, this liability totaled $0.3 million and $0.2 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-22-002054:notes:304]
Note 16 – Segment Information and Major Customers

[0000950170-22-002054:notes:305]
The Chief Operating Decision Maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. Network Solutions includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes a portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services.

[0000950170-22-002054:notes:306]
The performance of each segment is evaluated based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense) and income tax (expense) benefit are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-22-002054:notes:307]
The following table presents information about revenue and gross profit of our reportable segments for each of the years ended December 31, 2021, 2020 and 2019:

[0000950170-22-002054:notes:308]
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 498,834 |  |  | $ | 190,993 |  |  | $ | 438,015 |  |  | $ | 193,789 |  |  | $ | 455,226 |  |  | $ | 191,549 |  |
| Services & Support |  |  | 64,170 |  |  |  | 27,384 |  |  |  | 68,495 |  |  |  | 23,762 |  |  |  | 74,835 |  |  |  | 27,618 |  |
| Total |  | $ | 563,004 |  |  | $ | 218,377 |  |  | $ | 506,510 |  |  | $ | 217,551 |  |  | $ | 530,061 |  |  | $ | 219,167 |  |

[0000950170-22-002054:notes:309]
For the years ended December 31, 2021, 2020 and 2019, $1.2 million, $1.4 million and $1.7 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the years ended December 31, 2021, 2020 and 2019, $14 thousand, $32 thousand and $29 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0000950170-22-002054:notes:310]
In addition to our reportable segments, revenue is also reported for the following three categories – (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products.

[0000950170-22-002054:notes:311]
Additional Information

[0000950170-22-002054:notes:312]
The following table presents revenue information by geographic area for the years ended December 31, 2021, 2020 and 2019:

[0000950170-22-002054:notes:313]
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| United States |  | $ | 374,600 |  |  | $ | 352,079 |  |  | $ | 300,853 |  |
| Germany |  |  | 65,229 |  |  |  | 74,882 |  |  |  | 78,062 |  |
| United Kingdom |  |  | 56,355 |  |  |  | 13,799 |  |  |  | 2,569 |  |
| Mexico |  |  | 4,616 |  |  |  | 4,087 |  |  |  | 90,795 |  |
| Other international |  |  | 62,204 |  |  |  | 61,663 |  |  |  | 57,782 |  |
| Total |  | $ | 563,004 |  |  | $ | 506,510 |  |  | $ | 530,061 |  |

[0000950170-22-002054:notes:314]
Customers comprising more than 10% of revenue can change from year to year. Single customers comprising more than 10% of revenue in 2021 included one customer, at 18%, which was a distributor and was included in both our Network Solutions and Services & Support segments. Single customers comprising more than 10% of revenue in 2020 included three customers at 15%, 12% and 10% and was included in both our Network Solutions and Services & Support segments. Single customers comprising more than 10% of revenue in 2019 included three customers at 19%, 17% and 13% and was included in both our Network Solutions and Services & Support segments. Other than those with more than 10% of revenue disclosed above our next five largest customers can change, and have historically changed, from year-to-year. The next five largest customers combined represented 38%, 34% and 28% of total revenue in 2021, 2020 and 2019, respectively.

[0000950170-22-002054:notes:315]
As of December 31, 2021, property, plant and equipment, net totaled $55.8 million, which included $53.0 million held in the U.S. and $2.8 million held outside the U.S. As of December 31, 2020, property, plant and equipment, net totaled $62.4 million, which included $58.4 million held in the U.S. and $4.0 million held outside the U.S. Property, plant and equipment, net is reported on a Company-wide, functional basis only.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-22-002054:notes:316]
Note 17 – Commitments and Contingencies

[0000950170-22-002054:notes:317]
Shareholder Derivative Lawsuit

[0000950170-22-002054:notes:318]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and certain current and former members of its Board of Directors. The derivative suit alleges, among other things, that the defendants made or caused the Company to make materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The case was temporarily stayed pending an order on the defendants’ motion to dismiss in a separate securities class action case that included similar factual allegations, Burbridge v. ADTRAN, Inc., et al., Case No. 5:20-cv-00050-LCB (N.D. Ala.). The Burbridge case was dismissed on March 31, 2021, and the time to appeal the dismissal has expired, such that the dismissal is now final.  Following the dismissal, the plaintiff in the shareholder derivative suit sent a demand letter dated June 29, 2021 to ADTRAN’s Board of Directors.  The letter contains similar allegations to those made in the plaintiff’s filed complaint and in the now dismissed securities class action, and it demands, among other things, that the Board of Directors commence an investigation into the alleged wrongdoing. On December 10, 2021, after investigating the allegations in the demand with the assistance of independent counsel, the directors (Mr. Stanton abstaining) concluded that pursuing the claims asserted in the demand would not be in the Company's best interests and exercised their business judgment to refuse the demand. Since that time, the parties to the derivative litigation have stipulated that plaintiff will either dismiss his complaint or seek to amend it pursuant to a schedule to be ordered by the Court. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with the derivative lawsuit or the demand letter.

[0000950170-22-002054:notes:319]
Other Legal Matters

[0000950170-22-002054:notes:320]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in

[0000950170-22-002054:notes:321]
certain jurisdictions. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

[0000950170-22-002054:notes:322]
Performance Bonds

[0000950170-22-002054:notes:323]
Certain contracts, customers and/or jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2021, we had commitments related to these bonds totaling $22.9 million which expire at various dates through April 2025. As of December 31, 2020, we had commitments related to these bonds totaling $15.2 million. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-22-002054:notes:324]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.3 million as of December 31, 2021, of which $0.2 million is included in restricted cash and $18.1 million is included in long-term investments on the Consolidated Balance Sheets. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of December 31, 2021 and through the date of this report, the Company was in compliance with all contractual requirements under the letter of credit.

[0000950170-22-002054:notes:325]
Investment Commitment

[0000950170-22-002054:notes:326]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of December 31, 2021.


## us-gaap:CreditLossFinancialInstrumentTextBlock

[0000950170-22-002054:notes:327]
Note 18 – Current Expected Credit Losses

[0000950170-22-002054:notes:328]
Under ASC 326 – Financial Instruments – Credit Losses, the Company estimates credit losses for the contractual life of assets that are measured at amortized cost and are within the scope of this guidance, which includes accounts receivable, net investment in sales-type leases, contract assets under the revenue recognition model and outstanding notes receivable. Where appropriate, the Company pools assets if similar risk characteristics exist. Additionally, the Company analyzes its available-for-sale debt securities for impairment and records a credit loss allowance as needed.

[0000950170-22-002054:notes:329]
Assets Measured at Amortized Cost

[0000950170-22-002054:notes:330]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. Accounts receivable balances are considered past due when payment has not been received by the date indicated on the relevant invoice or based on agreed upon terms between the customer and the Company.

[0000950170-22-002054:notes:331]
As of December 31, 2021, 2020 and January 1, 2020 (the “implementation date”), the Company’s net outstanding accounts receivable balance was $158.7 million, $98.8 million and $90.5 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The Company’s historical losses related to accounts receivable have been immaterial as evidenced by its historical allowance and write-offs due to collectability. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0000950170-22-002054:notes:332]
No allowance for credit losses was recorded for the year ended December 31, 2021, 2020 or on January 1, 2020 related to accounts receivable. The Company's allowance for credit losses related to accounts receivable was $0 as of December 31, 2021 and was less than $0.1 million as of December 31, 2020 and January 1, 2020, all of which was expensed prior to January 1, 2020.

[0000950170-22-002054:notes:333]
Contract Assets

[0000950170-22-002054:notes:334]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of December 31, 2021, 2020 and January 1, 2020 (the "implementation date"), the Company’s outstanding contract asset balance was $0.5 million, $0.1 million and $2.8 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0000950170-22-002054:notes:335]
No allowance for credit losses was recorded for the year ended December 31, 2021, 2020 or January 1, 2020 related to contract assets.

[0000950170-22-002054:notes:336]
Net Investment in Sales-Type Leases

[0000950170-22-002054:notes:337]
The Company is the lessor in sales-type lease arrangements for network equipment. As of December 31, 2021, 2020 and January 1, 2020 (the "implementation date"), the Company’s outstanding net investment in sales-type leases was less than $0.1 million, $0.8 million and $1.6 million, respectively, which is included in other receivables and other non-current assets on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to future receivables under its outstanding sales-type leases using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates.

[0000950170-22-002054:notes:338]
The following table presents amortized cost basis in sales-type leases based on payment activity:

[0000950170-22-002054:notes:339]
|  |  | Sales-Type Leases Amortized Cost Basis by Origination Year |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |  | 2018 |  |  | 2017 |  |  | Prior |  |  | Total |  |
| Payment performance |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Performing |  | $ | 14 |  |  | $ | 11 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 25 |  |
| Non-performing |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 14 |  |  | $ | 11 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 25 |  |

[0000950170-22-002054:notes:340]
Sales-type lease receivables are considered past due when payment has not been received based on agreed upon terms between the customer and the Company. No allowance for credit losses was recorded for the year ended December 31, 2021, 2020 or January 1, 2020 related to sales-type leases.

[0000950170-22-002054:notes:341]
Secured Loan Receivable

[0000950170-22-002054:notes:342]
The Company has a secured loan receivable totaling $0.4 million and $0.9 million as of December 31, 2021 and 2020, which originated in February 2019, and is included in long-term investments on the Consolidated Balance Sheets as of December 31, 2021 and 2020. The Company assessed the need for an allowance for credit losses related to its secured loan receivable using the historical loss-rate method as well as asset-specific risks. There have been no historical losses related to this receivable. Asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect the customer’s ability to repay the loan upon maturity, such as the customer’s current financial condition, credit rating specific to the customer as determined by a third party and current overall economic conditions, as well as a Company valuation prepared by a third party which was based on reasonable and supportable forecasts as provided by management. Accrued interest receivable on the secured loan receivable, which is included in other receivables on the Consolidated Balance Sheets totaled less than $0.1 million as of December 31, 2021 and 2020, and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election.

[0000950170-22-002054:notes:343]
No allowance for credit losses was recorded for the years ended December 31, 2021 and 2020 or on the implementation date related to the secured loan receivable.

[0000950170-22-002054:notes:344]
Off-Balance Sheet Arrangements

[0000950170-22-002054:notes:345]
The Company did not have any off-balance sheet arrangements as of December 31, 2021, 2020, or January 1, 2020.

[0000950170-22-002054:notes:346]
Available-for-Sale Debt Securities

[0000950170-22-002054:notes:347]
As of December 31, 2021, 2020, and January 1, 2020, the Company’s available-for-sale debt securities totaled $30.1 million, $45.1 million, and $37.7 million, respectively. These securities were analyzed at the individual investment level, by Committee on Uniform Securities Identification Procedures (“CUSIP”), to limit credit losses, if applicable, to reflect only the amount by which the fair value of the security was less than its amortized cost. The Company noted that, as of December 31, 2021, 2020 and January 1, 2020, there was no intent to sell any of its available-for-sale debt securities before maturity, and, therefore, the Company assessed the need for an allowance for each of its available-for-sale debt securities in which the fair value was less than its amortized cost as of December 31, 2021, 2020 and January 1, 2020. Accrued interest receivable on available-for-sale debt securities, which is included in other receivables on the Consolidated Balance Sheets as of December 31, 2021, 2020 and 2019, totaled less than $0.1 million, $0.1 million and $0.1 million as of December 31, 2021, 2020 and January 1, 2020, respectively and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election. Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Consolidated Statements of (Loss) Income.

[0000950170-22-002054:notes:348]
The Company had 174 positions in available-for-sale debt securities that were in an unrealized loss position as of December 31, 2021. See Note 6 for additional information.

[0000950170-22-002054:notes:349]
For those available-for-sale debt securities whose fair value was less than its amortized cost basis, the Company analyzed additional criteria such as adverse conditions specifically related to the security, an industry or geographic area, failure of the issuer of the security to make scheduled interest or principal payments, if applicable, and any changes to the rating of the security by a rating agency to determine if a credit loss existed. The Company used information provided by its investment manager to determine if any scheduled interest or principal payments had not been received and used a third party to determine if any changes to credit ratings had occurred. Principal and interest payments are considered past due when payment has not been received based on scheduled terms of each debt security. The Company ceases to accrue interest on debt securities on a case by case basis. As of December 31, 2021, the Company noted that all principal and interest payments had been received as scheduled and that there had been no changes in credit ratings year-over-year or period-over-period that warranted further review.

[0000950170-22-002054:notes:350]
No allowance for credit losses was recorded for the years ended December 31, 2021 or December 31, 2020 or on the implementation date related to the Company’s available-for-sale debt securities.


## us-gaap:EarningsPerShareTextBlock

[0000950170-22-002054:notes:351]
Note 19 – (Loss) Earnings per Share

[0000950170-22-002054:notes:352]
The calculations of basic and diluted (loss) earnings per share for the years ended December 31, 2021, 2020 and 2019 are as follows:

[0000950170-22-002054:notes:353]
| (In thousands, except for per share amounts) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |  |
| Net (Loss) Income |  | $ | (8,635 | ) |  | $ | 2,378 |  |  | $ | (52,982 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,582 |  |  |  | 47,996 |  |  |  | 47,836 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | 292 |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 48,582 |  |  |  | 48,288 |  |  |  | 47,836 |  |
| (Loss) earnings per share – basic |  | $ | (0.18 | ) |  | $ | 0.05 |  |  | $ | (1.11 | ) |
| (Loss) earnings per share – diluted |  | $ | (0.18 | ) |  | $ | 0.05 |  |  | $ | (1.11 | ) |

[0000950170-22-002054:notes:354]
For the years ended December 31, 2021, 2020 and 2019, less than 0.1 million, 0.1 million and 0.5 million shares, respectively, of unvested or unearned, as applicable, PSUs, RSUs and restricted stock were excluded from the calculation of diluted (loss) earnings per share due to their anti-dilutive effect.

[0000950170-22-002054:notes:355]
For the year ended December 31, 2021, 2020 and 2019, 0.3 million, 3.6 million and 5.2 million stock options, respectively, were outstanding but were not included in the computation of diluted (loss) earnings per share due to their exercise prices being greater than the average market price of the common shares during the quarter, making them anti-dilutive under the treasury stock method.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-22-002054:notes:356]
Note 20 – Restructuring

[0000950170-22-002054:notes:357]
During the second half of 2019, the Company initiated a restructuring plan to realign its expense structure with the reduction in revenue experienced in recent years and overall Company objectives. As part of this restructuring plan, the Company announced plans to reduce its overall operating expenses, both in the U.S. and internationally. Management continued to assess the efficiency of operations during 2020 and 2021 and, in turn, consolidated locations and personnel, among other things, where possible.

[0000950170-22-002054:notes:358]
In February 2019, the Company announced the restructuring of a certain portion of its workforce predominantly in Germany, which included the closure of the Company’s office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. Voluntary early retirement was offered to certain other employees and was announced in March 2019 and again in August 2020.

[0000950170-22-002054:notes:359]
The cumulative amount of restructuring expenses incurred as of December 31, 2021 for the restructuring plans was $12.7 million.

[0000950170-22-002054:notes:360]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Consolidated Balance Sheets as of December 31, 2021 and 2020, is as follows:

[0000950170-22-002054:notes:361]
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 4,186 |  |  | $ | 1,568 |  |
| Plus: Amounts charged to cost and expense |  |  | 411 |  |  |  | 6,229 |  |
| Less: Amounts paid |  |  | (3,083 | ) |  |  | (3,611 | ) |
| Balance at end of period |  | $ | 1,514 |  |  | $ | 4,186 |  |

[0000950170-22-002054:notes:362]
Restructuring expenses included in the Consolidated Statements of (Loss) Income are for the years ended December 31, 2021, 2020 and 2019:

[0000950170-22-002054:notes:363]
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Network solutions - cost of revenue |  | $ | 13 |  |  | $ | 220 |  |  | $ | 629 |  |
| Services & support - cost of revenue |  |  | 3 |  |  |  | 235 |  |  |  | 156 |  |
| Cost of revenue |  | $ | 16 |  |  | $ | 455 |  |  | $ | 785 |  |
| Selling, general and administrative expenses |  |  | 221 |  |  |  | 1,832 |  |  |  | 2,360 |  |
| Research and development expenses |  |  | 174 |  |  |  | 3,942 |  |  |  | 2,869 |  |
| Total restructuring expenses |  | $ | 411 |  |  | $ | 6,229 |  |  | $ | 6,014 |  |

[0000950170-22-002054:notes:364]
The following table represents the components of restructuring expense by geographic area for the years ended December 31, 2021, 2020 and 2019:

[0000950170-22-002054:notes:365]
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| United States |  | $ | 289 |  |  | $ | 2,234 |  |  | $ | 3,336 |  |
| International |  |  | 122 |  |  |  | 3,995 |  |  |  | 2,678 |  |
| Total restructuring expenses |  | $ | 411 |  |  | $ | 6,229 |  |  | $ | 6,014 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000950170-22-002054:notes:366]
Note 21 – Summarized Quarterly Financial Data (Unaudited)

[0000950170-22-002054:notes:367]
The following table presents unaudited quarterly operating results for each of the last eight fiscal quarters. This information has been prepared on a basis consistent with the audited financial statements and includes all adjustments, consisting only of normal recurring adjustments, considered necessary for a fair presentation of the data.

[0000950170-22-002054:notes:368]
Unaudited Quarterly Operating Results

[0000950170-22-002054:notes:369]
|  |  | Three Months Ended |  |  |
| (In thousands, except for per share amounts) |  | March 31, 2021 |  |  | June 30, 2021 |  |  | September 30, 2021 |  |  | December 31, 2021 |  |  |
| Net revenue |  | $ | 127,533 |  |  | $ | 143,232 |  |  | $ | 138,081 |  |  | $ | 154,158 |  |  |
| Gross profit |  | $ | 53,601 |  |  | $ | 62,668 |  |  | $ | 47,673 |  |  | $ | 54,435 |  |  |
| Operating (loss) income |  | $ | (1,335 | ) |  | $ | 3,931 |  |  | $ | (10,058 | ) |  | $ | (7,238 | ) |  |
| Net (loss) income |  | $ | 896 |  |  | $ | 5,086 |  |  | $ | (10,427 | ) |  | $ | (4,190 | ) |  |
| (Loss) earnings per common share - basic |  | $ | 0.02 |  |  | $ | 0.10 |  |  | $ | (0.21 | ) |  | $ | (0.09 | ) |  |
| (Loss) earnings per common share - diluted |  | $ | 0.02 |  | (1) | $ | 0.10 |  | (1) | $ | (0.21 | ) |  | $ | (0.09 | ) |  |
|  |  | Three Months Ended |  |  |
| (In thousands, except for per share amounts) |  | March 31, 2020(2) |  |  | June 30, 2020 |  |  | September 30, 2020 |  |  | December 31, 2020 |  |  |
| Net revenue |  | $ | 114,523 |  |  | $ | 128,715 |  |  | $ | 133,143 |  |  | $ | 130,129 |  |  |
| Gross profit |  | $ | 51,600 |  |  | $ | 53,472 |  |  | $ | 58,962 |  |  | $ | 53,517 |  |  |
| Operating (loss) income |  | $ | (4,944 | ) |  | $ | (6,039 | ) |  | $ | 4,534 |  |  | $ | (3,324 | ) |  |
| Net (loss) income |  | $ | (9,969 | ) |  | $ | 752 |  |  | $ | 5,481 |  |  | $ | 6,114 |  |  |
| (Loss) earnings per common share - basic |  | $ | (0.21 | ) |  | $ | 0.02 |  |  | $ | 0.11 |  |  | $ | 0.13 |  |  |
| (Loss) earnings per common share - diluted |  | $ | (0.21 | ) |  | $ | 0.02 |  | (1) | $ | 0.11 |  | (1) | $ | 0.13 |  | (1) |

[0000950170-22-002054:notes:370]
(1)
Assumes exercise of dilutive securities calculated under the treasury stock method.

[0000950170-22-002054:notes:371]
(2)
See footnote 1 for discussion on out of period disclosures impacting these quarterly operating results.


## us-gaap:SubsequentEventsTextBlock

[0000950170-22-002054:notes:372]
Note 22 – Subsequent Events

[0000950170-22-002054:notes:373]
On February 2, 2022, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record at the close of business on February 17, 2022. The payment date will be March 3, 2022 in the aggregate amount of approximately $4.4 million.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000950170-22-002054:notes:374]
SCHEDULE II

[0000950170-22-002054:notes:375]
VALUATION AND QUALIFYING ACCOUNTS

[0000950170-22-002054:notes:376]
| (In thousands) |  | Balance atBeginningof Period |  |  | Charged toCosts &Expenses |  |  | Deductions |  |  | Balance atEnd ofPeriod |  |
| Year ended December 31, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 38 |  |  |  | (38 | ) |  |  | — |  |  | $ | — |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 45,818 |  |  |  | 6,347 |  |  |  | 1,601 |  |  | $ | 50,564 |  |
| Year ended December 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 38 |  |  |  | — |  |  |  | — |  |  | $ | 38 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 48,616 |  |  |  | 5,120 |  |  |  | 7,918 |  |  | $ | 45,818 |  |
| Year ended December 31, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 128 |  |  |  | 38 |  |  |  | 128 |  |  | $ | 38 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 5,816 |  |  |  | 43,560 |  |  |  | 760 |  |  | $ | 48,616 |  |
