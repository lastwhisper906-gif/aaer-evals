# ADTN notes — 0000950170-21-003219


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-21-003219:notes:1]
[same as prior period, unchanged from 0001564590-21-042027:notes:1]

[0000950170-21-003219:notes:2]
[same as prior period, unchanged from 0001564590-21-042027:notes:2]

[0000950170-21-003219:notes:3]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2020 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

[0000950170-21-003219:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 26, 2021.

[0000950170-21-003219:notes:5]
[same as prior period, unchanged from 0001564590-21-042027:notes:5]

[0000950170-21-003219:notes:6]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multi-element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

[0000950170-21-003219:notes:7]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus, including the Delta variant) as well as supply chain constraints as of September 30, 2021 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for expected credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints, could result in further impacts to our consolidated financial statements in future reporting periods.

[0000950170-21-003219:notes:8]
[same as prior period, unchanged from 0001564590-21-042027:notes:8]

[0000950170-21-003219:notes:9]
[same as prior period, unchanged from 0001564590-21-042027:notes:9]

[0000950170-21-003219:notes:10]
Recently Adopted Accounting Pronouncements

[0000950170-21-003219:notes:11]
[same as prior period, unchanged from 0001564590-21-042027:notes:11]

[0000950170-21-003219:notes:12]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by Accounting Standards Codification (“ASC”) 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 became effective for public business entities for fiscal years ending after December 15, 2020. The adoption of this standard did not have a material effect on the disclosures in the condensed consolidated financial statements.

[0000950170-21-003219:notes:13]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss) for the three months ended March 31, 2020, that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the condensed consolidated financial statements.

[0000950170-21-003219:notes:14]
[same as prior period, unchanged from 0001564590-21-042027:notes:14]


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000950170-21-003219:notes:15]
[same as prior period, unchanged from 0001564590-21-042027:notes:16]

[0000950170-21-003219:notes:16]
[same as prior period, unchanged from 0001564590-21-042027:notes:17]

[0000950170-21-003219:notes:17]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2021 |  |  | December 31, 2020 |  |
| Cash and cash equivalents |  | $ | 75,503 |  |  | $ | 60,161 |  |
| Restricted cash |  |  | 102 |  |  |  | 18 |  |
| Cash, cash equivalents and restricted cash |  | $ | 75,605 |  |  | $ | 60,179 |  |

[0000950170-21-003219:notes:18]
[same as prior period, unchanged from 0001564590-21-042027:notes:19]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-21-003219:notes:19]
[same as prior period, unchanged from 0001564590-21-042027:notes:20]

[0000950170-21-003219:notes:20]
[same as prior period, unchanged from 0001564590-21-042027:notes:21]

[0000950170-21-003219:notes:21]
[same as prior period, unchanged from 0001564590-21-042027:notes:22]

[0000950170-21-003219:notes:22]
[same as prior period, unchanged from 0001564590-21-042027:notes:23]

[0000950170-21-003219:notes:23]
[same as prior period, unchanged from 0001564590-21-042027:notes:24]

[0000950170-21-003219:notes:24]
[same as prior period, unchanged from 0001564590-21-042027:notes:25]

[0000950170-21-003219:notes:25]
[same as prior period, unchanged from 0001564590-21-042027:notes:26]

[0000950170-21-003219:notes:26]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 77,104 |  |  | $ | 12,069 |  |  | $ | 89,173 |  |  | $ | 71,919 |  |  | $ | 13,504 |  |  | $ | 85,423 |  |
| Subscriber Solutions & Experience |  |  | 42,093 |  |  |  | 2,819 |  |  |  | 44,912 |  |  |  | 40,843 |  |  |  | 2,282 |  |  |  | 43,125 |  |
| Traditional & Other Products |  |  | 1,570 |  |  |  | 2,426 |  |  |  | 3,996 |  |  |  | 2,467 |  |  |  | 2,128 |  |  |  | 4,595 |  |
| Total |  | $ | 120,767 |  |  | $ | 17,314 |  |  | $ | 138,081 |  |  | $ | 115,229 |  |  | $ | 17,914 |  |  | $ | 133,143 |  |

[0000950170-21-003219:notes:27]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 215,464 |  |  | $ | 33,747 |  |  | $ | 249,211 |  |  | $ | 194,695 |  |  | $ | 39,470 |  |  | $ | 234,165 |  |
| Subscriber Solutions & Experience |  |  | 139,459 |  |  |  | 7,832 |  |  |  | 147,291 |  |  |  | 118,907 |  |  |  | 6,790 |  |  |  | 125,697 |  |
| Traditional & Other Products |  |  | 5,102 |  |  |  | 7,242 |  |  |  | 12,344 |  |  |  | 10,322 |  |  |  | 6,197 |  |  |  | 16,519 |  |
| Total |  | $ | 360,025 |  |  | $ | 48,821 |  |  | $ | 408,846 |  |  | $ | 323,924 |  |  | $ | 52,457 |  |  | $ | 376,381 |  |

[0000950170-21-003219:notes:28]
Revenue allocated to remaining performance obligations represents contract revenue that has not yet been recognized for contracts with a duration of greater than one year. As of September 30, 2021, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $20.7 million and $17.7 million as of September 30, 2021 and December 31, 2020, respectively. The Company expects to recognize 64% of the $20.7 million as of September 30, 2021 over the next 12 months, with the remainder to be recognized thereafter.

[0000950170-21-003219:notes:29]
[same as prior period, unchanged from 0001564590-21-042027:notes:30]

[0000950170-21-003219:notes:30]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2021 |  |  | December 31, 2020 |  |
| Accounts receivable, net |  | $ | 124,146 |  |  | $ | 98,827 |  |
| Contract assets(1) |  | $ | 999 |  |  | $ | 63 |  |
| Unearned revenue |  | $ | 16,394 |  |  | $ | 14,092 |  |
| Non-current unearned revenue |  | $ | 7,426 |  |  | $ | 6,888 |  |

[0000950170-21-003219:notes:31]
(1)	Included in other receivables on the Condensed Consolidated Balance Sheets.

[0000950170-21-003219:notes:32]
Of the outstanding unearned revenue balances as of December 31, 2020, $2.0 million and $9.8 million were recognized as revenue during the three and nine months ended September 30, 2021, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000950170-21-003219:notes:33]
[same as prior period, unchanged from 0001564590-21-042027:notes:34]

[0000950170-21-003219:notes:34]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Access & Aggregation |  | $ | 89,173 |  |  | $ | 85,423 |  |  | $ | 249,211 |  |  | $ | 234,165 |  |
| Subscriber Solutions & Experience |  |  | 44,912 |  |  |  | 43,125 |  |  |  | 147,291 |  |  |  | 125,697 |  |
| Traditional & Other Products |  |  | 3,996 |  |  |  | 4,595 |  |  |  | 12,344 |  |  |  | 16,519 |  |
| Total |  | $ | 138,081 |  |  | $ | 133,143 |  |  | $ | 408,846 |  |  | $ | 376,381 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-21-003219:notes:35]
[same as prior period, unchanged from 0001564590-21-042027:notes:36]

[0000950170-21-003219:notes:36]
Our effective tax rate increased from an expense of 9.3% of pre-tax income for the three months ended September 30, 2020, to an expense of 14.1% of pre-tax loss for the three months ended September 30, 2021 and increased from a benefit of 36.8% of pre-tax loss for the nine months ended September 30, 2020 to an expense of 354.5% of pre-tax loss for the nine months ended September 30, 2021. The change in the effective tax rate for the three months ended September 30, 2021 was driven by tax expense in our international operations and additional changes in the valuation allowance related to our domestic operations. The change in the effective tax rate for the nine months ended September 30, 2021 was primarily driven by a tax benefit of $7.8 million recognized during the nine months ended September 30, 2020 as a result of the passing of the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) on March 27, 2020, which allowed for the carryback of federal net operating losses, partially offset with tax expense in our international operations in the current quarter.

[0000950170-21-003219:notes:37]
On February 12, 2021, the Alabama Business Tax Competitiveness Act (the "Act") was signed into law. As a result of the Act, we recognized an expense of $1.6 million in the first quarter of 2021 related to the revaluation of our deferred tax assets, which was offset by changes in our valuation allowance previously recorded against our domestic deferred tax assets.

[0000950170-21-003219:notes:38]
During the third quarter of 2021, management pursued a claim for refund related to the revocation of the IRC Section 59(e) election that was made on our originally filed 2018 U.S. federal tax return. The Company filed a related carryback claim of net operating losses generated in 2018 to prior years as allowed under the CARES Act that was passed in the first quarter of 2020. An IRS Section 59(e) election is generally non-revocable except in cases for which IRS Commissioner’s approval is given. Approval is granted only in rare and unusual circumstances. The Company filed a private letter ruling (the "PLR") request to revoke our election. To date, a response to the PLR has not been published. As a result of these filings, and management’s position to pursue them through appeals, if necessary, we have established a receivable in the amount of $15.2 million and a deferred tax asset related to our additional research and development credit carryforward in the amount of $1.8 million that would be available if our revocation request is successful, offset with an uncertain tax liability of $17.0 million within our financials as of September 30, 2021.

[0000950170-21-003219:notes:39]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of September 30, 2021, the Company had deferred tax assets totaling $59.2 million, and a valuation allowance totaling $50.2 million against those deferred tax assets. The remaining $9.0 million in deferred tax assets not offset by a valuation allowance are located in various foreign jurisdictions where the Company believes it is more likely than not we will realize these deferred tax assets. During the nine months ended September 30, 2021, the total increase in the valuation allowance against our domestic and international deferred tax assets was recorded in the amount of $4.0 million and $0.4 million, respectively. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results as well as the evaluation of evidence which requires significant judgement, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.

[0000950170-21-003219:notes:40]
[same as prior period, unchanged from 0001564590-21-042027:notes:40]

[0000950170-21-003219:notes:41]
|  |  | As of September 30, 2021 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 47,839 |  |  | $ | (47,839 | ) |  | $ | — |  |
| International |  |  | 11,350 |  |  |  | (2,393 | ) |  |  | 8,957 |  |
| Total |  | $ | 59,189 |  |  | $ | (50,232 | ) |  | $ | 8,957 |  |

[0000950170-21-003219:notes:42]
[same as prior period, unchanged from 0001564590-21-042027:notes:42]

[0000950170-21-003219:notes:43]
The change in the unrecognized income tax benefits for the nine months ended September 30, 2021 and year ended December 31, 2020, is reconciled below:

[0000950170-21-003219:notes:44]
| (In thousands) |  | For the Nine Months Ended September 30, 2021 |  |  | For the Year Ended December 31, 2020 |  |
| Balance at beginning of period |  | $ | 1,078 |  |  | $ | 1,487 |  |
| Increases for tax position related to: |  |  |  |  |  |  |
| Prior years |  |  | 17,025 |  |  |  | 4 |  |
| Current year |  |  | 102 |  |  |  | 165 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |
| Prior years |  |  | (27 | ) |  |  | — |  |
| Expiration of applicable statute of limitations |  |  | — |  |  |  | (578 | ) |
| Balance at end of period |  | $ | 18,178 |  |  | $ | 1,078 |  |

[0000950170-21-003219:notes:45]
As of September 30, 2021 and December 31, 2020, the liability for unrecognized tax benefit was $18.2 million and $1.1 million, respectively, of which $18.1 million and $1.0 million, respectively, would reduce the effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of September 30, 2021 and December 31, 2020, the balances of accrued interest and penalties were $0.3 million and $0.3 million, respectively.

[0000950170-21-003219:notes:46]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date, unless a resolution is reached regarding the item noted above. We file income tax returns in the U.S. for federal and various state jurisdictions and several foreign jurisdictions.  We are not currently under audit by the Internal Revenue Service.  Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2017.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-21-003219:notes:47]
[same as prior period, unchanged from 0001564590-21-042027:notes:43]

[0000950170-21-003219:notes:48]
[same as prior period, unchanged from 0001564590-21-042027:notes:44]

[0000950170-21-003219:notes:49]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Stock-based compensation expense included in cost of revenue |  | $ | 133 |  |  | $ | 101 |  |  | $ | 389 |  |  | $ | 303 |  |
| Selling, general and administrative expense |  |  | 1,116 |  |  |  | 953 |  |  |  | 3,312 |  |  |  | 2,999 |  |
| Research and development expense |  |  | 593 |  |  |  | 556 |  |  |  | 1,756 |  |  |  | 1,754 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,709 |  |  |  | 1,509 |  |  |  | 5,068 |  |  |  | 4,753 |  |
| Total stock-based compensation expense |  |  | 1,842 |  |  |  | 1,610 |  |  |  | 5,457 |  |  |  | 5,056 |  |
| Tax benefit for expense associated with stock options, PSUs, RSUs and restricted stock |  |  | (460 | ) |  |  | (384 | ) |  |  | (1,343 | ) |  |  | (1,205 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,382 |  |  | $ | 1,226 |  |  | $ | 4,114 |  |  | $ | 3,851 |  |

[0000950170-21-003219:notes:50]
[same as prior period, unchanged from 0001564590-21-042027:notes:46]

[0000950170-21-003219:notes:51]
The following table summarizes PSUs, RSUs and restricted stock outstanding as of December 31, 2020 and September 30, 2021 and the changes that occurred during the nine months ended September 30, 2021:

[0000950170-21-003219:notes:52]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2020 |  |  | 1,846 |  |  | $ | 11.49 |  |
| PSUs, RSUs and restricted stock granted |  |  | 359 |  |  | $ | 16.75 |  |
| PSUs, RSUs and restricted stock vested |  |  | (21 | ) |  | $ | 13.00 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (65 | ) |  | $ | 11.93 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, September 30, 2021 |  |  | 2,119 |  |  | $ | 12.40 |  |

[0000950170-21-003219:notes:53]
During each of the nine month periods ended September 30, 2021 and 2020, the Company granted 0.3 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over two-year and three-year periods, respectively, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0000950170-21-003219:notes:54]
[same as prior period, unchanged from 0001564590-21-042027:notes:51]

[0000950170-21-003219:notes:55]
As of September 30, 2021, total unrecognized compensation expense related to non-vested market-based PSUs, RSUs and restricted stock was approximately $11.3 million, which will be recognized over the remaining weighted-average period of 2.3 years. In addition, there was $7.5 million of unrecognized compensation expense related to unvested 2020 and 2021 performance-based PSUs, which will be recognized over the remaining requisite service period of 1.3 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0000950170-21-003219:notes:56]
As of September 30, 2021, 4.0 million shares were available for issuance under stockholder-approved equity plans.

[0000950170-21-003219:notes:57]
[same as prior period, unchanged from 0001564590-21-042027:notes:54]

[0000950170-21-003219:notes:58]
The following table summarizes stock options outstanding as of December 31, 2020 and September 30, 2021 and the changes that occurred during the nine months ended September 30, 2021:

[0000950170-21-003219:notes:59]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2020 |  |  | 2,718 |  |  | $ | 21.17 |  |  |  | 2.9 |  |  | $ | — |  |
| Stock options exercised |  |  | (363 | ) |  | $ | 16.81 |  |  |  |  |  |  | 1,411 |  |
| Stock options expired |  |  | (607 | ) |  | $ | 28.93 |  |  |  |  |  |  | 18 |  |
| Stock options outstanding, September 30, 2021 |  |  | 1,748 |  |  | $ | 19.37 |  |  |  | 2.7 |  |  | $ | 2,060 |  |
| Stock options exercisable, September 30, 2021 |  |  | 1,748 |  |  | $ | 19.37 |  |  |  | 2.7 |  |  | $ | 2,060 |  |

[0000950170-21-003219:notes:60]
As of September 30, 2021, there was no unrecognized compensation expense related to stock options as all awards vested in prior periods.

[0000950170-21-003219:notes:61]
There were no stock options granted during the nine months ended September 30, 2021 and 2020. All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0000950170-21-003219:notes:62]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on September 30, 2021. The amount of aggregate intrinsic value was $2.1 million as of September 30, 2021 and will change based on the fair market value of ADTRAN’s stock. The total pre-tax intrinsic value of options exercised during the nine months ended September 30, 2021 was $1.4 million.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-21-003219:notes:63]
6. INVESTMENTS

[0000950170-21-003219:notes:64]
Debt Securities and Other Investments

[0000950170-21-003219:notes:65]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

[0000950170-21-003219:notes:66]
|  |  | As of September 30, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 13,381 |  |  | $ | 39 |  |  | $ | (6 | ) |  | $ | 13,414 |  |
| Municipal fixed-rate bonds |  |  | 2,236 |  |  |  | 13 |  |  |  | (1 | ) |  |  | 2,248 |  |
| Asset-backed bonds |  |  | 3,497 |  |  |  | 17 |  |  |  | (1 | ) |  |  | 3,513 |  |
| Mortgage/Agency-backed bonds |  |  | 9,194 |  |  |  | 35 |  |  |  | (17 | ) |  |  | 9,212 |  |
| U.S. government bonds |  |  | 16,031 |  |  |  | 34 |  |  |  | (13 | ) |  |  | 16,052 |  |
| Foreign government bonds |  |  | 544 |  |  |  | 1 |  |  |  | (2 | ) |  |  | 543 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 45,416 |  |  | $ | 139 |  |  | $ | (40 | ) |  | $ | 45,515 |  |

[0000950170-21-003219:notes:67]
|  |  | As of December 31, 2020 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 11,762 |  |  | $ | 123 |  |  | $ | — |  |  | $ | 11,885 |  |
| Municipal fixed-rate bonds |  |  | 2,854 |  |  |  | 30 |  |  |  | — |  |  |  | 2,884 |  |
| Asset-backed bonds |  |  | 6,634 |  |  |  | 74 |  |  |  | — |  |  |  | 6,708 |  |
| Mortgage/Agency-backed bonds |  |  | 11,536 |  |  |  | 114 |  |  |  | (6 | ) |  |  | 11,644 |  |
| U.S. government bonds |  |  | 9,763 |  |  |  | 112 |  |  |  | — |  |  |  | 9,875 |  |
| Foreign government bonds |  |  | 1,334 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 1,337 |  |
| Commercial Paper |  |  | 250 |  |  |  | — |  |  |  | — |  |  |  | 250 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,666 |  |  | $ | 457 |  |  | $ | (7 | ) |  | $ | 45,116 |  |

[0000950170-21-003219:notes:68]
The contractual maturities related to debt securities and other investments were as follows:

[0000950170-21-003219:notes:69]
|  |  | As of September 30, 2021 |  |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Other |  |
| Less than one year |  | $ | 275 |  |  | $ | 652 |  |  | $ | — |  |  | $ | 638 |  |  | $ | 2,593 |  |  | $ | — |  |  | $ | 533 |  |
| One to two years |  |  | 4,494 |  |  |  | 534 |  |  |  | — |  |  |  | 1,005 |  |  |  | 4,021 |  |  |  | 246 |  |  |  | — |  |
| Two to three years |  |  | 6,616 |  |  |  | 761 |  |  |  | 93 |  |  |  | 1,102 |  |  |  | 5,810 |  |  |  | 297 |  |  |  | — |  |
| Three to five years |  |  | 2,029 |  |  |  | 301 |  |  |  | 1,573 |  |  |  | 235 |  |  |  | 3,628 |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 785 |  |  |  | 1,322 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,062 |  |  |  | 4,910 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 13,414 |  |  | $ | 2,248 |  |  | $ | 3,513 |  |  | $ | 9,212 |  |  | $ | 16,052 |  |  | $ | 543 |  |  | $ | 533 |  |

[0000950170-21-003219:notes:70]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0000950170-21-003219:notes:71]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to our debt securities:

[0000950170-21-003219:notes:72]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Gross realized gain on debt securities |  | $ | 22 |  |  | $ | 70 |  |  | $ | 206 |  |  | $ | 303 |  |
| Gross realized loss on debt securities |  |  | (17 | ) |  |  | (6 | ) |  |  | (53 | ) |  |  | (45 | ) |
| Total gain recognized, net |  | $ | 5 |  |  | $ | 64 |  |  | $ | 153 |  |  | $ | 258 |  |

[0000950170-21-003219:notes:73]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income (Loss). No allowance for credit loss was recorded for the nine months ended September 30, 2021 and 2020 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the nine months ended September 30, 2021.

[0000950170-21-003219:notes:74]
Marketable Equity Securities

[0000950170-21-003219:notes:75]
Our marketable equity securities consist of publicly traded stock, interests in funds and certain other investments measured at fair value or cost (where appropriate).

[0000950170-21-003219:notes:76]
In March 2019, an outstanding note receivable of $4.3 million owed to the Company was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment. The Company elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. During the year ended December 31, 2020, impairment charges totaling $2.6 million were recorded related to this equity investment, which was included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $0.8 million as of September 30, 2021 and December 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of September 30, 2021 and December 31, 2020. No impairment charge was recognized related to the note receivable as it is a secured loan.

[0000950170-21-003219:notes:77]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0000950170-21-003219:notes:78]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Realized gain (loss) on equity securities sold |  | $ | — |  |  | $ | 623 |  |  | $ | (55 | ) |  | $ | (1,485 | ) |
| Unrealized (loss) gain on equity securities held |  |  | (68 | ) |  |  | 2,157 |  |  |  | 2,844 |  |  |  | 3,046 |  |
| Total gain (loss) recognized, net |  | $ | (68 | ) |  | $ | 2,780 |  |  | $ | 2,789 |  |  | $ | 1,561 |  |

[0000950170-21-003219:notes:79]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income (Loss). U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-21-003219:notes:80]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-21-003219:notes:81]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-21-003219:notes:82]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-21-003219:notes:83]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-21-003219:notes:84]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 532 |  |  | $ | 532 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 400 |  |  |  | — |  |  |  | 400 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,414 |  |  |  | — |  |  |  | 13,414 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,248 |  |  |  | — |  |  |  | 2,248 |  |  |  | — |  |
| Asset-backed bonds |  |  | 3,513 |  |  |  | — |  |  |  | 3,513 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 9,212 |  |  |  | — |  |  |  | 9,212 |  |  |  | — |  |
| U.S. government bonds |  |  | 16,052 |  |  |  | 16,052 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 543 |  |  |  | — |  |  |  | 543 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 12,144 |  |  |  | 12,144 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 25,733 |  |  |  | 25,733 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 85,724 |  |  | $ | 55,861 |  |  | $ | 29,330 |  |  | $ | 533 |  |

[0000950170-21-003219:notes:85]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 497 |  |  | $ | 497 |  |  | $ | — |  |  | $ | — |  |
| U.S. government bonds |  |  | 350 |  |  |  | 350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,885 |  |  |  | — |  |  |  | 11,885 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,884 |  |  |  | — |  |  |  | 2,884 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,708 |  |  |  | — |  |  |  | 6,708 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,644 |  |  |  | — |  |  |  | 11,644 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,875 |  |  |  | 9,875 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,337 |  |  |  | — |  |  |  | 1,337 |  |  |  | — |  |
| Commercial paper |  |  | 250 |  |  |  | — |  |  |  | 250 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 10,963 |  |  |  | 10,963 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 23,891 |  |  |  | 23,891 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,217 |  |  | $ | 46,976 |  |  | $ | 34,708 |  |  | $ | 533 |  |

[0000950170-21-003219:notes:86]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0000950170-21-003219:notes:87]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consists of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-21-003219:notes:88]
[same as prior period, unchanged from 0001564590-21-042027:notes:85]

[0000950170-21-003219:notes:89]
[same as prior period, unchanged from 0001564590-21-042027:notes:86]

[0000950170-21-003219:notes:90]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2021 |  |  | December 31, 2020 |  |
| Raw materials |  | $ | 66,777 |  |  | $ | 47,026 |  |
| Work in process |  |  | 1,202 |  |  |  | 776 |  |
| Finished goods |  |  | 59,262 |  |  |  | 77,655 |  |
| Total inventory, net |  | $ | 127,241 |  |  | $ | 125,457 |  |

[0000950170-21-003219:notes:91]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which considers historical usage, known trends, inventory age and market conditions. As of September 30, 2021 and December 31, 2020, inventory reserves were $44.3 million and $39.6 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-21-003219:notes:92]
[same as prior period, unchanged from 0001564590-21-042027:notes:89]

[0000950170-21-003219:notes:93]
[same as prior period, unchanged from 0001564590-21-042027:notes:90]

[0000950170-21-003219:notes:94]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2021 |  |  | December 31, 2020 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 34,995 |  |  |  | 35,142 |  |
| Building |  |  | 68,156 |  |  |  | 68,169 |  |
| Furniture and fixtures |  |  | 19,925 |  |  |  | 19,965 |  |
| Computer hardware and software |  |  | 71,615 |  |  |  | 70,942 |  |
| Engineering and other equipment |  |  | 134,689 |  |  |  | 132,920 |  |
| Total property, plant and equipment |  |  | 333,955 |  |  |  | 331,713 |  |
| Less: accumulated depreciation |  |  | (277,399 | ) |  |  | (269,314 | ) |
| Total property, plant and equipment, net |  | $ | 56,556 |  |  | $ | 62,399 |  |

[0000950170-21-003219:notes:95]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to long-lived assets during the third quarters of 2021 and 2020. As a result, no impairment test of long-lived assets was performed as of September 30, 2021 and 2020, and no impairment losses of long-lived assets were recorded during the three or nine months ended September 30, 2021 and 2020.

[0000950170-21-003219:notes:96]
Depreciation expense was $3.0 million and $3.1 million for the three months ended September 30, 2021 and 2020 respectively, and $9.1 million for both the nine months ended September 30, 2021 and 2020, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-21-003219:notes:97]
[same as prior period, unchanged from 0001564590-21-042027:notes:94]

[0000950170-21-003219:notes:98]
Goodwill was $7.0 million as of September 30, 2021 and December 31, 2020, of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0000950170-21-003219:notes:99]
The Company evaluates the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that could more likely than not reduce the fair value of the reporting unit below its carrying amount. We assess qualitative factors to determine whether the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount and recognize an impairment charge for the amount by which the carrying value exceeds the fair value of the reporting unit. No interim impairment test of goodwill was performed as of September 30, 2021 and 2020, and no impairment of goodwill was recorded during the three or nine months ended September 30, 2021 and 2020.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-21-003219:notes:100]
[same as prior period, unchanged from 0001564590-21-042027:notes:97]

[0000950170-21-003219:notes:101]
[same as prior period, unchanged from 0001564590-21-042027:notes:98]

[0000950170-21-003219:notes:102]
|  |  | As of September 30, 2021 |  |  | As of December 31, 2020 |  |
| (In thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | $ | 20,876 |  |  | $ | (9,483 | ) |  | $ | 11,393 |  |  | $ | 21,123 |  |  | $ | (8,055 | ) |  | $ | 13,068 |  |
| Developed technology |  |  | 8,200 |  |  |  | (3,399 | ) |  |  | 4,801 |  |  |  | 8,200 |  |  |  | (2,546 | ) |  |  | 5,654 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (2,322 | ) |  |  | 3,578 |  |  |  | 5,900 |  |  |  | (1,830 | ) |  |  | 4,070 |  |
| Supplier relationships |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2,800 |  |  |  | (2,800 | ) |  |  | — |  |
| Licensing agreements |  |  | 560 |  |  |  | (207 | ) |  |  | 353 |  |  |  | 560 |  |  |  | (152 | ) |  |  | 408 |  |
| Patents |  |  | 500 |  |  |  | (346 | ) |  |  | 154 |  |  |  | 500 |  |  |  | (294 | ) |  |  | 206 |  |
| Trade names |  |  | 210 |  |  |  | (198 | ) |  |  | 12 |  |  |  | 210 |  |  |  | (146 | ) |  |  | 64 |  |
| Total |  | $ | 36,246 |  |  | $ | (15,955 | ) |  | $ | 20,291 |  |  | $ | 39,293 |  |  | $ | (15,823 | ) |  | $ | 23,470 |  |

[0000950170-21-003219:notes:103]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to intangible assets during the third quarters of 2021 and 2020. As a result, no impairment test of long-lived assets was performed as of September 30, 2021 and 2020, and no impairment losses of intangible assets were recorded during the three and nine months ended September 30, 2021 and 2020.

[0000950170-21-003219:notes:104]
Amortization expense was $1.0 million in each of the three months ended September 30, 2021 and 2020, and $3.1 million and $3.4 million for the nine months ended September 30, 2021 and 2020, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).

[0000950170-21-003219:notes:105]
[same as prior period, unchanged from 0001564590-21-042027:notes:102]

[0000950170-21-003219:notes:106]
|  |  | As of |  |
| (In thousands) |  | September 30, 2021 |  |
| 2021 |  | $ | 984 |  |
| 2022 |  |  | 3,479 |  |
| 2023 |  |  | 3,327 |  |
| 2024 |  |  | 3,233 |  |
| 2025 |  |  | 3,027 |  |
| Thereafter |  |  | 6,241 |  |
| Total |  | $ | 20,291 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000950170-21-003219:notes:107]
[same as prior period, unchanged from 0001564590-21-042027:notes:104]

[0000950170-21-003219:notes:108]
[same as prior period, unchanged from 0001564590-21-042027:notes:105]

[0000950170-21-003219:notes:109]
[same as prior period, unchanged from 0001564590-21-042027:notes:106]

[0000950170-21-003219:notes:110]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2021 |  |  | December 31, 2020 |  |
| Current minimum lease payments receivable(1) |  | $ | 129 |  |  | $ | 702 |  |
| Non-current minimum lease payments receivable(2) |  |  | 7 |  |  |  | 347 |  |
| Total minimum lease payments receivable |  |  | 136 |  |  |  | 1,049 |  |
| Less: Current unearned revenue |  |  | 98 |  |  |  | 218 |  |
| Less: Non-current unearned revenue |  |  | 1 |  |  |  | 50 |  |
| Net investment in sales-type leases |  | $ | 37 |  |  | $ | 781 |  |

[0000950170-21-003219:notes:111]
(1)
Included in other receivables on the Condensed Consolidated Balance Sheets.

[0000950170-21-003219:notes:112]
(2)
Included in other assets on the Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0000950170-21-003219:notes:113]
12. REVOLVING CREDIT AGREEMENT

[0000950170-21-003219:notes:114]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company had not made any draws under the Revolving Credit Agreement as of September 30, 2021.


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0000950170-21-003219:notes:115]
[same as prior period, unchanged from 0001564590-21-042027:notes:111]

[0000950170-21-003219:notes:116]
[same as prior period, unchanged from 0001564590-21-042027:notes:112]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-21-003219:notes:117]
[same as prior period, unchanged from 0001564590-21-042027:notes:113]

[0000950170-21-003219:notes:118]
[same as prior period, unchanged from 0001564590-21-042027:notes:114]

[0000950170-21-003219:notes:119]
Since 1997, the Company’s Board of Directors has approved multiple share repurchase programs that have authorized repurchases of its common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the nine months ended September 30, 2021, we did not repurchase any shares of our common stock. As of September 30, 2021, we had the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0000950170-21-003219:notes:120]
[same as prior period, unchanged from 0001564590-21-042027:notes:116]

[0000950170-21-003219:notes:121]
[same as prior period, unchanged from 0001564590-21-042027:notes:117]

[0000950170-21-003219:notes:122]
|  |  | Three Months Ended September 30, 2021 |  |
| (In thousands) |  | UnrealizedLossesonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of June 30, 2021 |  | $ | (255 | ) |  | $ | (9,310 | ) |  | $ | (3,960 | ) |  | $ | 385 |  |  | $ | (13,140 | ) |
| Other comprehensive loss before reclassifications |  |  | (29 | ) |  |  | — |  |  |  | (1,389 | ) |  |  | — |  |  |  | (1,418 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (32 | ) |  |  | 124 |  |  |  | — |  |  |  | — |  |  |  | 92 |  |
| Net current period other comprehensive income (loss) |  |  | (61 | ) |  |  | 124 |  |  |  | (1,389 | ) |  |  | — |  |  |  | (1,326 | ) |
| As of September 30, 2021 |  | $ | (316 | ) |  | $ | (9,186 | ) |  | $ | (5,349 | ) |  | $ | 385 |  |  | $ | (14,466 | ) |

[0000950170-21-003219:notes:123]
|  |  | Three Months Ended September 30, 2020 |  |
| (In thousands) |  | UnrealizedGains(Losses)onAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of June 30, 2020 |  | $ | 206 |  |  | $ | (8,894 | ) |  | $ | (7,043 | ) |  | $ | 385 |  |  | $ | (15,346 | ) |
| Other comprehensive income before reclassifications |  |  | 494 |  |  |  | — |  |  |  | 2,469 |  |  |  | — |  |  |  | 2,963 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (539 | ) |  |  | 244 |  |  |  | — |  |  |  | — |  |  |  | (295 | ) |
| Net current period other comprehensive income (loss) |  |  | (45 | ) |  |  | 244 |  |  |  | 2,469 |  |  |  | — |  |  |  | 2,668 |  |
| As of September 30, 2020 |  | $ | 161 |  |  | $ | (8,650 | ) |  | $ | (4,574 | ) |  | $ | 385 |  |  | $ | (12,678 | ) |

[0000950170-21-003219:notes:124]
|  |  | Nine Months Ended September 30, 2021 |  |
| (In thousands) |  | UnrealizedGains (Losses)onAvailable-for-SaleSecurities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2020 |  | $ | 32 |  |  | $ | (9,621 | ) |  | $ | (2,435 | ) |  | $ | 385 |  |  | $ | (11,639 | ) |
| Other comprehensive loss before reclassifications |  |  | (358 | ) |  |  | — |  |  |  | (2,914 | ) |  |  | — |  |  |  | (3,272 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | 10 |  |  |  | 435 |  |  |  | — |  |  |  | — |  |  |  | 445 |  |
| Net current period other comprehensive income (loss) |  |  | (348 | ) |  |  | 435 |  |  |  | (2,914 | ) |  |  | — |  |  |  | (2,827 | ) |
| As of September 30, 2021 |  | $ | (316 | ) |  | $ | (9,186 | ) |  | $ | (5,349 | ) |  | $ | 385 |  |  | $ | (14,466 | ) |

[0000950170-21-003219:notes:125]
|  |  | Nine Months Ended September 30, 2020 |  |
| (In thousands) |  | UnrealizedGains (Losses) on Available-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2019 |  | $ | (284 | ) |  | $ | (9,226 | ) |  | $ | (7,292 | ) |  | $ | 385 |  |  | $ | (16,417 | ) |
| Other comprehensive income before reclassifications |  |  | 444 |  |  |  | — |  |  |  | 2,718 |  |  |  | — |  |  |  | 3,162 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | 1 |  |  |  | 576 |  |  |  | — |  |  |  | — |  |  |  | 577 |  |
| Net current period other comprehensive income |  |  | 445 |  |  |  | 576 |  |  |  | 2,718 |  |  |  | — |  |  |  | 3,739 |  |
| As of September 30, 2020 |  | $ | 161 |  |  | $ | (8,650 | ) |  | $ | (4,574 | ) |  | $ | 385 |  |  | $ | (12,678 | ) |

[0000950170-21-003219:notes:126]
[same as prior period, unchanged from 0001564590-21-042027:notes:122]

[0000950170-21-003219:notes:127]
|  |  | Three Months Ended September 30, 2021 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in theStatement Where NetIncome Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | 42 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial gain |  |  | (180 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (138 | ) |  |  |
| Tax expense |  |  | 46 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (92 | ) |  |  |

[0000950170-21-003219:notes:128]
(1)
A part of the computation of net periodic pension cost, which is included in other income (expense), net in the Condensed Consolidated Statements of Income (Loss).

[0000950170-21-003219:notes:129]
|  |  | Three Months Ended September 30, 2020 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | 728 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial gain |  |  | (354 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 374 |  |  |  |
| Tax benefit |  |  | (79 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 295 |  |  |  |

[0000950170-21-003219:notes:130]
|  |  | Nine Months Ended September 30, 2021 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where NetIncome Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | (13 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial gain |  |  | (630 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (643 | ) |  |  |
| Tax expense |  |  | 198 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (445 | ) |  |  |

[0000950170-21-003219:notes:131]
|  |  | Nine Months Ended September 30, 2020 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | (1 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial gain |  |  | (835 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (836 | ) |  |  |
| Tax expense |  |  | 259 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (577 | ) |  |  |

[0000950170-21-003219:notes:132]
[same as prior period, unchanged from 0001564590-21-042027:notes:128]

[0000950170-21-003219:notes:133]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | (38 | ) |  | $ | 9 |  |  | $ | (29 | ) |  | $ | 668 |  |  | $ | (174 | ) |  | $ | 494 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | (42 | ) |  |  | 10 |  |  |  | (32 | ) |  |  | (728 | ) |  |  | 189 |  |  |  | (539 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 180 |  |  |  | (56 | ) |  |  | 124 |  |  |  | 354 |  |  |  | (110 | ) |  |  | 244 |  |
| Foreign currency translation adjustment |  |  | (1,389 | ) |  |  | — |  |  |  | (1,389 | ) |  |  | 2,469 |  |  |  | — |  |  |  | 2,469 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (1,289 | ) |  | $ | (37 | ) |  | $ | (1,326 | ) |  | $ | 2,763 |  |  | $ | (95 | ) |  | $ | 2,668 |  |

[0000950170-21-003219:notes:134]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | (471 | ) |  | $ | 113 |  |  | $ | (358 | ) |  | $ | 600 |  |  | $ | (156 | ) |  | $ | 444 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 13 |  |  |  | (3 | ) |  |  | 10 |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 630 |  |  |  | (195 | ) |  |  | 435 |  |  |  | 835 |  |  |  | (259 | ) |  |  | 576 |  |
| Foreign currency translation adjustment |  |  | (2,914 | ) |  |  | — |  |  |  | (2,914 | ) |  |  | 2,718 |  |  |  | — |  |  |  | 2,718 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (2,742 | ) |  | $ | (85 | ) |  | $ | (2,827 | ) |  | $ | 4,154 |  |  | $ | (415 | ) |  | $ | 3,739 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950170-21-003219:notes:135]
[same as prior period, unchanged from 0001564590-21-042027:notes:131]

[0000950170-21-003219:notes:136]
[same as prior period, unchanged from 0001564590-21-042027:notes:132]

[0000950170-21-003219:notes:137]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (10,427 | ) |  | $ | 5,481 |  |  | $ | (4,445 | ) |  | $ | (3,736 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,609 |  |  |  | 47,957 |  |  |  | 48,470 |  |  |  | 47,957 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | 467 |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 48,609 |  |  |  | 48,424 |  |  |  | 48,470 |  |  |  | 47,957 |  |
| Earnings (loss) per share – basic |  | $ | (0.21 | ) |  | $ | 0.11 |  |  | $ | (0.09 | ) |  | $ | (0.08 | ) |
| Earnings (loss) per share – diluted |  | $ | (0.21 | ) |  | $ | 0.11 |  |  | $ | (0.09 | ) |  | $ | (0.08 | ) |

[0000950170-21-003219:notes:138]
For the three months ended September 30, 2021 and 2020, 0.2 million and 3.4 million stock options, respectively, and for the nine months ended September 30, 2021 and 2020, 0.4 million and 4.3 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the applicable period, making them anti-dilutive under the treasury stock method.

[0000950170-21-003219:notes:139]
For the three months ended September 30, 2021 and 2020, less than one thousand and eighteen thousand shares, respectively, and for the nine months ended September 30, 2021 and 2020, four thousand and 0.1 million shares, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-21-003219:notes:140]
[same as prior period, unchanged from 0001564590-21-042027:notes:136]

[0000950170-21-003219:notes:141]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. Network Solutions includes hardware and software products and next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes a portfolio of maintenance, network installation and solution integration services, which include hosted cloud services and subscription services.

[0000950170-21-003219:notes:142]
[same as prior period, unchanged from 0001564590-21-042027:notes:138]

[0000950170-21-003219:notes:143]
[same as prior period, unchanged from 0001564590-21-042027:notes:139]

[0000950170-21-003219:notes:144]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 120,767 |  |  | $ | 39,738 |  |  | $ | 115,229 |  |  | $ | 52,434 |  |
| Services & Support |  |  | 17,314 |  |  |  | 7,935 |  |  |  | 17,914 |  |  |  | 6,528 |  |
| Total |  | $ | 138,081 |  |  | $ | 47,673 |  |  | $ | 133,143 |  |  | $ | 58,962 |  |

[0000950170-21-003219:notes:145]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 360,025 |  |  | $ | 143,981 |  |  | $ | 323,924 |  |  | $ | 145,432 |  |
| Services & Support |  |  | 48,821 |  |  |  | 19,961 |  |  |  | 52,457 |  |  |  | 18,602 |  |
| Total |  | $ | 408,846 |  |  | $ | 163,942 |  |  | $ | 376,381 |  |  | $ | 164,034 |  |

[0000950170-21-003219:notes:146]
[same as prior period, unchanged from 0001564590-21-042027:notes:142]

[0000950170-21-003219:notes:147]
[same as prior period, unchanged from 0001564590-21-042027:notes:143]

[0000950170-21-003219:notes:148]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| United States |  | $ | 91,868 |  |  | $ | 92,838 |  |  | $ | 273,009 |  |  | $ | 256,287 |  |
| International |  |  | 46,213 |  |  |  | 40,305 |  |  |  | 135,837 |  |  |  | 120,094 |  |
| Total |  | $ | 138,081 |  |  | $ | 133,143 |  |  | $ | 408,846 |  |  | $ | 376,381 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-21-003219:notes:149]
[same as prior period, unchanged from 0001564590-21-042027:notes:145]

[0000950170-21-003219:notes:150]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. The increasing complexity of our products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $5.6 million and $7.1 million as of September 30, 2021 and December 31, 2020, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. During the three and nine months ended September 30, 2021 and 2020, we had a net reversal of prior provisions related to warranty expirations, the impact of which is reflected in the table below:

[0000950170-21-003219:notes:151]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 5,997 |  |  | $ | 7,294 |  |  | $ | 7,146 |  |  | $ | 8,394 |  |
| Plus: Amounts charged to cost and expenses |  |  | 472 |  |  |  | 632 |  |  |  | 253 |  |  |  | 970 |  |
| Less: Deductions |  |  | (822 | ) |  |  | (734 | ) |  |  | (1,752 | ) |  |  | (2,172 | ) |
| Balance at end of period |  | $ | 5,647 |  |  | $ | 7,192 |  |  | $ | 5,647 |  |  | $ | 7,192 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-21-003219:notes:152]
18. COMMITMENTS AND CONTINGENCIES

[0000950170-21-003219:notes:153]
Shareholder Derivative Lawsuit

[0000950170-21-003219:notes:154]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. Stanton, et al., Case No. 5:20-cv-00447, was filed in the U.S. District Court for the Northern District of Alabama against two of the Company’s current executive officers, one of its former executive officers, and certain current and former members of its Board of Directors. The derivative suit alleges, among other things, that the defendants made or caused the Company to make materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The case was temporarily stayed pending an order on the defendants’ motion to dismiss in a separate securities class action case that included similar factual allegations, Burbridge v. ADTRAN, Inc., et al., Case No. 5:20-cv-00050-LCB (N.D. Ala.). The Burbridge case was dismissed on March 31, 2021, and the time to appeal the dismissal has expired, such that the dismissal is now final.  Following the dismissal, the plaintiff in the shareholder derivative suit sent a demand letter dated June 29, 2021 to ADTRAN’s Board of Directors.  The letter contains similar allegations to those made in the plaintiff’s filed complaint and in the now dismissed securities class action, and it demands, among other things, that the Board commence an investigation into the alleged wrongdoing.  We expect that the derivative suit will remain stayed pending the Board’s response to the demand. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with the derivative lawsuit or the demand letter.

[0000950170-21-003219:notes:155]
Other Legal Matters

[0000950170-21-003219:notes:156]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to patent rights, employment matters, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0000950170-21-003219:notes:157]
Business Combination Agreement

[0000950170-21-003219:notes:158]
On August 30, 2021, the Company, and ADVA Optical Networking SE, a European stock corporation incorporated under the laws of the European Union and Germany (“ADVA”), entered into a business combination agreement (the “Business Combination Agreement”), pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, Acorn HoldCo, Inc. (the "surviving corporation"), a Delaware corporation and currently a wholly-owned direct subsidiary of the Company.

[0000950170-21-003219:notes:159]
Under the terms of the Business Combination Agreement, Acorn MergeCo, Inc., a newly formed Delaware corporation and wholly-owned direct subsidiary of Acorn HoldCo (“Merger Sub”), will merge with and into ADTRAN, with ADTRAN surviving the merger (the “Merger”) as a wholly-owned direct subsidiary of Acorn HoldCo. Pursuant to the Merger, each outstanding share of common stock of the Company will be converted into the right to receive one share of common stock of Acorn HoldCo. Acorn HoldCo will also make a public exchange offer to exchange each issued and outstanding no-par value bearer share of ADVA, pursuant to which each ADVA share tendered and accepted for exchange will be exchanged for 0.8244 shares of common stock of Acorn HoldCo (the “Exchange Offer”, and together with the Merger, the “Business Combination”). Upon completion of the Business Combination, and assuming that all of the outstanding ADVA shares are exchanged in the Exchange Offer, former ADTRAN stockholders and former ADVA shareholders will own approximately 54% and 46%, respectively, of the outstanding Acorn HoldCo shares.

[0000950170-21-003219:notes:160]
The Business Combination Agreement was unanimously approved by the Board of Directors of the Company and by the supervisory board and management board of ADVA. The Company anticipates consummation of the Business Combination during mid-2022, subject to customary closing conditions as well as regulatory and shareholder approvals.

[0000950170-21-003219:notes:161]
Acorn HoldCo has entered into an irrevocable undertaking agreement (the “Irrevocable Undertaking”) with EGORA Holding GmbH and Egora Investments GmbH (collectively, the “Supporting Shareholders”) to validly accept the public exchange offer with respect to 7,000,000 shares held by them, representing 13.7% of the share capital of ADVA. The Irrevocable Undertaking includes other customary provisions, including certain restrictions on the Supporting Shareholders from disposing of the relevant shares.

[0000950170-21-003219:notes:162]
Additional information about the Business Combination Agreement and proposed Business Combination is set forth in the Company’s filings with the SEC, as well as in the registration statement on Form S-4 that Acorn HoldCo filed with the SEC, which has not yet become effective.

[0000950170-21-003219:notes:163]
Performance Bonds

[0000950170-21-003219:notes:164]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2021 and December 31, 2020, we had commitments related to these bonds totaling $20.9 million and $15.2 million, respectively, which expire at various dates through August 2024. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-21-003219:notes:165]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.4 million as of September 30, 2021, of which $0.1 million is included in restricted cash and $18.3 million is included in long-term investments on the Condensed Consolidated Balance Sheets. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the

[0000950170-21-003219:notes:166]
customer contract have been met. As of September 30, 2021, the Company was in compliance with all contractual requirements under the letter of credit.

[0000950170-21-003219:notes:167]
Investment Commitment

[0000950170-21-003219:notes:168]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of September 30, 2021.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-21-003219:notes:169]
[same as prior period, unchanged from 0001564590-21-042027:notes:158]

[0000950170-21-003219:notes:170]
During the second half of 2019, the Company initiated a restructuring plan to realign its expense structure with the reduction in revenue experienced in recent years and overall Company objectives. As part of this restructuring plan, the Company announced plans to reduce its overall operating expenses, both in the U.S. and internationally. Management continued to assess the efficiency of operations during 2020 and the first nine months of 2021 and, in turn, consolidated locations and personnel, among other things, where possible.

[0000950170-21-003219:notes:171]
[same as prior period, unchanged from 0001564590-21-042027:notes:160]

[0000950170-21-003219:notes:172]
The cumulative amount of restructuring expenses incurred as of September 30, 2021 for the restructuring plans was $12.5 million.

[0000950170-21-003219:notes:173]
[same as prior period, unchanged from 0001564590-21-042027:notes:162]

[0000950170-21-003219:notes:174]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (In thousands) |  | September 30, 2021 |  |  | September 30, 2021 |  |
| Balance at beginning of period |  | $ | 1,521 |  |  | $ | 4,186 |  |
| Plus: Amounts charged to cost and expense |  |  | — |  |  |  | 309 |  |
| Less: Amounts paid |  |  | (42 | ) |  |  | (3,016 | ) |
| Balance as of September 30, 2021 |  | $ | 1,479 |  |  | $ | 1,479 |  |

[0000950170-21-003219:notes:175]
[same as prior period, unchanged from 0001564590-21-042027:notes:164]

[0000950170-21-003219:notes:176]
[same as prior period, unchanged from 0001564590-21-042027:notes:165]

[0000950170-21-003219:notes:177]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Network Solutions - Cost of revenue |  | $ | — |  |  | $ | 187 |  |  | $ | 12 |  |  | $ | 220 |  |
| Services & Support - Cost of revenue |  |  | — |  |  |  | 45 |  |  |  | 3 |  |  |  | 68 |  |
| Cost of revenue |  | $ | — |  |  | $ | 232 |  |  | $ | 15 |  |  | $ | 288 |  |
| Selling, general and administrative expenses (1) |  |  | — |  |  |  | 1,050 |  |  |  | 145 |  |  |  | 1,622 |  |
| Research and development expenses (1) |  |  | — |  |  |  | 621 |  |  |  | 149 |  |  |  | 1,738 |  |
| Total restructuring expenses |  | $ | — |  |  | $ | 1,903 |  |  | $ | 309 |  |  | $ | 3,648 |  |

[0000950170-21-003219:notes:178]
(1) The Company does not allocate selling, general and administrative expense and research and development expense to the segment level.

[0000950170-21-003219:notes:179]
[same as prior period, unchanged from 0001564590-21-042027:notes:167]

[0000950170-21-003219:notes:180]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| United States |  | $ | — |  |  | $ | 448 |  |  | $ | 212 |  |  | $ | 2,191 |  |
| International |  |  | — |  |  |  | 1,455 |  |  |  | 97 |  |  |  | 1,457 |  |
| Total restructuring expenses |  | $ | — |  |  | $ | 1,903 |  |  | $ | 309 |  |  | $ | 3,648 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-21-003219:notes:181]
20. SUBSEQUENT EVENTS

[0000950170-21-003219:notes:182]
On November 1, 2021, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 16, 2021. The payment date will be November 30, 2021 in the aggregate amount of approximately $4.4 million.

[0000950170-21-003219:notes:183]
On November 4, 2021, the Company entered into a loan modification agreement and amendment to loan documents to extend the maturity date of the Revolving Credit Agreement through November 3, 2022. See Item 5, Other Information, of this report for additional information regarding the loan modification agreement.
