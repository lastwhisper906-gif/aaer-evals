# ADTN 10-Q controls and the auditor's report


## item_4_controls

[0000950170-21-003219:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000950170-21-003219:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000950170-21-003219:item_4_controls:3]
We maintain disclosure controls and procedures that are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure. Because of the inherent limitations to the effectiveness of any system of disclosure controls and procedures, no evaluation of disclosure controls and procedures can provide absolute assurance that all control issues, if any, with a company have been prevented or detected on a timely basis. Even disclosure controls and procedures determined to be effective can only provide reasonable assurance that their objectives are achieved.

[0000950170-21-003219:item_4_controls:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and our Chief Financial Officer, of the effectiveness of our disclosure controls and procedures, as such term is defined under Rule 13a-15(e) promulgated under the Exchange Act. Based on that evaluation, our Chief Executive Officer and our Chief Financial Officer concluded that, as of the end of the period covered by this report, our disclosure controls and procedures were effective at the reasonable assurance level.

[0000950170-21-003219:item_4_controls:5]
Changes in Internal Control over Financial Reporting.

[0000950170-21-003219:item_4_controls:6]
There were no changes in the Company’s internal control over financial reporting that occurred during the most recent fiscal quarter covered by this report that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.

[0000950170-21-003219:item_4_controls:7]
44
