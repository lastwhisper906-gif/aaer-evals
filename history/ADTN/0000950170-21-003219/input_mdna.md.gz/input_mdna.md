# ADTN MD&A — 0000950170-21-003219


## mdna

[0000950170-21-003219:mdna:1]
[same as prior period, unchanged from 0001564590-21-042027:mdna:1]

[0000950170-21-003219:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and the related notes that appear in Part I, Item 1 of this document.  In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2020, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1, Business, and Item 1A, Risk Factors, included in our Annual Report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 26, 2021 (the “2020 Form 10-K”).

[0000950170-21-003219:mdna:3]
[same as prior period, unchanged from 0001564590-21-042027:mdna:3]

[0000950170-21-003219:mdna:4]
[same as prior period, unchanged from 0001564590-21-042027:mdna:4]

[0000950170-21-003219:mdna:5]
[same as prior period, unchanged from 0001564590-21-042027:mdna:5]

[0000950170-21-003219:mdna:6]
We ended the third quarter of 2021 with a year-over-year revenue increase of 3.7% as compared to the three months ended September 30, 2020, driven by increased shipments to a diverse mix of global Tier-1 and regional service providers. During the third quarter of 2021, we had two 10% revenue customers geographically diversified, one U.S. distributor and one international customer. Our year-over-year domestic revenue declined by 1.0% as compared to the three months ended September 30, 2020, driven by decreased network planning and implementation services in our Services & Support segment. Internationally, our revenue increased by 14.7% compared to the prior year period, primarily driven by access network builds in the Asia Pacific region, with a focus on Australia, increased shipments to alternative network operators and a Tier-1 operator in Europe. We experienced record demand for our solutions in the third quarter of 2021 setting an all-time high for bookings in a quarter. This increased demand comes from service providers planning to deploy our fiber access platforms, in-home service delivery platforms and SaaS applications. We expect this growth to accelerate. During the third quarter we secured two additional Tier-1 fiber customers, and previously announced Tier-1 fiber customers significantly increased their bookings for our fiber access platforms. Although our revenue growth and profitability in the near-term are impacted by supply chain issues, our long-term outlook continues to strengthen given the record demand for our products and our expectation of an improving supply chain in 2022.

[0000950170-21-003219:mdna:7]
In March 2020, the World Health Organization declared the novel coronavirus (COVID-19) outbreak a global pandemic. The SARS-CoV-2 coronavirus (or variants of the SARS-CoV-2 coronavirus, including the Delta variant) continues to spread throughout the U.S. and the world and has resulted in authorities implementing varying measures to contain the virus, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns. Although vaccines have been approved and are being distributed, it cannot be predicted how long it will take before market conditions return to normal and there can be no assurance that the economic recovery will occur or offset the uncertainty and instability triggered by the pandemic. New and potentially more contagious variants of the COVID-19 virus are developing in several countries, including regions in which we have significant operations. The COVID-19 variants could further amplify the impact of the pandemic. While we are unable to accurately predict the full impact that the COVID-19 global pandemic will have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time. We have experienced a significant impact to our supply chain given COVID-19 and the related global semiconductor chip shortage, including delays in supply chain deliveries, extended lead times and shortages of some key components, some raw material cost increases and slowdowns at certain production facilities. We have also had to increase our volume of inventory to ensure supply continuity during the pandemic. In addition, we have experienced significant increases in freight-related costs due to the global shipping crisis. During the third quarter of 2021, the Company incurred supply chain constraint expenses which lowered our gross margins and decreased our profitability. While throughout the pandemic we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments, as well as COVID-19 related reductions in travel and infrastructure expenses, it is possible that we could experience some slowdown in demand, further supply chain issues and an increased impact from the ongoing semiconductor shortage and shortages of certain other key components as the pandemic continues. If the impacts of this shortage are more severe than we expect, it could result in longer lead times, inventory supply challenges and further increased costs, all of which could result in the deterioration of our results, potentially for a longer period than currently anticipated. To support the health and well-being of our employees, customers, partners and communities, many of our employees are working remotely as of the date of filing this report. However, there is risk that a number of our employees could be infected with COVID-19, including our key personnel. In addition, actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for certain employees, as well as the impacts to our supply chain, including delays in supply chain deliveries and the related global semiconductor chip shortage, have delayed and may continue to delay the timing of some orders and expected deliveries. Lastly, even after the COVID-19 pandemic has subsided, we may continue to experience adverse impacts to our business as a result of any economic recession that has occurred or may occur in the future as a result of the COVID-19 pandemic.

[0000950170-21-003219:mdna:8]
Among our customers, we made progress with our fiber, fiber-extension, in-home service delivery platforms and cloud services while also continuing to engage in value-added service opportunities that we expect will contribute to sales over the remainder of 2021 and beyond. In addition, we believe that we are at the beginning of a significant investment cycle for fiber deployment and in-home Wi-Fi connectivity driven by technology advancements and regulatory influences. The transition to next-generation network architectures is beginning, and we are seeing demand for our next-generation fiber access and connected home solutions. In 2021, payments to service providers under government funding programs such as the FCC RDOF have started.

[0000950170-21-003219:mdna:9]
[same as prior period, unchanged from 0001564590-21-042027:mdna:10]

[0000950170-21-003219:mdna:10]
[same as prior period, unchanged from 0001564590-21-042027:mdna:11]

[0000950170-21-003219:mdna:11]
[same as prior period, unchanged from 0001564590-21-042027:mdna:12]

[0000950170-21-003219:mdna:12]
[same as prior period, unchanged from 0001564590-21-042027:mdna:13]

[0000950170-21-003219:mdna:13]
Our operating results have fluctuated, and may continue to fluctuate, on a quarterly basis due to several factors, including customer order activity, supply chain constraints, component availability, and backlog. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days requiring us to maintain higher inventory levels.  These factors normally result in a varying order backlog and limited order flow visibility; however, with the current global supply chain and transportation constraints, and limited availability of semiconductor chips and other components of our products, we have experienced and may continue to experience extended lead times, increased logistics intervals and costs, and lower volume of products deliveries, which has had and may continue to have a material adverse effect on our operating results and could have a material

[0000950170-21-003219:mdna:14]
adverse effect on customer relations and our financial condition. Normal operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0000950170-21-003219:mdna:15]
We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors, and customers to address and to limit the disruption to our operations and order fulfillment.

[0000950170-21-003219:mdna:16]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that initially resulted from the COVID-19 pandemic and that may recur, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results. In recent years, the Company initiated restructuring plans to realign its expense structure with the reduction in revenue experienced and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and implemented certain cost savings initiatives, where possible. See Note 19 of the Notes to Condensed Consolidated Financial Statements included in Part 1, Item 1 of this report for additional information on this restructuring.

[0000950170-21-003219:mdna:17]
[same as prior period, unchanged from 0001564590-21-042027:mdna:16]

[0000950170-21-003219:mdna:18]
BUSINESS COMBINATION AGREEMENT

[0000950170-21-003219:mdna:19]
On August 30, 2021, the Company and ADVA Optical Networking SE, a European stock corporation incorporated under the laws of the European Union and Germany (“ADVA”), entered into a business combination agreement (the “Business Combination Agreement”), pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, Acorn HoldCo, Inc. (the "surviving corporation"), a Delaware corporation and currently a wholly-owned direct subsidiary of the Company.

[0000950170-21-003219:mdna:20]
Under the terms of the Business Combination Agreement, Acorn MergeCo, Inc., a newly formed Delaware corporation and wholly-owned direct subsidiary of Acorn HoldCo (“Merger Sub”), will merge with and into ADTRAN, with ADTRAN surviving the merger (the “Merger”) as a wholly-owned direct subsidiary of Acorn HoldCo. Pursuant to the Merger, each outstanding share of common stock of the Company will be converted into the right to receive one share of common stock of Acorn HoldCo. Acorn HoldCo will also make a public exchange offer to exchange each issued and outstanding no-par value bearer share of ADVA, pursuant to which each ADVA share tendered and accepted for exchange will be exchanged for 0.8244 shares of common stock of Acorn HoldCo (the “Exchange Offer”, and together with the Merger, the “Business Combination”). Upon completion of the Business Combination, and assuming that all of the outstanding ADVA shares are exchanged in the Exchange Offer, former ADTRAN stockholders and former ADVA shareholders will own approximately 54% and 46%, respectively, of the outstanding Acorn HoldCo shares.

[0000950170-21-003219:mdna:21]
The Business Combination Agreement was unanimously approved by the Board of Directors of the Company and by the supervisory board and management board of ADVA. The Company anticipates consummation of the Business Combination during mid-2022, subject to customary closing conditions as well as regulatory and shareholder approvals.

[0000950170-21-003219:mdna:22]
Acorn HoldCo has entered into an irrevocable undertaking agreement (the “Irrevocable Undertaking”) with EGORA Holding GmbH and Egora Investments GmbH (collectively, the “Supporting Shareholders”) to validly accept the public exchange offer with respect to 7,000,000 shares held by them, representing 13.7% of the share capital of ADVA. The Irrevocable Undertaking includes other customary provisions, such as certain restrictions on the Supporting Shareholders from disposing of the relevant shares.

[0000950170-21-003219:mdna:23]
Additional information about the Business Combination Agreement and proposed Business Combination is set forth in the Company’s filings with the SEC, as well as in the registration statement on Form S-4 that Acorn HoldCo filed with the SEC, which has not yet become effective.

[0000950170-21-003219:mdna:24]
[same as prior period, unchanged from 0001564590-21-042027:mdna:17]

[0000950170-21-003219:mdna:25]
[same as prior period, unchanged from 0001564590-21-042027:mdna:18]

[0000950170-21-003219:mdna:26]
[same as prior period, unchanged from 0001564590-21-042027:mdna:19]

[0000950170-21-003219:mdna:27]
[same as prior period, unchanged from 0001564590-21-042027:mdna:20]

[0000950170-21-003219:mdna:28]
35

[0000950170-21-003219:mdna:29]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2021 COMPARED TO THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2020

[0000950170-21-003219:mdna:30]
[same as prior period, unchanged from 0001564590-21-042027:mdna:23]

[0000950170-21-003219:mdna:31]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 87.5 |  | % |  | 86.5 |  | % |  | 88.1 |  | % |  | 86.1 |  | % |
| Services & Support |  |  | 12.5 |  |  |  | 13.5 |  |  |  | 11.9 |  |  |  | 13.9 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 58.7 |  |  |  | 47.2 |  |  |  | 52.8 |  |  |  | 47.4 |  |  |
| Services & Support |  |  | 6.8 |  |  |  | 8.6 |  |  |  | 7.1 |  |  |  | 9.0 |  |  |
| Total Cost of Revenue |  |  | 65.5 |  |  |  | 55.7 |  |  |  | 59.9 |  |  |  | 56.4 |  |  |
| Gross Profit |  |  | 34.5 |  |  |  | 44.3 |  |  |  | 40.1 |  |  |  | 43.6 |  |  |
| Selling, general and administrative expenses |  |  | 22.4 |  |  |  | 20.4 |  |  |  | 21.8 |  |  |  | 22.5 |  |  |
| Research and development expenses |  |  | 19.4 |  |  |  | 20.4 |  |  |  | 20.1 |  |  |  | 22.8 |  |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Operating Income (Loss) |  |  | (7.3 | ) |  |  | 3.4 |  |  |  | (1.8 | ) |  |  | (1.7 | ) |  |
| Interest and dividend income |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |
| Interest expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Net investment gain (loss) |  |  | — |  |  |  | 2.1 |  |  |  | 0.7 |  |  |  | 0.5 |  |  |
| Other income (expense), net |  |  | 0.5 |  |  |  | (1.3 | ) |  |  | 0.7 |  |  |  | (0.6 | ) |  |
| Income (Loss) Before Income Taxes |  |  | (6.6 | ) |  |  | 4.5 |  |  |  | (0.2 | ) |  |  | (1.6 | ) |  |
| Income tax (expense) benefit |  |  | (0.9 | ) |  |  | (0.4 | ) |  |  | (0.8 | ) |  |  | 0.6 |  |  |
| Net Income (Loss) |  |  | (7.6 | ) | % |  | 4.1 |  | % |  | (1.1 | ) | % |  | (1.0 | ) | % |

[0000950170-21-003219:mdna:32]
[same as prior period, unchanged from 0001564590-21-042027:mdna:25]

[0000950170-21-003219:mdna:33]
Our revenue increased 3.7% from $133.1 million for the three months ended September 30, 2020 to $138.1 million for the three months ended September 30, 2021 and increased 8.6% from $376.4 million for the nine months ended September 30, 2020 to $408.8 million for the nine months ended September 30, 2021. The increase in revenue for the three and nine months ended September 30, 2021 was primarily attributable to a $3.8 million and $15.0 million increase in Access & Aggregation revenue, respectively, and a $1.8 million and $21.6 million increase in Subscriber Solutions & Experience revenue, respectively, partially offset by a $0.6 million and $4.2 million decrease in the revenue of our Traditional & Other Products, respectively. Although our revenue increased, supply of semiconductor chips and other components of our products has become constrained resulting in extended lead times and increased costs. Transportation constraints, including shortages for both air and surface freight, as well as labor shortages in the transportation industry, have also affected the timing and the cost of obtaining raw materials and production supplies. Although our revenue growth and profitability in the near-term may be impacted by these global supply chain issues, our long-term outlook continues to strengthen given the strong customer order bookings during the third quarter of 2021.

[0000950170-21-003219:mdna:34]
Network Solutions segment revenue increased 4.8% from $115.2 million for the three months ended September 30, 2020 to $120.8 million for the three months ended September 30, 2021 and increased 11.1% from $323.9 million for the nine months ended September 30, 2020 to $360.0 million for the nine months ended September 30, 2021. The increase in revenue for the three and nine months ended September 30, 2021 was due primarily to revenue of Subscriber Solutions & Experience and Access & Aggregation products. The increase in Subscriber Solutions & Experience revenue for the three and nine months ended September 30, 2021 was primarily attributable to increased volume of network termination and Fiber CPE. The increase in the Access & Aggregation category for the three and nine months ended September 30, 2021 was due to increased volume of fiber access. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0000950170-21-003219:mdna:35]
Services & Support segment revenue decreased 3.3% from $17.9 million for the three months ended September 30, 2020 to $17.3 million for the three months ended September 30, 2021 and decreased 6.9% from $52.5 million for the nine months ended September 30, 2020 to $48.8 million for the nine months ended September 30, 2021. The decrease in revenue for the three and nine months ended September 30, 2021 was primarily attributable to decreased network planning and implementation services partially offset by an increase in maintenance and managed services.

[0000950170-21-003219:mdna:36]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments amounts and provided to a customer outside of the U.S., increased 15% from $34.3 million for the three months ended September 30, 2020 to $39.4 million for the three months ended September 30, 2021 and increased 13.1% from $120.1 million for the nine months ended September 30, 2020 to $135.8 million for the nine months ended September 30, 2021. International revenue, as a percentage of total revenue, increased from 29.8% for the three months ended September 30, 2020 to 32.7% for the three months ended September 30, 2021 and increased from 31.9% for the nine months ended September 30, 2020 to 33.2% for the nine months ended September 30, 2021. The increase in percentage of international revenue for the three and nine months ended September 30, 2021, was primarily driven by access network builds in the Asia Pacific region with a focus on Australia, increased shipments to alternative network operators in Europe and revenue from a Tier-1 operator in Europe.

[0000950170-21-003219:mdna:37]
Our international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. The competitive landscape in certain international markets is also affected by the increased presence of Asian manufacturers that seek to compete aggressively on price.

[0000950170-21-003219:mdna:38]
As a result of our global operations, our revenue and operating income in some international markets can be affected by foreign currency fluctuations. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income. However, for the three and nine months ended September 30, 2021, foreign currency fluctuations did not materially impact the Company's results of operations.

[0000950170-21-003219:mdna:39]
[same as prior period, unchanged from 0001564590-21-042027:mdna:31]

[0000950170-21-003219:mdna:40]
As a percentage of revenue, cost of revenue increased from 55.7% for the three months ended September 30, 2020 to 65.5% for the three months ended September 30, 2021 and increased from 56.4% for the nine months ended September 30, 2020 to 59.9% for the nine months ended September 30, 2021. For the three months ended September 30, 2021, the increase was primarily attributable to supply chain constraint related expenses. For the nine months ended September 30, 2021, the increase was primarily attributable to supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift.

[0000950170-21-003219:mdna:41]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 54.5% for the three months ended September 30, 2020 to 67.1% for the three months ended September 30, 2021 and increased from 55.1% for the nine months ended September 30, 2020 to 60.0% for the nine months ended September 30, 2021. The increase in cost of revenue as a percentage of revenue for the three and nine months ended September 30, 2021 was primarily attributable to supply chain constraint related expenses. The increase in cost of revenue as a percentage of revenue for the nine months ended September 30, 2021 was primarily attributable to supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift.

[0000950170-21-003219:mdna:42]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 63.6% for the three months ended September 30, 2020 to 54.2% for the three months ended September 30, 2021 and decreased from 64.5% for the nine months ended September 30, 2020 to 59.1% for the nine months ended September 30, 2021. The decrease in cost of revenue as a percentage of revenue for the three and nine months ended September 30, 2021 was primarily attributable to customer mix, changes in services and support mix.

[0000950170-21-003219:mdna:43]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0000950170-21-003219:mdna:44]
[same as prior period, unchanged from 0001564590-21-042027:mdna:37]

[0000950170-21-003219:mdna:45]
As a percentage of revenue, selling, general and administrative expenses increased from 20.4% for the three months ended September 30, 2020 to 22.4% for the three months ended September 30, 2021 and decreased from 22.5% for the nine months ended September 30, 2020 to 21.8% for the nine months ended September 30, 2021. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0000950170-21-003219:mdna:46]
Selling, general and administrative expenses increased 13.8% from $27.2 million for the three months ended September 30, 2020 to $31.0 million for the three months ended September 30, 2021 and increased 5.5% from $84.6 million for the nine months ended September 30, 2020 to $89.3 million for the nine months ended September 30, 2021. The increase in selling, general and administrative expenses for the three months ended September 30, 2021 was primarily attributable to increased acquisition expenses and labor related expenses, partially offset by deferred compensation related costs and lower restructuring expenses. The increase in selling, general and administrative expenses for the nine months ended September 30, 2021 was primarily attributable to increased acquisition expenses, deferred compensation related costs and insurance expense, partially offset by decreases in restructuring expenses, travel related expense and legal expense.

[0000950170-21-003219:mdna:47]
[same as prior period, unchanged from 0001564590-21-042027:mdna:40]

[0000950170-21-003219:mdna:48]
As a percentage of revenue, research and development expenses decreased from 20.4% for the three months ended September 30, 2020 to 19.4% for the three months ended September 30, 2021 and decreased from 22.8% for the nine months ended September 30, 2020 to 20.1% for the nine months ended September 30, 2021. Research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0000950170-21-003219:mdna:49]
Research and development expenses decreased 1.7% from $27.2 million for the three months ended September 30, 2020 to $26.8 million for the three months ended September 30, 2021 and decreased 4.3% from $85.8 million for the nine months ended September 30, 2020 to $82.1 million for the nine months ended September 30, 2021. The decrease in research and development expenses for the three and nine months ended September 30, 2021 was primarily attributable to lower personnel costs which were mainly the result of our restructuring programs, partially offset by increased contract services.

[0000950170-21-003219:mdna:50]
[same as prior period, unchanged from 0001564590-21-042027:mdna:43]

[0000950170-21-003219:mdna:51]
[same as prior period, unchanged from 0001564590-21-042027:mdna:44]

[0000950170-21-003219:mdna:52]
Asset impairments, which were $0.1 million for the nine months ended September 30, 2020, related to the abandonment of certain information technology projects in which we had previously capitalized costs. There were no asset impairments recognized during the three months ended September 30, 2020 or September 30, 2021 or for the nine months ended September 30, 2021.

[0000950170-21-003219:mdna:53]
[same as prior period, unchanged from 0001564590-21-042027:mdna:46]

[0000950170-21-003219:mdna:54]
Interest and dividend income remained constant at $0.3 million for the three months ended September 30, 2020 and 2021, and decreased 14.0% from $1.0 million for the nine months ended September 30, 2020 to $0.9 million for the nine months ended September 30, 2021. The decrease in interest and dividend income was primarily attributable to a decrease in the rate of return on our investments due to lower interest rates. Our total investments increased from $84.2 million as of September 30, 2020 to $86.5 million as of September 30, 2021.

[0000950170-21-003219:mdna:55]
[same as prior period, unchanged from 0001564590-21-042027:mdna:48]

[0000950170-21-003219:mdna:56]
Interest expense was less than $0.1 million for each of the three and nine months ended September 30, 2021 and 2020. Interest expense during the first nine months of 2021 was primarily related to our Revolving Credit Agreement that we entered into during the fourth quarter of 2020.

[0000950170-21-003219:mdna:57]
[same as prior period, unchanged from 0001564590-21-042027:mdna:50]

[0000950170-21-003219:mdna:58]
We recognized a net investment gain of $2.8 million and a net investment loss of $0.1 million for the three months ended September 30, 2020 and 2021, respectively, and a net investment gain of $1.8 million and $2.9 million for the nine months ended September 30, 2020 and 2021, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility, whether from COVID-19 or other factors, will result in continued volatility in our investment portfolio. See Note 6 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-21-003219:mdna:59]
[same as prior period, unchanged from 0001564590-21-042027:mdna:52]

[0000950170-21-003219:mdna:60]
Other income (expense), net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, improved from expense of $1.7 million for the three months ended September 30, 2020 to income of $0.6 million for the three months ended September 30, 2021 and improved from expense of $2.3 million for the nine months ended September 30, 2020 to income of $2.7 million for the nine months ended September 30, 2021.

[0000950170-21-003219:mdna:61]
[same as prior period, unchanged from 0001564590-21-042027:mdna:54]

[0000950170-21-003219:mdna:62]
Our effective tax rate increased from an expense of 9.3% of pre-tax income for the three months ended September 30, 2020, to an expense of 14.1% of pre-tax loss for the three months ended September 30, 2021 and increased from a benefit of 36.8% of pre-tax loss for the nine months ended September 30, 2020 to an expense of 354.5% of pre-tax loss for the nine months ended September 30, 2021. The change in the effective tax rate for the three months ended September 30, 2021 was driven by tax expense in our international operations and additional changes in the valuation allowance related to our domestic operations. The change in the effective tax rate for the nine months ended September 30, 2021 was primarily driven by a tax benefit of $7.8 million recognized during the nine months ended September 30, 2020 as a result of the enactment of the CARES Act in March 2020. See Note 4 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0000950170-21-003219:mdna:63]
[same as prior period, unchanged from 0001564590-21-042027:mdna:56]

[0000950170-21-003219:mdna:64]
As a result of the above factors, net income (loss) decreased from net income of $5.5 million for the three months ended September 30, 2020 to a net loss of $10.4 million for the three months ended September 30, 2021 and from a net loss of $3.7 million for the nine months ended September 30, 2020 to net loss of $4.4 million for the nine months ended September 30, 2021.

[0000950170-21-003219:mdna:65]
[same as prior period, unchanged from 0001564590-21-042027:mdna:58]

[0000950170-21-003219:mdna:66]
[same as prior period, unchanged from 0001564590-21-042027:mdna:59]

[0000950170-21-003219:mdna:67]
We have historically financed, and we currently expect to continue to finance, our ongoing business with existing cash, investments and cash flow from operations. We have used, and expect to continue to use, existing cash, investments and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expansion of our sales and marketing activities and capital expenditures. We believe that our cash and cash equivalents, investments and cash generated from operations will be adequate to meet our operating and capital needs for at least the next 12 months.

[0000950170-21-003219:mdna:68]
As of September 30, 2021, cash on hand was $75.5 million and short-term investments were $2.6 million, which resulted in available short-term liquidity of $78.1 million, of which $55.9 million was held by our foreign subsidiaries. As of December 31, 2020, cash on hand was $60.2 million and short-term investments were $3.1 million, which resulted in available short-term liquidity of $63.3 million, of which $49.7 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax.

[0000950170-21-003219:mdna:69]
During the fourth quarter of 2020, the Company entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. Based on the market value of the collateral at September 30, 2021, the Company had $10.0 million of loan availability under the revolving credit facility as of such date. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company entered into the Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. To date, the Company has not made any draws under the Revolving Credit Agreement. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company, which negative covenants are subject to certain exceptions. The Company must be in compliance with all covenants to be able to draw on the line of credit. As of September 30, 2021, the Company was in compliance with all covenants.

[0000950170-21-003219:mdna:70]
[same as prior period, unchanged from 0001564590-21-042027:mdna:63]

[0000950170-21-003219:mdna:71]
Net cash provided by operating activities of $28.9 million during the nine months ended September 30, 2021 increased by $34.2 million compared to net cash used of $5.3 million during the nine months ended September 30, 2020. This increase was primarily due to net cash inflows from working capital, specifically, an increase in the average number days payable to our trade suppliers, a decrease in other receivables and an increase in inventory turnover, and partially offset by an increase in accounts receivable and the average number of days it takes the Company to collect cash payment for sales. Additional details related to our working capital and its drivers are discussed below.

[0000950170-21-003219:mdna:72]
Net accounts receivable increased 25.6% from $98.8 million as of December 31, 2020 to $124.1 million as of September 30, 2021. Our allowance for expected credit losses was $38 thousand as of December 31, 2020. There was no allowance for expected credit losses as of September 30, 2021. The increase in net accounts receivable was due to an increase in sales volume and the timing of shipments within the quarter. Quarterly accounts receivable DSO increased from 70 days as of December 31, 2020 to 83 days as of September 30, 2021. The increase in DSO was due to the timing of product shipments and customer mix.

[0000950170-21-003219:mdna:73]
Other receivables decreased 54.2% from $21.5 million as of December 31, 2020 to $9.9 million as of September 30, 2021. The decrease in other receivables was primarily attributable to the receipt of an income tax refund and a decrease in contract manufacturer purchases.

[0000950170-21-003219:mdna:74]
Quarterly inventory turnover increased from 2.5 turns as of December 31, 2020 to 2.9 turns as of September 30, 2021. Inventory increased 1.4% from $125.5 million as of December 31, 2020 to $127.2 million as of September 30, 2021. While we remain subject to COVID-19 uncertainties related to supply chain and demand, we expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business and ensuring competitive lead times while managing the risk of inventory.

[0000950170-21-003219:mdna:75]
Accounts payable increased 58.4% from $49.9 million as of December 31, 2020 to $79.1 million as of September 30, 2021. The increase was primarily due to an increase in the average number days payable to our trade suppliers,. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0000950170-21-003219:mdna:76]
[same as prior period, unchanged from 0001564590-21-042027:mdna:69]

[0000950170-21-003219:mdna:77]
Capital expenditures totaled approximately $3.6 million and $5.1 million for the nine months ended September 30, 2021 and 2020, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and to finance building improvements.

[0000950170-21-003219:mdna:78]
Our combined short-term and long-term investments increased $3.2 million from $83.3 million as of December 31, 2020 to $86.5 million as of September 30, 2021. This increase reflects the impact of net realized and unrealized gains and losses on our investments.

[0000950170-21-003219:mdna:79]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 6 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information. As of September 30, 2021, our corporate bonds, municipal bonds, asset-backed bonds, mortgage/agency bonds, U.S. government bonds, other government bonds and variable-rate demand notes were classified as available-for-sale and had a combined duration of 1.67 years with an average Standard & Poor’s credit rating of AA-. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0000950170-21-003219:mdna:80]
Our long-term investments increased 4.7% from $80.1 million as of December 31, 2020 to $83.9 million as of September 30, 2021.  Our investments include various marketable equity securities classified as long-term investments with a fair market value of $12.1 million and $11.0 million as of September 30, 2021 and December 31, 2020, respectively. Long-term investments as of September 30, 2021 and December 31, 2020 also included $25.7 million and $23.9 million, respectively, related to our deferred compensation plans.

[0000950170-21-003219:mdna:81]
[same as prior period, unchanged from 0001564590-21-042027:mdna:74]

[0000950170-21-003219:mdna:82]
[same as prior period, unchanged from 0001564590-21-042027:mdna:75]

[0000950170-21-003219:mdna:83]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the nine months ended September 30, 2021 and 2020, we paid dividends totaling $13.1 million and $13.0 million, respectively. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0000950170-21-003219:mdna:84]
[same as prior period, unchanged from 0001564590-21-042027:mdna:77]

[0000950170-21-003219:mdna:85]
To accommodate employee stock option exercises, the Company issued 0.1 million and 0.4 million shares of treasury stock which resulted in proceeds of $2.6 million and $6.1 million during the three and nine months ended September 30, 2021, respectively. No stock options were exercised during the three and nine months ended September 30, 2020.

[0000950170-21-003219:mdna:86]
[same as prior period, unchanged from 0001564590-21-042027:mdna:79]

[0000950170-21-003219:mdna:87]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0000950170-21-003219:mdna:88]
[same as prior period, unchanged from 0001564590-21-042027:mdna:81]

[0000950170-21-003219:mdna:89]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2021 and December 31, 2020, we had commitments related to these bonds totaling $20.9 million and $15.2 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-21-003219:mdna:90]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021, as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.4 million as of September 30, 2021, of which $0.1 million is included in restricted cash and $18.3 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of September 30, 2021, the Company was in compliance with all contractual requirements under the letter of credit.

[0000950170-21-003219:mdna:91]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of September 30, 2021.

[0000950170-21-003219:mdna:92]
During the nine months ended September 30, 2021, there have been no other material changes in contractual obligations and commercial commitments from those discussed in the 2020 Form 10-K.

[0000950170-21-003219:mdna:93]
42
