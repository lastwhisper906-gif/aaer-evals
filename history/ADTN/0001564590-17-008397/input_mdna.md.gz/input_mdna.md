# ADTN MD&A — 0001564590-17-008397


## mdna

[0001564590-17-008397:mdna:1]
[same as prior period, unchanged from 0001564590-16-028206:mdna:1]

[0001564590-17-008397:mdna:2]
[same as prior period, unchanged from 0001564590-16-028206:mdna:2]

[0001564590-17-008397:mdna:3]
[same as prior period, unchanged from 0001564590-16-028206:mdna:3]

[0001564590-17-008397:mdna:4]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications across a variety of network infrastructures. These solutions are deployed by many of the United States’ and the world’s largest communications service providers (CSPs), distributed enterprises and small and medium-sized businesses, public and private enterprises, and millions of individual users worldwide.

[0001564590-17-008397:mdna:5]
[same as prior period, unchanged from 0001564590-16-028206:mdna:5]

[0001564590-17-008397:mdna:6]
[same as prior period, unchanged from 0001564590-16-028206:mdna:6]

[0001564590-17-008397:mdna:7]
Access & Aggregation solutions are used by CSPs to connect their network infrastructure to their subscribers. This category includes software and hardware-based products and services that aggregate and/or originate access technologies. The portfolio of ADTRAN solutions within this category includes a wide array of modular or fixed physical form factors designed to deliver the best technology and economic fit based on the target subscriber density and environmental conditions.

[0001564590-17-008397:mdna:8]
[same as prior period, unchanged from 0001564590-16-028206:mdna:8]

[0001564590-17-008397:mdna:9]
[same as prior period, unchanged from 0001564590-16-028206:mdna:9]

[0001564590-17-008397:mdna:10]
|  | • | hiX 5600 Series fiber aggregation and FTTN MSAN |

[0001564590-17-008397:mdna:11]
[same as prior period, unchanged from 0001564590-16-028206:mdna:12]

[0001564590-17-008397:mdna:12]
|  | • | GPON, EPON and 10G PON Optical Line Terminals (OLT) |

[0001564590-17-008397:mdna:13]
|  | • | SDX Fiber Access network elements |

[0001564590-17-008397:mdna:14]
[same as prior period, unchanged from 0001564590-16-028206:mdna:14]

[0001564590-17-008397:mdna:15]
[same as prior period, unchanged from 0001564590-16-028206:mdna:16]

[0001564590-17-008397:mdna:16]
[same as prior period, unchanged from 0001564590-16-028206:mdna:17]

[0001564590-17-008397:mdna:17]
|  | • | Network Management and Cloud-based software platforms and applications |

[0001564590-17-008397:mdna:18]
[same as prior period, unchanged from 0001564590-16-028206:mdna:19]

[0001564590-17-008397:mdna:19]
|  | • | Planning, engineering, program management, maintenance, installation and commissioning services to implement customer network solutions |

[0001564590-17-008397:mdna:20]
[same as prior period, unchanged from 0001564590-16-028206:mdna:20]

[0001564590-17-008397:mdna:21]
Customer Devices includes our products and services that provide end users access to CSP networks. Our Customer Devices portfolio includes a comprehensive array of service provider and enterprise hardware and software products and services.

[0001564590-17-008397:mdna:22]
[same as prior period, unchanged from 0001564590-16-028206:mdna:22]

[0001564590-17-008397:mdna:23]
[same as prior period, unchanged from 0001564590-16-028206:mdna:23]

[0001564590-17-008397:mdna:24]
[same as prior period, unchanged from 0001564590-16-028206:mdna:24]

[0001564590-17-008397:mdna:25]
[same as prior period, unchanged from 0001564590-16-028206:mdna:25]

[0001564590-17-008397:mdna:26]
[same as prior period, unchanged from 0001564590-16-028206:mdna:26]

[0001564590-17-008397:mdna:27]
[same as prior period, unchanged from 0001564590-16-028206:mdna:27]

[0001564590-17-008397:mdna:28]
[same as prior period, unchanged from 0001564590-16-028206:mdna:28]

[0001564590-17-008397:mdna:29]
[same as prior period, unchanged from 0001564590-16-028206:mdna:29]

[0001564590-17-008397:mdna:30]
[same as prior period, unchanged from 0001564590-16-028206:mdna:30]

[0001564590-17-008397:mdna:31]
|  | • | ProServices pre-sale and post-sale technical support |

[0001564590-17-008397:mdna:32]
[same as prior period, unchanged from 0001564590-16-028206:mdna:32]

[0001564590-17-008397:mdna:33]
[same as prior period, unchanged from 0001564590-16-028206:mdna:33]

[0001564590-17-008397:mdna:34]
[same as prior period, unchanged from 0001564590-16-028206:mdna:34]

[0001564590-17-008397:mdna:35]
[same as prior period, unchanged from 0001564590-16-028206:mdna:35]

[0001564590-17-008397:mdna:36]
[same as prior period, unchanged from 0001564590-16-028206:mdna:36]

[0001564590-17-008397:mdna:37]
[same as prior period, unchanged from 0001564590-16-028206:mdna:37]

[0001564590-17-008397:mdna:38]
[same as prior period, unchanged from 0001564590-16-028206:mdna:38]

[0001564590-17-008397:mdna:39]
[same as prior period, unchanged from 0001564590-16-028206:mdna:39]

[0001564590-17-008397:mdna:40]
Sales were $170.3 million for the three months ended March 31, 2017 compared to $142.2 million for the three months ended March 31, 2016. Our gross margin decreased to 43.3% for the three months ended March 31, 2017 from 46.3% for the three months ended March 31, 2016. Our operating income margin increased to 4.1% for the three months ended March 31, 2017 from 3.9% for the three months ended March 31, 2016. Net income was $6.7 million for the three months ended March 31, 2017, compared to $5.0 million for the three months ended March 31, 2016. Our effective tax rate decreased to 20.3% for the three months ended March 31, 2017 from 37.9% for the three months ended March 31, 2016.  Earnings per share, assuming dilution, were $0.14 for the three months ended March 31, 2017, compared to $0.10 for the three months ended March 31, 2016.

[0001564590-17-008397:mdna:41]
[same as prior period, unchanged from 0001564590-16-028206:mdna:41]

[0001564590-17-008397:mdna:42]
[same as prior period, unchanged from 0001564590-16-028206:mdna:42]

[0001564590-17-008397:mdna:43]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Item 1A of Part I in our most recent Annual Report on Form 10-K for the year ended December 31, 2016, filed on February 24, 2017 with the SEC.

[0001564590-17-008397:mdna:44]
[same as prior period, unchanged from 0001564590-16-028206:mdna:44]

[0001564590-17-008397:mdna:45]
Our critical accounting policies and estimates have not changed significantly from those detailed in our most recent Annual Report on Form 10-K for the year ended December 31, 2016, filed on February 24, 2017 with the SEC.

[0001564590-17-008397:mdna:46]
[same as prior period, unchanged from 0001564590-16-028206:mdna:46]

[0001564590-17-008397:mdna:47]
[same as prior period, unchanged from 0001564590-16-028206:mdna:47]

[0001564590-17-008397:mdna:48]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2017 COMPARED TO THREE MONTHS ENDED MARCH 31, 2016

[0001564590-17-008397:mdna:49]
[same as prior period, unchanged from 0001564590-16-028206:mdna:49]

[0001564590-17-008397:mdna:50]
Our sales increased 19.7% from $142.2 million in the three months ended March 31, 2016 to $170.3 million in the three months ended March 31, 2017. The increase in sales for the three months ended March 31, 2017 is primarily attributable to a $26.3 million increase in sales of our Access & Aggregation products, a $3.9 million increase in sales of our Customer Devices products, partially offset by a $2.1 million decrease in sales of our Traditional & Other products.

[0001564590-17-008397:mdna:51]
Network Solutions sales increased 15.9% from $123.9 million in the three months ended March 31, 2016 to $143.6 million in the three months ended March 31, 2017. The increase in sales for the three months ended March 31, 2017 is primarily attributable to an increase in sales of Access & Aggregation products and Customer Devices products, partially offset by a decrease in sales of our Traditional & Other products. The increase in sales of our Access & Aggregation products for the three months ended March 31, 2017 is primarily attributable to increased VDSL2 vectoring product sales in the European carrier market. The increase in sales of our Customer Devices products is primarily attributable to increased fiber product sales in the North American cable MSO market. While we expect that revenues from Traditional & Other products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-17-008397:mdna:52]
Services & Support sales increased 45.6% from $18.3 million in the three months ended March 31, 2016 to $26.7 million in the three months ended March 31, 2017. The increase in sales for the three months ended March 31, 2017 is primarily attributable to an increase in network installation services for Access & Aggregation products.

[0001564590-17-008397:mdna:53]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, increased 97.3% from $25.9 million in the three months ended March 31, 2016 to $51.0 million in the three months ended March 31, 2017. International sales, as a percentage of total sales, increased from 18.2% for the three months ended March 31, 2016 to 30.0% for the three months ended March 31, 2017. Our international revenues are affected to a great extent by the timing of network upgrade projects at our larger European customers and by changes in foreign exchange rates in territories in which we sell our products and services. In first quarter 2017, international network upgrades resumed; whereas, in 2016 our largest European customer focused on completing network upgrade activities in regions outside of our footprint with them.

[0001564590-17-008397:mdna:54]
[same as prior period, unchanged from 0001564590-16-028206:mdna:54]

[0001564590-17-008397:mdna:55]
As a percentage of sales, cost of sales increased from 53.7% in the three months ended March 31, 2016 to 56.7% in the three months ended March 31, 2017. The increase in cost of sales as a percentage of sales for the three months ended March 31, 2017 is primarily attributable to a regional revenue shift, customer and product mix, and services and support mix, partially offset by a reduction in warranty expense related to a settlement with a third party supplier for a defective component and purchase discounts received from a contract manufacturer.

[0001564590-17-008397:mdna:56]
Network Solutions cost of sales, as a percent of that segment’s sales, increased from 51.7% in the three months ended March 31, 2016 to 53.4% in the three months ended March 31, 2017. The increase in the cost of sales percentage for the three months ended March 31, 2017 is primarily attributable to a regional revenue shift and customer and product mix, partially offset by a reduction in warranty expense related to a settlement with a third party supplier for a defective component and purchase discounts received from a contract manufacturer.

[0001564590-17-008397:mdna:57]
Services & Support cost of sales, as a percent of that segment’s sales, increased from 67.3% in the three months ended March 31, 2016 to 74.6% in the three months ended March 31, 2017. The increase in the cost of sales percentage for the three months ended March 31, 2017 is primarily attributable to an increase in network installation services in the first quarter of 2017, which have higher costs, as opposed to a greater mix of maintenance and support services, which have lower costs, realized in the first quarter of 2016.

[0001564590-17-008397:mdna:58]
[same as prior period, unchanged from 0001564590-16-028206:mdna:58]

[0001564590-17-008397:mdna:59]
[same as prior period, unchanged from 0001564590-16-028206:mdna:59]

[0001564590-17-008397:mdna:60]
Selling, general and administrative expenses increased 12.9% from $30.8 million in the three months ended March 31, 2016 to $34.8 million in the three months ended March 31, 2017. The increase in selling, general and administrative expenses for the three months ended March 31, 2017 is primarily attributable to increases in ERP implementation expenses, travel expenses and performance-based compensation expense.

[0001564590-17-008397:mdna:61]
As a percentage of sales, selling, general and administrative expenses decreased from 21.6% in the three months ended March 31, 2016 to 20.4% in the three months ended March 31, 2017. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-17-008397:mdna:62]
[same as prior period, unchanged from 0001564590-16-028206:mdna:62]

[0001564590-17-008397:mdna:63]
Research and development expenses increased 8.2% from $29.5 million in the three months ended March 31, 2016 to $31.9 million in the three months ended March 31, 2017. The increase in research and development expenses for the three months ended March 31, 2017 is primarily attributable to an increase in labor and engineering materials cost related to customer specific projects and amortization of intangibles acquired in the third quarter of 2016.

[0001564590-17-008397:mdna:64]
As a percentage of sales, research and development expenses decreased from 20.7% in the three months ended March 31, 2016 to 18.7% in the three months ended March 31, 2017. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001564590-17-008397:mdna:65]
[same as prior period, unchanged from 0001564590-16-028206:mdna:65]

[0001564590-17-008397:mdna:66]
[same as prior period, unchanged from 0001564590-16-028206:mdna:66]

[0001564590-17-008397:mdna:67]
Interest and dividend income increased 9.1%, or $0.1 million, in the three months ended March 31, 2016 to the three months ended March 31, 2017. The increase in interest and dividend income for the three months ended March 31, 2017 is primarily attributable to an increase in the rate of return on fixed income investments.

[0001564590-17-008397:mdna:68]
[same as prior period, unchanged from 0001564590-16-028206:mdna:68]

[0001564590-17-008397:mdna:69]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended March 31, 2016 and 2017, respectively, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-17-008397:mdna:70]
[same as prior period, unchanged from 0001564590-16-028206:mdna:70]

[0001564590-17-008397:mdna:71]
Net realized investment gains decreased 72.8% from $1.7 million in the three months ended March 31, 2016 to $0.5 million in the three months ended March 31, 2017. The decrease in realized investment gains for the three months ended March 31, 2017 is primarily attributable to decreased gains from the sale of equity securities. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-17-008397:mdna:72]
[same as prior period, unchanged from 0001564590-16-028206:mdna:72]

[0001564590-17-008397:mdna:73]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, and scrap raw material sales, remained constant at $0.1 million of income in the three months ended March 31, 2016 and 2017, respectively.

[0001564590-17-008397:mdna:74]
[same as prior period, unchanged from 0001564590-16-028206:mdna:74]

[0001564590-17-008397:mdna:75]
Our effective tax rate decreased from 37.9% in the three months ended March 31, 2016 to 20.3% in the three months ended March 31, 2017. The decrease in the effective tax rate between the two periods is primarily attributable to an 11% effective rate reduction for a provision-to-return adjustment related to the assignment of research and development expenditures to specific company engineering locations, and the effective income tax rates among the respective jurisdictions.

[0001564590-17-008397:mdna:76]
[same as prior period, unchanged from 0001564590-16-028206:mdna:76]

[0001564590-17-008397:mdna:77]
As a result of the above factors, net income increased $1.6 million from $5.0 million in the three months ended March 31, 2016 to $6.7 million in the three months ended March 31, 2017.

[0001564590-17-008397:mdna:78]
As a percentage of sales, net income increased from 3.5% in the three months ended March 31, 2016 to 3.9% in the three months ended March 31, 2017.

[0001564590-17-008397:mdna:79]
[same as prior period, unchanged from 0001564590-16-028206:mdna:80]

[0001564590-17-008397:mdna:80]
[same as prior period, unchanged from 0001564590-16-028206:mdna:81]

[0001564590-17-008397:mdna:81]
[same as prior period, unchanged from 0001564590-16-028206:mdna:82]

[0001564590-17-008397:mdna:82]
At March 31, 2017, cash on hand was $72.6 million and short-term investments were $52.5 million, which resulted in available short-term liquidity of $125.0 million, of which $51.9 million was held by our foreign subsidiaries. At December 31, 2016, cash on hand was $79.9 million and short-term investments were $43.2 million, which resulted in available short-term liquidity of $123.1 million, of which $42.1 million was held by our foreign subsidiaries. We intend to permanently reinvest these funds outside the U.S. and our current business plans do not indicate a need to repatriate to fund domestic operations. The increase in short-term liquidity from December 31, 2016 to March 31, 2017 is primarily attributable to shifts among available investment option tenures to provide funds for our short-term cash needs.

[0001564590-17-008397:mdna:83]
[same as prior period, unchanged from 0001564590-16-028206:mdna:84]

[0001564590-17-008397:mdna:84]
Our working capital, which consists of current assets less current liabilities, increased 2.8% from $226.4 million as of December 31, 2016 to $232.8 million as of March 31, 2017, and our current ratio, defined as current assets divided by current liabilities, increased from 2.79 as of December 31, 2016 to 2.91 as of March 31, 2017. The increase in our working capital and current ratio is primarily attributable to an increase in inventory and a decrease in accounts payable and accrued wages and benefits, partially offset by a decrease in accounts receivable and an increase in accrued expenses and income tax payable. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, increased from 1.70 as of December 31, 2016 to 1.73 as of March 31, 2017. The increase in the quick ratio is primarily attributable to a decrease in accrued wages and benefits and accounts payable, partially offset by an increase in accrued expenses and income tax payable.

[0001564590-17-008397:mdna:85]
Accounts receivable decreased 7.5% from $92.3 million at December 31, 2016 to $85.4 million at March 31, 2017. We had no allowance for doubtful accounts at December 31, 2016 or March 31, 2017. Quarterly accounts receivable days sales outstanding (DSO) decreased from 52 days as of December 31, 2016 to 45 days as of March 31, 2017. The change in net accounts receivable is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than U.S. customers. Other receivables decreased from $15.1 million at December 31, 2016 to $13.4 million at March 31, 2017. The decrease in other receivables is primarily attributable to the timing of filing returns and collections of VAT receivables in our international subsidiaries. Other receivables will also fluctuate due to the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001564590-17-008397:mdna:86]
Quarterly inventory turnover decreased from 3.67 turns as of December 31, 2016 to 3.55 turns at March 31, 2017. Inventory increased 7.3% from December 31, 2016 to March 31, 2017. The increase in inventory at March 31, 2017 is primarily attributable to customer specific projects and volume discount purchases. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-17-008397:mdna:87]
Accounts payable decreased 3.9% from $77.3 million at December 31, 2016 to $74.3 million at March 31, 2017. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-17-008397:mdna:88]
[same as prior period, unchanged from 0001564590-16-028206:mdna:89]

[0001564590-17-008397:mdna:89]
Capital expenditures totaled approximately $3.9 million and $3.2 million for the three months ended March 31, 2017 and 2016, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-17-008397:mdna:90]
Our combined short-term and long-term investments increased $7.6 million from $219.3 million at December 31, 2016 to $226.9 million at March 31, 2017. This increase reflects funds available for investment provided by our operating activities and stock option exercises by our employees, partially offset by our cash needs for capital expenditures, purchases of treasury stock, and shareholder dividends, as well as net realized and unrealized gains and losses and amortization of net premiums on our combined investments.

[0001564590-17-008397:mdna:91]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At March 31, 2017 these investments included corporate bonds of $72.3 million, municipal fixed-rate bonds of $11.0 million, asset-backed bonds of $11.8 million, mortgage/agency-backed bonds of $12.3 million, U.S. government bonds of $28.0 million, foreign government bonds of $3.3 million and variable rate demand notes of $10.5 million. At December 31, 2016, these investments included corporate bonds of $66.4 million, municipal fixed-rate bonds of $11.8 million, asset-backed bonds of $10.2 million, mortgage/agency-backed bonds of $13.0 million, U.S. government bonds of $29.8 million, foreign government bonds of $3.7 million and variable rate demand notes of $11.9 million. As of March 31, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, foreign government bonds and variable rate demand notes were classified as available-for-sale and had a combined duration of 1.1 years with an average Standard & Poor’s credit rating of AA-. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-17-008397:mdna:92]
Our long-term investments decreased 1.0% from $176.1 million at December 31, 2016 to $174.4 million at March 31, 2017. Long-term investments at March 31, 2017 and December 31, 2016 included an investment in a certificate of deposit of $27.8 million, which serves as collateral for our revenue bond. See “Debt” below for additional information. We have various equity investments included in long-term investments at a cost of $30.9 million and $30.6 million, and with a fair value of $31.8 million and $29.4 million, at March 31, 2017 and December 31, 2016, respectively.

[0001564590-17-008397:mdna:93]
Long-term investments at March 31, 2017 and December 31, 2016 also included $17.4 million and $14.6 million, respectively, related to our deferred compensation plans, and $0.7 million and $0.8 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001564590-17-008397:mdna:94]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three months ended March 31, 2017 and 2016, other-than-temporary impairment charges were not significant.

[0001564590-17-008397:mdna:95]
[same as prior period, unchanged from 0001564590-16-028206:mdna:97]

[0001564590-17-008397:mdna:96]
[same as prior period, unchanged from 0001564590-16-028206:mdna:98]

[0001564590-17-008397:mdna:97]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the three months ended March 31, 2017, we paid dividends totaling $4.4 million.

[0001564590-17-008397:mdna:98]
[same as prior period, unchanged from 0001564590-16-028206:mdna:100]

[0001564590-17-008397:mdna:99]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $27.8 million at March 31, 2017 and December 31, 2016. At March 31, 2017, the estimated fair value of the Bond was approximately $27.9 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $27.8 million at March 31, 2017 and December 31, 2016, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.0 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at March 31, 2017.

[0001564590-17-008397:mdna:100]
[same as prior period, unchanged from 0001564590-16-028206:mdna:102]

[0001564590-17-008397:mdna:101]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the three months ended March 31, 2017, we repurchased 0.3 million shares of our common stock at an average price of $21.44 per share. As of March 31, 2017, we have the authority to purchase an additional 4.2 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-17-008397:mdna:102]
[same as prior period, unchanged from 0001564590-16-028206:mdna:104]

[0001564590-17-008397:mdna:103]
We issued 0.1 million shares of treasury stock during the three months ended March 31, 2017 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $23.02. We received proceeds totaling $1.4 million from the exercise of these stock options during the three months ended March 31, 2017.

[0001564590-17-008397:mdna:104]
[same as prior period, unchanged from 0001564590-16-028206:mdna:106]

[0001564590-17-008397:mdna:105]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the three months ended March 31, 2017, there have been no material changes in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2016 filed on February 24, 2017 with the SEC.

[0001564590-17-008397:mdna:106]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2017, of which $7.7 million has been applied to these commitments.
