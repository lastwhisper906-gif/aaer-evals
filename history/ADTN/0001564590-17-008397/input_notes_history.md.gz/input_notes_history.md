# ADTN note change history — 0001564590-16-028206 → 0001564590-17-008397


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0001564590-17-008397:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2017, of which $7.7 million has been applied to these commitments.
  (was, 2016-11-08, similarity 0.9652):
[0001564590-16-028206:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2016, of which $7.7 million has been applied to these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0001564590-17-008397:note_history:2]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018, and we are currently evaluating the transition method that will be elected. We are continuing to evaluate the potential impact of these ASUs, and we believe the most significant potential impact relates to our accounting for software license and installation services revenues. We do not believe there will be a significant impact to product or maintenance revenues.
  (was, 2016-11-08, similarity 0.7673):
[0001564590-16-028206:note_history:2]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; and ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018, and we are currently evaluating the transition method that will be elected and the impact that the adoption of ASU 2014-09 will have on our financial position, results of operations and cash flows.

- changed (2017-05-03):
[0001564590-17-008397:note_history:3]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of ASU 2016-02 will have a material impact on our financial position; however, we do not believe adoption will have a material impact on our results of operations. We believe the most significant impact relates to our accounting for operating leases for office space and equipment.
  (was, 2016-11-08, similarity 0.7049):
[0001564590-16-028206:note_history:3]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years, with early adoption permitted. A modified retrospective approach is required. We are currently evaluating the impact that the adoption of ASU 2016-02 will have on our financial position, results of operations and cash flows.

- added (2017-05-03):
[0001564590-17-008397:note_history:4]
In January 2017, the FASB issued Accounting Standards Update No. 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04). ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material impact on our financial position, results of operations or cash flows.

- added (2017-05-03):
[0001564590-17-008397:note_history:5]
In March 2017, the FASB issued Accounting Standards Update No. 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost (ASU 2017-07). ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. ASU 2017-07 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted. We do not expect ASU 2017-07 will have a material impact on our financial position, results of operations or cash flows.

- changed (2017-05-03):
[0001564590-17-008397:note_history:6]
In July 2015, the FASB issued Accounting Standards Update No.  2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We adopted ASU 2015-05 in the first quarter of 2017, and there was no material impact on our financial position, results of operations or cash flows.
  (was, 2016-11-08, similarity 0.9643):
[0001564590-16-028206:note_history:6]
In July 2015, the FASB issued Accounting Standards Update No.  2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We do not believe the adoption of ASU 2015-05 will have a material impact on our financial position, results of operations and cash flows.

- added (2017-05-03):
[0001564590-17-008397:note_history:7]
In January 2017, we adopted ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. As a result, beginning in the first quarter of 2017, we began recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit as a discrete event. The treatment of forfeitures has changed as we have elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur. As a result, we recorded an increase in additional paid in capital of $0.1 million, a charge to beginning retained earnings of $0.1 million, and an increase in the deferred tax assets related to non-qualified stock options and RSUs of $10 thousand. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows within operating activities. We elected to retrospectively apply the changes in presentation to the statements of cash flows and no longer classify excess tax benefits as a financing activity, which had no effect on our cash flows for the three months ended March 31, 2016. There was no material impact on our financial position, results of operations or cash flows as a result of these changes.

- removed (2017-05-03):
[0001564590-16-028206:note_history:8]
In November 2015, the FASB issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17). ASU 2015-17 amends the existing guidance on income taxes to require the classification of all deferred tax assets and liabilities as non-current on the balance sheet. ASU 2015-17 is effective for fiscal years beginning after December 15, 2016, including interim periods within those years. Early adoption is permitted. The guidance may be applied either prospectively, for all deferred tax assets and liabilities, or retrospectively to all periods presented. We have not selected a transition method or determined whether to early adopt ASU 2015-17 in 2016. Other than the revised balance sheet presentation of current deferred tax assets and liabilities, we do not believe the adoption of ASU 2015-17 will have a material impact on our financial position, results of operations and cash flows.

- removed (2017-05-03):
[0001564590-16-028206:note_history:9]
In March 2016, the FASB issued Accounting Standards Update No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09). ASU 2016-09 simplifies several aspects of accounting for share-based compensation arrangements, including income tax effects, the classification of tax-related cash flows on the statement of cash flows, and accounting for forfeitures. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016, including interim periods within those years. Early adoption is permitted. We are currently evaluating the impact that the adoption of ASU 2016-09 will have on our financial position, results of operations and cash flows.

- removed (2017-05-03):
[0001564590-16-028206:note_history:10]
In April 2015, the FASB issued Accounting Standards Update No. 2015-05, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on accounting for fees paid by a customer in a cloud computing arrangement. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. ASU 2015-05 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period. The amendments may be applied either prospectively to all arrangements entered into or materially modified after the effective date or retrospectively. We adopted ASU 2015-05 during the first quarter of 2016 and will apply the new standard prospectively. The adoption of ASU 2015-05 did not have a material impact on our financial position, results of operations and cash flows.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0001564590-17-008397:note_history:11]
At March 31, 2017, we held the following securities and investments, recorded at either fair value or cost:
  (was, 2016-11-08, similarity 0.9463):
[0001564590-16-028206:note_history:11]
At December 31, 2015, we held the following securities and investments, recorded at either fair value or cost.

- changed (2017-05-03):
[0001564590-17-008397:note_history:12]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 15,084 |  |  | $ | 2,314 |  |  | $ | (26 | ) |  | $ | 17,372 |  |
| Corporate bonds |  |  | 72,324 |  |  |  | 99 |  |  |  | (150 | ) |  |  | 72,273 |  |
| Municipal fixed-rate bonds |  |  | 10,970 |  |  |  | 14 |  |  |  | (25 | ) |  |  | 10,959 |  |
| Asset-backed bonds |  |  | 11,832 |  |  |  | 10 |  |  |  | (14 | ) |  |  | 11,828 |  |
| Mortgage/Agency-backed bonds |  |  | 12,370 |  |  |  | 23 |  |  |  | (80 | ) |  |  | 12,313 |  |
| U.S. government bonds |  |  | 28,251 |  |  |  | 27 |  |  |  | (231 | ) |  |  | 28,047 |  |
| Foreign government bonds |  |  | 3,279 |  |  |  | — |  |  |  | — |  |  |  | 3,279 |  |
| Variable rate demand notes |  |  | 10,505 |  |  |  | — |  |  |  | — |  |  |  | 10,505 |  |
| Marketable equity securities |  |  | 30,934 |  |  |  | 1,669 |  |  |  | (842 | ) |  |  | 31,761 |  |
| Available-for-sale securities held at fair value |  | $ | 195,549 |  |  | $ | 4,156 |  |  | $ | (1,368 | ) |  | $ | 198,337 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 734 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 226,871 |  |
  (was, 2016-11-08, similarity 0.9323):
[0001564590-16-028206:note_history:12]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,325 |  |  | $ | 1,575 |  |  | $ | (66 | ) |  | $ | 12,834 |  |
| Corporate bonds |  |  | 58,328 |  |  |  | 20 |  |  |  | (734 | ) |  |  | 57,614 |  |
| Municipal fixed-rate bonds |  |  | 26,414 |  |  |  | 28 |  |  |  | (18 | ) |  |  | 26,424 |  |
| Asset-backed bonds |  |  | 19,281 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 19,239 |  |
| Mortgage/Agency-backed bonds |  |  | 15,463 |  |  |  | 1 |  |  |  | (91 | ) |  |  | 15,373 |  |
| U.S. Government bonds |  |  | 35,646 |  |  |  | - |  |  |  | (248 | ) |  |  | 35,398 |  |
| Marketable equity securities |  |  | 31,643 |  |  |  | 4,301 |  |  |  | (1,693 | ) |  |  | 34,251 |  |
| Available-for-sale securities held at fair value |  | $ | 198,100 |  |  | $ | 5,927 |  |  | $ | (2,894 | ) |  | $ | 201,133 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,289 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 232,422 |  |

- changed (2017-05-03):
[0001564590-17-008397:note_history:13]
At December 31, 2016, we held the following securities and investments, recorded at either fair value or cost:
  (was, 2016-11-08, similarity 0.9665):
[0001564590-16-028206:note_history:13]
At September 30, 2016, we held the following securities and investments, recorded at either fair value or cost.

- changed (2017-05-03):
[0001564590-17-008397:note_history:14]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 12,367 |  |  | $ | 2,271 |  |  | $ | (42 | ) |  | $ | 14,596 |  |
| Corporate bonds |  |  | 66,522 |  |  |  | 64 |  |  |  | (174 | ) |  |  | 66,412 |  |
| Municipal fixed-rate bonds |  |  | 11,799 |  |  |  | 12 |  |  |  | (37 | ) |  |  | 11,774 |  |
| Asset-backed bonds |  |  | 10,201 |  |  |  | 19 |  |  |  | (14 | ) |  |  | 10,206 |  |
| Mortgage/Agency-backed bonds |  |  | 13,080 |  |  |  | 15 |  |  |  | (91 | ) |  |  | 13,004 |  |
| U.S. government bonds |  |  | 30,022 |  |  |  | 15 |  |  |  | (270 | ) |  |  | 29,767 |  |
| Foreign government bonds |  |  | 3,729 |  |  |  | 2 |  |  |  | (1 | ) |  |  | 3,730 |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | — |  |  |  | 11,855 |  |
| Marketable equity securities |  |  | 30,571 |  |  |  | 311 |  |  |  | (1,503 | ) |  |  | 29,379 |  |
| Available-for-sale securities held at fair value |  | $ | 190,146 |  |  | $ | 2,709 |  |  | $ | (2,132 | ) |  | $ | 190,723 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 767 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 219,290 |  |
  (was, 2016-11-08, similarity 0.8906):
[0001564590-16-028206:note_history:14]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,656 |  |  | $ | 2,172 |  |  | $ | (20 | ) |  | $ | 13,808 |  |
| Corporate bonds |  |  | 59,900 |  |  |  | 136 |  |  |  | (50 | ) |  |  | 59,986 |  |
| Municipal fixed-rate bonds |  |  | 17,589 |  |  |  | 54 |  |  |  | (4 | ) |  |  | 17,639 |  |
| Asset-backed bonds |  |  | 22,564 |  |  |  | 72 |  |  |  | (23 | ) |  |  | 22,613 |  |
| Mortgage/Agency-backed bonds |  |  | 15,055 |  |  |  | 24 |  |  |  | (43 | ) |  |  | 15,036 |  |
| U.S. government bonds |  |  | 28,437 |  |  |  | 168 |  |  |  | - |  |  |  | 28,605 |  |
| Foreign government bonds |  |  | 6,428 |  |  |  | 3 |  |  |  | (1 | ) |  |  | 6,430 |  |
| Variable rate demand notes |  |  | 12,315 |  |  |  | - |  |  |  | - |  |  |  | 12,315 |  |
| Marketable equity securities |  |  | 26,975 |  |  |  | 1,468 |  |  |  | (1,076 | ) |  |  | 27,367 |  |
| Available-for-sale securities held at fair value |  | $ | 200,919 |  |  | $ | 4,097 |  |  | $ | (1,217 | ) |  | $ | 203,799 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 28,900 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,196 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 233,895 |  |

- changed (2017-05-03):
[0001564590-17-008397:note_history:15]
As of March 31, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, foreign government bonds and variable rate demand notes had the following contractual maturities:
  (was, 2016-11-08, similarity 0.8904):
[0001564590-16-028206:note_history:15]
As of September 30, 2016, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds had the following contractual maturities:

- changed (2017-05-03):
[0001564590-17-008397:note_history:16]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Variable rate demand notes |  |
| Less than one year |  | $ | 31,566 |  |  | $ | 8,237 |  |  | $ | — |  |  | $ | — |  |  | $ | 750 |  |  | $ | 1,400 |  |  | $ | — |  |
| One to two years |  |  | 20,265 |  |  |  | 1,540 |  |  |  | 1,017 |  |  |  | 976 |  |  |  | 6,365 |  |  |  | 1,329 |  |  |  | — |  |
| Two to three years |  |  | 19,036 |  |  |  | — |  |  |  | 2,078 |  |  |  | 726 |  |  |  | 8,569 |  |  |  | 550 |  |  |  | — |  |
| Three to five years |  |  | 1,406 |  |  |  | 1,182 |  |  |  | 7,416 |  |  |  | — |  |  |  | 12,363 |  |  |  | — |  |  |  | 1,790 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,173 |  |  |  | 1,896 |  |  |  | — |  |  |  | — |  |  |  | 2,000 |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 144 |  |  |  | 8,715 |  |  |  | — |  |  |  | — |  |  |  | 6,715 |  |
| Total |  | $ | 72,273 |  |  | $ | 10,959 |  |  | $ | 11,828 |  |  | $ | 12,313 |  |  | $ | 28,047 |  |  | $ | 3,279 |  |  | $ | 10,505 |  |
  (was, 2016-11-08, similarity 0.6972):
[0001564590-16-028206:note_history:16]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 22,993 |  |  | $ | 12,156 |  |  | $ | - |  |  | $ | - |  |  | $ | 2,952 |  |  | $ | 5,100 |  |
| One to two years |  |  | 24,504 |  |  |  | 3,186 |  |  |  | 1,094 |  |  |  | 1,385 |  |  |  | 9,096 |  |  |  | 1,330 |  |
| Two to three years |  |  | 9,296 |  |  |  | 858 |  |  |  | 8,989 |  |  |  | 2,004 |  |  |  | 4,573 |  |  |  | - |  |
| Three to five years |  |  | 3,193 |  |  |  | 1,439 |  |  |  | 9,739 |  |  |  | - |  |  |  | 11,984 |  |  |  | - |  |
| Five to ten years |  |  | - |  |  |  | - |  |  |  | 2,614 |  |  |  | 1,448 |  |  |  | - |  |  |  | - |  |
| More than ten years |  |  | - |  |  |  | - |  |  |  | 177 |  |  |  | 10,199 |  |  |  | - |  |  |  | - |  |
| Total |  | $ | 59,986 |  |  | $ | 17,639 |  |  | $ | 22,613 |  |  | $ | 15,036 |  |  | $ | 28,605 |  |  | $ | 6,430 |  |

- changed (2017-05-03):
[0001564590-17-008397:note_history:17]
At March 31, 2017, we held a $27.8 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $27.8 million at March 31, 2017 and December 31, 2016. At March 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $27.9 million, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.
  (was, 2016-11-08, similarity 0.9642):
[0001564590-16-028206:note_history:17]
At September 30, 2016, we held a $28.9 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $28.9 million at September 30, 2016 and December 31, 2015. At September 30, 2016, the estimated fair value of the Bond using a level 2 valuation technique was approximately $29.3 million, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

- changed (2017-05-03):
[0001564590-17-008397:note_history:18]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three months ended March 31, 2017 and 2016, other-than-temporary impairment charges were not significant.
  (was, 2016-11-08, similarity 0.9758):
[0001564590-16-028206:note_history:18]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and nine months ended September 30, 2016, other-than-temporary impairment charges were not significant.

- changed (2017-05-03):
[0001564590-17-008397:note_history:19]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Gross realized gains |  | $ | 719 |  |  | $ | 2,364 |  |
| Gross realized losses |  | $ | (249 | ) |  | $ | (636 | ) |
  (was, 2016-11-08, similarity 0.6434):
[0001564590-16-028206:note_history:19]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Gross realized gains |  | $ | 1,346 |  |  | $ | 2,251 |  |  | $ | 5,226 |  |  | $ | 8,856 |  |
| Gross realized losses |  | $ | (30 | ) |  | $ | (191 | ) |  | $ | (1,072 | ) |  | $ | (426 | ) |

- changed (2017-05-03):
[0001564590-17-008397:note_history:20]
As of March 31, 2017 and 2016, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.
  (was, 2016-11-08, similarity 0.9677):
[0001564590-16-028206:note_history:20]
As of September 30, 2016 and 2015, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.

- added (2017-05-03):
[0001564590-17-008397:note_history:21]
|  |  | Fair Value Measurements at March 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,915 |  |  | $ | 5,915 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 3,499 |  |  |  | — |  |  |  | 3,499 |  |  |  | — |  |
| Cash equivalents |  |  | 9,414 |  |  |  | 5,915 |  |  |  | 3,499 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 17,372 |  |  |  | 17,372 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 72,273 |  |  |  | — |  |  |  | 72,273 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 10,959 |  |  |  | — |  |  |  | 10,959 |  |  |  | — |  |
| Asset-backed bonds |  |  | 11,828 |  |  |  | — |  |  |  | 11,828 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 12,313 |  |  |  | — |  |  |  | 12,313 |  |  |  | — |  |
| U.S. government bonds |  |  | 28,047 |  |  |  | 28,047 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 3,279 |  |  |  | — |  |  |  | 3,279 |  |  |  | — |  |
| Variable rate demand notes |  |  | 10,505 |  |  |  | — |  |  |  | 10,505 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 31,761 |  |  |  | 31,761 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 198,337 |  |  |  | 77,180 |  |  |  | 121,157 |  |  |  | — |  |
| Total |  | $ | 207,751 |  |  | $ | 83,095 |  |  | $ | 124,656 |  |  | $ | — |  |

- changed (2017-05-03):
[0001564590-17-008397:note_history:22]
|  |  | Fair Value Measurements at December 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,878 |  |  | $ | 6,878 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 17,222 |  |  |  | — |  |  |  | 17,222 |  |  |  | — |  |
| Cash equivalents |  |  | 24,100 |  |  |  | 6,878 |  |  |  | 17,222 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 14,596 |  |  |  | 14,596 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 66,412 |  |  |  | — |  |  |  | 66,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 11,774 |  |  |  | — |  |  |  | 11,774 |  |  |  | — |  |
| Asset-backed bonds |  |  | 10,206 |  |  |  | — |  |  |  | 10,206 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 13,004 |  |  |  | — |  |  |  | 13,004 |  |  |  | — |  |
| U.S. government bonds |  |  | 29,767 |  |  |  | 29,767 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 3,730 |  |  |  | — |  |  |  | 3,730 |  |  |  | — |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | 11,855 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 29,379 |  |  |  | 29,379 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 190,723 |  |  |  | 73,742 |  |  |  | 116,981 |  |  |  | — |  |
| Total |  | $ | 214,823 |  |  | $ | 80,620 |  |  | $ | 134,203 |  |  | $ | — |  |
  (was, 2016-11-08, similarity 0.7873):
[0001564590-16-028206:note_history:22]
|  |  | Fair Value Measurements at September 30, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,032 |  |  | $ | 2,032 |  |  | $ | - |  |  | $ | - |  |
| Commercial Paper |  |  | 3,585 |  |  |  | - |  |  |  | 3,585 |  |  |  | - |  |
| Cash equivalents |  |  | 5,617 |  |  |  | 2,032 |  |  |  | 3,585 |  |  |  | - |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,808 |  |  |  | 13,808 |  |  |  | - |  |  |  | - |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 59,986 |  |  |  | - |  |  |  | 59,986 |  |  |  | - |  |
| Municipal fixed-rate bonds |  |  | 17,639 |  |  |  | - |  |  |  | 17,639 |  |  |  | - |  |
| Asset-backed bonds |  |  | 22,613 |  |  |  | - |  |  |  | 22,613 |  |  |  | - |  |
| Mortgage/Agency-backed bonds |  |  | 15,036 |  |  |  | - |  |  |  | 15,036 |  |  |  | - |  |
| U.S. government bonds |  |  | 28,605 |  |  |  | 28,605 |  |  |  | - |  |  |  | - |  |
| Foreign government bonds |  |  | 6,430 |  |  |  | - |  |  |  | 6,430 |  |  |  | - |  |
| Variable rate demand notes |  |  | 12,315 |  |  |  | - |  |  |  | 12,315 |  |  |  | - |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 3,693 |  |  |  | 3,693 |  |  |  | - |  |  |  | - |  |
| Marketable equity securities – other |  |  | 23,674 |  |  |  | 23,674 |  |  |  | - |  |  |  | - |  |
| Available-for-sale securities |  |  | 203,799 |  |  |  | 69,780 |  |  |  | 134,019 |  |  |  | - |  |
| Total |  | $ | 209,416 |  |  | $ | 71,812 |  |  | $ | 137,604 |  |  | $ | - |  |

- removed (2017-05-03):
[0001564590-16-028206:note_history:23]
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,271 |  |  | $ | 1,271 |  |  | $ | - |  |  | $ | - |  |
| Commercial Paper |  |  | 11,696 |  |  |  | - |  |  |  | 11,696 |  |  |  | - |  |
| Cash equivalents |  |  | 12,967 |  |  |  | 1,271 |  |  |  | 11,696 |  |  |  | - |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,834 |  |  |  | 12,834 |  |  |  | - |  |  |  | - |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 57,614 |  |  |  | - |  |  |  | 57,614 |  |  |  | - |  |
| Municipal fixed-rate bonds |  |  | 26,424 |  |  |  | - |  |  |  | 26,424 |  |  |  | - |  |
| Asset-backed bonds |  |  | 19,239 |  |  |  | - |  |  |  | 19,239 |  |  |  | - |  |
| Mortgage/Agency-backed bonds |  |  | 15,373 |  |  |  | - |  |  |  | 15,373 |  |  |  | - |  |
| U.S. government bonds |  |  | 35,398 |  |  |  | 35,398 |  |  |  | - |  |  |  | - |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,384 |  |  |  | 5,384 |  |  |  | - |  |  |  | - |  |
| Marketable equity securities – other |  |  | 28,867 |  |  |  | 28,867 |  |  |  | - |  |  |  | - |  |
| Available-for-sale securities |  |  | 201,133 |  |  |  | 82,483 |  |  |  | 118,650 |  |  |  | - |  |
| Total |  | $ | 214,100 |  |  | $ | 83,754 |  |  | $ | 130,346 |  |  | $ | - |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2017-05-03):
[0001564590-17-008397:note_history:24]
On April 18, 2017, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on May 4, 2017. The payment date will be May 18, 2017. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
  (was, 2016-11-08, similarity 0.9641):
[0001564590-16-028206:note_history:24]
On October 18, 2016, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on November 03, 2016. The payment date will be November 17, 2016. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

- changed (2017-05-03):
[0001564590-17-008397:note_history:25]
During the second quarter and as of May 3, 2017, we have repurchased 50 thousand shares of our common stock through open market purchases at an average cost of $19.91 per share. We currently have the authority to purchase an additional 4.1 million shares of our common stock under the current plan approved by the Board of Directors.
  (was, 2016-11-08, similarity 0.9412):
[0001564590-16-028206:note_history:25]
During the fourth quarter and as of November 8, 2016, we have repurchased 0.2 million shares of our common stock through open market purchases at an average cost of $17.96 per share. We currently have the authority to purchase an additional 4.4 million shares of our common stock under the current plan approved by the Board of Directors.
