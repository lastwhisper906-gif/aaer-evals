# ADTN notes — 0001564590-17-008397


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-17-008397:notes:1]
[same as prior period, unchanged from 0001564590-16-028206:notes:1]

[0001564590-17-008397:notes:2]
[same as prior period, unchanged from 0001564590-16-028206:notes:2]

[0001564590-17-008397:notes:3]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (ADTRAN) have been prepared pursuant to the rules and regulations for reporting on Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles for complete financial statements are not included herein. The December 31, 2016 Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.

[0001564590-17-008397:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim statements should be read in conjunction with the financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2016, filed on February 24, 2017 with the SEC.

[0001564590-17-008397:notes:5]
[same as prior period, unchanged from 0001564590-16-028206:notes:5]

[0001564590-17-008397:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-17-008397:notes:7]
[same as prior period, unchanged from 0001564590-16-028206:notes:7]

[0001564590-17-008397:notes:8]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018, and we are currently evaluating the transition method that will be elected. We are continuing to evaluate the potential impact of these ASUs, and we believe the most significant potential impact relates to our accounting for software license and installation services revenues. We do not believe there will be a significant impact to product or maintenance revenues.

[0001564590-17-008397:notes:9]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of ASU 2016-02 will have a material impact on our financial position; however, we do not believe adoption will have a material impact on our results of operations. We believe the most significant impact relates to our accounting for operating leases for office space and equipment.

[0001564590-17-008397:notes:10]
In January 2017, the FASB issued Accounting Standards Update No. 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04). ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material impact on our financial position, results of operations or cash flows.

[0001564590-17-008397:notes:11]
In March 2017, the FASB issued Accounting Standards Update No. 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost (ASU 2017-07). ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. ASU 2017-07 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted. We do not expect ASU 2017-07 will have a material impact on our financial position, results of operations or cash flows.

[0001564590-17-008397:notes:12]
During the first quarter of 2017, we adopted the following accounting standards, which had no material effect on our financial position, results of operations or cash flows:

[0001564590-17-008397:notes:13]
In July 2015, the FASB issued Accounting Standards Update No.  2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We adopted ASU 2015-05 in the first quarter of 2017, and there was no material impact on our financial position, results of operations or cash flows.

[0001564590-17-008397:notes:14]
In January 2017, we adopted ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. As a result, beginning in the first quarter of 2017, we began recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit as a discrete event. The treatment of forfeitures has changed as we have elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur. As a result, we recorded an increase in additional paid in capital of $0.1 million, a charge to beginning retained earnings of $0.1 million, and an increase in the deferred tax assets related to non-qualified stock options and RSUs of $10 thousand. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows within operating activities. We elected to retrospectively apply the changes in presentation to the statements of cash flows and no longer classify excess tax benefits as a financing activity, which had no effect on our cash flows for the three months ended March 31, 2016. There was no material impact on our financial position, results of operations or cash flows as a result of these changes.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-008397:notes:15]
[same as prior period, unchanged from 0001564590-16-028206:notes:15]

[0001564590-17-008397:notes:16]
[same as prior period, unchanged from 0001564590-16-028206:notes:16]

[0001564590-17-008397:notes:17]
We recorded a bargain purchase gain of $3.5 million during the third quarter of 2016, net of income taxes, subject to customary working capital adjustments between the parties. The bargain purchase gain of $3.5 million represents the excess fair value of the net assets acquired over the consideration exchanged. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and pro forma data for future periods and have concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-17-008397:notes:18]
The allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date, subject to working capital adjustments, is as follows:

[0001564590-17-008397:notes:19]
| (In Thousands) |  |  |  |
| Assets |  |  |  |
| Inventory | $ | 3,131 |  |
| Property, plant and equipment |  | 352 |  |
| Intangible assets |  | 4,700 |  |
| Total assets acquired |  | 8,183 |  |
| Liabilities |  |  |  |
| Accounts payable |  | (1,250 | ) |
| Warranty payable |  | (61 | ) |
| Accrued wages and benefits |  | (122 | ) |
| Deferred income taxes |  | (2,265 | ) |
| Total liabilities assumed |  | (3,698 | ) |
| Total net assets |  | 4,485 |  |
| Gain on bargain purchase of a business, net of tax |  | (3,542 | ) |
| Total purchase price | $ | 943 |  |

[0001564590-17-008397:notes:20]
[same as prior period, unchanged from 0001564590-16-028206:notes:20]

[0001564590-17-008397:notes:21]
| In thousands | Value |  |  | Life (years) |  |
| Supply agreement | $ | 1,400 |  |  |  | 0.8 |  |
| Customer relationships |  | 1,200 |  |  |  | 6.0 |  |
| Developed technology |  | 800 |  |  |  | 10.0 |  |
| License |  | 500 |  |  |  | 1.3 |  |
| Patent |  | 500 |  |  |  | 7.3 |  |
| Non-compete |  | 200 |  |  |  | 2.3 |  |
| Trade name |  | 100 |  |  |  | 2.0 |  |
| Total | $ | 4,700 |  |  |  |  |  |

[0001564590-17-008397:notes:22]
The following unaudited supplemental pro forma information presents the financial results as if the acquisition had occurred on January 1, 2015. This unaudited supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2015, nor is it indicative of any future results. Aside from revising the 2015 net income for the effect of the bargain purchase gain, there were no material, non-recurring adjustments to this unaudited pro forma information.

[0001564590-17-008397:notes:23]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Pro forma revenue |  | $ | 143,354 |  |  | $ | 143,980 |  |
| Pro forma net income |  | $ | 4,884 |  |  | $ | 6,418 |  |

[0001564590-17-008397:notes:24]
For the three months ended March 31, 2017, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $0.7 million related to this acquisition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-008397:notes:25]
[same as prior period, unchanged from 0001564590-16-028206:notes:27]

[0001564590-17-008397:notes:26]
Our effective tax rate decreased from 37.9% in the three months ended March 31, 2016 to 20.3% in the three months ended March 31, 2017. The decrease in the effective tax rate between the two periods is primarily attributable to an 11% effective rate reduction for a provision-to-return adjustment related to the assignment of research and development expenditures to specific company engineering locations, and the effective income tax rates among the respective jurisdictions.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-17-008397:notes:27]
[same as prior period, unchanged from 0001564590-16-028206:notes:29]

[0001564590-17-008397:notes:28]
[same as prior period, unchanged from 0001564590-16-028206:notes:30]

[0001564590-17-008397:notes:29]
The following table summarizes the components of net periodic pension cost for the three months ended March 31, 2017 and 2016:

[0001564590-17-008397:notes:30]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Service cost |  | $ | 297 |  |  | $ | 297 |  |
| Interest cost |  |  | 143 |  |  |  | 176 |  |
| Expected return on plan assets |  |  | (299 | ) |  |  | (259 | ) |
| Amortization of actuarial losses |  |  | 73 |  |  |  | 43 |  |
| Net periodic pension cost |  | $ | 214 |  |  | $ | 257 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-17-008397:notes:31]
[same as prior period, unchanged from 0001564590-16-028206:notes:33]

[0001564590-17-008397:notes:32]
The following table summarizes the stock-based compensation expense related to stock options, performance stock units (PSUs), restricted stock units (RSUs) and restricted stock for the three months ended March 31, 2017 and 2016, which was recognized as follows:

[0001564590-17-008397:notes:33]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 91 |  |  | $ | 99 |  |
| Selling, general and administrative expense |  |  | 1,016 |  |  |  | 769 |  |
| Research and development expense |  |  | 776 |  |  |  | 690 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,792 |  |  |  | 1,459 |  |
| Total stock-based compensation expense |  |  | 1,883 |  |  |  | 1,558 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (380 | ) |  |  | (212 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,503 |  |  | $ | 1,346 |  |

[0001564590-17-008397:notes:34]
Stock Options

[0001564590-17-008397:notes:35]
The following table is a summary of our stock options outstanding as of December 31, 2016 and March 31, 2017 and the changes that occurred during the three months ended March 31, 2017:

[0001564590-17-008397:notes:36]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2016 |  |  | 6,338 |  |  | $ | 22.14 |  |  |  | 5.63 |  |  | $ | 16,972 |  |
| Options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (82 | ) |  | $ | 16.84 |  |  |  |  |  |  |  |  |  |
| Options forfeited |  |  | (12 | ) |  | $ | 17.84 |  |  |  |  |  |  |  |  |  |
| Options expired |  |  | (16 | ) |  | $ | 26.18 |  |  |  |  |  |  |  |  |  |
| Options outstanding, March 31, 2017 |  |  | 6,228 |  |  | $ | 22.21 |  |  |  | 5.38 |  |  | $ | 11,692 |  |
| Options vested and expected to vest, March 31, 2017 |  |  | 6,228 |  |  | $ | 22.21 |  |  |  | 5.38 |  |  | $ | 11,692 |  |
| Options exercisable, March 31, 2017 |  |  | 4,660 |  |  | $ | 23.78 |  |  |  | 4.47 |  |  | $ | 6,111 |  |

[0001564590-17-008397:notes:37]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between the closing price of our stock on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on March 31, 2017. The aggregate intrinsic value will change based on the fair market value of our stock.

[0001564590-17-008397:notes:38]
The total pre-tax intrinsic value of options exercised during the three months ended March 31, 2017 was $0.4 million.

[0001564590-17-008397:notes:39]
As of March 31, 2017, there was $6.3 million of unrecognized compensation expense related to unvested stock options, which is expected to be recognized over an average remaining recognition period of 2.0 years.

[0001564590-17-008397:notes:40]
[same as prior period, unchanged from 0001564590-16-028206:notes:36]

[0001564590-17-008397:notes:41]
There were no options granted during the three months ended March 31, 2017 or 2016.

[0001564590-17-008397:notes:42]
PSUs, RSUs and restricted stock

[0001564590-17-008397:notes:43]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2016 and the changes that occurred during the three months ended March 31, 2017:

[0001564590-17-008397:notes:44]
| (In thousands, except per share amounts) |  | Number of Shares |  |  | Weighted Avg. Grant Date Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2016 |  |  | 519 |  |  | $ | 20.51 |  |
| PSUs, RSUs and restricted stock granted |  |  | 518 |  |  | $ | 22.25 |  |
| PSUs, RSUs and restricted stock vested |  |  | (2 | ) |  | $ | 18.29 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (2 | ) |  | $ | 20.00 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, March 31, 2017 |  |  | 1,033 |  |  | $ | 21.39 |  |

[0001564590-17-008397:notes:45]
The fair value of our PSUs with market conditions is calculated using a Monte Carlo Simulation valuation method. The fair value of RSUs and restricted stock is equal to the closing price of our stock on the date of grant. During the first quarter of 2017, the Compensation Committee of the Board of Directors approved a PSU grant of 0.5 million shares that contain performance conditions. The fair value of these performance-based PSU awards was equal to the closing price of our stock on the date of grant.

[0001564590-17-008397:notes:46]
As of March 31, 2017, there was $8.8 million of unrecognized compensation expense related to unvested market-based PSUs, RSUs and restricted stock, which is expected to be recognized over an average remaining recognition period of 3.2 years. In addition, there was $11.5 million of unrecognized compensation expense related to unvested performance-based PSUs, which will be recognized over the requisite service period of three years as achievement of the performance objective becomes probable. For the three months ended March 31, 2017, no compensation expense was recognized related to these performance-based PSU awards.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-17-008397:notes:47]
6. INVESTMENTS

[0001564590-17-008397:notes:48]
At March 31, 2017, we held the following securities and investments, recorded at either fair value or cost:

[0001564590-17-008397:notes:49]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 15,084 |  |  | $ | 2,314 |  |  | $ | (26 | ) |  | $ | 17,372 |  |
| Corporate bonds |  |  | 72,324 |  |  |  | 99 |  |  |  | (150 | ) |  |  | 72,273 |  |
| Municipal fixed-rate bonds |  |  | 10,970 |  |  |  | 14 |  |  |  | (25 | ) |  |  | 10,959 |  |
| Asset-backed bonds |  |  | 11,832 |  |  |  | 10 |  |  |  | (14 | ) |  |  | 11,828 |  |
| Mortgage/Agency-backed bonds |  |  | 12,370 |  |  |  | 23 |  |  |  | (80 | ) |  |  | 12,313 |  |
| U.S. government bonds |  |  | 28,251 |  |  |  | 27 |  |  |  | (231 | ) |  |  | 28,047 |  |
| Foreign government bonds |  |  | 3,279 |  |  |  | — |  |  |  | — |  |  |  | 3,279 |  |
| Variable rate demand notes |  |  | 10,505 |  |  |  | — |  |  |  | — |  |  |  | 10,505 |  |
| Marketable equity securities |  |  | 30,934 |  |  |  | 1,669 |  |  |  | (842 | ) |  |  | 31,761 |  |
| Available-for-sale securities held at fair value |  | $ | 195,549 |  |  | $ | 4,156 |  |  | $ | (1,368 | ) |  | $ | 198,337 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 734 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 226,871 |  |

[0001564590-17-008397:notes:50]
At December 31, 2016, we held the following securities and investments, recorded at either fair value or cost:

[0001564590-17-008397:notes:51]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 12,367 |  |  | $ | 2,271 |  |  | $ | (42 | ) |  | $ | 14,596 |  |
| Corporate bonds |  |  | 66,522 |  |  |  | 64 |  |  |  | (174 | ) |  |  | 66,412 |  |
| Municipal fixed-rate bonds |  |  | 11,799 |  |  |  | 12 |  |  |  | (37 | ) |  |  | 11,774 |  |
| Asset-backed bonds |  |  | 10,201 |  |  |  | 19 |  |  |  | (14 | ) |  |  | 10,206 |  |
| Mortgage/Agency-backed bonds |  |  | 13,080 |  |  |  | 15 |  |  |  | (91 | ) |  |  | 13,004 |  |
| U.S. government bonds |  |  | 30,022 |  |  |  | 15 |  |  |  | (270 | ) |  |  | 29,767 |  |
| Foreign government bonds |  |  | 3,729 |  |  |  | 2 |  |  |  | (1 | ) |  |  | 3,730 |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | — |  |  |  | 11,855 |  |
| Marketable equity securities |  |  | 30,571 |  |  |  | 311 |  |  |  | (1,503 | ) |  |  | 29,379 |  |
| Available-for-sale securities held at fair value |  | $ | 190,146 |  |  | $ | 2,709 |  |  | $ | (2,132 | ) |  | $ | 190,723 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 767 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 219,290 |  |

[0001564590-17-008397:notes:52]
As of March 31, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, foreign government bonds and variable rate demand notes had the following contractual maturities:

[0001564590-17-008397:notes:53]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Variable rate demand notes |  |
| Less than one year |  | $ | 31,566 |  |  | $ | 8,237 |  |  | $ | — |  |  | $ | — |  |  | $ | 750 |  |  | $ | 1,400 |  |  | $ | — |  |
| One to two years |  |  | 20,265 |  |  |  | 1,540 |  |  |  | 1,017 |  |  |  | 976 |  |  |  | 6,365 |  |  |  | 1,329 |  |  |  | — |  |
| Two to three years |  |  | 19,036 |  |  |  | — |  |  |  | 2,078 |  |  |  | 726 |  |  |  | 8,569 |  |  |  | 550 |  |  |  | — |  |
| Three to five years |  |  | 1,406 |  |  |  | 1,182 |  |  |  | 7,416 |  |  |  | — |  |  |  | 12,363 |  |  |  | — |  |  |  | 1,790 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,173 |  |  |  | 1,896 |  |  |  | — |  |  |  | — |  |  |  | 2,000 |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 144 |  |  |  | 8,715 |  |  |  | — |  |  |  | — |  |  |  | 6,715 |  |
| Total |  | $ | 72,273 |  |  | $ | 10,959 |  |  | $ | 11,828 |  |  | $ | 12,313 |  |  | $ | 28,047 |  |  | $ | 3,279 |  |  | $ | 10,505 |  |

[0001564590-17-008397:notes:54]
Actual maturities may differ from contractual maturities because some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-17-008397:notes:55]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-17-008397:notes:56]
At March 31, 2017, we held a $27.8 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $27.8 million at March 31, 2017 and December 31, 2016. At March 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $27.9 million, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

[0001564590-17-008397:notes:57]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three months ended March 31, 2017 and 2016, other-than-temporary impairment charges were not significant.

[0001564590-17-008397:notes:58]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments.

[0001564590-17-008397:notes:59]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Gross realized gains |  | $ | 719 |  |  | $ | 2,364 |  |
| Gross realized losses |  | $ | (249 | ) |  | $ | (636 | ) |

[0001564590-17-008397:notes:60]
As of March 31, 2017 and 2016, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.

[0001564590-17-008397:notes:61]
We have categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows:  Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-17-008397:notes:62]
|  |  | Fair Value Measurements at March 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,915 |  |  | $ | 5,915 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 3,499 |  |  |  | — |  |  |  | 3,499 |  |  |  | — |  |
| Cash equivalents |  |  | 9,414 |  |  |  | 5,915 |  |  |  | 3,499 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 17,372 |  |  |  | 17,372 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 72,273 |  |  |  | — |  |  |  | 72,273 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 10,959 |  |  |  | — |  |  |  | 10,959 |  |  |  | — |  |
| Asset-backed bonds |  |  | 11,828 |  |  |  | — |  |  |  | 11,828 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 12,313 |  |  |  | — |  |  |  | 12,313 |  |  |  | — |  |
| U.S. government bonds |  |  | 28,047 |  |  |  | 28,047 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 3,279 |  |  |  | — |  |  |  | 3,279 |  |  |  | — |  |
| Variable rate demand notes |  |  | 10,505 |  |  |  | — |  |  |  | 10,505 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 31,761 |  |  |  | 31,761 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 198,337 |  |  |  | 77,180 |  |  |  | 121,157 |  |  |  | — |  |
| Total |  | $ | 207,751 |  |  | $ | 83,095 |  |  | $ | 124,656 |  |  | $ | — |  |

[0001564590-17-008397:notes:63]
|  |  | Fair Value Measurements at December 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,878 |  |  | $ | 6,878 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 17,222 |  |  |  | — |  |  |  | 17,222 |  |  |  | — |  |
| Cash equivalents |  |  | 24,100 |  |  |  | 6,878 |  |  |  | 17,222 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 14,596 |  |  |  | 14,596 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 66,412 |  |  |  | — |  |  |  | 66,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 11,774 |  |  |  | — |  |  |  | 11,774 |  |  |  | — |  |
| Asset-backed bonds |  |  | 10,206 |  |  |  | — |  |  |  | 10,206 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 13,004 |  |  |  | — |  |  |  | 13,004 |  |  |  | — |  |
| U.S. government bonds |  |  | 29,767 |  |  |  | 29,767 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 3,730 |  |  |  | — |  |  |  | 3,730 |  |  |  | — |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | 11,855 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 29,379 |  |  |  | 29,379 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 190,723 |  |  |  | 73,742 |  |  |  | 116,981 |  |  |  | — |  |
| Total |  | $ | 214,823 |  |  | $ | 80,620 |  |  | $ | 134,203 |  |  | $ | — |  |

[0001564590-17-008397:notes:64]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-17-008397:notes:65]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-008397:notes:66]
[same as prior period, unchanged from 0001564590-16-028206:notes:66]

[0001564590-17-008397:notes:67]
We participate in foreign exchange forward contracts in connection with the management of exposure to fluctuations in foreign exchange rates.

[0001564590-17-008397:notes:68]
Cash Flow Hedges

[0001564590-17-008397:notes:69]
Our cash flow hedging activities utilize foreign exchange forward contracts to reduce the risk that movements in exchange rates will adversely affect the net cash flows resulting from the planned purchase of products from foreign suppliers. Purchases of U.S. denominated inventory by our European subsidiary represent our primary exposure. Changes in the fair value of derivatives designated as cash flow hedges are not recognized in current operating results, but are recorded in accumulated other comprehensive income.  Amounts related to cash flow hedges are reclassified from accumulated other comprehensive income when the underlying hedged item impacts earnings. This reclassification is recorded in the same line item of the consolidated statements of income as where the effects of the hedged item are recorded, which is cost of sales.

[0001564590-17-008397:notes:70]
Undesignated Hedges

[0001564590-17-008397:notes:71]
We have certain customers and suppliers who are invoiced or pay in a non-functional currency. Changes in the monetary exchange rates may adversely affect our results of operations and financial condition, as outstanding non-functional balances are revalued to the functional currency through profit and loss. When appropriate, we utilize foreign exchange forward contracts to help manage the volatility relating to these valuation exposures. All changes in the fair value of our derivative instruments that do not qualify for or are not designated for hedged accounting transactions are recognized as other income (expense) in the Consolidated Statements of Income.

[0001564590-17-008397:notes:72]
As of March 31, 2017, we had foreign exchange forward contracts outstanding with notional amounts totaling $15.0 million (€14.1 million), which hedge a portion of projected inventory purchases expected to be settled in the third and fourth quarters of 2017. We have determined that there was no hedge ineffectiveness for the quarter ended March 31, 2017 related to these contracts.

[0001564590-17-008397:notes:73]
We do not hold or issue derivative instruments for trading or other speculative purposes. Our derivative instruments are recorded in the Consolidated Balance Sheets at their fair values. Our derivative instruments are not subject to master netting arrangements and are not offset in the Consolidated Balance Sheets.

[0001564590-17-008397:notes:74]
The fair values of our derivative instruments recorded in the Consolidated Balance Sheet as of March 31, 2017 and December 31, 2016 were as follows:

[0001564590-17-008397:notes:75]
| (In thousands) |  | Balance Sheet Location |  | March 31, 2017 |  |  | December 31, 2016 |  |
| Derivatives Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 79 |  |  | $ | — |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  |  | 1 |  |  |  | 159 |  |
| Total derivatives |  |  |  | $ | 80 |  |  | $ | 159 |  |

[0001564590-17-008397:notes:76]
The change in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during three months ended March 31, 2017 and 2016 were as follows:

[0001564590-17-008397:notes:77]
|  |  |  |  | Three Months Ended |  |
|  |  | Income Statement |  | March 31, |  |
| (In thousands) |  | Location |  | 2017 |  |  | 2016 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  |  | (34 | ) |  |  | (47 | ) |

[0001564590-17-008397:notes:78]
The change in our derivatives designated as hedging instruments recorded in other comprehensive income (OCI) and reclassified to income during the three months ended March 31, 2017 and 2016 were as follows:

[0001564590-17-008397:notes:79]
|  |  | Amount of Gains (Losses) Recognized in |  |  |  |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  |  |  | from AOCI into Income |  |
|  |  | Three Months Ended |  |  | Location of Gains |  | Three Months Ended |  |
|  |  | March 31, |  |  | (Losses) Reclassified |  | March 31, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | from AOCI into Income |  | 2017 |  |  | 2016 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 79 |  |  | $ | — |  |  | Cost of Sales |  | $ | — |  |  | $ | — |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-17-008397:notes:80]
[same as prior period, unchanged from 0001564590-16-028206:notes:71]

[0001564590-17-008397:notes:81]
At March 31, 2017 and December 31, 2016, inventory consisted of the following:

[0001564590-17-008397:notes:82]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Raw materials |  | $ | 43,197 |  |  | $ | 40,461 |  |
| Work in process |  |  | 3,277 |  |  |  | 4,003 |  |
| Finished goods |  |  | 66,300 |  |  |  | 60,653 |  |
| Total |  | $ | 112,774 |  |  | $ | 105,117 |  |

[0001564590-17-008397:notes:83]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At  March 31, 2017 and December 31, 2016, raw materials reserves totaled $14.5 million and $14.6 million, respectively, and finished goods inventory reserves totaled $11.6 million and $10.6 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-17-008397:notes:84]
[same as prior period, unchanged from 0001564590-16-028206:notes:75]

[0001564590-17-008397:notes:85]
Goodwill, all of which relates to our acquisition of Bluesocket, Inc., was $3.5 million at March 31, 2017 and December 31, 2016, of which $3.1 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-17-008397:notes:86]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2016, we concluded that it was not necessary to perform the two-step impairment test. There have been no impairment losses recognized since the acquisition in 2011.

[0001564590-17-008397:notes:87]
[same as prior period, unchanged from 0001564590-16-028206:notes:78]

[0001564590-17-008397:notes:88]
The following table presents our intangible assets as of March 31, 2017 and December 31, 2016:

[0001564590-17-008397:notes:89]
| (In thousands) |  | March 31, 2017 |  |  | December 31, 2016 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,951 |  |  | $ | (3,423 | ) |  |  | 3,528 |  |  | $ | 6,899 |  |  | $ | (3,208 | ) |  | $ | 3,691 |  |
| Developed technology |  |  | 6,474 |  |  |  | (5,302 | ) |  |  | 1,172 |  |  |  | 6,444 |  |  |  | (5,061 | ) |  |  | 1,383 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (2,163 | ) |  |  | 177 |  |  |  | 2,340 |  |  |  | (2,129 | ) |  |  | 211 |  |
| Supply agreement |  |  | 1,400 |  |  |  | (1,011 | ) |  |  | 389 |  |  |  | 1,400 |  |  |  | (544 | ) |  |  | 856 |  |
| License |  |  | 500 |  |  |  | (210 | ) |  |  | 290 |  |  |  | 500 |  |  |  | (113 | ) |  |  | 387 |  |
| Patent |  |  | 500 |  |  |  | (37 | ) |  |  | 463 |  |  |  | 500 |  |  |  | (20 | ) |  |  | 480 |  |
| Trade names |  |  | 370 |  |  |  | (297 | ) |  |  | 73 |  |  |  | 370 |  |  |  | (285 | ) |  |  | 85 |  |
| Non-compete |  |  | 200 |  |  |  | (48 | ) |  |  | 152 |  |  |  | 200 |  |  |  | (26 | ) |  |  | 174 |  |
| Total |  | $ | 18,735 |  |  | $ | (12,491 | ) |  | $ | 6,244 |  |  | $ | 18,653 |  |  | $ | (11,386 | ) |  | $ | 7,267 |  |

[0001564590-17-008397:notes:90]
Amortization expense, all of which relates to business acquisitions, was $1.1 million and $0.4 million for the three months ended March 31, 2017 and 2016, respectively.

[0001564590-17-008397:notes:91]
As of March 31, 2017, the estimated future amortization expense of our intangible assets is as follows:

[0001564590-17-008397:notes:92]
| (In thousands) |  | Amount |  |
| Remainder of 2017 |  | $ | 1,820 |  |
| 2018 |  |  | 1,172 |  |
| 2019 |  |  | 659 |  |
| 2020 |  |  | 624 |  |
| 2021 |  |  | 571 |  |
| Thereafter |  |  | 1,398 |  |
| Total |  | $ | 6,244 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-17-008397:notes:93]
[same as prior period, unchanged from 0001564590-16-028206:notes:84]

[0001564590-17-008397:notes:94]
A summary of the changes in stockholders’ equity for the three months ended March 31, 2017 is as follows:

[0001564590-17-008397:notes:95]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2016 |  | $ | 479,517 |  |
| Net income |  |  | 6,651 |  |
| Dividend payments |  |  | (4,369 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (8 | ) |
| Net unrealized gains on available-for-sale securities (net of tax) |  |  | 1,335 |  |
| Net unrealized gains on cash flow hedges |  |  | 79 |  |
| Defined benefit plan adjustments (net of tax) |  |  | 55 |  |
| Foreign currency translation adjustment |  |  | 1,242 |  |
| Proceeds from stock option exercises |  |  | 1,377 |  |
| Purchase of treasury stock |  |  | (5,559 | ) |
| ASU 2016-09 adoption |  |  | 10 |  |
| Stock-based compensation expense |  |  | 1,883 |  |
| Balance, March 31, 2017 |  | $ | 482,213 |  |

[0001564590-17-008397:notes:96]
[same as prior period, unchanged from 0001564590-16-028206:notes:87]

[0001564590-17-008397:notes:97]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the three months ended March 31, 2017, we repurchased 0.3 million shares of our common stock at an average price of $21.44 per share. As of March 31, 2017, we have the authority to purchase an additional 4.2 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-17-008397:notes:98]
[same as prior period, unchanged from 0001564590-16-028206:notes:89]

[0001564590-17-008397:notes:99]
We issued 0.1 million shares of treasury stock during the three months ended March 31, 2017 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $23.02. We received proceeds totaling $1.4 million from the exercise of these stock options during the three months ended March 31, 2017.

[0001564590-17-008397:notes:100]
[same as prior period, unchanged from 0001564590-16-028206:notes:91]

[0001564590-17-008397:notes:101]
During the three months ended March 31, 2017, we paid cash dividends as follows (in thousands except per share amounts):

[0001564590-17-008397:notes:102]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 2, 2017 |  | February 16, 2017 |  | $ | 0.09 |  |  | $ | 4,369 |  |

[0001564590-17-008397:notes:103]
[same as prior period, unchanged from 0001564590-16-028206:notes:94]

[0001564590-17-008397:notes:104]
Other comprehensive income consists of unrealized gains (losses) on available-for-sale securities, unrealized gains (losses) on cash flow hedges, reclassification adjustments for amounts included in net income related to impairments of available-for-sale securities, realized gains (losses) on available-for-sale securities, and amortization of actuarial gains (losses) related to our defined benefit plan, defined benefit plan adjustments, and foreign currency translation adjustments.

[0001564590-17-008397:notes:105]
The following tables present changes in accumulated other comprehensive income, net of tax, by component for the three months ended March 31, 2017 and 2016:

[0001564590-17-008397:notes:106]
|  |  | Three Months Ended March 31, 2017 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 404 |  |  | $ | — |  |  | $ | (5,017 | ) |  | $ | (7,575 | ) |  | $ | (12,188 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,620 |  |  |  | 79 |  |  |  | — |  |  |  | 1,242 |  |  |  | 2,941 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (285 | ) |  |  | — |  |  |  | 55 |  |  |  | — |  |  |  | (230 | ) |
| Net current period other comprehensive income (loss) |  |  | 1,335 |  |  |  | 79 |  |  |  | 55 |  |  |  | 1,242 |  |  |  | 2,711 |  |
| Ending balance |  | $ | 1,739 |  |  | $ | 79 |  |  | $ | (4,962 | ) |  | $ | (6,333 | ) |  | $ | (9,477 | ) |

[0001564590-17-008397:notes:107]
|  |  | Three Months Ended March 31, 2016 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,932 |  |  | $ | (3,895 | ) |  | $ | (7,006 | ) |  | $ | (8,969 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 758 |  |  |  | — |  |  |  | 1,228 |  |  |  | 1,986 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,013 | ) |  |  | 45 |  |  |  | — |  |  |  | (968 | ) |
| Net current period other comprehensive income (loss) |  |  | (255 | ) |  |  | 45 |  |  |  | 1,228 |  |  |  | 1,018 |  |
| Ending balance |  | $ | 1,677 |  |  | $ | (3,850 | ) |  | $ | (5,778 | ) |  | $ | (7,951 | ) |

[0001564590-17-008397:notes:108]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the three months ended March 31, 2017 and 2016

[0001564590-17-008397:notes:109]
| (In thousands) |  | Three Months Ended March 31, 2017 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 572 |  |  | Net realized investment gain |
| Impairment expense |  |  | (103 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (80 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 389 |  |  |  |
| Tax (expense) benefit |  |  | (159 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 230 |  |  |  |

[0001564590-17-008397:notes:110]
[same as prior period, unchanged from 0001564590-16-028206:notes:104]

[0001564590-17-008397:notes:111]
| (In thousands) |  | Three Months Ended March 31, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,761 |  |  | Net realized investment gain |
| Impairment expense |  |  | (100 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (65 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,596 |  |  |  |
| Tax (expense) benefit |  |  | (628 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 968 |  |  |  |

[0001564590-17-008397:notes:112]
The following table presents the tax effects related to the change in each component of other comprehensive income for the three months ended March 31, 2017 and 2016:

[0001564590-17-008397:notes:113]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 2,656 |  |  | $ | (1,036 | ) |  | $ | 1,620 |  |  | $ | 1,244 |  |  | $ | (486 | ) |  | $ | 758 |  |
| Unrealized gains (losses) on cash flow hedges |  |  | 79 |  |  |  | — |  |  |  | 79 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (469 | ) |  |  | 184 |  |  |  | (285 | ) |  |  | (1,661 | ) |  |  | 648 |  |  |  | (1,013 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 80 |  |  |  | (25 | ) |  |  | 55 |  |  |  | 65 |  |  |  | (20 | ) |  |  | 45 |  |
| Foreign currency translation adjustment |  |  | 1,242 |  |  |  | — |  |  |  | 1,242 |  |  |  | 1,228 |  |  |  | — |  |  |  | 1,228 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 3,588 |  |  | $ | (877 | ) |  | $ | 2,711 |  |  | $ | 876 |  |  | $ | 142 |  |  | $ | 1,018 |  |


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-008397:notes:114]
[same as prior period, unchanged from 0001564590-16-028206:notes:113]

[0001564590-17-008397:notes:115]
A summary of the calculation of basic and diluted earnings per share for the three months ended March 31, 2017 and 2016 is as follows:

[0001564590-17-008397:notes:116]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2017 |  |  | 2016 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 6,651 |  |  | $ | 5,014 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,430 |  |  |  | 49,220 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| Stock options |  |  | 416 |  |  |  | 120 |  |
| PSUs, RSUs and restricted stock |  |  | 93 |  |  |  | 49 |  |
| Weighted average number of shares – diluted |  |  | 48,939 |  |  |  | 49,389 |  |
| Net income per share – basic |  | $ | 0.14 |  |  | $ | 0.10 |  |
| Net income per share – diluted |  | $ | 0.14 |  |  | $ | 0.10 |  |

[0001564590-17-008397:notes:117]
Anti-dilutive options to purchase common stock outstanding were excluded from the above calculations. Anti-dilutive options totaled 4.0 million and 5.9 million for the three months ended March 31, 2017 and 2016, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-008397:notes:118]
[same as prior period, unchanged from 0001564590-16-028206:notes:117]

[0001564590-17-008397:notes:119]
We operate in two reportable segments: (1) Network Solutions and (2) Services & Support. Network Solutions includes hardware products and next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes our suite of ProCloud® managed services, network installation, engineering and maintenance services, and fee-based technical support and equipment repair/replacement plans.

[0001564590-17-008397:notes:120]
We evaluate the performance of our segments based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net realized investment gain/loss, other income/expense and provision for taxes are reported on a company-wide, functional basis only. There are no inter-segment revenues.

[0001564590-17-008397:notes:121]
The following table presents information about the reported sales and gross profit of our reportable segments for the three months ended March 31, 2017 and 2016 . We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-17-008397:notes:122]
|  |  | Three Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 143,597 |  |  | $ | 66,938 |  |  | $ | 123,883 |  |  | $ | 59,810 |  |
| Services & Support |  |  | 26,682 |  |  |  | 6,777 |  |  |  | 18,321 |  |  |  | 5,984 |  |
| Total |  | $ | 170,279 |  |  | $ | 73,715 |  |  | $ | 142,204 |  |  | $ | 65,794 |  |

[0001564590-17-008397:notes:123]
[same as prior period, unchanged from 0001564590-16-028206:notes:123]

[0001564590-17-008397:notes:124]
In addition to our reporting segments, we also report revenue for the following three categories – Access & Aggregation, Customer Devices, and Traditional & Other Products.

[0001564590-17-008397:notes:125]
The table below presents sales information by category for the three months ended March 31, 2017 and 2016:

[0001564590-17-008397:notes:126]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Access & Aggregation |  | $ | 120,143 |  |  | $ | 93,855 |  |
| Customer Devices |  |  | 36,268 |  |  |  | 32,353 |  |
| Traditional & Other Products |  |  | 13,868 |  |  |  | 15,996 |  |
| Total |  | $ | 170,279 |  |  | $ | 142,204 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-17-008397:notes:127]
[same as prior period, unchanged from 0001564590-16-028206:notes:159]

[0001564590-17-008397:notes:128]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $9.0 million and $8.5 million at March 31, 2017 and December 31, 2016, respectively. During the three months ended March 31, 2017, we recorded a receivable and a reduction in warranty expense related to a settlement with a third party supplier for a defective component. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0001564590-17-008397:notes:129]
A summary of warranty expense and write-off activity for the three months ended March 31, 2017 and 2016 is as follows:

[0001564590-17-008397:notes:130]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 8,548 |  |  | $ | 8,739 |  |
| Plus: Amounts charged to cost and expenses |  |  | (741 | ) |  |  | 898 |  |
| Less: Deductions |  |  | 1,181 |  |  |  | (595 | ) |
| Balance at end of period |  | $ | 8,988 |  |  | $ | 9,042 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-008397:notes:131]
14. COMMITMENTS AND CONTINGENCIES

[0001564590-17-008397:notes:132]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-17-008397:notes:133]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2017, of which $7.7 million has been applied to these commitments.


## us-gaap:SubsequentEventsTextBlock

[0001564590-17-008397:notes:134]
15. SUBSEQUENT EVENTS

[0001564590-17-008397:notes:135]
On April 18, 2017, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on May 4, 2017. The payment date will be May 18, 2017. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-17-008397:notes:136]
During the second quarter and as of May 3, 2017, we have repurchased 50 thousand shares of our common stock through open market purchases at an average cost of $19.91 per share. We currently have the authority to purchase an additional 4.1 million shares of our common stock under the current plan approved by the Board of Directors.
