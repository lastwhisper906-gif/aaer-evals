# ADTN 8-K — 0001193125-17-127926 filed 2017-04-19

## item codes, every 8-K on or before 2017-05-03

- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2017-05-03

- none on or before 2017-05-03

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-127926:8k_2_02:1]
EX-99.1
2
d377117dex991.htm
EX-99.1

[0001193125-17-127926:8k_2_02:2]
EX-99.1

[0001193125-17-127926:8k_2_02:3]
EXHIBIT 99.1

[0001193125-17-127926:8k_2_02:4]
ADTRAN, Inc. Reports Record Results for the First Quarter 2017

[0001193125-17-127926:8k_2_02:5]
and Declares Quarterly Cash Dividend

[0001193125-17-127926:8k_2_02:6]
HUNTSVILLE,
Ala.—(BUSINESS WIRE)—Apr. 18, 2017— ADTRAN, Inc. (NASDAQ:ADTN) reported results for the first quarter 2017. For the quarter, sales were $170.3 million compared to $142.2 million for the first quarter of 2016. Net income was $6.7
million compared to $5 million for the first quarter of 2016. Earnings per share, assuming dilution, were $0.14 compared to $0.10 for the first quarter of 2016. Non-GAAP earnings per share were $0.18 compared to $0.14 for the first quarter of 2016.
The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-17-127926:8k_2_02:7]
ADTRAN Chairman and
Chief Executive Officer Tom Stanton stated, “We started 2017 setting a company record for first quarter revenue, driven by increasing momentum in our ultra-broadband product sales and continuing strength in our services area. Most notably, we
had very strong performances in our fiber to the premises and vectoring products in both our domestic and international markets. ADTRAN continues to be at the forefront of enabling internet service providers of all types to meet increasing customer
demand and decrease their time to market for next generation services.”

[0001193125-17-127926:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash
dividend for the first quarter of 2017. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on May 4, 2017. The ex-dividend date is May 2, 2017, and the payment date is
May 18, 2017.

[0001193125-17-127926:8k_2_02:9]
The Company confirmed that its first quarter conference call will be held Wednesday, April 19, 2017, at 9:30 a.m. Central Time.
This conference call will be web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the call and click
on the conference call link provided.

[0001193125-17-127926:8k_2_02:10]
An online replay of the conference call will be available for seven days at www.streetevents.com. In addition, an
online replay of the conference call, as well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following the call.

[0001193125-17-127926:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet
communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please
visit www.adtran.com.

[0001193125-17-127926:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web,
visit www.adtran.com.

[0001193125-17-127926:8k_2_02:13]
This press release contains forward-looking statements which reflect management’s best judgment based on factors
currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component
costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2016. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking
statements included in this press release.

[0001193125-17-127926:8k_2_02:14]
Condensed Consolidated Balance Sheet

[0001193125-17-127926:8k_2_02:15]
(Unaudited)

[0001193125-17-127926:8k_2_02:16]
(In
thousands)

[0001193125-17-127926:8k_2_02:17]
|  |  | March 31,2017 |  |  | December 31,2016 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 72,558 |  |  | $ | 79,895 |  |
| Short-term investments |  |  | 52,458 |  |  |  | 43,188 |  |
| Accounts receivable, net |  |  | 85,396 |  |  |  | 92,346 |  |
| Other receivables |  |  | 13,398 |  |  |  | 15,137 |  |
| Income tax receivable, net |  |  | — |  |  |  | 760 |  |
| Inventory |  |  | 112,774 |  |  |  | 105,117 |  |
| Prepaid expenses and other current assets |  |  | 17,816 |  |  |  | 16,459 |  |
| Total Current Assets |  |  | 354,400 |  |  |  | 352,902 |  |
| Property, plant and equipment, net |  |  | 83,514 |  |  |  | 84,469 |  |
| Deferred tax assets, net |  |  | 39,085 |  |  |  | 38,036 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 12,274 |  |  |  | 12,234 |  |
| Long-term investments |  |  | 174,413 |  |  |  | 176,102 |  |
| Total Assets |  | $ | 667,178 |  |  | $ | 667,235 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 74,300 |  |  | $ | 77,342 |  |
| Unearned revenue |  |  | 16,969 |  |  |  | 16,326 |  |
| Accrued expenses |  |  | 15,035 |  |  |  | 12,434 |  |
| Accrued wages and benefits |  |  | 12,199 |  |  |  | 20,433 |  |
| Income tax payable, net |  |  | 3,126 |  |  |  | — |  |
| Total Current Liabilities |  |  | 121,629 |  |  |  | 126,535 |  |
| Non-current unearned revenue |  |  | 5,675 |  |  |  | 6,333 |  |
| Other non-current liabilities |  |  | 30,861 |  |  |  | 28,050 |  |
| Bonds payable |  |  | 26,800 |  |  |  | 26,800 |  |
| Total Liabilities |  |  | 184,965 |  |  |  | 187,718 |  |
| Stockholders’ Equity |  |  | 482,213 |  |  |  | 479,517 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 667,178 |  |  | $ | 667,235 |  |

[0001193125-17-127926:8k_2_02:18]
Consolidated Statements of Income

[0001193125-17-127926:8k_2_02:19]
(Unaudited)

[0001193125-17-127926:8k_2_02:20]
(In
thousands, except per share data)

[0001193125-17-127926:8k_2_02:21]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Sales |  |  |  |  |  |  |  |  |
| Products |  | $ | 143,597 |  |  | $ | 123,883 |  |
| Services |  |  | 26,682 |  |  |  | 18,321 |  |
| Total Sales |  |  | 170,279 |  |  |  | 142,204 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |
| Products |  |  | 76,659 |  |  |  | 64,073 |  |
| Services |  |  | 19,905 |  |  |  | 12,337 |  |
| Total Cost of Sales |  |  | 96,564 |  |  |  | 76,410 |  |
| Gross Profit |  |  | 73,715 |  |  |  | 65,794 |  |
| Selling, general and administrative expenses |  |  | 34,767 |  |  |  | 30,785 |  |
| Research and development expenses |  |  | 31,916 |  |  |  | 29,488 |  |
| Operating Income |  |  | 7,032 |  |  |  | 5,521 |  |
| Interest and dividend income |  |  | 933 |  |  |  | 855 |  |
| Interest expense |  |  | (141 | ) |  |  | (145 | ) |
| Net realized investment gain |  |  | 470 |  |  |  | 1,728 |  |
| Other income, net |  |  | 51 |  |  |  | 119 |  |
| Income before provision for income taxes |  |  | 8,345 |  |  |  | 8,078 |  |
| Provision for income taxes |  |  | (1,694 | ) |  |  | (3,064 | ) |
| Net Income |  | $ | 6,651 |  |  | $ | 5,014 |  |
| Weighted average shares outstanding - basic |  |  | 48,430 |  |  |  | 49,220 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 48,939 |  |  |  | 49,389 |  |
| Earnings per common share - basic |  | $ | 0.14 |  |  | $ | 0.10 |  |
| Earnings per common share - diluted (1) |  | $ | 0.14 |  |  | $ | 0.10 |  |

[0001193125-17-127926:8k_2_02:22]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001193125-17-127926:8k_2_02:23]
Consolidated Statements of Comprehensive Income

[0001193125-17-127926:8k_2_02:24]
(Unaudited)

[0001193125-17-127926:8k_2_02:25]
(In
thousands)

[0001193125-17-127926:8k_2_02:26]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Net Income |  | $ | 6,651 |  |  | $ | 5,014 |  |
| Other Comprehensive Income, net of tax: |  |  |  |  |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | 1,335 |  |  |  | (255 | ) |
| Unrealized gains on cash flow hedges |  |  | 79 |  |  |  | — |  |
| Defined benefit plan adjustments |  |  | 55 |  |  |  | 45 |  |
| Foreign currency translation |  |  | 1,242 |  |  |  | 1,228 |  |
| Other Comprehensive Income, net of tax |  |  | 2,711 |  |  |  | 1,018 |  |
| Comprehensive Income, net of tax |  | $ | 9,362 |  |  | $ | 6,032 |  |

[0001193125-17-127926:8k_2_02:27]
Consolidated Statements of Cash Flows

[0001193125-17-127926:8k_2_02:28]
(Unaudited)

[0001193125-17-127926:8k_2_02:29]
(In
thousands)

[0001193125-17-127926:8k_2_02:30]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 6,651 |  |  | $ | 5,014 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 4,323 |  |  |  | 3,347 |  |
| Amortization of net premium on available-for-sale investments |  |  | 124 |  |  |  | 220 |  |
| Net realized gain on long-term investments |  |  | (470 | ) |  |  | (1,728 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | (16 | ) |  |  | 3 |  |
| Stock-based compensation expense |  |  | 1,883 |  |  |  | 1,558 |  |
| Deferred income taxes |  |  | (1,947 | ) |  |  | 435 |  |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 7,247 |  |  |  | 4,752 |  |
| Other receivables |  |  | 1,884 |  |  |  | 10,200 |  |
| Inventory |  |  | (7,399 | ) |  |  | 163 |  |
| Prepaid expenses and other assets |  |  | (2,413 | ) |  |  | (3,083 | ) |
| Accounts payable |  |  | (1,713 | ) |  |  | (6,520 | ) |
| Accrued expenses and other liabilities |  |  | (3,166 | ) |  |  | 902 |  |
| Income tax payable/receivable, net |  |  | 4,049 |  |  |  | 413 |  |
| Net cash provided by operating activities |  |  | 9,037 |  |  |  | 15,676 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (3,872 | ) |  |  | (3,166 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 16 |  |  |  | — |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 24,471 |  |  |  | 60,586 |  |
| Purchases of available-for-sale investments |  |  | (29,517 | ) |  |  | (52,053 | ) |
| Net cash provided by (used in) investing activities |  |  | (8,902 | ) |  |  | 5,367 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 1,377 |  |  |  | 247 |  |
| Purchases of treasury stock |  |  | (5,559 | ) |  |  | (11,003 | ) |
| Dividend payments |  |  | (4,369 | ) |  |  | (4,453 | ) |
| Net cash used in financing activities |  |  | (8,551 | ) |  |  | (15,209 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (8,416 | ) |  |  | 5,834 |  |
| Effect of exchange rate changes |  |  | 1,079 |  |  |  | 1,225 |  |
| Cash and cash equivalents, beginning of period |  |  | 79,895 |  |  |  | 84,550 |  |
| Cash and cash equivalents, end of period |  | $ | 72,558 |  |  | $ | 91,609 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 509 |  |  | $ | 485 |  |

[0001193125-17-127926:8k_2_02:31]
Supplemental Information

[0001193125-17-127926:8k_2_02:32]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-17-127926:8k_2_02:33]
(Unaudited)

[0001193125-17-127926:8k_2_02:34]
(In
thousands)

[0001193125-17-127926:8k_2_02:35]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc., on May 4, 2012, we closed on the acquisition of the Nokia
Siemens Networks Broadband Access business (NSN BBA), and on September 13, 2016, we closed on the acquisition of CommScope’s active fiber business (CommScope). Acquisition related expenses, amortizations and adjustments for the three
months ended March 31, 2017 and 2016 for all three transactions are as follows:

[0001193125-17-127926:8k_2_02:36]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 158 |  |  | $ | 173 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 208 |  |  |  | 227 |  |
| Amortization of other purchase accounting adjustments |  |  | 28 |  |  |  | 36 |  |
| Subtotal NSN BBA acquisition |  |  | 236 |  |  |  | 263 |  |
| CommScope acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 686 |  |  |  | — |  |
| Amortization of other purchase accounting adjustments |  |  | 50 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | 8 |  |  |  | — |  |
| Subtotal CommScope acquisition |  |  | 744 |  |  |  | — |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 1,138 |  |  |  | 436 |  |
| Provision for income taxes |  |  | (425 | ) |  |  | (149 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 713 |  |  | $ | 287 |  |

[0001193125-17-127926:8k_2_02:37]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three months ended March 31, 2017 and 2016:

[0001193125-17-127926:8k_2_02:38]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Cost of goods sold |  | $ | 50 |  |  | $ | 7 |  |
| Selling, general and administrative expenses |  |  | 62 |  |  |  | 3 |  |
| Research and development expenses |  |  | 1,026 |  |  |  | 426 |  |
| Total acquisition related expenses, amortizations and adjustments included in operating expenses |  |  | 1,088 |  |  |  | 429 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 1,138 |  |  |  | 436 |  |
| Provision for income taxes |  |  | (425 | ) |  |  | (149 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 713 |  |  | $ | 287 |  |

[0001193125-17-127926:8k_2_02:39]
Supplemental Information

[0001193125-17-127926:8k_2_02:40]
Stock-based Compensation Expense

[0001193125-17-127926:8k_2_02:41]
(Unaudited)

[0001193125-17-127926:8k_2_02:42]
(In
thousands)

[0001193125-17-127926:8k_2_02:43]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 91 |  |  | $ | 99 |  |
| Selling, general and administrative expense |  |  | 1,016 |  |  |  | 769 |  |
| Research and development expense |  |  | 776 |  |  |  | 690 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,792 |  |  |  | 1,459 |  |
| Total stock-based compensation expense |  |  | 1,883 |  |  |  | 1,558 |  |
| Tax benefit for expense associated with non-qualified options, restricted stock units and restricted stock |  |  | (380 | ) |  |  | (212 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,503 |  |  | $ | 1,346 |  |

[0001193125-17-127926:8k_2_02:44]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-17-127926:8k_2_02:45]
Non-GAAP net income per share, diluted

[0001193125-17-127926:8k_2_02:46]
(Unaudited)

[0001193125-17-127926:8k_2_02:47]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| GAAP earnings per common share – diluted |  | $ | 0.14 |  |  | $ | 0.10 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.18 |  |  | $ | 0.14 |  |
