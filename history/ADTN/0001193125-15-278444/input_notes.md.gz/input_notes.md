# ADTN notes — 0001193125-15-278444


## us-gaap:DividendsDeclaredTableTextBlock

[0001193125-15-278444:notes:1]
During the six months ended June 30, 2015, we paid cash
 dividends as follows (in thousands except per share amounts):

[0001193125-15-278444:notes:2]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 5, 2015 |  | February 19, 2015 |  | $ | 0.09 |  |  | $ | 4,811 |  |
| May 7, 2015 |  | May 21, 2015 |  | $ | 0.09 |  |  | $ | 4,698 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-15-278444:notes:3]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1—Values based on unadjusted quoted prices for
 identical assets or liabilities in an active market; Level
 2—Values based on quoted prices in markets that are not
 active or model inputs that are observable either directly or
 indirectly; Level 3—Values based on prices or valuation
 techniques that require inputs that are both unobservable and
 significant to the overall fair value measurement. These inputs
 include information supplied by investees.

[0001193125-15-278444:notes:4]
|  |  | Fair Value Measurements at June 30, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,087 |  |  | $ | 1,087 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 16,534 |  |  |  | 16,534 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 114,430 |  |  |  | — |  |  |  | 114,430 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 67,387 |  |  |  | — |  |  |  | 67,387 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 3,695 |  |  |  | — |  |  |  | 3,695 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 7,786 |  |  |  | 7,786 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 29,514 |  |  |  | 29,514 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 239,346 |  |  |  | 53,834 |  |  |  | 185,512 |  |  |  | — |  |
| Total |  | $ | 240,433 |  |  | $ | 54,921 |  |  | $ | 185,512 |  |  | $ | — |  |

[0001193125-15-278444:notes:5]
[same as prior period, unchanged from 0001193125-15-173975:notes:12]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-15-278444:notes:6]
[same as prior period, unchanged from 0001193125-15-173975:notes:150]

[0001193125-15-278444:notes:7]
[same as prior period, unchanged from 0001193125-15-173975:notes:151]

[0001193125-15-278444:notes:8]
The following table summarizes the components of net periodic
 pension cost for the three and six months ended June 30, 2015
 and 2014:

[0001193125-15-278444:notes:9]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Service cost |  | $ | 324 |  |  | $ | 306 |  |  | $ | 664 |  |  | $ | 611 |  |
| Interest cost |  |  | 152 |  |  |  | 216 |  |  |  | 311 |  |  |  | 431 |  |
| Expected return on plan assets |  |  | (250 | ) |  |  | (280 | ) |  |  | (511 | ) |  |  | (559 | ) |
| Amortization of actuarial losses |  |  | 100 |  |  |  | — |  |  |  | 205 |  |  |  | — |  |
| Net periodic pension cost |  | $ | 326 |  |  | $ | 242 |  |  | $ | 669 |  |  | $ | 483 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-15-278444:notes:10]
A summary of the changes in stockholders’ equity for the six
 months ended June 30, 2015 is as follows:

[0001193125-15-278444:notes:11]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2014 |  | $ | 549,013 |  |
| Net income |  |  | 5,861 |  |
| Dividend payments |  |  | (9,509 | ) |
| Dividends accrued for unvested restricted stock units |  |  | 10 |  |
| Net unrealized losses on available-for-sale securities (net of tax) |  |  | (2,286 | ) |
| Defined benefit plan adjustments |  |  | 140 |  |
| Foreign currency translation adjustment |  |  | (2,446 | ) |
| Proceeds from stock option exercises |  |  | 833 |  |
| Purchase of treasury stock |  |  | (49,307 | ) |
| Income tax benefit from exercise of stock options |  |  | (23 | ) |
| Stock-based compensation expense |  |  | 3,114 |  |
| Balance, June 30, 2015 |  | $ | 495,400 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-15-278444:notes:12]
[same as prior period, unchanged from 0001193125-15-173975:notes:126]

[0001193125-15-278444:notes:13]
Our products generally include warranties of 90 days to ten years
 for product defects. We accrue for warranty returns at the time
 revenue is recognized based on our estimate of the cost to repair
 or replace the defective products. We engage in extensive product
 quality programs and processes, including actively monitoring and
 evaluating the quality of our component suppliers. Our products
 continue to become more complex in both size and functionality as
 many of our product offerings migrate from line card applications
 to systems products. The increasing complexity of our products will
 cause warranty incidences, when they arise, to be more costly. Our
 estimates regarding future warranty obligations may change due to
 product failure rates, material usage, and other rework costs
 incurred in correcting a product failure. In addition, from time to
 time, specific warranty accruals may be recorded if unforeseen
 problems arise. Should our actual experience relative to these
 factors be worse than our estimates, we will be required to record
 additional warranty expense. Alternatively, if we provide for more
 reserves than we require, we will reverse a portion of such
 provisions in future periods. The liability for warranty
 obligations totaled $8.9 million at June 30, 2015 and $8.4
 million at December 31, 2014. These liabilities are included
 in accrued expenses in the accompanying Consolidated Balance
 Sheets.

[0001193125-15-278444:notes:14]
A summary of warranty expense and write-off activity for the six
 months ended June 30, 2015 and 2014 is as follows:

[0001193125-15-278444:notes:15]
|  |  | Six Months Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| (In thousands) |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 8,415 |  |  | $ | 8,977 |  |
| Plus: Amounts charged to cost and expenses |  |  | 1,128 |  |  |  | 1,339 |  |
| Less: Deductions |  |  | (610 | ) |  |  | (1,999 | ) |
| Balance at end of period |  | $ | 8,933 |  |  | $ | 8,317 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-15-278444:notes:16]
5. INVESTMENTS

[0001193125-15-278444:notes:17]
At June 30, 2015, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-15-278444:notes:18]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 14,046 |  |  | $ | 2,601 |  |  | $ | (113 | ) |  | $ | 16,534 |  |
| Corporate bonds |  |  | 114,446 |  |  |  | 123 |  |  |  | (139 | ) |  |  | 114,430 |  |
| Municipal fixed-rate bonds |  |  | 67,302 |  |  |  | 130 |  |  |  | (45 | ) |  |  | 67,387 |  |
| Municipal variable rate demand notes |  |  | 3,695 |  |  |  | — |  |  |  | — |  |  |  | 3,695 |  |
| Marketable equity securities |  |  | 28,901 |  |  |  | 9,265 |  |  |  | (866 | ) |  |  | 37,300 |  |
| Available-for-sale securities held at fair value |  | $ | 228,390 |  |  | $ | 12,119 |  |  | $ | (1,163 | ) |  | $ | 239,346 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,446 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 270,792 |  |

[0001193125-15-278444:notes:19]
At December 31, 2014, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-15-278444:notes:20]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 13,897 |  |  | $ | 2,409 |  |  | $ | (12 | ) |  | $ | 16,294 |  |
| Corporate bonds |  |  | 111,261 |  |  |  | 186 |  |  |  | (186 | ) |  |  | 111,261 |  |
| Municipal fixed-rate bonds |  |  | 127,341 |  |  |  | 480 |  |  |  | (34 | ) |  |  | 127,787 |  |
| Municipal variable rate demand notes |  |  | 2,465 |  |  |  | — |  |  |  | — |  |  |  | 2,465 |  |
| Marketable equity securities |  |  | 26,399 |  |  |  | 12,395 |  |  |  | (539 | ) |  |  | 38,255 |  |
| Available-for-sale securities held at fair value |  | $ | 281,363 |  |  | $ | 15,470 |  |  | $ | (771 | ) |  | $ | 296,062 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,506 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 327,568 |  |

[0001193125-15-278444:notes:21]
As of June 30, 2015, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

[0001193125-15-278444:notes:22]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 32,179 |  |  | $ | 18,254 |  |
| One to two years |  |  | 42,510 |  |  |  | 35,462 |  |
| Two to three years |  |  | 39,741 |  |  |  | 12,460 |  |
| Three to five years |  |  | — |  |  |  | 1,211 |  |
| Total |  | $ | 114,430 |  |  | $ | 67,387 |  |

[0001193125-15-278444:notes:23]
Actual maturities may differ from contractual maturities because
 some borrowers have the right to call or prepay obligations with or
 without call or prepayment penalties.

[0001193125-15-278444:notes:24]
Our investment policy provides limitations for issuer
 concentration, which limits, at the time of purchase, the
 concentration in any one issuer to 5% of the market value of our
 total investment portfolio.

[0001193125-15-278444:notes:25]
At June 30, 2015, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 June 30, 2015, the estimated fair value of the Bond using a
 level 2 valuation technique was approximately $29.9 million, based
 on a debt security with a comparable interest rate and maturity and
 a Standard and Poor’s credit rating of AAA. For more
 information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

[0001193125-15-278444:notes:26]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and six months
 ended June 30, 2015 and 2014, other-than-temporary impairment
 charges were not significant.

[0001193125-15-278444:notes:27]
Realized gains and losses on sales of securities are computed under
 the specific identification method. The following table presents
 gross realized gains and losses related to our investments.

[0001193125-15-278444:notes:28]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Gross realized gains |  | $ | 3,459 |  |  | $ | 2,407 |  |  | $ | 6,604 |  |  | $ | 4,635 |  |
| Gross realized losses |  | $ | (204 | ) |  | $ | (67 | ) |  | $ | (234 | ) |  | $ | (103 | ) |

[0001193125-15-278444:notes:29]
As of June 30, 2015 and 2014, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.

[0001193125-15-278444:notes:30]
The fair value of our Level 2 securities is calculated using a
 weighted average market price for each security. Market prices are
 obtained from a variety of industry standard data providers,
 security master files from large financial institutions, and other
 third-party sources. These multiple market prices are used as
 inputs into a distribution-curve-based algorithm to determine the
 daily market value of each security.

[0001193125-15-278444:notes:31]
Our municipal variable rate demand notes have a structure that
 implies a standard expected market price. The frequent interest
 rate resets make it reasonable to expect the price to stay at par.
 These securities are priced at the expected market price.


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-15-278444:notes:32]
The fair values of our derivative instruments recorded in the
 Consolidated Balance Sheet as of June 30, 2015 and
 December 31, 2014 were as follows:

[0001193125-15-278444:notes:33]
| (In thousands) |  | Balance Sheet Location |  | June 30, 2015 |  |  | December 31, 2014 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 447 |  |  | $ | 249 |  |
| Foreign exchange contracts – liability derivatives |  | Accounts payable |  | $ | (832 | ) |  | $ | (10 | ) |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-15-278444:notes:34]
As of June 30, 2015, the estimated future amortization expense
 of our intangible assets is as follows:

[0001193125-15-278444:notes:35]
| (In thousands) |  | Amount |  |
| Remainder of 2015 |  | $ | 928 |  |
| 2016 |  |  | 1,679 |  |
| 2017 |  |  | 1,164 |  |
| 2018 |  |  | 703 |  |
| 2019 |  |  | 309 |  |
| Thereafter |  |  | 1,314 |  |
| Total |  | $ | 6,097 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-15-278444:notes:36]
[same as prior period, unchanged from 0001193125-15-173975:notes:13]

[0001193125-15-278444:notes:37]
Goodwill, all of which relates to our acquisition of Bluesocket,
 Inc. and is included in our Enterprise Networks division, was $3.5
 million at June 30, 2015 and December 31, 2014. We
 evaluate the carrying value of goodwill during the fourth quarter
 of each year and between annual evaluations if events occur or
 circumstances change that would more likely than not reduce the
 fair value of the reporting unit below its carrying amount. We have
 elected to first assess the qualitative factors to determine
 whether it is more likely than not that the fair value of the
 reporting unit to which the goodwill is assigned is less than its
 carrying amount as a basis for determining whether it is necessary
 to perform the two-step impairment test. If we determine that it is
 more likely than not that its fair value is less than its carrying
 amount, then the two-step impairment test will be performed. There
 have been no impairment losses recorded since acquisition.

[0001193125-15-278444:notes:38]
[same as prior period, unchanged from 0001193125-15-173975:notes:15]

[0001193125-15-278444:notes:39]
The following table presents our intangible assets as of
 June 30, 2015 and December 31, 2014:

[0001193125-15-278444:notes:40]
| (In thousands) |  | June 30, 2015 |  |  | December 31, 2014 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 5,937 |  |  | $ | (2,350 | ) |  | $ | 3,587 |  |  | $ | 6,310 |  |  | $ | (2,136 | ) |  | $ | 4,174 |  |
| Developed technology |  |  | 5,784 |  |  |  | (3,962 | ) |  |  | 1,822 |  |  |  | 6,005 |  |  |  | (3,577 | ) |  |  | 2,428 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,687 | ) |  |  | 653 |  |  |  | 2,340 |  |  |  | (1,520 | ) |  |  | 820 |  |
| Trade names |  |  | 270 |  |  |  | (235 | ) |  |  | 35 |  |  |  | 270 |  |  |  | (205 | ) |  |  | 65 |  |
| Other |  |  | 11 |  |  |  | (11 | ) |  |  | — |  |  |  | 12 |  |  |  | (11 | ) |  |  | 1 |  |
| Total |  | $ | 14,342 |  |  | $ | (8,245 | ) |  | $ | 6,097 |  |  | $ | 14,937 |  |  | $ | (7,449 | ) |  | $ | 7,488 |  |

[0001193125-15-278444:notes:41]
Amortization expense, all of which relates to business
 acquisitions, was $0.5 million and $0.6 million for the three
 months ended June 30, 2015 and 2014, respectively, and $1.0
 million and $1.2 million for the six months ended June 30,
 2015 and 2014, respectively.


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0001193125-15-278444:notes:42]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the three
 months ended June 30, 2015 and 2014:

[0001193125-15-278444:notes:43]
|  |  | Three Months Ended June 30, 2015 |  |  | Three Months Ended June 30, 2014 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 290 |  |  | $ | (113 | ) |  | $ | 177 |  |  | $ | 4,125 |  |  | $ | (1,609 | ) |  | $ | 2,516 |  |
| Reclassification adjustment for amounts included in net income |  |  | (3,108 | ) |  |  | 1,220 |  |  |  | (1,888 | ) |  |  | (2,126 | ) |  |  | 829 |  |  |  | (1,297 | ) |
| Foreign currency translation adjustment |  |  | 872 |  |  |  | — |  |  |  | 872 |  |  |  | 134 |  |  |  | — |  |  |  | 134 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (1,946 | ) |  | $ | 1,107 |  |  | $ | (839 | ) |  | $ | 2,133 |  |  | $ | (780 | ) |  | $ | 1,353 |  |

[0001193125-15-278444:notes:44]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the six months
 ended June 30, 2015 and 2014:

[0001193125-15-278444:notes:45]
|  |  | Six Months Ended June 30, 2015 |  |  | Six Months Ended June 30, 2014 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 2,520 |  |  | $ | (983 | ) |  | $ | 1,537 |  |  | $ | 4,784 |  |  | $ | (1,866 | ) |  | $ | 2,918 |  |
| Reclassification adjustment for amounts included in net income |  |  | (6,064 | ) |  |  | 2,381 |  |  |  | (3,683 | ) |  |  | (4,296 | ) |  |  | 1,676 |  |  |  | (2,620 | ) |
| Foreign currency translation adjustment |  |  | (2,446 | ) |  |  | — |  |  |  | (2,446 | ) |  |  | 386 |  |  |  | — |  |  |  | 386 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (5,990 | ) |  | $ | 1,398 |  |  | $ | (4,592 | ) |  | $ | 874 |  |  | $ | (190 | ) |  | $ | 684 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsGainLossInStatementOfFinancialPerformanceTextBlock

[0001193125-15-278444:notes:46]
The change in the fair values of our derivative instruments
 recorded in the Consolidated Statements of Income during the three
 and six months ended June 30, 2015 and 2014 were as
 follows:

[0001193125-15-278444:notes:47]
|  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Income Statement Location |  | June 30, |  |  | June 30, |  |
| (In thousands) |  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | (1,299 | ) |  | $ | (438 | ) |  | $ | 177 |  |  | $ | (548 | ) |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-278444:notes:48]
[same as prior period, unchanged from 0001193125-15-173975:notes:33]

[0001193125-15-278444:notes:49]
[same as prior period, unchanged from 0001193125-15-173975:notes:34]

[0001193125-15-278444:notes:50]
The following tables present information about the reported sales
 and gross profit of our reportable segments for the three and six
 months ended June 30, 2015 and 2014. Asset information by
 reportable segment is not reported, since we do not produce such
 information internally.

[0001193125-15-278444:notes:51]
|  |  | Three Months Ended |  |
|  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 135,397 |  |  | $ | 54,699 |  |  | $ | 143,455 |  |  | $ | 68,053 |  |
| Enterprise Networks |  |  | 24,741 |  |  |  | 13,547 |  |  |  | 32,674 |  |  |  | 18,744 |  |
| Total |  | $ | 160,138 |  |  | $ | 68,246 |  |  | $ | 176,129 |  |  | $ | 86,797 |  |

[0001193125-15-278444:notes:52]
|  |  | Six Months Ended |  |
|  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 251,411 |  |  | $ | 104,558 |  |  | $ | 261,617 |  |  | $ | 129,406 |  |
| Enterprise Networks |  |  | 51,562 |  |  |  | 29,251 |  |  |  | 61,516 |  |  |  | 35,181 |  |
| Total |  | $ | 302,973 |  |  | $ | 133,809 |  |  | $ | 323,133 |  |  | $ | 164,587 |  |

[0001193125-15-278444:notes:53]
[same as prior period, unchanged from 0001193125-15-173975:notes:37]

[0001193125-15-278444:notes:54]
[same as prior period, unchanged from 0001193125-15-173975:notes:38]

[0001193125-15-278444:notes:55]
[same as prior period, unchanged from 0001193125-15-173975:notes:39]

[0001193125-15-278444:notes:56]
[same as prior period, unchanged from 0001193125-15-173975:notes:40]

[0001193125-15-278444:notes:57]
[same as prior period, unchanged from 0001193125-15-173975:notes:41]

[0001193125-15-278444:notes:58]
[same as prior period, unchanged from 0001193125-15-173975:notes:42]

[0001193125-15-278444:notes:59]
[same as prior period, unchanged from 0001193125-15-173975:notes:43]

[0001193125-15-278444:notes:60]
[same as prior period, unchanged from 0001193125-15-173975:notes:44]

[0001193125-15-278444:notes:61]
[same as prior period, unchanged from 0001193125-15-173975:notes:45]

[0001193125-15-278444:notes:62]
[same as prior period, unchanged from 0001193125-15-173975:notes:46]

[0001193125-15-278444:notes:63]
[same as prior period, unchanged from 0001193125-15-173975:notes:47]

[0001193125-15-278444:notes:64]
[same as prior period, unchanged from 0001193125-15-173975:notes:48]

[0001193125-15-278444:notes:65]
[same as prior period, unchanged from 0001193125-15-173975:notes:49]

[0001193125-15-278444:notes:66]
[same as prior period, unchanged from 0001193125-15-173975:notes:50]

[0001193125-15-278444:notes:67]
[same as prior period, unchanged from 0001193125-15-173975:notes:51]

[0001193125-15-278444:notes:68]
[same as prior period, unchanged from 0001193125-15-173975:notes:52]

[0001193125-15-278444:notes:69]
[same as prior period, unchanged from 0001193125-15-173975:notes:53]

[0001193125-15-278444:notes:70]
[same as prior period, unchanged from 0001193125-15-173975:notes:54]

[0001193125-15-278444:notes:71]
[same as prior period, unchanged from 0001193125-15-173975:notes:55]

[0001193125-15-278444:notes:72]
[same as prior period, unchanged from 0001193125-15-173975:notes:56]

[0001193125-15-278444:notes:73]
[same as prior period, unchanged from 0001193125-15-173975:notes:57]

[0001193125-15-278444:notes:74]
[same as prior period, unchanged from 0001193125-15-173975:notes:58]

[0001193125-15-278444:notes:75]
[same as prior period, unchanged from 0001193125-15-173975:notes:59]

[0001193125-15-278444:notes:76]
[same as prior period, unchanged from 0001193125-15-173975:notes:60]

[0001193125-15-278444:notes:77]
[same as prior period, unchanged from 0001193125-15-173975:notes:61]

[0001193125-15-278444:notes:78]
[same as prior period, unchanged from 0001193125-15-173975:notes:62]

[0001193125-15-278444:notes:79]
[same as prior period, unchanged from 0001193125-15-173975:notes:63]

[0001193125-15-278444:notes:80]
[same as prior period, unchanged from 0001193125-15-173975:notes:64]

[0001193125-15-278444:notes:81]
[same as prior period, unchanged from 0001193125-15-173975:notes:65]

[0001193125-15-278444:notes:82]
[same as prior period, unchanged from 0001193125-15-173975:notes:66]

[0001193125-15-278444:notes:83]
[same as prior period, unchanged from 0001193125-15-173975:notes:67]

[0001193125-15-278444:notes:84]
[same as prior period, unchanged from 0001193125-15-173975:notes:68]

[0001193125-15-278444:notes:85]
[same as prior period, unchanged from 0001193125-15-173975:notes:69]

[0001193125-15-278444:notes:86]
[same as prior period, unchanged from 0001193125-15-173975:notes:70]

[0001193125-15-278444:notes:87]
[same as prior period, unchanged from 0001193125-15-173975:notes:71]

[0001193125-15-278444:notes:88]
[same as prior period, unchanged from 0001193125-15-173975:notes:72]

[0001193125-15-278444:notes:89]
[same as prior period, unchanged from 0001193125-15-173975:notes:73]

[0001193125-15-278444:notes:90]
The table below presents sales information by product category for
 the three and six months ended June 30, 2015 and 2014:

[0001193125-15-278444:notes:91]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Carrier Systems |  | $ | 119,039 |  |  | $ | 128,824 |  |  | $ | 219,478 |  |  | $ | 228,377 |  |
| Business Networking |  |  | 34,210 |  |  |  | 41,969 |  |  |  | 69,591 |  |  |  | 79,888 |  |
| Loop Access |  |  | 6,889 |  |  |  | 5,336 |  |  |  | 13,904 |  |  |  | 14,868 |  |
| Total |  | $ | 160,138 |  |  | $ | 176,129 |  |  | $ | 302,973 |  |  | $ | 323,133 |  |

[0001193125-15-278444:notes:92]
[same as prior period, unchanged from 0001193125-15-173975:notes:76]

[0001193125-15-278444:notes:93]
The table below presents subcategory revenues for the three and six
 months ended June 30, 2015 and 2014:

[0001193125-15-278444:notes:94]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 100,746 |  |  | $ | 108,309 |  |  | $ | 185,540 |  |  | $ | 189,836 |  |
| Optical (included in Carrier Systems) |  |  | 16,432 |  |  |  | 15,833 |  |  |  | 28,936 |  |  |  | 28,622 |  |
| Internetworking (included in Business Networking) |  |  | 33,158 |  |  |  | 40,986 |  |  |  | 67,317 |  |  |  | 77,932 |  |
| Subtotal |  |  | 150,336 |  |  |  | 165,128 |  |  |  | 281,793 |  |  |  | 296,390 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 6,399 |  |  |  | 4,798 |  |  |  | 13,102 |  |  |  | 13,675 |  |
| Other products (excluding HDSL) |  |  | 3,403 |  |  |  | 6,203 |  |  |  | 8,078 |  |  |  | 13,068 |  |
| Subtotal |  |  | 9,802 |  |  |  | 11,001 |  |  |  | 21,180 |  |  |  | 26,743 |  |
| Total |  | $ | 160,138 |  |  | $ | 176,129 |  |  | $ | 302,973 |  |  | $ | 323,133 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-278444:notes:95]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the three months
 ended June 30, 2015 and 2014:

[0001193125-15-278444:notes:96]
|  |  | Three Months Ended June 30, 2015 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 8,461 |  |  | $ | (5,689 | ) |  | $ | (6,600 | ) |  | $ | (3,828 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 177 |  |  |  | — |  |  |  | 872 |  |  |  | 1,049 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,960 | ) |  |  | 72 |  |  |  | — |  |  |  | (1,888 | ) |
| Net current period other comprehensive income (loss) |  |  | (1,783 | ) |  |  | 72 |  |  |  | 872 |  |  |  | (839 | ) |
| Ending balance |  | $ | 6,678 |  |  | $ | (5,617 | ) |  | $ | (5,728 | ) |  | $ | (4,667 | ) |

[0001193125-15-278444:notes:97]
|  |  | Three Months Ended June 30, 2014 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 9,816 |  |  | $ | (891 | ) |  | $ | 1,159 |  |  | $ | 10,084 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 2,516 |  |  |  | — |  |  |  | 134 |  |  |  | 2,650 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,297 | ) |  |  | — |  |  |  | — |  |  |  | (1,297 | ) |
| Net current period other comprehensive income (loss) |  |  | 1,219 |  |  |  | — |  |  |  | 134 |  |  |  | 1,353 |  |
| Ending balance |  | $ | 11,035 |  |  | $ | (891 | ) |  | $ | 1,293 |  |  | $ | 11,437 |  |

[0001193125-15-278444:notes:98]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the six months
 ended June 30, 2015 and 2014:

[0001193125-15-278444:notes:99]
|  |  | Six Months Ended June 30, 2015 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 8,964 |  |  | $ | (5,757 | ) |  | $ | (3,282 | ) |  | $ | (75 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,537 |  |  |  | — |  |  |  | (2,446 | ) |  |  | (909 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (3,823 | ) |  |  | 140 |  |  |  | — |  |  |  | (3,683 | ) |
| Net current period other comprehensive income (loss) |  |  | (2,286 | ) |  |  | 140 |  |  |  | (2,446 | ) |  |  | (4,592 | ) |
| Ending balance |  | $ | 6,678 |  |  | $ | (5,617 | ) |  | $ | (5,728 | ) |  | $ | (4,667 | ) |

[0001193125-15-278444:notes:100]
|  |  | Six Months Ended June 30, 2014 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,737 |  |  | $ | (891 | ) |  | $ | 907 |  |  | $ | 10,753 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 2,918 |  |  |  | — |  |  |  | 386 |  |  |  | 3,304 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,620 | ) |  |  | — |  |  |  | — |  |  |  | (2,620 | ) |
| Net current period other comprehensive income (loss) |  |  | 298 |  |  |  | — |  |  |  | 386 |  |  |  | 684 |  |
| Ending balance |  | $ | 11,035 |  |  | $ | (891 | ) |  | $ | 1,293 |  |  | $ | 11,437 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-15-278444:notes:101]
[same as prior period, unchanged from 0001193125-15-173975:notes:121]

[0001193125-15-278444:notes:102]
[same as prior period, unchanged from 0001193125-15-173975:notes:122]

[0001193125-15-278444:notes:103]
[same as prior period, unchanged from 0001193125-15-173975:notes:123]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-15-278444:notes:104]
A summary of the calculation of basic and diluted earnings per
 share for the three and six months ended June 30, 2015 and
 2014 is as follows:

[0001193125-15-278444:notes:105]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands, except per share amounts) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 2,544 |  |  | $ | 14,395 |  |  | $ | 5,861 |  |  | $ | 24,002 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 51,822 |  |  |  | 55,409 |  |  |  | 52,607 |  |  |  | 56,077 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 72 |  |  |  | 288 |  |  |  | 122 |  |  |  | 459 |  |
| Restricted stock and restricted stock units |  |  | 23 |  |  |  | 32 |  |  |  | 13 |  |  |  | 23 |  |
| Weighted average number of shares – diluted |  |  | 51,917 |  |  |  | 55,729 |  |  |  | 52,742 |  |  |  | 56,559 |  |
| Net income per share – basic |  | $ | 0.05 |  |  | $ | 0.26 |  |  | $ | 0.11 |  |  | $ | 0.43 |  |
| Net income per share – diluted |  | $ | 0.05 |  |  | $ | 0.26 |  |  | $ | 0.11 |  |  | $ | 0.42 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-15-278444:notes:106]
The following table summarizes the stock-based compensation expense
 related to stock options, restricted stock units (RSUs) and
 restricted stock for the three and six months ended June 30,
 2015 and 2014, which was recognized as follows:

[0001193125-15-278444:notes:107]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 53 |  |  | $ | 119 |  |  | $ | 143 |  |  | $ | 235 |  |
| Selling, general and administrative expense |  |  | 723 |  |  |  | 1,015 |  |  |  | 1,414 |  |  |  | 2,041 |  |
| Research and development expense |  |  | 699 |  |  |  | 958 |  |  |  | 1,557 |  |  |  | 1,873 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,422 |  |  |  | 1,973 |  |  |  | 2,971 |  |  |  | 3,914 |  |
| Total stock-based compensation expense |  |  | 1,475 |  |  |  | 2,092 |  |  |  | 3,114 |  |  |  | 4,149 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (222 | ) |  |  | (296 | ) |  |  | (402 | ) |  |  | (580 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,253 |  |  | $ | 1,796 |  |  | $ | 2,712 |  |  | $ | 3,569 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-15-278444:notes:108]
At June 30, 2015 and December 31, 2014, inventory
 consisted of the following:

[0001193125-15-278444:notes:109]
| (In thousands) |  | June 30, 2015 |  |  | December 31, 2014 |  |
| Raw materials |  | $ | 38,819 |  |  | $ | 34,831 |  |
| Work in process |  |  | 3,489 |  |  |  | 3,750 |  |
| Finished goods |  |  | 57,740 |  |  |  | 48,129 |  |
| Total |  | $ | 100,048 |  |  | $ | 86,710 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-15-278444:notes:110]
[same as prior period, unchanged from 0001193125-15-173975:notes:79]

[0001193125-15-278444:notes:111]
We establish reserves for estimated excess, obsolete, or
 unmarketable inventory equal to the difference between the cost of
 the inventory and the estimated fair value of the inventory based
 upon assumptions about future demand and market conditions. At
 June 30, 2015 and December 31, 2014, raw materials
 reserves totaled $17.6 million and $16.9 million, respectively, and
 finished goods inventory reserves totaled $7.6 million and $7.8
 million, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-278444:notes:112]
[same as prior period, unchanged from 0001193125-15-173975:notes:124]

[0001193125-15-278444:notes:113]
Our effective tax rate increased from 34.2% in the six months ended
 June 30, 2014 to 39.1% in the six months ended June 30,
 2015. The increase in the effective tax rate between the two
 periods is primarily attributable to the release of a valuation
 allowance attributable to a foreign subsidiary in 2014.


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-15-278444:notes:114]
The following table is a summary of our stock options outstanding
 as of December 31, 2014 and June 30, 2015 and the changes
 that occurred during the six months ended June 30, 2015:

[0001193125-15-278444:notes:115]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2014 |  |  | 6,981 |  |  | $ | 23.62 |  |  |  | 6.45 |  |  | $ | 10,625 |  |
| Options granted |  |  | 2 |  |  | $ | 22.56 |  |  |  |  |  |  |  |  |  |
| Options forfeited |  |  | (243 | ) |  | $ | 21.01 |  |  |  |  |  |  |  |  |  |
| Options expired |  |  | (157 | ) |  | $ | 26.78 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (52 | ) |  | $ | 16.08 |  |  |  |  |  |  |  |  |  |
| Options outstanding, June 30, 2015 |  |  | 6,531 |  |  | $ | 23.70 |  |  |  | 5.92 |  |  | $ | 446 |  |
| Options vested and expected to vest, June 30, 2015 |  |  | 6,440 |  |  | $ | 23.75 |  |  |  | 5.85 |  |  | $ | 331 |  |
| Options exercisable, June 30, 2015 |  |  | 4,190 |  |  | $ | 25.21 |  |  |  | 4.51 |  |  | $ | 446 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-278444:notes:116]
14. COMMITMENTS AND CONTINGENCIES

[0001193125-15-278444:notes:117]
In the ordinary course of business, we may be subject to various
 legal proceedings and claims, including employment disputes, patent
 claims, disputes over contract agreements and other commercial
 disputes. In some cases, claimants seek damages or other relief,
 such as royalty payments related to patents, which, if granted,
 could require significant expenditures. Although the outcome of any
 claim or litigation can never be certain, it is our opinion that
 the outcome of all contingencies of which we are currently aware
 will not materially affect our business, operations, financial
 condition or cash flows.

[0001193125-15-278444:notes:118]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of June 30, 2015, of which $7.7 million has been applied to
 these commitments.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-15-278444:notes:119]
[same as prior period, unchanged from 0001193125-15-173975:notes:87]

[0001193125-15-278444:notes:120]
[same as prior period, unchanged from 0001193125-15-173975:notes:88]

[0001193125-15-278444:notes:121]
As of June 30, 2015, we had forward contracts outstanding with
 notional amounts totaling €39.0 million ($43.4 million),
 which mature at various times throughout 2015.

[0001193125-15-278444:notes:122]
|  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Income Statement Location |  | June 30, |  |  | June 30, |  |
| (In thousands) |  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | (1,299 | ) |  | $ | (438 | ) |  | $ | 177 |  |  | $ | (5 |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-15-278444:notes:123]
[same as prior period, unchanged from 0001193125-15-173975:notes:105]

[0001193125-15-278444:notes:124]
[same as prior period, unchanged from 0001193125-15-173975:notes:106]

[0001193125-15-278444:notes:125]
Since 1997, our Board of Directors has approved multiple share
 repurchase programs that have authorized open market repurchase
 transactions of up to 45.0 million shares of our common stock.
 During the six months ended June 30, 2015, we repurchased
 2.9 million shares of our common stock at an average price of
 $16.87 per share. As of June 30, 2015, we have the authority to
 purchase an additional 1.9 million shares of our common stock
 under the current plans approved by the Board of Directors.

[0001193125-15-278444:notes:126]
[same as prior period, unchanged from 0001193125-15-173975:notes:108]

[0001193125-15-278444:notes:127]
We issued 0.1 million shares of treasury stock during the six
 months ended June 30, 2015 to accommodate employee stock
 option exercises. The stock options had exercise prices ranging
 from $15.29 to $22.53. We received proceeds totaling $0.8 million
 from the exercise of these stock options during the six months
 ended June 30, 2015.

[0001193125-15-278444:notes:128]
[same as prior period, unchanged from 0001193125-15-173975:notes:110]

[0001193125-15-278444:notes:129]
[same as prior period, unchanged from 0001193125-15-173975:notes:113]

[0001193125-15-278444:notes:130]
Other comprehensive income consists of unrealized gains (losses) on
 available-for-sale securities, reclassification adjustments for
 amounts included in net income related to impairments of
 available-for-sale securities, realized gains (losses) on
 available-for-sale securities, and amortization of actuarial gains
 (losses) related to our defined benefit plan, defined benefit plan
 adjustments, and foreign currency translation adjustments.

[0001193125-15-278444:notes:131]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the three months
 ended June 30, 2015 and 2014:

[0001193125-15-278444:notes:132]
| (In thousands) |  | Three Months Ended June 30, 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 3,264 |  |  | Net realized investment gain |
| Impairment expense |  |  | (51 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (105 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 3,108 |  |  |  |
| Tax (expense) benefit |  |  | (1,220 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,888 |  |  |  |

[0001193125-15-278444:notes:133]
| (1) | Included in the computation of net periodic pension cost. See Note 3 of Notes to Consolidated Financial Statements. |

[0001193125-15-278444:notes:134]
| (In thousands) |  | Three Months Ended June 30, 2014 |  |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |  |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 2,160 |  |  |  | Net realized investment gain |  |
| Impairment expense |  |  | (34 | ) |  |  | Net realized investment gain |  |
| Total reclassifications for the period, before tax |  |  | 2,126 |  |  |  |  |  |
| Tax (expense) benefit |  |  | (829 | ) |  |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,297 |  |  |  |  |  |

[0001193125-15-278444:notes:135]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the six months ended
 June 30, 2015 and 2014:

[0001193125-15-278444:notes:136]
| (In thousands) |  | Six Months Ended June 30, 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 6,340 |  |  | Net realized investment gain |
| Impairment expense |  |  | (73 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (203 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 6,064 |  |  |  |
| Tax (expense) benefit |  |  | (2,381 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 3,683 |  |  |  |

[0001193125-15-278444:notes:137]
| (In thousands) |  | Six Months Ended June 30, 2014 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 4,330 |  |  | Net realized investment gain |
| Impairment expense |  |  | (34 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 4,296 |  |  |  |
| Tax (expense) benefit |  |  | (1,676 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,620 |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-278444:notes:138]
[same as prior period, unchanged from 0001193125-15-173975:notes:142]

[0001193125-15-278444:notes:139]
[same as prior period, unchanged from 0001193125-15-173975:notes:143]

[0001193125-15-278444:notes:140]
There were no options granted during the three months ended
 June 30, 2015 and 2014. The weighted-average assumptions and
 value of options granted for the six months ended June 30,
 2015 and 2014 are as follows:

[0001193125-15-278444:notes:141]
|  |  | Six Months Ended |  |
|  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Expected volatility |  |  | 38.75 | % |  |  | 39.57 | % |
| Risk-free interest rate |  |  | 1.46 | % |  |  | 1.86 | % |
| Expected dividend yield |  |  | 1.60 | % |  |  | 1.38 | % |
| Expected life (in years) |  |  | 6.47 |  |  |  | 6.25 |  |
| Weighted-average estimated value |  | $ | 7.63 |  |  | $ | 9.28 |  |

[0001193125-15-278444:notes:142]
The fair value of our RSUs is calculated using a Monte Carlo
 Simulation valuation method. No RSUs were granted or vested during
 the three and six months ended June 30, 2015 and 2014. Twelve
 thousand RSUs were forfeited during the six months ended
 June 30, 2015.

[0001193125-15-278444:notes:143]
The fair value of restricted stock is equal to the closing price of
 our stock on the date of grant. No restricted stock was granted or
 forfeited during the three and six months ended June 30, 2015
 and 2014. Two thousand shares of restricted stock vested during the
 three months ended June 30, 2015.

[0001193125-15-278444:notes:144]
Stock-based compensation expense recognized in our Consolidated
 Statements of Income for the three and six months ended
 June 30, 2015 and 2014 is based on options, RSUs and
 restricted stock ultimately expected to vest, and has been reduced
 for estimated forfeitures. Estimated forfeitures for stock options
 are based upon historical experience and approximate 3.3% annually.
 We estimated a 0% forfeiture rate for our RSUs and restricted stock
 due to the limited number of recipients and historical experience
 for these awards.

[0001193125-15-278444:notes:145]
As of June 30, 2015, total compensation expense related to
 non-vested stock options, RSUs and restricted stock not yet
 recognized was approximately $12.6 million, which is expected to be
 recognized over an average remaining recognition period of 2.5
 years.

[0001193125-15-278444:notes:146]
The aggregate intrinsic values in the table above represent the
 total pre-tax intrinsic value (the difference between the closing
 price of our stock on the last trading day of the quarter and the
 exercise price, multiplied by the number of in-the-money options)
 that would have been received by the option holders had all option
 holders exercised their options on June 30, 2015. The
 aggregate intrinsic value will change based on the fair market
 value of our stock.

[0001193125-15-278444:notes:147]
The total pre-tax intrinsic value of options exercised during the
 three and six months ended June 30, 2015 was $25 thousand and
 $0.1 million, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-15-278444:notes:148]
Recent Accounting Pronouncements

[0001193125-15-278444:notes:149]
In May 2014, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update No. 2014-09, Revenue from
 Contracts with Customers (ASU 2014-09), which supersedes the
 revenue recognition requirements in Topic 605, Revenue
 Recognition, including most industry-specific revenue
 recognition guidance throughout the Industry Topics of the
 Codification. The core principle of ASU 2014-09 is to recognize
 revenues when promised goods or services are transferred to
 customers in an amount that reflects the consideration that is
 expected to be received for those goods or services. ASU 2014-09 is
 effective for annual reporting periods beginning after
 December 15, 2017, including interim periods within that
 reporting period, and early application is not permitted. ASU
 2014-09 allows for either full retrospective or modified
 retrospective adoption. We are currently evaluating the transition
 method that will be elected and the impact that the adoption of ASU
 2014-09 will have on our financial position, results of operations
 and cash flows.

[0001193125-15-278444:notes:150]
In April 2015, the FASB issued Accounting Standards Update
 No. 2015-05, Intangibles – Goodwill and Other –
 Internal-Use Software (Subtopic 350-40): Customer’s
 Accounting for Fees Paid in a Cloud Computing Arrangement (ASU
 2015-05), which provides guidance on accounting for fees paid by a
 customer in a cloud computing arrangement. If a cloud computing
 arrangement includes a software license, then the customer should
 account for the software license element of the arrangement
 consistent with the acquisition of other software licenses. If a
 cloud computing arrangement does not include a software license,
 the customer should account for the arrangement as a service
 contract. ASU 2015-05 is effective for annual reporting periods
 beginning after December 15, 2015, including interim periods
 within that reporting period. Early adoption is permitted. The
 amendments may be applied either prospectively to all arrangements
 entered into or materially modified after the effective date or
 retrospectively. We do not believe the adoption of ASU 2015-05 will
 have a material impact on our financial position, results of
 operations and cash flows.

[0001193125-15-278444:notes:151]
In July 2015, the FASB issued Accounting Standards Update No.
 2015-11, Inventory (Topic 330): Simplifying the Measurement of
 Inventory (ASU 2015-11). Currently, Topic 330,
 Inventory, requires an entity to measure inventory at the
 lower of cost or market. Market could be replacement cost, net
 realizable value, or net realizable value less an approximately
 normal profit margin. ASU 2015-11 does not apply to inventory that
 is measured using last-in, first-out (LIFO) or the retail inventory
 method. The amendments apply to all other inventory, which includes
 inventory that is measured using first-in, first-out (FIFO) or
 average cost. ASU 2015-11 requires an entity to measure in scope
 inventory at the lower of cost and net realizable value. Net
 realizable value is the estimated selling prices in the ordinary
 course of business, less reasonably predictable costs of
 completion, disposal, and transportation. ASU 2015-11 is effective
 for annual reporting periods beginning after December 15,
 2016, including interim periods within that reporting period. The
 amendments should be applied prospectively with earlier application
 permitted as of the beginning of an interim or annual reporting
 period. We do not believe the adoption of ASU 2015-05 will have a
 material impact on our financial position, results of operations
 and cash flows.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-15-278444:notes:152]
[same as prior period, unchanged from 0001193125-15-173975:notes:130]

[0001193125-15-278444:notes:153]
[same as prior period, unchanged from 0001193125-15-173975:notes:131]

[0001193125-15-278444:notes:154]
[same as prior period, unchanged from 0001193125-15-173975:notes:132]

[0001193125-15-278444:notes:155]
[same as prior period, unchanged from 0001193125-15-173975:notes:133]

[0001193125-15-278444:notes:156]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter of 2015. The aggregate
 impact of the corrections was a $0.8 million reduction to pre-tax
 income for the six months ended June 30, 2015 and is not
 expected to be material to the current year annual results.

[0001193125-15-278444:notes:157]
[same as prior period, unchanged from 0001193125-15-173975:notes:135]

[0001193125-15-278444:notes:158]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated pension liability,
 fair value of investments, and the evaluation of
 other-than-temporary declines in the value of investments. Actual
 amounts could differ significantly from these estimates.


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-278444:notes:159]
[same as prior period, unchanged from 0001193125-15-173975:notes:4]

[0001193125-15-278444:notes:160]
Anti-dilutive options to purchase common stock outstanding were
 excluded from the above calculations. Anti-dilutive options totaled
 6.1 million and 4.3 million for the three months ended
 June 30, 2015 and 2014, respectively, and 5.7 million and
 3.1 million for the six months ended June 30, 2015 and
 2014, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-15-278444:notes:161]
13. RELATED PARTY TRANSACTIONS

[0001193125-15-278444:notes:162]
During 2014, we employed the law firm of our director emeritus for
 legal services. All bills for services rendered by this firm were
 reviewed and approved by our Chief Financial Officer. We believe
 that the fees for such services were comparable to those charged by
 other firms for services rendered to us. The services of our
 director emeritus ended with his death on September 7, 2014.
 For the three and six months ended June 30, 2014, we incurred
 fees of $10 thousand per month for these legal services.


## us-gaap:SubsequentEventsTextBlock

[0001193125-15-278444:notes:163]
15. SUBSEQUENT EVENTS

[0001193125-15-278444:notes:164]
On July 14, 2015, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 July 30, 2015. The payment date will be August 13, 2015.
 The quarterly dividend payment will be approximately $4.5 million.
 In July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.

[0001193125-15-278444:notes:165]
On July 14, 2015, our Board of Directors authorized the
 repurchase of an additional 5.0 million shares of our common
 stock (bringing the total shares authorized for repurchase to 50.0
 million), which will commence upon completion of the repurchase
 plan announced May 14, 2014. This new authorization will be
 implemented through open market or private purchases from time to
 time as conditions warrant.

[0001193125-15-278444:notes:166]
During the third quarter and as of August 5, 2015, we have
 repurchased 0.8 million shares of our common stock through
 open market purchases at an average cost of $16.31 per share. We
 currently have the authority to purchase an additional
 6.0 million shares of our common stock under the current plan
 approved by the Board of Directors.
