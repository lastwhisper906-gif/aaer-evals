# ADTN note change history — 0001193125-15-173975 → 0001193125-15-278444


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-08-05):
[0001193125-15-278444:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of June 30, 2015, of which $7.7 million has been applied to
 these commitments.
  (was, 2015-05-06, similarity 0.9773):
[0001193125-15-173975:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of March 31, 2015, of which $7.7 million has been applied to
 these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-08-05):
[0001193125-15-278444:note_history:2]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter of 2015. The aggregate
 impact of the corrections was a $0.8 million reduction to pre-tax
 income for the six months ended June 30, 2015 and is not
 expected to be material to the current year annual results.
  (was, 2015-05-06, similarity 0.9139):
[0001193125-15-173975:note_history:2]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter. The aggregate impact
 of the corrections was a $0.8 million reduction to pre-tax income
 for the three months ended March 31, 2015 and is not expected
 to be material to the current year annual results.

- changed (2015-08-05):
[0001193125-15-278444:note_history:3]
In May 2014, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update No. 2014-09, Revenue from
 Contracts with Customers (ASU 2014-09), which supersedes the
 revenue recognition requirements in Topic 605, Revenue
 Recognition, including most industry-specific revenue
 recognition guidance throughout the Industry Topics of the
 Codification. The core principle of ASU 2014-09 is to recognize
 revenues when promised goods or services are transferred to
 customers in an amount that reflects the consideration that is
 expected to be received for those goods or services. ASU 2014-09 is
 effective for annual reporting periods beginning after
 December 15, 2017, including interim periods within that
 reporting period, and early application is not permitted. ASU
 2014-09 allows for either full retrospective or modified
 retrospective adoption. We are currently evaluating the transition
 method that will be elected and the impact that the adoption of ASU
 2014-09 will have on our financial position, results of operations
 and cash flows.
  (was, 2015-05-06, similarity 0.9965):
[0001193125-15-173975:note_history:3]
In May 2014, the Financial Accounting Standards Board issued
 Accounting Standards Update No. 2014-09, Revenue from Contracts with
 Customers (ASU
 2014-09), which supersedes the revenue recognition requirements in
 Topic 605, Revenue Recognition,
 including most industry-specific revenue recognition guidance
 throughout the Industry Topics of the Codification. The core
 principle of ASU 2014-09 is to recognize revenues when promised
 goods or services are transferred to customers in an amount that
 reflects the consideration that is expected to be received for
 those goods or services. ASU 2014-09 is effective for annual
 reporting periods beginning after December 15, 2016, including
 interim periods within that reporting period, and early application
 is not permitted. ASU 2014-09 allows for either full retrospective
 or modified retrospective adoption. We are currently evaluating the
 transition method that will be elected and the impact that the
 adoption of ASU 2014-09 will have on our financial position,
 results of operations and cash flows.

- added (2015-08-05):
[0001193125-15-278444:note_history:4]
In April 2015, the FASB issued Accounting Standards Update
 No. 2015-05, Intangibles – Goodwill and Other –
 Internal-Use Software (Subtopic 350-40): Customer’s
 Accounting for Fees Paid in a Cloud Computing Arrangement (ASU
 2015-05), which provides guidance on accounting for fees paid by a
 customer in a cloud computing arrangement. If a cloud computing
 arrangement includes a software license, then the customer should
 account for the software license element of the arrangement
 consistent with the acquisition of other software licenses. If a
 cloud computing arrangement does not include a software license,
 the customer should account for the arrangement as a service
 contract. ASU 2015-05 is effective for annual reporting periods
 beginning after December 15, 2015, including interim periods
 within that reporting period. Early adoption is permitted. The
 amendments may be applied either prospectively to all arrangements
 entered into or materially modified after the effective date or
 retrospectively. We do not believe the adoption of ASU 2015-05 will
 have a material impact on our financial position, results of
 operations and cash flows.

- added (2015-08-05):
[0001193125-15-278444:note_history:5]
In July 2015, the FASB issued Accounting Standards Update No.
 2015-11, Inventory (Topic 330): Simplifying the Measurement of
 Inventory (ASU 2015-11). Currently, Topic 330,
 Inventory, requires an entity to measure inventory at the
 lower of cost or market. Market could be replacement cost, net
 realizable value, or net realizable value less an approximately
 normal profit margin. ASU 2015-11 does not apply to inventory that
 is measured using last-in, first-out (LIFO) or the retail inventory
 method. The amendments apply to all other inventory, which includes
 inventory that is measured using first-in, first-out (FIFO) or
 average cost. ASU 2015-11 requires an entity to measure in scope
 inventory at the lower of cost and net realizable value. Net
 realizable value is the estimated selling prices in the ordinary
 course of business, less reasonably predictable costs of
 completion, disposal, and transportation. ASU 2015-11 is effective
 for annual reporting periods beginning after December 15,
 2016, including interim periods within that reporting period. The
 amendments should be applied prospectively with earlier application
 permitted as of the beginning of an interim or annual reporting
 period. We do not believe the adoption of ASU 2015-05 will have a
 material impact on our financial position, results of operations
 and cash flows.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-05):
[0001193125-15-278444:note_history:6]
At June 30, 2015, we held the following securities and
 investments, recorded at either fair value or cost.
  (was, 2015-05-06, similarity 0.9552):
[0001193125-15-173975:note_history:6]
At March 31, 2015, we held the following securities and
 investments, recorded at either fair value or cost.

- changed (2015-08-05):
[0001193125-15-278444:note_history:7]
As of June 30, 2015, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:
  (was, 2015-05-06, similarity 0.9581):
[0001193125-15-173975:note_history:7]
As of March 31, 2015, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

- changed (2015-08-05):
[0001193125-15-278444:note_history:8]
At June 30, 2015, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 June 30, 2015, the estimated fair value of the Bond using a
 level 2 valuation technique was approximately $29.9 million, based
 on a debt security with a comparable interest rate and maturity and
 a Standard and Poor’s credit rating of AAA. For more
 information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.
  (was, 2015-05-06, similarity 0.9881):
[0001193125-15-173975:note_history:8]
At March 31, 2015, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 March 31, 2015, the estimated fair value of the Bond using a
 level 2 valuation technique was approximately $29.7 million, based
 on a debt security with a comparable interest rate and maturity and
 a Standard and Poor’s credit rating of AAA. For more
 information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

- changed (2015-08-05):
[0001193125-15-278444:note_history:9]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and six months
 ended June 30, 2015 and 2014, other-than-temporary impairment
 charges were not significant.
  (was, 2015-05-06, similarity 0.9811):
[0001193125-15-173975:note_history:9]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three months ended
 March 31, 2015 and 2014, other-than-temporary impairment
 charges were not significant.

- changed (2015-08-05):
[0001193125-15-278444:note_history:10]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Gross realized gains |  | $ | 3,459 |  |  | $ | 2,407 |  |  | $ | 6,604 |  |  | $ | 4,635 |  |
| Gross realized losses |  | $ | (204 | ) |  | $ | (67 | ) |  | $ | (234 | ) |  | $ | (103 | ) |
  (was, 2015-05-06, similarity 0.7672):
[0001193125-15-173975:note_history:10]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Gross realized gains |  | $ | 3,145 |  |  | $ | 2,228 |  |
| Gross realized losses |  | $ | (30 | ) |  | $ | (36 | ) |

- changed (2015-08-05):
[0001193125-15-278444:note_history:11]
As of June 30, 2015 and 2014, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.
  (was, 2015-05-06, similarity 0.9705):
[0001193125-15-173975:note_history:11]
As of March 31, 2015 and 2014, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.

- changed (2015-08-05):
[0001193125-15-278444:note_history:12]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1—Values based on unadjusted quoted prices for
 identical assets or liabilities in an active market; Level
 2—Values based on quoted prices in markets that are not
 active or model inputs that are observable either directly or
 indirectly; Level 3—Values based on prices or valuation
 techniques that require inputs that are both unobservable and
 significant to the overall fair value measurement. These inputs
 include information supplied by investees.
  (was, 2015-05-06, similarity 0.9917):
[0001193125-15-173975:note_history:12]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1 - Values based on unadjusted quoted prices for
 identical assets or liabilities in an active market; Level 2 -
 Values based on quoted prices in markets that are not active or
 model inputs that are observable either directly or indirectly;
 Level 3 - Values based on prices or valuation techniques that
 require inputs that are both unobservable and significant to the
 overall fair value measurement. These inputs include information
 supplied by investees.

- changed (2015-08-05):
[0001193125-15-278444:note_history:13]
|  |  | Fair Value Measurements at June 30, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,087 |  |  | $ | 1,087 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 16,534 |  |  |  | 16,534 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 114,430 |  |  |  | — |  |  |  | 114,430 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 67,387 |  |  |  | — |  |  |  | 67,387 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 3,695 |  |  |  | — |  |  |  | 3,695 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 7,786 |  |  |  | 7,786 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 29,514 |  |  |  | 29,514 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 239,346 |  |  |  | 53,834 |  |  |  | 185,512 |  |  |  | — |  |
| Total |  | $ | 240,433 |  |  | $ | 54,921 |  |  | $ | 185,512 |  |  | $ | — |  |
  (was, 2015-05-06, similarity 0.9186):
[0001193125-15-173975:note_history:13]
|  |  | Fair Value Measurements at March 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | $ | 11,997 |  |  | $ | — |  |  | $ | 11,997 |  |  | $ | — |  |
| Money market funds |  |  | 3,228 |  |  |  | 3,228 |  |  |  | — |  |  |  | — |  |
| Cash equivalents |  |  | 15,225 |  |  |  | 3,228 |  |  |  | 11,997 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 16,572 |  |  |  | 16,572 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 132,388 |  |  |  | — |  |  |  | 132,388 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 93,117 |  |  |  | — |  |  |  | 93,117 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 4,245 |  |  |  | — |  |  |  | 4,245 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 9,034 |  |  |  | 9,034 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,589 |  |  |  | 28,589 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 283,945 |  |  |  | 54,195 |  |  |  | 229,750 |  |  |  | — |  |
| Total |  | $ | 299,170 |  |  | $ | 57,423 |  |  | $ | 241,747 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2015-08-05):
[0001193125-15-278444:note_history:14]
During 2014, we employed the law firm of our director emeritus for
 legal services. All bills for services rendered by this firm were
 reviewed and approved by our Chief Financial Officer. We believe
 that the fees for such services were comparable to those charged by
 other firms for services rendered to us. The services of our
 director emeritus ended with his death on September 7, 2014.
 For the three and six months ended June 30, 2014, we incurred
 fees of $10 thousand per month for these legal services.
  (was, 2015-05-06, similarity 0.9558):
[0001193125-15-173975:note_history:14]
During 2014, we employed the law firm of our director emeritus for
 legal services. All bills for services rendered by this firm were
 reviewed and approved by our Chief Financial Officer. We believe
 that the fees for such services were comparable to those charged by
 other firms for services rendered to us. The services of our
 director emeritus ended with his death on September 7, 2014.
 For the three months ended March 31, 2014, we incurred fees of
 $10 thousand per month for these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2015-08-05):
[0001193125-15-278444:note_history:15]
On July 14, 2015, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 July 30, 2015. The payment date will be August 13, 2015.
 The quarterly dividend payment will be approximately $4.5 million.
 In July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.

- added (2015-08-05):
[0001193125-15-278444:note_history:16]
On July 14, 2015, our Board of Directors authorized the
 repurchase of an additional 5.0 million shares of our common
 stock (bringing the total shares authorized for repurchase to 50.0
 million), which will commence upon completion of the repurchase
 plan announced May 14, 2014. This new authorization will be
 implemented through open market or private purchases from time to
 time as conditions warrant.

- changed (2015-08-05):
[0001193125-15-278444:note_history:17]
During the third quarter and as of August 5, 2015, we have
 repurchased 0.8 million shares of our common stock through
 open market purchases at an average cost of $16.31 per share. We
 currently have the authority to purchase an additional
 6.0 million shares of our common stock under the current plan
 approved by the Board of Directors.
  (was, 2015-05-06, similarity 0.972):
[0001193125-15-173975:note_history:17]
During the second quarter and as of May 6, 2015, we have
 repurchased 1.2 million shares of our common stock through open
 market purchases at an average cost of $16.33 per share. We
 currently have the authority to purchase an additional 3.4 million
 shares of our common stock under the current plan approved by the
 Board of Directors.

- removed (2015-08-05):
[0001193125-15-173975:note_history:18]
On April 21, 2015, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 May 7, 2015. The payment date will be May 21, 2015. The
 quarterly dividend payment will be approximately $4.7 million. In
 July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.
