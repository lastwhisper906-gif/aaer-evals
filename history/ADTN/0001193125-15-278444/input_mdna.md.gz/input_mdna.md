# ADTN MD&A — 0001193125-15-278444


## mdna

[0001193125-15-278444:mdna:1]
[same as prior period, unchanged from 0001193125-15-173975:mdna:1]

[0001193125-15-278444:mdna:2]
[same as prior period, unchanged from 0001193125-15-173975:mdna:2]

[0001193125-15-278444:mdna:3]
[same as prior period, unchanged from 0001193125-15-173975:mdna:3]

[0001193125-15-278444:mdna:4]
[same as prior period, unchanged from 0001193125-15-173975:mdna:4]

[0001193125-15-278444:mdna:5]
[same as prior period, unchanged from 0001193125-15-173975:mdna:5]

[0001193125-15-278444:mdna:6]
[same as prior period, unchanged from 0001193125-15-173975:mdna:6]

[0001193125-15-278444:mdna:7]
[same as prior period, unchanged from 0001193125-15-173975:mdna:7]

[0001193125-15-278444:mdna:8]
[same as prior period, unchanged from 0001193125-15-173975:mdna:8]

[0001193125-15-278444:mdna:9]
[same as prior period, unchanged from 0001193125-15-173975:mdna:9]

[0001193125-15-278444:mdna:10]
[same as prior period, unchanged from 0001193125-15-173975:mdna:10]

[0001193125-15-278444:mdna:11]
[same as prior period, unchanged from 0001193125-15-173975:mdna:11]

[0001193125-15-278444:mdna:12]
[same as prior period, unchanged from 0001193125-15-173975:mdna:12]

[0001193125-15-278444:mdna:13]
[same as prior period, unchanged from 0001193125-15-173975:mdna:13]

[0001193125-15-278444:mdna:14]
[same as prior period, unchanged from 0001193125-15-173975:mdna:14]

[0001193125-15-278444:mdna:15]
[same as prior period, unchanged from 0001193125-15-173975:mdna:15]

[0001193125-15-278444:mdna:16]
[same as prior period, unchanged from 0001193125-15-173975:mdna:16]

[0001193125-15-278444:mdna:17]
[same as prior period, unchanged from 0001193125-15-173975:mdna:17]

[0001193125-15-278444:mdna:18]
[same as prior period, unchanged from 0001193125-15-173975:mdna:18]

[0001193125-15-278444:mdna:19]
[same as prior period, unchanged from 0001193125-15-173975:mdna:19]

[0001193125-15-278444:mdna:20]
[same as prior period, unchanged from 0001193125-15-173975:mdna:20]

[0001193125-15-278444:mdna:21]
[same as prior period, unchanged from 0001193125-15-173975:mdna:21]

[0001193125-15-278444:mdna:22]
[same as prior period, unchanged from 0001193125-15-173975:mdna:22]

[0001193125-15-278444:mdna:23]
[same as prior period, unchanged from 0001193125-15-173975:mdna:23]

[0001193125-15-278444:mdna:24]
[same as prior period, unchanged from 0001193125-15-173975:mdna:24]

[0001193125-15-278444:mdna:25]
[same as prior period, unchanged from 0001193125-15-173975:mdna:25]

[0001193125-15-278444:mdna:26]
[same as prior period, unchanged from 0001193125-15-173975:mdna:26]

[0001193125-15-278444:mdna:27]
[same as prior period, unchanged from 0001193125-15-173975:mdna:27]

[0001193125-15-278444:mdna:28]
[same as prior period, unchanged from 0001193125-15-173975:mdna:28]

[0001193125-15-278444:mdna:29]
[same as prior period, unchanged from 0001193125-15-173975:mdna:29]

[0001193125-15-278444:mdna:30]
[same as prior period, unchanged from 0001193125-15-173975:mdna:30]

[0001193125-15-278444:mdna:31]
[same as prior period, unchanged from 0001193125-15-173975:mdna:31]

[0001193125-15-278444:mdna:32]
[same as prior period, unchanged from 0001193125-15-173975:mdna:32]

[0001193125-15-278444:mdna:33]
[same as prior period, unchanged from 0001193125-15-173975:mdna:33]

[0001193125-15-278444:mdna:34]
[same as prior period, unchanged from 0001193125-15-173975:mdna:34]

[0001193125-15-278444:mdna:35]
[same as prior period, unchanged from 0001193125-15-173975:mdna:35]

[0001193125-15-278444:mdna:36]
[same as prior period, unchanged from 0001193125-15-173975:mdna:36]

[0001193125-15-278444:mdna:37]
[same as prior period, unchanged from 0001193125-15-173975:mdna:37]

[0001193125-15-278444:mdna:38]
[same as prior period, unchanged from 0001193125-15-173975:mdna:38]

[0001193125-15-278444:mdna:39]
[same as prior period, unchanged from 0001193125-15-173975:mdna:39]

[0001193125-15-278444:mdna:40]
[same as prior period, unchanged from 0001193125-15-173975:mdna:40]

[0001193125-15-278444:mdna:41]
[same as prior period, unchanged from 0001193125-15-173975:mdna:41]

[0001193125-15-278444:mdna:42]
[same as prior period, unchanged from 0001193125-15-173975:mdna:42]

[0001193125-15-278444:mdna:43]
[same as prior period, unchanged from 0001193125-15-173975:mdna:43]

[0001193125-15-278444:mdna:44]
Sales were $160.1 million and $303.0 million for the three and six months ended June 30, 2015
compared to $176.1 million and $323.1 million for the three and six months ended June 30, 2014. Product revenues for our three core areas, Broadband Access, Optical and Internetworking, were $150.3 million and $281.8 million for the three and
six months ended June 30, 2015 compared to $165.1 million and $296.4 million for the three and six months ended June 30, 2014. Our gross margin decreased to 42.6% and 44.2% for the three and six months ended June 30, 2015 from 49.3%
and 50.9% for the three and six months ended June 30, 2014. Our operating income margin decreased to 0.4% and 0.9% for the three and six months ended June 30, 2015 from 11.0% and 9.5% for the three and six months ended June 30, 2014.
Net income was $2.5 million and $5.9 million for the three and six months ended June 30, 2015 compared to $14.4 million and $24.0 million for the three and six months ended June 30, 2014. Our effective tax rate increased to 38.1% and 39.1%
for the three and six months ended June 30, 2015 from 34.0% and 34.2% for the three and six months ended June 30, 2014. Earnings per share, assuming dilution, were $0.05 and $0.11 for the three and six months ended June 30, 2015
compared to $0.26 and $0.42 for the three and six months ended June 30, 2014.

[0001193125-15-278444:mdna:45]
26

[0001193125-15-278444:mdna:46]
[same as prior period, unchanged from 0001193125-15-173975:mdna:46]

[0001193125-15-278444:mdna:47]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, foreign
currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs and
announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the
obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer
delivery requirements, which may negatively impact our operating results in a given quarter.

[0001193125-15-278444:mdna:48]
Accordingly, our historical financial performance is not
necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. A list of factors that could materially affect our business, financial condition or operating
results is included under “Factors That Could Affect Our Future Results” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this report. These
factors have also been discussed in more detail in Item 1A of Part I in our most recent Annual Report on Form 10-K for the year ended December 31, 2014, filed on February 24, 2015 with the SEC.

[0001193125-15-278444:mdna:49]
CRITICAL ACCOUNTING POLICIES AND ESTIMATES

[0001193125-15-278444:mdna:50]
Our critical
accounting policies and estimates have not changed significantly from those detailed in our most recent Annual Report on Form 10-K for the year ended December 31, 2014, filed on February 24, 2015 with the SEC.

[0001193125-15-278444:mdna:51]
EFFECT OF RECENT ACCOUNTING PRONOUNCEMENTS

[0001193125-15-278444:mdna:52]
See Note 1 of
Notes to Consolidated Financial Statements in Item 1 of this Form 10-Q for a full description of recent accounting pronouncements, including the expected dates of adoption and estimated effects on results of operations and financial condition,
which is incorporated herein by reference.

[0001193125-15-278444:mdna:53]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2015 COMPARED TO THREE AND SIX MONTHS
ENDED JUNE 30, 2014

[0001193125-15-278444:mdna:54]
[same as prior period, unchanged from 0001193125-15-173975:mdna:54]

[0001193125-15-278444:mdna:55]
ADTRAN’s
sales decreased 9.1% from $176.1 million in the three months ended June 30, 2014 to $160.1 million in the three months ended June 30, 2015 and decreased 6.2% from $323.1 million in the six months ended June 30, 2014 to $303.0 million
in the six months ended June 30, 2015. The decrease in sales for the three months ended June 30, 2015 is primarily attributable to a $7.8 million decrease in sales of our Internetworking products, a $7.6 million decrease in sales of our
Broadband Access products, and a $1.2 million decrease in sales of our HDSL and other legacy products. The decrease in sales for the six months ended June 30, 2015 is primarily attributable to a $10.6 million decrease in sales of our
Internetworking products, a $4.3 million decrease in sales of our Broadband Access products, and a $5.6 million decrease in sales of our HDSL and other legacy products. Sales during the three and six months ended June 30, 2015 were also
negatively impacted by the strengthening of the U.S. dollar against the Euro.

[0001193125-15-278444:mdna:56]
Carrier Networks sales decreased 5.6% from $143.5 million in the three months ended June 30, 2014 to $135.4
million in the three months ended June 30, 2015, and decreased 3.9% from $261.6 million in the six months ended June 30, 2014 to $251.4 million in the six months ended June 30, 2015. The decrease in sales for the three and six months
ended June, 2015 is primarily attributable to decreases in sales of our Broadband Access products and sales of our HDSL and other legacy products. The decrease in sales of our Broadband Access products is primarily attributable to the impact of the
strengthening of the U.S. dollar against the Euro. The decrease in sales of HDSL and other legacy products for the three and six months ended June 30, 2015 has been expected as customers continue to upgrade their networks to deliver higher
bandwidth services by migrating to newer technologies, including to our core products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to
decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-15-278444:mdna:57]
Enterprise Networks sales decreased 24.3% from $32.7 million in the three months ended June 30, 2014 to $24.7 million in the three months ended
June 30, 2015, and decreased 16.2% from $61.5 million in the six months ended June 30, 2014 to $51.6 million in the six months ended June 30, 2015. The decrease in sales for the three and six months ended June 30, 2015 is
primarily attributable to decreases in sales of our Internetworking products. The decrease in sales of our Internetworking products for the Enterprise Networks division was primarily attributable to continued weakness in our IP gateway product
segment, primarily in our CLEC customer base. Internetworking product sales attributable to Enterprise Networks were 93.1% and 93.5% of the division’s sales in the three and six months ended June 30, 2015, compared to 95.0% and 94.7% in
the three and six months ended June 30, 2014. Legacy products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 18.6% and 19.0% for the three and six months
ended June 30, 2014 to 15.4% and 17.0% for the three and six months ended June 30, 2015.

[0001193125-15-278444:mdna:58]
International sales, which are included in the Carrier
Networks and Enterprise Networks amounts discussed above, decreased 29.5% from $79.1 million in the three months ended June 30, 2014 to $55.7 million in the three months ended June 30, 2015, and decreased 13.7% from $133.4 million in the
six months ended June 30, 2014 to $115.1 million in the six months ended June 30, 2015. International sales, as a percentage of total sales, decreased from 44.9% and 41.3% for the three and six months ended June 30, 2014 to 34.8% and
38.0% for the three and six months ended June 30, 2015. The decrease in international sales for the three and six months ended June 30, 2015 is primarily attributable to a decrease in sales in the EMEA region, Latin America and the
Asia-Pacific region. The decrease in sales in the EMEA region is primarily attributable to the strengthening of the U.S. dollar against the Euro during the three and six months ended June 30, 2015.

[0001193125-15-278444:mdna:59]
Carrier System product sales decreased $9.8 million and $8.9 million in the three and six months ended June 30, 2015 compared to the three and six months
ended June 30, 2014. The decrease for the three months ended June 30, 2015 is primarily attributable to a $7.6 million decrease in Broadband Access product sales and a $2.8 million decrease in legacy product sales. The decrease for the six
months ended June 30, 2015 is primarily attributable to a $4.3 million decrease in Broadband Access product sales and a $4.9 million decrease in legacy product sales. The decreases for the three and six months ended June 30, 2015 are
primarily attributable to the factors discussed above.

[0001193125-15-278444:mdna:60]
Business Networking product sales decreased $7.8 million and $10.3 million in the three and six
months ended June 30, 2015 compared to the three and six months ended June 30, 2014. The decrease for the three months ended June 30, 2015 is primarily attributable to a $7.8 million decrease in Internetworking product sales. The
decrease for the six months ended June 30, 2015 is primarily attributable to a $10.6 million decrease in Internetworking product sales. The decreases for the three and six months ended June 30, 2015 are primarily attributable to the
factors discussed above.

[0001193125-15-278444:mdna:61]
Loop Access product sales increased $1.6 million in the three months ended June 30, 2015 compared to the three months ended
June 30, 2014, and decreased $1.0 million in the six months ended June 30, 2015 compared to the six months ended June 30, 2014. The increase for the three months ended June 30, 2015 is primarily attributable to a $1.6 million
increase in HDSL product sales. The decrease for the six months ended June 30, 2015 is primarily attributable to a $0.6 million decrease in HDSL product sales. The changes for the three and six months ended June 30, 2015 are primarily
attributable to the factors discussed above.

[0001193125-15-278444:mdna:62]
[same as prior period, unchanged from 0001193125-15-173975:mdna:62]

[0001193125-15-278444:mdna:63]
As a percentage of sales, cost of sales increased from 50.7% in the three months ended June 30, 2014 to 57.4% in the three months ended June 30,
2015, and increased from 49.1% in the six months ended June 30, 2014 to 55.8% in the six months ended June 30, 2015. The increase for the three months ended June 30, 2015 is primarily attributable to the strengthening of the U.S.
dollar against the Euro, growth in our service-related material sales in the U.S. market, and customer mix. The increase in the six months ended June 30, 2015 is primarily attributable to the strengthening of the U.S. dollar against the Euro,
growth in our service-related material sales in the U.S. market, and product to services mix.

[0001193125-15-278444:mdna:64]
Carrier Networks cost of sales, as a percent of division
sales, increased from 52.6% in the three months ended June 30, 2014 to 59.6% in the three months ended June 30, 2015, and increased from 50.5% in the six months ended June 30, 2014 to 58.4% in the six months ended June 30, 2015.
The increases for the three and six months ended June 30, 2015 are primarily attributable to the strengthening of the U.S. dollar against the Euro, growth in service-related material sales in the U.S. market, customer mix, and customer price
movements to achieve market share position.

[0001193125-15-278444:mdna:65]
Enterprise Networks cost of sales, as a percent of division sales, increased from 42.6% in the three months
ended June 30, 2014 to 45.2% in the three months ended June 30, 2015, and increased from 42.8% in the six months ended June 30, 2014 to 43.3% in the six months ended June 30, 2015. The increases for the three and six months ended
June 30, 2015 are primarily attributable to customer mix and product to services mix.

[0001193125-15-278444:mdna:66]
An important part of our strategy is to reduce the product
cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions
and the lowering of product selling prices.

[0001193125-15-278444:mdna:67]
[same as prior period, unchanged from 0001193125-15-173975:mdna:67]

[0001193125-15-278444:mdna:68]
Selling, general and administrative expenses decreased 4.9% from $33.8 million in the three months ended June 30, 2014 to $32.1 million in the three
months ended June 30, 2015, and decreased 6.7% from $67.7 million in the six months ended June 30, 2014 to $63.2 million in the six months ended June 30, 2015. The decrease in selling, general and administrative expenses for the three
months ended June 30, 2015 is primarily attributable to decreases in compensation expense and travel expense, partially offset by restructuring charges. These restructuring charges were primarily attributable to consolidation in our sales
force. The decrease in selling, general and administrative expenses for the six months ended June 30, 2015 is primarily attributable to decreases in compensation expense, legal expense, and independent contractor expense, partially offset by
restructuring charges.

[0001193125-15-278444:mdna:69]
As a percentage of sales, selling, general and administrative expenses increased from 19.2% in the three months ended
June 30, 2014 to 20.1% in the three months ended June 30, 2015, and decreased from 21.0% in the six months ended June 30, 2014 to 20.9% in the six months ended June 30, 2015. Selling, general and administrative expenses as a
percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-15-278444:mdna:70]
RESEARCH AND DEVELOPMENT
EXPENSES

[0001193125-15-278444:mdna:71]
Research and development expenses increased 5.4% from $33.7 million in the three months ended June 30, 2014 to $35.5 million in the
three months ended June 30, 2015, and increased 2.7% from $66.2 million in the six months ended June 30, 2014 to $68.0 million in the six months ended June 30, 2015. The increases in research and development expenses for the three and
six months ended June 30, 2015 are primarily attributable to restructuring charges and engineering and testing expense. These restructuring charges were primary attributable to the consolidation of engineering resources.

[0001193125-15-278444:mdna:72]
As a percentage of sales, research and development expenses increased from 19.1% in the three months ended June 30, 2014 to 22.2% in the three months
ended June 30, 2015, and increased from 20.5% in the six months ended June 30, 2014 to 22.4% in the six months ended June 30, 2015. Research and development expenses as a percentage of sales will fluctuate whenever there are
incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-15-278444:mdna:73]
We expect to continue to incur research and development expenses in connection with our new and existing products
and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products and product
cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-15-278444:mdna:74]
[same as prior period, unchanged from 0001193125-15-173975:mdna:74]

[0001193125-15-278444:mdna:75]
Interest and
dividend income decreased 13.9% from $1.1 million in the three months ended June 30, 2014 to $0.9 million in the three months ended June 30, 2015, and decreased 21.6% from $2.3 million in the six months ended June 30, 2014 to $1.8
million in the six months ended June 30, 2015. The decreases in interest and dividend income for the three and six months ended June 30, 3015 are primarily attributable to a reduction in investment principal partially offset by a slightly
higher rate of return.

[0001193125-15-278444:mdna:76]
[same as prior period, unchanged from 0001193125-15-173975:mdna:76]

[0001193125-15-278444:mdna:77]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended June 30, 2014 and
2015, and $0.4 million in the six months ended June 30, 2014 and $0.3 million in the six months ended June 30, 2015, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for
additional information on our revenue bond.

[0001193125-15-278444:mdna:78]
[same as prior period, unchanged from 0001193125-15-173975:mdna:78]

[0001193125-15-278444:mdna:79]
Net realized investment gain increased 39.1% from $2.3 million in the three months ended June 30, 2014 to $3.3 million in the three months ended
June 30, 2015, and increased 40.6% from $4.5 million in the six months ended June 30, 2014 to $6.4 million in the six months ended June 30, 2015. The increases in realized investment gains for the three and six months ended
June 30, 2015 are primarily attributable to increased gains from the sale of equity securities. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-15-278444:mdna:80]
[same as prior period, unchanged from 0001193125-15-173975:mdna:80]

[0001193125-15-278444:mdna:81]
Other income
(expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, and scrap raw material sales, changed from $0.8 million of expense in the three months ended
June 30, 2014 to $0.5 million of expense in the three months ended June 30, 2015. The change in the three months ended June 30, 2015 is primarily attributable to a decrease in losses on foreign currency transactions during the second
quarter of 2015. Other income (expense) changed from $0.7 million of expense in the six months ended June 30, 2014 to $0.9 million of expense in the six months ended June 30, 2015. The change in the six months ended June 30, 2015 is
primarily attributable to losses on foreign currency transactions during the first quarter of 2015.

[0001193125-15-278444:mdna:82]
[same as prior period, unchanged from 0001193125-15-173975:mdna:82]

[0001193125-15-278444:mdna:83]
Our effective tax rate increased from 34.2% in the six months ended June 30, 2014 to 39.1% in the six months ended June 30, 2015. The increase in the
effective tax rate between the two periods is primarily attributable to the release of a valuation allowance attributable to a foreign subsidiary in 2014.

[0001193125-15-278444:mdna:84]
[same as prior period, unchanged from 0001193125-15-173975:mdna:84]

[0001193125-15-278444:mdna:85]
As a result of the above factors, net
income decreased $11.9 million from $14.4 million in the three months ended June 30, 2014 to $2.5 million in the three months ended June 30, 2015, and decreased $18.1 million from $24.0 million in the six months ended June 30, 2014 to
$5.9 million in the six months ended June 30, 2015.

[0001193125-15-278444:mdna:86]
As a percentage of sales, net income decreased from 8.2% in the three months ended June 30,
2014 to 1.6% in the three months ended June 30, 2015, and decreased from 7.4% in the six months ended June 30, 2014 to 1.9% in the six months ended June 30, 2015.

[0001193125-15-278444:mdna:87]
[same as prior period, unchanged from 0001193125-15-173975:mdna:87]

[0001193125-15-278444:mdna:88]
[same as prior period, unchanged from 0001193125-15-173975:mdna:88]

[0001193125-15-278444:mdna:89]
We intend to finance our operations with cash
flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product
development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to
meet our operating and capital needs for at least the next 12 months.

[0001193125-15-278444:mdna:90]
At June 30, 2015, cash on hand was $87.2 million and short-term investments
were $54.1 million, which resulted in available short-term liquidity of $141.3 million. At December 31, 2014, our cash on hand of $73.4 million and short-term investments of $46.9 million resulted in available short-term liquidity of $120.4
million. The increase in short-term liquidity from December 31, 2014 to June 30, 2015 is primarily attributable to a reallocation of our investments to provide additional funds for our short-term cash needs, which includes operating
activities, capital expenditures, purchase of treasury stock, and shareholder dividends.

[0001193125-15-278444:mdna:91]
[same as prior period, unchanged from 0001193125-15-173975:mdna:91]

[0001193125-15-278444:mdna:92]
Our working capital, which consists of current assets less current liabilities, increased 3.7% from $232.1 million as of December 31, 2014 to $240.7
million as of June 30, 2015. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 1.75 as of December 31, 2014 to 1.60 as of June 30,
2015. The current ratio, defined as current assets divided by current liabilities, decreased from 2.95 as of December 31, 2014 to 2.67 as of June 30, 2015. The changes in our working capital, quick ratio and current ratio are primarily
attributable to increases in cash, inventory, and short-term investments, and a decrease in unearned revenue, partially offset by an increase in accounts payable.

[0001193125-15-278444:mdna:93]
Net accounts receivable increased 0.7% from $88.5 million at December 31, 2014 to $89.1 million at June 30, 2015. Our allowance for doubtful
accounts was $0.1 million at December 31, 2014 and $21 thousand at June 30, 2015. Quarterly accounts receivable days sales outstanding (DSO) decreased from 57 days as of December 31, 2014 to 51 days as of June 30, 2015. The
change in net accounts receivable is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than U.S. customers. Other receivables decreased from $33.3
million at December 31, 2014 to $31.4 million at June 30, 2015. The decrease in other receivables is primarily attributable to the timing of filing returns and collections of VAT receivables in our international subsidiaries. Other
receivables will also fluctuate due to the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001193125-15-278444:mdna:94]
Quarterly inventory turnover increased from 3.5 turns as of December 31, 2014 to 3.8 turns as of June 30, 2015. Inventory increased 15.4% from
December 31, 2014 to June 30, 2015. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing the risk of inventory
obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-15-278444:mdna:95]
Accounts payable increased 51.5% from $56.4 million at
December 31, 2014 to $85.5 million at June 30, 2015. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-15-278444:mdna:96]
[same as prior period, unchanged from 0001193125-15-173975:mdna:96]

[0001193125-15-278444:mdna:97]
Capital expenditures totaled
approximately $5.4 million and $4.9 million for the six months ended June 30, 2015 and 2014, respectively. These expenditures were primarily used to purchase manufacturing and test equipment and computer software and hardware.

[0001193125-15-278444:mdna:98]
Our combined short-term and long-term investments decreased $56.8 million from $327.6 million at December 31, 2014 to $270.8 million at June 30,
2015. This decrease reflects the impact of our cash needs for capital expenditures, share repurchases, and dividends, as well as net realized and unrealized losses and amortization of net premiums on our combined investments, partially offset by
additional funds available for investment provided by our operating activities and stock option exercises by our employees.

[0001193125-15-278444:mdna:99]
We invest all available cash not required for immediate use in operations primarily in securities that we believe
bear minimal risk of loss. At June 30, 2015 these investments included corporate bonds of $114.4 million, municipal fixed-rate bonds of $67.4 million, and municipal variable rate demand notes of $3.7 million. At December 31, 2014, these
investments included corporate bonds of $111.3 million, municipal fixed-rate bonds of $127.8 million, and municipal variable rate demand notes of $2.5 million. As of June 30, 2015, our corporate bonds, municipal fixed-rate bonds, and municipal
variable rate demand notes were classified as available-for-sale and had a combined duration of 1.0 years with an average credit rating of A. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are
able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-15-278444:mdna:100]
Our
long-term investments decreased 22.8% from $280.6 million at December 31, 2014 to $216.7 million at June 30, 2015. Long-term investments at June 30, 2015 and December 31, 2014 included an investment in a certificate of deposit of
$30.0 million, which serves as collateral for our revenue bond, as discussed below. We have various equity investments included in long-term investments at a cost of $28.9 million and $26.4 million, and with a fair value of $37.3 million and $38.3
million, at June 30, 2015 and December 31, 2014, respectively.

[0001193125-15-278444:mdna:101]
Long-term investments at June 30, 2015 and December 31, 2014 also
included $16.5 million and $16.3 million, respectively, related to our deferred compensation plans, and $1.4 million and $1.5 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an
investment in a privately held telecommunications equipment manufacturer.

[0001193125-15-278444:mdna:102]
We review our investment portfolio for potential
“other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate
charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical
declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair
value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if
any. For the three and six months ended June 30, 2015 and 2014, other-than-temporary impairment charges were not significant.

[0001193125-15-278444:mdna:103]
Financing
Activities

[0001193125-15-278444:mdna:104]
[same as prior period, unchanged from 0001193125-15-173975:mdna:104]

[0001193125-15-278444:mdna:105]
In July 2003, our Board of
Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the six months ended June 30, 2015, we paid dividends totaling $9.5
million.

[0001193125-15-278444:mdna:106]
[same as prior period, unchanged from 0001193125-15-173975:mdna:106]

[0001193125-15-278444:mdna:107]
We have amounts outstanding
under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $30.0 million at June 30, 2015 and December 31, 2014. At June 30, 2015, the estimated fair value of the Bond was
approximately $29.9 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $30.0
million at June 30, 2015 and December 31, 2014, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the
indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of
payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our
intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.2 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at
June 30, 2015.

[0001193125-15-278444:mdna:108]
[same as prior period, unchanged from 0001193125-15-173975:mdna:108]

[0001193125-15-278444:mdna:109]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to
45.0 million shares of our common stock. This authorization will be implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2015, we repurchased 2.9 million
shares of our common stock at an average price of $16.87 per share. As of June 30, 2015, we have the authority to purchase an additional 1.9 million shares of our common stock under the current plans approved by the Board of Directors.

[0001193125-15-278444:mdna:110]
[same as prior period, unchanged from 0001193125-15-173975:mdna:110]

[0001193125-15-278444:mdna:111]
To accommodate employee
stock option exercises, we issued 0.1 million shares of treasury stock for $0.8 million during the six months ended June 30, 2015.

[0001193125-15-278444:mdna:112]
[same as prior period, unchanged from 0001193125-15-173975:mdna:112]

[0001193125-15-278444:mdna:113]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or
other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the six months ended June 30, 2015, there have been no material changes in contractual obligations and
commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2014 filed on February 24, 2015 with the SEC.

[0001193125-15-278444:mdna:114]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2015, of
which $7.7 million has been applied to these commitments.

[0001193125-15-278444:mdna:115]
[same as prior period, unchanged from 0001193125-15-173975:mdna:115]

[0001193125-15-278444:mdna:116]
[same as prior period, unchanged from 0001193125-15-173975:mdna:116]

[0001193125-15-278444:mdna:117]
[same as prior period, unchanged from 0001193125-15-173975:mdna:117]

[0001193125-15-278444:mdna:118]
[same as prior period, unchanged from 0001193125-15-173975:mdna:118]

[0001193125-15-278444:mdna:119]
[same as prior period, unchanged from 0001193125-15-173975:mdna:119]

[0001193125-15-278444:mdna:120]
[same as prior period, unchanged from 0001193125-15-173975:mdna:120]

[0001193125-15-278444:mdna:121]
[same as prior period, unchanged from 0001193125-15-173975:mdna:121]

[0001193125-15-278444:mdna:122]
[same as prior period, unchanged from 0001193125-15-173975:mdna:122]

[0001193125-15-278444:mdna:123]
[same as prior period, unchanged from 0001193125-15-173975:mdna:123]

[0001193125-15-278444:mdna:124]
[same as prior period, unchanged from 0001193125-15-173975:mdna:124]

[0001193125-15-278444:mdna:125]
[same as prior period, unchanged from 0001193125-15-173975:mdna:125]

[0001193125-15-278444:mdna:126]
[same as prior period, unchanged from 0001193125-15-173975:mdna:126]

[0001193125-15-278444:mdna:127]
[same as prior period, unchanged from 0001193125-15-173975:mdna:127]

[0001193125-15-278444:mdna:128]
[same as prior period, unchanged from 0001193125-15-173975:mdna:128]

[0001193125-15-278444:mdna:129]
[same as prior period, unchanged from 0001193125-15-173975:mdna:129]

[0001193125-15-278444:mdna:130]
[same as prior period, unchanged from 0001193125-15-173975:mdna:130]

[0001193125-15-278444:mdna:131]
[same as prior period, unchanged from 0001193125-15-173975:mdna:131]

[0001193125-15-278444:mdna:132]
[same as prior period, unchanged from 0001193125-15-173975:mdna:132]

[0001193125-15-278444:mdna:133]
[same as prior period, unchanged from 0001193125-15-173975:mdna:133]

[0001193125-15-278444:mdna:134]
[same as prior period, unchanged from 0001193125-15-173975:mdna:134]

[0001193125-15-278444:mdna:135]
[same as prior period, unchanged from 0001193125-15-173975:mdna:135]

[0001193125-15-278444:mdna:136]
[same as prior period, unchanged from 0001193125-15-173975:mdna:136]

[0001193125-15-278444:mdna:137]
[same as prior period, unchanged from 0001193125-15-173975:mdna:137]

[0001193125-15-278444:mdna:138]
[same as prior period, unchanged from 0001193125-15-173975:mdna:138]

[0001193125-15-278444:mdna:139]
[same as prior period, unchanged from 0001193125-15-173975:mdna:139]

[0001193125-15-278444:mdna:140]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-15-278444:mdna:141]
[same as prior period, unchanged from 0001193125-15-173975:mdna:141]

[0001193125-15-278444:mdna:142]
[same as prior period, unchanged from 0001193125-15-173975:mdna:142]

[0001193125-15-278444:mdna:143]
[same as prior period, unchanged from 0001193125-15-173975:mdna:144]

[0001193125-15-278444:mdna:144]
[same as prior period, unchanged from 0001193125-15-173975:mdna:145]

[0001193125-15-278444:mdna:145]
[same as prior period, unchanged from 0001193125-15-173975:mdna:146]

[0001193125-15-278444:mdna:146]
[same as prior period, unchanged from 0001193125-15-173975:mdna:147]

[0001193125-15-278444:mdna:147]
[same as prior period, unchanged from 0001193125-15-173975:mdna:148]

[0001193125-15-278444:mdna:148]
[same as prior period, unchanged from 0001193125-15-173975:mdna:149]

[0001193125-15-278444:mdna:149]
[same as prior period, unchanged from 0001193125-15-173975:mdna:150]

[0001193125-15-278444:mdna:150]
[same as prior period, unchanged from 0001193125-15-173975:mdna:151]

[0001193125-15-278444:mdna:151]
[same as prior period, unchanged from 0001193125-15-173975:mdna:152]
