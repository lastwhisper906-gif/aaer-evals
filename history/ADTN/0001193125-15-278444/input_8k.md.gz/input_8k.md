# ADTN 8-K — 0001193125-15-253068 filed 2015-07-15

## item codes, every 8-K on or before 2015-08-05

- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2015-08-05

- none on or before 2015-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-253068:8k_2_02:1]
EX-99.1
2
d48294dex991.htm
EX-99.1

[0001193125-15-253068:8k_2_02:2]
EX-99.1

[0001193125-15-253068:8k_2_02:3]
EXHIBIT 99.1

[0001193125-15-253068:8k_2_02:4]
ADTRAN, INC.

[0001193125-15-253068:8k_2_02:5]
REPORTS RESULTS for the SECOND QUARTER 2015 and DECLARES QUARTERLY CASH DIVIDEND

[0001193125-15-253068:8k_2_02:6]
HUNTSVILLE, Ala.—(BUSINESS WIRE)—July 14, 2015—ADTRAN, Inc. (NASDAQ:ADTN) reported results for the second quarter 2015. For the quarter,
sales were $160,138,000 compared to $176,129,000 for the second quarter of 2014. Net income was $2,544,000 compared to $14,395,000 for the second quarter of 2014. Earnings per share, assuming dilution, were $0.05 compared to $0.26 for the second
quarter of 2014. Non-GAAP earnings per share were $0.10 compared to $0.30 for the second quarter of 2014. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-15-253068:8k_2_02:7]
ADTRAN Chief Executive Officer Tom Stanton stated, “Revenue for the quarter came in higher than expected, driven by the timing of CAF-related orders in
our domestic business. EPS on a GAAP basis was reduced due to one-time restructuring charges as we continue to focus our company on the opportunities that are ahead. During the quarter, we saw an increase in broadband infrastructure activity in our
domestic markets as carriers seek to position themselves competitively and utilize CAF funding to accelerate their deployment plans.”

[0001193125-15-253068:8k_2_02:8]
The Company
also announced that its Board of Directors declared a cash dividend for the second quarter of 2015. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on July 30, 2015. The ex-dividend
date is July 28, 2015 and the payment date is August 13, 2015.

[0001193125-15-253068:8k_2_02:9]
The Company confirmed that its second quarter conference call will be held
Wednesday, July 15, 2015 at 9:30 a.m. Central Time. This conference call will be web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately
10 minutes prior to the start of the call and click on the conference call link provided.

[0001193125-15-253068:8k_2_02:10]
An online replay of the conference call will be available for
seven days at www.streetevents.com. In addition, an online replay of the conference call, as well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12
months following the call.

[0001193125-15-253068:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice,
data, video and Internet communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more
information, please visit www.adtran.com.

[0001193125-15-253068:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at
info@adtran.com. On the Web, visit www.adtran.com.

[0001193125-15-253068:8k_2_02:13]
This press release contains forward-looking statements which reflect management’s
best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the
product and channel mix, component costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2014 and on Form 10-Q for the quarter ended March 31, 2015. These risks and
uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001193125-15-253068:8k_2_02:14]
| CONTACT: Michael Foliano Senior Vice President & Interim CFO 256-963-8885 |  | INVESTOR SERVICES/ASSISTANCE: Gayle Ellis Investor Services 256-963-8220 |

[0001193125-15-253068:8k_2_02:15]
Condensed Consolidated Balance Sheet

[0001193125-15-253068:8k_2_02:16]
(Unaudited)

[0001193125-15-253068:8k_2_02:17]
(In
thousands)

[0001193125-15-253068:8k_2_02:18]
|  |  | June 30,2015 |  |  | December 31,2014 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 87,215 |  |  | $ | 73,439 |  |
| Short-term investments |  |  | 54,127 |  |  |  | 46,919 |  |
| Accounts receivable, net |  |  | 89,088 |  |  |  | 88,502 |  |
| Other receivables |  |  | 31,442 |  |  |  | 33,295 |  |
| Inventory |  |  | 100,048 |  |  |  | 86,710 |  |
| Prepaid expenses |  |  | 5,817 |  |  |  | 5,129 |  |
| Deferred tax assets, net |  |  | 17,038 |  |  |  | 17,095 |  |
| Total Current Assets |  |  | 384,775 |  |  |  | 351,089 |  |
| Property, plant and equipment, net |  |  | 73,347 |  |  |  | 74,828 |  |
| Deferred tax assets, net |  |  | 20,473 |  |  |  | 17,694 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 10,236 |  |  |  | 10,942 |  |
| Long-term investments |  |  | 216,665 |  |  |  | 280,649 |  |
| Total Assets |  | $ | 708,988 |  |  | $ | 738,694 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 85,456 |  |  | $ | 56,414 |  |
| Unearned revenue |  |  | 17,495 |  |  |  | 22,762 |  |
| Accrued expenses |  |  | 15,538 |  |  |  | 11,077 |  |
| Accrued wages and benefits |  |  | 15,515 |  |  |  | 13,855 |  |
| Income tax payable, net |  |  | 10,072 |  |  |  | 14,901 |  |
| Total Current Liabilities |  |  | 144,076 |  |  |  | 119,009 |  |
| Non-current unearned revenue |  |  | 9,444 |  |  |  | 10,948 |  |
| Other non-current liabilities |  |  | 31,268 |  |  |  | 30,924 |  |
| Bonds payable |  |  | 28,800 |  |  |  | 28,800 |  |
| Total Liabilities |  |  | 213,588 |  |  |  | 189,681 |  |
| Stockholders’ Equity |  |  | 495,400 |  |  |  | 549,013 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 708,988 |  |  | $ | 738,694 |  |

[0001193125-15-253068:8k_2_02:19]
Consolidated Statements of Income

[0001193125-15-253068:8k_2_02:20]
(Unaudited)

[0001193125-15-253068:8k_2_02:21]
(In
thousands, except per share data)

[0001193125-15-253068:8k_2_02:22]
|  |  | Three Months EndedJune 30, |  |  | Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Sales |  | $ | 160,138 |  |  | $ | 176,129 |  |  | $ | 302,973 |  |  | $ | 323,133 |  |
| Cost of sales |  |  | 91,892 |  |  |  | 89,332 |  |  |  | 169,164 |  |  |  | 158,546 |  |
| Gross Profit |  |  | 68,246 |  |  |  | 86,797 |  |  |  | 133,809 |  |  |  | 164,587 |  |
| Selling, general and administrative expenses |  |  | 32,123 |  |  |  | 33,788 |  |  |  | 63,187 |  |  |  | 67,727 |  |
| Research and development expenses |  |  | 35,479 |  |  |  | 33,670 |  |  |  | 68,015 |  |  |  | 66,223 |  |
| Operating Income |  |  | 644 |  |  |  | 19,339 |  |  |  | 2,607 |  |  |  | 30,637 |  |
| Interest and dividend income |  |  | 908 |  |  |  | 1,054 |  |  |  | 1,841 |  |  |  | 2,348 |  |
| Interest expense |  |  | (149 | ) |  |  | (148 | ) |  |  | (297 | ) |  |  | (375 | ) |
| Net realized investment gain |  |  | 3,255 |  |  |  | 2,340 |  |  |  | 6,370 |  |  |  | 4,532 |  |
| Other income (expense), net |  |  | (547 | ) |  |  | (774 | ) |  |  | (900 | ) |  |  | (652 | ) |
| Income before provision for income taxes |  |  | 4,111 |  |  |  | 21,811 |  |  |  | 9,621 |  |  |  | 36,490 |  |
| Provision for income taxes |  |  | (1,567 | ) |  |  | (7,416 | ) |  |  | (3,760 | ) |  |  | (12,488 | ) |
| Net Income |  | $ | 2,544 |  |  | $ | 14,395 |  |  | $ | 5,861 |  |  | $ | 24,002 |  |
| Weighted average shares outstanding - basic |  |  | 51,822 |  |  |  | 55,409 |  |  |  | 52,607 |  |  |  | 56,077 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 51,917 |  |  |  | 55,729 |  |  |  | 52,742 |  |  |  | 56,559 |  |
| Earnings per common share - basic |  | $ | 0.05 |  |  | $ | 0.26 |  |  | $ | 0.11 |  |  | $ | 0.43 |  |
| Earnings per common share - diluted (1) |  | $ | 0.05 |  |  | $ | 0.26 |  |  | $ | 0.11 |  |  | $ | 0.42 |  |

[0001193125-15-253068:8k_2_02:23]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001193125-15-253068:8k_2_02:24]
Consolidated Statements of Comprehensive Income

[0001193125-15-253068:8k_2_02:25]
(Unaudited)

[0001193125-15-253068:8k_2_02:26]
(In
thousands)

[0001193125-15-253068:8k_2_02:27]
|  |  | Three Months EndedJune 30, |  |  | Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net Income |  | $ | 2,544 |  |  | $ | 14,395 |  |  | $ | 5,861 |  |  | $ | 24,002 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | (1,783 | ) |  |  | 1,219 |  |  |  | (2,286 | ) |  |  | 298 |  |
| Defined benefit plan adjustments |  |  | 72 |  |  |  | — |  |  |  | 140 |  |  |  | — |  |
| Foreign currency translation |  |  | 872 |  |  |  | 134 |  |  |  | (2,446 | ) |  |  | 386 |  |
| Other Comprehensive Income (Loss), net of tax |  |  | (839 | ) |  |  | 1,353 |  |  |  | (4,592 | ) |  |  | 684 |  |
| Comprehensive Income, net of tax |  | $ | 1,705 |  |  | $ | 15,748 |  |  | $ | 1,269 |  |  | $ | 24,686 |  |

[0001193125-15-253068:8k_2_02:28]
Consolidated Statements of Cash Flows

[0001193125-15-253068:8k_2_02:29]
(Unaudited)

[0001193125-15-253068:8k_2_02:30]
(In
thousands)

[0001193125-15-253068:8k_2_02:31]
|  |  | Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 5,861 |  |  | $ | 24,002 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 7,256 |  |  |  | 7,467 |  |
| Amortization of net premium on available-for-sale investments |  |  | 1,578 |  |  |  | 2,272 |  |
| Net realized gain on long-term investments |  |  | (6,370 | ) |  |  | (4,532 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 160 |  |  |  | 37 |  |
| Stock-based compensation expense |  |  | 3,114 |  |  |  | 4,149 |  |
| Deferred income taxes |  |  | (1,743 | ) |  |  | 377 |  |
| Tax benefit from stock option exercises |  |  | (23 | ) |  |  | 67 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | 38 |  |  |  | (58 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (2,003 | ) |  |  | (31,583 | ) |
| Other receivables |  |  | (119 | ) |  |  | (4,072 | ) |
| Inventory |  |  | (14,254 | ) |  |  | 841 |  |
| Prepaid expenses and other assets |  |  | (1,433 | ) |  |  | (3,103 | ) |
| Accounts payable |  |  | 30,938 |  |  |  | 14,425 |  |
| Accrued expenses and other liabilities |  |  | 2,175 |  |  |  | 8,248 |  |
| Income tax payable, net |  |  | (3,961 | ) |  |  | 4,442 |  |
| Net cash provided by operating activities |  |  | 21,214 |  |  |  | 22,979 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (5,392 | ) |  |  | (4,919 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 8 |  |  |  | 1 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 120,422 |  |  |  | 166,518 |  |
| Purchases of available-for-sale investments |  |  | (62,626 | ) |  |  | (106,406 | ) |
| Net cash provided by investing activities |  |  | 52,412 |  |  |  | 55,194 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 833 |  |  |  | 1,781 |  |
| Purchases of treasury stock |  |  | (49,307 | ) |  |  | (53,091 | ) |
| Dividend payments |  |  | (9,509 | ) |  |  | (10,137 | ) |
| Payments on long-term debt |  |  | — |  |  |  | (16,500 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | (38 | ) |  |  | 58 |  |
| Net cash used in financing activities |  |  | (58,021 | ) |  |  | (77,889 | ) |
| Net increase in cash and cash equivalents |  |  | 15,605 |  |  |  | 284 |  |
| Effect of exchange rate changes |  |  | (1,829 | ) |  |  | 321 |  |
| Cash and cash equivalents, beginning of period |  |  | 73,439 |  |  |  | 58,298 |  |
| Cash and cash equivalents, end of period |  | $ | 87,215 |  |  | $ | 58,903 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 270 |  |  | $ | 423 |  |

[0001193125-15-253068:8k_2_02:32]
Supplemental Information

[0001193125-15-253068:8k_2_02:33]
Restructuring Expenses

[0001193125-15-253068:8k_2_02:34]
(Unaudited)

[0001193125-15-253068:8k_2_02:35]
(In
thousands)

[0001193125-15-253068:8k_2_02:36]
Restructuring expenses were recorded in the following Consolidated Statements of Income categories for the three and six months ended
June 30, 2015 and 2014:

[0001193125-15-253068:8k_2_02:37]
|  |  | Three and Six MonthsEnded June 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Restructuring expense included in cost of sales |  | $ | 98 |  |  | $ | — |  |
| Selling, general and administrative expense |  |  | 644 |  |  |  | — |  |
| Research and development expense |  |  | 1,383 |  |  |  | — |  |
| Restructuring expense included in operating expenses |  |  | 2,027 |  |  |  | — |  |
| Total restructuring expense |  |  | 2,125 |  |  |  | — |  |
| Provision for income taxes |  |  | (829 | ) |  |  | — |  |
| Total restructuring expense, net of tax |  | $ | 1,296 |  |  | $ | — |  |

[0001193125-15-253068:8k_2_02:38]
Supplemental Information

[0001193125-15-253068:8k_2_02:39]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-15-253068:8k_2_02:40]
(Unaudited)

[0001193125-15-253068:8k_2_02:41]
(In
thousands)

[0001193125-15-253068:8k_2_02:42]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the
Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and six months ended June 30, 2015 and 2014 for both transactions are as follows:

[0001193125-15-253068:8k_2_02:43]
|  |  | Three Months EndedJune 30, |  |  | Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 226 |  |  | $ | 226 |  |  | $ | 452 |  |  | $ | 472 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 229 |  |  |  | 295 |  |  |  | 470 |  |  |  | 597 |  |
| Amortization of other purchase accounting adjustments |  |  | 140 |  |  |  | 294 |  |  |  | 294 |  |  |  | 655 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 35 |  |  |  | 17 |  |  |  | 41 |  |  |  | 65 |  |
| Subtotal |  |  | 404 |  |  |  | 606 |  |  |  | 805 |  |  |  | 1,317 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 630 |  |  |  | 832 |  |  |  | 1,257 |  |  |  | 1,789 |  |
| Provision for income taxes |  |  | (213 | ) |  |  | (276 | ) |  |  | (426 | ) |  |  | (592 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 417 |  |  | $ | 556 |  |  | $ | 831 |  |  | $ | 1,197 |  |

[0001193125-15-253068:8k_2_02:44]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three and six months ended June 30, 2015 and 2014:

[0001193125-15-253068:8k_2_02:45]
|  |  | Three Months EndedJune 30, |  |  | Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 64 |  |  | $ | 180 |  |  | $ | 131 |  |  | $ | 423 |  |
| Cost of goods sold |  |  | 33 |  |  |  | 23 |  |  |  | 45 |  |  |  | 57 |  |
| Subtotal |  |  | 97 |  |  |  | 203 |  |  |  | 176 |  |  |  | 480 |  |
| Selling, general and administrative expenses |  |  | 39 |  |  |  | 24 |  |  |  | 51 |  |  |  | 79 |  |
| Research and development expenses |  |  | 494 |  |  |  | 605 |  |  |  | 1,030 |  |  |  | 1,230 |  |
| Subtotal |  |  | 533 |  |  |  | 629 |  |  |  | 1,081 |  |  |  | 1,309 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 630 |  |  |  | 832 |  |  |  | 1,257 |  |  |  | 1,789 |  |
| Provision for income taxes |  |  | (213 | ) |  |  | (276 | ) |  |  | (426 | ) |  |  | (592 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 417 |  |  | $ | 556 |  |  | $ | 831 |  |  | $ | 1,197 |  |

[0001193125-15-253068:8k_2_02:46]
Supplemental Information

[0001193125-15-253068:8k_2_02:47]
Stock-based Compensation Expense

[0001193125-15-253068:8k_2_02:48]
(Unaudited)

[0001193125-15-253068:8k_2_02:49]
(In
thousands)

[0001193125-15-253068:8k_2_02:50]
|  |  | Three Months EndedJune 30, |  |  | Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 53 |  |  | $ | 119 |  |  | $ | 143 |  |  | $ | 235 |  |
| Selling, general and administrative expense |  |  | 723 |  |  |  | 1,015 |  |  |  | 1,414 |  |  |  | 2,041 |  |
| Research and development expense |  |  | 699 |  |  |  | 958 |  |  |  | 1,557 |  |  |  | 1,873 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,422 |  |  |  | 1,973 |  |  |  | 2,971 |  |  |  | 3,914 |  |
| Total stock-based compensation expense |  |  | 1,475 |  |  |  | 2,092 |  |  |  | 3,114 |  |  |  | 4,149 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (222 | ) |  |  | (296 | ) |  |  | (402 | ) |  |  | (580 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,253 |  |  | $ | 1,796 |  |  | $ | 2,712 |  |  | $ | 3,569 |  |

[0001193125-15-253068:8k_2_02:51]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-15-253068:8k_2_02:52]
Non-GAAP net income per share, diluted

[0001193125-15-253068:8k_2_02:53]
(Unaudited)

[0001193125-15-253068:8k_2_02:54]
|  |  | Three Months EndedJune 30, |  |  | Six Months EndedJune 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| GAAP earnings per common share – diluted |  | $ | 0.05 |  |  | $ | 0.26 |  |  | $ | 0.11 |  |  | $ | 0.42 |  |
| Restructuring expense |  |  | 0.02 |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.02 |  |
| Stock-based compensation expense |  |  | 0.02 |  |  |  | 0.03 |  |  |  | 0.05 |  |  |  | 0.06 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.10 |  |  | $ | 0.30 |  |  | $ | 0.20 |  |  | $ | 0.50 |  |
