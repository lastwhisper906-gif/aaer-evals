# ADTN 8-K — 0001193125-14-269660 filed 2014-07-16

## item codes, every 8-K on or before 2014-08-06

- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2014-08-06

- none on or before 2014-08-06

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-269660:8k_2_02:1]
EX-99.1
2
d754694dex991.htm
EXHIBIT 99.1

[0001193125-14-269660:8k_2_02:2]
Exhibit 99.1

[0001193125-14-269660:8k_2_02:3]
Exhibit 99.1

[0001193125-14-269660:8k_2_02:4]
ADTRAN, INC.

[0001193125-14-269660:8k_2_02:5]
REPORTS RESULTS for the SECOND QUARTER 2014 and DECLARES QUARTERLY CASH DIVIDEND

[0001193125-14-269660:8k_2_02:6]
HUNTSVILLE, Ala.—(BUSINESS WIRE)—July 15, 2014—ADTRAN, Inc. (NASDAQ:ADTN) reported results for the second quarter 2014. For the quarter, sales
were $176,129,000 compared to $162,233,000 for the second quarter of 2013. Operating income was $19,339,000 compared to $14,053,000 for the second quarter of 2013. Net income was $14,395,000 compared to $9,859,000 for the second quarter of 2013.
Earnings per share, assuming dilution, were $0.26 compared to $0.17 for the second quarter of 2013. Non-GAAP earnings per share were $0.30 compared to $0.21 for the second quarter of 2013. The reconciliation between GAAP earnings per share, diluted,
and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-14-269660:8k_2_02:7]
ADTRAN Chief Executive Officer Tom Stanton stated, “Our long stated goal of
geographic diversification continued to pay dividends in the second quarter as international revenues reached a record $79 million. This strength drove our Broadband Access category to achieve record revenues, growing 33% over the same period last
year. Operating income increased 38% over the same period last year.”

[0001193125-14-269660:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash
dividend for the second quarter of 2014. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on July 31, 2014. The ex-dividend date is July 29, 2014 and the payment date is
August 14, 2014.

[0001193125-14-269660:8k_2_02:9]
The Company confirmed that its second quarter conference call will be held Wednesday, July 16, 2014, at 9:30 a.m. Central
Time. This conference call will be web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the call and click on the
conference call link provided.

[0001193125-14-269660:8k_2_02:10]
An online replay of the conference call will be available for seven days at www.streetevents.com. In addition, an online
replay of the conference call, as well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following the call.

[0001193125-14-269660:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet
communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit
www.adtran.com.

[0001193125-14-269660:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web, visit
www.adtran.com.

[0001193125-14-269660:8k_2_02:13]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known.
However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs,
manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2013 and on Form 10-Q for the quarter ended March 31, 2014. These risks and uncertainties could cause actual results to
differ materially from those in the forward-looking statements included in this press release.

[0001193125-14-269660:8k_2_02:14]
| CONTACT: |  | INVESTOR SERVICES/ASSISTANCE: |
| Jim Matthews Senior Vice President/CFO 256-963-8775 |  | Gayle Ellis 256-963-8220 |

[0001193125-14-269660:8k_2_02:15]
Condensed Consolidated Balance Sheet

[0001193125-14-269660:8k_2_02:16]
(Unaudited)

[0001193125-14-269660:8k_2_02:17]
(In
thousands)

[0001193125-14-269660:8k_2_02:18]
|  |  | June 30,2014 |  |  | December 31,2013 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 58,903 |  |  | $ | 58,298 |  |
| Short-term investments |  |  | 45,930 |  |  |  | 105,760 |  |
| Accounts receivable, net |  |  | 115,538 |  |  |  | 85,814 |  |
| Other receivables |  |  | 23,841 |  |  |  | 18,249 |  |
| Inventory |  |  | 89,239 |  |  |  | 90,111 |  |
| Prepaid expenses |  |  | 5,295 |  |  |  | 4,325 |  |
| Deferred tax assets, net |  |  | 15,054 |  |  |  | 17,083 |  |
| Total Current Assets |  |  | 353,800 |  |  |  | 379,640 |  |
| Property, plant and equipment, net |  |  | 75,265 |  |  |  | 76,739 |  |
| Deferred tax assets, net |  |  | 11,092 |  |  |  | 9,622 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 12,087 |  |  |  | 11,180 |  |
| Long-term investments |  |  | 311,622 |  |  |  | 309,225 |  |
| Total Assets |  | $ | 767,358 |  |  | $ | 789,898 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 62,103 |  |  | $ | 48,282 |  |
| Unearned revenue |  |  | 26,364 |  |  |  | 22,205 |  |
| Accrued expenses |  |  | 11,865 |  |  |  | 12,776 |  |
| Accrued wages and benefits |  |  | 15,930 |  |  |  | 14,040 |  |
| Income tax payable, net |  |  | 9,400 |  |  |  | 5,002 |  |
| Total Current Liabilities |  |  | 125,662 |  |  |  | 102,305 |  |
| Non-current unearned revenue |  |  | 15,213 |  |  |  | 14,643 |  |
| Other non-current liabilities |  |  | 24,424 |  |  |  | 22,144 |  |
| Bonds payable |  |  | 30,000 |  |  |  | 46,200 |  |
| Total Liabilities |  |  | 195,299 |  |  |  | 185,292 |  |
| Stockholders’ Equity |  |  | 572,059 |  |  |  | 604,606 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 767,358 |  |  | $ | 789,898 |  |

[0001193125-14-269660:8k_2_02:19]
Consolidated Statements of Income

[0001193125-14-269660:8k_2_02:20]
(Unaudited)

[0001193125-14-269660:8k_2_02:21]
(In
thousands, except per share data)

[0001193125-14-269660:8k_2_02:22]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Sales |  | $ | 176,129 |  |  | $ | 162,233 |  |  | $ | 323,133 |  |  | $ | 305,246 |  |
| Cost of sales |  |  | 89,332 |  |  |  | 82,435 |  |  |  | 158,546 |  |  |  | 155,771 |  |
| Gross Profit |  |  | 86,797 |  |  |  | 79,798 |  |  |  | 164,587 |  |  |  | 149,475 |  |
| Selling, general and administrative expenses |  |  | 33,788 |  |  |  | 32,685 |  |  |  | 67,727 |  |  |  | 63,288 |  |
| Research and development expenses |  |  | 33,670 |  |  |  | 33,060 |  |  |  | 66,223 |  |  |  | 65,571 |  |
| Operating Income |  |  | 19,339 |  |  |  | 14,053 |  |  |  | 30,637 |  |  |  | 20,616 |  |
| Interest and dividend income |  |  | 1,054 |  |  |  | 1,674 |  |  |  | 2,348 |  |  |  | 3,442 |  |
| Interest expense |  |  | (148 | ) |  |  | (575 | ) |  |  | (375 | ) |  |  | (1,156 | ) |
| Net realized investment gain |  |  | 2,340 |  |  |  | 1,553 |  |  |  | 4,532 |  |  |  | 5,198 |  |
| Other income (expense), net |  |  | (774 | ) |  |  | 129 |  |  |  | (652 | ) |  |  | (1,543 | ) |
| Income before provision for income taxes |  |  | 21,811 |  |  |  | 16,834 |  |  |  | 36,490 |  |  |  | 26,557 |  |
| Provision for income taxes |  |  | (7,416 | ) |  |  | (6,975 | ) |  |  | (12,488 | ) |  |  | (8,808 | ) |
| Net Income |  | $ | 14,395 |  |  | $ | 9,859 |  |  | $ | 24,002 |  |  | $ | 17,749 |  |
| Weighted average shares outstanding – basic |  |  | 55,409 |  |  |  | 59,056 |  |  |  | 56,077 |  |  |  | 60,443 |  |
| Weighted average shares outstanding – diluted (1) |  |  | 55,729 |  |  |  | 59,311 |  |  |  | 56,559 |  |  |  | 60,660 |  |
| Earnings per common share – basic |  | $ | 0.26 |  |  | $ | 0.17 |  |  | $ | 0.43 |  |  | $ | 0.29 |  |
| Earnings per common share – diluted (1) |  | $ | 0.26 |  |  | $ | 0.17 |  |  | $ | 0.42 |  |  | $ | 0.29 |  |

[0001193125-14-269660:8k_2_02:23]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001193125-14-269660:8k_2_02:24]
Consolidated Statements of Comprehensive Income

[0001193125-14-269660:8k_2_02:25]
(Unaudited)

[0001193125-14-269660:8k_2_02:26]
(In
thousands)

[0001193125-14-269660:8k_2_02:27]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net Income |  | $ | 14,395 |  |  | $ | 9,859 |  |  | $ | 24,002 |  |  | $ | 17,749 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | 1,219 |  |  |  | (1,698 | ) |  |  | 298 |  |  |  | (3,342 | ) |
| Foreign currency translation |  |  | 134 |  |  |  | (1,713 | ) |  |  | 386 |  |  |  | (1,390 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  | 1,353 |  |  |  | (3,411 | ) |  |  | 684 |  |  |  | (4,732 | ) |
| Comprehensive Income, net of tax |  | $ | 15,748 |  |  | $ | 6,448 |  |  | $ | 24,686 |  |  | $ | 13,017 |  |

[0001193125-14-269660:8k_2_02:28]
Consolidated Statements of Cash Flows

[0001193125-14-269660:8k_2_02:29]
(Unaudited)

[0001193125-14-269660:8k_2_02:30]
(In
thousands)

[0001193125-14-269660:8k_2_02:31]
|  |  | Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 24,002 |  |  | $ | 17,749 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 7,467 |  |  |  | 7,373 |  |
| Amortization of net premium on available-for-sale investments |  |  | 2,272 |  |  |  | 3,315 |  |
| Net realized gain on long-term investments |  |  | (4,532 | ) |  |  | (5,198 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 37 |  |  |  | 17 |  |
| Stock-based compensation expense |  |  | 4,149 |  |  |  | 4,340 |  |
| Deferred income taxes |  |  | 377 |  |  |  | 150 |  |
| Tax benefit from stock option exercises |  |  | 67 |  |  |  | 21 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (58 | ) |  |  | (21 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (29,949 | ) |  |  | (23,018 | ) |
| Other receivables |  |  | (5,706 | ) |  |  | (2,727 | ) |
| Inventory |  |  | 841 |  |  |  | 13,336 |  |
| Prepaid expenses and other assets |  |  | (3,103 | ) |  |  | (665 | ) |
| Accounts payable |  |  | 14,425 |  |  |  | 19,786 |  |
| Accrued expenses and other liabilities |  |  | 8,248 |  |  |  | (6,587 | ) |
| Income tax payable, net |  |  | 4,442 |  |  |  | 1,094 |  |
| Net cash provided by operating activities |  |  | 22,979 |  |  |  | 28,965 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (4,919 | ) |  |  | (3,201 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 1 |  |  |  | — |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 166,518 |  |  |  | 224,163 |  |
| Purchases of available-for-sale investments |  |  | (106,406 | ) |  |  | (179,730 | ) |
| Net cash provided by investing activities |  |  | 55,194 |  |  |  | 41,232 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 1,781 |  |  |  | 819 |  |
| Purchases of treasury stock |  |  | (53,091 | ) |  |  | (89,917 | ) |
| Dividend payments |  |  | (10,137 | ) |  |  | (10,982 | ) |
| Payments on long-term debt |  |  | (16,500 | ) |  |  | — |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | 58 |  |  |  | 21 |  |
| Net cash used in financing activities |  |  | (77,889 | ) |  |  | (100,059 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 284 |  |  |  | (29,862 | ) |
| Effect of exchange rate changes |  |  | 321 |  |  |  | (1,036 | ) |
| Cash and cash equivalents, beginning of period |  |  | 58,298 |  |  |  | 68,457 |  |
| Cash and cash equivalents, end of period |  | $ | 58,903 |  |  | $ | 37,559 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 423 |  |  | $ | 574 |  |

[0001193125-14-269660:8k_2_02:32]
Supplemental Information

[0001193125-14-269660:8k_2_02:33]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-14-269660:8k_2_02:34]
(Unaudited)

[0001193125-14-269660:8k_2_02:35]
(In
thousands)

[0001193125-14-269660:8k_2_02:36]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the
Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and six months ended June 30, 2014 and 2013 for both transactions are as follows:

[0001193125-14-269660:8k_2_02:37]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 226 |  |  | $ | 287 |  |  | $ | 472 |  |  | $ | 580 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 295 |  |  |  | 288 |  |  |  | 597 |  |  |  | 582 |  |
| Amortization of other purchase accounting adjustments |  |  | 294 |  |  |  | 342 |  |  |  | 655 |  |  |  | 752 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 17 |  |  |  | 82 |  |  |  | 65 |  |  |  | 236 |  |
| Subtotal |  |  | 606 |  |  |  | 712 |  |  |  | 1,317 |  |  |  | 1,570 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 832 |  |  |  | 999 |  |  |  | 1,789 |  |  |  | 2,150 |  |
| Provision for income taxes |  |  | (276 | ) |  |  | (333 | ) |  |  | (592 | ) |  |  | (713 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 556 |  |  | $ | 666 |  |  | $ | 1,197 |  |  | $ | 1,437 |  |

[0001193125-14-269660:8k_2_02:38]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three and six months ended June 30, 2014 and 2013:

[0001193125-14-269660:8k_2_02:39]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 180 |  |  | $ | 235 |  |  | $ | 423 |  |  | $ | 497 |  |
| Cost of goods sold |  |  | 23 |  |  |  | 64 |  |  |  | 57 |  |  |  | 151 |  |
| Subtotal |  |  | 203 |  |  |  | 299 |  |  |  | 480 |  |  |  | 648 |  |
| Selling, general and administrative expenses |  |  | 24 |  |  |  | 113 |  |  |  | 79 |  |  |  | 274 |  |
| Research and development expenses |  |  | 605 |  |  |  | 587 |  |  |  | 1,230 |  |  |  | 1,228 |  |
| Subtotal |  |  | 629 |  |  |  | 700 |  |  |  | 1,309 |  |  |  | 1,502 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 832 |  |  |  | 999 |  |  |  | 1,789 |  |  |  | 2,150 |  |
| Provision for income taxes |  |  | (276 | ) |  |  | (333 | ) |  |  | (592 | ) |  |  | (713 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 556 |  |  | $ | 666 |  |  | $ | 1,197 |  |  | $ | 1,437 |  |

[0001193125-14-269660:8k_2_02:40]
Supplemental Information

[0001193125-14-269660:8k_2_02:41]
Stock-based Compensation Expense

[0001193125-14-269660:8k_2_02:42]
(Unaudited)

[0001193125-14-269660:8k_2_02:43]
(In
thousands)

[0001193125-14-269660:8k_2_02:44]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 119 |  |  | $ | 110 |  |  | $ | 235 |  |  | $ | 216 |  |
| Selling, general and administrative expense |  |  | 1,015 |  |  |  | 1,042 |  |  |  | 2,041 |  |  |  | 2,105 |  |
| Research and development expense |  |  | 958 |  |  |  | 956 |  |  |  | 1,873 |  |  |  | 2,019 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,973 |  |  |  | 1,998 |  |  |  | 3,914 |  |  |  | 4,124 |  |
| Total stock-based compensation expense |  |  | 2,092 |  |  |  | 2,108 |  |  |  | 4,149 |  |  |  | 4,340 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (296 | ) |  |  | (310 | ) |  |  | (580 | ) |  |  | (617 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,796 |  |  | $ | 1,798 |  |  | $ | 3,569 |  |  | $ | 3,723 |  |

[0001193125-14-269660:8k_2_02:45]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-14-269660:8k_2_02:46]
Non-GAAP net income per share, diluted

[0001193125-14-269660:8k_2_02:47]
(Unaudited)

[0001193125-14-269660:8k_2_02:48]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| GAAP earnings per common share – diluted |  | $ | 0.26 |  |  | $ | 0.17 |  |  | $ | 0.42 |  |  | $ | 0.29 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.02 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.06 |  |  |  | 0.06 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.30 |  |  | $ | 0.21 |  |  | $ | 0.50 |  |  | $ | 0.37 |  |
