# ADTN notes — 0001193125-14-297927


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-297927:notes:1]
15. COMMITMENTS AND CONTINGENCIES

[0001193125-14-297927:notes:2]
In the ordinary course of business, we may be subject to various
 legal proceedings and claims, including employment disputes, patent
 claims, disputes over contract agreements and other commercial
 disputes. In some cases, claimants seek damages or other relief,
 such as royalty payments related to patents, which, if granted,
 could require significant expenditures. Although the outcome of any
 claim or litigation can never be certain, it is our opinion that
 the outcome of all contingencies of which we are currently aware
 will not materially affect our business, operations, financial
 condition or cash flows.

[0001193125-14-297927:notes:3]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of June 30, 2014, of which $7.7 million has been applied to
 these commitments.


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-297927:notes:4]
11. EARNINGS PER SHARE

[0001193125-14-297927:notes:5]
A summary of the calculation of basic and diluted earnings per
 share for the three and six months ended June 30, 2014 and
 2013 is as follows:

[0001193125-14-297927:notes:6]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands, except per share amounts) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 14,395 |  |  | $ | 9,859 |  |  | $ | 24,002 |  |  | $ | 17,749 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 55,409 |  |  |  | 59,056 |  |  |  | 56,077 |  |  |  | 60,443 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 288 |  |  |  | 209 |  |  |  | 459 |  |  |  | 177 |  |
| Restricted stock and restricted stock units |  |  | 32 |  |  |  | 46 |  |  |  | 23 |  |  |  | 40 |  |
| Weighted average number of shares – diluted |  |  | 55,729 |  |  |  | 59,311 |  |  |  | 56,559 |  |  |  | 60,660 |  |
| Net income per share – basic |  | $ | 0.26 |  |  | $ | 0.17 |  |  | $ | 0.43 |  |  | $ | 0.29 |  |
| Net income per share – diluted |  | $ | 0.26 |  |  | $ | 0.17 |  |  | $ | 0.42 |  |  | $ | 0.29 |  |

[0001193125-14-297927:notes:7]
Anti-dilutive options to purchase common stock outstanding were
 excluded from the above calculations. Anti-dilutive options totaled
 4.3 million for the three months ended June 30, 2014 and
 2013, and 3.1 million and 5.1 million for the six months
 ended June 30, 2014 and 2013, respectively.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001193125-14-297927:notes:8]
We evaluate the carrying value of goodwill during the fourth
 quarter of each year and between annual evaluations if events occur
 or circumstances change that would more likely than not reduce the
 fair value of the reporting unit below its carrying amount. When
 evaluating whether goodwill is impaired, we compare the fair value
 of the reporting unit to which the goodwill is assigned to the
 reporting unit’s carrying amount, including goodwill. If the
 carrying amount of the reporting unit exceeds its fair value, then
 the amount of the impairment loss is measured.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001193125-14-297927:notes:9]
The weighted-average assumptions and value of options granted for
 the six months ended June 30, 2014 are summarized as
 follows:

[0001193125-14-297927:notes:10]
|  |  | Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  |
| Expected volatility |  |  | 39.57 | % |
| Risk-free interest rate |  |  | 1.86 | % |
| Expected dividend yield |  |  | 1.38 | % |
| Expected life (in years) |  |  | 6.25 |  |
| Weighted-average estimated value |  | $ | 9.28 |  |


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001193125-14-297927:notes:11]
Other Comprehensive Income

[0001193125-14-297927:notes:12]
Other comprehensive income consists of unrealized gains (losses) on
 available-for-sale securities, reclassification adjustments for
 amounts included in net income related to impairments of
 available-for-sale securities and realized gains (losses) on
 available-for-sale securities, defined benefit plan adjustments and
 foreign currency translation adjustments.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-14-297927:notes:13]
[same as prior period, unchanged from 0001193125-14-187120:notes:77]

[0001193125-14-297927:notes:14]
|  |  | Fair Value Measurements at June 30, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 11,737 |  |  | $ | 11,737 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,755 |  |  |  | 15,755 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 99,391 |  |  |  | — |  |  |  | 99,391 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 155,982 |  |  |  | — |  |  |  | 155,982 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 15,120 |  |  |  | — |  |  |  | 15,120 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 12,085 |  |  |  | 12,085 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 27,642 |  |  |  | 27,642 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 325,975 |  |  |  | 55,482 |  |  |  | 270,493 |  |  |  | — |  |
| Total |  | $ | 337,712 |  |  | $ | 67,219 |  |  | $ | 270,493 |  |  | $ | — |  |

[0001193125-14-297927:notes:15]
|  |  | Fair Value Measurements at December 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,949 |  |  | $ | 3,949 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,123 |  |  |  | 15,123 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 166,859 |  |  |  | — |  |  |  | 166,859 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 136,302 |  |  |  | — |  |  |  | 136,302 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | 8,310 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 11,398 |  |  |  | 11,398 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 27,054 |  |  |  | 27,054 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 365,046 |  |  |  | 53,575 |  |  |  | 311,471 |  |  |  | — |  |
| Total |  | $ | 368,995 |  |  | $ | 57,524 |  |  | $ | 311,471 |  |  | $ | — |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-14-297927:notes:16]
At June 30, 2014, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-14-297927:notes:17]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 12,733 |  |  | $ | 3,037 |  |  | $ | (15 | ) |  | $ | 15,755 |  |
| Corporate bonds |  |  | 98,995 |  |  |  | 403 |  |  |  | (7 | ) |  |  | 99,391 |  |
| Municipal fixed-rate bonds |  |  | 155,171 |  |  |  | 825 |  |  |  | (14 | ) |  |  | 155,982 |  |
| Municipal variable rate demand notes |  |  | 15,120 |  |  |  | — |  |  |  | — |  |  |  | 15,120 |  |
| Marketable equity securities |  |  | 25,896 |  |  |  | 14,249 |  |  |  | (418 | ) |  |  | 39,727 |  |
| Available-for-sale securities held at fair value |  | $ | 307,915 |  |  | $ | 18,514 |  |  | $ | (454 | ) |  | $ | 325,975 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,577 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 357,552 |  |

[0001193125-14-297927:notes:18]
[same as prior period, unchanged from 0001193125-14-187120:notes:123]

[0001193125-14-297927:notes:19]
[same as prior period, unchanged from 0001193125-14-187120:notes:124]


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-14-297927:notes:20]
The fair values of our derivative instruments recorded in the
 Consolidated Balance Sheet as of June 30, 2014 and
 December 31, 2013 were as follows:

[0001193125-14-297927:notes:21]
| (In thousands) |  | Balance Sheet Location |  | June 30, 2014 |  |  | December 31, 2013 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 4 |  |  | $ | 18 |  |
| Foreign exchange contracts – liability derivatives |  | Accounts payable |  | $ | (232 | ) |  | $ | (15 | ) |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-297927:notes:22]
At June 30, 2014 and December 31, 2013, inventory
 consisted of the following:

[0001193125-14-297927:notes:23]
| (In thousands) |  | June 30, 2014 |  |  | December 31, 2013 |  |
| Raw materials |  | $ | 39,557 |  |  | $ | 44,093 |  |
| Work in process |  |  | 7,086 |  |  |  | 3,484 |  |
| Finished goods |  |  | 42,596 |  |  |  | 42,534 |  |
| Total |  | $ | 89,239 |  |  | $ | 90,111 |  |


## us-gaap:ScheduleOfRealizedGainLossTableTextBlock

[0001193125-14-297927:notes:24]
[same as prior period, unchanged from 0001193125-14-187120:notes:107]

[0001193125-14-297927:notes:25]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Gross realized gains |  | $ | 2,407 |  |  | $ | 1,728 |  |  | $ | 4,635 |  |  | $ | 5,455 |  |
| Gross realized losses |  | $ | (67 | ) |  | $ | (175 | ) |  | $ | (103 | ) |  | $ | (257 | ) |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-14-297927:notes:26]
The following table is a summary of our stock options outstanding
 as of December 31, 2013 and June 30, 2014 and the changes
 that occurred during the six months ended June 30, 2014:

[0001193125-14-297927:notes:27]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2013 |  |  | 6,358 |  |  | $ | 24.43 |  |  |  | 6.60 |  |  | $ | 25,878 |  |
| Options granted |  |  | 2 |  |  | $ | 26.03 |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (144 | ) |  | $ | 26.02 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (91 | ) |  | $ | 19.56 |  |  |  |  |  |  |  |  |  |
| Options outstanding, June 30, 2014 |  |  | 6,125 |  |  | $ | 24.46 |  |  |  | 6.09 |  |  | $ | 8,724 |  |
| Options exercisable, June 30, 2014 |  |  | 3,776 |  |  | $ | 24.81 |  |  |  | 4.68 |  |  | $ | 4,900 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-297927:notes:28]
12. SEGMENT INFORMATION

[0001193125-14-297927:notes:29]
We operate in two reportable segments: (1) the Carrier
 Networks Division and (2) the Enterprise Networks Division. We
 evaluate the performance of our segments based on gross profit;
 therefore, selling, general and administrative expenses, research
 and development expenses, interest and dividend income, interest
 expense, net realized investment gain/loss, other income/expense
 and provision for taxes are reported on an entity-wide basis only.
 There are no inter-segment revenues.

[0001193125-14-297927:notes:30]
The following tables present information about the reported sales
 and gross profit of our reportable segments for the three and six
 months ended June 30, 2014 and 2013. Asset information by
 reportable segment is not reported, since we do not produce such
 information internally.

[0001193125-14-297927:notes:31]
|  |  | Three Months Ended |  |
|  |  | June 30, 2014 |  |  | June 30, 2013 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 143,455 |  |  | $ | 68,053 |  |  | $ | 123,333 |  |  | $ | 57,913 |  |
| Enterprise Networks |  |  | 32,674 |  |  |  | 18,744 |  |  |  | 38,900 |  |  |  | 21,885 |  |
| Total |  | $ | 176,129 |  |  | $ | 86,797 |  |  | $ | 162,233 |  |  | $ | 79,798 |  |

[0001193125-14-297927:notes:32]
|  |  | Six Months Ended |  |
|  |  | June 30, 2014 |  |  | June 30, 2013 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 261,617 |  |  | $ | 129,406 |  |  | $ | 233,220 |  |  | $ | 109,504 |  |
| Enterprise Networks |  |  | 61,516 |  |  |  | 35,181 |  |  |  | 72,026 |  |  |  | 39,971 |  |
| Total |  | $ | 323,133 |  |  | $ | 164,587 |  |  | $ | 305,246 |  |  | $ | 149,475 |  |

[0001193125-14-297927:notes:33]
[same as prior period, unchanged from 0001193125-14-187120:notes:26]

[0001193125-14-297927:notes:34]
[same as prior period, unchanged from 0001193125-14-187120:notes:27]

[0001193125-14-297927:notes:35]
Carrier Systems products are used by
 communications service providers to provide data, voice and video
 services to consumers and enterprises. This category includes the
 following product areas and related services:

[0001193125-14-297927:notes:36]
[same as prior period, unchanged from 0001193125-14-187120:notes:29]

[0001193125-14-297927:notes:37]
[same as prior period, unchanged from 0001193125-14-187120:notes:30]

[0001193125-14-297927:notes:38]
[same as prior period, unchanged from 0001193125-14-187120:notes:31]

[0001193125-14-297927:notes:39]
[same as prior period, unchanged from 0001193125-14-187120:notes:32]

[0001193125-14-297927:notes:40]
[same as prior period, unchanged from 0001193125-14-187120:notes:33]

[0001193125-14-297927:notes:41]
[same as prior period, unchanged from 0001193125-14-187120:notes:34]

[0001193125-14-297927:notes:42]
[same as prior period, unchanged from 0001193125-14-187120:notes:35]

[0001193125-14-297927:notes:43]
[same as prior period, unchanged from 0001193125-14-187120:notes:36]

[0001193125-14-297927:notes:44]
[same as prior period, unchanged from 0001193125-14-187120:notes:37]

[0001193125-14-297927:notes:45]
[same as prior period, unchanged from 0001193125-14-187120:notes:38]

[0001193125-14-297927:notes:46]
[same as prior period, unchanged from 0001193125-14-187120:notes:39]

[0001193125-14-297927:notes:47]
[same as prior period, unchanged from 0001193125-14-187120:notes:40]

[0001193125-14-297927:notes:48]
Business Networking products provide access to
 communication services and facilitate the delivery of cloud
 connectivity and enterprise communications to distributed
 enterprises and small and medium-sized businesses. This category
 includes the following product areas and related services:

[0001193125-14-297927:notes:49]
[same as prior period, unchanged from 0001193125-14-187120:notes:42]

[0001193125-14-297927:notes:50]
[same as prior period, unchanged from 0001193125-14-187120:notes:43]

[0001193125-14-297927:notes:51]
[same as prior period, unchanged from 0001193125-14-187120:notes:44]

[0001193125-14-297927:notes:52]
[same as prior period, unchanged from 0001193125-14-187120:notes:45]

[0001193125-14-297927:notes:53]
[same as prior period, unchanged from 0001193125-14-187120:notes:46]

[0001193125-14-297927:notes:54]
[same as prior period, unchanged from 0001193125-14-187120:notes:47]

[0001193125-14-297927:notes:55]
[same as prior period, unchanged from 0001193125-14-187120:notes:48]

[0001193125-14-297927:notes:56]
[same as prior period, unchanged from 0001193125-14-187120:notes:49]

[0001193125-14-297927:notes:57]
[same as prior period, unchanged from 0001193125-14-187120:notes:50]

[0001193125-14-297927:notes:58]
[same as prior period, unchanged from 0001193125-14-187120:notes:51]

[0001193125-14-297927:notes:59]
[same as prior period, unchanged from 0001193125-14-187120:notes:52]

[0001193125-14-297927:notes:60]
[same as prior period, unchanged from 0001193125-14-187120:notes:53]

[0001193125-14-297927:notes:61]
Loop Access products are used by carrier
 and enterprise customers for access to copper-based communications
 networks. The Loop Access category includes the following product
 areas and related services:

[0001193125-14-297927:notes:62]
[same as prior period, unchanged from 0001193125-14-187120:notes:55]

[0001193125-14-297927:notes:63]
[same as prior period, unchanged from 0001193125-14-187120:notes:56]

[0001193125-14-297927:notes:64]
[same as prior period, unchanged from 0001193125-14-187120:notes:57]

[0001193125-14-297927:notes:65]
[same as prior period, unchanged from 0001193125-14-187120:notes:58]

[0001193125-14-297927:notes:66]
[same as prior period, unchanged from 0001193125-14-187120:notes:59]

[0001193125-14-297927:notes:67]
The table below presents sales information by product category for
 the three and six months ended June 30, 2014 and 2013:

[0001193125-14-297927:notes:68]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Carrier Systems |  | $ | 128,824 |  |  | $ | 105,537 |  |  | $ | 228,377 |  |  | $ | 198,341 |  |
| Business Networking |  |  | 41,969 |  |  |  | 45,379 |  |  |  | 79,888 |  |  |  | 83,455 |  |
| Loop Access |  |  | 5,336 |  |  |  | 11,317 |  |  |  | 14,868 |  |  |  | 23,450 |  |
| Total |  | $ | 176,129 |  |  | $ | 162,233 |  |  | $ | 323,133 |  |  | $ | 305,246 |  |

[0001193125-14-297927:notes:69]
[same as prior period, unchanged from 0001193125-14-187120:notes:62]

[0001193125-14-297927:notes:70]
The table below presents subcategory revenues for the three and six
 months ended June 30, 2014 and 2013:

[0001193125-14-297927:notes:71]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 108,309 |  |  | $ | 81,628 |  |  | $ | 189,836 |  |  | $ | 153,862 |  |
| Optical (included in Carrier Systems) |  |  | 15,833 |  |  |  | 15,986 |  |  |  | 28,622 |  |  |  | 24,860 |  |
| Internetworking (included in Business Networking) |  |  | 40,986 |  |  |  | 43,922 |  |  |  | 77,932 |  |  |  | 80,834 |  |
| Subtotal |  |  | 165,128 |  |  |  | 141,536 |  |  |  | 296,390 |  |  |  | 259,556 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 4,798 |  |  |  | 10,289 |  |  |  | 13,675 |  |  |  | 21,696 |  |
| Other products (excluding HDSL) |  |  | 6,203 |  |  |  | 10,408 |  |  |  | 13,068 |  |  |  | 23,994 |  |
| Subtotal |  |  | 11,001 |  |  |  | 20,697 |  |  |  | 26,743 |  |  |  | 45,690 |  |
| Total |  | $ | 176,129 |  |  | $ | 162,233 |  |  | $ | 323,133 |  |  | $ | 305,246 |  |


## us-gaap:DisclosureOfReclassificationAmountTextBlock

[0001193125-14-297927:notes:72]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the three months
 ended June 30, 2014 and 2013:

[0001193125-14-297927:notes:73]
| (In thousands) |  | Three Months Ended June 30, 2014 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 2,160 |  |  | Net realized investment gain |
| Impairment expense |  |  | (34 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 2,126 |  |  |  |
| Tax (expense) benefit |  |  | (829 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,297 |  |  |  |
| (In thousands) |  | Three Months Ended June 30, 2013 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,469 |  |  | Net realized investment gain |
| Impairment expense |  |  | — |  |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 1,469 |  |  |  |
| Tax (expense) benefit |  |  | (573 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 896 |  |  |  |

[0001193125-14-297927:notes:74]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the six months ended
 June 30, 2014 and 2013:

[0001193125-14-297927:notes:75]
| (In thousands) |  | Six Months Ended June 30, 2014 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 4,330 |  |  | Net realized investment gain |
| Impairment expense |  |  | (34 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 4,296 |  |  |  |
| Tax (expense) benefit |  |  | (1,676 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,620 |  |  |  |

[0001193125-14-297927:notes:76]
| (In thousands) |  | Six Months Ended June 30, 2013 |  |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |  |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 4,913 |  |  |  | Net realized investment gain |  |
| Impairment expense |  |  | (4 | ) |  |  | Net realized investment gain |  |
| Total reclassifications for the period, before tax |  |  | 4,909 |  |  |  |  |  |
| Tax (expense) benefit |  |  | (1,915 | ) |  |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,994 |  |  |  |  |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-14-297927:notes:77]
8. INVENTORY

[0001193125-14-297927:notes:78]
We establish reserves for estimated excess, obsolete, or
 unmarketable inventory equal to the difference between the cost of
 the inventory and the estimated fair value of the inventory based
 upon assumptions about future demand and market conditions. At
 June 30, 2014 and December 31, 2013, raw materials
 reserves totaled $17.1 million and $16.9 million, respectively, and
 finished goods inventory reserves totaled $6.0 million and $6.1
 million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-14-297927:notes:79]
14. RELATED PARTY TRANSACTIONS

[0001193125-14-297927:notes:80]
We employ the law firm of our director emeritus for legal services.
 All bills for services rendered by this firm are reviewed and
 approved by our Chief Financial Officer. We believe that the fees
 for such services are comparable to those charged by other firms
 for services rendered to us. For the three and six months ended
 June 30, 2014 and 2013, we incurred fees of $10 thousand per
 month for these legal services.


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-14-297927:notes:81]
The following table summarizes the stock-based compensation expense
 related to stock options, restricted stock units (RSUs) and
 restricted stock for the three and six months ended June 30,
 2014 and 2013, which was recognized as follows:

[0001193125-14-297927:notes:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 119 |  |  | $ | 110 |  |  | $ | 235 |  |  | $ | 216 |  |
| Selling, general and administrative expense |  |  | 1,015 |  |  |  | 1,042 |  |  |  | 2,041 |  |  |  | 2,105 |  |
| Research and development expense |  |  | 958 |  |  |  | 956 |  |  |  | 1,873 |  |  |  | 2,019 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,973 |  |  |  | 1,998 |  |  |  | 3,914 |  |  |  | 4,124 |  |
| Total stock-based compensation expense |  |  | 2,092 |  |  |  | 2,108 |  |  |  | 4,149 |  |  |  | 4,340 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (296 | ) |  |  | (310 | ) |  |  | (580 | ) |  |  | (617 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,796 |  |  | $ | 1,798 |  |  | $ | 3,569 |  |  | $ | 3,723 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-14-297927:notes:83]
As of June 30, 2014, the estimated future amortization expense
 of our intangible assets is as follows:

[0001193125-14-297927:notes:84]
| (In thousands) |  | Amount |  |
| Remainder of 2014 |  | $ | 1,140 |  |
| 2015 |  |  | 2,157 |  |
| 2016 |  |  | 1,883 |  |
| 2017 |  |  | 1,284 |  |
| 2018 |  |  | 778 |  |
| Thereafter |  |  | 1,990 |  |
| Total |  | $ | 9,232 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-14-297927:notes:85]
A summary of the changes in stockholders’ equity for the six
 months ended June 30, 2014 is as follows:

[0001193125-14-297927:notes:86]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2013 |  | $ | 604,606 |  |
| Net income |  |  | 24,002 |  |
| Dividend payments |  |  | (10,137 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (2 | ) |
| Net unrealized gains (losses) on available-for-sale securities (net of tax) |  |  | 298 |  |
| Foreign currency translation adjustment |  |  | 386 |  |
| Proceeds from stock option exercises |  |  | 1,781 |  |
| Purchase of treasury stock |  |  | (53,091 | ) |
| Income tax benefit from exercise of stock options |  |  | 67 |  |
| Stock-based compensation expense |  |  | 4,149 |  |
| Balance, June 30, 2014 |  | $ | 572,059 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-14-297927:notes:87]
9. GOODWILL AND INTANGIBLE ASSETS

[0001193125-14-297927:notes:88]
We evaluate the carrying value of goodwill, generated from our
 acquisition of Bluesocket, Inc. and assigned to our Enterprise
 Networks division, during the fourth quarter of each year. We may
 perform additional evaluations if events occur or circumstances
 change that would more likely than not reduce the fair value of the
 reporting unit below its carrying amount. When evaluating whether
 goodwill is impaired, we compare the fair value of the reporting
 unit to which the goodwill is assigned to the reporting
 unit’s carrying amount, including goodwill. If the carrying
 amount of the reporting unit exceeds its fair value, then the
 amount of the impairment loss is measured. There have been no
 impairment losses recorded since acquisition.

[0001193125-14-297927:notes:89]
[same as prior period, unchanged from 0001193125-14-187120:notes:150]

[0001193125-14-297927:notes:90]
The following table presents our intangible assets as of
 June 30, 2014 and December 31, 2013:

[0001193125-14-297927:notes:91]
| (In thousands) |  | June 30, 2014 |  |  | December 31, 2013 |  |
|  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,914 |  |  | $ | (1,923 | ) |  | $ | 4,991 |  |  | $ | 6,996 |  |  | $ | (1,555 | ) |  | $ | 5,441 |  |
| Developed technology |  |  | 6,363 |  |  |  | (3,208 | ) |  |  | 3,155 |  |  |  | 6,537 |  |  |  | (2,692 | ) |  |  | 3,845 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,353 | ) |  |  | 987 |  |  |  | 2,340 |  |  |  | (1,185 | ) |  |  | 1,155 |  |
| Trade names |  |  | 270 |  |  |  | (175 | ) |  |  | 95 |  |  |  | 270 |  |  |  | (145 | ) |  |  | 125 |  |
| Other |  |  | 14 |  |  |  | (10 | ) |  |  | 4 |  |  |  | 14 |  |  |  | (8 | ) |  |  | 6 |  |
| Total |  | $ | 15,901 |  |  | $ | (6,669 | ) |  | $ | 9,232 |  |  | $ | 16,157 |  |  | $ | (5,585 | ) |  | $ | 10,572 |  |

[0001193125-14-297927:notes:92]
Amortization expense, all of which relates to business
 acquisitions, was $0.6 million for the three months ended
 June 30, 2014 and 2013, and $1.2 million for the six months
 ended June 30, 2014 and 2013.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001193125-14-297927:notes:93]
This supplemental pro forma information does not purport to be
 indicative of what would have occurred had the acquisition of the
 NSN BBA business been completed on January 1, 2011, nor are
 they indicative of any future results.

[0001193125-14-297927:notes:94]
| (In thousands) (Unaudited) |  | 2012 |  |  | 2011 |  |
| Pro forma revenue |  | $ | 672,044 |  |  | $ | 913,485 |  |
| Pro forma pre-tax loss |  | $ | 57,906 |  |  | $ | 169,162 |  |
| Weighted average exchange rate during the period (EURO/USD) |  | € | 1.00/$1.29 |  |  | € | 1.00/$1.38 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-297927:notes:95]
7. DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001193125-14-297927:notes:96]
[same as prior period, unchanged from 0001193125-14-187120:notes:110]

[0001193125-14-297927:notes:97]
As of June 30, 2014, we had forward contracts outstanding with
 notional amounts totaling €19.3 million ($26.4 million),
 which mature through 2014.

[0001193125-14-297927:notes:98]
The change in the fair values of our derivative instruments
 recorded in the Consolidated Statements of Income during the three
 and six months ended June 30, 2014 were as follows:

[0001193125-14-297927:notes:99]
|  |  | Income Statement Location |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | (438 | ) |  | $ | 138 |  |  | $ | (548 | ) |  | $ | (86 | ) |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-14-297927:notes:100]
6. INVESTMENTS

[0001193125-14-297927:notes:101]
As of June 30, 2014, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

[0001193125-14-297927:notes:102]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 7,187 |  |  | $ | 25,826 |  |
| One to two years |  |  | 46,881 |  |  |  | 66,823 |  |
| Two to three years |  |  | 45,323 |  |  |  | 49,269 |  |
| Three to five years |  |  | — |  |  |  | 14,064 |  |
| Total |  | $ | 99,391 |  |  | $ | 155,982 |  |

[0001193125-14-297927:notes:103]
Our investment policy provides limitations for issuer
 concentration, which limits, at the time of purchase, the
 concentration in any one issuer to 5% of the market value of our
 total investment portfolio.

[0001193125-14-297927:notes:104]
At June 30, 2014, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). During
 the first quarter of 2014, we made a principal payment on the Bond
 of $16.5 million. At June 30, 2014, the estimated fair value
 of the Bond using a level 2 valuation technique was approximately
 $29.7 million, based on a debt security with a comparable interest
 rate and maturity and a Standard and Poor’s credit rating of
 AAA. For more information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

[0001193125-14-297927:notes:105]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and six months
 ended June 30, 2014 and 2013, other-than-temporary impairment
 charges were not significant.

[0001193125-14-297927:notes:106]
Realized gains and losses on sales of securities are computed under
 the specific identification method. The following table presents
 gross realized gains and losses related to our investments.

[0001193125-14-297927:notes:107]
As of June 30, 2014 and 2013, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.

[0001193125-14-297927:notes:108]
The fair value of our Level 2 securities is calculated using a
 weighted average market price for each security. Market prices are
 obtained from a variety of industry standard data providers,
 security master files from large financial institutions, and other
 third-party sources. These multiple market prices are used as
 inputs into a distribution-curve-based algorithm to determine the
 daily market value of each security.

[0001193125-14-297927:notes:109]
Our municipal variable rate demand notes have a structure that
 implies a standard expected market price. The frequent interest
 rate resets make it reasonable to expect the price to stay at par.
 These securities are priced at the expected market price.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-297927:notes:110]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the three months
 ended June 30, 2014 and 2013:

[0001193125-14-297927:notes:111]
|  |  | Three Months Ended June 30, 2014 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 9,816 |  |  | $ | (891 | ) |  | $ | 1,159 |  |  | $ | 10,084 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 2,516 |  |  |  | — |  |  |  | 134 |  |  |  | 2,650 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,297 | ) |  |  | — |  |  |  | — |  |  |  | (1,297 | ) |
| Net current period other comprehensive income (loss) |  |  | 1,219 |  |  |  | — |  |  |  | 134 |  |  |  | 1,353 |  |
| Ending balance |  | $ | 11,035 |  |  | $ | (891 | ) |  | $ | 1,293 |  |  | $ | 11,437 |  |

[0001193125-14-297927:notes:112]
|  |  | Three Months Ended June 30, 2013 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 8,464 |  |  | $ | (1,952 | ) |  | $ | 3,435 |  |  | $ | 9,947 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (802 | ) |  |  | — |  |  |  | (1,713 | ) |  |  | (2,515 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (896 | ) |  |  | — |  |  |  | — |  |  |  | (896 | ) |
| Net current period other comprehensive income (loss) |  |  | (1,698 | ) |  |  | — |  |  |  | (1,713 | ) |  |  | (3,411 | ) |
| Ending balance |  | $ | 6,766 |  |  | $ | (1,952 | ) |  | $ | 1,722 |  |  | $ | 6,536 |  |

[0001193125-14-297927:notes:113]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the six months
 ended June 30, 2014 and 2013:

[0001193125-14-297927:notes:114]
|  |  | Six Months Ended June 30, 2014 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,737 |  |  | $ | (891 | ) |  | $ | 907 |  |  | $ | 10,753 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 2,918 |  |  |  | — |  |  |  | 386 |  |  |  | 3,304 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,620 | ) |  |  | — |  |  |  | — |  |  |  | (2,620 | ) |
| Net current period other comprehensive income (loss) |  |  | 298 |  |  |  | — |  |  |  | 386 |  |  |  | 684 |  |
| Ending balance |  | $ | 11,035 |  |  | $ | (891 | ) |  | $ | 1,293 |  |  | $ | 11,437 |  |

[0001193125-14-297927:notes:115]
|  |  | Six Months Ended June 30, 2013 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,108 |  |  | $ | (1,952 | ) |  | $ | 3,112 |  |  | $ | 11,268 |  |
| Other comprehensive income (loss) before reclassifications |  |  | (348 | ) |  |  | — |  |  |  | (1,390 | ) |  |  | (1,738 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,994 | ) |  |  | — |  |  |  | — |  |  |  | (2,994 | ) |
| Net current period other comprehensive income (loss) |  |  | (3,342 | ) |  |  | — |  |  |  | (1,390 | ) |  |  | (4,732 | ) |
| Ending balance |  | $ | 6,766 |  |  | $ | (1,952 | ) |  | $ | 1,722 |  |  | $ | 6,536 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-14-297927:notes:116]
10. STOCKHOLDERS’ EQUITY

[0001193125-14-297927:notes:117]
[same as prior period, unchanged from 0001193125-14-187120:notes:91]

[0001193125-14-297927:notes:118]
Since 1997, our Board of Directors has approved multiple share
 repurchase programs that have authorized open market repurchase
 transactions of up to 40.0 million shares of our common stock.
 On May 14, 2014, our Board of Directors authorized the
 repurchase of an additional 5.0 million shares of our common
 stock (bringing the total shares authorized for repurchase to 45.0
 million), which will commence upon completion of the repurchase
 plan announced May 1, 2013. This new authorization will be
 implemented through open market or private purchases from time to
 time as conditions warrant.

[0001193125-14-297927:notes:119]
During the six months ended June 30, 2014, we repurchased
 2.3 million shares of our common stock at an average price of
 $22.73 per share. We currently have the authority to purchase an
 additional 6.1 million shares of our common stock under the
 current plans approved by the Board of Directors.

[0001193125-14-297927:notes:120]
[same as prior period, unchanged from 0001193125-14-187120:notes:93]

[0001193125-14-297927:notes:121]
We issued 0.1 million shares of treasury stock during the six
 months ended June 30, 2014 to accommodate employee stock
 option exercises. The stock options had exercise prices ranging
 from $15.29 to $23.46. We received proceeds totaling $1.8 million
 from the exercise of these stock options during the six months
 ended June 30, 2014.

[0001193125-14-297927:notes:122]
[same as prior period, unchanged from 0001193125-14-187120:notes:95]

[0001193125-14-297927:notes:123]
During the six months ended June 30, 2014, we paid cash
 dividends as follows (in thousands except per share amounts):

[0001193125-14-297927:notes:124]
| Record Date |  | Payment Date |  | Per Share Amount |  | Total Dividend Paid |
| February 6, 2014 |  | February 20, 2014 |  | $0.09 |  | $5,102 |
| May 1, 2014 |  | May 15, 2014 |  | $0.09 |  | $5,035 |

[0001193125-14-297927:notes:125]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the three
 months ended June 30, 2014 and 2013:

[0001193125-14-297927:notes:126]
|  |  | Three Months Ended June 30, 2014 |  |  | Three Months Ended June 30, 2013 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 4,125 |  |  | $ | (1,609 | ) |  | $ | 2,516 |  |  | $ | (1,315 | ) |  | $ | 513 |  |  | $ | (802 | ) |
| Reclassification adjustment for amounts included in net income |  |  | (2,126 | ) |  |  | 829 |  |  |  | (1,297 | ) |  |  | (1,469 | ) |  |  | 573 |  |  |  | (896 | ) |
| Foreign currency translation adjustment |  |  | 134 |  |  |  | — |  |  |  | 134 |  |  |  | (1,713 | ) |  |  | — |  |  |  | (1,713 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 2,133 |  |  | $ | (780 | ) |  | $ | 1,353 |  |  | $ | (4,497 | ) |  | $ | 1,086 |  |  | $ | (3,411 | ) |

[0001193125-14-297927:notes:127]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the six months
 ended June 30, 2014 and 2013:

[0001193125-14-297927:notes:128]
|  |  | Six Months Ended June 30, 2014 |  |  | Six Months Ended June 30, 2013 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 4,784 |  |  | $ | (1,866 | ) |  | $ | 2,918 |  |  | $ | (571 | ) |  | $ | 223 |  |  | $ | (348 | ) |
| Reclassification adjustment for amounts included in net income |  |  | (4,296 | ) |  |  | 1,676 |  |  |  | (2,620 | ) |  |  | (4,909 | ) |  |  | 1,915 |  |  |  | (2,994 | ) |
| Foreign currency translation adjustment |  |  | 386 |  |  |  | — |  |  |  | 386 |  |  |  | (1,390 | ) |  |  | — |  |  |  | (1,390 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 874 |  |  | $ | (190 | ) |  | $ | 684 |  |  | $ | (6,870 | ) |  | $ | 2,138 |  |  | $ | (4,732 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-14-297927:notes:129]
2. BUSINESS COMBINATION

[0001193125-14-297927:notes:130]
On May 4, 2012, we acquired the NSN BBA business. This
 acquisition provides us with an established customer base in key
 markets and complementary, market-focused products and was
 accounted for as a business combination. We have included the
 financial results of the NSN BBA business in our consolidated
 financial statements since the date of acquisition. These revenues
 are included in the Carrier Networks division in the Broadband
 Access subcategory.

[0001193125-14-297927:notes:131]
The following supplemental pro forma information presents the
 financial results of the combined entity for the years ended
 December 31, 2012 and 2011. The pro forma results of the
 acquired NSN BBA business for the period January 1, 2012 to
 May 4, 2012 and January 1, 2011 to December 31, 2011
 were not included in our consolidated financial results for the
 years ended December 31, 2012 or 2011. There were no material,
 non-recurring pro forma adjustments to the historical data.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-14-297927:notes:132]
[same as prior period, unchanged from 0001193125-14-187120:notes:81]

[0001193125-14-297927:notes:133]
[same as prior period, unchanged from 0001193125-14-187120:notes:82]

[0001193125-14-297927:notes:134]
[same as prior period, unchanged from 0001193125-14-187120:notes:83]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-297927:notes:135]
3. INCOME TAXES

[0001193125-14-297927:notes:136]
Our effective tax rate increased from 33.2% in the six months ended
 June 30, 2013 to 34.2% in the six months ended June 30,
 2014. The increase in the effective tax rate between the two
 periods is primarily attributable to the net effect of the
 exclusion of a benefit for the research tax credit, which expired
 on December 31, 2013, offset by the release of a valuation
 allowance attributable to a foreign subsidiary in 2014.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-14-297927:notes:137]
[same as prior period, unchanged from 0001193125-14-187120:notes:133]

[0001193125-14-297927:notes:138]
[same as prior period, unchanged from 0001193125-14-187120:notes:134]

[0001193125-14-297927:notes:139]
We corrected immaterial misclassifications between the operating
 and investing sections of our consolidated statements of cash flows
 and adjusted our cash flows for the six months ended June 30,
 2013 in these categories by $0.5 million in order to be consistent
 with the 2014 presentation.

[0001193125-14-297927:notes:140]
[same as prior period, unchanged from 0001193125-14-187120:notes:136]

[0001193125-14-297927:notes:141]
During the year ended December 31, 2013, we identified two
 adjustments in the acquired NSN (formerly Nokia Siemens Networks)
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.5 million
 understatement of net income in the first two quarters of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for the second quarter of
 2013 and concluded that the impact was not material. We also
 evaluated the impact of the cumulative effect of the adjustments in
 2013 and concluded that the impact is not material to our results
 for the year 2013. Accordingly, during the three months ended
 September 30, 2013 we recorded an out of period adjustment to
 correct these issues.

[0001193125-14-297927:notes:142]
[same as prior period, unchanged from 0001193125-14-187120:notes:138]

[0001193125-14-297927:notes:143]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated working capital
 adjustments under negotiation related to the NSN BBA business
 acquisition, estimated pension liability, fair value of
 investments, and the evaluation of other-than-temporary declines in
 the value of investments. Actual amounts could differ significantly
 from these estimates.

[0001193125-14-297927:notes:144]
Recent Accounting Pronouncements

[0001193125-14-297927:notes:145]
In May 2014, the Financial Accounting Standards Board issued
 Accounting Standards Update No. 2014-09, Revenue from Contracts with
 Customers (ASU
 2014-09), which supersedes the revenue recognition requirements in
 Topic 605, Revenue Recognition,
 including most industry-specific revenue recognition guidance
 throughout the Industry Topics of the Codification. The core
 principle of ASU 2014-09 is to recognize revenues when promised
 goods or services are transferred to customers in an amount that
 reflects the consideration that is expected to be received for
 those goods or services. ASU 2014-09 is effective for annual
 reporting periods beginning after December 15, 2016, including
 interim periods within that reporting period, and early application
 is not permitted. ASU 2014-09 allows for either full retrospective
 or modified retrospective adoption. We are currently evaluating the
 transition method that will be elected and the impact that the
 adoption of ASU 2014-09 will have on our financial position,
 results of operations and cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-14-297927:notes:146]
13. LIABILITY FOR WARRANTY RETURNS

[0001193125-14-297927:notes:147]
Our products generally include warranties of 90 days to ten years
 for product defects. We accrue for warranty returns at the time
 revenue is recognized based on our estimate of the cost to repair
 or replace the defective products. We engage in extensive product
 quality programs and processes, including actively monitoring and
 evaluating the quality of our component suppliers. Our products
 continue to become more complex in both size and functionality as
 many of our product offerings migrate from line card applications
 to systems products. The increasing complexity of our products will
 cause warranty incidences, when they arise, to be more costly. Our
 estimates regarding future warranty obligations may change due to
 product failure rates, material usage, and other rework costs
 incurred in correcting a product failure. In addition, from time to
 time, specific warranty accruals may be recorded if unforeseen
 problems arise. Should our actual experience relative to these
 factors be worse than our estimates, we will be required to record
 additional warranty expense. Alternatively, if we provide for more
 reserves than we require, we will reverse a portion of such
 provisions in future periods. The liability for warranty
 obligations totaled $8.3 million at June 30, 2014 and $9.0
 million at December 31, 2013. The decrease from
 December 31, 2013 to June 30, 2014 includes a $1.5
 million decrease related to the settlement of an outstanding
 warranty claim, which corresponds to a reduction in Other
 Receivables. These liabilities are included in accrued expenses in
 the accompanying Consolidated Balance Sheets.

[0001193125-14-297927:notes:148]
A summary of warranty expense and write-off activity for the six
 months ended June 30, 2014 and 2013 is as follows:

[0001193125-14-297927:notes:149]
|  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period |  | $ | 8,977 |  |  | $ | 9,653 |  |
| Plus: Amounts charged to cost and expenses |  |  | 1,339 |  |  |  | 470 |  |
| Less: Deductions |  |  | (1,999 | ) |  |  | (2,182 | ) |
| Balance at end of period |  | $ | 8,317 |  |  | $ | 7,941 |  |

[0001193125-14-297927:notes:150]
Deductions for the six months ended June 30, 2014 include a
 $1.5 million reduction that relates to the settlement of an
 outstanding warranty claim, which corresponds to a reduction in
 Other Receivables.


## us-gaap:SubsequentEventsTextBlock

[0001193125-14-297927:notes:151]
16. SUBSEQUENT EVENTS

[0001193125-14-297927:notes:152]
On July 15, 2014, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 July 31, 2014. The payment date will be August 14, 2014.
 The quarterly dividend payment will be approximately $4.9 million.
 In July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.

[0001193125-14-297927:notes:153]
During the third quarter and as of August 6, 2014, we have
 repurchased 45 thousand shares of our common stock through
 open market purchases at an average cost of $21.93 per share. We
 currently have the authority to purchase an additional 6.1 million
 shares of our common stock under the current plan approved by the
 Board of Directors.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-14-297927:notes:154]
5. STOCK-BASED COMPENSATION

[0001193125-14-297927:notes:155]
[same as prior period, unchanged from 0001193125-14-187120:notes:4]

[0001193125-14-297927:notes:156]
There were no options granted during the three months ended
 June 30, 2014 or the three and six months ended June 30,
 2013. The weighted-average assumptions and value of options granted
 for the six months ended June 30, 2014 are summarized as
 follows:

[0001193125-14-297927:notes:157]
The fair value of our RSUs is calculated using a Monte Carlo
 Simulation valuation method. No RSUs were granted, forfeited, or
 vested during the three and six months ended June 30, 2014 or
 2013.

[0001193125-14-297927:notes:158]
The fair value of restricted stock is equal to the closing price of
 our stock on the date of grant. We granted four thousand shares of
 restricted stock during the three and six months ended
 June 30, 2014 at a fair value of $21.30 per share. No
 restricted stock was forfeited or vested during the three and six
 months ended June 30, 2014 or 2013.

[0001193125-14-297927:notes:159]
Stock-based compensation expense recognized in our Consolidated
 Statements of Income for the three and six months ended
 June 30, 2014 and 2013 is based on options, RSUs and
 restricted stock ultimately expected to vest, and has been reduced
 for estimated forfeitures. Estimated forfeitures for stock options
 were based upon historical experience and approximate 2.5%
 annually. We estimated a 0% forfeiture rate for our RSUs and
 restricted stock due to the limited number of recipients and
 historical experience for these awards.

[0001193125-14-297927:notes:160]
As of June 30, 2014, total compensation expense related to
 non-vested stock options, RSUs and restricted stock not yet
 recognized was approximately $14.1 million, which is expected to be
 recognized over an average remaining recognition period of 2.4
 years.

[0001193125-14-297927:notes:161]
The aggregate intrinsic values in the table above represent the
 total pre-tax intrinsic value (the difference between the closing
 price of our stock on the last trading day of the quarter and the
 exercise price, multiplied by the number of in-the-money options)
 that would have been received by the option holders had all option
 holders exercised their options on June 30, 2014. The
 aggregate intrinsic value will change based on the fair market
 value of our stock.

[0001193125-14-297927:notes:162]
The total pre-tax intrinsic value of options exercised during the
 three and six months ended June 30, 2014 was $0.1 million and
 $0.6 million, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-14-297927:notes:163]
4. PENSION BENEFIT PLAN

[0001193125-14-297927:notes:164]
[same as prior period, unchanged from 0001193125-14-187120:notes:126]

[0001193125-14-297927:notes:165]
The following table summarizes the components of net periodic
 pension cost for the three and six months ended June 30, 2014
 and 2013:

[0001193125-14-297927:notes:166]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Service cost |  | $ | 306 |  |  | $ | 294 |  |  | $ | 611 |  |  | $ | 594 |  |
| Interest cost |  |  | 216 |  |  |  | 182 |  |  |  | 431 |  |  |  | 369 |  |
| Expected return on plan assets |  |  | (280 | ) |  |  | (248 | ) |  |  | (559 | ) |  |  | (501 | ) |
| Net periodic pension cost |  | $ | 242 |  |  | $ | 228 |  |  | $ | 483 |  |  | $ | 462 |  |
