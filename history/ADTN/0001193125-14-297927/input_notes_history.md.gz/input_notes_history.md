# ADTN note change history — 0001193125-14-187120 → 0001193125-14-297927


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-08-06):
[0001193125-14-297927:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of June 30, 2014, of which $7.7 million has been applied to
 these commitments.
  (was, 2014-05-07, similarity 0.9773):
[0001193125-14-187120:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of March 31, 2014, of which $7.7 million has been applied to
 these commitments.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-08-06):
[0001193125-14-297927:note_history:2]
We corrected immaterial misclassifications between the operating
 and investing sections of our consolidated statements of cash flows
 and adjusted our cash flows for the six months ended June 30,
 2013 in these categories by $0.5 million in order to be consistent
 with the 2014 presentation.
  (was, 2014-05-07, similarity 0.9198):
[0001193125-14-187120:note_history:2]
We corrected immaterial misclassifications between the operating
 and investing sections of our consolidated statements of cash flows
 and adjusted our cash flows for the three months ended
 March 31, 2013 in these categories by $0.1 million in order to
 be consistent with the 2014 presentation.

- changed (2014-08-06):
[0001193125-14-297927:note_history:3]
During the year ended December 31, 2013, we identified two
 adjustments in the acquired NSN (formerly Nokia Siemens Networks)
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.5 million
 understatement of net income in the first two quarters of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for the second quarter of
 2013 and concluded that the impact was not material. We also
 evaluated the impact of the cumulative effect of the adjustments in
 2013 and concluded that the impact is not material to our results
 for the year 2013. Accordingly, during the three months ended
 September 30, 2013 we recorded an out of period adjustment to
 correct these issues.
  (was, 2014-05-07, similarity 0.7625):
[0001193125-14-187120:note_history:3]
During the year ended December 31, 2013, we identified two
 adjustments in the acquired NSN (formerly Nokia Siemens Networks)
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.3 million
 understatement of net income in the first quarter of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for first quarter of 2013
 and concluded that the impact was not material. We also evaluated
 the impact of the cumulative effect of the adjustments in 2013 and
 concluded that the impact was not material to our results for
 the year 2013. Accordingly, during the three months ended
 September 30, 2013 we recorded an out of period adjustment to
 correct these issues.

- added (2014-08-06):
[0001193125-14-297927:note_history:4]
In May 2014, the Financial Accounting Standards Board issued
 Accounting Standards Update No. 2014-09, Revenue from Contracts with
 Customers (ASU
 2014-09), which supersedes the revenue recognition requirements in
 Topic 605, Revenue Recognition,
 including most industry-specific revenue recognition guidance
 throughout the Industry Topics of the Codification. The core
 principle of ASU 2014-09 is to recognize revenues when promised
 goods or services are transferred to customers in an amount that
 reflects the consideration that is expected to be received for
 those goods or services. ASU 2014-09 is effective for annual
 reporting periods beginning after December 15, 2016, including
 interim periods within that reporting period, and early application
 is not permitted. ASU 2014-09 allows for either full retrospective
 or modified retrospective adoption. We are currently evaluating the
 transition method that will be elected and the impact that the
 adoption of ASU 2014-09 will have on our financial position,
 results of operations and cash flows.

- removed (2014-08-06):
[0001193125-14-187120:note_history:5]
During the three months ended March 31, 2014, no accounting
 pronouncements were issued that would have a material effect on our
 consolidated results of operations or financial condition.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-06):
[0001193125-14-297927:note_history:6]
At June 30, 2014, we held the following securities and
 investments, recorded at either fair value or cost.
  (was, 2014-05-07, similarity 0.9552):
[0001193125-14-187120:note_history:6]
At March 31, 2014, we held the following securities and
 investments, recorded at either fair value or cost.

- changed (2014-08-06):
[0001193125-14-297927:note_history:7]
As of June 30, 2014, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:
  (was, 2014-05-07, similarity 0.9581):
[0001193125-14-187120:note_history:7]
As of March 31, 2014, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

- changed (2014-08-06):
[0001193125-14-297927:note_history:8]
At June 30, 2014, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). During
 the first quarter of 2014, we made a principal payment on the Bond
 of $16.5 million. At June 30, 2014, the estimated fair value
 of the Bond using a level 2 valuation technique was approximately
 $29.7 million, based on a debt security with a comparable interest
 rate and maturity and a Standard and Poor’s credit rating of
 AAA. For more information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.
  (was, 2014-05-07, similarity 0.9887):
[0001193125-14-187120:note_history:8]
At March 31, 2014, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). During
 the first quarter of 2014, we made a principal payment on the Bond
 of $16.5 million. At March 31, 2014, the estimated fair value
 of the Bond using a level 2 valuation technique was approximately
 $29.6 million, based on a debt security with a comparable interest
 rate and maturity and a Standard and Poor’s credit rating of
 AAA-. For more information on the Bond, see “Debt”
 under “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

- changed (2014-08-06):
[0001193125-14-297927:note_history:9]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and six months
 ended June 30, 2014 and 2013, other-than-temporary impairment
 charges were not significant.
  (was, 2014-05-07, similarity 0.8825):
[0001193125-14-187120:note_history:9]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. As a result of our review, we
 recorded no other-than-temporary impairment charges during the
 three months ended March 31, 2014. For the three months ended
 March 31, 2013, we recorded an other-than-temporary impairment
 charge of $4 thousand related to one marketable equity
 security.

- changed (2014-08-06):
[0001193125-14-297927:note_history:10]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Gross realized gains |  | $ | 2,407 |  |  | $ | 1,728 |  |  | $ | 4,635 |  |  | $ | 5,455 |  |
| Gross realized losses |  | $ | (67 | ) |  | $ | (175 | ) |  | $ | (103 | ) |  | $ | (257 | ) |
  (was, 2014-05-07, similarity 0.7672):
[0001193125-14-187120:note_history:10]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Gross realized gains |  | $ | 2,228 |  |  | $ | 3,727 |  |
| Gross realized losses |  | $ | (36 | ) |  | $ | (82 | ) |

- changed (2014-08-06):
[0001193125-14-297927:note_history:11]
As of June 30, 2014 and 2013, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.
  (was, 2014-05-07, similarity 0.9705):
[0001193125-14-187120:note_history:11]
As of March 31, 2014 and 2013, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.

- changed (2014-08-06):
[0001193125-14-297927:note_history:12]
|  |  | Fair Value Measurements at June 30, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 11,737 |  |  | $ | 11,737 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,755 |  |  |  | 15,755 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 99,391 |  |  |  | — |  |  |  | 99,391 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 155,982 |  |  |  | — |  |  |  | 155,982 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 15,120 |  |  |  | — |  |  |  | 15,120 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 12,085 |  |  |  | 12,085 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 27,642 |  |  |  | 27,642 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 325,975 |  |  |  | 55,482 |  |  |  | 270,493 |  |  |  | — |  |
| Total |  | $ | 337,712 |  |  | $ | 67,219 |  |  | $ | 270,493 |  |  | $ | — |  |
  (was, 2014-05-07, similarity 0.6592):
[0001193125-14-187120:note_history:12]
|  |  | Fair Value Measurements at March 31, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 11,742 |  |  | $ | 11,742 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,277 |  |  |  | 15,277 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 130,863 |  |  |  | — |  |  |  | 130,863 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 158,387 |  |  |  | — |  |  |  | 158,387 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 24,840 |  |  |  | — |  |  |  | 24,840 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 10,639 |  |  |  | 10,639 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 26,947 |  |  |  | 26,947 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 366,953 |  |  |  | 52,863 |  |  |  | 314,090 |  |  |  | — |  |
| Total |  | $ | 378,695 |  |  | $ | 64,605 |  |  | $ | 314,090 |  |  | $ | — |  |
|  |  | Fair Value Measurements at December 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,949 |  |  | $ | 3,949 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,123 |  |  |  | 15,123 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 166,859 |  |  |  | — |  |  |  | 166,859 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 136,302 |  |  |  | — |  |  |  | 136,302 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | 8,310 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 11,398 |  |  |  | 11,398 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 27,054 |  |  |  | 27,054 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 365,046 |  |  |  | 53,575 |  |  |  | 311,471 |  |  |  | — |  |
| Total |  | $ | 368,995 |  |  | $ | 57,524 |  |  | $ | 311,471 |  |  | $ | — |  |

- added (2014-08-06):
[0001193125-14-297927:note_history:13]
|  |  | Fair Value Measurements at December 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,949 |  |  | $ | 3,949 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,123 |  |  |  | 15,123 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 166,859 |  |  |  | — |  |  |  | 166,859 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 136,302 |  |  |  | — |  |  |  | 136,302 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | 8,310 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 11,398 |  |  |  | 11,398 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 27,054 |  |  |  | 27,054 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 365,046 |  |  |  | 53,575 |  |  |  | 311,471 |  |  |  | — |  |
| Total |  | $ | 368,995 |  |  | $ | 57,524 |  |  | $ | 311,471 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2014-08-06):
[0001193125-14-297927:note_history:14]
We employ the law firm of our director emeritus for legal services.
 All bills for services rendered by this firm are reviewed and
 approved by our Chief Financial Officer. We believe that the fees
 for such services are comparable to those charged by other firms
 for services rendered to us. For the three and six months ended
 June 30, 2014 and 2013, we incurred fees of $10 thousand per
 month for these legal services.
  (was, 2014-05-07, similarity 0.9467):
[0001193125-14-187120:note_history:14]
We employ the law firm of our director emeritus for legal services.
 All bills for services rendered by this firm are reviewed and
 approved by our Chief Financial Officer. We believe that the fees
 for such services are comparable to those charged by other firms
 for services rendered to us. For the three months ended
 March 31, 2014 and 2013, we incurred fees of $10 thousand per
 month for these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2014-08-06):
[0001193125-14-297927:note_history:15]
On July 15, 2014, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 July 31, 2014. The payment date will be August 14, 2014.
 The quarterly dividend payment will be approximately $4.9 million.
 In July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.

- changed (2014-08-06):
[0001193125-14-297927:note_history:16]
During the third quarter and as of August 6, 2014, we have
 repurchased 45 thousand shares of our common stock through
 open market purchases at an average cost of $21.93 per share. We
 currently have the authority to purchase an additional 6.1 million
 shares of our common stock under the current plan approved by the
 Board of Directors.
  (was, 2014-05-07, similarity 0.9487):
[0001193125-14-187120:note_history:16]
During the second quarter and as of May 7, 2014, we have
 repurchased 1.3 million shares of our common stock through
 open market purchases at an average cost of $22.63 per share. We
 currently have the authority to purchase an additional 1.8 million
 shares of our common stock under the current plan approved by the
 Board of Directors.

- removed (2014-08-06):
[0001193125-14-187120:note_history:17]
On April 15, 2014, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 May 1, 2014. The payment date will be May 15, 2014. The
 quarterly dividend payment will be approximately $5.0 million. In
 July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.
