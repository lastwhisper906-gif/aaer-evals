# ADTN MD&A — 0001193125-14-297927


## mdna

[0001193125-14-297927:mdna:1]
[same as prior period, unchanged from 0001193125-14-187120:mdna:1]

[0001193125-14-297927:mdna:2]
[same as prior period, unchanged from 0001193125-14-187120:mdna:2]

[0001193125-14-297927:mdna:3]
[same as prior period, unchanged from 0001193125-14-187120:mdna:3]

[0001193125-14-297927:mdna:4]
[same as prior period, unchanged from 0001193125-14-187120:mdna:4]

[0001193125-14-297927:mdna:5]
[same as prior period, unchanged from 0001193125-14-187120:mdna:5]

[0001193125-14-297927:mdna:6]
[same as prior period, unchanged from 0001193125-14-187120:mdna:6]

[0001193125-14-297927:mdna:7]
[same as prior period, unchanged from 0001193125-14-187120:mdna:7]

[0001193125-14-297927:mdna:8]
[same as prior period, unchanged from 0001193125-14-187120:mdna:8]

[0001193125-14-297927:mdna:9]
[same as prior period, unchanged from 0001193125-14-187120:mdna:9]

[0001193125-14-297927:mdna:10]
[same as prior period, unchanged from 0001193125-14-187120:mdna:10]

[0001193125-14-297927:mdna:11]
[same as prior period, unchanged from 0001193125-14-187120:mdna:11]

[0001193125-14-297927:mdna:12]
[same as prior period, unchanged from 0001193125-14-187120:mdna:12]

[0001193125-14-297927:mdna:13]
[same as prior period, unchanged from 0001193125-14-187120:mdna:13]

[0001193125-14-297927:mdna:14]
[same as prior period, unchanged from 0001193125-14-187120:mdna:14]

[0001193125-14-297927:mdna:15]
[same as prior period, unchanged from 0001193125-14-187120:mdna:15]

[0001193125-14-297927:mdna:16]
[same as prior period, unchanged from 0001193125-14-187120:mdna:16]

[0001193125-14-297927:mdna:17]
[same as prior period, unchanged from 0001193125-14-187120:mdna:17]

[0001193125-14-297927:mdna:18]
[same as prior period, unchanged from 0001193125-14-187120:mdna:18]

[0001193125-14-297927:mdna:19]
[same as prior period, unchanged from 0001193125-14-187120:mdna:19]

[0001193125-14-297927:mdna:20]
Business Networking products provide access to communication services and facilitate the delivery of cloud
connectivity and enterprise communications to distributed enterprises and small and medium-sized businesses. This category includes the following product areas and related services:

[0001193125-14-297927:mdna:21]
[same as prior period, unchanged from 0001193125-14-187120:mdna:21]

[0001193125-14-297927:mdna:22]
[same as prior period, unchanged from 0001193125-14-187120:mdna:22]

[0001193125-14-297927:mdna:23]
[same as prior period, unchanged from 0001193125-14-187120:mdna:23]

[0001193125-14-297927:mdna:24]
[same as prior period, unchanged from 0001193125-14-187120:mdna:24]

[0001193125-14-297927:mdna:25]
[same as prior period, unchanged from 0001193125-14-187120:mdna:25]

[0001193125-14-297927:mdna:26]
[same as prior period, unchanged from 0001193125-14-187120:mdna:26]

[0001193125-14-297927:mdna:27]
[same as prior period, unchanged from 0001193125-14-187120:mdna:27]

[0001193125-14-297927:mdna:28]
[same as prior period, unchanged from 0001193125-14-187120:mdna:28]

[0001193125-14-297927:mdna:29]
[same as prior period, unchanged from 0001193125-14-187120:mdna:29]

[0001193125-14-297927:mdna:30]
[same as prior period, unchanged from 0001193125-14-187120:mdna:30]

[0001193125-14-297927:mdna:31]
[same as prior period, unchanged from 0001193125-14-187120:mdna:31]

[0001193125-14-297927:mdna:32]
[same as prior period, unchanged from 0001193125-14-187120:mdna:32]

[0001193125-14-297927:mdna:33]
[same as prior period, unchanged from 0001193125-14-187120:mdna:33]

[0001193125-14-297927:mdna:34]
[same as prior period, unchanged from 0001193125-14-187120:mdna:34]

[0001193125-14-297927:mdna:35]
[same as prior period, unchanged from 0001193125-14-187120:mdna:35]

[0001193125-14-297927:mdna:36]
[same as prior period, unchanged from 0001193125-14-187120:mdna:36]

[0001193125-14-297927:mdna:37]
[same as prior period, unchanged from 0001193125-14-187120:mdna:37]

[0001193125-14-297927:mdna:38]
[same as prior period, unchanged from 0001193125-14-187120:mdna:38]

[0001193125-14-297927:mdna:39]
In addition, we identify subcategories of product revenues, which we divide
into core products and legacy products. Our core products consist of Broadband Access and Optical products (included in Carrier Systems) and Internetworking products (included in Business Networking). Our legacy products include HDSL products
(included in Loop Access) and other products not included in the aforementioned core products. Many of our customers are migrating their networks to deliver higher bandwidth services by utilizing newer technologies. We believe that products and
services offered in our core product areas position us well for this migration. As a result of this migration, revenues of our legacy products, including HDSL, have decreased significantly. Despite occasional increases, we anticipate revenues of our
legacy products, including HDSL, will continue to decline over time.

[0001193125-14-297927:mdna:40]
See Note 12 of Notes to Consolidated Financial Statements in this report for further
information regarding these product categories.

[0001193125-14-297927:mdna:41]
Sales were $176.1 million and $323.1 million for the three and six months ended June 30, 2014
compared to $162.2 million and $305.2 million for the three and six months ended June 30, 2013. Product revenues for our three core areas, Broadband Access, Optical and Internetworking, were $165.1 million and $296.4 million for the three and
six months ended June 30, 2014 compared to $141.5 million and $259.6 million for the three and six months ended June 30, 2013. Our gross margin increased to 49.3% and 50.9% for the three and six months ended June 30, 2014 from 49.2%
and 49.0% for the three and six months ended June 30, 2013. Our operating income margin increased to 11.0% and 9.5% for the three and six months ended June 30, 2014 from 8.7% and 6.8% for the three and six months ended June 30, 2013.
Net income was $14.4 million and $24.0 million for the three and six months ended June 30, 2014 compared to $9.9 million and $17.7 million for the three and six months ended June 30, 2013. Our effective tax rate decreased to 34.0% for the
three months ended June 30, 2014 from 41.4% for the three months ended June 30, 2013 and increased to 34.2% for the six months ended June 30, 2014 from 33.2% for the six months ended June 30, 2013. Earnings per share, assuming
dilution, were $0.26 and $0.42 for the three and six months ended June 30, 2014 compared to $0.17 and $0.29 for the three and six months ended June 30, 2013.

[0001193125-14-297927:mdna:42]
26

[0001193125-14-297927:mdna:43]
[same as prior period, unchanged from 0001193125-14-187120:mdna:43]

[0001193125-14-297927:mdna:44]
[same as prior period, unchanged from 0001193125-14-187120:mdna:44]

[0001193125-14-297927:mdna:45]
[same as prior period, unchanged from 0001193125-14-187120:mdna:45]

[0001193125-14-297927:mdna:46]
[same as prior period, unchanged from 0001193125-14-187120:mdna:46]

[0001193125-14-297927:mdna:47]
[same as prior period, unchanged from 0001193125-14-187120:mdna:47]

[0001193125-14-297927:mdna:48]
[same as prior period, unchanged from 0001193125-14-187120:mdna:48]

[0001193125-14-297927:mdna:49]
[same as prior period, unchanged from 0001193125-14-187120:mdna:49]

[0001193125-14-297927:mdna:50]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2014 COMPARED TO THREE AND SIX MONTHS ENDED JUNE 30, 2013

[0001193125-14-297927:mdna:51]
[same as prior period, unchanged from 0001193125-14-187120:mdna:51]

[0001193125-14-297927:mdna:52]
ADTRAN’s sales increased 8.6% from
$162.2 million in the three months ended June 30, 2013 to $176.1 million in the three months ended June 30, 2014, and increased 5.9% from $305.2 million in the six months ended June 30, 2013 to $323.1 million in the six months ended
June 30, 2014. The increase in sales for the three months ended June 30, 2014 is primarily attributable to a $26.7 million increase in sales of our Broadband Access products, partially offset by a $9.7 million decrease in sales of our HDSL
and other legacy products and a $2.9 million decrease in sales of our Internetworking products. The increase in sales for the six months ended June 30, 2014 is primarily attributable to a $36.0 million increase in sales of our Broadband Access
products and a $3.8 million increase in sales of our Optical products, partially offset by an $18.9 million decrease in sales of our HDSL and other legacy products and a $2.9 million decrease in sales of our Internetworking products.

[0001193125-14-297927:mdna:53]
Carrier Networks sales increased 16.3% from $123.3 million in the three months ended June 30, 2013 to $143.5
million in the three months ended June 30, 2014, and increased 12.2% from $233.2 million in the six months ended June 30, 2013 to $261.6 million in the six months ended June 30, 2014. The increase in sales for the three months ended
June 30, 2014 is primarily attributable to increases in sales of our Broadband Access products and Internetworking products, partially offset by decreases in sales of our HDSL and other legacy products. The increase in sales for the six months
ended June 30, 2014 is primarily attributable to increases in sales of our Broadband Access products, Internetworking products, and Optical products, partially offset by decreases in sales of our HDSL and other legacy products. The increase in
sales of our Broadband Access products for the three and six months ended June 30, 2014 is primarily attributable to an increase in hiX product sales and an increase in professional services. The increase in sales of our Internetworking
products for the three and six months ended June 30, 2014 is primarily attributable to increases in Carrier Ethernet sales and FTTP ONT sales to carriers. The increase in sales of our Optical products for the six months ended June 30, 2014
is primarily attributable to increased shipments of optical products for broadband access and increased shipments of our OPTI-6100 products to a domestic tier 1 carrier for Ethernet services to enterprises and wireless backhaul that occurred during
the first quarter. The decrease in sales of HDSL and other legacy products for the three and six months ended June 30, 2014 has been expected as customers continue to upgrade their networks to deliver higher bandwidth services by migrating to
newer technologies, including to our core products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to decline over time, these revenues may
continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-14-297927:mdna:54]
Enterprise Networks sales decreased 16.0% from
$38.9 million in the three months ended June 30, 2013 to $32.7 million in the three months ended June 30, 2014, and decreased 14.6% from $72.0 million in the six months ended June 30, 2013 to $61.5 million in the six months ended
June 30, 2014. The decrease in sales for the three and six months ended June 30, 2014 is primarily attributable to decreases in sales of our Internetworking products and sales of our legacy products. The decrease in sales of our
Internetworking products for this division was primarily attributable to lower sales of products through service provider channels. The decrease in legacy products was expected and discussed further above. Internetworking product sales attributable
to Enterprise Networks were 95.0% and 94.7% of the division’s sales in the three and six months ended June 30, 2014, compared to 93.4% and 93.7% in the three and six months ended June 30, 2013. Legacy products primarily comprise the
remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 24.0% and 23.6% for the three and six months ended June 30, 2013 to 18.6% and 19.0% for the three and six months ended June 30,
2014.

[0001193125-14-297927:mdna:55]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, increased 127.7% from $34.7
million in the three months ended June 30, 2013 to $79.1 million in the three months ended June 30, 2014, and increased 91.5% from $69.7 million in the six months ended June 30, 2013 to $133.4 million in the six months ended
June 30, 2014. International sales, as a percentage of total sales, increased from 21.4% and 22.8% for the three and six months ended June 30, 2013 to 44.9% and 41.3% for the three and six months ended June 30, 2014. International
sales increased in the three and six months ended June 30, 2014 compared to the three and six months ended June 30, 2013 primarily due to an increase in sales in the EMEA region and Latin America, partially offset by a decrease in sales in
the Asia-Pacific region.

[0001193125-14-297927:mdna:56]
Carrier System product sales increased $23.3 million and $30.0 million in the three and six months ended June 30, 2014
compared to the three and six months ended June 30, 2013. The increase for the three months ended June 30, 2014 is primarily attributable to a $26.7 million increase in Broadband Access product sales, partially offset by a $3.2 million
decrease in sales of our legacy products. The increase for the six months ended June 30, 2014 is primarily attributable to a $36.0 million increase in Broadband Access product sales and a $3.8 million increase in Optical product sales,
partially offset by a $9.7 million decrease in sales of our legacy products. The changes for the three and six months ended June 30, 2014 are primarily attributable to the factors discussed above.

[0001193125-14-297927:mdna:57]
Business Networking product sales decreased $3.4 million and $3.6 million in the three and six months ended June 30, 2014 compared to the three and six
months ended June 30, 2013. The decrease for the three and six months ended June 30, 2014 is primarily due to a $2.9 million decrease in Internetworking product sales. The changes for the three and six months ended June 30, 2014 are
primarily attributable to the factors discussed above.

[0001193125-14-297927:mdna:58]
28

[0001193125-14-297927:mdna:59]
Loop Access product sales decreased $6.0 million and $8.6 million in the three and six months ended June 30,
2014 compared to the three and six months ended June 30, 2013. The decrease for the three and six months ended June 30, 2014 is primarily due to a $5.5 million and an $8.0 million decrease, respectively, in HDSL product sales, which is
discussed further above.

[0001193125-14-297927:mdna:60]
[same as prior period, unchanged from 0001193125-14-187120:mdna:59]

[0001193125-14-297927:mdna:61]
As a
percentage of sales, cost of sales decreased from 50.8% in the three months ended June 30, 2013 to 50.7% in the three months ended June 30, 2014 and decreased from 51.0% in the six months ended June 30, 2013 to 49.1% in the six months
ended June 30, 2014. The decrease for the three and six months ended June 30, 2014 is primarily attributable to improving gross margins in our international business, largely offset by shifts in customer mix.

[0001193125-14-297927:mdna:62]
Carrier Networks cost of sales, as a percent of division sales, decreased from 53.0% in the three months ended June 30, 2013 to 52.6% in the three months
ended June 30, 2014 and decreased from 53.0% in the six months ended June 30, 2013 to 50.5% in the six months ended June 30, 2014. The decrease for the three and six months ended June 30, 2014 is primarily attributable to
improving gross margins in our international business, largely offset by shifts in customer mix.

[0001193125-14-297927:mdna:63]
Enterprise Networks cost of sales, as a percent of
division sales, decreased from 43.7% in the three months ended June 30, 2013 to 42.6% in the three months ended June 30, 2014 and decreased from 44.5% in the six months ended June 30, 2013 to 42.8% in the six months ended
June 30, 2014. The decrease for the three and six months ended June 30, 2014 is primarily attributable to shifts in customer mix.

[0001193125-14-297927:mdna:64]
An important
part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing
differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-14-297927:mdna:65]
[same as prior period, unchanged from 0001193125-14-187120:mdna:64]

[0001193125-14-297927:mdna:66]
Selling, general and administrative expenses increased 3.4% from $32.7 million in the three months ended June 30, 2013 to $33.8 million in
the three months ended June 30, 2014 and increased 7.0% from $63.3 million in the six months ended June 30, 2013 to $67.7 million in the six months ended June 30, 2014. The increase in selling, general and administrative expenses for
the three and six months ended June 30, 2014 is primarily attributable to increases in incentive compensation, legal expenses, travel expenses and marketing expenses.

[0001193125-14-297927:mdna:67]
Selling, general and administrative expenses as a percentage of sales decreased from 20.1% in the three months ended June 30, 2013 to 19.2% in the three
months ended June 30, 2014 and increased from 20.7% in the six months ended June 30, 2013 to 21.0% in the six months ended June 30, 2014. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever
there is a significant fluctuation in revenues for the periods being compared.

[0001193125-14-297927:mdna:68]
[same as prior period, unchanged from 0001193125-14-187120:mdna:67]

[0001193125-14-297927:mdna:69]
Research and development expenses increased 1.8% from $33.1 million in the three months ended June 30, 2013 to $33.7 million in the three months ended
June 30, 2014 and increased 1.0% from $65.6 million in the six months ended June 30, 2013 to $66.2 million in the six months ended June 30, 2014. The increase in research and development expenses for the three and six months ended
June 30, 2014 is primarily related to increases in compensation costs and travel expenses, partially offset by a decrease in independent contractor expense.

[0001193125-14-297927:mdna:70]
As a percentage of sales, research and development expenses decreased from 20.4% in the three months ended June 30, 2013 to 19.1% in the three months
ended June 30, 2014 and decreased from 21.5% in the six months ended June 30, 2013 to 20.5% in the six months ended June 30, 2014. Research and development expenses as a percentage of sales will fluctuate whenever there are
incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-14-297927:mdna:71]
We expect to continue to incur research and development expenses in connection with our new and existing products
and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products and product
cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-14-297927:mdna:72]
[same as prior period, unchanged from 0001193125-14-187120:mdna:71]

[0001193125-14-297927:mdna:73]
Interest and
dividend income decreased 37.0% from $1.7 million in the three months ended June 30, 2013 to $1.1 million in the three months ended June 30, 2014 and decreased 31.8% from $3.4 million in the six months ended June 30, 2013 to $2.3
million in the six months ended June 30, 2014. The decrease in interest and dividend income is primarily attributable to an $18.3 million reduction of restricted funds that serves as a collateral deposit against our taxable revenue bond during
the first quarter and a reduction in the interest rate of that investment from 4.8% to 1.6% (see “Interest Expense” below for corresponding decrease in the interest rate of our taxable revenue bond). See “Liquidity and Capital
Resources” below for additional information on our taxable revenue bond.

[0001193125-14-297927:mdna:74]
[same as prior period, unchanged from 0001193125-14-187120:mdna:73]

[0001193125-14-297927:mdna:75]
Interest expense, which is primarily related to our taxable revenue bond, decreased 74.3% from $0.6 million in the three months ended June 30, 2013 to
$0.1 million in the three months ended June 30, 2014 and decreased 67.6% from $1.2 million in the six months ended June 30, 2013 to $0.4 million in the six months ended June 30, 2014. The decrease is primarily attributable to a $16.5
million principal payment made on our taxable revenue bond during the first quarter and a reduction in the interest rate of that bond from 5.0% to 2.0%. See “Liquidity and Capital Resources” below for additional information on our revenue
bond.

[0001193125-14-297927:mdna:76]
[same as prior period, unchanged from 0001193125-14-187120:mdna:75]

[0001193125-14-297927:mdna:77]
Net
realized investment gain increased 50.7% from $1.6 million in the three months ended June 30, 2013 to $2.3 million in the three months ended June 30, 2014 and decreased 12.8% from $5.2 million in the six months ended June 30, 2013 to
$4.5 million in the six months ended June 30, 2014. The increase in realized investment gains for the three months ended June 30, 2014 is primarily attributable to higher gains from the sale of equity securities compared to the same period
in 2013. The decrease in realized investment gains for the six months ended June 30, 2014 is primarily attributable to lower gains from the sale of equity securities during the first quarter of 2014. See “Investing Activities” in
“Liquidity and Capital Resources” below for additional information.

[0001193125-14-297927:mdna:78]
[same as prior period, unchanged from 0001193125-14-187120:mdna:77]

[0001193125-14-297927:mdna:79]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management
fees, scrap raw material sales, and gains and losses on the disposal of property, plant and equipment occurring in the normal course of business, changed from $0.1 million of income in the three months ended June 30, 2013 to $0.8 million of
expense in the three months ended June 30, 2014. The change in the three months ended June 30, 2014 is primarily attributable to losses on foreign currency transactions during the second quarter of 2014. Other income (expense) changed from
$1.5 million of expense in the six months ended June 30, 2013 to $0.7 million of expense in the six months ended June 30, 2014. The change in the six months ended June 30, 2014 is primarily attributable to losses on foreign currency
transactions during the first quarter of 2013.

[0001193125-14-297927:mdna:80]
[same as prior period, unchanged from 0001193125-14-187120:mdna:79]

[0001193125-14-297927:mdna:81]
Our effective tax rate increased from 33.2% in the six months ended June 30, 2013 to 34.2% in the six months ended June 30, 2014. The increase in the
effective tax rate between the two periods is primarily attributable to the net effect of the exclusion of a benefit for the research tax credit, which expired on December 31, 2013, offset by the release of a valuation allowance attributable to
a foreign subsidiary in 2014.

[0001193125-14-297927:mdna:82]
[same as prior period, unchanged from 0001193125-14-187120:mdna:81]

[0001193125-14-297927:mdna:83]
As a result of the above factors, net income increased $4.5 million from $9.9 million in the three months ended June 30, 2013 to $14.4 million in the
three months ended June 30, 2014 and increased $6.3 million from $17.7 million in the six months ended June 30, 2013 to $24.0 million in the six months ended June 30, 2014.

[0001193125-14-297927:mdna:84]
As a percentage of sales, net income increased from 6.1% in the three months ended June 30, 2013 to 8.2% in the three months ended June 30, 2014 and
increased from 5.8% in the six months ended June 30, 2013 to 7.4% in the six months ended June 30, 2014.

[0001193125-14-297927:mdna:85]
[same as prior period, unchanged from 0001193125-14-187120:mdna:84]

[0001193125-14-297927:mdna:86]
[same as prior period, unchanged from 0001193125-14-187120:mdna:85]

[0001193125-14-297927:mdna:87]
We intend to finance our operations
with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product
development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to
meet our operating and capital needs for at least the next 12 months.

[0001193125-14-297927:mdna:88]
At June 30, 2014, cash on hand was $58.9 million and short-term investments
were $45.9 million, which resulted in available short-term liquidity of $104.8 million. At December 31, 2013, our cash on hand of $58.3 million and short-term investments of $105.8 million resulted in available short-term liquidity of $164.1
million. The decrease in short-term liquidity from December 31, 2013 to June 30, 2014 primarily reflects funds used for equipment acquisitions, payments on long-term debt, share repurchases and dividends, partially offset by funds provided
by our operating activities and stock option exercises by our employees.

[0001193125-14-297927:mdna:89]
[same as prior period, unchanged from 0001193125-14-187120:mdna:88]

[0001193125-14-297927:mdna:90]
Our working capital, which consists of current assets less current liabilities, decreased 17.7% from $277.3 million as of December 31, 2013 to $228.1
million as of June 30, 2014. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.44 as of December 31, 2013 to 1.75 as of June 30,
2014. The current ratio, defined as current assets divided by current liabilities, decreased from 3.71 as of December 31, 2013 to 2.82 as of June 30, 2014. The decreases in our working capital, quick ratio and current ratio are primarily
attributable to a decrease in short-term investments and an increase in accounts payable and unearned revenue, partially offset by an increase in accounts receivable, during the six months ended June 30, 2014. Short-term investments were used
to fund share repurchases during 2014.

[0001193125-14-297927:mdna:91]
Net accounts receivable increased 34.6% from $85.8 million at December 31, 2013 to $115.5 million at
June 30, 2014. Our allowance for doubtful accounts was $130 thousand at December 31, 2013 and $116 thousand at June 30, 2014. Quarterly accounts receivable days sales outstanding (DSO) increased from 50 days as of December 31,
2013 to 60 days as of June 30, 2014. The change in net accounts receivable and DSO is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than
U.S. customers. Other receivables increased from $18.2 million at December 31, 2013 to $23.8 million at June 30, 2014. The increase in other receivables is primarily attributable to the timing of filing returns and collections of VAT
receivables in our international subsidiaries. Other receivables will also fluctuate due to the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001193125-14-297927:mdna:92]
Quarterly inventory turnover increased from 3.6 turns as of December 31, 2013 to 4.1 turns as of June 30, 2014. Inventory decreased 1.0% from
December 31, 2013 to June 30, 2014. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing the risk of inventory
obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-14-297927:mdna:93]
Accounts payable increased 28.6% from $48.3 million at
December 31, 2013 to $62.1 million at June 30, 2014. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-14-297927:mdna:94]
[same as prior period, unchanged from 0001193125-14-187120:mdna:93]

[0001193125-14-297927:mdna:95]
Capital expenditures totaled approximately $4.9 million and $3.2 million for the six months ended June 30, 2014 and 2013, respectively. These expenditures
were primarily used to purchase manufacturing and test equipment and computer software and hardware.

[0001193125-14-297927:mdna:96]
Our combined short-term and long-term investments
decreased $57.4 million from $415.0 million at December 31, 2013 to $357.6 million at June 30, 2014. This decrease reflects the impact of our cash needs for equipment acquisitions, payments on long-term debt, share repurchases, dividends,
as well as net realized and unrealized losses and amortization of net premiums on our combined investments, partially offset by additional funds available for investment provided by our operating activities and stock option exercises by our
employees.

[0001193125-14-297927:mdna:97]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss.
At June 30, 2014 these investments included corporate bonds of $99.4 million, municipal fixed-rate bonds of $156.0 million, and municipal variable rate demand notes of $15.1 million. At December 31, 2013, these investments included
corporate bonds of $166.9 million, municipal fixed-rate bonds of $136.3 million, and municipal variable rate demand notes of $8.3 million. As of June 30, 2014, our corporate bonds, municipal fixed-rate bonds, and municipal variable rate demand
notes were classified as available-for-sale and had a combined duration of 1.1 years with an average credit rating of AA-. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain
prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-14-297927:mdna:98]
Our long-term
investments increased 0.8% from $309.2 million at December 31, 2013 to $311.6 million at June 30, 2014. Long-term investments at June 30, 2014 and December 31, 2013 included an investment in a certificate of deposit of $30.0
million and $48.3 million, respectively, which serves as collateral for our revenue bond, as discussed below. We have various equity investments included in long-term investments at a cost of $25.9 million and $24.7 million, and with a fair value of
$39.7 million and $38.5 million, at June 30, 2014 and December 31, 2013, respectively.

[0001193125-14-297927:mdna:99]
Long-term investments at June 30, 2014 and
December 31, 2013 also included $15.8 million and $15.1 million, respectively, related to our deferred compensation plans, and $1.6 million and $1.7 million, respectively, of other investments carried at cost, consisting of interests in two
private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001193125-14-297927:mdna:100]
We review our investment portfolio for potential
“other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate
charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical
declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair
value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if
any. For the three and six months ended June 30, 2014 and 2013, other-than-temporary impairment charges were not significant.

[0001193125-14-297927:mdna:101]
Financing
Activities

[0001193125-14-297927:mdna:102]
[same as prior period, unchanged from 0001193125-14-187120:mdna:101]

[0001193125-14-297927:mdna:103]
In July 2003, our Board of
Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the six months ended June 30, 2014, we paid dividends totaling $10.1
million.

[0001193125-14-297927:mdna:104]
[same as prior period, unchanged from 0001193125-14-187120:mdna:103]

[0001193125-14-297927:mdna:105]
We have amounts outstanding
under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $30.0 million and $46.5 million at June 30, 2014 and December 31, 2013, respectively. At June 30, 2014, the
estimated fair value of the Bond was approximately $29.7 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments

[0001193125-14-297927:mdna:106]
are restricted funds in the amount of $30.0 million and $48.3 million at June 30, 2014 and December 31, 2013, which is a collateral deposit against the principal amount of the
Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction
with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program.
We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. During the first quarter of 2014, we made a principal payment on the Bond of $16.5 million.

[0001193125-14-297927:mdna:107]
[same as prior period, unchanged from 0001193125-14-187120:mdna:105]

[0001193125-14-297927:mdna:108]
Since 1997, our Board of
Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 40.0 million shares of our common stock. On May 14, 2014, our Board of Directors authorized the repurchase of an
additional 5.0 million shares of our common stock (bringing the total shares authorized for repurchase to 45.0 million), which will commence upon completion of the repurchase plan announced May 1, 2013. This new authorization will be
implemented through open market or private purchases from time to time as conditions warrant.

[0001193125-14-297927:mdna:109]
During the six months ended June 30, 2014, we
repurchased 2.3 million shares of our common stock at an average price of $22.73 per share. We currently have the authority to purchase an additional 6.1 million shares of our common stock under the current plans approved by the Board of
Directors.

[0001193125-14-297927:mdna:110]
[same as prior period, unchanged from 0001193125-14-187120:mdna:107]

[0001193125-14-297927:mdna:111]
To accommodate
employee stock option exercises, we issued 0.1 million shares of treasury stock for $1.8 million during the six months ended June 30, 2014. During the six months ended June 30, 2013, we issued 45 thousand shares of treasury stock
for $0.8 million.

[0001193125-14-297927:mdna:112]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001193125-14-297927:mdna:113]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or
other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the six months ended June 30, 2014, the only material change in contractual obligations and commercial
commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2013 filed on February 27, 2014 with the SEC was due to a $16.5 million principal payment on our taxable revenue bond.

[0001193125-14-297927:mdna:114]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2014, of
which $7.7 million has been applied to these commitments.

[0001193125-14-297927:mdna:115]
FACTORS THAT COULD AFFECT OUR FUTURE RESULTS

[0001193125-14-297927:mdna:116]
The following are some of the risks that could affect our financial performance or could cause actual results to differ materially from those expressed or
implied in our forward-looking statements:

[0001193125-14-297927:mdna:117]
[same as prior period, unchanged from 0001193125-14-187120:mdna:114]

[0001193125-14-297927:mdna:118]
[same as prior period, unchanged from 0001193125-14-187120:mdna:115]

[0001193125-14-297927:mdna:119]
[same as prior period, unchanged from 0001193125-14-187120:mdna:117]

[0001193125-14-297927:mdna:120]
[same as prior period, unchanged from 0001193125-14-187120:mdna:118]

[0001193125-14-297927:mdna:121]
[same as prior period, unchanged from 0001193125-14-187120:mdna:119]

[0001193125-14-297927:mdna:122]
[same as prior period, unchanged from 0001193125-14-187120:mdna:120]

[0001193125-14-297927:mdna:123]
[same as prior period, unchanged from 0001193125-14-187120:mdna:121]

[0001193125-14-297927:mdna:124]
[same as prior period, unchanged from 0001193125-14-187120:mdna:122]

[0001193125-14-297927:mdna:125]
[same as prior period, unchanged from 0001193125-14-187120:mdna:123]

[0001193125-14-297927:mdna:126]
[same as prior period, unchanged from 0001193125-14-187120:mdna:124]

[0001193125-14-297927:mdna:127]
[same as prior period, unchanged from 0001193125-14-187120:mdna:125]

[0001193125-14-297927:mdna:128]
[same as prior period, unchanged from 0001193125-14-187120:mdna:126]

[0001193125-14-297927:mdna:129]
[same as prior period, unchanged from 0001193125-14-187120:mdna:127]

[0001193125-14-297927:mdna:130]
[same as prior period, unchanged from 0001193125-14-187120:mdna:128]

[0001193125-14-297927:mdna:131]
[same as prior period, unchanged from 0001193125-14-187120:mdna:129]

[0001193125-14-297927:mdna:132]
[same as prior period, unchanged from 0001193125-14-187120:mdna:130]

[0001193125-14-297927:mdna:133]
[same as prior period, unchanged from 0001193125-14-187120:mdna:131]

[0001193125-14-297927:mdna:134]
[same as prior period, unchanged from 0001193125-14-187120:mdna:132]

[0001193125-14-297927:mdna:135]
[same as prior period, unchanged from 0001193125-14-187120:mdna:133]

[0001193125-14-297927:mdna:136]
[same as prior period, unchanged from 0001193125-14-187120:mdna:134]

[0001193125-14-297927:mdna:137]
[same as prior period, unchanged from 0001193125-14-187120:mdna:135]

[0001193125-14-297927:mdna:138]
[same as prior period, unchanged from 0001193125-14-187120:mdna:136]

[0001193125-14-297927:mdna:139]
[same as prior period, unchanged from 0001193125-14-187120:mdna:137]

[0001193125-14-297927:mdna:140]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-14-297927:mdna:141]
[same as prior period, unchanged from 0001193125-14-187120:mdna:140]

[0001193125-14-297927:mdna:142]
[same as prior period, unchanged from 0001193125-14-187120:mdna:141]

[0001193125-14-297927:mdna:143]
|  | • |  | If we are unable to successfully develop and maintain relationships with system integrators, service providers, and enterprise value added resellers, our sales may be negatively affected. |

[0001193125-14-297927:mdna:144]
[same as prior period, unchanged from 0001193125-14-187120:mdna:143]

[0001193125-14-297927:mdna:145]
[same as prior period, unchanged from 0001193125-14-187120:mdna:144]

[0001193125-14-297927:mdna:146]
[same as prior period, unchanged from 0001193125-14-187120:mdna:145]

[0001193125-14-297927:mdna:147]
[same as prior period, unchanged from 0001193125-14-187120:mdna:146]

[0001193125-14-297927:mdna:148]
[same as prior period, unchanged from 0001193125-14-187120:mdna:147]

[0001193125-14-297927:mdna:149]
[same as prior period, unchanged from 0001193125-14-187120:mdna:148]

[0001193125-14-297927:mdna:150]
[same as prior period, unchanged from 0001193125-14-187120:mdna:149]

[0001193125-14-297927:mdna:151]
[same as prior period, unchanged from 0001193125-14-187120:mdna:150]

[0001193125-14-297927:mdna:152]
34
