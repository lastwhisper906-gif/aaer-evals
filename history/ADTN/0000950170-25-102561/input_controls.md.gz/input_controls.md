# ADTN 10-Q controls and the auditor's report


## item_4_controls

[0000950170-25-102561:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000950170-25-102561:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000950170-25-102561:item_4_controls:3]
We maintain disclosure controls and procedures that are designed to ensure that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000950170-25-102561:item_4_controls:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e)) under the Exchange Act. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that due to the material weaknesses in our internal control over financial reporting described below, our disclosure controls and procedures were not effective as of June 30, 2025.

[0000950170-25-102561:item_4_controls:5]
Material Weaknesses in Internal Control over Financial Reporting

[0000950170-25-102561:item_4_controls:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. In its assessment of the effectiveness of internal control over financial reporting as of June 30, 2025, management determined that there were deficiencies in Adtran’s internal control over financial reporting that constituted material weaknesses that continue to exist as of June 30, 2025. Such material weaknesses were as follows:

[0000950170-25-102561:item_4_controls:7]
•
Adtran did not design and maintain effective controls in response to the risks of material misstatement. Specifically, changes to existing controls or the implementation of new controls have not been sufficient to respond to changes to the risks of material misstatement to financial reporting.

[0000950170-25-102561:item_4_controls:8]
•
Adtran did not design and maintain effective controls relating to communicating accurate information internally and with those charged with governance. This includes providing information pursuant to objectives, responsibilities and functions of internal control.

[0000950170-25-102561:item_4_controls:9]
These material weaknesses contributed to the following additional material weaknesses:

[0000950170-25-102561:item_4_controls:10]
•
Adtran did not design and maintain effective controls over financial statement preparation, presentation and disclosure commensurate with its financial reporting requirements. Specifically, Adtran did not design and maintain effective controls over the presentation and disclosure of transactions, including non-controlling interest.

[0000950170-25-102561:item_4_controls:11]
•
Adtran did not design and maintain effective controls to address the initial application of complex accounting standards and accounting of non-routine, unusual or complex events and transactions. Specifically, Adtran did not design and maintain effective controls to timely analyze and account for (i) non-controlling interest and (ii) the receivable purchase and servicing agreement.

[0000950170-25-102561:item_4_controls:12]
•
Adtran did not design and maintain effective controls over an inventory suspense account. Specifically, certain inventory activity was not reviewed at a sufficient level of precision to identify the nature and aging of the individual inventory suspense account activity.

[0000950170-25-102561:item_4_controls:13]
The material weaknesses resulted in the restatements and revisions of immaterial adjustments to our consolidated financial statements for the years ended December 31, 2022, December 31, 2023 and December 31, 2024, as well as the condensed consolidated financial statements for the quarterly and year-to-date periods ended September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024, June 30, 2024 and September 30, 2024. The material weaknesses also resulted in material adjustments that were corrected prior to the issuance of the condensed consolidated financial statements for the quarterly period ended March 31, 2025. Additionally, these material weaknesses could result in misstatements of Adtran’s accounts or disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0000950170-25-102561:item_4_controls:14]
Management’s Remediation Efforts

[0000950170-25-102561:item_4_controls:15]
To remediate the material weaknesses in Adtran’s internal control over financial reporting related to the risks of material misstatement, including financial statement preparation, presentation and disclosure of transactions and the non-controlling interest, Adtran has begun to implement its remediation plan that included the introduction of new or enhanced controls over the reconciliation and review of Adtran's consolidated financial statements, global identification and reassessment of all key processes and controls, increased training and awareness of control activities, and increased scrutiny on control performance and documentation standards. Adtran's management believes that the continuation of its remediation plan along with the foregoing actions will support the improvement of the Company’s internal control over financial reporting, and, through its efforts to identify, design, and implement the necessary control activities, will be effective in remediating such material weaknesses.

[0000950170-25-102561:item_4_controls:16]
56

[0000950170-25-102561:item_4_controls:17]
To remediate the material weaknesses in Adtran’s internal control over financial reporting relating to accounting of non-routine, unusual or complex events and transactions for non-controlling interest and the receivable purchase and servicing agreement, Adtran has implemented a remediation plan that involved introducing new controls over the identification and review of contracts, transactions or arrangements that may result in a financial obligation including the use of an accounting third-party consultant as needed to ensure proper presentation of these items within its financial statements. These controls have been in place since the third quarter of 2024.

[0000950170-25-102561:item_4_controls:18]
To remediate the material weakness relating to the communication of accurate information internally and with those charged with governance, Adtran has begun to implement a remediation plan that includes the establishment of a cross-functional internal control and communication policy, the consolidation and refinement of reporting processes, the implementation of a centralized communication platform, enhanced internal control policies, training sessions for personnel on internal control expectations, and the strengthening of the internal audit function’s role in testing the effectiveness of communication-related controls on a periodic basis.

[0000950170-25-102561:item_4_controls:19]
To remediate the material weakness relating to maintaining effective controls over an inventory suspense account, Adtran has implemented a remediation plan that includes the re-design of Adtran’s reconciliation workflow for inventory and cost of goods sold accounts, enhanced ERP system configurations, customized reconciliation tools that provide exception-based reporting, training sessions for personnel on inventory and cost of goods sold recognition principles, enhanced review and oversight through a formal review process within an automated reconciliation tool and enhanced review procedures.

[0000950170-25-102561:item_4_controls:20]
We have implemented certain of the above-referenced controls and are in the process of testing their effectiveness, and we both plan to initiate and have begun to initiate certain other controls. We will continue to devote significant time and attention to these remediation efforts. As Adtran continues to evaluate and work to improve its internal control over financial reporting, management may decide to take additional measures to address the material weaknesses or determine to modify the remediation plans described above. Until the remediation steps set forth above, including the implementation of all necessary control activities that we identify, are fully completed, and there has been time for us to conclude through testing that the control activities are operating effectively, the material weaknesses described above will not be considered remediated.

[0000950170-25-102561:item_4_controls:21]
Changes in Internal Control over Financial Reporting

[0000950170-25-102561:item_4_controls:22]
There were no changes in Adtran’s internal control over financial reporting that occurred during the most recent fiscal quarter covered by this report that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.

[0000950170-25-102561:item_4_controls:23]
57
