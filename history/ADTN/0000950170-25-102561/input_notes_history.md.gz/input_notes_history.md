# ADTN note change history — 0000950170-25-075374 → 0000950170-25-102561


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-08-05):
[0000950170-25-102561:note_history:1]
In addition to such Legal Matters, the Company is a party to appraisal proceedings relating to the DPLTA which were originally filed with the Landgericht Meiningen (Meiningen Regional Court) on February 3, 2023. The DPLTA provides that Adtran Networks shareholders (other than the Company) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest or (ii) to remain Adtran Networks shareholders and receive recurring cash compensation of €0.52 per share for each full fiscal year of Adtran Networks. The appraisal proceedings, which were initiated by certain minority shareholders of Adtran Networks, challenge the adequacy of both forms of compensation. While the Company believes that the compensation offered in connection with the DPLTA is fair, it notes that German courts often adjudicate increases of the cash compensation to plaintiffs in varying amounts in connection with German appraisal proceedings. Therefore, the Company cannot rule out that the court or an appellate court may increase the cash compensation owed to the minority Adtran Networks shareholders. Given the stage of the appraisal proceedings, the Company is currently unable to predict the likely outcome or estimate the potential financial impact, if any, of the appraisal proceedings. If a ruling were to occur and be upheld upon appeal that required the Company to pay significant additional cash compensation to the Adtran Networks minority shareholders, there exists the possibility of a material adverse effect on our financial position and results of operations for the period in which the ruling occurs or future periods.
  (was, 2025-05-20, similarity 0.9909):
[0000950170-25-075374:note_history:1]
In addition to such Legal Matters, the Company is a party to appraisal proceedings relating to the DPLTA which were originally filed with the Landgericht Meiningen (Meiningen District Court) on February 3, 2023. The DPLTA provides that Adtran Networks shareholders (other than the Company) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest or (ii) to remain Adtran Networks shareholders and receive recurring cash compensation of €0.52 per share for each full fiscal year of Adtran Networks. The appraisal proceedings, which were initiated by certain minority shareholders of Adtran Networks, challenge the adequacy of both forms of compensation. While the Company believes that the compensation offered in connection with the DPLTA is fair, it notes that German courts often adjudicate increases of the cash compensation to plaintiffs in varying amounts in connection with German appraisal proceedings. Therefore, the Company cannot rule out that the first instance court or an appellate court may increase the cash compensation owed to the minority Adtran Networks shareholders. Given the stage of the appraisal proceedings, the Company is currently unable to predict the likely outcome or estimate the potential financial impact, if any, of the appraisal proceedings. If a ruling were to occur and be upheld upon appeal that required the Company to pay significant additional cash compensation to the Adtran Networks minority shareholders, there exists the possibility of a material adverse effect on our financial position and results of operations for the period in which the ruling occurs or future periods.

- changed (2025-08-05):
[0000950170-25-102561:note_history:2]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of June 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, the Company would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.8 million or $385.2 million, based on an exchange rate as of June 30, 2025, and reflecting interest accrued through June 30, 2025, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The court has decided a procedural matter in the DPLTA appraisal proceedings; the parties may or may not choose to appeal such decision, if able, and the proceeding for the trial on the merits of the DPLTA will continue. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to
  (was, 2025-05-20, similarity 0.7425):
[0000950170-25-075374:note_history:2]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of March 31, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, the Company would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.5 million or approximately $366.1 million, based on an exchange rate as of March 31, 2025, and reflecting interest accrued through March 31, 2025, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a ruling on a procedural matter in the DPLTA appraisal proceedings during the latter half of 2025 or 2026, which ruling, depending on outcome, will likely be appealed and may take 6-12 months to be decided on appeal. The Company does not expect that a trial on the merits of the DPLTA appraisal proceedings will commence until the procedural matter has been resolved. The proceeding for the trial on the merits of the DPLTA will likely take a minimum of 12 months for a ruling and such ruling may likewise be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

- added (2025-08-05):
[0000950170-25-102561:note_history:3]
take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

- changed (2025-08-05):
[0000950170-25-102561:note_history:4]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of June 30, 2025) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholders meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended June 30, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation. During the six months ended June 30, 2025 and 2024, we accrued $4.8 million and $5.0 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.
  (was, 2025-05-20, similarity 0.8647):
[0000950170-25-075374:note_history:4]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million (or $9.7 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholders meeting is scheduled for June 27, 2025 and, therefore, the Annual Recurring Compensation will be due on July 2, 2025. During the three months ended March 31, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

- added (2025-08-05):
[0000950170-25-102561:note_history:5]
For the three and six months ended June 30, 2025, approximately 0.9 million shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million, or $19.4 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or $20 thousand and $25 thousand, respectively, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders.

- changed (2025-08-05):
[0000950170-25-102561:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2025 and December 31, 2024, we had commitments related to these bonds totaling $16.9 million and $15.7 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2025-05-20, similarity 0.9913):
[0000950170-25-075374:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2025 and December 31, 2024, we had commitments related to these bonds totaling $15.2 million and $15.7 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2025-08-05):
[0000950170-25-102561:note_history:7]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of June 30, 2025, purchase obligations totaled $192.7 million.
  (was, 2025-05-20, similarity 0.9918):
[0000950170-25-075374:note_history:7]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of March 31, 2025, purchase obligations totaled $203.9 million.

- removed (2025-08-05):
[0000950170-25-075374:note_history:8]
For the three months ended March 31, 2025 and 2024, less than one thousand shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €12 thousand and €4 thousand, respectively, or approximately $13 thousand and $5 thousand based on the applicable exchange rates at the time of the transactions, were paid to Adtran Networks shareholders.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-05):
[0000950170-25-102561:note_history:9]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications, and federal, state and local government agencies. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.
  (was, 2025-05-20, similarity 0.9985):
[0000950170-25-075374:note_history:9]
ADTRAN Holdings, Inc. (“Adtran” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

- changed (2025-08-05):
[0000950170-25-102561:note_history:10]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of June 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.8 million or $385.2 million, based on an exchange rate as of June 30, 2025, and reflecting interest accrued through June 30, 2025 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The court has decided a procedural matter in the DPLTA appraisal proceedings; the parties may or may not choose to appeal such decision, if able, and the proceeding for the trial on the merits of the DPLTA will continue. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.
  (was, 2025-05-20, similarity 0.7912):
[0000950170-25-075374:note_history:10]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of March 31, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.5 million or approximately $366.1 million, based on an exchange rate as of March 31, 2025, and reflecting interest accrued through March 31, 2025 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a ruling on a procedural matter in the DPLTA appraisal proceedings during the latter half of 2025 or 2026, which ruling, depending on outcome, will likely be appealed and may take 6-12 months to be decided on appeal. The Company does not expect that a trial on the merits of the DPLTA appraisal proceedings will commence until the procedural matter has been resolved. The proceeding for the trial on the merits of the DPLTA will likely take a minimum of 12 months for a ruling and such ruling may likewise be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

- changed (2025-08-05):
[0000950170-25-102561:note_history:11]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of June 30, 2025) per year assuming none of the minority Adtran Networks shareholders as of June 30, 2025 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended June 30, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation. During the six months ended June 30, 2025 and 2024, we accrued $4.8 million and $5.0 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.
  (was, 2025-05-20, similarity 0.8399):
[0000950170-25-075374:note_history:11]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million (or $9.7 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders as of March 31, 2025 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for June 27, 2025 and, therefore, the Annual Recurring Compensation will be due on July 2, 2025. During the three months ended March 31, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.

- changed (2025-08-05):
[0000950170-25-102561:note_history:12]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended five times. The Company had access to $156.5 million on its Credit Facility for future borrowings; however, as of June 30, 2025, the Company was limited to additional borrowings of $66.8 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x. See Note 10, Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement.
  (was, 2025-05-20, similarity 0.9685):
[0000950170-25-075374:note_history:12]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. The Company had access to $180.7 million on its Credit Facility for future borrowings; however, as of March 31, 2025 and the date of this filing the Company was limited to additional borrowings of $25.8 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x. See Note 10, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement.

- added (2025-08-05):
[0000950170-25-102561:note_history:13]
As of June 30, 2025, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet the substantial majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three and six months ended June 30, 2025, approximately 0.9 million shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million or $19.4 million based on the applicable exchange rates at the time of the transactions being paid to Adtran Networks shareholders. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or $20 thousand and $25 thousand, respectively, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact the date of a decision by the court on the merits of the case is uncertain, it will most likely take a minimum of 12 months for a ruling and, thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

- changed (2025-08-05):
[0000950170-25-102561:note_history:14]
The Company experienced revenue declines in the year ended December 31, 2024. However, customers have started to replenish their inventories to meet increasing demand. Revenue began to increase in the first half of 2025 and management expects orders and billings to continue to increase during the remainder of 2025. The Company continues to implement plans to preserve cash liquidity to maintain compliance with the Company’s covenants in case of further impacts related to customer inventory reduction initiatives and uncertain macroeconomic conditions. Additionally, the Company suspended dividend payments and effectuated a business efficiency program (the "Business Efficiency Program"), which targeted the reduction of ongoing operating expenses and focused on enhancing capital efficiency. The Business Efficiency Program was completed as of December 31, 2024. The Company has determined that it is probable that the sale of its headquarters in Huntsville will occur within the next twelve months after December 31, 2024. The Company may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that it can meet its needs and obligations and maintain compliance with its debt covenants.
  (was, 2025-05-20, similarity 0.9175):
[0000950170-25-075374:note_history:14]
The Company experienced revenue declines in the year ended December 31, 2024. However, customers have started to replenish their inventories to meet increasing demand and management expects orders and billings to increase during the remainder of 2025. The Company continues to implement plans to preserve cash liquidity to maintain compliance with the Company’s covenants in case of further impacts related to customer inventory reduction initiatives and uncertain macroeconomic conditions. Additionally, the Company suspended dividend payments and effectuated a business efficiency program (the "Business Efficiency Program"), which targeted the reduction of ongoing operating expenses and focused on enhancing capital efficiency. The Business Efficiency Program was completed as of December 31, 2024, other than the Company's aim of selling its headquarters. The Company has determined that it is probable that the sale of its headquarters in Huntsville will occur within the next twelve months after December 31, 2024. The Company may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that it can meet its needs and obligations and maintain compliance with its debt covenants.

- changed (2025-08-05):
[0000950170-25-102561:note_history:15]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and to support our ability to continue to comply with our debt covenants under the Credit Facility and continue as a going concern, for at least the next twelve months, from the issuance of these financial statements. See Note 10, Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo Credit agreement.
  (was, 2025-05-20, similarity 0.9805):
[0000950170-25-075374:note_history:15]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and to support our ability to continue to comply with our debt covenants under the Credit Facility and continue as a going concern, for at least the next twelve months, from the issuance of these financial statements. See Note 10, Revolving Credit Agreements, for additional information regarding the terms of the Wells Fargo Credit agreement.

- added (2025-08-05):
[0000950170-25-102561:note_history:16]
During the six months ended June 30, 2025, there were no significant changes to our critical accounting policies as described in the financial statements contained in the 2024 Form 10-K/A.

- changed (2025-08-05):
[0000950170-25-102561:note_history:17]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Amendment No. 1 to the Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on May 20, 2025 ("2024 Form 10-K/A").
  (was, 2025-05-20, similarity 0.9964):
[0000950170-25-075374:note_history:17]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Amendment No. 1 to the Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on May 20, 2025 (the "2024 Form 10-K/A").

- added (2025-08-05):
[0000950170-25-102561:note_history:18]
As discussed in the financial statements as of and for the year ended December 31, 2024 included in our 2024 Form 10-K/A, we identified errors in our previously issued financial statements related to the historical accounting for certain inventory and cost of goods sold transactions (“Adjustment”). The affected periods included the annual periods ended December 31, 2023 and 2024 and the interim periods ended March 31, 2024, June 30, 2024 and September 30, 2024.

- changed (2025-08-05):
[0000950170-25-102561:note_history:19]
In connection with the identification of the Adjustment, the Audit Committee oversaw an internal investigation into the circumstances surrounding the Adjustment and its impact on the Company’s historical financial statements. Based on the findings of the internal investigation, it was determined that the underlying errors giving rise to the Adjustment were not properly addressed in the Company’s previously filed financial statements as of and for the years ended December 31, 2024 and 2023 and were not communicated to the Audit Committee or the independent auditors prior to the filing of the initial 2024 Annual Report on Form 10-K. As described in Part I, Item 4 of this report, the Company is taking certain remedial actions to address the material weaknesses in its internal controls associated with these findings. On August 4, 2025, we received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation, which we will respond to accordingly.
  (was, 2025-05-20, similarity 0.8324):
[0000950170-25-075374:note_history:19]
In connection with the identification of the Adjustment, the Audit Committee has overseen an internal investigation into the circumstances surrounding the Adjustment and its impact on the Company’s historical financial statements. Based on the findings of the internal investigation, which is substantially complete, it has been determined that the underlying errors giving rise to the Adjustment were not properly addressed in the Company’s previously filed financial statements as of and for the years ended December 31, 2024 and 2023 and was not communicated to the Audit Committee or the independent auditors prior to the filing of the initial 2024 Annual Report on Form 10-K. As described in Part I, Item 4 of this report, the Company is taking certain remedial actions to address the material weaknesses in its internal controls associated with these findings.

- changed (2025-08-05):
[0000950170-25-102561:note_history:20]
The identified errors referenced above impacted the Condensed Consolidated Financial Statements as of and for the three and six months ended June 30, 2024, among other periods as previously disclosed. Below is a summary description of the significant errors in the Company's Condensed Consolidated Financial Statements as of and for the three and six months ended June 30, 2024:
  (was, 2025-05-20, similarity 0.6132):
[0000950170-25-075374:note_history:20]
The identified errors impacted the Condensed Consolidated Financial Statements as of and for the three months ended March 31, 2024, among other periods as previously disclosed. Below is a summary description of the significant errors in the Company's Condensed Consolidated Financial Statements as of and for the quarter ended March 31, 2024:

- changed (2025-08-05):
[0000950170-25-102561:note_history:21]
ADJ 2 - For the periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024, the Company remeasured the RNCI each quarter-end at the current exchange rate of euros to U.S. Dollar. The Company treated the RNCI as a monetary mezzanine equity instrument but should have treated it as a non-monetary mezzanine equity instrument not subject to remeasurement.
  (was, 2025-05-20, similarity 0.9095):
[0000950170-25-075374:note_history:21]
ADJ 2 - For the periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024 the Company remeasured the redeemable non-controlling interest each quarter-end at the current exchange rate of euros to U.S. Dollar. The Company treated the redeemable non-controlling interest as a monetary mezzanine equity instrument but should have treated it as a non-monetary mezzanine equity instrument not subject to remeasurement.

- changed (2025-08-05):
[0000950170-25-102561:note_history:22]
We assessed the materiality of the errors on prior period consolidated financial statements in accordance with SEC Staff Accounting Bulletin No. 99, “Materiality,” codified in ASC Topic 250, Accounting Changes and Error Corrections. Based on this assessment, we concluded that the errors, in the aggregate, are material to the June 30, 2024 financial statements and therefore, we have restated those
  (was, 2025-05-20, similarity 0.7166):
[0000950170-25-075374:note_history:22]
We assessed the materiality of the errors on prior period consolidated financial statements in accordance with SEC Staff Accounting Bulletin No. 99, “Materiality,” codified in ASC Topic 250, Accounting Changes and Error Corrections. Based on this assessment, we concluded that the errors, in the aggregate, are material to the March 31, 2024 financial statements and therefore, we are restating those financial statements herein. Furthermore, we made adjustments to correct for other previously identified immaterial errors. The

- changed (2025-08-05):
[0000950170-25-102561:note_history:23]
financial statements herein. Furthermore, we made adjustments to correct for other previously identified immaterial errors. The Company has also restated impacted amounts within the accompanying footnotes to the Condensed Consolidated Financial Statements. See Note 18 for further information about the restatement.
  (was, 2025-05-20, similarity 0.744):
[0000950170-25-075374:note_history:23]
Company has also restated impacted amounts within the accompanying footnotes to the Condensed Consolidated Financial Statements. See Note 18 for further information about the restatement.

- changed (2025-08-05):
[0000950170-25-102561:note_history:24]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, currency fluctuations and political tensions as of June 30, 2025, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.
  (was, 2025-05-20, similarity 0.9943):
[0000950170-25-075374:note_history:24]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, currency fluctuations and political tensions as of March 31, 2025, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.

- changed (2025-08-05):
[0000950170-25-102561:note_history:25]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2023-09 will have on our disclosures.
  (was, 2025-05-20, similarity 0.9549):
[0000950170-25-075374:note_history:25]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2023-09 will have on our disclosures.

- removed (2025-08-05):
[0000950170-25-075374:note_history:26]
As of March 31, 2025, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet the substantial majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three months ended March 31, 2025 and 2024, less than one thousand shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €12 thousand and €4 thousand, respectively, or approximately $13 thousand and $5 thousand based on the applicable exchange rates at the time of the transaction, were paid to Adtran Networks shareholders. On April 14, 2025, 0.4 million shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €7.0 million or approximately $7.5 million, based on the applicable exchange rate at the time of the transaction, will be paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact that the Company expects to receive a procedural decision during 2025 or 2026 that will likely be appealed and, while the date of a decision by the court on the merits of the case is uncertain, it will likely take a minimum of 12 months for a ruling and, thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

- removed (2025-08-05):
[0000950170-25-075374:note_history:27]
As discussed in the financial statements as of and for the year ended December 31, 2024 included in our amended 2024 Annual Report on Form 10-K/A, we identified errors in our previously issued financial statements. In addition, on May 13, 2025, the Company announced that it needed additional time to complete its quarterly reporting process as a result of the restatements to the annual periods ended December 31, 2023 and 2024 and for the interim periods ended March 31, 2024, June 30, 2024 and September 30, 2024, as well as to complete its evaluation of internal control over financial reporting as of December 31, 2024 as a result of errors related to the historical accounting for certain inventory and cost of goods sold transactions in its Adtran Networks SE subsidiary (the “Adjustment”). As a result, the Company filed a Form 12b-25 with the SEC and delayed the filing of this report.

- removed (2025-08-05):
[0000950170-25-075374:note_history:28]
Reclassification of Prior Year Presentation

- removed (2025-08-05):
[0000950170-25-075374:note_history:29]
Certain prior year amounts have been reclassified for consistency with current year presentation. These reclassifications had no effect on reported results of operations. An adjustment has been made to the Consolidated Statement of Cash Flows for the quarter ended March 31, 2024, to reclassify between Property, Plant and Equipment and Intangible Assets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-05):
[0000950170-25-102561:note_history:30]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Wells Fargo credit agreement |  | $ | 190,180 |  |  | $ | 189,576 |  |
| Total non-current revolving credit facility |  | $ | 190,180 |  |  | $ | 189,576 |  |
  (was, 2025-05-20, similarity 0.9785):
[0000950170-25-075374:note_history:30]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2025 |  |  | December 31, 2024 |  |
| Wells Fargo credit agreement |  | $ | 190,085 |  |  | $ | 189,576 |  |
| Total non-current revolving credit facility |  | $ | 190,085 |  |  | $ | 189,576 |  |

- added (2025-08-05):
[0000950170-25-102561:note_history:31]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to the Credit Agreement, dated August 9, 2023 (“Amendment No. 1”), the Second Amendment to the Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to the Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), the Fourth Amendment to the Credit Amendment, dated June 4, 2024 ("Amendment No. 4"), and the Fifth Amendment to the Credit Agreement, dated May 6, 2025 (“Amendment No. 5” and, collectively with Amendment No. 1, Amendment No. 2, Amendment No. 3, and Amendment No. 4, the “Credit Agreement Amendments”; and the Original Credit Agreement, as amended by the Credit Agreement Amendments, the “Amended Credit Agreement”). Amendment No. 5, together with a substantially concurrent prepayment by Adtran Networks of outstanding revolving loans under the German Borrower Sublimit (as defined in the Amended Credit Agreement, which term includes Amendment No. 5 for the purposes of this note) in the amount of $24.0 million, among other things, resulted in (i) a permanent partial reduction in the total commitments under the Amended Credit Agreement from $374.0 million to $350.0 million, (ii) a reduction of the German Borrower Sublimit from $74.0 million to $50.0 million, and (iii) a reduction of the German Commitment Reduction Threshold (as defined in the Amended Credit Agreement) to $25.0 million. The lenders also waived certain events of default related to among others, inaccuracies in the financial statements that were previously delivered to the lenders by the Company with respect to the fiscal quarters ended June 30, 2024 and September 30, 2024, and breaches of the Consolidated Fixed Charge Coverage Ratio (as defined in the Amended Credit Agreement) financial covenant for the fiscal quarters ended June 30, 2024 and September 30, 2024. As of June 30, 2025, the Amended Credit Agreement provided for a secured revolving credit facility of up to $350.0 million of borrowings, $50.0 million of which is solely available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below).

- changed (2025-08-05):
[0000950170-25-102561:note_history:32]
As of June 30, 2025, the Company’s borrowings under the revolving line of credit were $190.2 million, of which approximately $165.0 million were borrowed by the U.S. Borrower and $25.2 million were borrowed under the Subline by Adtran Networks, who became a party to the Amended Credit Agreement in June 2024. The credit facilities provided under the Amended Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $350.0 million total revolving facility for the issuance of letters of credit. As of June 30, 2025, the U.S. Borrower had a total of $3.3 million in letters of credit under the Amended Credit Agreement, leaving a net amount (after giving effect to the $190.2 million of outstanding borrowings described above) of $156.5 million available for future borrowings; however, as of June 30, 2025, the Company was limited to additional borrowings of $66.8 million based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the exchange offer consideration.
  (was, 2025-05-20, similarity 0.8028):
[0000950170-25-075374:note_history:32]
As of March 31, 2025, the Company’s borrowings under the revolving line of credit were $190.1 million, of which approximately $141.0 million were borrowed by the U.S. Borrower and $49.1 million were borrowed under the Subline by Adtran Networks (as defined below), who became a party to the Amended Credit Agreement in June 2024. The credit facilities provided under the Amended Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $374.0 million total revolving facility for the issuance of letters of credit. As of March 31, 2025, the U.S. Borrower had a total of $3.2 million in letters of credit under the Amended Credit Agreement, leaving a net amount (after giving effect to the $190.1 million of outstanding borrowings described above) of $180.7 million available for future borrowings;

- changed (2025-08-05):
[0000950170-25-102561:note_history:33]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $350.0 million revolving commitments in an aggregate amount of $50.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold of $50.0 million may be lowered from time to time pursuant to the terms of the Amended Credit Agreement. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to Adtran Networks). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.
  (was, 2025-05-20, similarity 0.9821):
[0000950170-25-075374:note_history:33]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $374.0 million revolving commitments in an aggregate amount of $100.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold (as defined below) will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold was initially $75.0 million and may be lowered from time to time pursuant to the terms of the Amended Credit Agreement. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to Adtran Networks). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

- changed (2025-08-05):
[0000950170-25-102561:note_history:34]
All U.S. borrowings under the Amended Credit Agreement bear interest at a rate tied to the Base Rate (as defined in the Amended Credit Agreement) or SOFR, at the Company’s option, and all E.U. borrowings bear interest at a rate tied to the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent), in each case plus applicable margins which vary based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Amended Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable. As of June 30, 2025, the weighted average interest rate on our revolving credit agreements was 8.55%.
  (was, 2025-05-20, similarity 0.9942):
[0000950170-25-075374:note_history:34]
All U.S. borrowings under the Amended Credit Agreement bear interest at a rate tied to the Base Rate (as defined in the Amended Credit Agreement) or SOFR, at the Company’s option, and all E.U. borrowings bear interest at a rate tied to the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent), in each case plus applicable margins which vary based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Amended Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable. As of March 31, 2025, the weighted average interest rate on our revolving credit agreements was 8.55%.

- changed (2025-08-05):
[0000950170-25-102561:note_history:35]
The Company made certain representations and warranties to the lenders in the Amended Credit Agreement that are customary for credit arrangements of this type. The Company also agreed to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a “Springing Covenant Period,” as defined below) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such ratios are defined in the Amended Credit Agreement). A “Springing Covenant Event” occurs when at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of August 9, 2023 have been tendered and purchased by the Company. Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During a Springing Covenant Period, the Company’s leverage ratios are increased. In addition, the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. As of June 30, 2025, the Company was in compliance with all covenants.
  (was, 2025-05-20, similarity 0.9965):
[0000950170-25-075374:note_history:35]
The Company made certain representations and warranties to the lenders in the Amended Credit Agreement that are customary for credit arrangements of this type. The Company also agreed to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a “Springing Covenant Period,” as defined below) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such ratios are defined in the Amended Credit Agreement). A “Springing Covenant Event” occurs when at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of August 9, 2023 have been tendered and purchased by the Company. Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During a Springing Covenant Period, the Company’s leverage ratios are increased. In addition, the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. As of March 31, 2025, the Company was in compliance with all covenants.

- removed (2025-08-05):
[0000950170-25-075374:note_history:36]
Wells Fargo Credit Facility

- removed (2025-08-05):
[0000950170-25-075374:note_history:37]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to the Credit Agreement, dated August 9, 2023, 2021 (“Amendment No. 1”), the Second Amendment to the Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to the Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), and the Fourth Amendment to the Credit Amendment, dated June 4, 2024 (“Amendment No. 4” and, collectively with Amendment No. 1, Amendment No. 2, and Amendment No. 3, the “Credit Agreement Amendments”; and the Original Credit Agreement, as amended by the Credit Agreement Amendments, the “Amended Credit Agreement”). As of the date of this filing, the Amended Credit Agreement provided for a secured revolving credit facility of up to $374.0 million of borrowings, $74.0 million of which is solely available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below.

- removed (2025-08-05):
[0000950170-25-075374:note_history:38]
however, as of March 31, 2025 and the date of this filing the Company was limited to additional borrowings of $25.8 million based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-05):
[0000950170-25-102561:note_history:39]
5. LONG TERM INVESTMENTS
  (was, 2025-05-20, similarity 0.7222):
[0000950170-25-075374:note_history:39]
5. INVESTMENTS

- changed (2025-08-05):
[0000950170-25-102561:note_history:40]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2025 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 238 |  |  | $ | 238 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 1,072 |  |  |  | 1,072 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 32,044 |  |  |  | 32,044 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,354 |  |  | $ | 33,354 |  |  | $ | — |  |  | $ | — |  |
  (was, 2025-05-20, similarity 0.9717):
[0000950170-25-075374:note_history:40]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,538 |  |  | $ | 5,538 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 1,068 |  |  |  | 1,068 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 30,991 |  |  |  | 30,991 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 37,597 |  |  | $ | 37,597 |  |  | $ | — |  |  | $ | — |  |

- added (2025-08-05):
[0000950170-25-102561:note_history:41]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 5,538 |  |  | $ | 5,538 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 1,068 |  |  |  | 1,068 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 30,991 |  |  |  | 30,991 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 37,597 |  |  | $ | 37,597 |  |  | $ | — |  |  | $ | — |  |

- added (2025-08-05):
[0000950170-25-102561:note_history:42]
(1)
The money market fund balances of $0.2 million and $5.5 million as of June 30, 2025 and December 31, 2024, respectively, are included in cash and cash equivalents on the balance sheet.

- changed (2025-08-05):
[0000950170-25-102561:note_history:43]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; and
  (was, 2025-05-20, similarity 0.9973):
[0000950170-25-075374:note_history:43]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly and

- removed (2025-08-05):
[0000950170-25-075374:note_history:44]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2025 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,539 |  |  | $ | 5,539 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 970 |  |  |  | 970 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 29,003 |  |  |  | 29,003 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,512 |  |  | $ | 35,512 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-05):
[0000950170-25-102561:note_history:45]
|  |  | Three Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 75,537 |  |  | $ | 8,221 |  |  | $ | 83,758 |  |  | $ | 73,615 |  |  | $ | 8,782 |  |  | $ | 82,397 |  |
| Access & Aggregation Solutions |  |  | 77,353 |  |  |  | 13,859 |  |  |  | 91,212 |  |  |  | 54,112 |  |  |  | 15,795 |  |  |  | 69,907 |  |
| Optical Networking Solutions |  |  | 66,608 |  |  |  | 23,490 |  |  |  | 90,098 |  |  |  | 51,467 |  |  |  | 22,220 |  |  |  | 73,687 |  |
| Total |  | $ | 219,498 |  |  | $ | 45,570 |  |  | $ | 265,068 |  |  | $ | 179,194 |  |  | $ | 46,797 |  |  | $ | 225,991 |  |
  (was, 2025-05-20, similarity 0.965):
[0000950170-25-075374:note_history:45]
|  |  | Three Months Ended |  |
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 71,748 |  |  | $ | 8,662 |  |  | $ | 80,410 |  |  | $ | 60,369 |  |  | $ | 9,399 |  |  | $ | 69,767 |  |
| Access & Aggregation Solutions |  |  | 75,847 |  |  |  | 13,289 |  |  |  | 89,136 |  |  |  | 67,777 |  |  |  | 13,535 |  |  |  | 81,312 |  |
| Optical Networking Solutions |  |  | 54,622 |  |  |  | 23,576 |  |  |  | 78,198 |  |  |  | 53,127 |  |  |  | 21,966 |  |  |  | 75,094 |  |
| Total |  | $ | 202,217 |  |  | $ | 45,527 |  |  | $ | 247,744 |  |  | $ | 181,273 |  |  | $ | 44,900 |  |  | $ | 226,173 |  |

- added (2025-08-05):
[0000950170-25-102561:note_history:46]
|  |  | Six Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 147,285 |  |  | $ | 16,884 |  |  | $ | 164,169 |  |  | $ | 133,984 |  |  | $ | 18,181 |  |  | $ | 152,165 |  |
| Access & Aggregation Solutions |  |  | 153,200 |  |  |  | 27,148 |  |  | $ | 180,348 |  |  |  | 121,889 |  |  |  | 29,330 |  |  | $ | 151,219 |  |
| Optical Networking Solutions |  |  | 121,230 |  |  |  | 47,065 |  |  | $ | 168,295 |  |  |  | 104,594 |  |  |  | 44,186 |  |  | $ | 148,780 |  |
| Total |  | $ | 421,715 |  |  | $ | 91,097 |  |  | $ | 512,812 |  |  | $ | 360,467 |  |  | $ | 91,697 |  |  | $ | 452,164 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-05):
[0000950170-25-102561:note_history:47]
|  |  | Three Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 75,537 |  |  | $ | 8,221 |  |  | $ | 83,758 |  |  | $ | 73,615 |  |  | $ | 8,782 |  |  | $ | 82,397 |  |
| Access & Aggregation Solutions |  |  | 77,353 |  |  |  | 13,859 |  |  |  | 91,212 |  |  |  | 54,112 |  |  |  | 15,795 |  |  |  | 69,907 |  |
| Optical Networking Solutions |  |  | 66,608 |  |  |  | 23,490 |  |  |  | 90,098 |  |  |  | 51,467 |  |  |  | 22,220 |  |  |  | 73,687 |  |
| Total |  | $ | 219,498 |  |  | $ | 45,570 |  |  | $ | 265,068 |  |  | $ | 179,194 |  |  | $ | 46,797 |  |  | $ | 225,991 |  |
  (was, 2025-05-20, similarity 0.965):
[0000950170-25-075374:note_history:47]
|  |  | Three Months Ended |  |
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 71,748 |  |  | $ | 8,662 |  |  | $ | 80,410 |  |  | $ | 60,369 |  |  | $ | 9,399 |  |  | $ | 69,767 |  |
| Access & Aggregation Solutions |  |  | 75,847 |  |  |  | 13,289 |  |  |  | 89,136 |  |  |  | 67,777 |  |  |  | 13,535 |  |  |  | 81,312 |  |
| Optical Networking Solutions |  |  | 54,622 |  |  |  | 23,576 |  |  |  | 78,198 |  |  |  | 53,127 |  |  |  | 21,966 |  |  |  | 75,094 |  |
| Total |  | $ | 202,217 |  |  | $ | 45,527 |  |  | $ | 247,744 |  |  | $ | 181,273 |  |  | $ | 44,900 |  |  | $ | 226,173 |  |

- added (2025-08-05):
[0000950170-25-102561:note_history:48]
|  |  | Six Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 147,285 |  |  | $ | 16,884 |  |  | $ | 164,169 |  |  | $ | 133,984 |  |  | $ | 18,181 |  |  | $ | 152,165 |  |
| Access & Aggregation Solutions |  |  | 153,200 |  |  |  | 27,148 |  |  | $ | 180,348 |  |  |  | 121,889 |  |  |  | 29,330 |  |  | $ | 151,219 |  |
| Optical Networking Solutions |  |  | 121,230 |  |  |  | 47,065 |  |  | $ | 168,295 |  |  |  | 104,594 |  |  |  | 44,186 |  |  | $ | 148,780 |  |
| Total |  | $ | 421,715 |  |  | $ | 91,097 |  |  | $ | 512,812 |  |  | $ | 360,467 |  |  | $ | 91,697 |  |  | $ | 452,164 |  |

- changed (2025-08-05):
[0000950170-25-102561:note_history:49]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2025 and December 31, 2024 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $264.9 million and $325.7 million, respectively. As of June 30, 2025, approximately 62.8% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of June 30, 2025, are related to contracts or orders that have an original expected duration of one year or less and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.
  (was, 2025-05-20, similarity 0.9857):
[0000950170-25-075374:note_history:49]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2025 and December 31, 2024 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $274.3 million and $325.7 million, respectively. As of March 31, 2025, approximately 69% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of March 31, 2025, are related to contracts or orders that have an original expected duration of one year or less and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2025-08-05):
[0000950170-25-102561:note_history:50]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Accounts receivable, net |  | $ | 164,768 |  |  | $ | 178,030 |  |
| Contract assets(1) |  | $ | 510 |  |  | $ | 631 |  |
| Unearned revenue |  | $ | 62,695 |  |  | $ | 52,701 |  |
| Non-current unearned revenue |  | $ | 24,429 |  |  | $ | 22,065 |  |
  (was, 2025-05-20, similarity 0.9841):
[0000950170-25-075374:note_history:50]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2025 |  |  | December 31, 2024 |  |
| Accounts receivable, net |  | $ | 166,519 |  |  | $ | 178,030 |  |
| Contract assets(1) |  | $ | 431 |  |  | $ | 631 |  |
| Unearned revenue |  | $ | 66,459 |  |  | $ | 52,701 |  |
| Non-current unearned revenue |  | $ | 24,082 |  |  | $ | 22,065 |  |

- changed (2025-08-05):
[0000950170-25-102561:note_history:51]
The allowance for credit losses was $1.3 million as of June 30, 2025, and December 31, 2024, related to accounts receivable.
  (was, 2025-05-20, similarity 0.848):
[0000950170-25-075374:note_history:51]
The allowance for credit losses was $1.2 million and $1.3 million as of March 31, 2025, and December 31, 2024, respectively, related to accounts receivable.

- changed (2025-08-05):
[0000950170-25-102561:note_history:52]
Receivables Purchase Agreement
  (was, 2025-05-20, similarity 0.9836):
[0000950170-25-075374:note_history:52]
Receivables Purchase Agreements

- changed (2025-08-05):
[0000950170-25-102561:note_history:53]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of June 30, 2025, totaled $18.4 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million and $0.6 million for the three months and six months ended June 30, 2025, respectively.
  (was, 2025-05-20, similarity 0.9293):
[0000950170-25-075374:note_history:53]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of March 31, 2025, totaled $11.2 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months ended March 31, 2025.

- changed (2025-08-05):
[0000950170-25-102561:note_history:54]
On December 19, 2023, the Company entered into a receivables purchase agreement (the "Prior Factoring Agreement") with a third-party financial institution which qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidation. The Prior Factoring Agreement was terminated on July 1, 2024. For the three and six months ended June 30, 2024, the Company incurred program fee expenses of $0.3 million and $0.6 million, respectively.
  (was, 2025-05-20, similarity 0.8401):
[0000950170-25-075374:note_history:54]
On December 19, 2023, the Company entered into a receivables purchase agreement (the "Prior Factoring Agreement") with a third-party financial institution which qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidation. The Prior Factoring Agreement was terminated on July 1, 2024. For the three months ended March 31, 2024, the Company incurred program fee expenses of $0.3 million.

- changed (2025-08-05):
[0000950170-25-102561:note_history:55]
No allowance for credit losses was recorded for the three and six months ended June 30, 2025 and 2024, respectively, related to contract assets.
  (was, 2025-05-20, similarity 0.9354):
[0000950170-25-075374:note_history:55]
No allowance for credit losses was recorded for the three months ended March 31, 2025 and 2024, respectively, related to contract assets.

- added (2025-08-05):
[0000950170-25-102561:note_history:56]
Of the outstanding unearned revenue balances as of December 31, 2024, $12.8 million and $34.7 million were recognized as revenue during the three and six months ended June 30, 2025, respectively. Of the $65.1 million of outstanding unearned revenue balances as of December 31, 2023, $13.7 million and $33.1 million were recognized as revenue during the three and six months ended June 30, 2024, respectively.

- removed (2025-08-05):
[0000950170-25-075374:note_history:57]
Of the outstanding unearned revenue balances as of December 31, 2024, $21.9 million were recognized as revenue during the three months ended March 31, 2025. Of the $65.1 million of outstanding unearned revenue balances as of December 31, 2023, $19.7 million were recognized as revenue during the three months ended March 31, 2024.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-08-05):
[0000950170-25-102561:note_history:58]
Annual Recurring Compensation Payment in accordance with the DPLTA

- added (2025-08-05):
[0000950170-25-102561:note_history:59]
On July 1, 2025, the Company paid $10.1 million with respect to the 2024 fiscal year Annual Recurring Compensation. See Note 13 for additional information on the Annual Recurring Compensation payment.

- added (2025-08-05):
[0000950170-25-102561:note_history:60]
Enactment of the “One Big Beautiful Bill Act”

- added (2025-08-05):
[0000950170-25-102561:note_history:61]
On July 4, 2025, the “One Big Beautiful Bill Act” (OBBBA) was signed into law, which constitutes the enactment date of the tax reconciliation bill under U.S. GAAP. Key corporate tax provisions include the restoration of 100% bonus depreciation, expensing of domestic research and experimental expenditures under Section 174A, modifications to Section 163(j) interest expense limitations, updates to the rules governing global intangible low-taxed income and foreign-derived intangible income, amendments to energy credits, and expanded Section 162(m) aggregation requirements. In accordance with ASC 740, the effects of the new tax law will be recognized in the period of enactment. The Company is currently evaluating the impact of the OBBBA, and an estimate of the financial effect is not yet available.

- removed (2025-08-05):
[0000950170-25-075374:note_history:62]
Exit Compensation Payments

- removed (2025-08-05):
[0000950170-25-075374:note_history:63]
On April 14, 2025, 0.4 million shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €7.0 million or approximately $7.5 million, based on the applicable exchange rate at the time of the transaction, was paid to Adtran Networks shareholders.

- removed (2025-08-05):
[0000950170-25-075374:note_history:64]
Fifth Amendment to Wells Fargo Credit Agreement

- removed (2025-08-05):
[0000950170-25-075374:note_history:65]
On May 6, 2025, the Company, ADTRAN, Inc., and Adtran Networks entered into a fifth amendment to the Credit Agreement ("Amendment No. 5"). Amendment No. 5, together with a substantially concurrent prepayment by the German Borrower of outstanding revolving loans under the German Borrower Sublimit (as defined in the Amended Credit Agreement, which term includes Amendment No. 5 for the purposes of this note) in the amount of $24.0 million, among other things, resulted in (i) a permanent partial reduction in the total commitments under the Amended Credit Agreement from $374.0 million to $350.0 million, (ii) a reduction of the German Borrower Sublimit from $74.0 million to $50.0 million, and (iii) a reduction of the German Commitment Reduction Threshold (as defined in the Amended Credit Agreement) to $25.0 million. The lenders also waived certain events of default related to among others, inaccuracies in the financial statements that were previously delivered to the lenders by the Company with respect to the fiscal quarters ended June 30, 2024 and September 30, 2024, and breaches of the Consolidated Fixed Charge Coverage Ratio (as defined in the Amended Credit Agreement) financial covenant for the fiscal quarters ended June 30, 2024 and September 30, 2024.
