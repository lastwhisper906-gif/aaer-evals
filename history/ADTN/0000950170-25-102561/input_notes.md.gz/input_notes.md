# ADTN notes — 0000950170-25-102561


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-25-102561:notes:1]
[same as prior period, unchanged from 0000950170-25-075374:notes:1]

[0000950170-25-102561:notes:2]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications, and federal, state and local government agencies. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-25-102561:notes:3]
[same as prior period, unchanged from 0000950170-25-075374:notes:3]

[0000950170-25-102561:notes:4]
Liquidity, Domination and Profit and Loss Transfer Agreement and Credit Facility

[0000950170-25-102561:notes:5]
[same as prior period, unchanged from 0000950170-25-075374:notes:5]

[0000950170-25-102561:notes:6]
[same as prior period, unchanged from 0000950170-25-075374:notes:6]

[0000950170-25-102561:notes:7]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of June 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.8 million or $385.2 million, based on an exchange rate as of June 30, 2025, and reflecting interest accrued through June 30, 2025 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The court has decided a procedural matter in the DPLTA appraisal proceedings; the parties may or may not choose to appeal such decision, if able, and the proceeding for the trial on the merits of the DPLTA will continue. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

[0000950170-25-102561:notes:8]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of June 30, 2025) per year assuming none of the minority Adtran Networks shareholders as of June 30, 2025 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended June 30, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation. During the six months ended June 30, 2025 and 2024, we accrued $4.8 million and $5.0 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.

[0000950170-25-102561:notes:9]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended five times. The Company had access to $156.5 million on its Credit Facility for future borrowings; however, as of June 30, 2025, the Company was limited to additional borrowings of $66.8 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x. See Note 10, Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement.

[0000950170-25-102561:notes:10]
[same as prior period, unchanged from 0000950170-25-075374:notes:9]

[0000950170-25-102561:notes:11]
As of June 30, 2025, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet the substantial majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three and six months ended June 30, 2025, approximately 0.9 million shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million or $19.4 million based on the applicable exchange rates at the time of the transactions being paid to Adtran Networks shareholders. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or $20 thousand and $25 thousand, respectively, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact the date of a decision by the court on the merits of the case is uncertain, it will most likely take a minimum of 12 months for a ruling and, thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

[0000950170-25-102561:notes:12]
The Company experienced revenue declines in the year ended December 31, 2024. However, customers have started to replenish their inventories to meet increasing demand. Revenue began to increase in the first half of 2025 and management expects orders and billings to continue to increase during the remainder of 2025. The Company continues to implement plans to preserve cash liquidity to maintain compliance with the Company’s covenants in case of further impacts related to customer inventory reduction initiatives and uncertain macroeconomic conditions. Additionally, the Company suspended dividend payments and effectuated a business efficiency program (the "Business Efficiency Program"), which targeted the reduction of ongoing operating expenses and focused on enhancing capital efficiency. The Business Efficiency Program was completed as of December 31, 2024. The Company has determined that it is probable that the sale of its headquarters in Huntsville will occur within the next twelve months after December 31, 2024. The Company may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that it can meet its needs and obligations and maintain compliance with its debt covenants.

[0000950170-25-102561:notes:13]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and to support our ability to continue to comply with our debt covenants under the Credit Facility and continue as a going concern, for at least the next twelve months, from the issuance of these financial statements. See Note 10, Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo Credit agreement.

[0000950170-25-102561:notes:14]
[same as prior period, unchanged from 0000950170-25-075374:notes:14]

[0000950170-25-102561:notes:15]
During the six months ended June 30, 2025, there were no significant changes to our critical accounting policies as described in the financial statements contained in the 2024 Form 10-K/A.

[0000950170-25-102561:notes:16]
[same as prior period, unchanged from 0000950170-25-075374:notes:15]

[0000950170-25-102561:notes:17]
[same as prior period, unchanged from 0000950170-25-075374:notes:16]

[0000950170-25-102561:notes:18]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Amendment No. 1 to the Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on May 20, 2025 ("2024 Form 10-K/A").

[0000950170-25-102561:notes:19]
Restatement of Previously Issued Financial Statements

[0000950170-25-102561:notes:20]
As discussed in the financial statements as of and for the year ended December 31, 2024 included in our 2024 Form 10-K/A, we identified errors in our previously issued financial statements related to the historical accounting for certain inventory and cost of goods sold transactions (“Adjustment”). The affected periods included the annual periods ended December 31, 2023 and 2024 and the interim periods ended March 31, 2024, June 30, 2024 and September 30, 2024.

[0000950170-25-102561:notes:21]
In connection with the identification of the Adjustment, the Audit Committee oversaw an internal investigation into the circumstances surrounding the Adjustment and its impact on the Company’s historical financial statements. Based on the findings of the internal investigation, it was determined that the underlying errors giving rise to the Adjustment were not properly addressed in the Company’s previously filed financial statements as of and for the years ended December 31, 2024 and 2023 and were not communicated to the Audit Committee or the independent auditors prior to the filing of the initial 2024 Annual Report on Form 10-K. As described in Part I, Item 4 of this report, the Company is taking certain remedial actions to address the material weaknesses in its internal controls associated with these findings. On August 4, 2025, we received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation, which we will respond to accordingly.

[0000950170-25-102561:notes:22]
The identified errors referenced above impacted the Condensed Consolidated Financial Statements as of and for the three and six months ended June 30, 2024, among other periods as previously disclosed. Below is a summary description of the significant errors in the Company's Condensed Consolidated Financial Statements as of and for the three and six months ended June 30, 2024:

[0000950170-25-102561:notes:23]
[same as prior period, unchanged from 0000950170-25-075374:notes:22]

[0000950170-25-102561:notes:24]
ADJ 2 - For the periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024, the Company remeasured the RNCI each quarter-end at the current exchange rate of euros to U.S. Dollar. The Company treated the RNCI as a monetary mezzanine equity instrument but should have treated it as a non-monetary mezzanine equity instrument not subject to remeasurement.

[0000950170-25-102561:notes:25]
[same as prior period, unchanged from 0000950170-25-075374:notes:24]

[0000950170-25-102561:notes:26]
[same as prior period, unchanged from 0000950170-25-075374:notes:25]

[0000950170-25-102561:notes:27]
[same as prior period, unchanged from 0000950170-25-075374:notes:26]

[0000950170-25-102561:notes:28]
We assessed the materiality of the errors on prior period consolidated financial statements in accordance with SEC Staff Accounting Bulletin No. 99, “Materiality,” codified in ASC Topic 250, Accounting Changes and Error Corrections. Based on this assessment, we concluded that the errors, in the aggregate, are material to the June 30, 2024 financial statements and therefore, we have restated those

[0000950170-25-102561:notes:29]
financial statements herein. Furthermore, we made adjustments to correct for other previously identified immaterial errors. The Company has also restated impacted amounts within the accompanying footnotes to the Condensed Consolidated Financial Statements. See Note 18 for further information about the restatement.

[0000950170-25-102561:notes:30]
[same as prior period, unchanged from 0000950170-25-075374:notes:29]

[0000950170-25-102561:notes:31]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenue and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

[0000950170-25-102561:notes:32]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, currency fluctuations and political tensions as of June 30, 2025, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.

[0000950170-25-102561:notes:33]
[same as prior period, unchanged from 0000950170-25-075374:notes:32]

[0000950170-25-102561:notes:34]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2024-03, "Disaggregation of Income Statement Expenses (DISE) (Topic 220): Improvements to Income Statement Disclosures", which applies to all public business entities (PBEs) and is intended to enhance disclosures about specific types of expenses included in the expense captions presented on the face of the income statement as well as disclosures about selling expenses. The amendments are effective prospectively for annual periods beginning after December 15, 2026, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2024-03 will have on our disclosures.

[0000950170-25-102561:notes:35]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2023-09 will have on our disclosures.

[0000950170-25-102561:notes:36]
Recently Adopted Accounting Pronouncements

[0000950170-25-102561:notes:37]
There are currently no recently adopted accounting pronouncements that are expected to have a material effect on the Condensed Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-25-102561:notes:38]
[same as prior period, unchanged from 0000950170-25-075374:notes:39]

[0000950170-25-102561:notes:39]
[same as prior period, unchanged from 0000950170-25-075374:notes:40]

[0000950170-25-102561:notes:40]
[same as prior period, unchanged from 0000950170-25-075374:notes:41]

[0000950170-25-102561:notes:41]
[same as prior period, unchanged from 0000950170-25-075374:notes:42]

[0000950170-25-102561:notes:42]
[same as prior period, unchanged from 0000950170-25-075374:notes:43]

[0000950170-25-102561:notes:43]
[same as prior period, unchanged from 0000950170-25-075374:notes:44]

[0000950170-25-102561:notes:44]
[same as prior period, unchanged from 0000950170-25-075374:notes:45]

[0000950170-25-102561:notes:45]
[same as prior period, unchanged from 0000950170-25-075374:notes:46]

[0000950170-25-102561:notes:46]
[same as prior period, unchanged from 0000950170-25-075374:notes:47]

[0000950170-25-102561:notes:47]
[same as prior period, unchanged from 0000950170-25-075374:notes:48]

[0000950170-25-102561:notes:48]
|  |  | Three Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 75,537 |  |  | $ | 8,221 |  |  | $ | 83,758 |  |  | $ | 73,615 |  |  | $ | 8,782 |  |  | $ | 82,397 |  |
| Access & Aggregation Solutions |  |  | 77,353 |  |  |  | 13,859 |  |  |  | 91,212 |  |  |  | 54,112 |  |  |  | 15,795 |  |  |  | 69,907 |  |
| Optical Networking Solutions |  |  | 66,608 |  |  |  | 23,490 |  |  |  | 90,098 |  |  |  | 51,467 |  |  |  | 22,220 |  |  |  | 73,687 |  |
| Total |  | $ | 219,498 |  |  | $ | 45,570 |  |  | $ | 265,068 |  |  | $ | 179,194 |  |  | $ | 46,797 |  |  | $ | 225,991 |  |

[0000950170-25-102561:notes:49]
|  |  | Six Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 147,285 |  |  | $ | 16,884 |  |  | $ | 164,169 |  |  | $ | 133,984 |  |  | $ | 18,181 |  |  | $ | 152,165 |  |
| Access & Aggregation Solutions |  |  | 153,200 |  |  |  | 27,148 |  |  | $ | 180,348 |  |  |  | 121,889 |  |  |  | 29,330 |  |  | $ | 151,219 |  |
| Optical Networking Solutions |  |  | 121,230 |  |  |  | 47,065 |  |  | $ | 168,295 |  |  |  | 104,594 |  |  |  | 44,186 |  |  | $ | 148,780 |  |
| Total |  | $ | 421,715 |  |  | $ | 91,097 |  |  | $ | 512,812 |  |  | $ | 360,467 |  |  | $ | 91,697 |  |  | $ | 452,164 |  |

[0000950170-25-102561:notes:50]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2025 and December 31, 2024 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $264.9 million and $325.7 million, respectively. As of June 30, 2025, approximately 62.8% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of June 30, 2025, are related to contracts or orders that have an original expected duration of one year or less and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-25-102561:notes:51]
[same as prior period, unchanged from 0000950170-25-075374:notes:51]

[0000950170-25-102561:notes:52]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Accounts receivable, net |  | $ | 164,768 |  |  | $ | 178,030 |  |
| Contract assets(1) |  | $ | 510 |  |  | $ | 631 |  |
| Unearned revenue |  | $ | 62,695 |  |  | $ | 52,701 |  |
| Non-current unearned revenue |  | $ | 24,429 |  |  | $ | 22,065 |  |

[0000950170-25-102561:notes:53]
[same as prior period, unchanged from 0000950170-25-075374:notes:53]

[0000950170-25-102561:notes:54]
[same as prior period, unchanged from 0000950170-25-075374:notes:54]

[0000950170-25-102561:notes:55]
The allowance for credit losses was $1.3 million as of June 30, 2025, and December 31, 2024, related to accounts receivable.

[0000950170-25-102561:notes:56]
Receivables Purchase Agreement

[0000950170-25-102561:notes:57]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of June 30, 2025, totaled $18.4 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million and $0.6 million for the three months and six months ended June 30, 2025, respectively.

[0000950170-25-102561:notes:58]
On December 19, 2023, the Company entered into a receivables purchase agreement (the "Prior Factoring Agreement") with a third-party financial institution which qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidation. The Prior Factoring Agreement was terminated on July 1, 2024. For the three and six months ended June 30, 2024, the Company incurred program fee expenses of $0.3 million and $0.6 million, respectively.

[0000950170-25-102561:notes:59]
[same as prior period, unchanged from 0000950170-25-075374:notes:59]

[0000950170-25-102561:notes:60]
No allowance for credit losses was recorded for the three and six months ended June 30, 2025 and 2024, respectively, related to contract assets.

[0000950170-25-102561:notes:61]
[same as prior period, unchanged from 0000950170-25-075374:notes:61]

[0000950170-25-102561:notes:62]
Of the outstanding unearned revenue balances as of December 31, 2024, $12.8 million and $34.7 million were recognized as revenue during the three and six months ended June 30, 2025, respectively. Of the $65.1 million of outstanding unearned revenue balances as of December 31, 2023, $13.7 million and $33.1 million were recognized as revenue during the three and six months ended June 30, 2024, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-25-102561:notes:63]
[same as prior period, unchanged from 0000950170-25-075374:notes:63]

[0000950170-25-102561:notes:64]
The Company’s effective tax rate changed from an expense of 4.7% of pre-tax loss for the three months ended June 30, 2024, to an expense of 5.9% of pre-tax loss for the three months ended June 30, 2025, and changed from a benefit of 4.2% of pre-tax loss for the six months ended June 30, 2024, to an expense of 2.3% of pre-tax loss for the six months ended June 30, 2025. The changes in the effective tax rate for the three and six months ended June 30, 2025, were driven primarily by loss jurisdictions for which the recognition of tax benefits on pre-tax losses incurred during the three and six months ended June 30, 2025 were limited due to a valuation allowance.

[0000950170-25-102561:notes:65]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of June 30, 2025, the Company had net deferred tax assets totaling $100.7 million, and a valuation allowance totaling $115.7 million against those deferred tax assets. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results, as well as the evaluation of evidence which requires significant judgment, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance, or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-25-102561:notes:66]
[same as prior period, unchanged from 0000950170-25-075374:notes:66]

[0000950170-25-102561:notes:67]
[same as prior period, unchanged from 0000950170-25-075374:notes:67]

[0000950170-25-102561:notes:68]
[same as prior period, unchanged from 0000950170-25-075374:notes:68]

[0000950170-25-102561:notes:69]
[same as prior period, unchanged from 0000950170-25-075374:notes:69]

[0000950170-25-102561:notes:70]
[same as prior period, unchanged from 0000950170-25-075374:notes:70]

[0000950170-25-102561:notes:71]
As of June 30, 2025, 4.1 million shares were available for issuance pursuant to awards that may be made in the future under shareholder-approved equity plans.

[0000950170-25-102561:notes:72]
For the three months ended June 30, 2025 and 2024, stock-based compensation expense was $2.7 million and $3.8 million, respectively, and for the six months ended June 30, 2025 and 2024, stock-based compensation expense was $5.9 million and $7.8 million, respectively.

[0000950170-25-102561:notes:73]
PSUs, RSUs and Restricted Stock - ADTRAN Holdings, Inc.

[0000950170-25-102561:notes:74]
The following table summarizes the changes of the PSUs, RSUs and restricted stock outstanding during the six months ended June 30, 2025:

[0000950170-25-102561:notes:75]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2024 |  |  | 2,335 |  |  | $ | 13.22 |  |
| PSUs, RSUs and restricted stock granted |  |  | 1,278 |  |  | $ | 10.35 |  |
| PSUs, RSUs and restricted stock vested |  |  | (509 | ) |  | $ | 11.59 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (148 | ) |  | $ | 11.06 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, June 30, 2025 |  |  | 2,956 |  |  | $ | 11.44 |  |

[0000950170-25-102561:notes:76]
[same as prior period, unchanged from 0000950170-25-075374:notes:76]

[0000950170-25-102561:notes:77]
As of June 30, 2025, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $17.8 million, which will be recognized over the remaining weighted-average period of 2.7 years. As of June 30, 2025, there was $9.9 million of unrecognized compensation expense related to unvested performance-based PSUs (not-considered probable), which will be recognized over the remaining requisite service period of 0.5 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0000950170-25-102561:notes:78]
Stock Options - ADTRAN Holdings, Inc.

[0000950170-25-102561:notes:79]
The following table summarizes the changes of the stock options outstanding that occurred during the six months ended June 30, 2025:

[0000950170-25-102561:notes:80]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2024 |  |  | 2,944 |  |  | $ | 9.86 |  |  |  | 5.0 |  |  | $ | 3,762 |  |
| Stock options exercised |  |  | (172 | ) |  | $ | 6.76 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (98 | ) |  | $ | 9.62 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (17 | ) |  | $ | 14.12 |  |  |  |  |  |  |  |
| Stock options outstanding, June 30, 2025 |  |  | 2,657 |  |  | $ | 10.04 |  |  |  | 4.6 |  |  | $ | 4,200 |  |
| Stock options exercisable, June 30, 2025 |  |  | 1,750 |  |  | $ | 9.82 |  |  |  | 3.5 |  |  | $ | 2,141 |  |

[0000950170-25-102561:notes:81]
As of June 30, 2025, there was $1.3 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 0.6 years.

[0000950170-25-102561:notes:82]
The determination of the fair value of stock options assumed or granted by ADTRAN was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors.

[0000950170-25-102561:notes:83]
[same as prior period, unchanged from 0000950170-25-075374:notes:83]

[0000950170-25-102561:notes:84]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between the Company's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on June 30, 2025. The amount of aggregate intrinsic value was $4.2 million as of June 30, 2025, which will change based on the fair market value of the Company's stock. The total pre-tax intrinsic value of options exercised during the six months ended June 30, 2025, and 2024 was $0.5 million and $34 thousand, respectively. During the three and six months ended June 30, 2025 and 2024, 0.5 million and 0.1 million stock options vested, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-25-102561:notes:85]
5. LONG TERM INVESTMENTS

[0000950170-25-102561:notes:86]
The Company has cash equivalents and investments which are held at fair value as follows:

[0000950170-25-102561:notes:87]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2025 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 238 |  |  | $ | 238 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 1,072 |  |  |  | 1,072 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 32,044 |  |  |  | 32,044 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,354 |  |  | $ | 33,354 |  |  | $ | — |  |  | $ | — |  |

[0000950170-25-102561:notes:88]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 5,538 |  |  | $ | 5,538 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 1,068 |  |  |  | 1,068 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 30,991 |  |  |  | 30,991 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 37,597 |  |  | $ | 37,597 |  |  | $ | — |  |  | $ | — |  |

[0000950170-25-102561:notes:89]
(1)
The money market fund balances of $0.2 million and $5.5 million as of June 30, 2025 and December 31, 2024, respectively, are included in cash and cash equivalents on the balance sheet.

[0000950170-25-102561:notes:90]
Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0000950170-25-102561:notes:91]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-25-102561:notes:92]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-25-102561:notes:93]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; and

[0000950170-25-102561:notes:94]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-25-102561:notes:95]
6. INVENTORY, NET

[0000950170-25-102561:notes:96]
[same as prior period, unchanged from 0000950170-25-075374:notes:95]

[0000950170-25-102561:notes:97]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Raw materials |  | $ | 85,043 |  |  | $ | 106,384 |  |
| Work in process |  |  | 11,530 |  |  |  | 9,724 |  |
| Finished goods |  |  | 143,508 |  |  |  | 145,449 |  |
| Total inventory, net |  | $ | 240,081 |  |  | $ | 261,557 |  |

[0000950170-25-102561:notes:98]
[same as prior period, unchanged from 0000950170-25-075374:notes:97]

[0000950170-25-102561:notes:99]
During the twelve months ended December 31, 2024, the Company recorded an inventory write-down of $8.6 million, as a result of a strategy shift which included discontinuance of certain product lines in connection with the Business Efficiency Program of which $4.1 million relates to inventory write-downs and $4.5 million relates to other charges, all of which are included in cost of revenue in the Condensed Consolidated Statements of Loss.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-25-102561:notes:100]
7. PROPERTY, PLANT AND EQUIPMENT, NET

[0000950170-25-102561:notes:101]
[same as prior period, unchanged from 0000950170-25-075374:notes:100]

[0000950170-25-102561:notes:102]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Engineering and other equipment |  | $ | 197,351 |  |  | $ | 184,694 |  |
| Building |  |  | 52,529 |  |  |  | 50,871 |  |
| Computer hardware and software |  |  | 121,704 |  |  |  | 113,241 |  |
| Building and land improvements |  |  | 43,557 |  |  |  | 39,979 |  |
| Furniture and fixtures |  |  | 21,468 |  |  |  | 20,994 |  |
| Land |  |  | 3,075 |  |  |  | 2,989 |  |
| Total property, plant and equipment |  |  | 439,684 |  |  |  | 412,768 |  |
| Less: accumulated depreciation and amortization |  |  | (327,748 | ) |  |  | (306,314 | ) |
| Total property, plant and equipment, net |  | $ | 111,936 |  |  | $ | 106,454 |  |

[0000950170-25-102561:notes:103]
[same as prior period, unchanged from 0000950170-25-075374:notes:102]

[0000950170-25-102561:notes:104]
Depreciation and amortization expense was $7.6 million and $7.0 million for the three months ended June 30, 2025 and 2024, respectively, and $14.5 million and $14.1 million for the six months ended June 30, 2025 and 2024, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.

[0000950170-25-102561:notes:105]
[same as prior period, unchanged from 0000950170-25-075374:notes:104]

[0000950170-25-102561:notes:106]
[same as prior period, unchanged from 0000950170-25-075374:notes:105]

[0000950170-25-102561:notes:107]
The Company records assets held for sale at the lower of their carrying value or fair value. The total carrying value of assets held for sale was $11.9 million as of June 30, 2025 and December 31, 2024, respectively, and is separately recorded on the balance sheet.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-25-102561:notes:108]
[same as prior period, unchanged from 0000950170-25-075374:notes:107]

[0000950170-25-102561:notes:109]
The changes in the carrying amount of goodwill for the six months ended June 30, 2025, are as follows:

[0000950170-25-102561:notes:110]
| (In thousands) |  | Services & Support |  |
| As of December 31, 2024 |  | $ | 52,918 |  |
| Foreign currency translation adjustments |  |  | 7,276 |  |
| As of June 30, 2025 |  | $ | 60,194 |  |

[0000950170-25-102561:notes:111]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company performs its annual goodwill impairment assessment on the first day of the fourth quarter. In addition, the Company performs an interim impairment assessment prior to our annual measurement date whenever events or changes in circumstances indicate that the carrying amount of such assets (or group of assets) may not be recoverable.

[0000950170-25-102561:notes:112]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment of our reporting units. The Company determined the fair value of each reporting unit using a combination of an income approach and a market-based peer group analysis. The significant inputs and assumptions used in the determination of the fair value of our reporting units, based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to cash flow projections, discount rate, peer group determination and market multiple selection. The Company determined upon its quantitative impairment assessment to recognize a $297.4 million non-cash goodwill impairment charge for the Network Solutions reporting unit. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the first quarter of 2024.

[0000950170-25-102561:notes:113]
No impairment of goodwill was recognized during the three and six months ended June 30, 2025 and the three months ended June 30, 2024. As of June 30, 2025, accumulated goodwill impairment losses totaled $335.3 million.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-25-102561:notes:114]
9. INTANGIBLE ASSETS, NET

[0000950170-25-102561:notes:115]
Intangible assets, net as of June 30, 2025, and December 31, 2024, consisted of the following:

[0000950170-25-102561:notes:116]
|  |  |  |  | As of June 30, 2025 |  |  | As of December 31, 2024 |  |
| (In thousands excluding years) | Weighted Average Useful Life(in years) |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | 11.0 |  |  | $ | 56,396 |  |  | $ | (22,927 | ) |  | $ | 33,469 |  |  | $ | 51,165 |  |  | $ | (18,778 | ) |  | $ | 32,387 |  |
| Backlog |  | 1.7 |  |  |  | 61,298 |  |  |  | (61,163 | ) |  |  | 135 |  |  |  | 53,839 |  |  |  | (52,258 | ) |  |  | 1,581 |  |
| Developed technology |  | 7.8 |  |  |  | 413,360 |  |  |  | (139,457 | ) |  |  | 273,903 |  |  |  | 346,923 |  |  |  | (99,588 | ) |  |  | 247,335 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (4,780 | ) |  |  | 1,120 |  |  |  | 5,900 |  |  |  | (4,452 | ) |  |  | 1,448 |  |
| Licensed agreements |  | 8.5 |  |  |  | 560 |  |  |  | (427 | ) |  |  | 133 |  |  |  | 560 |  |  |  | (407 | ) |  |  | 153 |  |
| Trade names |  | 2.8 |  |  |  | 31,710 |  |  |  | (30,301 | ) |  |  | 1,409 |  |  |  | 27,851 |  |  |  | (25,862 | ) |  |  | 1,989 |  |
| Total |  |  |  | $ | 569,224 |  |  | $ | (259,055 | ) |  | $ | 310,169 |  |  | $ | 486,238 |  |  | $ | (201,345 | ) |  | $ | 284,893 |  |

[0000950170-25-102561:notes:117]
No impairment losses related to intangible assets were recorded during the three and six months ended June 30, 2025 and 2024.

[0000950170-25-102561:notes:118]
Amortization expense was $15.7 million and $15.3 million in the three months ended June 30, 2025 and 2024, respectively, and $30.6 million and $30.4 million in the six months ended June 30, 2025 and 2024, respectively and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.

[0000950170-25-102561:notes:119]
[same as prior period, unchanged from 0000950170-25-075374:notes:117]

[0000950170-25-102561:notes:120]
|  |  | As of |  |
| (In thousands) |  | June 30, 2025 |  |
| 2025 |  | $ | 32,368 |  |
| 2026 |  |  | 64,772 |  |
| 2027 |  |  | 59,150 |  |
| 2028 |  |  | 49,561 |  |
| 2029 |  |  | 46,025 |  |
| Thereafter |  |  | 58,293 |  |
| Total |  | $ | 310,169 |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-25-102561:notes:121]
10. CREDIT AGREEMENTS

[0000950170-25-102561:notes:122]
The carrying amounts of the Company's non-current revolving credit facility in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-25-102561:notes:123]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Wells Fargo credit agreement |  | $ | 190,180 |  |  | $ | 189,576 |  |
| Total non-current revolving credit facility |  | $ | 190,180 |  |  | $ | 189,576 |  |

[0000950170-25-102561:notes:124]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to the Credit Agreement, dated August 9, 2023 (“Amendment No. 1”), the Second Amendment to the Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to the Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), the Fourth Amendment to the Credit Amendment, dated June 4, 2024 ("Amendment No. 4"), and the Fifth Amendment to the Credit Agreement, dated May 6, 2025 (“Amendment No. 5” and, collectively with Amendment No. 1, Amendment No. 2, Amendment No. 3, and Amendment No. 4, the “Credit Agreement Amendments”; and the Original Credit Agreement, as amended by the Credit Agreement Amendments, the “Amended Credit Agreement”). Amendment No. 5, together with a substantially concurrent prepayment by Adtran Networks of outstanding revolving loans under the German Borrower Sublimit (as defined in the Amended Credit Agreement, which term includes Amendment No. 5 for the purposes of this note) in the amount of $24.0 million, among other things, resulted in (i) a permanent partial reduction in the total commitments under the Amended Credit Agreement from $374.0 million to $350.0 million, (ii) a reduction of the German Borrower Sublimit from $74.0 million to $50.0 million, and (iii) a reduction of the German Commitment Reduction Threshold (as defined in the Amended Credit Agreement) to $25.0 million. The lenders also waived certain events of default related to among others, inaccuracies in the financial statements that were previously delivered to the lenders by the Company with respect to the fiscal quarters ended June 30, 2024 and September 30, 2024, and breaches of the Consolidated Fixed Charge Coverage Ratio (as defined in the Amended Credit Agreement) financial covenant for the fiscal quarters ended June 30, 2024 and September 30, 2024. As of June 30, 2025, the Amended Credit Agreement provided for a secured revolving credit facility of up to $350.0 million of borrowings, $50.0 million of which is solely available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below).

[0000950170-25-102561:notes:125]
As of June 30, 2025, the Company’s borrowings under the revolving line of credit were $190.2 million, of which approximately $165.0 million were borrowed by the U.S. Borrower and $25.2 million were borrowed under the Subline by Adtran Networks, who became a party to the Amended Credit Agreement in June 2024. The credit facilities provided under the Amended Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $350.0 million total revolving facility for the issuance of letters of credit. As of June 30, 2025, the U.S. Borrower had a total of $3.3 million in letters of credit under the Amended Credit Agreement, leaving a net amount (after giving effect to the $190.2 million of outstanding borrowings described above) of $156.5 million available for future borrowings; however, as of June 30, 2025, the Company was limited to additional borrowings of $66.8 million based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the exchange offer consideration.

[0000950170-25-102561:notes:126]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $350.0 million revolving commitments in an aggregate amount of $50.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold of $50.0 million may be lowered from time to time pursuant to the terms of the Amended Credit Agreement. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to Adtran Networks). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

[0000950170-25-102561:notes:127]
All U.S. borrowings under the Amended Credit Agreement bear interest at a rate tied to the Base Rate (as defined in the Amended Credit Agreement) or SOFR, at the Company’s option, and all E.U. borrowings bear interest at a rate tied to the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent), in each case plus applicable margins which vary based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Amended Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable. As of June 30, 2025, the weighted average interest rate on our revolving credit agreements was 8.55%.

[0000950170-25-102561:notes:128]
The Company made certain representations and warranties to the lenders in the Amended Credit Agreement that are customary for credit arrangements of this type. The Company also agreed to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a “Springing Covenant Period,” as defined below) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such ratios are defined in the Amended Credit Agreement). A “Springing Covenant Event” occurs when at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of August 9, 2023 have been tendered and purchased by the Company. Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During a Springing Covenant Period, the Company’s leverage ratios are increased. In addition, the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. As of June 30, 2025, the Company was in compliance with all covenants.

[0000950170-25-102561:notes:129]
The Amended Credit Agreement also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Amended Credit Agreement.

[0000950170-25-102561:notes:130]
All obligations under the Amended Credit Agreement (including under the Subline) are guaranteed by the U.S. Borrower and certain subsidiaries of the U.S. Borrower (“Full Facility Guarantors”). To secure such guarantees, the U.S. Borrower and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and the U.S. Borrower has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries (the “Subline Guarantors”) have also provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, Adtran Networks and the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-25-102561:notes:131]
[same as prior period, unchanged from 0000950170-25-075374:notes:131]

[0000950170-25-102561:notes:132]
[same as prior period, unchanged from 0000950170-25-075374:notes:132]

[0000950170-25-102561:notes:133]
We maintain a defined benefit pension plan covering employees in certain foreign countries. The net amounts recognized in the Condensed Consolidated Balance Sheets for the unfunded pension liability as of June 30, 2025 and December 31, 2024 were as follows:

[0000950170-25-102561:notes:134]
|  |  |  |  | As of |  |  | As of |  |
| (In thousands) |  | Balance Sheet Location |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Non-current pension asset |  | Other non-current assets |  | $ | 588 |  |  | $ | 517 |  |
| Current pension liability |  | Accrued wages and benefits |  |  | (345 | ) |  |  | (303 | ) |
| Non-current pension liability |  | Non-current pension liability |  |  | (9,686 | ) |  |  | (8,983 | ) |
| Total |  |  |  | $ | (9,443 | ) |  | $ | (8,769 | ) |

[0000950170-25-102561:notes:135]
[same as prior period, unchanged from 0000950170-25-075374:notes:135]

[0000950170-25-102561:notes:136]
[same as prior period, unchanged from 0000950170-25-075374:notes:136]

[0000950170-25-102561:notes:137]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Service cost |  | $ | 421 |  |  | $ | 333 |  |  | $ | 810 |  |  | $ | 673 |  |
| Interest cost |  |  | 525 |  |  |  | 281 |  |  |  | 1,011 |  |  |  | 566 |  |
| Expected return on plan assets |  |  | (635 | ) |  |  | (354 | ) |  |  | (1,223 | ) |  |  | (713 | ) |
| Amortization of actuarial losses |  |  | 12 |  |  |  | 2 |  |  |  | 23 |  |  |  | 5 |  |
| Net periodic pension cost |  | $ | 323 |  |  | $ | 262 |  |  | $ | 621 |  |  | $ | 531 |  |

[0000950170-25-102561:notes:138]
The components of net periodic pension cost, other than the service cost component, are included in other (expense) income, net in the Condensed Consolidated Statements of Loss. Service cost is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss. The Company made contributions to the defined benefit pension plans totaling $2.0 million and $2.2 million during the six months ended June 30, 2025 and 2024, respectively. Contributions to the defined benefit pension plans for the remainder of 2025 will be limited to benefit payments to retirees which are paid out of the operating cash flows of the Company and are expected to be approximately $1.5 million.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-25-102561:notes:139]
[same as prior period, unchanged from 0000950170-25-075374:notes:139]

[0000950170-25-102561:notes:140]
[same as prior period, unchanged from 0000950170-25-075374:notes:140]

[0000950170-25-102561:notes:141]
[same as prior period, unchanged from 0000950170-25-075374:notes:141]

[0000950170-25-102561:notes:142]
|  |  | Three Months Ended June 30, 2025 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Translation Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of March 31, 2025 |  | $ | (382 | ) |  | $ | (896 | ) |  | $ | 32,525 |  |  | $ | 385 |  |  | $ | 31,632 |  |
| Other comprehensive (loss) income before reclassifications |  |  | (28 | ) |  |  | — |  |  |  | 46,455 |  |  |  | — |  |  |  | 46,427 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | 28 |  |  |  | 268 |  |  |  | — |  |  |  | — |  |  |  | 296 |  |
| Net current period other comprehensive income |  |  | — |  |  |  | 268 |  |  |  | 46,455 |  |  |  | — |  |  |  | 46,723 |  |
| Balance as of June 30, 2025 |  | $ | (382 | ) |  | $ | (628 | ) |  | $ | 78,980 |  |  | $ | 385 |  |  | $ | 78,355 |  |

[0000950170-25-102561:notes:143]
|  |  | Three Months Ended June 30, 2024 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Translation Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of March 31, 2024 |  | $ | (382 | ) |  | $ | (2,566 | ) |  | $ | 32,260 |  |  | $ | 385 |  |  | $ | 29,697 |  |
| Other comprehensive loss before reclassifications |  |  | (5 | ) |  |  | — |  |  |  | (1,375 | ) |  |  | — |  |  |  | (1,380 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 5 |  |  |  | (7 | ) |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| Net current period other comprehensive loss |  |  | — |  |  |  | (7 | ) |  |  | (1,375 | ) |  |  | — |  |  |  | (1,382 | ) |
| Balance as of June 30, 2024 (Restated) |  | $ | (382 | ) |  | $ | (2,573 | ) |  | $ | 30,885 |  |  | $ | 385 |  |  | $ | 28,315 |  |

[0000950170-25-102561:notes:144]
|  |  | Six Months Ended June 30, 2025 |  |
| (In thousands) |  | UnrealizedGains (Losses)onAvailable-for-SaleSecurities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Translation Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2024 |  | $ | (382 | ) |  | $ | (1,027 | ) |  | $ | 12,278 |  |  | $ | 385 |  |  | $ | 11,254 |  |
| Other comprehensive income before reclassifications |  |  | 20 |  |  |  | — |  |  |  | 66,702 |  |  |  | — |  |  |  | 66,722 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (20 | ) |  |  | 399 |  |  |  | — |  |  |  | — |  |  |  | 379 |  |
| Net current period other comprehensive income |  |  | — |  |  |  | 399 |  |  |  | 66,702 |  |  |  | — |  |  |  | 67,101 |  |
| Balance as of June 30, 2025 |  | $ | (382 | ) |  | $ | (628 | ) |  | $ | 78,980 |  |  | $ | 385 |  |  | $ | 78,355 |  |

[0000950170-25-102561:notes:145]
|  |  | Six Months Ended June 30, 2024 |  |
| (In thousands) |  | UnrealizedGains (Losses) on Available-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Translation Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2023 |  | $ | (382 | ) |  | $ | (2,506 | ) |  | $ | 50,033 |  |  | $ | 385 |  |  | $ | 47,530 |  |
| Other comprehensive loss before reclassifications |  |  | (124 | ) |  |  | — |  |  |  | (19,148 | ) |  |  | — |  |  |  | (19,272 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 124 |  |  |  | (67 | ) |  |  | — |  |  |  | — |  |  |  | 57 |  |
| Net current period other comprehensive loss |  |  | — |  |  |  | (67 | ) |  |  | (19,148 | ) |  |  | — |  |  |  | (19,215 | ) |
| Balance as of June 30, 2024 (Restated) |  | $ | (382 | ) |  | $ | (2,573 | ) |  | $ | 30,885 |  |  | $ | 385 |  |  | $ | 28,315 |  |

[0000950170-25-102561:notes:146]
[same as prior period, unchanged from 0000950170-25-075374:notes:144]

[0000950170-25-102561:notes:147]
|  |  | Three Months Ended June 30, 2025 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in theStatement Where NetLoss Is Presented |
| Unrealized gain on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 38 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial gain |  |  | 388 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | 426 |  |  |  |
| Tax expense |  |  | (130 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 296 |  |  |  |

[0000950170-25-102561:notes:148]
(1)
A part of the computation of net periodic pension cost, which is included in other (expense) income, net in the Condensed Consolidated Statements of Loss.

[0000950170-25-102561:notes:149]
|  |  | Three Months Ended June 30, 2024 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Loss |  |  | Affected Line Item in the Statement Where Net Loss Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 7 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial loss |  |  | (10 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (3 | ) |  |  |
| Tax benefit |  |  | 1 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (2 | ) |  |  |

[0000950170-25-102561:notes:150]
|  |  | Six Months Ended June 30, 2025 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net LossIs Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (27 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial gain |  |  | 578 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | 551 |  |  |  |
| Tax expense |  |  | (172 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 379 |  |  |  |

[0000950170-25-102561:notes:151]
|  |  | Six Months Ended June 30, 2024 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net LossIs Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 168 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial loss |  |  | (97 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 71 |  |  |  |
| Tax expense |  |  | (14 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 57 |  |  |  |

[0000950170-25-102561:notes:152]
[same as prior period, unchanged from 0000950170-25-075374:notes:148]

[0000950170-25-102561:notes:153]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024(Restated) |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized loss on available-for-sale securities |  | $ | (38 | ) |  | $ | 10 |  |  | $ | (28 | ) |  | $ | (7 | ) |  | $ | 2 |  |  | $ | (5 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net gain |  |  | 38 |  |  |  | (10 | ) |  |  | 28 |  |  |  | 7 |  |  |  | (2 | ) |  |  | 5 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net gain (loss) |  |  | 388 |  |  |  | (120 | ) |  |  | 268 |  |  |  | (10 | ) |  |  | 3 |  |  |  | (7 | ) |
| Foreign currency translation adjustments |  |  | 46,455 |  |  |  | — |  |  |  | 46,455 |  |  |  | (1,375 | ) |  |  | — |  |  |  | (1,375 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 46,843 |  |  | $ | (120 | ) |  | $ | 46,723 |  |  | $ | (1,385 | ) |  | $ | 3 |  |  | $ | (1,382 | ) |

[0000950170-25-102561:notes:154]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024(Restated) |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | 27 |  |  | $ | (7 | ) |  | $ | 20 |  |  | $ | (168 | ) |  | $ | 44 |  |  | $ | (124 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) gain |  |  | (27 | ) |  |  | 7 |  |  |  | (20 | ) |  |  | 168 |  |  |  | (44 | ) |  |  | 124 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net gain (loss) |  |  | 578 |  |  |  | (179 | ) |  |  | 399 |  |  |  | (97 | ) |  |  | 30 |  |  |  | (67 | ) |
| Foreign currency translation adjustments |  |  | 66,702 |  |  |  | — |  |  |  | 66,702 |  |  |  | (19,148 | ) |  |  | — |  |  |  | (19,148 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 67,280 |  |  | $ | (179 | ) |  | $ | 67,101 |  |  | $ | (19,245 | ) |  | $ | 30 |  |  | $ | (19,215 | ) |


## us-gaap:RedeemableNoncontrollingInterestTableTextBlock

[0000950170-25-102561:notes:155]
The following table summarizes the redeemable non-controlling interest activity for the six months ended June 30, 2025 and for the year ended December 31, 2024:

[0000950170-25-102561:notes:156]
|  |  | Six Months Ended |  |  | For the Year Ended |  |  |
| (In thousands) |  | June 30, 2025 |  |  | December 31, 2024 |  |  |
| Balance at beginning of period |  | $ | 422,943 |  |  | $ | 443,327 |  |  |
| Redemption of redeemable non-controlling interest |  |  | (20,854 | ) |  |  | (20,384 | ) |  |
| Net income attributable to redeemable non-controlling interests |  |  | 4,592 |  |  |  | 9,824 |  |  |
| Annual recurring compensation earned |  |  | (4,592 | ) |  |  | (9,824 | ) |  |
| Balance at end of period |  | $ | 402,089 |  |  | $ | 422,943 |  |  |


## us-gaap:EarningsPerShareTextBlock

[0000950170-25-102561:notes:157]
[same as prior period, unchanged from 0000950170-25-075374:notes:153]

[0000950170-25-102561:notes:158]
[same as prior period, unchanged from 0000950170-25-075374:notes:154]

[0000950170-25-102561:notes:159]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  | (Restated) |  |  |  |  |  | (Restated) |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss attributable to ADTRAN Holdings, Inc. |  | $ | (20,531 | ) |  | $ | (49,667 | ) |  | $ | (31,798 | ) |  | $ | (380,432 | ) |
| Effect of redemption of RNCI |  |  | 1,494 |  |  |  | — |  |  |  | 1,491 |  |  |  | — |  |
| Net loss attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | (19,037 | ) |  | $ | (49,667 | ) |  | $ | (30,307 | ) |  | $ | (380,432 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 79,748 |  |  |  | 78,852 |  |  |  | 79,642 |  |  |  | 78,803 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 79,748 |  |  |  | 78,852 |  |  |  | 79,642 |  |  |  | 78,803 |  |
| Loss per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.24 | ) |  | $ | (0.63 | ) |  | $ | (0.38 | ) |  | $ | (4.83 | ) |
| Loss per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.24 | ) |  | $ | (0.63 | ) |  | $ | (0.38 | ) |  | $ | (4.83 | ) |

[0000950170-25-102561:notes:160]
For the three months ended June 30, 2025 and 2024, 0.5 million and 1.4 million, respectively, and for the six months ended June 30, 2025 and 2024, 0.3 million and 1.3 million, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0000950170-25-102561:notes:161]
For the three months ended June 30, 2025 and 2024, 1.2 million and 5.0 million outstanding stock options, respectively, and for the six months ended June 30, 2025 and 2024, 0.9 million and 4.2 million outstanding stock options, respectively, were anti-dilutive and excluded from the calculation of loss per share under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-25-102561:notes:162]
[same as prior period, unchanged from 0000950170-25-075374:notes:158]

[0000950170-25-102561:notes:163]
The chief operating decision maker, the Company's CEO, regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support.

[0000950170-25-102561:notes:164]
The Network Solutions segment includes hardware and software products that enable a digital future which support the Company's Subscriber, Access & Aggregation, and Optical Networking Solutions. The Company's cloud-managed Wi-Fi gateways, virtualization software, and switches provide a mix of wired and wireless connectivity at the customer premises. In addition, its carrier ethernet products support a variety of applications at the network edge ranging from mobile backhaul to connecting enterprise customers (“Subscriber Solutions”). The Company's portfolio includes products for multi-gigabit service delivery over fiber or alternative media to homes and businesses.

[0000950170-25-102561:notes:165]
[same as prior period, unchanged from 0000950170-25-075374:notes:161]

[0000950170-25-102561:notes:166]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain, other income (expense), net and income tax benefit are reported on a consolidated basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-25-102561:notes:167]
[same as prior period, unchanged from 0000950170-25-075374:notes:163]

[0000950170-25-102561:notes:168]
|  |  | Three Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | (Restated) |  |  | (Restated) |  |
| Network Solutions |  | $ | 219,498 |  |  | $ | 147,321 |  |  | $ | 72,177 |  |  | $ | 179,194 |  |  | $ | 124,916 |  |  | $ | 54,278 |  |
| Services & Support |  |  | 45,570 |  |  |  | 18,823 |  |  |  | 26,747 |  |  |  | 46,797 |  |  |  | 19,816 |  |  |  | 26,981 |  |
| Total |  | $ | 265,068 |  |  | $ | 166,144 |  |  | $ | 98,924 |  |  | $ | 225,991 |  |  | $ | 144,732 |  |  | $ | 81,259 |  |

[0000950170-25-102561:notes:169]
|  |  | Six Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | (Restated) |  |  | (Restated) |  |
| Network Solutions |  | $ | 421,715 |  |  | $ | 281,562 |  |  | $ | 140,153 |  |  | $ | 360,467 |  |  | $ | 261,964 |  |  | $ | 98,503 |  |
| Services & Support |  |  | 91,097 |  |  |  | 37,150 |  |  |  | 53,947 |  |  |  | 91,697 |  |  |  | 38,626 |  |  |  | 53,071 |  |
| Total |  | $ | 512,812 |  |  | $ | 318,712 |  |  | $ | 194,100 |  |  | $ | 452,164 |  |  | $ | 300,590 |  |  | $ | 151,574 |  |

[0000950170-25-102561:notes:170]
For the three months ended June 30, 2025 and 2024, $1.3 million and $1.5 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the six months ended June 30, 2025 and 2024, $2.6 million and $3.1 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the three months ended June 30, 2025 and 2024, $0.1 million and $0.1 million, respectively, of depreciation expense was included in gross profit for our Services & Support segment. For the six months ended June 30, 2025 and 2024, $0.1 million and $0.1 million, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0000950170-25-102561:notes:171]
[same as prior period, unchanged from 0000950170-25-075374:notes:166]

[0000950170-25-102561:notes:172]
[same as prior period, unchanged from 0000950170-25-075374:notes:167]

[0000950170-25-102561:notes:173]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| United States |  | $ | 120,340 |  |  | $ | 107,604 |  |  | $ | 223,529 |  |  | $ | 190,894 |  |
| United Kingdom |  |  | 56,249 |  |  |  | 43,560 |  |  |  | 119,158 |  |  |  | 96,300 |  |
| Germany |  |  | 31,205 |  |  |  | 24,542 |  |  |  | 58,393 |  |  |  | 64,283 |  |
| Other international |  |  | 57,274 |  |  |  | 50,285 |  |  |  | 111,732 |  |  |  | 100,687 |  |
| Total |  | $ | 265,068 |  |  | $ | 225,991 |  |  | $ | 512,812 |  |  | $ | 452,164 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-25-102561:notes:174]
16. COMMITMENTS AND CONTINGENCIES

[0000950170-25-102561:notes:175]
Legal Matters

[0000950170-25-102561:notes:176]
From time to time, the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. The Company records an accrual for any Legal Matters that arise whenever it considers that it is probable that it is exposed to a loss contingency and the amount of the loss contingency can be reasonably estimated. Although the ultimate disposition of asserted claims cannot be predicted with certainty, it is our belief that the outcome of any such claims, either individually or on a combined basis, will not have a material adverse effect on our consolidated financial position.

[0000950170-25-102561:notes:177]
DPLTA Appraisal Proceedings

[0000950170-25-102561:notes:178]
In addition to such Legal Matters, the Company is a party to appraisal proceedings relating to the DPLTA which were originally filed with the Landgericht Meiningen (Meiningen Regional Court) on February 3, 2023. The DPLTA provides that Adtran Networks shareholders (other than the Company) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest or (ii) to remain Adtran Networks shareholders and receive recurring cash compensation of €0.52 per share for each full fiscal year of Adtran Networks. The appraisal proceedings, which were initiated by certain minority shareholders of Adtran Networks, challenge the adequacy of both forms of compensation. While the Company believes that the compensation offered in connection with the DPLTA is fair, it notes that German courts often adjudicate increases of the cash compensation to plaintiffs in varying amounts in connection with German appraisal proceedings. Therefore, the Company cannot rule out that the court or an appellate court may increase the cash compensation owed to the minority Adtran Networks shareholders. Given the stage of the appraisal proceedings, the Company is currently unable to predict the likely outcome or estimate the potential financial impact, if any, of the appraisal proceedings. If a ruling were to occur and be upheld upon appeal that required the Company to pay significant additional cash compensation to the Adtran Networks minority shareholders, there exists the possibility of a material adverse effect on our financial position and results of operations for the period in which the ruling occurs or future periods.

[0000950170-25-102561:notes:179]
DPLTA Exit and Recurring Compensation Costs and the Absorption of Adtran Network's Annual Net Loss

[0000950170-25-102561:notes:180]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of June 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, the Company would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.8 million or $385.2 million, based on an exchange rate as of June 30, 2025, and reflecting interest accrued through June 30, 2025, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The court has decided a procedural matter in the DPLTA appraisal proceedings; the parties may or may not choose to appeal such decision, if able, and the proceeding for the trial on the merits of the DPLTA will continue. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to

[0000950170-25-102561:notes:181]
take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

[0000950170-25-102561:notes:182]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of June 30, 2025) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholders meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended June 30, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation. During the six months ended June 30, 2025 and 2024, we accrued $4.8 million and $5.0 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

[0000950170-25-102561:notes:183]
For the three and six months ended June 30, 2025, approximately 0.9 million shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million, or $19.4 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or $20 thousand and $25 thousand, respectively, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders.

[0000950170-25-102561:notes:184]
In addition, under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applies to the net loss generated by Adtran Networks in 2024, and it will apply to any net loss generated by Adtran Networks in 2025.

[0000950170-25-102561:notes:185]
Performance Bonds

[0000950170-25-102561:notes:186]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2025 and December 31, 2024, we had commitments related to these bonds totaling $16.9 million and $15.7 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-25-102561:notes:187]
Purchase Obligations

[0000950170-25-102561:notes:188]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of June 30, 2025, purchase obligations totaled $192.7 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-25-102561:notes:189]
[same as prior period, unchanged from 0000950170-25-075374:notes:183]

[0000950170-25-102561:notes:190]
On November 6, 2023, due to the uncertainty around the then current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a Business Efficiency Program targeting the reduction of ongoing operating expenses and focusing on capital efficiency. This included certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the sale of owned real estate (including the sale of our headquarters in Huntsville), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-102561:notes:191]
During the three and six months ended June 30, 2024, we recognized $17.5 million and $34.6 million of costs related to the Business Efficiency Program, respectively. The costs recognized during the six months ended June 30, 2024, included charges of $8.9 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.1 million relates to inventory write-downs and $4.8 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss. Although the Company did not incur any additional Business Efficiency Program costs during the three and six months ended June 30, 2025, the Company reduced previously accrued costs by $0.3 million during the three and six months ended June 30, 2025.

[0000950170-25-102561:notes:192]
A reconciliation of the beginning and ending restructuring liabilities, which is included in accrued wages and benefits and accounts payable in the Condensed Consolidated Balance Sheets as of June 30, 2025 and December 31, 2024, is as follows:

[0000950170-25-102561:notes:193]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (In thousands) |  | June 30, 2025 |  |  | June 30, 2025 |  |
| Balance at beginning of period |  | $ | 3,064 |  |  | $ | 10,336 |  |
| Less: Adjusted accrued costs |  |  | (284 | ) |  |  | (284 | ) |
| Less: Amounts paid |  |  | (139 | ) |  |  | (7,411 | ) |
| Balance as of June 30, 2025 |  | $ | 2,641 |  |  | $ | 2,641 |  |

[0000950170-25-102561:notes:194]
|  |  | For the Year Ended |  |
| (In thousands) |  | December 31, 2024 |  |
| Balance as of December 31, 2023 |  | $ | 8,309 |  |
| Plus: Amounts charged to cost and expense |  |  | 40,545 |  |
| Less: Amounts paid |  |  | (38,518 | ) |
| Balance as of December 31, 2024 |  | $ | 10,336 |  |

[0000950170-25-102561:notes:195]
Restructuring expenses included in the Condensed Consolidated Statements of Loss are for the three and six months ended June 30, 2025 and 2024:

[0000950170-25-102561:notes:196]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Network Solutions - Cost of revenue |  | $ | — |  |  | $ | 524 |  |  | $ | — |  |  | $ | 2,842 |  |
| Network Solutions - charges and inventory write-down |  |  | — |  |  |  | 143 |  |  | $ | — |  |  |  | 8,925 |  |
| Services & Support - Cost of revenue |  |  | — |  |  |  | 2,121 |  |  |  | — |  |  |  | 2,268 |  |
| Cost of revenue |  | $ | — |  |  | $ | 2,788 |  |  | $ | — |  |  | $ | 14,035 |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 3,497 |  |  |  | — |  |  |  | 5,299 |  |
| Research and development expenses |  |  | (284 | ) |  |  | 11,245 |  |  |  | (284 | ) |  |  | 15,306 |  |
| Total restructuring expenses |  | $ | (284 | ) |  | $ | 17,530 |  |  | $ | (284 | ) |  | $ | 34,640 |  |

[0000950170-25-102561:notes:197]
The following table represents the components of restructuring expenses by geographic area for the three and six months ended June 30, 2025 and 2024:

[0000950170-25-102561:notes:198]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| United States |  | $ | — |  |  | $ | 1,226 |  |  | $ | — |  |  | $ | 16,286 |  |
| International |  |  | (284 | ) |  |  | 16,304 |  |  |  | (284 | ) |  |  | 18,354 |  |
| Total restructuring expenses |  | $ | (284 | ) |  | $ | 17,530 |  |  | $ | (284 | ) |  | $ | 34,640 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000950170-25-102561:notes:199]
18. RESTATEMENT OF QUARTERLY FINANCIAL INFORMATION

[0000950170-25-102561:notes:200]
As previously disclosed in our Form 10-K/A and as discussed in Note 1 “Summary of Significant Accounting Policies”, the following tables reflect the impact of errors and other previously identified immaterial errors to the specific line items presented in our previously reported (a) Condensed Consolidated Balance Sheets; (b) Condensed Consolidated Statements of Loss and Condensed Consolidated Statements of Comprehensive Loss; (c) Condensed Consolidated Statements of Changes in Equity and; (d) Condensed Consolidated Statements of Cash Flows as of and for the three and six months ended June 30, 2024.

[0000950170-25-102561:notes:201]
|  |  |  | As of June 30, 2024 |  |
|  | Adj Reference |  | As Reported |  |  | Adjustment |  |  | As Restated |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Current Assets |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 111,185 |  |  | $ | — |  |  | $ | 111,185 |  |
| Accounts receivable, less allowance for credit losses of $191 as of June 30, 2024 |  |  |  | 186,176 |  |  |  | (1 | ) |  |  | 186,175 |  |
| Other receivables |  |  |  | 11,436 |  |  |  | — |  |  |  | 11,436 |  |
| Inventory, net | ADJ 3 |  |  | 287,860 |  |  |  | (4,221 | ) |  |  | 283,639 |  |
| Income tax receivable | ADJ 4 |  |  | 13,050 |  |  |  | (4,735 | ) |  |  | 8,315 |  |
| Prepaid expenses and other current assets |  |  |  | 58,612 |  |  |  | (3,188 | ) |  |  | 55,424 |  |
| Total Current Assets |  |  |  | 668,319 |  |  |  | (12,145 | ) |  |  | 656,174 |  |
| Property, plant and equipment, net |  |  |  | 134,578 |  |  |  | 3,513 |  |  |  | 138,091 |  |
| Goodwill | ADJ 4 |  |  | 54,897 |  |  |  | — |  |  |  | 54,897 |  |
| Intangibles, net |  |  |  | 290,793 |  |  |  | — |  |  |  | 290,793 |  |
| Deferred tax assets | ADJ 4 |  |  | 24,931 |  |  |  | 4,000 |  |  |  | 28,931 |  |
| Other non-current assets |  |  |  | 87,105 |  |  |  | — |  |  |  | 87,105 |  |
| Long-term investments |  |  |  | 30,159 |  |  |  | — |  |  |  | 30,159 |  |
| Total Assets |  |  | $ | 1,290,782 |  |  | $ | (4,632 | ) |  | $ | 1,286,150 |  |
| LIABILITIES, REDEEMABLE NON-CONTROLLING INTEREST AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 158,550 |  |  | $ | — |  |  | $ | 158,550 |  |
| Unearned revenue |  |  |  | 55,107 |  |  |  | — |  |  |  | 55,107 |  |
| Accrued expenses and other liabilities | ADJ 1 |  |  | 36,307 |  |  |  | (1,402 | ) |  |  | 34,905 |  |
| Accrued wages and benefits |  |  |  | 37,520 |  |  |  | 118 |  |  |  | 37,638 |  |
| Income tax payable, net |  |  |  | 2,228 |  |  |  | (20 | ) |  |  | 2,208 |  |
| Total Current Liabilities |  |  |  | 289,712 |  |  |  | (1,304 | ) |  |  | 288,408 |  |
| Non-current revolving credit agreement outstanding |  |  |  | 190,273 |  |  |  | — |  |  |  | 190,273 |  |
| Deferred tax liabilities | ADJ 4 |  |  | 21,077 |  |  |  | 420 |  |  |  | 21,497 |  |
| Non-current unearned revenue |  |  |  | 26,584 |  |  |  | — |  |  |  | 26,584 |  |
| Non-current pension liability |  |  |  | 11,505 |  |  |  | — |  |  |  | 11,505 |  |
| Deferred compensation liability |  |  |  | 30,601 |  |  |  | — |  |  |  | 30,601 |  |
| Non-current lease obligations |  |  |  | 26,613 |  |  |  | — |  |  |  | 26,613 |  |
| Other non-current liabilities | ADJ 1 |  |  | 34,445 |  |  |  | (701 | ) |  |  | 33,744 |  |
| Total Liabilities |  |  |  | 630,810 |  |  |  | (1,585 | ) |  |  | 629,225 |  |
| Commitments and contingencies (see Note 16) |  |  |  |  |  |  |  |  |  |  |
| Redeemable Non-Controlling Interest | ADJ 2 |  |  | 439,743 |  |  |  | 3,554 |  |  |  | 443,297 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01 per share; 200,000 shares authorized; 79,121 shares issued and 78,855 outstanding as of June 30, 2024 |  |  |  | 791 |  |  |  | — |  |  |  | 791 |  |
| Additional paid-in capital |  |  |  | 802,737 |  |  |  | (850 | ) |  |  | 801,887 |  |
| Accumulated other comprehensive income | ADJ 1, 3, 4 |  |  | 28,274 |  |  |  | 41 |  |  |  | 28,315 |  |
| Retained deficit | ADJ 2, 3, 4 |  |  | (606,375 | ) |  |  | (5,792 | ) |  |  | (612,167 | ) |
| Treasury stock at cost: 266 shares as of June 30, 2024 |  |  |  | (5,198 | ) |  |  | — |  |  |  | (5,198 | ) |
| Total Equity |  |  |  | 220,229 |  |  |  | (6,601 | ) |  |  | 213,628 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,290,782 |  |  | $ | (4,632 | ) |  | $ | 1,286,150 |  |

[0000950170-25-102561:notes:202]
|  |  |  | Three Months Ended June 30, 2024 |  |  | Six Months Ended June 30, 2024 |  |
|  | Adj Reference |  | As Reported |  |  | Adjustment |  |  | As Restated |  |  | As Reported |  |  | Adjustment |  |  | As Restated |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | $ | 179,194 |  |  | $ | — |  |  | $ | 179,194 |  |  | $ | 360,467 |  |  | $ | — |  |  | $ | 360,467 |  |
| Services & Support |  |  |  | 46,797 |  |  |  | — |  |  |  | 46,797 |  |  |  | 91,697 |  |  |  | — |  |  |  | 91,697 |  |
| Total Revenue |  |  |  | 225,991 |  |  |  | — |  |  |  | 225,991 |  |  |  | 452,164 |  |  |  | — |  |  |  | 452,164 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions | ADJ 3 |  |  | 124,457 |  |  |  | 316 |  |  |  | 124,773 |  |  |  | 250,783 |  |  |  | 2,256 |  |  |  | 253,039 |  |
| Network Solutions - Inventory Write Down |  |  |  | 143 |  |  |  | — |  |  |  | 143 |  |  |  | 8,925 |  |  |  | — |  |  |  | 8,925 |  |
| Services & Support |  |  |  | 19,816 |  |  |  | — |  |  |  | 19,816 |  |  |  | 38,626 |  |  |  | — |  |  |  | 38,626 |  |
| Total Cost of Revenue |  |  |  | 144,416 |  |  |  | 316 |  |  |  | 144,732 |  |  |  | 298,334 |  |  |  | 2,256 |  |  |  | 300,590 |  |
| Gross Profit |  |  |  | 81,575 |  |  |  | (316 | ) |  |  | 81,259 |  |  |  | 153,830 |  |  |  | (2,256 | ) |  |  | 151,574 |  |
| Selling, general and administrative expenses |  |  |  | 59,493 |  |  |  | (129 | ) |  |  | 59,364 |  |  |  | 118,593 |  |  |  | (238 | ) |  |  | 118,355 |  |
| Research and development expenses |  |  |  | 60,388 |  |  |  | (36 | ) |  |  | 60,352 |  |  |  | 120,639 |  |  |  | (72 | ) |  |  | 120,567 |  |
| Goodwill impairment |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 292,583 |  |  |  | 4,770 |  |  |  | 297,353 |  |
| Operating Loss |  |  |  | (38,306 | ) |  |  | (151 | ) |  |  | (38,457 | ) |  |  | (377,985 | ) |  |  | (6,716 | ) |  |  | (384,701 | ) |
| Interest and dividend income |  |  |  | 366 |  |  |  | — |  |  |  | 366 |  |  |  | 763 |  |  |  | — |  |  |  | 763 |  |
| Interest expense |  |  |  | (6,906 | ) |  |  | — |  |  |  | (6,906 | ) |  |  | (11,504 | ) |  |  | — |  |  |  | (11,504 | ) |
| Net investment gain |  |  |  | 872 |  |  |  | — |  |  |  | 872 |  |  |  | 3,125 |  |  |  | — |  |  |  | 3,125 |  |
| Other (expense) income, net |  |  |  | (901 | ) |  |  | — |  |  |  | (901 | ) |  |  | 409 |  |  |  | — |  |  |  | 409 |  |
| Loss Before Income Taxes |  |  |  | (44,875 | ) |  |  | (151 | ) |  |  | (45,026 | ) |  |  | (385,192 | ) |  |  | (6,716 | ) |  |  | (391,908 | ) |
| Income tax (expense) benefit |  |  |  | (2,136 | ) |  |  | — |  |  |  | (2,136 | ) |  |  | 16,511 |  |  |  | — |  |  |  | 16,511 |  |
| Net Loss |  |  | $ | (47,011 | ) |  | $ | (151 | ) |  | $ | (47,162 | ) |  | $ | (368,681 | ) |  | $ | (6,716 | ) |  | $ | (375,397 | ) |
| Net Income attributable to non-controlling interest | ADJ 1 |  |  | 2,854 |  |  |  | (349 | ) |  |  | 2,505 |  |  |  | 5,734 |  |  |  | (699 | ) |  |  | 5,035 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (49,865 | ) |  | $ | 198 |  |  | $ | (49,667 | ) |  | $ | (374,415 | ) |  | $ | (6,017 | ) |  | $ | (380,432 | ) |
| Weighted average shares outstanding – basic |  |  |  | 78,852 |  |  |  | 78,852 |  |  |  | 78,852 |  |  |  | 78,803 |  |  |  | 78,803 |  |  |  | 78,803 |  |
| Weighted average shares outstanding – diluted |  |  |  | 78,852 |  |  |  | 78,852 |  |  |  | 78,852 |  |  |  | 78,803 |  |  |  | 78,803 |  |  |  | 78,803 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (0.63 | ) |  | $ | 0.00 |  |  | $ | (0.63 | ) |  | $ | (4.75 | ) |  | $ | (0.08 | ) |  | $ | (4.83 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (0.63 | ) |  | $ | 0.00 |  |  | $ | (0.63 | ) |  | $ | (4.75 | ) |  | $ | (0.08 | ) |  | $ | (4.83 | ) |
| Net Loss |  |  | $ | (47,011 | ) |  | $ | (151 | ) |  | $ | (47,162 | ) |  | $ | (368,681 | ) |  | $ | (6,716 | ) |  | $ | (375,397 | ) |
| Other Comprehensive Loss, net of tax |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Defined benefit plan adjustments |  |  |  | (7 | ) |  |  | — |  |  |  | (7 | ) |  |  | (67 | ) |  |  | — |  |  |  | (67 | ) |
| Foreign currency translation loss | ADJ 1, 3, 4 |  |  | (1,375 | ) |  |  | (67 | ) |  |  | (1,442 | ) |  |  | (19,120 | ) |  |  | (95 | ) |  |  | (19,215 | ) |
| Other Comprehensive Loss, net of tax |  |  |  | (1,382 | ) |  |  | (67 | ) |  |  | (1,449 | ) |  |  | (19,187 | ) |  |  | (95 | ) |  |  | (19,282 | ) |
| Comprehensive Loss, net of tax |  |  |  | (48,393 | ) |  |  | (218 | ) |  |  | (48,611 | ) |  |  | (387,868 | ) |  |  | (6,811 | ) |  |  | (394,679 | ) |
| Less: Comprehensive Income attributable to non-controlling interest | ADJ 1 |  |  | 2,854 |  |  |  | (350 | ) |  |  | 2,504 |  |  |  | 5,734 |  |  |  | (699 | ) |  |  | 5,035 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (51,247 | ) |  | $ | 132 |  |  | $ | (51,115 | ) |  | $ | (393,602 | ) |  | $ | (6,112 | ) |  | $ | (399,714 | ) |

[0000950170-25-102561:notes:203]
|  |  | Retained Deficit |  |  | Accumulated Other Comprehensive Income |  |  | Additional paid-in capital |  |
| (In thousands) |  | As Reported |  |  | Adjustment |  |  | As Restated |  |  | As Reported |  |  | Adjustment |  |  | As Restated |  |  | As Reported |  |  | Adjustment |  |  | As Restated |  |
| Balance as of December 31, 2023 |  | $ | (243,908 | ) |  | $ | 12,202 |  |  | $ | (231,706 | ) |  | $ | 47,461 |  |  | $ | 69 |  |  | $ | 47,530 |  |  | $ | 795,304 |  |  | $ | (836 | ) |  | $ | 794,468 |  |
| Net loss |  |  | (321,670 | ) |  |  | (6,565 | ) |  |  | (328,235 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Annual recurring compensation earned |  |  | (2,880 | ) |  |  | 349 |  |  |  | (2,531 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive loss, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (17,805 | ) |  |  | (28 | ) |  |  | (17,833 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Deferred compensation adjustments, net of tax |  |  | 3 |  |  |  | — |  |  |  | 3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (368 | ) |  |  | — |  |  |  | (368 | ) |
| ADTRAN RSUs and restricted stock vested |  |  | (243 | ) |  |  | — |  |  |  | (243 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| ADTRAN stock options exercised |  |  | 219 |  |  |  | — |  |  |  | 219 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| ADTRAN stock-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,957 |  |  |  | — |  |  |  | 3,957 |  |
| Redemption of redeemable non-controlling interest |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | 10,115 |  |  |  | (10,115 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Adtran Networks stock-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | (10 | ) |  |  | (6 | ) |
| Balance as of March 31, 2024 |  | $ | (558,363 | ) |  | $ | (4,129 | ) |  | $ | (562,492 | ) |  | $ | 29,656 |  |  | $ | 41 |  |  | $ | 29,697 |  |  | $ | 798,897 |  |  | $ | (846 | ) |  | $ | 798,051 |  |
| Net loss |  |  | (47,011 | ) |  |  | (151 | ) |  |  | (47,162 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Annual recurring compensation earned |  |  | (2,854 | ) |  |  | 350 |  |  |  | (2,504 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive loss, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,382 | ) |  |  | — |  |  |  | (1,382 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Deferred compensation adjustments, net of tax |  |  | (3 | ) |  |  | — |  |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| ADTRAN RSUs and restricted stock vested |  |  | (16 | ) |  |  | — |  |  |  | (16 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| ADTRAN stock-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,836 |  |  |  | — |  |  |  | 3,836 |  |
| Redemption of redeemable non-controlling interest |  |  | 4 |  |  |  | — |  |  |  | 4 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | 1,868 |  |  |  | (1,868 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Adtran Networks stock-based compensation expense |  |  | — |  |  |  | 6 |  |  |  | 6 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4 |  |  |  | (4 | ) |  |  | — |  |
| Balance as of June 30, 2024 |  | $ | (606,375 | ) |  | $ | (5,792 | ) |  | $ | (612,167 | ) |  | $ | 28,274 |  |  | $ | 41 |  |  | $ | 28,315 |  |  | $ | 802,737 |  |  | $ | (850 | ) |  | $ | 801,887 |  |

[0000950170-25-102561:notes:204]
|  |  |  | Six Months Ended June 30, 2024 |  |
|  | Adj Reference |  | As Reported |  |  | Adjustment |  |  | As Restated |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net Loss |  |  | $ | (368,681 | ) |  | $ | (6,716 | ) |  | $ | (375,397 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  | 45,156 |  |  |  | (313 | ) |  |  | 44,843 |  |
| Goodwill Impairment | ADJ 4 |  |  | 292,583 |  |  |  | 4,770 |  |  |  | 297,353 |  |
| Amortization of debt issuance cost |  |  |  | 1,013 |  |  |  | — |  |  |  | 1,013 |  |
| Gain on investments, net |  |  |  | (2,867 | ) |  |  | — |  |  |  | (2,867 | ) |
| Net loss on disposal of property, plant and equipment |  |  |  | 185 |  |  |  | — |  |  |  | 185 |  |
| Stock-based compensation expense |  |  |  | 7,793 |  |  |  | (6 | ) |  |  | 7,787 |  |
| Deferred income taxes |  |  |  | (13,684 | ) |  |  | — |  |  |  | (13,684 | ) |
| Other, net |  |  |  | (126 | ) |  |  | — |  |  |  | (126 | ) |
| Inventory write down - business efficiency program |  |  |  | 4,135 |  |  |  | — |  |  |  | 4,135 |  |
| Inventory reserves |  |  |  | 3,722 |  |  |  | — |  |  |  | 3,722 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  | 26,913 |  |  |  | (3,498 | ) |  |  | 23,415 |  |
| Other receivables |  |  |  | 6,279 |  |  |  | — |  |  |  | 6,279 |  |
| Income taxes receivable, net |  |  |  | (5,653 | ) |  |  | 4,735 |  |  |  | (918 | ) |
| Inventory | ADJ 3 |  |  | 62,151 |  |  |  | 2,256 |  |  |  | 64,407 |  |
| Prepaid expenses, other current assets and other assets |  |  |  | (14,731 | ) |  |  | (3,408 | ) |  |  | (18,139 | ) |
| Accounts payable |  |  |  | (3,966 | ) |  |  | — |  |  |  | (3,966 | ) |
| Accrued expenses and other liabilities |  |  |  | 19,152 |  |  |  | 3,493 |  |  |  | 22,645 |  |
| Income taxes payable, net |  |  |  | (2,878 | ) |  |  | — |  |  |  | (2,878 | ) |
| Net cash provided by operating activities |  |  |  | 56,496 |  |  |  | 1,313 |  |  |  | 57,809 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  |  | (23,644 | ) |  |  | (1,327 | ) |  |  | (24,971 | ) |
| Purchases of intangibles - developed technology |  |  |  | (5,725 | ) |  |  | — |  |  |  | (5,725 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  |  | 956 |  |  |  | — |  |  |  | 956 |  |
| Purchases of available-for-sale investments |  |  |  | (121 | ) |  |  | — |  |  |  | (121 | ) |
| Net cash used in investing activities |  |  |  | (28,534 | ) |  |  | (1,327 | ) |  |  | (29,861 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  |  | (189 | ) |  |  | — |  |  |  | (189 | ) |
| Proceeds from stock option exercises |  |  |  | 219 |  |  |  | — |  |  |  | 219 |  |
| Proceeds from receivables purchase agreement |  |  |  | 68,556 |  |  |  | — |  |  |  | 68,556 |  |
| Repayments on receivables purchase agreement |  |  |  | (66,399 | ) |  |  | — |  |  |  | (66,399 | ) |
| Repayment of revolving credit agreements |  |  |  | (5,000 | ) |  |  | — |  |  |  | (5,000 | ) |
| Payment for redemption of redeemable non-controlling interest |  |  |  | (25 | ) |  |  | — |  |  |  | (25 | ) |
| Payment of debt issuance cost |  |  |  | (1,994 | ) |  |  | — |  |  |  | (1,994 | ) |
| Net cash used in financing activities |  |  |  | (4,832 | ) |  |  | — |  |  |  | (4,832 | ) |
| Net increase in cash and cash equivalents |  |  |  | 23,130 |  |  |  | (14 | ) |  |  | 23,116 |  |
| Effect of exchange rate changes |  |  |  | 888 |  |  |  | 14 |  |  |  | 902 |  |
| Cash and cash equivalents, beginning of period |  |  |  | 87,167 |  |  |  | — |  |  |  | 87,167 |  |
| Cash and cash equivalents, end of period |  |  | $ | 111,185 |  |  | $ | — |  |  | $ | 111,185 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  |  | $ | 6,554 |  |  | $ | — |  |  | $ | 6,554 |  |
| Cash paid for income taxes |  |  | $ | 7,433 |  |  | $ | — |  |  | $ | 7,433 |  |
| Cash used in operating activities related to operating leases |  |  | $ | 4,780 |  |  | $ | — |  |  | $ | 4,780 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  |  | $ | 1,999 |  |  | $ | — |  |  | $ | 1,999 |  |
| Purchases of property, plant and equipment included in accounts payable |  |  | $ | 1,059 |  |  | $ | — |  |  | $ | 1,059 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-25-102561:notes:205]
19. SUBSEQUENT EVENTS

[0000950170-25-102561:notes:206]
Annual Recurring Compensation Payment in accordance with the DPLTA

[0000950170-25-102561:notes:207]
On July 1, 2025, the Company paid $10.1 million with respect to the 2024 fiscal year Annual Recurring Compensation. See Note 13 for additional information on the Annual Recurring Compensation payment.

[0000950170-25-102561:notes:208]
Enactment of the “One Big Beautiful Bill Act”

[0000950170-25-102561:notes:209]
On July 4, 2025, the “One Big Beautiful Bill Act” (OBBBA) was signed into law, which constitutes the enactment date of the tax reconciliation bill under U.S. GAAP. Key corporate tax provisions include the restoration of 100% bonus depreciation, expensing of domestic research and experimental expenditures under Section 174A, modifications to Section 163(j) interest expense limitations, updates to the rules governing global intangible low-taxed income and foreign-derived intangible income, amendments to energy credits, and expanded Section 162(m) aggregation requirements. In accordance with ASC 740, the effects of the new tax law will be recognized in the period of enactment. The Company is currently evaluating the impact of the OBBBA, and an estimate of the financial effect is not yet available.
