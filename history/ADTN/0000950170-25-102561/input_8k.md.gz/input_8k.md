# ADTN 8-K — 0000950170-25-102401 filed 2025-08-05

## item codes, every 8-K on or before 2025-08-05

- 2025-08-05 0000950170-25-102401 — 2.02, 7.01, 9.01
- 2025-07-30 0000950170-25-100222 — 5.07, 8.01, 9.01
- 2025-07-17 0000950170-25-096408 — 2.02, 7.01, 9.01 — amendment of 0000950170-25-096231
- 2025-07-16 0000950170-25-096231 — 2.02, 7.01, 9.01
- 2025-05-28 0000950170-25-077995 — 2.02, 9.01
- 2025-05-27 0001193125-25-127878 — 8.01, 9.01
- 2025-05-13 0000950170-25-070473 — 4.02, 8.01, 9.01
- 2025-05-12 0000950170-25-069478 — 1.01, 9.01
- 2025-05-08 0000950170-25-066343 — 2.02, 7.01, 9.01
- 2025-04-16 0001193125-25-081800 — 7.01, 9.01
- 2025-03-07 0001193125-25-048727 — 5.02, 7.01, 9.01
- 2025-02-27 0000950170-25-028352 — 2.02, 7.01, 9.01
- 2024-11-07 0000950170-24-122762 — 2.02, 7.01, 9.01
- 2024-08-30 0000950170-24-102309 — 5.02, 9.01
- 2024-08-06 0000950170-24-091207 — 2.02, 7.01, 9.01
- 2024-08-02 0000950170-24-089974 — 5.02
- 2024-06-10 0001193125-24-158388 — 1.01, 2.03, 9.01
- 2024-05-09 0000950170-24-056830 — 5.02, 5.07, 9.01
- 2024-05-07 0000950170-24-053920 — 2.02, 7.01, 9.01
- 2024-05-03 0001193125-24-130896 — 2.02, 7.01, 9.01
- 2024-04-17 0000950170-24-045151 — 2.05, 9.01
- 2024-03-15 0000950170-24-031864 — 2.02, 9.01
- 2024-02-27 0000950170-24-020613 — 2.02, 7.01, 9.01
- 2024-02-20 0001193125-24-040068 — 4.02
- 2024-01-22 0001193125-24-011697 — 1.01, 2.03, 9.01
- 2023-12-06 0001193125-23-289895 — 5.02, 9.01
- 2023-12-05 0001193125-23-289150 — 5.02, 9.01
- 2023-11-07 0001193125-23-271842 — 2.02, 7.01, 9.01
- 2023-10-24 0001193125-23-261665 — 5.02, 5.03, 9.01
- 2023-10-17 0001193125-23-257289 — 2.02, 7.01, 9.01
- 2023-09-29 0001193125-23-246498 — 5.02
- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2025-08-05

- 2025-05-13 0000950170-25-070493 — NT 10-Q, for the period ended 2025-05-13
- 2024-02-29 0000950170-24-023141 — NT 10-K, for the period ended 2023-12-31
- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-25-102401:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0000950170-25-102401:8k_2_02:2]
EX-99.1

[0000950170-25-102401:8k_2_02:3]
ADTRAN Holdings, Inc. reports second quarter 2025 financial results

[0000950170-25-102401:8k_2_02:4]
Huntsville, Alabama, USA. — Aug. 4, 2025 — ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” “ADTRAN” or the “Company”) today announced its unaudited financial results for the second quarter ended June 30, 2025.

[0000950170-25-102401:8k_2_02:5]
•
Revenue: $265.1 million, higher by 17% year-over-year.

[0000950170-25-102401:8k_2_02:6]
•
Gross margin: GAAP gross margin: 37.3%; non-GAAP gross margin: 41.4%.

[0000950170-25-102401:8k_2_02:7]
•
Operating margin: GAAP operating margin (5.0)%, non-GAAP operating margin 3.0%.

[0000950170-25-102401:8k_2_02:8]
•
Net cash provided by operating activities of $32.2 million.

[0000950170-25-102401:8k_2_02:9]
•
Cash and cash equivalents of $106.3 million, an increase of $5.0 million sequentially.

[0000950170-25-102401:8k_2_02:10]
ADTRAN Holdings Chairman and Chief Executive Officer Tom Stanton stated, “We delivered strong second quarter results with revenue growth that exceeded expectations, reflecting solid execution across our business and increasing demand. We experienced growth across all major revenue categories and gained market share in key areas. We also continued to strengthen our balance sheet with solid cash generation. These results underscore the impact of our strategic product investments and the trust customers are placing in Adtran to help them evolve and scale their networks to meet the demands of cloud, AI, and edge computing”

[0000950170-25-102401:8k_2_02:11]
Mr. Stanton added, “Looking forward, our bookings and pipeline reinforce our confidence in continued gains in profitability and cash flow. With a clear strategy, global reach, and investment in next-generation network architectures, Adtran remains well-positioned.”

[0000950170-25-102401:8k_2_02:12]
Business outlook1

[0000950170-25-102401:8k_2_02:13]
For the third quarter of 2025, the Company expects revenue to be within a range of $270.0 million to $280.0 million. Non-GAAP operating margin is expected to be within a range of 3.0% to 7.0%.

[0000950170-25-102401:8k_2_02:14]
1 Non-GAAP operating margin (which is calculated as non-GAAP operating income (loss) divided by revenue) is a non-GAAP financial measure. The Company has provided third quarter 2025 guidance with regard to non-GAAP operating margin. This measure excludes from the corresponding GAAP financial measure the effect of adjustments as described below. The Company has not provided a reconciliation of such non-GAAP guidance to guidance presented on a GAAP basis because it cannot predict and quantify without unreasonable effort all of the adjustments that may occur during the period due to the difficulty of predicting the timing and amounts of various items within a reasonable range. In particular, non-GAAP operating margin excludes certain items, such as acquisition related expenses, amortizations and adjustments, stock-based compensation expense, restructuring expenses, integration expenses, deferred compensation adjustments, professional fees and other expenses and goodwill impairment that the Company is unable to quantitatively predict. Depending on the materiality of these items, they could have a significant impact on the Company's GAAP financial results.

[0000950170-25-102401:8k_2_02:15]
Conference call

[0000950170-25-102401:8k_2_02:16]
The Company will hold a conference call to discuss its second quarter 2025 results on Tuesday, Aug. 5, 2025, at 9:30 a.m. Central Time (4:30 p.m. Central European Summer Time). The Company will webcast this conference call at the events and presentations section of ADTRAN Holdings, Inc. Investor Relations website at https://events.q4inc.com/attendee/260991346 approximately 10 minutes before the start of the call, or you may dial 1-888-330-2391 (Toll-Free US) or 1-240-789-2702, and use Conference ID 8936454.

[0000950170-25-102401:8k_2_02:17]
An online replay of the Company’s conference call, as well as the transcript of the call, will be available on the Investor Relations site https://investors.adtran.com/ shortly following the call and will remain available for at least 12 months. For more information, visit https://investors.adtran.com or email investor.relations@adtran.com.

[0000950170-25-102401:8k_2_02:18]
Upcoming conference schedule

[0000950170-25-102401:8k_2_02:19]
August 19, 2025: Rosenblatt Age of AI Tech Conference (Virtual)

[0000950170-25-102401:8k_2_02:20]
August 26, 2025: Evercore ISI Semiconductor, IT Hardware, & Networking Investor Conference

[0000950170-25-102401:8k_2_02:21]
September 10, 2025: Wolfe Research TMT Conference

[0000950170-25-102401:8k_2_02:22]
About Adtran

[0000950170-25-102401:8k_2_02:23]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to

[0000950170-25-102401:8k_2_02:24]
manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises, government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the majority shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE (“Adtran Networks”). Find more at Adtran.com, LinkedIn and X.

[0000950170-25-102401:8k_2_02:25]
Cautionary note regarding forward-looking statements

[0000950170-25-102401:8k_2_02:26]
Explanation of use of non-GAAP financial measures

[0000950170-25-102401:8k_2_02:27]
Set forth in the tables below are reconciliations of gross profit, gross margin, operating expenses, operating loss, operating margin, other expense, net loss inclusive of the non-controlling interest, net loss attributable to the Company, and loss per share - basic and diluted, attributable to the Company, and net cash provided by operating activities, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income (loss), non-GAAP operating margin, non-GAAP other expense, non-GAAP net income (loss) inclusive of the non-controlling interest, non-GAAP net income (loss) attributable to the Company, non-GAAP net earnings (loss) per share - basic and diluted, attributable to the Company, and free cash flow, respectively. Such non-GAAP measures exclude acquisition-related expenses, amortization and adjustments (consisting of intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations), stock-based compensation expense, restructuring expenses, integration expenses, deferred compensation adjustments, goodwill impairments, professional fees and other expenses, amortization of pension actuarial losses, the tax effect of these adjustments to net loss and purchases of property, plant and equipment. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of these non-GAAP measures, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company. These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0000950170-25-102401:8k_2_02:28]
Published by

[0000950170-25-102401:8k_2_02:29]
ADTRAN Holdings, Inc.

[0000950170-25-102401:8k_2_02:30]
www.adtran.com

[0000950170-25-102401:8k_2_02:31]
For media

[0000950170-25-102401:8k_2_02:32]
Gareth Spence

[0000950170-25-102401:8k_2_02:33]
+44 1904 699 358

[0000950170-25-102401:8k_2_02:34]
public.relations@adtran.com

[0000950170-25-102401:8k_2_02:35]
For investors

[0000950170-25-102401:8k_2_02:36]
Peter Schuman, IRC

[0000950170-25-102401:8k_2_02:37]
+1 256 963 6305

[0000950170-25-102401:8k_2_02:38]
investor.relations@adtran.com

[0000950170-25-102401:8k_2_02:39]
Condensed Consolidated Balance Sheets

[0000950170-25-102401:8k_2_02:40]
(Unaudited)

[0000950170-25-102401:8k_2_02:41]
(In thousands)

[0000950170-25-102401:8k_2_02:42]
|  | June 30, |  |  | December 31, |  |
|  | 2025 |  |  | 2024 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 106,271 |  |  | $ | 76,021 |  |
| Accounts receivable, net |  | 164,768 |  |  |  | 178,030 |  |
| Other receivables |  | 8,354 |  |  |  | 9,775 |  |
| Inventory, net |  | 240,081 |  |  |  | 261,557 |  |
| Income tax receivable |  | 8,136 |  |  |  | 5,461 |  |
| Prepaid expenses and other current assets |  | 67,717 |  |  |  | 56,395 |  |
| Assets held for sale |  | 11,901 |  |  |  | 11,901 |  |
| Total Current Assets |  | 607,228 |  |  |  | 599,140 |  |
| Property, plant and equipment, net |  | 111,936 |  |  |  | 106,454 |  |
| Goodwill |  | 60,194 |  |  |  | 52,918 |  |
| Intangible assets, net |  | 310,169 |  |  |  | 284,893 |  |
| Deferred tax assets |  | 17,826 |  |  |  | 17,826 |  |
| Other non-current assets |  | 75,826 |  |  |  | 78,128 |  |
| Long-term investments |  | 33,116 |  |  |  | 32,060 |  |
| Total Assets | $ | 1,216,295 |  |  | $ | 1,171,419 |  |
| Liabilities, Redeemable Non-Controlling Interest and Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 178,287 |  |  | $ | 171,825 |  |
| Unearned revenue |  | 62,695 |  |  |  | 52,701 |  |
| Accrued expenses and other liabilities |  | 38,127 |  |  |  | 34,158 |  |
| Accrued wages and benefits |  | 29,532 |  |  |  | 32,853 |  |
| Income tax payable, net |  | 1,019 |  |  |  | 1,936 |  |
| Total Current Liabilities |  | 309,660 |  |  |  | 293,473 |  |
| Non-current revolving credit agreement |  | 190,180 |  |  |  | 189,576 |  |
| Deferred tax liabilities |  | 32,866 |  |  |  | 30,372 |  |
| Non-current unearned revenue |  | 24,429 |  |  |  | 22,065 |  |
| Non-current pension liability |  | 9,686 |  |  |  | 8,983 |  |
| Deferred compensation liability |  | 34,390 |  |  |  | 33,203 |  |
| Non-current lease obligations |  | 27,783 |  |  |  | 25,925 |  |
| Other non-current liabilities |  | 15,599 |  |  |  | 17,928 |  |
| Total Liabilities |  | 644,593 |  |  |  | 621,525 |  |
| Redeemable Non-Controlling Interest |  | 402,089 |  |  |  | 422,943 |  |
| Equity |  |  |  |  |  |
| Common stock |  | 800 |  |  |  | 795 |  |
| Additional paid-in capital |  | 814,749 |  |  |  | 808,913 |  |
| Accumulated other comprehensive income |  | 78,355 |  |  |  | 11,254 |  |
| Retained deficit |  | (719,183 | ) |  |  | (688,813 | ) |
| Treasury stock |  | (5,108 | ) |  |  | (5,198 | ) |
| Total Equity |  | 169,613 |  |  |  | 126,951 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity | $ | 1,216,295 |  |  | $ | 1,171,419 |  |

[0000950170-25-102401:8k_2_02:43]
Condensed Consolidated Statements of Loss

[0000950170-25-102401:8k_2_02:44]
(Unaudited)

[0000950170-25-102401:8k_2_02:45]
(In thousands, except per share amounts)

[0000950170-25-102401:8k_2_02:46]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |  |
|  |  |  |  |  | (Restated) |  |  |  |  |  | (Restated) |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 219,498 |  |  | $ | 179,194 |  |  | $ | 421,715 |  |  | $ | 360,467 |  |  |
| Services & Support |  |  | 45,570 |  |  |  | 46,797 |  |  |  | 91,097 |  |  |  | 91,697 |  |  |
| Total Revenue |  |  | 265,068 |  |  |  | 225,991 |  |  |  | 512,812 |  |  |  | 452,164 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 147,321 |  |  |  | 124,773 |  |  |  | 281,562 |  |  |  | 253,039 |  |  |
| Network Solutions - charges and inventory write-down |  |  | — |  |  |  | 143 |  |  |  | — |  |  |  | 8,925 |  |  |
| Services & Support |  |  | 18,823 |  |  |  | 19,816 |  |  |  | 37,150 |  |  |  | 38,626 |  |  |
| Total Cost of Revenue |  |  | 166,144 |  |  |  | 144,732 |  |  |  | 318,712 |  |  |  | 300,590 |  |  |
| Gross Profit |  |  | 98,924 |  |  |  | 81,259 |  |  |  | 194,100 |  |  |  | 151,574 |  |  |
| Selling, general and administrative expenses |  |  | 60,347 |  |  |  | 59,364 |  |  |  | 110,632 |  |  |  | 118,355 |  |  |
| Research and development expenses |  |  | 51,895 |  |  |  | 60,352 |  |  |  | 100,754 |  |  |  | 120,567 |  |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 297,353 |  |  |
| Operating Loss |  |  | (13,318 | ) |  |  | (38,457 | ) |  |  | (17,286 | ) |  |  | (384,701 | ) |  |
| Interest and dividend income |  |  | 201 |  |  |  | 366 |  |  |  | 327 |  |  |  | 763 |  |  |
| Interest expense |  |  | (4,564 | ) |  |  | (6,906 | ) |  |  | (9,325 | ) |  |  | (11,504 | ) |  |
| Net investment gain |  |  | 3,075 |  |  |  | 872 |  |  |  | 1,389 |  |  |  | 3,125 |  |  |
| Other (expense) income, net |  |  | (2,636 | ) |  |  | (901 | ) |  |  | (1,692 | ) |  |  | 409 |  |  |
| Loss Before Income Taxes |  |  | (17,242 | ) |  |  | (45,026 | ) |  |  | (26,587 | ) |  |  | (391,908 | ) |  |
| Income tax (expense) benefit |  |  | (1,016 | ) |  |  | (2,136 | ) |  |  | (619 | ) |  |  | 16,511 |  |  |
| Net Loss |  | $ | (18,258 | ) |  | $ | (47,162 | ) |  | $ | (27,206 | ) |  | $ | (375,397 | ) |  |
| Less: Net Income attributable to non-controlling interest (1) |  |  | 2,273 |  |  |  | 2,505 |  |  |  | 4,592 |  |  |  | 5,035 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (20,531 | ) |  | $ | (49,667 | ) |  | $ | (31,798 | ) |  | $ | (380,432 | ) |  |
| Weighted average shares outstanding – basic |  |  | 79,748 |  |  |  | 78,852 |  |  |  | 79,642 |  |  |  | 78,803 |  |  |
| Weighted average shares outstanding – diluted |  |  | 79,748 |  |  |  | 78,852 |  |  |  | 79,642 |  |  |  | 78,803 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.24 | ) | (2) | $ | (0.63 | ) |  | $ | (0.38 | ) | (2) | $ | (4.83 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.24 | ) | (2) | $ | (0.63 | ) |  | $ | (0.38 | ) | (2) | $ | (4.83 | ) |  |

[0000950170-25-102401:8k_2_02:47]
(1) For the three and six months ended June 30, 2025 we accrued $2.4 million and $4.8 million, respectively, net income attributable to non-controlling interest, representing the recurring cash compensation earned by non-controlling interest shareholders post-DPLTA. For the three and six months ended June 30, 2024, we accrued $2.5 million and $5.0 million, respectively, representing the recurring cash compensation earned by non-controlling interest shareholders post-DPLTA.

[0000950170-25-102401:8k_2_02:48]
(2) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $1.5 million effect of redemption of RNCI for the three and six months ended June 30, 2025.

[0000950170-25-102401:8k_2_02:49]
Condensed Consolidated Statements of Cash Flows

[0000950170-25-102401:8k_2_02:50]
(Unaudited)

[0000950170-25-102401:8k_2_02:51]
(In thousands)

[0000950170-25-102401:8k_2_02:52]
|  |  | June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  | (Restated) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net loss |  | $ | (27,206 | ) |  | $ | (375,397 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 44,990 |  |  |  | 44,843 |  |
| Goodwill impairment |  |  | — |  |  |  | 297,353 |  |
| Amortization of debt issuance cost |  |  | 639 |  |  |  | 1,013 |  |
| Gain on investments, net |  |  | (1,506 | ) |  |  | (2,867 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 24 |  |  |  | 185 |  |
| Stock-based compensation expense |  |  | 5,888 |  |  |  | 7,787 |  |
| Deferred income taxes |  |  | 1,189 |  |  |  | (13,684 | ) |
| Other, net |  |  | — |  |  |  | (126 | ) |
| Inventory write down - business efficiency program |  |  | — |  |  |  | 4,135 |  |
| Inventory reserves |  |  | 9,176 |  |  |  | 3,722 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 25,754 |  |  |  | 23,415 |  |
| Other receivables |  |  | 1,416 |  |  |  | 6,279 |  |
| Income taxes receivable, net |  |  | (2,349 | ) |  |  | (918 | ) |
| Inventory |  |  | 29,594 |  |  |  | 64,407 |  |
| Prepaid expenses, other current assets and other assets |  |  | 6,095 |  |  |  | (18,139 | ) |
| Accounts payable |  |  | (6,242 | ) |  |  | (3,966 | ) |
| Accrued expenses and other liabilities |  |  | (11,305 | ) |  |  | 22,645 |  |
| Income taxes payable, net |  |  | (816 | ) |  |  | (2,878 | ) |
| Net cash provided by operating activities |  |  | 75,341 |  |  |  | 57,809 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (12,084 | ) |  |  | (24,971 | ) |
| Purchases of intangibles - developed technology |  |  | (20,444 | ) |  |  | (5,725 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 727 |  |  |  | 956 |  |
| Purchases of available-for-sale investments |  |  | (243 | ) |  |  | (121 | ) |
| Payments for beneficial interests in securitized accounts receivable |  |  | (49 | ) |  |  | — |  |
| Net cash used in investing activities |  |  | (32,093 | ) |  |  | (29,861 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (1,223 | ) |  |  | (189 | ) |
| Proceeds from stock option exercises |  |  | 1,163 |  |  |  | 219 |  |
| Proceeds from receivables purchase agreement |  |  | — |  |  |  | 68,556 |  |
| Repayments on receivables purchase agreement |  |  | — |  |  |  | (66,399 | ) |
| Proceeds from draw on revolving credit agreements |  |  | 24,000 |  |  |  | — |  |
| Repayment of revolving credit agreements |  |  | (24,000 | ) |  |  | (5,000 | ) |
| Payment of debt issuance cost |  |  | (64 | ) |  |  | (1,994 | ) |
| Payment for redemption of redeemable non-controlling interest |  |  | (19,363 | ) |  |  | (25 | ) |
| Net cash used in financing activities |  |  | (19,487 | ) |  |  | (4,832 | ) |
| Net increase in cash and cash equivalents |  |  | 23,761 |  |  |  | 23,116 |  |
| Effect of exchange rate changes |  |  | 6,489 |  |  |  | 902 |  |
| Cash and cash equivalents, beginning of period |  |  | 76,021 |  |  |  | 87,167 |  |
| Cash and cash equivalents, end of period |  | $ | 106,271 |  |  | $ | 111,185 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 8,049 |  |  | $ | 6,554 |  |
| Cash paid for income taxes, net of refunds |  | $ | 4,155 |  |  | $ | 7,433 |  |
| Cash used in operating activities related to operating leases |  | $ | 5,236 |  |  | $ | 4,780 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |
| Redemption of redeemable non-controlling interest |  | $ | 1,491 |  |  | $ | — |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 3,538 |  |  | $ | 1,999 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 1,450 |  |  | $ | 1,059 |  |

[0000950170-25-102401:8k_2_02:53]
Supplemental Information

[0000950170-25-102401:8k_2_02:54]
Reconciliation of Gross Profit and Gross Margin to

[0000950170-25-102401:8k_2_02:55]
Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0000950170-25-102401:8k_2_02:56]
(Unaudited)

[0000950170-25-102401:8k_2_02:57]
(In thousands)

[0000950170-25-102401:8k_2_02:58]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | March 31, |  |  | June 30, |  |  |  | June 30, |  |  | June 30, |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  |  | (Restated) |  |
| Total Revenue |  | $ | 265,068 |  |  | $ | 247,744 |  |  | $ | 225,991 |  |  |  | $ | 512,812 |  |  | $ | 452,164 |  |
| Cost of Revenue |  |  | 166,144 |  |  |  | 152,568 |  |  |  | 144,732 |  |  |  | $ | 318,712 |  |  | $ | 300,590 |  |
| Acquisition-related expenses, amortizations and adjustments (1) |  |  | (10,599 | ) |  |  | (9,831 | ) |  |  | (10,064 | ) |  |  |  | (20,430 | ) |  |  | (20,241 | ) |
| Stock-based compensation expense |  |  | (222 | ) |  |  | (267 | ) |  |  | (280 | ) |  |  |  | (489 | ) |  |  | (555 | ) |
| Restructuring expenses (2) |  |  | — |  |  |  | — |  |  |  | (2,788 | ) |  |  |  | — |  |  |  | (14,035 | ) |
| Integration expenses (3) |  |  | — |  |  |  | — |  |  |  | (35 | ) |  |  |  | — |  |  |  | (70 | ) |
| Non-GAAP Cost of Revenue |  | $ | 155,323 |  |  | $ | 142,470 |  |  | $ | 131,565 |  |  |  | $ | 297,793 |  |  | $ | 265,689 |  |
| Gross Profit |  | $ | 98,924 |  |  | $ | 95,176 |  |  | $ | 81,259 |  |  |  | $ | 194,100 |  |  | $ | 151,574 |  |
| Non-GAAP Gross Profit |  | $ | 109,745 |  |  | $ | 105,274 |  |  | $ | 94,426 |  |  |  | $ | 215,019 |  |  | $ | 186,475 |  |
| Gross Margin |  |  | 37.3 | % |  |  | 38.4 | % |  |  | 36.0 | % |  |  |  | 37.9 | % |  |  | 33.5 | % |
| Non-GAAP Gross Margin |  |  | 41.4 | % |  |  | 42.5 | % |  |  | 41.8 | % |  |  |  | 41.9 | % |  |  | 41.2 | % |

[0000950170-25-102401:8k_2_02:59]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-102401:8k_2_02:60]
(2) Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:61]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks which was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:62]
Supplemental Information

[0000950170-25-102401:8k_2_02:63]
Reconciliation of Operating Expenses to Non-GAAP Operating Expenses

[0000950170-25-102401:8k_2_02:64]
(Unaudited)

[0000950170-25-102401:8k_2_02:65]
(In thousands)

[0000950170-25-102401:8k_2_02:66]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | March 31, |  |  | June 30, |  |  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  |  | (Restated) |  |  |
| Operating Expenses |  | $ | 112,242 |  |  | $ | 99,144 |  |  | $ | 119,716 |  |  |  | $ | 211,386 |  |  | $ | 536,275 |  |  |
| Acquisition-related expenses, amortizations and adjustments (1) |  |  | (2,175 | ) | (2) |  | (2,249 | ) | (8) |  | (7,233 | ) | (11) |  |  | (4,424 | ) | (14) |  | (12,114 | ) | (16) |
| Stock-based compensation expense |  |  | (2,451 | ) | (3) |  | (2,943 | ) | (9) |  | (3,317 | ) | (12) |  |  | (5,394 | ) | (15) |  | (6,759 | ) | (17) |
| Restructuring expenses |  |  | 284 |  | (4) |  | — |  | (10) |  | (14,742 | ) | (13) |  |  | 284 |  | (4) |  | (20,604 | ) | (18) |
| Integration expenses (5) |  |  | — |  |  |  | — |  |  |  | (531 | ) |  |  |  | — |  |  |  | (1,011 | ) |  |
| Deferred compensation adjustments (6) |  |  | (3,034 | ) |  |  | 1,547 |  |  |  | (848 | ) |  |  |  | (1,487 | ) |  |  | (2,788 | ) |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | (297,353 | ) | (19) |
| Professional fees and other expenses |  |  | (3,153 | ) | (7) |  | — |  |  |  | — |  |  |  |  | (3,153 | ) | (7) |  | — |  |  |
| Non-GAAP Operating Expenses |  | $ | 101,713 |  |  | $ | 95,499 |  |  | $ | 93,045 |  |  |  | $ | 197,212 |  |  | $ | 195,646 |  |  |

[0000950170-25-102401:8k_2_02:67]
(1) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-102401:8k_2_02:68]
(2) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $1.7 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-102401:8k_2_02:69]
(3) $1.8 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-102401:8k_2_02:70]
(4) Includes true-up of expenses on the condensed consolidated statements of loss for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:71]
(5) Includes expenses on the condensed consolidated statements of loss related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks and which was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:72]
(6) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for certain employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-25-102401:8k_2_02:73]
(7) $3.2 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes professional fees related to an internal investigation and related employee exit costs, fees relating to other one-time professional fees and business expenses.

[0000950170-25-102401:8k_2_02:74]
(8) Includes $2.2 million of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations on the condensed consolidated statements of loss.

[0000950170-25-102401:8k_2_02:75]
(9) $2.0 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-102401:8k_2_02:76]
(10) The Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:77]
(11) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $6.7 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-102401:8k_2_02:78]
(12) $2.4 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-102401:8k_2_02:79]
(13) $3.5 million is included in selling, general and administrative expenses and $11.3 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses of $13.5 million of wage related and other charges due to the Greifswald facility closure in connection with the Business Efficiency Program, of which $2.6 million is included in selling, general and administrative and $10.9 million is included in research and development expenses on the condensed consolidated statements of loss. The Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:80]
(14) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $3.5 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-102401:8k_2_02:81]
(15) $3.8 million is included in selling, general and administrative expenses and $1.6 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-102401:8k_2_02:82]
(16) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $11.2 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-102401:8k_2_02:83]
(17) $4.9 million is included in selling, general and administrative expenses and $1.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-102401:8k_2_02:84]
(18) $5.3 million is included in selling, general and administrative expenses and $15.3 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses of $13.5 million of wage related and other charges due to the Greifswald facility closure in connection with the Business Efficiency Program, of which $2.6 million is included in selling, general and administrative and $10.9 million is included in research and development expenses on the condensed consolidated statements of loss. The Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:85]
(19) Includes non-cash goodwill impairment charge related to our Services and Support reporting unit. The impairment primarily resulted from a decrease in projected revenue growth rates and EBITDA margins.

[0000950170-25-102401:8k_2_02:86]
Supplemental Information

[0000950170-25-102401:8k_2_02:87]
Reconciliation of Operating Loss and Operating Margin to Non-GAAP Operating Income (Loss)

[0000950170-25-102401:8k_2_02:88]
and Non-GAAP Operating Margin

[0000950170-25-102401:8k_2_02:89]
(Unaudited)

[0000950170-25-102401:8k_2_02:90]
(In thousands)

[0000950170-25-102401:8k_2_02:91]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | March 31, |  |  | June 30, |  |  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  |  | (Restated) |  |  |
| Total Revenue |  | $ | 265,068 |  |  | $ | 247,744 |  |  | $ | 225,991 |  |  |  | $ | 512,812 |  |  | $ | 452,164 |  |  |
| Operating Loss |  | $ | (13,318 | ) |  | $ | (3,968 | ) |  | $ | (38,457 | ) |  |  | $ | (17,286 | ) |  | $ | (384,701 | ) |  |
| Acquisition related expenses, amortizations and adjustments (1) |  |  | 12,774 |  |  |  | 12,080 |  |  |  | 17,297 |  |  |  |  | 24,854 |  |  |  | 32,355 |  |  |
| Stock-based compensation expense |  |  | 2,673 |  |  |  | 3,210 |  |  |  | 3,597 |  |  |  |  | 5,883 |  |  |  | 7,314 |  |  |
| Restructuring expenses (2) |  |  | (284 | ) |  |  | — |  |  |  | 17,530 |  |  |  |  | (284 | ) |  |  | 34,640 |  |  |
| Integration expenses (3) |  |  | — |  |  |  | — |  |  |  | 566 |  |  |  |  | — |  |  |  | 1,080 |  |  |
| Deferred compensation adjustments (4) |  |  | 3,034 |  |  |  | (1,547 | ) |  |  | 848 |  |  |  |  | 1,487 |  |  |  | 2,788 |  |  |
| Goodwill impairment (5) |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 297,353 |  |  |
| Professional fees and other expenses |  |  | 3,153 |  | (6) |  | — |  |  |  | — |  |  |  |  | 3,153 |  | (6) |  | — |  |  |
| Non-GAAP Operating Income (Loss) |  | $ | 8,032 |  |  | $ | 9,775 |  |  | $ | 1,381 |  |  |  | $ | 17,807 |  |  | $ | (9,171 | ) |  |
| Operating Margin |  |  | -5.0 | % |  |  | -1.6 | % |  |  | -17.0 | % |  |  |  | -3.4 | % |  |  | -85.1 | % |  |
| Non-GAAP Operating Margin |  |  | 3.0 | % |  |  | 3.9 | % |  |  | 0.6 | % |  |  |  | 3.5 | % |  |  | -2.0 | % |  |

[0000950170-25-102401:8k_2_02:92]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-102401:8k_2_02:93]
(2) Includes expenses for the Company's  Business Efficiency Program, which was designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:94]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks, which was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:95]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for certain employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-25-102401:8k_2_02:96]
(5) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company's market capitalization, cautious service provider spending due to economic uncertainty and continued elevated customer inventory adjustments.

[0000950170-25-102401:8k_2_02:97]
(6) $3.2 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes professional fees related to an internal investigation and related employee exit costs, fees relating to other one-time professional fees and business expenses.

[0000950170-25-102401:8k_2_02:98]
Supplemental Information

[0000950170-25-102401:8k_2_02:99]
Reconciliation of Other Expense to Non-GAAP Other Expense

[0000950170-25-102401:8k_2_02:100]
(Unaudited)

[0000950170-25-102401:8k_2_02:101]
(In thousands)

[0000950170-25-102401:8k_2_02:102]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | March 31, |  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  | (Restated) |  |
| Interest and dividend income |  | $ | 201 |  |  | $ | 126 |  |  | $ | 366 |  |  | $ | 327 |  |  | $ | 763 |  |
| Interest expense |  |  | (4,564 | ) |  |  | (4,761 | ) |  |  | (6,906 | ) |  |  | (9,325 | ) |  |  | (11,504 | ) |
| Net investment gain (loss) |  |  | 3,075 |  |  |  | (1,686 | ) |  |  | 872 |  |  |  | 1,389 |  |  |  | 3,125 |  |
| Other (expense) income, net |  |  | (2,636 | ) |  |  | 944 |  |  |  | (901 | ) |  |  | (1,692 | ) |  |  | 409 |  |
| Total Other Expense |  | $ | (3,924 | ) |  | $ | (5,377 | ) |  | $ | (6,569 | ) |  | $ | (9,301 | ) |  | $ | (7,207 | ) |
| Deferred compensation adjustments (1) |  |  | (2,968 | ) |  |  | 1,649 |  |  |  | (896 | ) |  |  | (1,319 | ) |  |  | (3,335 | ) |
| Pension expense (2) |  |  | 11 |  |  |  | 11 |  |  |  | 7 |  |  |  | 22 |  |  |  | 14 |  |
| Non-GAAP Other Expense |  | $ | (6,881 | ) |  | $ | (3,717 | ) |  | $ | (7,458 | ) |  | $ | (10,598 | ) |  | $ | (10,528 | ) |

[0000950170-25-102401:8k_2_02:103]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0000950170-25-102401:8k_2_02:104]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-25-102401:8k_2_02:105]
Supplemental Information

[0000950170-25-102401:8k_2_02:106]
Reconciliation of Net Loss inclusive of Non-Controlling Interest to

[0000950170-25-102401:8k_2_02:107]
Non-GAAP Net (Loss) Income inclusive of Non-Controlling Interest

[0000950170-25-102401:8k_2_02:108]
(Unaudited)

[0000950170-25-102401:8k_2_02:109]
and

[0000950170-25-102401:8k_2_02:110]
Reconciliation of Net Loss attributable to ADTRAN Holdings, Inc. and

[0000950170-25-102401:8k_2_02:111]
Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0000950170-25-102401:8k_2_02:112]
Non-GAAP Net (Loss) Income attributable to ADTRAN Holdings, Inc. and

[0000950170-25-102401:8k_2_02:113]
Non-GAAP (Loss) Earnings per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0000950170-25-102401:8k_2_02:114]
(Unaudited)

[0000950170-25-102401:8k_2_02:115]
(In thousands, except per share amounts)

[0000950170-25-102401:8k_2_02:116]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | March 31, |  |  | June 30, |  |  |  | June 30, |  |  | June 30, |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  |  | (Restated) |  |
| Net Loss attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | (19,037 | ) |  | $ | (11,270 | ) |  | $ | (49,667 | ) |  |  | $ | (30,307 | ) |  | $ | (380,432 | ) |
| Effect of redemption of RNCI (1) |  |  | (1,494 | ) |  |  | 3 |  |  |  | — |  |  |  |  | (1,491 | ) |  |  | — |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (20,531 | ) |  | $ | (11,267 | ) |  | $ | (49,667 | ) |  |  | $ | (31,798 | ) |  | $ | (380,432 | ) |
| Net Income attributable to non-controlling interest (2) |  |  | 2,273 |  |  |  | 2,319 |  |  |  | 2,505 |  |  |  |  | 4,592 |  |  |  | 5,035 |  |
| Net Loss inclusive of non-controlling interest |  | $ | (18,258 | ) |  | $ | (8,948 | ) |  | $ | (47,162 | ) |  |  | $ | (27,206 | ) |  | $ | (375,397 | ) |
| Acquisition related expenses, amortizations and adjustments (3) |  |  | 12,774 |  |  |  | 12,080 |  |  |  | 17,297 |  |  |  |  | 24,854 |  |  |  | 32,355 |  |
| Stock-based compensation expense |  |  | 2,673 |  |  |  | 3,210 |  |  |  | 3,597 |  |  |  |  | 5,883 |  |  |  | 7,314 |  |
| Deferred compensation adjustments (4) |  |  | 66 |  |  |  | 102 |  |  |  | (48 | ) |  |  |  | 168 |  |  |  | (547 | ) |
| Pension adjustments (5) |  |  | 11 |  |  |  | 11 |  |  |  | 7 |  |  |  |  | 22 |  |  |  | 14 |  |
| Restructuring expenses (6) |  |  | (284 | ) |  |  | — |  |  |  | 17,530 |  |  |  |  | (284 | ) |  |  | 34,640 |  |
| Integration expenses (7) |  |  | — |  |  |  | — |  |  |  | 566 |  |  |  |  | — |  |  |  | 1,080 |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 297,353 |  |
| Professional fees and other expenses |  |  | 3,153 |  | (8) |  | — |  |  |  | — |  |  |  |  | 3,153 |  | (8) |  | — |  |
| Tax effect of adjustments to net loss (9) |  |  | 388 |  |  |  | (1,980 | ) |  |  | 780 |  |  |  |  | (1,592 | ) |  |  | (17,746 | ) |
| Non-GAAP Net Income (Loss) inclusive of non-controlling interest |  | $ | 523 |  |  | $ | 4,475 |  |  | $ | (7,433 | ) |  |  | $ | 4,998 |  |  | $ | (20,934 | ) |
| Net Income attributable to non-controlling interest (2) |  |  | 2,273 |  |  |  | 2,319 |  |  |  | 2,505 |  |  |  |  | 4,592 |  |  |  | 5,035 |  |
| Non-GAAP Net (Loss) Income attributable to ADTRAN Holdings, Inc. |  | $ | (1,750 | ) |  | $ | 2,156 |  |  | $ | (9,938 | ) |  |  | $ | 406 |  |  | $ | (25,969 | ) |
| Effect of redemption of RNCI (1) |  |  | 1,494 |  |  |  | (3 | ) |  |  | — |  |  |  |  | 1,491 |  |  |  | — |  |
| Non-GAAP Net (Loss) Income attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | (256 | ) |  | $ | 2,153 |  |  | $ | (9,938 | ) |  |  | $ | 1,897 |  |  | $ | (25,969 | ) |
| Weighted average shares outstanding – basic |  |  | 79,748 |  |  |  | 79,534 |  |  |  | 78,852 |  |  |  |  | 79,642 |  |  |  | 78,803 |  |
| Weighted average shares outstanding – diluted |  |  | 79,748 |  |  |  | 79,534 |  |  |  | 78,852 |  |  |  |  | 79,642 |  |  |  | 78,803 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.24 | ) |  | $ | (0.14 | ) |  | $ | (0.63 | ) |  |  | $ | (0.38 | ) |  | $ | (4.83 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.24 | ) |  | $ | (0.14 | ) |  | $ | (0.63 | ) |  |  | $ | (0.38 | ) |  | $ | (4.83 | ) |
| Non-GAAP (Loss) Earnings per common share attributable to ADTRAN – basic |  | $ | (0.00 | ) |  | $ | 0.03 |  |  | $ | (0.13 | ) |  |  | $ | 0.02 |  |  | $ | (0.33 | ) |
| Non-GAAP (Loss) Earnings per common share attributable to ADTRAN – basic |  | $ | (0.00 | ) |  | $ | 0.03 |  |  | $ | (0.13 | ) |  |  | $ | 0.02 |  |  | $ | (0.33 | ) |

[0000950170-25-102401:8k_2_02:117]
(1) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $1.5 million effect of redemption of RNCI for the three and six months ended June 30, 2025.

[0000950170-25-102401:8k_2_02:118]
(2) Represents the non-controlling interest portion of the Company's ownership of Adtran Networks pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0000950170-25-102401:8k_2_02:119]
(3) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-102401:8k_2_02:120]
(4) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-25-102401:8k_2_02:121]
(5) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-25-102401:8k_2_02:122]
(6) Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:123]
(7)  Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks. Includes fees incurred for the expansion of internal controls at Adtran Networks and the implementation of the DPTLA which was completed as of December 31, 2024.

[0000950170-25-102401:8k_2_02:124]
(8) $3.2 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes professional fees related to an internal investigation and related employee exit costs, fees relating to other one-time professional fees and business expenses.

[0000950170-25-102401:8k_2_02:125]
(9) Represents the tax effect of non-GAAP adjustments. Beginning in the period ended September 30, 2024, the Company changed its method of calculating non-GAAP income taxes by applying blended statutory tax rates to non-GAAP losses before income taxes in order to include current and deferred income tax expenses that are commensurate with the non-GAAP measure of profitability. The blended statutory tax rate is calculated using 0%, resulting in no tax benefits net of impact of valuation allowance, for the loss jurisdiction’s non-GAAP losses before income taxes and 30% for all remaining jurisdictions’ non-GAAP income before income taxes. Prior periods have been adjusted to reflect the application of blended statutory tax rates, net of impact of valuation allowance, to non-GAAP losses before income taxes as opposed to the previous application of blended statutory and effective tax rates to separate non-GAAP adjustments. We previously reported the tax effect of the adjustment to non-GAAP net loss under the prior method of $7.9 million and $13.5 million for the three months ended June 30, 2024 and six months ended June 30, 2024, respectively.

[0000950170-25-102401:8k_2_02:126]
Supplemental Information

[0000950170-25-102401:8k_2_02:127]
Reconciliation of Net Cash Provided By Operating Activities to Free Cash Flow

[0000950170-25-102401:8k_2_02:128]
(Unaudited)

[0000950170-25-102401:8k_2_02:129]
(In thousands)

[0000950170-25-102401:8k_2_02:130]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | March 31, |  |  | June 30, |  |  |  | June 30, |  |  | June 30, |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  |  | (Restated) |  |
| Net Cash provided by operating activities |  | $ | 32,160 |  |  | $ | 43,181 |  |  | $ | 19,884 |  |  |  | $ | 75,341 |  |  | $ | 57,809 |  |
| Purchases of property, plant and equipment and developed technologies (1) |  |  | (13,833 | ) |  |  | (18,695 | ) |  |  | (15,994 | ) |  |  |  | (32,528 | ) |  |  | (30,696 | ) |
| Free cash flow (Non-GAAP) |  | $ | 18,327 |  |  | $ | 24,486 |  |  | $ | 3,890 |  |  |  | $ | 42,813 |  |  | $ | 27,113 |  |

[0000950170-25-102401:8k_2_02:131]
(1) Purchases related to capital expenditures and developed technologies.
