# ADTN MD&A — 0001564590-18-027351


## mdna

[0001564590-18-027351:mdna:1]
[same as prior period, unchanged from 0001564590-18-019154:mdna:1]

[0001564590-18-027351:mdna:2]
[same as prior period, unchanged from 0001564590-18-019154:mdna:2]

[0001564590-18-027351:mdna:3]
[same as prior period, unchanged from 0001564590-18-019154:mdna:3]

[0001564590-18-027351:mdna:4]
[same as prior period, unchanged from 0001564590-18-019154:mdna:4]

[0001564590-18-027351:mdna:5]
[same as prior period, unchanged from 0001564590-18-019154:mdna:5]

[0001564590-18-027351:mdna:6]
Our business is global. We supply different sets of products to different customers in different regions around the world. Our financial results in any period reflect the activities of our various customers in their respective regions at any given time. In order to service our customers and build revenue, we are constantly conducting research and development of new products addressing customer needs and testing those products for the particular specifications of the particular customers. The lead times to revenues for these products vary.

[0001564590-18-027351:mdna:7]
As previously reported, we experienced a significant negative impact on our North American revenue as a result of a decision in mid-fourth quarter 2017 by a major customer to suspend a product rollout following a merger. While we continue to sell to that customer, the project in question has not yet resumed and we are unsure when, if ever, it will. During the periods covered in this report, our North American revenue was also impacted by slower-than-expected orders of an ultra-broadband product by a large domestic customer.

[0001564590-18-027351:mdna:8]
During the same period, however, we have seen a modest expansion of our revenues from much of the customer base and have brought to fruition our participation in a number of large customer projects which in some cases have begun to produce some revenue and in all cases we anticipate represent significant revenue opportunities in the future. These include next generation PON projects with large carriers, both domestically and internationally, the beginnings of deployment for a large project in the APAC region, a significant network upgrade by a Tier 1 European customer, as well as continued expansion and opportunities for our EPON products to two of the top North American cable MSO operators.

[0001564590-18-027351:mdna:9]
While our Services business did not increase at the rate that it did in 2016 and 2017, and has decreased from the record levels we achieved in 2017 due to the above-mentioned merger-related disruption, we continue to develop our Services business around the world, and we anticipate that it will continue to expand and remain an increasingly important part of our revenue streams across the world. Margins on services revenue vary depending upon the types of services performed.

[0001564590-18-027351:mdna:10]
[same as prior period, unchanged from 0001564590-18-019154:mdna:6]

[0001564590-18-027351:mdna:11]
[same as prior period, unchanged from 0001564590-18-019154:mdna:7]

[0001564590-18-027351:mdna:12]
[same as prior period, unchanged from 0001564590-18-019154:mdna:8]

[0001564590-18-027351:mdna:13]
[same as prior period, unchanged from 0001564590-18-019154:mdna:9]

[0001564590-18-027351:mdna:14]
[same as prior period, unchanged from 0001564590-18-019154:mdna:10]

[0001564590-18-027351:mdna:15]
Sales were $140.3 million and $389.2 million for the three and nine months ended September 30, 2018, compared to $185.1 million and $540.1 million for the three and nine months ended September 30, 2017. Our gross margin decreased to 41.6% and 38.1% in the three and nine months ended September 30, 2018, from 46.7% and 45.3% in the three and nine months ended September 30, 2017. Our operating income margin decreased to (1.6)% and (10.7)% for the three and nine months ended September 30, 2018, from 9.8% and 7.7% for the three and nine months ended September 30, 2017. Net income (loss) was $7.6 million and $(10.9) million for the three and nine months ended September 30, 2018, compared to $15.9 million and $35.0 million for the three and nine months ended September 30, 2017. Our effective tax rate, excluding the effect of the bargain purchase gain in 2018, was a benefit of 135.7% and 52.2% for the three and nine months ended September 30, 2018, compared to a provision of 17.2% and 23.1% for the three and nine months ended September 30, 2017. Earnings (loss) per share, assuming dilution, was $0.16 and $(0.23) for the three and nine months ended September 30, 2018, compared to $0.33 and $0.72 for the three and nine months ended September 30, 2017.

[0001564590-18-027351:mdna:16]
[same as prior period, unchanged from 0001564590-18-019154:mdna:12]

[0001564590-18-027351:mdna:17]
[same as prior period, unchanged from 0001564590-18-019154:mdna:13]

[0001564590-18-027351:mdna:18]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Item 1A of Part I in our most recent Annual Report on Form 10-K for the year ended December 31, 2017, filed on February 23, 2018 with the SEC and in Part II Item 1A herein.

[0001564590-18-027351:mdna:19]
[same as prior period, unchanged from 0001564590-18-019154:mdna:15]

[0001564590-18-027351:mdna:20]
[same as prior period, unchanged from 0001564590-18-019154:mdna:16]

[0001564590-18-027351:mdna:21]
[same as prior period, unchanged from 0001564590-18-019154:mdna:17]

[0001564590-18-027351:mdna:22]
[same as prior period, unchanged from 0001564590-18-019154:mdna:18]

[0001564590-18-027351:mdna:23]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2018 COMPARED TO THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2017

[0001564590-18-027351:mdna:24]
[same as prior period, unchanged from 0001564590-18-019154:mdna:20]

[0001564590-18-027351:mdna:25]
Our sales decreased 24.2% from $185.1 million in the three months ended September 30, 2017 to $140.3 million in the three months ended September 30, 2018, and decreased 27.9% from $540.1 million in the nine months ended September 30, 2017 to $389.2 million in the nine months ended September 30, 2018. The decrease in sales for the three and nine months ended September 30, 2018 is primarily attributable to a merger-related review and slowdown in spending at a domestic Tier 1 customer that particularly affected our Access & Aggregation products and services, which decreased $44.1 million and $136.4 million over the same three and nine month periods last year. The decline in sales to the previously mentioned domestic Tier 1 customer was partially offset by an increase in sales to international customers. Compared to the same three and nine month periods last year, our Customer Devices products increased $3.0 million and decreased $2.5 million, respectively, and our Traditional & Other Products decreased $3.7 million and $12.0 million, respectively.

[0001564590-18-027351:mdna:26]
Network Solutions sales decreased 16.8% from $145.5 million in the three months ended September 30, 2017 to $121.0 million in the three months ended September 30, 2018, and decreased 23.2% from $444.6 million in the nine months ended September 30, 2017 to $341.4 million in the nine months ended September 30, 2018. The decrease in sales of our Access & Aggregation products for the three and nine months ended September 30, 2018 is primarily attributable to a merger-related review and slowdown in spending at a domestic Tier 1 customer, partially offset by an increase in sales to an international Tier 1 customer as discussed further below. The changes for the three and nine months ended September 30, 2018 in sales of our Customer Devices products are primarily attributable to the changes in sales of fiber CPE products. While we expect that revenues from Traditional & Other Products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-18-027351:mdna:27]
Services & Support sales decreased 51.3% from $39.6 million in the three months ended September 30, 2017 to $19.3 million in the three months ended September 30, 2018, and decreased 49.9% from $95.5 million in the nine months ended September 30, 2017 to $47.8 million in the nine months ended September 30, 2018. The decrease in sales for the three and nine months ended September 30, 2018 is primarily attributable to a decrease in network installation services for Access & Aggregation products related to the above mentioned merger-related review and slowdown in spending at a domestic Tier 1 customer.

[0001564590-18-027351:mdna:28]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, increased 52.0% from $37.2 million in the three months ended September 30, 2017 to $56.6 million in the three months ended September 30, 2018, and increased 38.8% from $126.2 million in the nine months ended September 30, 2017 to $175.2 million in the nine months ended September 30, 2018. International sales, as a percentage of total sales, increased from 20.1% for the three months ended September 30, 2017 to 40.3% for the three months ended September 30, 2018, and increased from 23.4% for the nine months ended September 30, 2017 to 45.0% in the nine months ended September 30, 2018. The increase in sales for the three and nine months ended September 30, 2018 is primarily attributable to an increase in sales in EMEA and APAC. The increase in sales in EMEA for the three and nine months ended September 30, 2018 is primarily attributable to a network expansion program and a Services award by a large European Tier-1 customer. The increase in sales in APAC for the three and nine months ended September 30, 2018 is primarily attributable to a network expansion program in Australia.

[0001564590-18-027351:mdna:29]
[same as prior period, unchanged from 0001564590-18-019154:mdna:25]

[0001564590-18-027351:mdna:30]
We recognized a positive revenue impact in the first half of 2017 due to our being awarded a network expansion program by a large European Tier-1 customer. During 2018, this European Tier 1 customer undertook an additional network expansion project. We anticipate that as our Latin American customers resume their network upgrade projects, we may experience further enhancement to our revenues. As announced, we received of a new nationwide award in the APAC region, as well as additional awards based on new ADTRAN technologies in the EMEA region that have, and we believe will continue to have, a positive impact to our revenues. However, a resolution of the regulatory changes affecting a major customer in Mexico has been slower than anticipated, and business with one of our customers in that region has not yet returned to normal levels. We are continuing to pursue opportunities with new customers in this region.

[0001564590-18-027351:mdna:31]
[same as prior period, unchanged from 0001564590-18-019154:mdna:27]

[0001564590-18-027351:mdna:32]
As a percentage of sales, cost of sales increased from 53.3% in the three months ended September 30, 2017 to 58.4% in the three months ended September 30, 2018, and increased from 54.7% in the nine months ended September 30, 2017 to 61.9% in the nine months ended September 30, 2018. The increase in cost of sales as a percentage of sales for the three months ended September 30, 2018 is primarily attributable to a regional revenue shift, customer and product mix, and services and support mix. The increase in cost of sales as a percentage of sales for the nine months ended September 30, 2018 is primarily attributable to a regional revenue shift, customer and product mix, and services and support mix, restructuring expenses and an increase in warranty replacements.

[0001564590-18-027351:mdna:33]
Network Solutions cost of sales, as a percent of that segment’s sales, increased from 50.6% in the three months ended September 30, 2017 to 57.8% in the three months ended September 30, 2018, and increased from 51.7% in the nine months ended September 30, 2017 to 61.0% in the nine months ended September 30, 2018. The increase in cost of sales as a percentage of sales for the three months ended September 30, 2018 is primarily attributable to a regional revenue shift and customer and product mix. The increase in cost of sales as a percentage of sales for the nine months ended September 30, 2018 is primarily attributable to a regional revenue shift, customer and product mix, an increase in warranty expense due to a settlement in first quarter of 2017 with a third party supplier for a defective component and purchase discounts received from a contract manufacturer in the first quarter of 2017 and restructuring expenses.

[0001564590-18-027351:mdna:34]
[same as prior period, unchanged from 0001564590-18-019154:mdna:30]

[0001564590-18-027351:mdna:35]
Services & Support cost of sales, as a percent of that segment’s sales, decreased from 63.3% in the three months ended September 30, 2017 to 61.9% in the three months ended September 30, 2018, and increased from 68.5% in the nine months ended September 30, 2017 to 68.6% in the nine months ended September 30, 2018. The decrease in cost of sales as a percentage of sales for the three months ended September 30, 2018 is primarily attributable to customer mix, services and support mix and cost reductions. The increase in cost of sales as a percentage of sales for the nine months ended September 30, 2018 is primarily attributable to services and support mix and an increase in labor expense due to a restructuring program.

[0001564590-18-027351:mdna:36]
[same as prior period, unchanged from 0001564590-18-019154:mdna:32]

[0001564590-18-027351:mdna:37]
[same as prior period, unchanged from 0001564590-18-019154:mdna:33]

[0001564590-18-027351:mdna:38]
[same as prior period, unchanged from 0001564590-18-019154:mdna:34]

[0001564590-18-027351:mdna:39]
Selling, general and administrative expenses decreased 11.3% from $34.7 million in the three months ended September 30, 2017 to $30.8 million in the three months ended September 30, 2018, and decreased 7.5% from $104.2 million in the nine months ended September 30, 2017 to $96.4 million in the nine months ended September 30, 2018. The decrease in selling, general and administrative expenses for the three months ended September 30, 2018 is primarily attributable to decreases in compensation and labor expense, travel expense and independent contractor expense, partially offset by an increase in restructuring expense. The decrease in selling, general and administrative expenses for the nine months ended September 30, 2018 is primarily attributable to a decrease in compensation and labor expense, independent contractor expense, and travel expense, partially offset by an increase in restructuring expense.

[0001564590-18-027351:mdna:40]
As a percentage of sales, selling, general and administrative expenses increased from 18.7% in the three months ended September 30, 2017 to 21.9% in the three months ended September 30, 2018, and increased from 19.3% in the nine months ended September 30, 2017 to 24.8% in the nine months ended September 30, 2018. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-18-027351:mdna:41]
[same as prior period, unchanged from 0001564590-18-019154:mdna:37]

[0001564590-18-027351:mdna:42]
Research and development expenses decreased 11.0% from $33.6 million in the three months ended September 30, 2017 to $29.9 million in the three months ended September 30, 2018, and decreased 5.7% from $99.1 million in the nine months ended September 30, 2017 to $93.5 million in the nine months ended September 30, 2018. The decrease in research and development expenses for the three months ended September 30, 2018 is primarily attributable to decreases in labor, engineering materials and independent contractor expense. The decrease in research and development expenses for the nine months ended September 30, 2018 is primarily attributable to decreases in engineering materials and independent contractor expense and amortization of intangibles acquired in the third quarter of 2016 that were fully amortized in 2017, partially offset by an increase in restructuring expense.

[0001564590-18-027351:mdna:43]
As a percentage of sales, research and development expenses increased from 18.1% in the three months ended September 30, 2017 to 21.3% in the three months ended September 30, 2018, and increased from 18.4% in the nine months ended September 30, 2017 to 24.0% in the nine months ended September 30, 2018. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenues for the periods being compared.

[0001564590-18-027351:mdna:44]
[same as prior period, unchanged from 0001564590-18-019154:mdna:40]

[0001564590-18-027351:mdna:45]
[same as prior period, unchanged from 0001564590-18-019154:mdna:41]

[0001564590-18-027351:mdna:46]
Interest and dividend income decreased 13.3% from $1.0 million in the three months ended September 30, 2017 to $0.8 million in the three months ended September 30, 2018, and decreased 8.9% from $2.9 million in the nine months ended September 30, 2017 to $2.6 million in the nine months ended September 30, 2018. The decrease in interest and dividend income for the three and nine months ended September 30, 2018 is primarily attributable to fluctuations in investment balances and a decrease in the rate of return on those investments due to interest rate movements.

[0001564590-18-027351:mdna:47]
[same as prior period, unchanged from 0001564590-18-019154:mdna:43]

[0001564590-18-027351:mdna:48]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended September 30, 2017 and 2018, and $0.4 million in the nine months ended September 30, 2017 and 2018, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-18-027351:mdna:49]
NET INVESTMENT GAIN

[0001564590-18-027351:mdna:50]
Net investment gains increased 346.7% from $1.0 million in the three months ended September 30, 2017 to $4.5 million in the three months ended September 30, 2018, and increased 88.2% from $2.9 million in the nine months ended September 30, 2017 to $5.4 million in the nine months ended September 30, 2018. The increase in net investment gains for the three and nine months ended September 30, 2018 is primarily attributable to changes in fair value on equity securities recognized during the period under ASC 2016-01. Prior to January 1, 2018, changes in fair value were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet. See Note 1, Note 7 and “Investing Activities” in “Liquidity and Capital Resources” for additional information.

[0001564590-18-027351:mdna:51]
OTHER INCOME (EXPENSE), NET

[0001564590-18-027351:mdna:52]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, gains and losses on foreign exchange forward contracts, investment account management fees, and scrap raw material sales.  Other income, net increased 123.9% from $0.8 million of expense in the three months ended September 30, 2017 to $0.2 million of income in the three months ended September 30, 2018. Other income (expense), net decreased 94.9% from $1.4 million of expense in the nine months ended September 30, 2017 to $0.1 million of expense in the nine months ended September 30, 2018. The change in other income (expense), net for the three and nine months ended September 30, 2018 is primarily attributable to higher losses on foreign exchange contracts and transactions in 2017.

[0001564590-18-027351:mdna:53]
[same as prior period, unchanged from 0001564590-18-019154:mdna:49]

[0001564590-18-027351:mdna:54]
[same as prior period, unchanged from 0001564590-18-019154:mdna:50]

[0001564590-18-027351:mdna:55]
[same as prior period, unchanged from 0001564590-18-019154:mdna:51]

[0001564590-18-027351:mdna:56]
Our effective tax rate decreased from an expense of 23.1% in the nine months ended September 30, 2017 to a benefit of 34.9%, excluding the tax effect of the bargain purchase gain, in the nine months ended September 30, 2018. The decrease in the effective tax rate between the two periods is primarily driven by the completion of other tax projects, current year net losses in our domestic business and the effect of the U.S. Tax Cuts and Jobs Act, which was signed into law on December 22, 2017.

[0001564590-18-027351:mdna:57]
[same as prior period, unchanged from 0001564590-18-019154:mdna:53]

[0001564590-18-027351:mdna:58]
As a result of the above factors, net income (loss) decreased $8.3 million from $15.9 million in the three months ended September 30, 2017 to $7.6 million in the three months ended September 30, 2018, and decreased $45.8 million from $35.0 million in the nine months ended September 30, 2017 to $(10.9) million in the nine months ended September 30, 2018.

[0001564590-18-027351:mdna:59]
[same as prior period, unchanged from 0001564590-18-019154:mdna:55]

[0001564590-18-027351:mdna:60]
[same as prior period, unchanged from 0001564590-18-019154:mdna:56]

[0001564590-18-027351:mdna:61]
[same as prior period, unchanged from 0001564590-18-019154:mdna:57]

[0001564590-18-027351:mdna:62]
At September 30, 2018, cash on hand was $94.2 million and short-term investments were $5.9 million, which resulted in available short-term liquidity of $100.1 million, of which $70.1 million was held by our foreign subsidiaries. At December 31, 2017, cash on hand was $86.4 million and short-term investments were $16.1 million, which resulted in available short-term liquidity of $102.6 million, of which $56.8 million was held by our foreign subsidiaries. We intend to permanently reinvest the funds held by our foreign subsidiaries outside the U.S. and our current business plans do not indicate a need to repatriate these funds to finance domestic operations. The decrease in short-term liquidity from December 31, 2017 to September 30, 2018 is primarily attributable to shifts among available investment option tenures to provide funds for our short-term cash needs.

[0001564590-18-027351:mdna:63]
[same as prior period, unchanged from 0001564590-18-019154:mdna:59]

[0001564590-18-027351:mdna:64]
Our working capital, which consists of current assets less current liabilities, decreased 26.5% from $306.3 million as of December 31, 2017 to $225.0 million as of September 30, 2018, and our current ratio, defined as current assets divided by current liabilities, decreased from 3.87 as of December 31, 2017 to 2.82 as of September 30, 2018. The decreases in our working capital and current ratio are primarily attributable to decreases in accounts receivable and inventory, and an increase in income tax payable. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.31 as of December 31, 2017 to 1.63 as of September 30, 2018. The decrease in the quick ratio is primarily attributable to a decrease in accounts receivable and an increase in income tax payable.

[0001564590-18-027351:mdna:65]
Accounts receivable decreased 29.3% from $144.2 million at December 31, 2017 to $101.9 million at September 30, 2018. We had no allowance for doubtful accounts at December 31, 2017 or September 30, 2018. Quarterly accounts receivable days sales outstanding (DSO) decreased from 105 days as of December 31, 2017 to 67 days as of September 30, 2018. The decrease in net accounts receivable is due to the collection of customer-specific payment terms that became due in the first quarter of 2018 and the timing of sales and collections during the quarter. Additionally, certain international customers may have longer payment terms than U.S. customers.

[0001564590-18-027351:mdna:66]
Quarterly inventory turnover increased from 2.28 turns as of December 31, 2017 to 2.89 turns at September 30, 2018. Inventory decreased 13.5% from $122.5 million at December 31, 2017 to $106.1 million at September 30, 2018. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-18-027351:mdna:67]
Prepaid expense and other current assets decreased 39.7% from $17.3 million at December 31, 2017 to $10.4 million at September 30, 2018. The decrease in prepaid expenses and other current assets is primarily attributable to the recognition of deferred costs related to network installation services that were completed during the first quarter.

[0001564590-18-027351:mdna:68]
Income tax payable increased 264.3% from $3.9 million at December 31, 2017 to $14.3 million at September 30, 2018. The increase in income tax payable is primarily attributable to income taxes accrued for foreign jurisdictions.

[0001564590-18-027351:mdna:69]
[same as prior period, unchanged from 0001564590-18-019154:mdna:65]

[0001564590-18-027351:mdna:70]
Capital expenditures totaled approximately $5.7 million and $12.3 million for the nine months ended September 30, 2018 and 2017, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-18-027351:mdna:71]
Our combined short-term and long-term investments increased $3.8 million from $146.4 million at December 31, 2017 to $150.2 million at September 30, 2018. This increase reflects funds available for investment provided by our operating activities, as well as net realized and unrealized gains and losses and amortization of net premiums on our combined investments, partially offset by our cash needs for capital expenditures, purchases of treasury stock, and shareholder dividends.

[0001564590-18-027351:mdna:72]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At September 30, 2018 these investments included corporate bonds of $25.6 million, municipal fixed-rate bonds of $1.4 million, asset-backed bonds of $8.4 million, mortgage/agency-backed bonds of $5.4 million, U.S. government bonds of $19.8 million, and foreign government bonds of $0.6 million. At December 31, 2017, these investments included corporate bonds of $32.5 million, municipal fixed-rate bonds of $2.9 million, asset-backed bonds of $6.5 million, mortgage/agency-backed bonds of $5.5 million, U.S. government bonds of $14.3 million, and foreign government bonds of $0.7 million. As of September 30, 2018, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds were classified as available-for-sale and had a combined duration of 1.7 years with an average Standard & Poor’s credit rating of AA-. Because our bond portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-18-027351:mdna:73]
Our long-term investments increased 10.7% from $130.3 million at December 31, 2017 to $144.2 million at September 30, 2018. Long-term investments at September 30, 2018 and December 31, 2017 included an investment in a certificate of deposit of $26.7 million and $27.8 million, respectively, which serves as collateral for our revenue bond. See “Debt” below for additional information. We have various equity investments included in long-term investments with a fair value of $40.9 million and $35.7 million, at September 30, 2018 and December 31, 2017, respectively.

[0001564590-18-027351:mdna:74]
Long-term investments at September 30, 2018 and December 31, 2017 also included $20.9 million and $19.9 million, respectively, related to our deferred compensation plans, and $0.5 million of other investments carried at cost, consisting of interests in two private equity funds.

[0001564590-18-027351:mdna:75]
[same as prior period, unchanged from 0001564590-18-019154:mdna:71]

[0001564590-18-027351:mdna:76]
[same as prior period, unchanged from 0001564590-18-019154:mdna:72]

[0001564590-18-027351:mdna:77]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the nine months ended September 30, 2018, we paid dividends totaling $13.0 million.

[0001564590-18-027351:mdna:78]
[same as prior period, unchanged from 0001564590-18-019154:mdna:74]

[0001564590-18-027351:mdna:79]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $26.7 million at September 30, 2018 and December 31, 2017. At September 30, 2018, the estimated fair value of the Bond was approximately $26.5 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $26.7 million and $27.8 million at September 30, 2018 and December 31, 2017, respectively, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.1 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at September 30, 2018.

[0001564590-18-027351:mdna:80]
[same as prior period, unchanged from 0001564590-18-019154:mdna:76]

[0001564590-18-027351:mdna:81]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock that are implemented through open market or private purchases from time to time as conditions warrant. During the nine months ended September 30, 2018, we repurchased 0.9 million shares of our common stock at an average price of $15.75 per share. As of September 30, 2018, we have the authority to purchase an additional 2.7 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-18-027351:mdna:82]
[same as prior period, unchanged from 0001564590-18-019154:mdna:78]

[0001564590-18-027351:mdna:83]
We issued 0.1 million shares of treasury stock during the nine months ended September 30, 2018 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $1.3 million from the exercise of these stock options during the nine months ended September 30, 2018.

[0001564590-18-027351:mdna:84]
[same as prior period, unchanged from 0001564590-18-019154:mdna:80]

[0001564590-18-027351:mdna:85]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the nine months ended September 30, 2018, there have been no material changes in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2017 filed on February 23, 2018 with the SEC.

[0001564590-18-027351:mdna:86]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2018, of which $7.7 million has been applied to these commitments.
