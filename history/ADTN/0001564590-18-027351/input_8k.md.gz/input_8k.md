# ADTN 8-K — 0001564590-18-024365 filed 2018-10-17

## item codes, every 8-K on or before 2018-11-06

- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2018-11-06

- none on or before 2018-11-06

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-024365:8k_2_02:1]
EX-99.1
2
adtn-ex991_6.htm
EX-99.1

[0001564590-18-024365:8k_2_02:2]
adtn-ex991_6.htm

[0001564590-18-024365:8k_2_02:3]
EXHIBIT 99.1

[0001564590-18-024365:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the Third Quarter 2018 and Declares Quarterly Cash Dividend

[0001564590-18-024365:8k_2_02:5]
HUNTSVILLE, Ala.--(BUSINESS WIRE)—October 16, 2018-- ADTRAN, Inc. (NASDAQ:ADTN) reported results for the third quarter 2018. For the quarter, sales were $140.3 million compared to $185.1 million for the third quarter of 2017. Net income was $7.6 million compared to $15.9 million for the third quarter of 2017. Earnings per share, assuming dilution, were $0.16 compared to $0.33 for the third quarter of 2017. Non-GAAP earnings per share were $0.21 compared to $0.37 for the third quarter of 2017. GAAP earnings per share include the expense of stock-based compensation, acquisition related amortizations and other expenses, and restructuring expenses. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001564590-18-024365:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “Total revenue for the quarter grew 10% sequentially, including the effect of a late start to our G.fast shipments to the Asia-Pacific region.  Notwithstanding the G.fast shipment impact, our third quarter results showed strong improvements in gross margins and operating expenses.  On a regional basis, sales contributions followed typical seasonal patterns with growth in the Americas, expected seasonal declines in Europe and growth in Asia-Pacific, driven by new customer activity.  Looking forward, we are very encouraged by the continued momentum in ultra-broadband shipments to both carriers and MSOs globally as service providers continue to evolve their networks to meet changing customer expectations.”

[0001564590-18-024365:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the third quarter of 2018. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on October 31, 2018. The ex-dividend date is October 30, 2018, and the payment date is November 14, 2018.

[0001564590-18-024365:8k_2_02:8]
The Company confirmed that it will hold its third quarter conference call Wednesday, October 17, 2018, at 9:30 a.m. Central Time. ADTRAN will webcast this conference. To listen, simply visit the Investor Relations site at www.investors.adtran.com approximately 10 minutes prior to the start of the call and click on the conference call link provided.

[0001564590-18-024365:8k_2_02:9]
An online replay of the conference call, as well as the text of the Company's earnings release, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or via email at investor.relations@adtran.com.

[0001564590-18-024365:8k_2_02:10]
ADTRAN, Inc. is the leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. Please visit us at www.adtran.com, LinkedIn, Facebook and Twitter.

[0001564590-18-024365:8k_2_02:11]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2017. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-18-024365:8k_2_02:12]
Condensed Consolidated Balance Sheet

[0001564590-18-024365:8k_2_02:13]
(Unaudited)

[0001564590-18-024365:8k_2_02:14]
(In thousands)

[0001564590-18-024365:8k_2_02:15]
|  | September 30, |  |  | December 31, |  |
|  | 2018 |  |  | 2017 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 94,173 |  |  | $ | 86,433 |  |
| Short-term investments |  | 5,912 |  |  |  | 16,129 |  |
| Accounts receivable, net |  | 101,865 |  |  |  | 144,150 |  |
| Other receivables |  | 30,084 |  |  |  | 26,578 |  |
| Inventory, net |  | 106,060 |  |  |  | 122,542 |  |
| Prepaid expenses and other current assets |  | 10,428 |  |  |  | 17,282 |  |
| Total Current Assets |  | 348,522 |  |  |  | 413,114 |  |
| Property, plant and equipment, net |  | 81,457 |  |  |  | 85,079 |  |
| Deferred tax assets, net |  | 39,595 |  |  |  | 23,428 |  |
| Goodwill |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  | 31,523 |  |  |  | 13,725 |  |
| Long-term investments |  | 144,241 |  |  |  | 130,256 |  |
| Total Assets | $ | 648,830 |  |  | $ | 669,094 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 65,032 |  |  | $ | 60,632 |  |
| Unearned revenue |  | 17,004 |  |  |  | 13,070 |  |
| Accrued expenses |  | 14,548 |  |  |  | 13,232 |  |
| Accrued wages and benefits |  | 12,604 |  |  |  | 15,948 |  |
| Income tax payable |  | 14,340 |  |  |  | 3,936 |  |
| Total Current Liabilities |  | 123,528 |  |  |  | 106,818 |  |
| Non-current unearned revenue |  | 3,846 |  |  |  | 4,556 |  |
| Other non-current liabilities |  | 32,255 |  |  |  | 34,209 |  |
| Bonds payable |  | 25,600 |  |  |  | 25,600 |  |
| Total Liabilities |  | 185,229 |  |  |  | 171,183 |  |
| Stockholders' Equity |  | 463,601 |  |  |  | 497,911 |  |
| Total Liabilities and Stockholders' Equity | $ | 648,830 |  |  | $ | 669,094 |  |

[0001564590-18-024365:8k_2_02:16]
Consolidated Statements of Income

[0001564590-18-024365:8k_2_02:17]
(Unaudited)

[0001564590-18-024365:8k_2_02:18]
(In thousands, except per share data)

[0001564590-18-024365:8k_2_02:19]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 121,043 |  |  | $ | 145,467 |  |  | $ | 341,359 |  |  | $ | 444,607 |  |
| Services |  |  | 19,292 |  |  |  | 39,645 |  |  |  | 47,830 |  |  |  | 95,457 |  |
| Total Sales |  |  | 140,335 |  |  |  | 185,112 |  |  |  | 389,189 |  |  |  | 540,064 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 69,943 |  |  |  | 73,534 |  |  |  | 208,184 |  |  |  | 229,861 |  |
| Services |  |  | 11,944 |  |  |  | 25,087 |  |  |  | 32,828 |  |  |  | 65,377 |  |
| Total Cost of Sales |  |  | 81,887 |  |  |  | 98,621 |  |  |  | 241,012 |  |  |  | 295,238 |  |
| Gross Profit |  |  | 58,448 |  |  |  | 86,491 |  |  |  | 148,177 |  |  |  | 244,826 |  |
| Selling, general and administrative expenses |  |  | 30,750 |  |  |  | 34,676 |  |  |  | 96,361 |  |  |  | 104,171 |  |
| Research and development expenses |  |  | 29,877 |  |  |  | 33,588 |  |  |  | 93,455 |  |  |  | 99,116 |  |
| Operating Income (Loss) |  |  | (2,179 | ) |  |  | 18,227 |  |  |  | (41,639 | ) |  |  | 41,539 |  |
| Interest and dividend income |  |  | 825 |  |  |  | 952 |  |  |  | 2,604 |  |  |  | 2,857 |  |
| Interest expense |  |  | (134 | ) |  |  | (139 | ) |  |  | (398 | ) |  |  | (417 | ) |
| Net realized investment gain |  |  | 4,507 |  |  |  | 1,009 |  |  |  | 5,400 |  |  |  | 2,869 |  |
| Other income (expense), net |  |  | 201 |  |  |  | (842 | ) |  |  | (73 | ) |  |  | (1,427 | ) |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  | 11,322 |  |  |  | — |  |
| Income (Loss) Before Provision for Income Taxes |  |  | 3,220 |  |  |  | 19,207 |  |  |  | (22,784 | ) |  |  | 45,421 |  |
| (Provision) benefit for income taxes |  |  | 4,369 |  |  |  | (3,309 | ) |  |  | 11,889 |  |  |  | (10,471 | ) |
| Net Income (Loss) |  | $ | 7,589 |  |  | $ | 15,898 |  |  | $ | (10,895 | ) |  | $ | 34,950 |  |
| Weighted average shares outstanding – basic |  |  | 47,710 |  |  |  | 47,870 |  |  |  | 47,927 |  |  |  | 48,110 |  |
| Weighted average shares outstanding – diluted(1) |  |  | 47,834 |  |  |  | 48,531 |  |  |  | 47,994 |  |  |  | 48,618 |  |
| Earnings (loss) per common share – basic |  | $ | 0.16 |  |  | $ | 0.33 |  |  | $ | (0.23 | ) |  | $ | 0.73 |  |
| Earnings (loss) per common share – diluted(1) |  | $ | 0.16 |  |  | $ | 0.33 |  |  | $ | (0.23 | ) |  | $ | 0.72 |  |

[0001564590-18-024365:8k_2_02:20]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-18-024365:8k_2_02:21]
Consolidated Statements of Comprehensive Income

[0001564590-18-024365:8k_2_02:22]
(Unaudited)

[0001564590-18-024365:8k_2_02:23]
(In thousands)

[0001564590-18-024365:8k_2_02:24]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net Income (Loss) |  | $ | 7,589 |  |  | $ | 15,898 |  |  | $ | (10,895 | ) |  | $ | 34,950 |  |
| Other Comprehensive Income (Loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net unrealized gains (losses) on available-for-sale securities |  |  | (32 | ) |  |  | 804 |  |  |  | (3,340 | ) |  |  | 2,512 |  |
| Net unrealized gains (losses) on cash flow hedges |  |  | — |  |  |  | 142 |  |  |  | — |  |  |  | (196 | ) |
| Defined benefit plan adjustments |  |  | 37 |  |  |  | 73 |  |  |  | 104 |  |  |  | 214 |  |
| Foreign currency translation |  |  | (451 | ) |  |  | 1,541 |  |  |  | (3,033 | ) |  |  | 5,402 |  |
| Other Comprehensive Income (Loss), net of tax |  |  | (446 | ) |  |  | 2,560 |  |  |  | (6,269 | ) |  |  | 7,932 |  |
| Comprehensive Income (Loss), net of tax |  | $ | 7,143 |  |  | $ | 18,458 |  |  | $ | (17,164 | ) |  | $ | 42,882 |  |

[0001564590-18-024365:8k_2_02:25]
Consolidated Statements of Cash Flows

[0001564590-18-024365:8k_2_02:26]
(Unaudited)

[0001564590-18-024365:8k_2_02:27]
(In thousands)

[0001564590-18-024365:8k_2_02:28]
|  |  | Nine Months Ended |  |
|  |  | September 30, |  |
|  |  | 2018 |  |  | 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (10,895 | ) |  | $ | 34,950 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 11,952 |  |  |  | 12,034 |  |
| Amortization of net premium on available-for-sale investments |  |  | (14 | ) |  |  | 352 |  |
| Net realized gain on long-term investments |  |  | (5,400 | ) |  |  | (2,869 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | 68 |  |  |  | (10 | ) |
| Gain on bargain purchase of a business |  |  | (11,322 | ) |  |  | — |  |
| Stock-based compensation expense |  |  | 5,243 |  |  |  | 5,573 |  |
| Deferred income taxes |  |  | (20,368 | ) |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 41,166 |  |  |  | (6,975 | ) |
| Other receivables |  |  | (1,842 | ) |  |  | (2,924 | ) |
| Inventory |  |  | 16,543 |  |  |  | (9,483 | ) |
| Prepaid expenses and other assets |  |  | 8,722 |  |  |  | (9,647 | ) |
| Accounts payable |  |  | 5,223 |  |  |  | (4,727 | ) |
| Accrued expenses and other liabilities |  |  | 156 |  |  |  | (2,820 | ) |
| Income tax payable |  |  | 9,461 |  |  |  | 8,571 |  |
| Net cash provided by operating activities |  |  | 48,693 |  |  |  | 22,025 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (5,695 | ) |  |  | (12,304 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 16 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 116,757 |  |  |  | 137,272 |  |
| Purchases of available-for-sale investments |  |  | (115,271 | ) |  |  | (79,713 | ) |
| Acquisition of business |  |  | (7,806 | ) |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | (12,015 | ) |  |  | 45,271 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 1,321 |  |  |  | 6,606 |  |
| Purchases of treasury stock |  |  | (14,185 | ) |  |  | (17,348 | ) |
| Dividend payments |  |  | (12,976 | ) |  |  | (13,031 | ) |
| Net cash used in financing activities |  |  | (25,840 | ) |  |  | (23,773 | ) |
| Net increase in cash and cash equivalents |  |  | 10,838 |  |  |  | 43,523 |  |
| Effect of exchange rate changes |  |  | (3,098 | ) |  |  | 4,835 |  |
| Cash and cash equivalents, beginning of period |  |  | 86,433 |  |  |  | 79,895 |  |
| Cash and cash equivalents, end of period |  | $ | 94,173 |  |  | $ | 128,253 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 355 |  |  | $ | 272 |  |

[0001564590-18-024365:8k_2_02:29]
Supplemental Information

[0001564590-18-024365:8k_2_02:30]
Restructuring Expenses

[0001564590-18-024365:8k_2_02:31]
(Unaudited)

[0001564590-18-024365:8k_2_02:32]
(In thousands)

[0001564590-18-024365:8k_2_02:33]
Restructuring expense was recorded in the following Consolidated Statements of Income categories for three and nine months ended September 30, 2018 and 2017:

[0001564590-18-024365:8k_2_02:34]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Restructuring expense included in cost of sales |  | $ | — |  |  | $ | — |  |  | $ | 2,761 |  |  | $ | — |  |
| Selling, general and administrative expense |  |  | 261 |  |  |  | 93 |  |  |  | 2,661 |  |  |  | 93 |  |
| Research and development expense |  |  | — |  |  |  | 122 |  |  |  | 1,814 |  |  |  | 122 |  |
| Restructuring expense included in operating expenses |  |  | 261 |  |  |  | 215 |  |  |  | 4,475 |  |  |  | 215 |  |
| Total restructuring expense |  |  | 261 |  |  |  | 215 |  |  |  | 7,236 |  |  |  | 215 |  |
| Provision for income taxes |  |  | (68 | ) |  |  | (84 | ) |  |  | (1,882 | ) |  |  | (84 | ) |
| Total restructuring expense, net of tax |  | $ | 193 |  |  | $ | 131 |  |  | $ | 5,354 |  |  | $ | 131 |  |

[0001564590-18-024365:8k_2_02:35]
Supplemental Information

[0001564590-18-024365:8k_2_02:36]
Acquisition Related Expenses, Amortizations and Adjustments

[0001564590-18-024365:8k_2_02:37]
(Unaudited)

[0001564590-18-024365:8k_2_02:38]
(In thousands)

[0001564590-18-024365:8k_2_02:39]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc., on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA), on September 13, 2016, we closed on the acquisition of CommScope’s active fiber business (CommScope), and on March 19, 2018, we closed on the acquisition of Sumitomo Electric Lightwave Corp.’s North American EPON business (Sumitomo). Acquisition related expenses, amortizations and adjustments for the three and nine months ended September 30, 2018 and 2017 for all four transactions are as follows:

[0001564590-18-024365:8k_2_02:40]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 53 |  |  | $ | 158 |  |  | $ | 369 |  |  | $ | 474 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 88 |  |  |  | 95 |  |  |  | 270 |  |  |  | 432 |  |
| Amortization of other purchase accounting adjustments |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 39 |  |
| Subtotal - NSN BBA acquisition |  |  | 88 |  |  |  | 96 |  |  |  | 271 |  |  |  | 471 |  |
| CommScope acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 123 |  |  |  | 219 |  |  |  | 373 |  |  |  | 1,513 |  |
| Amortization of other purchase accounting adjustments |  |  | — |  |  |  | 4 |  |  |  | 1 |  |  |  | 85 |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8 |  |
| Subtotal - CommScope acquisition |  |  | 123 |  |  |  | 223 |  |  |  | 374 |  |  |  | 1,606 |  |
| Sumitomo acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 662 |  |  |  | — |  |  |  | 1,434 |  |  |  | — |  |
| Amotization of other purchase accounting adjustments |  |  | — |  |  |  | — |  |  |  | 79 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | — |  |  |  | 124 |  |  |  | — |  |
| Subtotal - Sumitomo acquisition |  |  | 662 |  |  |  | — |  |  |  | 1,637 |  |  |  | — |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 926 |  |  |  | 477 |  |  |  | 2,651 |  |  |  | 2,551 |  |
| Provision for income taxes |  |  | (245 | ) |  |  | (178 | ) |  |  | (702 | ) |  |  | (957 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 681 |  |  | $ | 299 |  |  | $ | 1,949 |  |  | $ | 1,594 |  |

[0001564590-18-024365:8k_2_02:41]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and nine months ended September 30, 2018 and 2017:

[0001564590-18-024365:8k_2_02:42]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Cost of goods sold |  | $ | 350 |  |  | $ | 5 |  |  | $ | 839 |  |  | $ | 86 |  |
| Selling, general and administrative expenses |  |  | 289 |  |  |  | 50 |  |  |  | 874 |  |  |  | 164 |  |
| Research and development expenses |  |  | 287 |  |  |  | 422 |  |  |  | 938 |  |  |  | 2,301 |  |
| Total acquisition related expenses, amortizations and adjustments included in operating expenses |  |  | 576 |  |  |  | 472 |  |  |  | 1,812 |  |  |  | 2,465 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 926 |  |  |  | 477 |  |  |  | 2,651 |  |  |  | 2,551 |  |
| Provision for income taxes |  |  | (245 | ) |  |  | (178 | ) |  |  | (702 | ) |  |  | (957 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 681 |  |  | $ | 299 |  |  | $ | 1,949 |  |  | $ | 1,594 |  |

[0001564590-18-024365:8k_2_02:43]
Supplemental Information

[0001564590-18-024365:8k_2_02:44]
Stock-based Compensation Expense

[0001564590-18-024365:8k_2_02:45]
(Unaudited)

[0001564590-18-024365:8k_2_02:46]
(In thousands)

[0001564590-18-024365:8k_2_02:47]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 101 |  |  | $ | 97 |  |  | $ | 298 |  |  | $ | 281 |  |
| Selling, general and administrative expense |  |  | 894 |  |  |  | 994 |  |  |  | 2,924 |  |  |  | 3,018 |  |
| Research and development expense |  |  | 645 |  |  |  | 743 |  |  |  | 2,021 |  |  |  | 2,274 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,539 |  |  |  | 1,737 |  |  |  | 4,945 |  |  |  | 5,292 |  |
| Total stock-based compensation expense |  |  | 1,640 |  |  |  | 1,834 |  |  |  | 5,243 |  |  |  | 5,573 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (292) |  |  |  | (402 | ) |  |  | (1,016) |  |  |  | (1,215 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,348 |  |  | $ | 1,432 |  |  | $ | 4,227 |  |  | $ | 4,358 |  |

[0001564590-18-024365:8k_2_02:48]
Reconciliation of GAAP net income per share, diluted, to

[0001564590-18-024365:8k_2_02:49]
Non-GAAP net income per share, diluted

[0001564590-18-024365:8k_2_02:50]
(Unaudited)

[0001564590-18-024365:8k_2_02:51]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2018 |  |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| GAAP earnings (loss) per common share - diluted |  | $ | 0.16 |  |  |  | 0.33 |  |  | $ | (0.23 | ) |  | $ | 0.72 |  |
| Restructuring expense |  |  | — |  |  |  | — |  |  |  | 0.11 |  |  |  | — |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.04 |  |  |  | 0.03 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.09 |  |  |  | 0.09 |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  | (0.24 | ) |  |  | — |  |
| Non-GAAP earnings (loss) per common share - diluted(1) |  | $ | 0.21 |  |  |  | 0.37 |  |  | $ | (0.22 | ) |  | $ | 0.84 |  |

[0001564590-18-024365:8k_2_02:52]
(1) Table may not foot due to rounding
