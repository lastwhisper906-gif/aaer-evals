# ADTN notes — 0001564590-18-027351


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-18-027351:notes:1]
[same as prior period, unchanged from 0001564590-18-019154:notes:1]

[0001564590-18-027351:notes:2]
[same as prior period, unchanged from 0001564590-18-019154:notes:2]

[0001564590-18-027351:notes:3]
[same as prior period, unchanged from 0001564590-18-019154:notes:3]

[0001564590-18-027351:notes:4]
[same as prior period, unchanged from 0001564590-18-019154:notes:4]

[0001564590-18-027351:notes:5]
[same as prior period, unchanged from 0001564590-18-019154:notes:5]

[0001564590-18-027351:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-18-027351:notes:7]
[same as prior period, unchanged from 0001564590-18-019154:notes:7]

[0001564590-18-027351:notes:8]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as, ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provides for an optional transition method that allows for the application of current legacy guidance, including its disclosure requirements, in the comparative periods presented in the year of adoption.  Otherwise, Topic 842 must be adopted by a modified retrospective method, with elective reliefs, which requires application of the new guidance for all periods presented.   The Company plans to use the optional transition method when adopting the new standard.  ASU 2016-02, ASU 2018-10 and ASU 2018-11 are effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. We anticipate the adoption of these ASUs will have a material increase in the assets and liabilities of our consolidated balance sheets; however, we do not believe adoption will have a material effect on our results of operations. We believe the most significant effect relates to our accounting for operating leases for office space.

[0001564590-18-027351:notes:9]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. ASU 2016-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect ASU 2016-13 will have on our consolidated financial statements.

[0001564590-18-027351:notes:10]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material effect on our consolidated financial statements.

[0001564590-18-027351:notes:11]
In March 2017, the FASB issued ASU 2017-08, Receivables – Nonrefundable Fees and Other Costs (Subtopic 310-20): Premium Amortization on Purchased Callable Debt Securities, which shortens the amortization period for the premium on certain purchased callable debt securities to the earliest call date.  ASU 2017-08 is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2018 with early adoption permitted.  The amendments should be applied through a modified-retrospective transition approach that requires a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  We are currently evaluating the effect of ASU 2017-08, but we do not expect it will have a material effect on our consolidated financial statements.

[0001564590-18-027351:notes:12]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating the effect ASU 2017-12 will have on our consolidated financial statements.

[0001564590-18-027351:notes:13]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allows for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating whether to reclassify stranded tax effects related to the Tax Cuts and Jobs Act of 2017, but we do not expect ASU 2018-02 will have a material effect on our consolidated financial statements.

[0001564590-18-027351:notes:14]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820) Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project called, Concepts Statement No. 8 -  Conceptual Framework for Financial Reporting — Chapter 8, Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements.  ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements.  More specifically ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value.  In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows.  ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but we do not expect it will have a material effect on our financial statement disclosures.

[0001564590-18-027351:notes:15]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715.  ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (PBO) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (ABO) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but we do not expect it will have a material effect on our financial statement disclosures.

[0001564590-18-027351:notes:16]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40), Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement.  Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software.  ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted.  We are currently evaluating whether to early adopt, but we do not expect it will have a material effect on our consolidated financial statements.

[0001564590-18-027351:notes:17]
[same as prior period, unchanged from 0001564590-18-019154:notes:13]

[0001564590-18-027351:notes:18]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification and/or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We adopted ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method, which was applied to all contracts on the date of initial adoption.

[0001564590-18-027351:notes:19]
[same as prior period, unchanged from 0001564590-18-019154:notes:15]

[0001564590-18-027351:notes:20]
[same as prior period, unchanged from 0001564590-18-019154:notes:16]

[0001564590-18-027351:notes:21]
The cumulative effect of the changes made to our Consolidated Balance Sheet on January 1, 2018 for the adoption of ASU 2014-09 and the related ASUs was as follows:

[0001564590-18-027351:notes:22]
| (In thousands) |  | Balance at December 31, 2017 |  |  | Adjustments due to ASU 2014-09 |  |  | Balance at January 1, 2018 |  |
| Other receivables |  | $ | 26,578 |  |  | $ | 374 |  |  | $ | 26,952 |  |
| Deferred tax assets, net |  | $ | 23,428 |  |  | $ | (96 | ) |  | $ | 23,332 |  |
| Retained earnings |  | $ | 922,178 |  |  | $ | 278 |  |  | $ | 922,456 |  |

[0001564590-18-027351:notes:23]
The effect of the adoption of ASU 2014-09 and the related ASUs on our financial statements was as follows:

[0001564590-18-027351:notes:24]
|  |  | For the three months ended September 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 121,043 |  |  | $ | 120,588 |  |  | $ | 455 |  |
| Services |  | $ | 19,292 |  |  | $ | 17,932 |  |  | $ | 1,360 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 69,943 |  |  | $ | 69,754 |  |  | $ | 189 |  |
| Services |  | $ | 11,944 |  |  | $ | 11,046 |  |  | $ | 898 |  |
| Income before benefit for income taxes |  | $ | 3,220 |  |  | $ | 2,492 |  |  | $ | 728 |  |
| Benefit for income taxes |  | $ | 4,369 |  |  | $ | 3,382 |  |  | $ | 987 |  |
| Net income |  | $ | 7,589 |  |  | $ | 5,874 |  |  | $ | 1,715 |  |

[0001564590-18-027351:notes:25]
|  |  | For the nine months ended September 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 341,359 |  |  | $ | 341,464 |  |  | $ | (105 | ) |
| Services |  | $ | 47,830 |  |  | $ | 46,062 |  |  | $ | 1,768 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 208,184 |  |  | $ | 208,480 |  |  | $ | (296 | ) |
| Services |  | $ | 32,828 |  |  | $ | 31,743 |  |  | $ | 1,085 |  |
| Loss before benefit for income taxes |  | $ | (22,784 | ) |  | $ | (23,658 | ) |  | $ | 874 |  |
| Benefit for income taxes |  | $ | 11,889 |  |  | $ | 10,938 |  |  | $ | 951 |  |
| Net loss |  | $ | (10,895 | ) |  | $ | (12,720 | ) |  | $ | 1,825 |  |

[0001564590-18-027351:notes:26]
|  |  | As of September 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other receivables |  | $ | 30,084 |  |  | $ | 27,917 |  |  | $ | 2,167 |  |
| Inventory |  | $ | 106,060 |  |  | $ | 106,402 |  |  | $ | (342 | ) |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 900,324 |  |  | $ | 898,499 |  |  | $ | 1,825 |  |

[0001564590-18-027351:notes:27]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. Subsequently, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, which issued technical corrections and improvements intended to clarify certain aspects of ASU 2016-01. ASU 2016-01 was effective beginning January 1, 2018 and we now recognize any changes in the fair value of certain equity investments in net income as prescribed by the new standard rather than in other comprehensive income. We adopted ASU 2016-01 on January 1, 2018 using the modified retrospective method, which resulted in a $3.2 million reclassification of net unrealized gains from accumulated other comprehensive income to opening retained earnings. ASU 2018-03 is effective for us with the interim period beginning after June 15, 2018. See Note 7 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-027351:notes:28]
In March 2017, the FASB issued ASU 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost. ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. We adopted ASU 2017-07 on January 1, 2018. We retrospectively adopted the presentation of service cost separate from other components of net periodic pension costs. As a result, $0.1 million and $0.3 million have been reclassified from cost of sales, selling, general and administrative expenses, and research and development expense to other income (expense), net for the three and nine months ended September 30, 2017, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-027351:notes:29]
[same as prior period, unchanged from 0001564590-18-019154:notes:25]

[0001564590-18-027351:notes:30]
[same as prior period, unchanged from 0001564590-18-019154:notes:26]

[0001564590-18-027351:notes:31]
[same as prior period, unchanged from 0001564590-18-019154:notes:27]

[0001564590-18-027351:notes:32]
[same as prior period, unchanged from 0001564590-18-019154:notes:28]

[0001564590-18-027351:notes:33]
[same as prior period, unchanged from 0001564590-18-019154:notes:29]

[0001564590-18-027351:notes:34]
The actual revenue and net loss included in our Consolidated Statements of Income for the three months ended September 30, 2018 and the period March 19, 2018 to September 30, 2018 are as follows:

[0001564590-18-027351:notes:35]
|  | Three Months Ended |  |  | March 19, 2018 to |  |
| (In thousands) | September 30, 2018 |  |  | September 30, 2018 |  |
| Revenue | $ | 1,021 |  |  | $ | 2,218 |  |
| Net income (loss) | $ | 564 |  |  | $ | (322 | ) |

[0001564590-18-027351:notes:36]
[same as prior period, unchanged from 0001564590-18-019154:notes:32]

[0001564590-18-027351:notes:37]
[same as prior period, unchanged from 0001564590-18-019154:notes:33]

[0001564590-18-027351:notes:38]
[same as prior period, unchanged from 0001564590-18-019154:notes:34]

[0001564590-18-027351:notes:39]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Pro forma revenue |  | $ | 187,027 |  |  | $ | 390,449 |  |  | $ | 545,706 |  |
| Pro forma net income (loss) |  | $ | 14,997 |  |  | $ | (23,431 | ) |  | $ | 43,826 |  |
| Pro forma earnings per share - basic |  | $ | 0.31 |  |  | $ | (0.49 | ) |  | $ | 0.91 |  |
| Pro forma earnings per share - diluted |  | $ | 0.31 |  |  | $ | (0.49 | ) |  | $ | 0.90 |  |

[0001564590-18-027351:notes:40]
For the three and nine months ended September 30, 2018, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $0.7 million and $1.6 million, respectively, related to this acquisition.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-18-027351:notes:41]
[same as prior period, unchanged from 0001564590-18-019154:notes:37]

[0001564590-18-027351:notes:42]
[same as prior period, unchanged from 0001564590-18-019154:notes:38]

[0001564590-18-027351:notes:43]
[same as prior period, unchanged from 0001564590-18-019154:notes:39]

[0001564590-18-027351:notes:44]
[same as prior period, unchanged from 0001564590-18-019154:notes:40]

[0001564590-18-027351:notes:45]
[same as prior period, unchanged from 0001564590-18-019154:notes:41]

[0001564590-18-027351:notes:46]
[same as prior period, unchanged from 0001564590-18-019154:notes:42]

[0001564590-18-027351:notes:47]
The majority of the revenue from this segment is from hardware sales and is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

[0001564590-18-027351:notes:48]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term. In relation to these lease agreements, during the three months ended September 30, 2018 and 2017, we recognized revenue of $4.2 million and $8.4 million, respectively, and during the nine months ended September 30, 2018 and 2017 we recognized revenue of $10.5 million and $15.4 million, respectively.

[0001564590-18-027351:notes:49]
[same as prior period, unchanged from 0001564590-18-019154:notes:45]

[0001564590-18-027351:notes:50]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, and solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-18-027351:notes:51]
[same as prior period, unchanged from 0001564590-18-019154:notes:47]

[0001564590-18-027351:notes:52]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue as our customers benefit evenly throughout the contract term and deferred revenues are recorded in current and non-current unearned revenue.

[0001564590-18-027351:notes:53]
[same as prior period, unchanged from 0001564590-18-019154:notes:49]

[0001564590-18-027351:notes:54]
[same as prior period, unchanged from 0001564590-18-019154:notes:50]

[0001564590-18-027351:notes:55]
As of September 30, 2018, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

[0001564590-18-027351:notes:56]
[same as prior period, unchanged from 0001564590-18-019154:notes:52]

[0001564590-18-027351:notes:57]
| (In thousands) |  | September 30, 2018 |  |  | January 1, 2018 |  |
| Accounts receivable |  | $ | 101,865 |  |  | $ | 144,150 |  |
| Contract assets |  | $ | 4,564 |  |  | $ | 374 |  |
| Unearned revenue |  | $ | 17,004 |  |  | $ | 13,070 |  |
| Non-current unearned revenue |  | $ | 3,846 |  |  | $ | 4,556 |  |

[0001564590-18-027351:notes:58]
The decrease in accounts receivable is due to the collection of customer specific payment terms that became due in the first quarter of 2018. The increase in the contract asset balance for the nine months ended September 30, 2018 is primarily attributable to revenue recognized that has not yet been billed to the customer during the period. The increase in the unearned revenue balance as of nine months ended September 30, 2018 is primarily attributable to cash payments received or due in advance of satisfying our performance obligations, offset by $8.9 million of revenues recognized that were included in the unearned revenue balance as of December 31, 2017.

[0001564590-18-027351:notes:59]
The following table disaggregates our revenue by major source for the three months ended September 30, 2018:

[0001564590-18-027351:notes:60]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 76,046 |  |  | $ | 15,855 |  |  | $ | 91,901 |  |
| Customer Devices |  |  | 37,313 |  |  |  | 1,239 |  |  |  | 38,552 |  |
| Traditional & Other Products |  |  | 7,684 |  |  |  | 2,198 |  |  |  | 9,882 |  |
| Total |  | $ | 121,043 |  |  | $ | 19,292 |  |  | $ | 140,335 |  |

[0001564590-18-027351:notes:61]
The following table disaggregates our revenue by major source for the nine months ended September 30, 2018:

[0001564590-18-027351:notes:62]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 220,653 |  |  | $ | 37,670 |  |  | $ | 258,323 |  |
| Customer Devices |  |  | 99,396 |  |  |  | 3,817 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 21,310 |  |  |  | 6,343 |  |  |  | 27,653 |  |
| Total |  | $ | 341,359 |  |  | $ | 47,830 |  |  | $ | 389,189 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-027351:notes:63]
[same as prior period, unchanged from 0001564590-18-019154:notes:59]

[0001564590-18-027351:notes:64]
Our effective tax rate decreased from an expense of 23.1% in the nine months ended September 30, 2017, to a benefit of 34.9%, excluding the tax effect of the bargain purchase gain, in the nine months ended September 30, 2018. The decrease in the effective tax rate between the two periods is primarily driven by the completion of other tax projects, current year net losses in our domestic business and the effect of the U.S. Tax Cuts and Jobs Act, which was signed into law on December 22, 2017.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-18-027351:notes:65]
[same as prior period, unchanged from 0001564590-18-019154:notes:61]

[0001564590-18-027351:notes:66]
[same as prior period, unchanged from 0001564590-18-019154:notes:62]

[0001564590-18-027351:notes:67]
The following table summarizes the components of net periodic pension cost for the three and nine months ended September 30, 2018 and 2017:

[0001564590-18-027351:notes:68]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Service cost |  | $ | 294 |  |  | $ | 327 |  |  | $ | 905 |  |  | $ | 930 |  |
| Interest cost |  |  | 179 |  |  |  | 158 |  |  |  | 551 |  |  |  | 448 |  |
| Expected return on plan assets |  |  | (381 | ) |  |  | (329 | ) |  |  | (1,174 | ) |  |  | (935 | ) |
| Amortization of actuarial losses |  |  | 61 |  |  |  | 80 |  |  |  | 188 |  |  |  | 228 |  |
| Net periodic pension cost |  | $ | 153 |  |  | $ | 236 |  |  | $ | 470 |  |  | $ | 671 |  |

[0001564590-18-027351:notes:69]
The components of net periodic pension cost other than the service cost component are included in the line item “Other income (expense), net” in the Consolidated Statements of Income.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-027351:notes:70]
[same as prior period, unchanged from 0001564590-18-019154:notes:66]

[0001564590-18-027351:notes:71]
The following table summarizes the stock-based compensation expense related to stock options, performance stock units (PSUs), restricted stock units (RSUs) and restricted stock for the three and nine months ended September 30, 2018 and 2017, which was recognized as follows:

[0001564590-18-027351:notes:72]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 101 |  |  | $ | 97 |  |  | $ | 298 |  |  | $ | 281 |  |
| Selling, general and administrative expense |  |  | 894 |  |  |  | 994 |  |  |  | 2,924 |  |  |  | 3,018 |  |
| Research and development expense |  |  | 645 |  |  |  | 743 |  |  |  | 2,021 |  |  |  | 2,274 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,539 |  |  |  | 1,737 |  |  |  | 4,945 |  |  |  | 5,292 |  |
| Total stock-based compensation expense |  |  | 1,640 |  |  |  | 1,834 |  |  |  | 5,243 |  |  |  | 5,573 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (292 | ) |  |  | (402 | ) |  |  | (1,016 | ) |  |  | (1,215 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,348 |  |  | $ | 1,432 |  |  | $ | 4,227 |  |  | $ | 4,358 |  |

[0001564590-18-027351:notes:73]
[same as prior period, unchanged from 0001564590-18-019154:notes:69]

[0001564590-18-027351:notes:74]
The following table is a summary of our stock options outstanding as of December 31, 2017 and September 30, 2018 and the changes that occurred during the nine months ended September 30, 2018:

[0001564590-18-027351:notes:75]
| (In thousands, except per share amounts) |  | Number of Stock Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Stock options outstanding, December 31, 2017 |  |  | 5,148 |  |  | $ | 22.65 |  |  |  | 4.87 |  |  | $ | 6,109 |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (85 | ) |  | $ | 15.48 |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (71 | ) |  | $ | 16.50 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (331 | ) |  | $ | 25.87 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, September 30, 2018 |  |  | 4,661 |  |  | $ | 22.64 |  |  |  | 4.12 |  |  | $ | 2,730 |  |
| Stock options vested and expected to vest, September 30, 2018 |  |  | 4,661 |  |  | $ | 22.64 |  |  |  | 4.12 |  |  | $ | 2,730 |  |
| Stock options exercisable, September 30, 2018 |  |  | 3,952 |  |  | $ | 23.75 |  |  |  | 3.63 |  |  | $ | 1,600 |  |

[0001564590-18-027351:notes:76]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between the closing price of our stock on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money stock options) that would have been received by the option holders had all option holders exercised their options on September 30, 2018. The aggregate intrinsic value will change based on the fair market value of our stock.

[0001564590-18-027351:notes:77]
The total pre-tax intrinsic value of options exercised during the three and nine months ended September 30, 2018 was $0.1 million and $0.2 million, respectively.

[0001564590-18-027351:notes:78]
As of September 30, 2018, there was $1.2 million of unrecognized compensation expense related to unvested stock options, which is expected to be recognized over an average remaining recognition period of 1.0 years.

[0001564590-18-027351:notes:79]
[same as prior period, unchanged from 0001564590-18-019154:notes:75]

[0001564590-18-027351:notes:80]
There were no stock options granted during the three and nine months ended September 30, 2018 or 2017.

[0001564590-18-027351:notes:81]
[same as prior period, unchanged from 0001564590-18-019154:notes:77]

[0001564590-18-027351:notes:82]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2017 and the changes that occurred during the nine months ended September 30, 2018:

[0001564590-18-027351:notes:83]
| (In thousands, except per share amounts) |  | Number of Shares |  |  | Weighted Avg. Grant Date Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2017 |  |  | 1,292 |  |  | $ | 21.33 |  |
| PSUs, RSUs and restricted stock granted |  |  | 22 |  |  | $ | 17.84 |  |
| PSUs, RSUs and restricted stock vested |  |  | (14 | ) |  | $ | 20.19 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (165 | ) |  | $ | 21.66 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, September 30, 2018 |  |  | 1,135 |  |  | $ | 21.23 |  |

[0001564590-18-027351:notes:84]
The fair value of our PSUs with market conditions is calculated using a Monte Carlo simulation valuation method. The fair value of RSUs and restricted stock is equal to the closing price of our stock on the date of grant. During the first quarter of 2017, the Compensation Committee of the Board of Directors approved a PSU grant of 0.5 million shares that contain performance conditions. The fair value of these performance-based PSU awards was equal to the closing price of our stock on the date of grant.

[0001564590-18-027351:notes:85]
As of September 30, 2018, there was $9.8 million of unrecognized compensation expense related to unvested market-based PSUs, RSUs and restricted stock, which is expected to be recognized over an average remaining recognition period of 2.6 years. In addition, there was $9.4 million of unrecognized compensation expense related to unvested performance-based PSUs, which will be recognized over the requisite service period of three years as the achievement of the performance objective becomes probable. For the three and nine months ended September 30, 2018, no compensation expense was recognized related to these performance-based PSU awards.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-18-027351:notes:86]
7. INVESTMENTS

[0001564590-18-027351:notes:87]
Debt Securities and Other Investments

[0001564590-18-027351:notes:88]
At September 30, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-18-027351:notes:89]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 25,758 |  |  | $ | 13 |  |  | $ | (209 | ) |  | $ | 25,562 |  |
| Municipal fixed-rate bonds |  |  | 1,451 |  |  |  | — |  |  |  | (36 | ) |  |  | 1,415 |  |
| Asset-backed bonds |  |  | 8,384 |  |  |  | — |  |  |  | (29 | ) |  |  | 8,355 |  |
| Mortgage/Agency-backed bonds |  |  | 5,450 |  |  |  | — |  |  |  | (87 | ) |  |  | 5,363 |  |
| U.S. government bonds |  |  | 19,957 |  |  |  | — |  |  |  | (184 | ) |  |  | 19,773 |  |
| Foreign government bonds |  |  | 593 |  |  |  | 2 |  |  |  | — |  |  |  | 595 |  |
| Available-for-sale debt securities held at fair value |  | $ | 61,593 |  |  | $ | 15 |  |  | $ | (545 | ) |  | $ | 61,063 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 26,700 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 520 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 88,283 |  |

[0001564590-18-027351:notes:90]
At December 31, 2017, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-18-027351:notes:91]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 32,654 |  |  | $ | 44 |  |  | $ | (155 | ) |  | $ | 32,543 |  |
| Municipal fixed-rate bonds |  |  | 2,902 |  |  |  | 2 |  |  |  | (22 | ) |  |  | 2,882 |  |
| Asset-backed bonds |  |  | 6,545 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 6,526 |  |
| Mortgage/Agency-backed bonds |  |  | 5,554 |  |  |  | 1 |  |  |  | (46 | ) |  |  | 5,509 |  |
| U.S. government bonds |  |  | 14,477 |  |  |  | — |  |  |  | (174 | ) |  |  | 14,303 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 5 |  |  |  | — |  |  |  | 730 |  |
| Available-for-sale debt securities held at fair value |  | $ | 62,857 |  |  | $ | 53 |  |  | $ | (417 | ) |  | $ | 62,493 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 90,840 |  |

[0001564590-18-027351:notes:92]
As of September 30, 2018 our debt securities had the following contractual maturities:

[0001564590-18-027351:notes:93]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 2,800 |  |  | $ | — |  |  | $ | 3,112 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 10,122 |  |  |  | 287 |  |  |  | 657 |  |  |  | — |  |  |  | 11,716 |  |  |  | 285 |  |
| Two to three years |  |  | 9,898 |  |  |  | 1,128 |  |  |  | 714 |  |  |  | 425 |  |  |  | 5,565 |  |  |  | 310 |  |
| Three to five years |  |  | 2,742 |  |  |  | — |  |  |  | 2,244 |  |  |  | 1,561 |  |  |  | 2,492 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 445 |  |  |  | 525 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,183 |  |  |  | 2,852 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 25,562 |  |  | $ | 1,415 |  |  | $ | 8,355 |  |  | $ | 5,363 |  |  | $ | 19,773 |  |  | $ | 595 |  |

[0001564590-18-027351:notes:94]
Actual maturities may differ from contractual maturities because some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-18-027351:notes:95]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:

[0001564590-18-027351:notes:96]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Gross realized gains on debt securities |  | $ | 24 |  |  | $ | 91 |  |  | $ | 49 |  |  | $ | 148 |  |
| Gross realized losses on debt securities |  |  | (50 | ) |  |  | (28 | ) |  |  | (365 | ) |  |  | (179 | ) |
| Total gain (loss) recognized, net |  | $ | (26 | ) |  | $ | 63 |  |  | $ | (316 | ) |  | $ | (31 | ) |

[0001564590-18-027351:notes:97]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-18-027351:notes:98]
At September 30, 2018, we held a $26.7 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $26.7 million at September 30, 2018 and December 31, 2017. At September 30, 2018 and December 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $26.5 million and $26.7 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

[0001564590-18-027351:notes:99]
Marketable Equity Securities

[0001564590-18-027351:notes:100]
Our marketable equity securities consist of publicly traded stocks or funds measured at fair value.

[0001564590-18-027351:notes:101]
Prior to January 1, 2018, our marketable equity securities were classified as available-for-sale. Realized gains and losses on marketable equity securities were included in net investment gain (loss). Unrealized gains and losses were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet.

[0001564590-18-027351:notes:102]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to opening retained earnings.

[0001564590-18-027351:notes:103]
Realized and unrealized gains and losses for our marketable equity securities for the three and nine months ended September 30, 2018 were as follows:

[0001564590-18-027351:notes:104]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2018 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | 1,240 |  |  | $ | 1,587 |  |
| Unrealized gains (losses) on equity securities held |  |  | 3,293 |  |  |  | 4,129 |  |
| Total gain (loss) recognized, net |  | $ | 4,533 |  |  | $ | 5,716 |  |

[0001564590-18-027351:notes:105]
As of September 30, 2018 and 2017, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not significant.

[0001564590-18-027351:notes:106]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows:  Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-18-027351:notes:107]
|  |  | Fair Value Measurements at September 30, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,423 |  |  | $ | 1,423 |  |  | $ | — |  |  | $ | — |  |
| Foreign government securities |  |  | 600 |  |  |  | — |  |  |  | 600 |  |  |  | — |  |
| Cash equivalents |  |  | 2,023 |  |  |  | 1,423 |  |  |  | 600 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 25,562 |  |  |  | — |  |  |  | 25,562 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,415 |  |  |  | — |  |  |  | 1,415 |  |  |  | — |  |
| Asset-backed bonds |  |  | 8,355 |  |  |  | — |  |  |  | 8,355 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,363 |  |  |  | — |  |  |  | 5,363 |  |  |  | — |  |
| U.S. government bonds |  |  | 19,773 |  |  |  | 19,773 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 595 |  |  |  | — |  |  |  | 595 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Marketable equity securities – various industries |  |  | 40,645 |  |  |  | 40,645 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 277 |  |  |  | 277 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,948 |  |  |  | 20,948 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 122,933 |  |  |  | 81,643 |  |  |  | 41,290 |  |  |  | — |  |
| Total |  | $ | 124,956 |  |  | $ | 83,066 |  |  | $ | 41,890 |  |  | $ | — |  |

[0001564590-18-027351:notes:108]
|  |  | Fair Value Measurements at December 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,851 |  |  | $ | 5,851 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 3,999 |  |  |  | — |  |  |  | 3,999 |  |  |  | — |  |
| Cash equivalents |  |  | 9,850 |  |  |  | 5,851 |  |  |  | 3,999 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 32,543 |  |  |  | — |  |  |  | 32,543 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,882 |  |  |  | — |  |  |  | 2,882 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,526 |  |  |  | — |  |  |  | 6,526 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,509 |  |  |  | — |  |  |  | 5,509 |  |  |  | — |  |
| U.S. government bonds |  |  | 14,303 |  |  |  | 14,303 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 730 |  |  |  | — |  |  |  | 730 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,662 |  |  |  | 35,662 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 19,883 |  |  |  | 19,883 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 118,038 |  |  |  | 69,848 |  |  |  | 48,190 |  |  |  | — |  |
| Total |  | $ | 127,888 |  |  | $ | 75,699 |  |  | $ | 52,189 |  |  | $ | — |  |

[0001564590-18-027351:notes:109]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-027351:notes:110]
[same as prior period, unchanged from 0001564590-18-019154:notes:106]

[0001564590-18-027351:notes:111]
[same as prior period, unchanged from 0001564590-18-019154:notes:107]

[0001564590-18-027351:notes:112]
[same as prior period, unchanged from 0001564590-18-019154:notes:108]

[0001564590-18-027351:notes:113]
[same as prior period, unchanged from 0001564590-18-019154:notes:109]

[0001564590-18-027351:notes:114]
[same as prior period, unchanged from 0001564590-18-019154:notes:110]

[0001564590-18-027351:notes:115]
We have certain customers and suppliers who are invoiced or pay in a non-functional currency. Changes in the monetary exchange rates may adversely affect our results of operations and financial condition, as outstanding non-functional balances are revalued to the functional currency through profit and loss. When appropriate, we utilize foreign exchange forward contracts to help manage the volatility relating to these valuation exposures. All changes in the fair value of our derivative instruments that do not qualify for or are not designated for hedged accounting transactions are recognized as other income (expense), net in the Consolidated Statements of Income.

[0001564590-18-027351:notes:116]
[same as prior period, unchanged from 0001564590-18-019154:notes:112]

[0001564590-18-027351:notes:117]
As of September 30, 2018, we had no foreign exchange forward contracts.

[0001564590-18-027351:notes:118]
The changes in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the three and nine months ended September 30, 2018 and 2017 were as follows:

[0001564590-18-027351:notes:119]
|  |  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Income Statement |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | Location |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense), net |  | $ | — |  |  | $ | (334 | ) |  | $ | 13 |  |  | $ | (819 | ) |

[0001564590-18-027351:notes:120]
The changes in our derivatives designated as hedging instruments recorded in other comprehensive income (OCI) and reclassified to income, net of tax, during the three and nine months ended September 30, 2018 and 2017, were as follows:

[0001564590-18-027351:notes:121]
|  |  | Amount of Gains (Losses) Recognized in |  |  |  |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  |  |  | from AOCI into Income |  |
|  |  |  |  |  | Location of Gains |  |  |  |
|  |  | Three Months Ended September 30, |  |  | (Losses) Reclassified |  | Three Months Ended September 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | from AOCI into Income |  | 2018 |  |  | 2017 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | — |  |  | $ | (127 | ) |  | Cost of Sales |  | $ | — |  |  | $ | (269 | ) |

[0001564590-18-027351:notes:122]
|  |  | Amount of Gains (Losses) Recognized in |  |  |  |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  |  |  | from AOCI into Income |  |
|  |  |  |  |  | Location of Gains |  |  |  |
|  |  | Nine Months Ended September 30, |  |  | (Losses) Reclassified |  | Nine Months Ended September 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | from AOCI into Income |  | 2018 |  |  | 2017 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | — |  |  | $ | (619 | ) |  | Cost of Sales |  | $ | — |  |  | $ | (423 | ) |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-18-027351:notes:123]
[same as prior period, unchanged from 0001564590-18-019154:notes:119]

[0001564590-18-027351:notes:124]
At September 30, 2018 and December 31, 2017, inventory consisted of the following:

[0001564590-18-027351:notes:125]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Raw materials |  | $ | 47,664 |  |  | $ | 44,185 |  |
| Work in process |  |  | 1,289 |  |  |  | 1,939 |  |
| Finished goods |  |  | 57,107 |  |  |  | 76,418 |  |
| Total |  | $ | 106,060 |  |  | $ | 122,542 |  |

[0001564590-18-027351:notes:126]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At September 30, 2018 and December 31, 2017, raw materials reserves totaled $17.2 million and $15.0 million, respectively, and finished goods inventory reserves totaled $10.6 million and $8.3 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-18-027351:notes:127]
[same as prior period, unchanged from 0001564590-18-019154:notes:123]

[0001564590-18-027351:notes:128]
Goodwill, all of which relates to our acquisition of Bluesocket, Inc., was $3.5 million at September 30, 2018 and December 31, 2017, of which $3.1 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-18-027351:notes:129]
[same as prior period, unchanged from 0001564590-18-019154:notes:125]

[0001564590-18-027351:notes:130]
[same as prior period, unchanged from 0001564590-18-019154:notes:126]

[0001564590-18-027351:notes:131]
The following table presents our intangible assets as of September 30, 2018 and December 31, 2017. Fully amortized intangible assets have been removed from prior year balances for comparability.

[0001564590-18-027351:notes:132]
| (In thousands) |  | September 30, 2018 |  |  | December 31, 2017 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 20,724 |  |  | $ | (5,072 | ) |  | $ | 15,652 |  |  | $ | 7,474 |  |  | $ | (4,283 | ) |  | $ | 3,191 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (355 | ) |  |  | 5,545 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Developed technology |  |  | 5,435 |  |  |  | (4,799 | ) |  |  | 636 |  |  |  | 5,524 |  |  |  | (4,663 | ) |  |  | 861 |  |
| Supplier relationship |  |  | 2,800 |  |  |  | (758 | ) |  |  | 2,042 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Intellectual property |  |  | 930 |  |  |  | (930 | ) |  |  | — |  |  |  | 930 |  |  |  | (852 | ) |  |  | 78 |  |
| Patent |  |  | 500 |  |  |  | (140 | ) |  |  | 360 |  |  |  | 500 |  |  |  | (89 | ) |  |  | 411 |  |
| Non-compete |  |  | 200 |  |  |  | (181 | ) |  |  | 19 |  |  |  | 200 |  |  |  | (115 | ) |  |  | 85 |  |
| Trade names |  |  | 100 |  |  |  | (100 | ) |  |  | — |  |  |  | 100 |  |  |  | (65 | ) |  |  | 35 |  |
| Total |  | $ | 36,589 |  |  | $ | (12,335 | ) |  | $ | 24,254 |  |  | $ | 14,728 |  |  | $ | (10,067 | ) |  | $ | 4,661 |  |

[0001564590-18-027351:notes:133]
Amortization expense, all of which relates to business acquisitions, was $0.9 million and $0.5 million for the three months ended September 30, 2018 and 2017, respectively, and $2.4 million for the nine months ended September 30, 2018 and 2017.

[0001564590-18-027351:notes:134]
As of September 30, 2018, the estimated future amortization expense of our intangible assets is as follows:

[0001564590-18-027351:notes:135]
| (In thousands) |  | Amount |  |
| Remainder of 2018 |  | $ | 859 |  |
| 2019 |  |  | 3,540 |  |
| 2020 |  |  | 2,657 |  |
| 2021 |  |  | 2,364 |  |
| 2022 |  |  | 2,350 |  |
| Thereafter |  |  | 12,484 |  |
| Total |  | $ | 24,254 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-18-027351:notes:136]
[same as prior period, unchanged from 0001564590-18-019154:notes:132]

[0001564590-18-027351:notes:137]
A summary of the changes in stockholders’ equity for the nine months ended September 30, 2018 is as follows:

[0001564590-18-027351:notes:138]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2017 |  | $ | 497,911 |  |
| Net income (loss) |  |  | (10,895 | ) |
| Dividend payments |  |  | (12,976 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (15 | ) |
| Net unrealized gains (losses) on available-for-sale securities (net of tax) |  |  | (3,340 | ) |
| Defined benefit plan adjustments (net of tax) |  |  | 104 |  |
| Foreign currency translation adjustment |  |  | (3,033 | ) |
| Proceeds from stock option exercises |  |  | 1,321 |  |
| Purchase of treasury stock |  |  | (14,185 | ) |
| Adoption of new accounting standards (see Note 1) |  |  | 3,499 |  |
| Stock-based compensation expense |  |  | 5,243 |  |
| RSU's and restricted stock vested |  |  | (33 | ) |
| Balance, September 30, 2018 |  | $ | 463,601 |  |

[0001564590-18-027351:notes:139]
[same as prior period, unchanged from 0001564590-18-019154:notes:135]

[0001564590-18-027351:notes:140]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock that are implemented through open market or private purchases from time to time as conditions warrant. During the nine months ended September 30, 2018, we repurchased 0.9 million shares of our common stock at an average price of $15.75 per share. As of September 30, 2018, we have the authority to purchase an additional 2.7 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-18-027351:notes:141]
[same as prior period, unchanged from 0001564590-18-019154:notes:137]

[0001564590-18-027351:notes:142]
We issued 0.1 million shares of treasury stock during the nine months ended September 30, 2018 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $1.3 million from the exercise of these stock options during the nine months ended September 30, 2018.

[0001564590-18-027351:notes:143]
[same as prior period, unchanged from 0001564590-18-019154:notes:139]

[0001564590-18-027351:notes:144]
During the nine months ended September 30, 2018, we paid cash dividends as follows (in thousands except per share amounts):

[0001564590-18-027351:notes:145]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| January 31, 2018 |  | February 14, 2018 |  | $ | 0.09 |  |  | $ | 4,367 |  |
| May 2, 2018 |  | May 16, 2018 |  | $ | 0.09 |  |  | $ | 4,312 |  |
| August 1, 2018 |  | August 15, 2018 |  | $ | 0.09 |  |  | $ | 4,297 |  |

[0001564590-18-027351:notes:146]
[same as prior period, unchanged from 0001564590-18-019154:notes:142]

[0001564590-18-027351:notes:147]
[same as prior period, unchanged from 0001564590-18-019154:notes:143]

[0001564590-18-027351:notes:148]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the three months ended September 30, 2018 and 2017:

[0001564590-18-027351:notes:149]
|  |  | Three Months Ended September 30, 2018 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | (741 | ) |  | $ | (4,219 | ) |  | $ | (4,158 | ) |  | $ | (9,118 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,208 |  |  |  | — |  |  |  | (451 | ) |  |  | 757 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (1,240 | ) |  |  | 37 |  |  |  | — |  |  |  | (1,203 | ) |
| Net current period other comprehensive income (loss) |  |  | (32 | ) |  |  | 37 |  |  |  | (451 | ) |  |  | (446 | ) |
| Ending balance |  | $ | (773 | ) |  | $ | (4,182 | ) |  | $ | (4,609 | ) |  | $ | (9,564 | ) |

[0001564590-18-027351:notes:150]
|  |  | Three Months Ended September 30, 2017 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 2,112 |  |  | $ | (338 | ) |  | $ | (4,876 | ) |  | $ | (3,714 | ) |  | $ | (6,816 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,420 |  |  |  | (127 | ) |  |  | — |  |  |  | 1,541 |  |  |  | 2,834 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (616 | ) |  |  | 269 |  |  |  | 73 |  |  |  | — |  |  |  | (274 | ) |
| Net current period other comprehensive income (loss) |  |  | 804 |  |  |  | 142 |  |  |  | 73 |  |  |  | 1,541 |  |  |  | 2,560 |  |
| Ending balance |  | $ | 2,916 |  |  | $ | (196 | ) |  | $ | (4,803 | ) |  | $ | (2,173 | ) |  | $ | (4,256 | ) |

[0001564590-18-027351:notes:151]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the nine months ended September 30, 2018 and 2017:

[0001564590-18-027351:notes:152]
|  |  | Nine Months Ended September 30, 2018 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 2,567 |  |  | $ | (4,286 | ) |  | $ | (1,576 | ) |  | $ | (3,295 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 869 |  |  |  | — |  |  |  | (3,033 | ) |  |  | (2,164 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (989 | ) |  |  | 104 |  |  |  | — |  |  |  | (885 | ) |
| Amounts reclassified to retained earnings (1) |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |
| Net current period other comprehensive income (loss) |  |  | (3,340 | ) |  |  | 104 |  |  |  | (3,033 | ) |  |  | (6,269 | ) |
| Ending balance |  | $ | (773 | ) |  | $ | (4,182 | ) |  | $ | (4,609 | ) |  | $ | (9,564 | ) |

[0001564590-18-027351:notes:153]
|  | (1) | With the adoption of ASU 2016-01, the unrealized gains on our equity investments were reclassified to retained earnings. See Note 1 for more information. |

[0001564590-18-027351:notes:154]
|  |  | Nine Months Ended September 30, 2017 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 404 |  |  | $ | — |  |  | $ | (5,017 | ) |  | $ | (7,575 | ) |  | $ | (12,188 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 4,262 |  |  |  | (619 | ) |  |  | — |  |  |  | 5,402 |  |  |  | 9,045 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (1,750 | ) |  |  | 423 |  |  |  | 214 |  |  |  | — |  |  |  | (1,113 | ) |
| Net current period other comprehensive income (loss) |  |  | 2,512 |  |  |  | (196 | ) |  |  | 214 |  |  |  | 5,402 |  |  |  | 7,932 |  |
| Ending balance |  | $ | 2,916 |  |  | $ | (196 | ) |  | $ | (4,803 | ) |  | $ | (2,173 | ) |  | $ | (4,256 | ) |

[0001564590-18-027351:notes:155]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the three months ended September 30, 2018 and 2017:

[0001564590-18-027351:notes:156]
| (In thousands) |  | Three Months Ended September 30, 2018 |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | 1,676 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (54 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,622 |  |  |  |
| Tax (expense) benefit |  |  | (419 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,203 |  |  |  |

[0001564590-18-027351:notes:157]
[same as prior period, unchanged from 0001564590-18-019154:notes:155]

[0001564590-18-027351:notes:158]
| (In thousands) |  | Three Months Ended September 30, 2017 |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | 1,066 |  |  | Net investment gain |
| Impairment expense |  |  | (57 | ) |  | Net investment gain |
| Net losses on derivatives designated as hedging instruments |  |  | (385 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (106 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 518 |  |  |  |
| Tax (expense) benefit |  |  | (244 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 274 |  |  |  |

[0001564590-18-027351:notes:159]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the nine months ended September 30, 2018 and 2017:

[0001564590-18-027351:notes:160]
| (In thousands) |  | Nine Months Ended September 30, 2018 |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | 1,352 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (151 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,201 |  |  |  |
| Tax (expense) benefit |  |  | (316 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 885 |  |  |  |

[0001564590-18-027351:notes:161]
| (In thousands) |  | Nine Months Ended September 30, 2017 |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | 3,031 |  |  | Net investment gain |
| Impairment expense |  |  | (162 | ) |  | Net investment gain |
| Net losses on derivatives designated as hedging instruments |  |  | (539 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (310 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 2,020 |  |  |  |
| Tax (expense) benefit |  |  | (907 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,113 |  |  |  |

[0001564590-18-027351:notes:162]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss) for the three months ended September 30, 2018 and 2017:

[0001564590-18-027351:notes:163]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 1,632 |  |  | $ | (424 | ) |  | $ | 1,208 |  |  | $ | 2,328 |  |  | $ | (908 | ) |  | $ | 1,420 |  |
| Unrealized gains (losses) on cash flow hedges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (184 | ) |  |  | 57 |  |  |  | (127 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (1,676 | ) |  |  | 436 |  |  |  | (1,240 | ) |  |  | (1,009 | ) |  |  | 393 |  |  |  | (616 | ) |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |  |  | (116 | ) |  |  | 269 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 54 |  |  |  | (17 | ) |  |  | 37 |  |  |  | 106 |  |  |  | (33 | ) |  |  | 73 |  |
| Foreign currency translation adjustment |  |  | (451 | ) |  |  | — |  |  |  | (451 | ) |  |  | 1,541 |  |  |  | — |  |  |  | 1,541 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (441 | ) |  | $ | (5 | ) |  | $ | (446 | ) |  | $ | 3,167 |  |  | $ | (607 | ) |  | $ | 2,560 |  |

[0001564590-18-027351:notes:164]
The following table presents the tax effects related to the change in each component of other comprehensive income for the nine months ended September 30, 2018 and 2017:

[0001564590-18-027351:notes:165]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 1,174 |  |  | $ | (305 | ) |  | $ | 869 |  |  | $ | 6,987 |  |  | $ | (2,725 | ) |  | $ | 4,262 |  |
| Unrealized gains (losses) on cash flow hedges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (897 | ) |  |  | 278 |  |  |  | (619 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (1,352 | ) |  |  | 363 |  |  |  | (989 | ) |  |  | (2,869 | ) |  |  | 1,119 |  |  |  | (1,750 | ) |
| Reclassification adjustment for amounts reclassed to retained earnings related to the adoption of ASU 2016-01 |  |  | (3,220 | ) |  |  | — |  |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 539 |  |  |  | (116 | ) |  |  | 423 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 151 |  |  |  | (47 | ) |  |  | 104 |  |  |  | 310 |  |  |  | (96 | ) |  |  | 214 |  |
| Foreign currency translation adjustment |  |  | (3,033 | ) |  |  | — |  |  |  | (3,033 | ) |  |  | 5,402 |  |  |  | — |  |  |  | 5,402 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (6,280 | ) |  | $ | 11 |  |  | $ | (6,269 | ) |  | $ | 9,472 |  |  | $ | (1,540 | ) |  | $ | 7,932 |  |


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-027351:notes:166]
[same as prior period, unchanged from 0001564590-18-019154:notes:163]

[0001564590-18-027351:notes:167]
A summary of the calculation of basic and diluted earnings per share for the three and nine months ended September 30, 2018 and 2017 is as follows:

[0001564590-18-027351:notes:168]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 7,589 |  |  | $ | 15,898 |  |  | $ | (10,895 | ) |  | $ | 34,950 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,710 |  |  |  | 47,870 |  |  |  | 47,927 |  |  |  | 48,110 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 27 |  |  |  | 487 |  |  |  | — |  |  |  | 385 |  |
| PSUs, RSUs and restricted stock |  |  | 97 |  |  |  | 174 |  |  |  | — |  |  |  | 123 |  |
| Weighted average number of shares – diluted |  |  | 47,834 |  |  |  | 48,531 |  |  |  | 47,927 |  |  |  | 48,618 |  |
| Net income (loss) per share – basic |  | $ | 0.16 |  |  | $ | 0.33 |  |  | $ | (0.23 | ) |  | $ | 0.73 |  |
| Net income (loss) per share – diluted |  | $ | 0.16 |  |  | $ | 0.33 |  |  | $ | (0.23 | ) |  | $ | 0.72 |  |

[0001564590-18-027351:notes:169]
Anti-dilutive options to purchase common stock outstanding were excluded from the above calculations. Anti-dilutive options totaled 3.9 million and 3.2 million for the three months ended September 30, 2018 and 2017, respectively, and 4.8 million and 3.9 million for the nine months ended September 30, 2018 and 2017.  As a result of the net loss for the nine months ended September 30, 2018, we excluded 0.1 million of unvested stock options, PSUs, RSUs and restricted stock from the calculation of diluted EPS due to their anti-dilutive effect.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-027351:notes:170]
[same as prior period, unchanged from 0001564590-18-019154:notes:167]

[0001564590-18-027351:notes:171]
[same as prior period, unchanged from 0001564590-18-019154:notes:168]

[0001564590-18-027351:notes:172]
We evaluate the performance of our segments based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain, other income (expense) and provision for taxes are reported on a company-wide, functional basis only. There are no inter-segment revenues.

[0001564590-18-027351:notes:173]
The following table presents information about the reported sales and gross profit of our reportable segments for the three and nine months ended September 30, 2018 and 2017. We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-18-027351:notes:174]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 121,043 |  |  | $ | 51,100 |  |  | $ | 145,467 |  |  | $ | 71,933 |  |
| Services & Support |  |  | 19,292 |  |  |  | 7,348 |  |  |  | 39,645 |  |  |  | 14,558 |  |
| Total |  | $ | 140,335 |  |  | $ | 58,448 |  |  | $ | 185,112 |  |  | $ | 86,491 |  |

[0001564590-18-027351:notes:175]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 341,359 |  |  | $ | 133,175 |  |  | $ | 444,607 |  |  | $ | 214,746 |  |
| Services & Support |  |  | 47,830 |  |  |  | 15,002 |  |  |  | 95,457 |  |  |  | 30,080 |  |
| Total |  | $ | 389,189 |  |  | $ | 148,177 |  |  | $ | 540,064 |  |  | $ | 244,826 |  |

[0001564590-18-027351:notes:176]
[same as prior period, unchanged from 0001564590-18-019154:notes:173]

[0001564590-18-027351:notes:177]
[same as prior period, unchanged from 0001564590-18-019154:notes:174]

[0001564590-18-027351:notes:178]
The table below presents sales information by category for the three and nine months ended September 30, 2018 and 2017:

[0001564590-18-027351:notes:179]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Access & Aggregation |  | $ | 91,901 |  |  | $ | 135,959 |  |  | $ | 258,323 |  |  | $ | 394,741 |  |
| Customer Devices |  |  | 38,552 |  |  |  | 35,582 |  |  |  | 103,213 |  |  |  | 105,683 |  |
| Traditional & Other Products |  |  | 9,882 |  |  |  | 13,571 |  |  |  | 27,653 |  |  |  | 39,640 |  |
| Total |  | $ | 140,335 |  |  | $ | 185,112 |  |  | $ | 389,189 |  |  | $ | 540,064 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-18-027351:notes:180]
[same as prior period, unchanged from 0001564590-18-019154:notes:177]

[0001564590-18-027351:notes:181]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $9.0 million and $9.7 million at September 30, 2018 and December 31, 2017. During the three months ended March 31, 2017, we recorded a receivable and a reduction in warranty expense related to a settlement with a third party supplier for a defective component, the impact of which is reflected in the table below.  During the three months ended September 30, 2018, we had a reversal of prior provisions, the impact of which is reflected in the table below. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0001564590-18-027351:notes:182]
A summary of warranty expense and write-off activity for the three and nine months ended September 30, 2018 and 2017 is as follows:

[0001564590-18-027351:notes:183]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 10,111 |  |  | $ | 9,180 |  |  | $ | 9,724 |  |  | $ | 8,548 |  |
| Plus: Amounts charged to cost and expenses |  |  | (34 | ) |  |  | 4,087 |  |  |  | 6,649 |  |  |  | 6,401 |  |
| Less: Deductions |  |  | (1,053 | ) |  |  | (2,328 | ) |  |  | (7,349 | ) |  |  | (4,010 | ) |
| Balance at end of period |  | $ | 9,024 |  |  | $ | 10,939 |  |  | $ | 9,024 |  |  | $ | 10,939 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-027351:notes:184]
15. COMMITMENTS AND CONTINGENCIES

[0001564590-18-027351:notes:185]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-18-027351:notes:186]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2018, of which $7.7 million has been applied to these commitments.


## us-gaap:SubsequentEventsTextBlock

[0001564590-18-027351:notes:187]
16. SUBSEQUENT EVENTS

[0001564590-18-027351:notes:188]
On October 16, 2018, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on October 31, 2018. The payment date will be November 14, 2018. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-18-027351:notes:189]
During the 4th quarter and as of November 6, 2018, we have repurchased 0.1 million shares of our common stock through open market purchases at an average cost of $13.60 per share.  We currently have the authority to purchase an additional 2.6 million shares of our common stock under the current plan approved by the Board of Directors.
