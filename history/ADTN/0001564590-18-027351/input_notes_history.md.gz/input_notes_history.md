# ADTN note change history — 0001564590-18-019154 → 0001564590-18-027351


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001564590-18-027351:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2018, of which $7.7 million has been applied to these commitments.
  (was, 2018-08-03, similarity 0.9726):
[0001564590-18-019154:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2018, of which $7.7 million has been applied to these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-11-06):
[0001564590-18-027351:note_history:2]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as, ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provides for an optional transition method that allows for the application of current legacy guidance, including its disclosure requirements, in the comparative periods presented in the year of adoption.  Otherwise, Topic 842 must be adopted by a modified retrospective method, with elective reliefs, which requires application of the new guidance for all periods presented.   The Company plans to use the optional transition method when adopting the new standard.  ASU 2016-02, ASU 2018-10 and ASU 2018-11 are effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. We anticipate the adoption of these ASUs will have a material increase in the assets and liabilities of our consolidated balance sheets; however, we do not believe adoption will have a material effect on our results of operations. We believe the most significant effect relates to our accounting for operating leases for office space.

- added (2018-11-06):
[0001564590-18-027351:note_history:3]
In March 2017, the FASB issued ASU 2017-08, Receivables – Nonrefundable Fees and Other Costs (Subtopic 310-20): Premium Amortization on Purchased Callable Debt Securities, which shortens the amortization period for the premium on certain purchased callable debt securities to the earliest call date.  ASU 2017-08 is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2018 with early adoption permitted.  The amendments should be applied through a modified-retrospective transition approach that requires a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  We are currently evaluating the effect of ASU 2017-08, but we do not expect it will have a material effect on our consolidated financial statements.

- added (2018-11-06):
[0001564590-18-027351:note_history:4]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820) Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project called, Concepts Statement No. 8 -  Conceptual Framework for Financial Reporting — Chapter 8, Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements.  ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements.  More specifically ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value.  In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows.  ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but we do not expect it will have a material effect on our financial statement disclosures.

- added (2018-11-06):
[0001564590-18-027351:note_history:5]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715.  ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (PBO) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (ABO) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but we do not expect it will have a material effect on our financial statement disclosures.

- added (2018-11-06):
[0001564590-18-027351:note_history:6]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40), Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement.  Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software.  ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted.  We are currently evaluating whether to early adopt, but we do not expect it will have a material effect on our consolidated financial statements.

- changed (2018-11-06):
[0001564590-18-027351:note_history:7]
| (In thousands) |  | Balance at December 31, 2017 |  |  | Adjustments due to ASU 2014-09 |  |  | Balance at January 1, 2018 |  |
| Other receivables |  | $ | 26,578 |  |  | $ | 374 |  |  | $ | 26,952 |  |
| Deferred tax assets, net |  | $ | 23,428 |  |  | $ | (96 | ) |  | $ | 23,332 |  |
| Retained earnings |  | $ | 922,178 |  |  | $ | 278 |  |  | $ | 922,456 |  |
  (was, 2018-08-03, similarity 0.9244):
[0001564590-18-019154:note_history:7]
| (In thousands) |  | Balance at December 31, 2017 |  |  | Adjustments due to ASU 2014-09 |  |  | Balance at January 1, 2018 |  |
| Other receivables |  | $ | 26,578 |  |  |  | 374 |  |  | $ | 26,952 |  |
| Deferred tax assets, net |  | $ | 23,428 |  |  |  | (96 | ) |  | $ | 23,332 |  |
| Retained earnings |  | $ | 922,178 |  |  |  | 278 |  |  | $ | 922,456 |  |

- added (2018-11-06):
[0001564590-18-027351:note_history:8]
|  |  | For the three months ended September 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 121,043 |  |  | $ | 120,588 |  |  | $ | 455 |  |
| Services |  | $ | 19,292 |  |  | $ | 17,932 |  |  | $ | 1,360 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 69,943 |  |  | $ | 69,754 |  |  | $ | 189 |  |
| Services |  | $ | 11,944 |  |  | $ | 11,046 |  |  | $ | 898 |  |
| Income before benefit for income taxes |  | $ | 3,220 |  |  | $ | 2,492 |  |  | $ | 728 |  |
| Benefit for income taxes |  | $ | 4,369 |  |  | $ | 3,382 |  |  | $ | 987 |  |
| Net income |  | $ | 7,589 |  |  | $ | 5,874 |  |  | $ | 1,715 |  |

- added (2018-11-06):
[0001564590-18-027351:note_history:9]
|  |  | For the nine months ended September 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 341,359 |  |  | $ | 341,464 |  |  | $ | (105 | ) |
| Services |  | $ | 47,830 |  |  | $ | 46,062 |  |  | $ | 1,768 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 208,184 |  |  | $ | 208,480 |  |  | $ | (296 | ) |
| Services |  | $ | 32,828 |  |  | $ | 31,743 |  |  | $ | 1,085 |  |
| Loss before benefit for income taxes |  | $ | (22,784 | ) |  | $ | (23,658 | ) |  | $ | 874 |  |
| Benefit for income taxes |  | $ | 11,889 |  |  | $ | 10,938 |  |  | $ | 951 |  |
| Net loss |  | $ | (10,895 | ) |  | $ | (12,720 | ) |  | $ | 1,825 |  |

- changed (2018-11-06):
[0001564590-18-027351:note_history:10]
|  |  | As of September 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other receivables |  | $ | 30,084 |  |  | $ | 27,917 |  |  | $ | 2,167 |  |
| Inventory |  | $ | 106,060 |  |  | $ | 106,402 |  |  | $ | (342 | ) |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 900,324 |  |  | $ | 898,499 |  |  | $ | 1,825 |  |
  (was, 2018-08-03, similarity 0.8251):
[0001564590-18-019154:note_history:10]
|  |  | As of June 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other receivables |  | $ | 28,163 |  |  |  | 28,164 |  |  | $ | (1 | ) |
| Inventory |  | $ | 120,537 |  |  |  | 120,426 |  |  | $ | 111 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 897,586 |  |  |  | 897,476 |  |  | $ | 110 |  |

- changed (2018-11-06):
[0001564590-18-027351:note_history:11]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. Subsequently, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, which issued technical corrections and improvements intended to clarify certain aspects of ASU 2016-01. ASU 2016-01 was effective beginning January 1, 2018 and we now recognize any changes in the fair value of certain equity investments in net income as prescribed by the new standard rather than in other comprehensive income. We adopted ASU 2016-01 on January 1, 2018 using the modified retrospective method, which resulted in a $3.2 million reclassification of net unrealized gains from accumulated other comprehensive income to opening retained earnings. ASU 2018-03 is effective for us with the interim period beginning after June 15, 2018. See Note 7 of Notes to Consolidated Financial Statements for additional information.
  (was, 2018-08-03, similarity 0.9231):
[0001564590-18-019154:note_history:11]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. Subsequently, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, which issued technical corrections and improvements intended to clarify certain aspects of ASU 2016-01. ASU 2016-01 was effective beginning January 1, 2018 and we now recognize any changes in the fair value of certain equity investments in net income as prescribed by the new standard rather than in other comprehensive income. We adopted ASU 2016-01 on January 1, 2018 using the modified retrospective method, which resulted in a $3.2 million reclassification of net unrealized gains from accumulated other comprehensive income to opening retained earnings. ASU 2018-03 is effective for us with the interim period beginning after June 15, 2018. We are currently evaluating the effect ASU 2018-03 will have on our consolidated financial statements.

- changed (2018-11-06):
[0001564590-18-027351:note_history:12]
In March 2017, the FASB issued ASU 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost. ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. We adopted ASU 2017-07 on January 1, 2018. We retrospectively adopted the presentation of service cost separate from other components of net periodic pension costs. As a result, $0.1 million and $0.3 million have been reclassified from cost of sales, selling, general and administrative expenses, and research and development expense to other income (expense), net for the three and nine months ended September 30, 2017, respectively.
  (was, 2018-08-03, similarity 0.9744):
[0001564590-18-019154:note_history:12]
In March 2017, the FASB issued ASU 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost. ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. We adopted ASU 2017-07 on January 1, 2018. We retrospectively adopted the presentation of service cost separate from other components of net periodic pension costs. As a result, $0.1 million and $0.2 million have been reclassified from cost of sales, selling, general and administrative expenses, and research and development expense to other expense, net for the three and six months ended June 30, 2017, respectively.

- removed (2018-11-06):
[0001564590-18-019154:note_history:13]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. Subsequently, in July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02. ASU 2016-02 and ASU 2018-10 are effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of these ASUs will have a material increase in the assets and liabilities of our consolidated balance sheets; however, we do not believe adoption will have a material effect on our results of operations. We believe the most significant effect relates to our accounting for operating leases for office space and equipment.

- removed (2018-11-06):
[0001564590-18-019154:note_history:14]
|  |  | For the three months ended June 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 115,063 |  |  |  | 115,437 |  |  | $ | (374 | ) |
| Services |  | $ | 12,985 |  |  |  | 13,430 |  |  | $ | (445 | ) |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 69,629 |  |  |  | 70,003 |  |  | $ | (374 | ) |
| Services |  | $ | 8,423 |  |  |  | 8,772 |  |  | $ | (349 | ) |
| Loss before benefit for income taxes |  | $ | (11,259 | ) |  |  | (11,163 | ) |  | $ | (96 | ) |
| Benefit for income taxes |  | $ | 3,589 |  |  |  | 3,558 |  |  | $ | 31 |  |
| Net loss |  | $ | (7,670 | ) |  |  | (7,605 | ) |  | $ | (65 | ) |

- removed (2018-11-06):
[0001564590-18-019154:note_history:15]
|  |  | For the six months ended June 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 220,316 |  |  |  | 220,876 |  |  | $ | (560 | ) |
| Services |  | $ | 28,538 |  |  |  | 28,130 |  |  | $ | 408 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 138,241 |  |  |  | 138,726 |  |  | $ | (485 | ) |
| Services |  | $ | 20,884 |  |  |  | 20,697 |  |  | $ | 187 |  |
| Loss before benefit for income taxes |  | $ | (26,004 | ) |  |  | (26,150 | ) |  | $ | 146 |  |
| Benefit for income taxes |  | $ | 7,520 |  |  |  | 7,556 |  |  | $ | (36 | ) |
| Net loss |  | $ | (18,484 | ) |  |  | (18,594 | ) |  | $ | 110 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001564590-18-027351:note_history:16]
At September 30, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:
  (was, 2018-08-03, similarity 0.9515):
[0001564590-18-019154:note_history:16]
At June 30, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:

- changed (2018-11-06):
[0001564590-18-027351:note_history:17]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 25,758 |  |  | $ | 13 |  |  | $ | (209 | ) |  | $ | 25,562 |  |
| Municipal fixed-rate bonds |  |  | 1,451 |  |  |  | — |  |  |  | (36 | ) |  |  | 1,415 |  |
| Asset-backed bonds |  |  | 8,384 |  |  |  | — |  |  |  | (29 | ) |  |  | 8,355 |  |
| Mortgage/Agency-backed bonds |  |  | 5,450 |  |  |  | — |  |  |  | (87 | ) |  |  | 5,363 |  |
| U.S. government bonds |  |  | 19,957 |  |  |  | — |  |  |  | (184 | ) |  |  | 19,773 |  |
| Foreign government bonds |  |  | 593 |  |  |  | 2 |  |  |  | — |  |  |  | 595 |  |
| Available-for-sale debt securities held at fair value |  | $ | 61,593 |  |  | $ | 15 |  |  | $ | (545 | ) |  | $ | 61,063 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 26,700 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 520 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 88,283 |  |
  (was, 2018-08-03, similarity 0.9989):
[0001564590-18-019154:note_history:17]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 35,896 |  |  | $ | 27 |  |  | $ | (250 | ) |  | $ | 35,673 |  |
| Municipal fixed-rate bonds |  |  | 2,259 |  |  |  | — |  |  |  | (38 | ) |  |  | 2,221 |  |
| Asset-backed bonds |  |  | 10,355 |  |  |  | 1 |  |  |  | (37 | ) |  |  | 10,319 |  |
| Mortgage/Agency-backed bonds |  |  | 7,292 |  |  |  | — |  |  |  | (85 | ) |  |  | 7,207 |  |
| U.S. government bonds |  |  | 8,953 |  |  |  | — |  |  |  | (104 | ) |  |  | 8,849 |  |
| Foreign government bonds |  |  | 1,036 |  |  |  | 2 |  |  |  | — |  |  |  | 1,038 |  |
| Available-for-sale debt securities held at fair value |  | $ | 65,791 |  |  | $ | 30 |  |  | $ | (514 | ) |  | $ | 65,307 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 26,700 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 520 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 92,527 |  |

- changed (2018-11-06):
[0001564590-18-027351:note_history:18]
As of September 30, 2018 our debt securities had the following contractual maturities:
  (was, 2018-08-03, similarity 0.9299):
[0001564590-18-019154:note_history:18]
As of June 30, 2018, our debt securities had the following contractual maturities:

- changed (2018-11-06):
[0001564590-18-027351:note_history:19]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 2,800 |  |  | $ | — |  |  | $ | 3,112 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 10,122 |  |  |  | 287 |  |  |  | 657 |  |  |  | — |  |  |  | 11,716 |  |  |  | 285 |  |
| Two to three years |  |  | 9,898 |  |  |  | 1,128 |  |  |  | 714 |  |  |  | 425 |  |  |  | 5,565 |  |  |  | 310 |  |
| Three to five years |  |  | 2,742 |  |  |  | — |  |  |  | 2,244 |  |  |  | 1,561 |  |  |  | 2,492 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 445 |  |  |  | 525 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,183 |  |  |  | 2,852 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 25,562 |  |  | $ | 1,415 |  |  | $ | 8,355 |  |  | $ | 5,363 |  |  | $ | 19,773 |  |  | $ | 595 |  |
  (was, 2018-08-03, similarity 0.9962):
[0001564590-18-019154:note_history:19]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 1,500 |  |  | $ | 490 |  |  | $ | 4,079 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 16,694 |  |  |  | 603 |  |  |  | 2,270 |  |  |  | — |  |  |  | 1,519 |  |  |  | 729 |  |
| Two to three years |  |  | 12,264 |  |  |  | 1,128 |  |  |  | 556 |  |  |  | — |  |  |  | 3,845 |  |  |  | 309 |  |
| Three to five years |  |  | 5,215 |  |  |  | — |  |  |  | 1,939 |  |  |  | 1,970 |  |  |  | 3,485 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 588 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,475 |  |  |  | 4,649 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,673 |  |  | $ | 2,221 |  |  | $ | 10,319 |  |  | $ | 7,207 |  |  | $ | 8,849 |  |  | $ | 1,038 |  |

- added (2018-11-06):
[0001564590-18-027351:note_history:20]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Gross realized gains on debt securities |  | $ | 24 |  |  | $ | 91 |  |  | $ | 49 |  |  | $ | 148 |  |
| Gross realized losses on debt securities |  |  | (50 | ) |  |  | (28 | ) |  |  | (365 | ) |  |  | (179 | ) |
| Total gain (loss) recognized, net |  | $ | (26 | ) |  | $ | 63 |  |  | $ | (316 | ) |  | $ | (31 | ) |

- changed (2018-11-06):
[0001564590-18-027351:note_history:21]
At September 30, 2018, we held a $26.7 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $26.7 million at September 30, 2018 and December 31, 2017. At September 30, 2018 and December 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $26.5 million and $26.7 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.
  (was, 2018-08-03, similarity 0.9665):
[0001564590-18-019154:note_history:21]
At June 30, 2018, we held a $26.7 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $26.7 million at June 30, 2018 and December 31, 2017. At June 30, 2018 and December 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $26.5 million and $26.7 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

- changed (2018-11-06):
[0001564590-18-027351:note_history:22]
Prior to January 1, 2018, our marketable equity securities were classified as available-for-sale. Realized gains and losses on marketable equity securities were included in net investment gain (loss). Unrealized gains and losses were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet.
  (was, 2018-08-03, similarity 0.9864):
[0001564590-18-019154:note_history:22]
Prior to January 1, 2018, our marketable equity securities were classified as available-for-sale. Realized gains and losses on marketable equity securities were included in net realized investment gain (loss). Unrealized gains and losses were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet.

- changed (2018-11-06):
[0001564590-18-027351:note_history:23]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to opening retained earnings.
  (was, 2018-08-03, similarity 0.99):
[0001564590-18-019154:note_history:23]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net realized investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to opening retained earnings.

- changed (2018-11-06):
[0001564590-18-027351:note_history:24]
Realized and unrealized gains and losses for our marketable equity securities for the three and nine months ended September 30, 2018 were as follows:
  (was, 2018-08-03, similarity 0.9433):
[0001564590-18-019154:note_history:24]
Realized and unrealized gains and losses for our marketable equity securities for the three and six months ended June 30, 2018 were as follows:

- changed (2018-11-06):
[0001564590-18-027351:note_history:25]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2018 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | 1,240 |  |  | $ | 1,587 |  |
| Unrealized gains (losses) on equity securities held |  |  | 3,293 |  |  |  | 4,129 |  |
| Total gain (loss) recognized, net |  | $ | 4,533 |  |  | $ | 5,716 |  |
  (was, 2018-08-03, similarity 0.9115):
[0001564590-18-019154:note_history:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (52 | ) |  | $ | 347 |  |
| Unrealized gains (losses) on equity securities held |  |  | 1,258 |  |  |  | 836 |  |
| Total gain (loss) recognized, net |  | $ | 1,206 |  |  | $ | 1,183 |  |

- changed (2018-11-06):
[0001564590-18-027351:note_history:26]
As of September 30, 2018 and 2017, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not significant.
  (was, 2018-08-03, similarity 0.943):
[0001564590-18-019154:note_history:26]
As of June 30, 2018 and 2017, gross unrealized losses related to individual investments in a continuous loss position for 12 months or longer were not significant.

- changed (2018-11-06):
[0001564590-18-027351:note_history:27]
|  |  | Fair Value Measurements at September 30, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,423 |  |  | $ | 1,423 |  |  | $ | — |  |  | $ | — |  |
| Foreign government securities |  |  | 600 |  |  |  | — |  |  |  | 600 |  |  |  | — |  |
| Cash equivalents |  |  | 2,023 |  |  |  | 1,423 |  |  |  | 600 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 25,562 |  |  |  | — |  |  |  | 25,562 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,415 |  |  |  | — |  |  |  | 1,415 |  |  |  | — |  |
| Asset-backed bonds |  |  | 8,355 |  |  |  | — |  |  |  | 8,355 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,363 |  |  |  | — |  |  |  | 5,363 |  |  |  | — |  |
| U.S. government bonds |  |  | 19,773 |  |  |  | 19,773 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 595 |  |  |  | — |  |  |  | 595 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Marketable equity securities – various industries |  |  | 40,645 |  |  |  | 40,645 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 277 |  |  |  | 277 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,948 |  |  |  | 20,948 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 122,933 |  |  |  | 81,643 |  |  |  | 41,290 |  |  |  | — |  |
| Total |  | $ | 124,956 |  |  | $ | 83,066 |  |  | $ | 41,890 |  |  | $ | — |  |
  (was, 2018-08-03, similarity 0.9727):
[0001564590-18-019154:note_history:27]
|  |  | Fair Value Measurements at June 30, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,008 |  |  | $ | 2,008 |  |  | $ | — |  |  | $ | — |  |
| Foreign government securities |  |  | 350 |  |  |  | — |  |  |  | 350 |  |  |  | — |  |
| Cash equivalents |  |  | 2,358 |  |  |  | 2,008 |  |  |  | 350 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 35,673 |  |  |  | — |  |  |  | 35,673 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,221 |  |  |  | — |  |  |  | 2,221 |  |  |  | — |  |
| Asset-backed bonds |  |  | 10,319 |  |  |  | — |  |  |  | 10,319 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 7,207 |  |  |  | — |  |  |  | 7,207 |  |  |  | — |  |
| U.S. government bonds |  |  | 8,849 |  |  |  | 8,849 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,038 |  |  |  | — |  |  |  | 1,038 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 37,600 |  |  |  | 37,600 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,379 |  |  |  | 20,379 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 123,286 |  |  |  | 66,828 |  |  |  | 56,458 |  |  |  | — |  |
| Total |  | $ | 125,644 |  |  | $ | 68,836 |  |  | $ | 56,808 |  |  | $ | — |  |

- removed (2018-11-06):
[0001564590-18-019154:note_history:28]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Gross realized gains |  | $ | 25 |  |  | $ | 33 |  |  | $ | 25 |  |  | $ | 57 |  |
| Gross realized losses |  | $ | (241 | ) |  | $ | (113 | ) |  | $ | (315 | ) |  | $ | (152 | ) |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001564590-18-027351:note_history:29]
The following table disaggregates our revenue by major source for the three months ended September 30, 2018:
  (was, 2018-08-03, similarity 0.9453):
[0001564590-18-019154:note_history:29]
The following table disaggregates our revenue by major source for the three months ended June 30, 2018:

- changed (2018-11-06):
[0001564590-18-027351:note_history:30]
The following table disaggregates our revenue by major source for the nine months ended September 30, 2018:
  (was, 2018-08-03, similarity 0.9192):
[0001564590-18-019154:note_history:30]
The following table disaggregates our revenue by major source for the six months ended June 30, 2018:


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001564590-18-027351:note_history:31]
The majority of the revenue from this segment is from hardware sales and is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.
  (was, 2018-08-03, similarity 0.965):
[0001564590-18-019154:note_history:31]
The majority of the revenue from this segment is from hardware sales and is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. Revenue is recorded net of estimated discounts and rebates using the most likely amount. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

- changed (2018-11-06):
[0001564590-18-027351:note_history:32]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term. In relation to these lease agreements, during the three months ended September 30, 2018 and 2017, we recognized revenue of $4.2 million and $8.4 million, respectively, and during the nine months ended September 30, 2018 and 2017 we recognized revenue of $10.5 million and $15.4 million, respectively.
  (was, 2018-08-03, similarity 0.9627):
[0001564590-18-019154:note_history:32]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term. In relation to these lease agreements, during the three months ended June 30, 2018 and 2017, we recognized revenue of $4.0 million and $5.2 million, respectively, and during the six months ended June 30, 2018 and 2017 we recognized revenue of $6.3 million and $7.0 million, respectively.

- changed (2018-11-06):
[0001564590-18-027351:note_history:33]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, and solutions integration and managed services, which include hosted cloud services and subscription services.
  (was, 2018-08-03, similarity 0.991):
[0001564590-18-019154:note_history:33]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

- changed (2018-11-06):
[0001564590-18-027351:note_history:34]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue as our customers benefit evenly throughout the contract term and deferred revenues are recorded in current and non-current unearned revenue.
  (was, 2018-08-03, similarity 0.7817):
[0001564590-18-019154:note_history:34]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. Payments received are recorded in current or non-current unearned revenue depending on the length of the service period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue as our customers benefit evenly throughout the contract term.

- changed (2018-11-06):
[0001564590-18-027351:note_history:35]
As of September 30, 2018, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.
  (was, 2018-08-03, similarity 0.9313):
[0001564590-18-019154:note_history:35]
As of June 30, 2018, we did not have any remaining performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

- changed (2018-11-06):
[0001564590-18-027351:note_history:36]
| (In thousands) |  | September 30, 2018 |  |  | January 1, 2018 |  |
| Accounts receivable |  | $ | 101,865 |  |  | $ | 144,150 |  |
| Contract assets |  | $ | 4,564 |  |  | $ | 374 |  |
| Unearned revenue |  | $ | 17,004 |  |  | $ | 13,070 |  |
| Non-current unearned revenue |  | $ | 3,846 |  |  | $ | 4,556 |  |
  (was, 2018-08-03, similarity 0.8033):
[0001564590-18-019154:note_history:36]
| (In thousands) |  | June 30, 2018 |  |  | January 1, 2018 |  |
| Accounts receivable |  | $ | 76,135 |  |  | $ | 144,150 |  |
| Contract assets |  |  | 1,672 |  |  |  | 374 |  |
| Unearned revenue |  |  | 14,307 |  |  |  | 13,070 |  |
| Non-current unearned revenue |  |  | 3,639 |  |  |  | 4,556 |  |

- added (2018-11-06):
[0001564590-18-027351:note_history:37]
The decrease in accounts receivable is due to the collection of customer specific payment terms that became due in the first quarter of 2018. The increase in the contract asset balance for the nine months ended September 30, 2018 is primarily attributable to revenue recognized that has not yet been billed to the customer during the period. The increase in the unearned revenue balance as of nine months ended September 30, 2018 is primarily attributable to cash payments received or due in advance of satisfying our performance obligations, offset by $8.9 million of revenues recognized that were included in the unearned revenue balance as of December 31, 2017.

- changed (2018-11-06):
[0001564590-18-027351:note_history:38]
The following table disaggregates our revenue by major source for the three months ended September 30, 2018:
  (was, 2018-08-03, similarity 0.9453):
[0001564590-18-019154:note_history:38]
The following table disaggregates our revenue by major source for the three months ended June 30, 2018:

- changed (2018-11-06):
[0001564590-18-027351:note_history:39]
The following table disaggregates our revenue by major source for the nine months ended September 30, 2018:
  (was, 2018-08-03, similarity 0.9192):
[0001564590-18-019154:note_history:39]
The following table disaggregates our revenue by major source for the six months ended June 30, 2018:

- removed (2018-11-06):
[0001564590-18-019154:note_history:40]
The decrease in accounts receivable is due to the collection of customer specific payment terms that became due in the first quarter of 2018. The increase in the contract asset balance for the six months ended June 30, 2018 is primarily attributable to revenue recognized that has not yet been billed to the customer during the period. The increase in the unearned revenue balance as of June 30, 2018 is primarily attributable to cash payments received or due in advance of satisfying our performance obligations, offset by $7.1 million of revenues recognized that were included in the unearned revenue balance as of December 31, 2017.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-11-06):
[0001564590-18-027351:note_history:41]
On October 16, 2018, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on October 31, 2018. The payment date will be November 14, 2018. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

- added (2018-11-06):
[0001564590-18-027351:note_history:42]
During the 4th quarter and as of November 6, 2018, we have repurchased 0.1 million shares of our common stock through open market purchases at an average cost of $13.60 per share.  We currently have the authority to purchase an additional 2.6 million shares of our common stock under the current plan approved by the Board of Directors.

- removed (2018-11-06):
[0001564590-18-019154:note_history:43]
On July 17, 2018, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on August 1, 2018. The payment date will be August 15, 2018. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
