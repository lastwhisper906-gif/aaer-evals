# ADTN MD&A — 0001564590-16-022906


## mdna

[0001564590-16-022906:mdna:1]
ITEM 2. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001564590-16-022906:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and the related notes that appear elsewhere in this document.

[0001564590-16-022906:mdna:3]
[same as prior period, unchanged from 0001193125-16-576994:mdna:3]

[0001564590-16-022906:mdna:4]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications across a variety of network infrastructures. These solutions are deployed by many of the United States’ and the world’s largest service providers, distributed enterprises and small and medium-sized businesses, public and private enterprises, and millions of individual users worldwide.

[0001564590-16-022906:mdna:5]
Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek in most instances to be a high-quality, low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001564590-16-022906:mdna:6]
We report revenue for the following three categories – Access & Aggregation, Customer Devices, and Traditional & Other Products.

[0001564590-16-022906:mdna:7]
Access & Aggregation generally includes software and hardware based products and services that communication service providers (CSPs) use to aggregate and/or originate network access technologies. The portfolio of ADTRAN solutions within this category includes a wide array of modular or fixed physical form factors designed to deliver the best technology and economic fit for our customers based on the target subscriber density and environmental conditions.

[0001564590-16-022906:mdna:8]
The Access & Aggregation category includes product and service families such as:

[0001564590-16-022906:mdna:9]
|  | · | Total Access® 5000 Series Fiber to the Premises (FTTP) and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001564590-16-022906:mdna:10]
|  | · | hiX 5600 Series fiber aggregation and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001564590-16-022906:mdna:11]
|  | · | Fiber to the Distribution Point (FTTdp) Optical Network Units (ONU) |

[0001564590-16-022906:mdna:12]
|  | · | Optical Line Terminals (OLT) |

[0001564590-16-022906:mdna:13]
|  | · | Optical Networking Edge (ONE) aggregation |

[0001564590-16-022906:mdna:14]
|  | · | Distribution Point Units (DPUs) |

[0001564590-16-022906:mdna:15]
|  | · | IP Digital Subscriber Line Access Multiplexers (DSLAMs) |

[0001564590-16-022906:mdna:16]
|  | · | Cabinet and Outside-Plant (OSP) enclosures and services |

[0001564590-16-022906:mdna:17]
|  | · | Network Management and Cloud based software platforms and applications |

[0001564590-16-022906:mdna:18]
|  | · | Pluggable optical transceivers (i.e., SFP, SFP+, XFP, QSFP), cables and other miscellaneous materials |

[0001564590-16-022906:mdna:19]
|  | · | Other products and services that are generally applicable to Access & Aggregation |

[0001564590-16-022906:mdna:20]
Customer Devices generally includes the products and services that provide end users access to the CSP network.  The Customer Devices portfolio includes a comprehensive array of service provider and enterprise hardware and software products and services.

[0001564590-16-022906:mdna:21]
[same as prior period, unchanged from 0001193125-16-576994:mdna:21]

[0001564590-16-022906:mdna:22]
|  | · | Broadband customer premise solutions, including Passive Optical Network (PON) and point-to-point Ethernet Optical Network Terminals (ONTs) |

[0001564590-16-022906:mdna:23]
|  | · | Residential and business gateways |

[0001564590-16-022906:mdna:24]
|  | · | Wi-Fi access points and associated powering and switching infrastructure |

[0001564590-16-022906:mdna:25]
|  | · | enterprise Session Border Controllers (eSBC) |

[0001564590-16-022906:mdna:26]
|  | · | Branch office and access routers |

[0001564590-16-022906:mdna:27]
|  | · | Carrier Ethernet services termination devices |

[0001564590-16-022906:mdna:28]
|  | · | VoIP media gateways |

[0001564590-16-022906:mdna:29]
|  | · | ProServices |

[0001564590-16-022906:mdna:30]
|  | · | Planning, engineering, program management, maintenance, installation and commissioning services to implement the customer devices solutions into consumer, small business and enterprise locations |

[0001564590-16-022906:mdna:31]
|  | · | Other products and services that are generally applicable to customer devices |

[0001564590-16-022906:mdna:32]
Traditional & Other Products generally includes a mix of prior generation technologies’ products and services, as well as other products and services that do not fit within the Access & Aggregation or Customer Devices categories.

[0001564590-16-022906:mdna:33]
The Traditional & Other Products category includes products and services such as:

[0001564590-16-022906:mdna:34]
|  | · | Time Division Multiplexed (TDM) and Asynchronous Transfer Mode (ATM) based aggregation systems and customer devices |

[0001564590-16-022906:mdna:35]
|  | · | HDSL, ADSL and other mature technologies used to deliver business and residential services over the CSP access and customer networks |

[0001564590-16-022906:mdna:36]
|  | · | Other products and services that do not fit within the Access & Aggregation and Customer Devices categories |

[0001564590-16-022906:mdna:37]
[same as prior period, unchanged from 0001193125-16-576994:mdna:37]

[0001564590-16-022906:mdna:38]
Sales were $162.7 million and $304.9 million for the three and six months ended June 30, 2016 compared to $160.1 million and $303.0 million for the three and six months ended June 30, 2015. Our gross margin increased to 48.5% and 47.5% for the three and six months ended June 30, 2016 from 42.6% and 44.2% for the three and six months ended June 30, 2015. Our operating income margin increased to 9.1% and 6.7% for the three and six months ended June 30, 2016 from 0.4% and 0.9% for the three and six months ended June 30, 2015. Net income was $10.2 million and $15.2 million for the three and six months ended June 30, 2016 compared to $2.5 million and $5.9 million for the three and six months ended June 30, 2015. Our effective tax rate decreased to 37.8% and 37.9% for the three and six months ended June 30, 2016 from 38.1% and 39.1% for the three and six months ended June 30, 2015.  Earnings per share, assuming dilution, were $0.21 and $0.31 for the three and six months ended June 30, 2016 compared to $0.05 and $0.11 for the three and six months ended June 30, 2015.

[0001564590-16-022906:mdna:39]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future periods due to a number of factors, including customer order activity and backlog. Backlog levels vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001564590-16-022906:mdna:40]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter.

[0001564590-16-022906:mdna:41]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. A list of factors that could materially affect our business, financial condition or operating results is included under “Factors That Could Affect Our Future Results” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this report. These factors have also been discussed in more detail in Item 1A of Part I in our most recent Annual Report on Form 10-K for the year ended December 31, 2015, filed on February 24, 2016 with the SEC.

[0001564590-16-022906:mdna:42]
[same as prior period, unchanged from 0001193125-16-576994:mdna:42]

[0001564590-16-022906:mdna:43]
Our critical accounting policies and estimates have not changed significantly from those detailed in our most recent Annual Report on Form 10-K for the year ended December 31, 2015, filed on February 24, 2016 with the SEC.

[0001564590-16-022906:mdna:44]
[same as prior period, unchanged from 0001193125-16-576994:mdna:44]

[0001564590-16-022906:mdna:45]
See Note 1 of Notes to Consolidated Financial Statements in Item 1 of this Form 10-Q for a full description of recent accounting pronouncements, including the expected dates of adoption and estimated effects on results of operations and financial condition, which is incorporated herein by reference.

[0001564590-16-022906:mdna:46]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2016 COMPARED TO THREE AND SIX MONTHS ENDED JUNE 30, 2015

[0001564590-16-022906:mdna:47]
[same as prior period, unchanged from 0001193125-16-576994:mdna:47]

[0001564590-16-022906:mdna:48]
Our sales increased 1.6% from $160.1 million in the three months ended June 30, 2015 to $162.7 million in the three months ended June 30, 2016, and increased 0.6% from $303.0 million in the six months ended June 30, 2015 to $304.9 million in the six months ended June 30, 2016. The increase in sales for the three months ended June 30, 2016 is primarily attributable to a $10.8 million increase in sales of our Customer Devices products, a $2.2 million increase in sales of our Traditional & Other products, partially offset by a $10.5 million decrease in sales of our Access & Aggregation products. The increase in sales for the six months ended June 30, 2016 is primarily attributable to a $11.5 million increase in sales of our Customer Devices products, partially offset by a $9.5 million decrease in sales of our Access & Aggregation products.

[0001564590-16-022906:mdna:49]
Network Solutions sales decreased 3.9% from $144.1 million in the three months ended June 30, 2015 to $138.5 million in the three months ended June 30, 2016, and decreased 4.1% from $273.6 million in the six months ended June 30, 2015 to $262.4 million in the six months ended June 30, 2016. The decrease in sales for the three and six months ended June 30, 2016 is primarily attributable to a decrease in sales of Access and Aggregation products, partially offset by an increase in Customer Devices products. The decrease in sales of our Access and Aggregation products is primarily attributable to a decrease in international hiX product sales, partially offset by an increase in U.S. Total Access 5000 product sales. The increase in sales of our Customer Devices products is primarily attributable to increased sales of our FTTP ONT products and Ethernet products.

[0001564590-16-022906:mdna:50]
Services & Support sales increased 50.6% from $16.0 million in the three months ended June 30, 2015 to $24.2 million in the three months ended June 30, 2016, and increased 44.6% from $29.4 million in the six months ended June 30, 2015 to $42.5 million in the six months ended June 30, 2016. The increase in sales for the three and six months ended June 30, 2016 is primarily attributable to an increase in network installation services for access and aggregation products.

[0001564590-16-022906:mdna:51]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, decreased 47.8% from $55.7 million in the three months ended June 30, 2015 to $29.1 million in the three months ended June 30, 2016, and decreased 52.3% from $115.1 million in the six months ended June 30, 2015 to $54.9 million in the six months ended June 30, 2016. International sales, as a percentage of total sales, decreased from 34.8% and 38.0% for the three and six months ended June 30, 2015 to 17.9% and 18.0% for the three and six months ended June 30, 2016. The decrease in international sales for the three and six months ended June 30, 2016 is primarily attributable to the return to more seasonally normal buying patterns in Europe and also, relating to the decrease in international sales as a percentage of revenue, growing momentum in the U.S. broadband market.

[0001564590-16-022906:mdna:52]
[same as prior period, unchanged from 0001193125-16-576994:mdna:52]

[0001564590-16-022906:mdna:53]
As a percentage of sales, cost of sales decreased from 57.4% in the three months ended June 30, 2015 to 51.5% in the three months ended June 30, 2016, and decreased from 55.8% in the six months ended June 30, 2015 to 52.5% in the six months ended June 30, 2016. The decrease in cost of sales for the three and six months ended June 30, 2016 is primarily attributable to a regional revenue shift and a change in product and services mix.

[0001564590-16-022906:mdna:54]
Network Solutions cost of sales, as a percent of that segment’s sales, decreased from 58.4% in the three months ended June 30, 2015 to 49.0% in the three months ended June 30, 2016, and decreased from 56.9% in the six months ended June 30, 2015 to 50.3% in the six months ended June 30, 2016. The decrease in cost of sales for the three and six months ended June 30, 2016 is primarily attributable to a regional revenue shift and customer and product mix.

[0001564590-16-022906:mdna:55]
Services & Support cost of sales, as a percent of that segment’s sales, increased from 47.9% in the three months ended June 30, 2015 to 65.8% in the three months ended June 30, 2016, and increased from 45.6% in the six months ended June 30, 2015 to 66.5% in the six months ended June 30, 2016. The increase in cost of sales for the three and six months ended June 30, 2016 is primarily attributable to an increase in network installation services, which have higher costs, versus a greater mix of maintenance and support services in the prior periods.

[0001564590-16-022906:mdna:56]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-16-022906:mdna:57]
[same as prior period, unchanged from 0001193125-16-576994:mdna:57]

[0001564590-16-022906:mdna:58]
Selling, general and administrative expenses increased 2.3% from $32.1 million in the three months ended June 30, 2015 to $32.9 million in the three months ended June 30, 2016, and increased 0.7% from $63.2 million in the six months ended June 30, 2015 to $63.7 million in the six months ended June 30, 2016. The increase in selling, general and administrative expenses for the three and six months ended June 30, 2016 is primarily attributable to an increase in compensation expense, partially offset by a decrease in professional services.

[0001564590-16-022906:mdna:59]
As a percentage of sales, selling, general and administrative expenses increased from 20.1% in the three months ended June 30, 2015 to 20.2% in the three months ended June 30, 2016, and was consistent at 20.9% in the six months ended June 30, 2015 and 2016. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-16-022906:mdna:60]
[same as prior period, unchanged from 0001193125-16-576994:mdna:60]

[0001564590-16-022906:mdna:61]
Research and development expenses decreased 11.8% from $35.5 million in the three months ended June 30, 2015 to $31.3 million in the three months ended June 30, 2016, and decreased 10.7% from $68.0 million in the six months ended June 30, 2015 to $60.8 million in the six months ended June 30, 2016. The decrease in research and development expenses for the three months ended June 30, 2016 is primarily attributable to a decrease in compensation expense and testing expense. The decrease in research and development expenses for the six months ended June 30, 2016 is primarily attributable to a decrease in compensation expense and testing expense, partially offset by an increase in contract services. The decrease is compensation expense for the three and six months ended June 30, 2016 was primary attributable to the consolidation of engineering resources that occurred in the second quarter of 2015.

[0001564590-16-022906:mdna:62]
As a percentage of sales, research and development expenses decreased from 22.2% in the three months ended June 30, 2015 to 19.2% in the three months ended June 30, 2016, and decreased from 22.4% in the six months ended June 30, 2015 to 19.9% in the six months ended June 30, 2016. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001564590-16-022906:mdna:63]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001564590-16-022906:mdna:64]
[same as prior period, unchanged from 0001193125-16-576994:mdna:64]

[0001564590-16-022906:mdna:65]
Interest and dividend income increased 2.1%, or $19 thousand from the three months ended June 30, 2015 to the three months ended June 30, 2016, and decreased 3.2%, or $0.1 million from the six months ended June 30, 2015 to the six months ended June 30, 2016. The increase in interest and dividend income for the three months ended June 30, 2016, is primarily attributable to an increase in interest rates. The decrease in interest and dividend income for the six months ended June 30, 2016 is primarily attributable to a reduction in investment principal, partially offset by a small increase in interest rates.

[0001564590-16-022906:mdna:66]
[same as prior period, unchanged from 0001193125-16-576994:mdna:66]

[0001564590-16-022906:mdna:67]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended June 30, 2015 and 2016, and $0.3 million in the six months ended June 30, 2015 and 2016, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-16-022906:mdna:68]
[same as prior period, unchanged from 0001193125-16-576994:mdna:68]

[0001564590-16-022906:mdna:69]
Net realized investment gains decreased 65.9% from $3.3 million in the three months ended June 30, 2015 to $1.1 million in the three months ended June 30, 2016, and decreased 55.4% from $6.4 million in the six months ended June 30, 2015 to $2.8 million in the six months ended June 30, 2016. The decrease in realized investment gains for the three and six months ended June 30, 2016 is primarily attributable to decreased gains from the sale of equity securities. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-16-022906:mdna:70]
[same as prior period, unchanged from 0001193125-16-576994:mdna:70]

[0001564590-16-022906:mdna:71]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, and scrap raw material sales, changed from $0.5 million of expense in the three months ended June 30, 2015 to $0.3 million of expense in the three months ended June 30, 2016, and changed from $0.9 million of expense in the six months ended June 30, 2015 to $0.1 million of expense in the six months ended June 30, 2016. The change for the three and six months ended June 30, 2016 is primarily attributable to reduced losses on foreign currency transactions.

[0001564590-16-022906:mdna:72]
[same as prior period, unchanged from 0001193125-16-576994:mdna:72]

[0001564590-16-022906:mdna:73]
Our effective tax rate decreased from 39.1% in the six months ended June 30, 2015 to 37.9% in the six months ended June 30, 2016. The decrease in the effective tax rate between the two periods is primarily attributable to the research and development tax credit being made permanent.

[0001564590-16-022906:mdna:74]
NET INCOME

[0001564590-16-022906:mdna:75]
As a result of the above factors, net income increased $7.7 million from $2.5 million in the three months ended June 30, 2015 to $10.2 million in the three months ended June 30, 2016, and increased $9.4 million from $5.9 million in the six months ended June 30, 2015 to $15.2 million in the six months ended June 30, 2016.

[0001564590-16-022906:mdna:76]
As a percentage of sales, net income increased from 1.6% in the three months ended June 30, 2015 to 6.3% in the three months ended June 30, 2016, and increased from 1.9% in the six months ended June 30, 2015 to 5.0% in the six months ended June 30, 2016.

[0001564590-16-022906:mdna:77]
[same as prior period, unchanged from 0001193125-16-576994:mdna:77]

[0001564590-16-022906:mdna:78]
[same as prior period, unchanged from 0001193125-16-576994:mdna:78]

[0001564590-16-022906:mdna:79]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-16-022906:mdna:80]
At June 30, 2016, cash on hand was $70.9 million and short-term investments were $50.9 million, which resulted in available short-term liquidity of $121.8 million, of which $34.2 million was held by our foreign subsidiaries. At December 31, 2015, cash on hand was $84.6 million and short-term investments were $34.4 million, which resulted in available short-term liquidity of $118.9 million, of which $38.9 million was held by our foreign subsidiaries. The increase in short-term liquidity from December 31, 2015 to June 30, 2016 is primarily attributable to shifts among available investment option tenures to provide funds for our short-term cash needs.

[0001564590-16-022906:mdna:81]
[same as prior period, unchanged from 0001193125-16-576994:mdna:81]

[0001564590-16-022906:mdna:82]
Our working capital, which consists of current assets less current liabilities, increased 1.3% from $238.1 million as of December 31, 2015 to $241.2 million as of June 30, 2016. The increase in our working capital is primarily attributable to an increase in accounts receivable, partially offset by a decrease in other receivables and inventory, and an increase in accounts payable. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, remained consistent at 2.06 as of December 31, 2015 and 2.05 as of June 30, 2016. The current ratio, defined as current assets divided by current liabilities, decreased from 3.57 as of December 31, 2015 to 3.34 as of June 30, 2016. The decrease in the current ratio is primarily attributable to an increase in accounts payable, accrued wages and benefits, and a decrease in inventory, partially offset by an increase in accounts receivable.

[0001564590-16-022906:mdna:83]
Net accounts receivable increased 24.3% from $71.9 million at December 31, 2015 to $89.4 million at June 30, 2016. Our allowance for doubtful accounts was $19 thousand at December 31, 2015 and June 30, 2016. Quarterly accounts receivable days sales outstanding (DSO) increased from 48 days as of December 31, 2015 to 50 days as of June 30, 2016. The change in net accounts receivable is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than U.S. customers. Other receivables decreased from $19.3 million at December 31, 2015 to $11.7 million at June 30, 2016. The decrease in other receivables is primarily attributable to the timing of filing returns and collections of VAT receivables in our international subsidiaries. Other receivables will also fluctuate due to the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001564590-16-022906:mdna:84]
Quarterly inventory turnover increased from 3.3 turns as of December 31, 2015 to 3.7 turns at June 30, 2016. Inventory decreased 5.0% from December 31, 2015 to June 30, 2016. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-16-022906:mdna:85]
Accounts payable increased 21.7% from $48.7 million at December 31, 2015 to $59.2 million at June 30, 2016. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-16-022906:mdna:86]
[same as prior period, unchanged from 0001193125-16-576994:mdna:86]

[0001564590-16-022906:mdna:87]
Capital expenditures totaled approximately $6.7 million and $5.4 million for the six months ended June 30, 2016 and 2015, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-16-022906:mdna:88]
Our combined short-term and long-term investments increased $4.7 million from $232.4 million at December 31, 2015 to $237.1 million at June 30, 2016. This increase reflects the impact of our cash needs for capital expenditures, purchases of treasury stock, and shareholder dividends, as well as net realized and unrealized losses and amortization of net premiums on our combined investments, partially offset by additional funds available for investment provided by our operating activities and stock option exercises by our employees.

[0001564590-16-022906:mdna:89]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At June 30, 2016 these investments included corporate bonds of $54.1 million, municipal fixed-rate bonds of $16.9 million, asset-backed bonds of $23.6 million, mortgage/agency-backed bonds of $19.2 million, U.S. government bonds of $33.8 million, and variable rate demand notes of $11.7 million. At December 31, 2015, these investments included corporate bonds of $57.6 million, municipal fixed-rate bonds of $26.4 million, asset-backed bonds of $19.2 million, mortgage/agency-backed bonds of $15.4 million, and U.S. government bonds of $35.4 million. As of June 30, 2016, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and variable rate demand notes were classified as available-for-sale and had a combined duration of 0.96 years with an average Standard & Poor’s credit rating of AA-. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-16-022906:mdna:90]
Our long-term investments decreased 5.9% from $198.0 million at December 31, 2015 to $186.2 million at June 30, 2016. Long-term investments at June 30, 2016 and December 31, 2015 included an investment in a certificate of deposit of $30.0 million, which serves as collateral for our revenue bond. See “Debt” below for additional information. We have various equity investments included in long-term investments at a cost of $32.9 million and $31.6 million, and with a fair value of $33.4 million and $34.3 million, at June 30, 2016 and December 31, 2015, respectively.

[0001564590-16-022906:mdna:91]
Long-term investments at June 30, 2016 and December 31, 2015 also included $13.1 million and $12.8 million, respectively, related to our deferred compensation plans, and $1.2 million and $1.3 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001564590-16-022906:mdna:92]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and six months ended June 30, 2016 and 2015, other-than-temporary impairment charges were not significant.

[0001564590-16-022906:mdna:93]
[same as prior period, unchanged from 0001193125-16-576994:mdna:93]

[0001564590-16-022906:mdna:94]
[same as prior period, unchanged from 0001193125-16-576994:mdna:94]

[0001564590-16-022906:mdna:95]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the six months ended June 30, 2016, we paid dividends totaling $8.9 million.

[0001564590-16-022906:mdna:96]
[same as prior period, unchanged from 0001193125-16-576994:mdna:96]

[0001564590-16-022906:mdna:97]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $28.9 million at June 30, 2016 and December 31, 2015. At June 30, 2016, the estimated fair value of the Bond was approximately $29.4 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $30.0 million at June 30, 2016 and December 31, 2015, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.0 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at June 30, 2016.

[0001564590-16-022906:mdna:98]
[same as prior period, unchanged from 0001193125-16-576994:mdna:98]

[0001564590-16-022906:mdna:99]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2016, we repurchased 0.9 million shares of our common stock at an average price of $18.48 per share. As of June 30, 2016, we have the authority to purchase an additional 4.9 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-16-022906:mdna:100]
[same as prior period, unchanged from 0001193125-16-576994:mdna:100]

[0001564590-16-022906:mdna:101]
We issued 33 thousand shares of treasury stock during the six months ended June 30, 2016 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $0.5 million from the exercise of these stock options during the six months ended June 30, 2016.

[0001564590-16-022906:mdna:102]
[same as prior period, unchanged from 0001193125-16-576994:mdna:102]

[0001564590-16-022906:mdna:103]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the six months ended June 30, 2016, there have been no material changes in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2015 filed on February 24, 2016 with the SEC.

[0001564590-16-022906:mdna:104]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2016, of which $7.7 million has been applied to these commitments.

[0001564590-16-022906:mdna:105]
33
