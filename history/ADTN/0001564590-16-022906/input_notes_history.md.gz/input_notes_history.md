# ADTN note change history — 0001193125-16-576994 → 0001564590-16-022906


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0001564590-16-022906:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2016, of which $7.7 million has been applied to these commitments.
  (was, 2016-05-04, similarity 0.9773):
[0001193125-16-576994:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of March 31, 2016, of which $7.7 million has been applied to
 these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-08-05):
[0001564590-16-022906:note_history:2]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; and ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018, and we are currently evaluating the transition method that will be elected and the impact that the adoption of ASU 2014-09 will have on our financial position, results of operations and cash flows.

- changed (2016-08-05):
[0001564590-16-022906:note_history:3]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years, with early adoption permitted. A modified retrospective approach is required. We are currently evaluating the impact that the adoption of ASU 2016-02 will have on our financial position, results of operations and cash flows.
  (was, 2016-05-04, similarity 0.9983):
[0001193125-16-576994:note_history:3]
In February 2016, the FASB issued Accounting Standards Update
 No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU
 2016-02 requires an entity to recognize lease assets and lease
 liabilities on the balance sheet and to disclose key information
 about the entity’s leasing arrangements. ASU 2016-02 is
 effective for fiscal years beginning after December 15, 2018,
 and interim periods within those fiscal years, with early adoption
 permitted. A modified retrospective approach is required. We are
 currently evaluating the impact that the adoption of ASU 2016-02
 will have on our financial position, results of operations and cash
 flows.

- removed (2016-08-05):
[0001193125-16-576994:note_history:4]
Out of Period Adjustment

- removed (2016-08-05):
[0001193125-16-576994:note_history:5]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter of 2015. The aggregate
 impact of the corrections was a $0.8 million reduction to pre-tax
 income for the three months ended March 31, 2015 and was not
 material to the prior year quarterly or annual results.

- removed (2016-08-05):
[0001193125-16-576994:note_history:6]
In May 2014, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update No. 2014-09, Revenue from
 Contracts with Customers (ASU 2014-09), which supersedes the
 revenue recognition requirements in Topic 605, Revenue
 Recognition, including most industry-specific revenue
 recognition guidance throughout the Industry Topics of the
 Codification. The core principle of ASU 2014-09 is to recognize
 revenues when promised goods or services are transferred to
 customers in an amount that reflects the consideration that is
 expected to be received for those goods or services. In August
 2015, the FASB issued ASU 2015-14, which deferred the effective
 date of ASU 2014-09 to fiscal years beginning after
 December 31, 2017, and interim periods within those fiscal
 years. ASU 2014-09 allows for either full retrospective or modified
 retrospective adoption. We are currently evaluating the transition
 method that will be elected and the impact that the adoption of ASU
 2014-09 will have on our financial position, results of operations
 and cash flows.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-05):
[0001564590-16-022906:note_history:7]
At June 30, 2016, we held the following securities and investments, recorded at either fair value or cost.
  (was, 2016-05-04, similarity 0.9552):
[0001193125-16-576994:note_history:7]
At March 31, 2016, we held the following securities and
 investments, recorded at either fair value or cost.

- changed (2016-08-05):
[0001564590-16-022906:note_history:8]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,516 |  |  | $ | 1,628 |  |  | $ | (49 | ) |  | $ | 13,095 |  |
| Corporate bonds |  |  | 54,044 |  |  |  | 149 |  |  |  | (61 | ) |  |  | 54,132 |  |
| Municipal fixed-rate bonds |  |  | 16,889 |  |  |  | 59 |  |  |  | - |  |  |  | 16,948 |  |
| Asset-backed bonds |  |  | 23,526 |  |  |  | 53 |  |  |  | (6 | ) |  |  | 23,573 |  |
| Mortgage/Agency-backed bonds |  |  | 19,214 |  |  |  | 44 |  |  |  | (39 | ) |  |  | 19,219 |  |
| U.S. Government bonds |  |  | 33,498 |  |  |  | 308 |  |  |  | - |  |  |  | 33,806 |  |
| Variable rate demand notes |  |  | 11,740 |  |  |  | - |  |  |  | - |  |  |  | 11,740 |  |
| Marketable equity securities |  |  | 32,948 |  |  |  | 1,901 |  |  |  | (1,478 | ) |  |  | 33,371 |  |
| Available-for-sale securities held at fair value |  | $ | 203,375 |  |  | $ | 4,142 |  |  | $ | (1,633 | ) |  | $ | 205,884 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,232 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 237,116 |  |
  (was, 2016-05-04, similarity 0.9466):
[0001193125-16-576994:note_history:8]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 11,440 |  |  | $ | 1,634 |  |  | $ | (70 | ) |  | $ | 13,004 |  |
| Corporate bonds |  |  | 61,154 |  |  |  | 89 |  |  |  | (386 | ) |  |  | 60,857 |  |
| Municipal fixed-rate bonds |  |  | 15,659 |  |  |  | 54 |  |  |  | (1 | ) |  |  | 15,712 |  |
| Asset-backed bonds |  |  | 20,540 |  |  |  | 28 |  |  |  | (8 | ) |  |  | 20,560 |  |
| Mortgage/Agency-backed bonds |  |  | 14,959 |  |  |  | 19 |  |  |  | (82 | ) |  |  | 14,896 |  |
| Government bonds |  |  | 33,205 |  |  |  | 216 |  |  |  | (2 | ) |  |  | 33,419 |  |
| Variable Rate Demand Notes |  |  | 2,235 |  |  |  | — |  |  |  | — |  |  |  | 2,235 |  |
| Marketable equity securities |  |  | 31,798 |  |  |  | 2,886 |  |  |  | (1,647 | ) |  |  | 33,037 |  |
| Available-for-sale securities held at fair value |  | $ | 190,990 |  |  | $ | 4,926 |  |  | $ | (2,196 | ) |  | $ | 193,720 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,266 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 224,986 |  |

- changed (2016-08-05):
[0001564590-16-022906:note_history:9]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,325 |  |  | $ | 1,575 |  |  | $ | (66 | ) |  | $ | 12,834 |  |
| Corporate bonds |  |  | 58,328 |  |  |  | 20 |  |  |  | (734 | ) |  |  | 57,614 |  |
| Municipal fixed-rate bonds |  |  | 26,414 |  |  |  | 28 |  |  |  | (18 | ) |  |  | 26,424 |  |
| Asset-backed bonds |  |  | 19,281 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 19,239 |  |
| Mortgage/Agency-backed bonds |  |  | 15,463 |  |  |  | 1 |  |  |  | (91 | ) |  |  | 15,373 |  |
| U.S. Government bonds |  |  | 35,646 |  |  |  | - |  |  |  | (248 | ) |  |  | 35,398 |  |
| Marketable equity securities |  |  | 31,643 |  |  |  | 4,301 |  |  |  | (1,693 | ) |  |  | 34,251 |  |
| Available-for-sale securities held at fair value |  | $ | 198,100 |  |  | $ | 5,927 |  |  | $ | (2,894 | ) |  | $ | 201,133 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,289 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 232,422 |  |
  (was, 2016-05-04, similarity 0.9624):
[0001193125-16-576994:note_history:9]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 11,325 |  |  | $ | 1,575 |  |  | $ | (66 | ) |  | $ | 12,834 |  |
| Corporate bonds |  |  | 58,328 |  |  |  | 20 |  |  |  | (734 | ) |  |  | 57,614 |  |
| Municipal fixed-rate bonds |  |  | 26,414 |  |  |  | 28 |  |  |  | (18 | ) |  |  | 26,424 |  |
| Asset-backed bonds |  |  | 19,281 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 19,239 |  |
| Mortgage/Agency-backed bonds |  |  | 15,463 |  |  |  | 1 |  |  |  | (91 | ) |  |  | 15,373 |  |
| Government bonds |  |  | 35,646 |  |  |  | — |  |  |  | (248 | ) |  |  | 35,398 |  |
| Marketable equity securities |  |  | 31,643 |  |  |  | 4,301 |  |  |  | (1,693 | ) |  |  | 34,251 |  |
| Available-for-sale securities held at fair value |  | $ | 198,100 |  |  | $ | 5,927 |  |  | $ | (2,894 | ) |  | $ | 201,133 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,289 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 232,422 |  |

- changed (2016-08-05):
[0001564590-16-022906:note_history:10]
As of June 30, 2016, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, and U.S. government bonds had the following contractual maturities:
  (was, 2016-05-04, similarity 0.9609):
[0001193125-16-576994:note_history:10]
As of March 31, 2016, our corporate bonds, municipal
 fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds,
 and government bonds had the following contractual maturities:

- changed (2016-08-05):
[0001564590-16-022906:note_history:11]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. Government bonds |  |
| Less than one year |  | $ | 20,729 |  |  | $ | 10,473 |  |  | $ | - |  |  | $ | 4,972 |  |  | $ | 2,953 |  |
| One to two years |  |  | 24,884 |  |  |  | 4,488 |  |  |  | 822 |  |  |  | 2,569 |  |  |  | 7,481 |  |
| Two to three years |  |  | 6,099 |  |  |  | 1,536 |  |  |  | 9,077 |  |  |  | 2,058 |  |  |  | 11,344 |  |
| Three to five years |  |  | 2,420 |  |  |  | 451 |  |  |  | 10,991 |  |  |  | - |  |  |  | 12,028 |  |
| Five to ten years |  |  | - |  |  |  | - |  |  |  | 2,506 |  |  |  | 1,036 |  |  |  | - |  |
| More than ten years |  |  | - |  |  |  | - |  |  |  | 177 |  |  |  | 8,584 |  |  |  | - |  |
| Total |  | $ | 54,132 |  |  | $ | 16,948 |  |  | $ | 23,573 |  |  | $ | 19,219 |  |  | $ | 33,806 |  |
  (was, 2016-05-04, similarity 0.8727):
[0001193125-16-576994:note_history:11]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | Government bonds |  |
| Less than one year |  | $ | 17,668 |  |  | $ | 7,147 |  |  | $ | — |  |  | $ | 1,000 |  |  | $ | 1,253 |  |
| One to two years |  |  | 29,883 |  |  |  | 5,566 |  |  |  | 190 |  |  |  | 1,300 |  |  |  | 4,751 |  |
| Two to three years |  |  | 12,490 |  |  |  | 1,373 |  |  |  | 8,158 |  |  |  | 1,774 |  |  |  | 17,992 |  |
| Three to five years |  |  | 816 |  |  |  | 226 |  |  |  | 9,496 |  |  |  | — |  |  |  | 9,423 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 2,540 |  |  |  | 1,180 |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | 1,400 |  |  |  | 176 |  |  |  | 9,642 |  |  |  | — |  |
| Total |  | $ | 60,857 |  |  | $ | 15,712 |  |  | $ | 20,560 |  |  | $ | 14,896 |  |  | $ | 33,419 |  |

- added (2016-08-05):
[0001564590-16-022906:note_history:12]
At June 30, 2016, we held a $30.0 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $28.9 million at June 30, 2016 and December 31, 2015. At June 30, 2016, the estimated fair value of the Bond using a level 2 valuation technique was approximately $29.4 million, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

- changed (2016-08-05):
[0001564590-16-022906:note_history:13]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and six months ended June 30, 2016 and 2015, other-than-temporary impairment charges were not significant.
  (was, 2016-05-04, similarity 0.9811):
[0001193125-16-576994:note_history:13]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three months ended
 March 31, 2016 and 2015, other-than-temporary impairment
 charges were not significant.

- changed (2016-08-05):
[0001564590-16-022906:note_history:14]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Gross realized gains |  | $ | 1,517 |  |  | $ | 3,459 |  |  | $ | 3,881 |  |  | $ | 6,604 |  |
| Gross realized losses |  | $ | (407 | ) |  | $ | (204 | ) |  | $ | (1,043 | ) |  | $ | (234 | ) |
  (was, 2016-05-04, similarity 0.7589):
[0001193125-16-576994:note_history:14]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Gross realized gains |  | $ | 2,364 |  |  | $ | 3,145 |  |
| Gross realized losses |  | $ | (636 | ) |  | $ | (30 | ) |

- changed (2016-08-05):
[0001564590-16-022906:note_history:15]
As of June 30, 2016 and 2015, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.
  (was, 2016-05-04, similarity 0.9705):
[0001193125-16-576994:note_history:15]
As of March 31, 2016 and 2015, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.

- changed (2016-08-05):
[0001564590-16-022906:note_history:16]
|  |  | Fair Value Measurements at June 30, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,915 |  |  | $ | 1,915 |  |  | $ | - |  |  | $ | - |  |
| Commercial Paper |  |  | 15,996 |  |  |  | - |  |  |  | 15,996 |  |  |  | - |  |
| Cash equivalents |  |  | 17,911 |  |  |  | 1,915 |  |  |  | 15,996 |  |  |  | - |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,095 |  |  |  | 13,095 |  |  |  | - |  |  |  | - |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 54,132 |  |  |  | - |  |  |  | 54,132 |  |  |  | - |  |
| Municipal fixed-rate bonds |  |  | 16,948 |  |  |  | - |  |  |  | 16,948 |  |  |  | - |  |
| Asset-backed bonds |  |  | 23,573 |  |  |  | - |  |  |  | 23,573 |  |  |  | - |  |
| Mortgage/Agency-backed bonds |  |  | 19,219 |  |  |  | - |  |  |  | 19,219 |  |  |  | - |  |
| U.S. Government bonds |  |  | 33,806 |  |  |  | 33,806 |  |  |  | - |  |  |  | - |  |
| Variable rate demand notes |  |  | 11,740 |  |  |  | - |  |  |  | 11,740 |  |  |  | - |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 4,386 |  |  |  | 4,386 |  |  |  | - |  |  |  | - |  |
| Marketable equity securities – other |  |  | 28,985 |  |  |  | 28,985 |  |  |  | - |  |  |  | - |  |
| Available-for-sale securities |  |  | 205,884 |  |  |  | 80,272 |  |  |  | 125,612 |  |  |  | - |  |
| Total |  | $ | 223,795 |  |  | $ | 82,187 |  |  | $ | 141,608 |  |  | $ | - |  |
  (was, 2016-05-04, similarity 0.8325):
[0001193125-16-576994:note_history:16]
|  |  | Fair Value Measurements at March 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,110 |  |  | $ | 2,110 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 26,442 |  |  |  | — |  |  |  | 26,442 |  |  |  | — |  |
| Cash equivalents |  |  | 28,552 |  |  |  | 2,110 |  |  |  | 26,442 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,004 |  |  |  | 13,004 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 60,857 |  |  |  | — |  |  |  | 60,857 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 15,712 |  |  |  | — |  |  |  | 15,712 |  |  |  | — |  |
| Asset-backed bonds |  |  | 20,560 |  |  |  | — |  |  |  | 20,560 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 14,896 |  |  |  | — |  |  |  | 14,896 |  |  |  | — |  |
| Government bonds |  |  | 33,419 |  |  |  | 33,419 |  |  |  | — |  |  |  | — |  |
| Variable Rate Demand Notes |  |  | 2,235 |  |  |  | — |  |  |  | 2,235 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 4,709 |  |  |  | 4,709 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,328 |  |  |  | 28,328 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 193,720 |  |  |  | 79,460 |  |  |  | 114,260 |  |  |  | — |  |
| Total |  | $ | 222,272 |  |  | $ | 81,570 |  |  | $ | 140,702 |  |  | $ | — |  |

- changed (2016-08-05):
[0001564590-16-022906:note_history:17]
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,271 |  |  | $ | 1,271 |  |  | $ | - |  |  | $ | - |  |
| Commercial Paper |  |  | 11,696 |  |  |  | - |  |  |  | 11,696 |  |  |  | - |  |
| Cash equivalents |  |  | 12,967 |  |  |  | 1,271 |  |  |  | 11,696 |  |  |  | - |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,834 |  |  |  | 12,834 |  |  |  | - |  |  |  | - |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 57,614 |  |  |  | - |  |  |  | 57,614 |  |  |  | - |  |
| Municipal fixed-rate bonds |  |  | 26,424 |  |  |  | - |  |  |  | 26,424 |  |  |  | - |  |
| Asset-backed bonds |  |  | 19,239 |  |  |  | - |  |  |  | 19,239 |  |  |  | - |  |
| Mortgage/Agency-backed bonds |  |  | 15,373 |  |  |  | - |  |  |  | 15,373 |  |  |  | - |  |
| U.S. Government bonds |  |  | 35,398 |  |  |  | 35,398 |  |  |  | - |  |  |  | - |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,384 |  |  |  | 5,384 |  |  |  | - |  |  |  | - |  |
| Marketable equity securities – other |  |  | 28,867 |  |  |  | 28,867 |  |  |  | - |  |  |  | - |  |
| Available-for-sale securities |  |  | 201,133 |  |  |  | 82,483 |  |  |  | 118,650 |  |  |  | - |  |
| Total |  | $ | 214,100 |  |  | $ | 83,754 |  |  | $ | 130,346 |  |  | $ | - |  |
  (was, 2016-05-04, similarity 0.8423):
[0001193125-16-576994:note_history:17]
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,271 |  |  | $ | 1,271 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 11,696 |  |  |  | — |  |  |  | 11,696 |  |  |  | — |  |
| Cash equivalents |  |  | 12,967 |  |  |  | 1,271 |  |  |  | 11,696 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,834 |  |  |  | 12,834 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 57,614 |  |  |  | — |  |  |  | 57,614 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 26,424 |  |  |  | — |  |  |  | 26,424 |  |  |  | — |  |
| Asset-backed bonds |  |  | 19,239 |  |  |  | — |  |  |  | 19,239 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 15,373 |  |  |  | — |  |  |  | 15,373 |  |  |  | — |  |
| Government bonds |  |  | 35,398 |  |  |  | 35,398 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,384 |  |  |  | 5,384 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,867 |  |  |  | 28,867 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 201,133 |  |  |  | 82,483 |  |  |  | 118,650 |  |  |  | — |  |
| Total |  | $ | 214,100 |  |  | $ | 83,754 |  |  | $ | 130,346 |  |  | $ | — |  |

- changed (2016-08-05):
[0001564590-16-022906:note_history:18]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.
  (was, 2016-05-04, similarity 0.9797):
[0001193125-16-576994:note_history:18]
Our municipal variable rate demand notes have a structure that
 implies a standard expected market price. The frequent interest
 rate resets make it reasonable to expect the price to stay at par.
 These securities are priced at the expected market price.

- removed (2016-08-05):
[0001193125-16-576994:note_history:19]
At March 31, 2016, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 March 31, 2016, the estimated fair value of the Bond using a
 level 2 valuation technique was approximately $29.1 million, based
 on a debt security with a comparable interest rate and maturity and
 a Standard and Poor’s credit rating of AAA. For more
 information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2016-08-05):
[0001564590-16-022906:note_history:20]
On July 12, 2016, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on July 28, 2016. The payment date will be August 11, 2016. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

- changed (2016-08-05):
[0001564590-16-022906:note_history:21]
During the third quarter and as of August 5, 2016, we have repurchased 0.3 million shares of our common stock through open market purchases at an average cost of $17.99 per share. We currently have the authority to purchase an additional 4.6 million shares of our common stock under the current plan approved by the Board of Directors.
  (was, 2016-05-04, similarity 0.9487):
[0001193125-16-576994:note_history:21]
During the second quarter and as of May 4, 2016, we have
 repurchased 30 thousand shares of our common stock through
 open market purchases at an average cost of $18.64 per share. We
 currently have the authority to purchase an additional
 5.2 million shares of our common stock under the current plan
 approved by the Board of Directors.

- removed (2016-08-05):
[0001193125-16-576994:note_history:22]
On April 12, 2016, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 April 28, 2016. The payment date will be May 12, 2016.
 The quarterly dividend payment will be approximately $4.4 million.
 In July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.
