# ADTN notes — 0001564590-16-022906


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-16-022906:notes:1]
[same as prior period, unchanged from 0001193125-16-576994:notes:140]

[0001564590-16-022906:notes:2]
Basis of Presentation

[0001564590-16-022906:notes:3]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (ADTRAN) have been prepared pursuant to the rules and regulations for reporting on Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles for complete financial statements are not included herein. The December 31, 2015 Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.

[0001564590-16-022906:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim statements should be read in conjunction with the financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2015, filed on February 24, 2016 with the SEC.

[0001564590-16-022906:notes:5]
[same as prior period, unchanged from 0001193125-16-576994:notes:144]

[0001564590-16-022906:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-16-022906:notes:7]
Recent Accounting Pronouncements

[0001564590-16-022906:notes:8]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; and ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018, and we are currently evaluating the transition method that will be elected and the impact that the adoption of ASU 2014-09 will have on our financial position, results of operations and cash flows.

[0001564590-16-022906:notes:9]
In July 2015, the FASB issued Accounting Standards Update No.  2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We do not believe the adoption of ASU 2015-05 will have a material impact on our financial position, results of operations and cash flows.

[0001564590-16-022906:notes:10]
In November 2015, the FASB issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17). ASU 2015-17 amends the existing guidance on income taxes to require the classification of all deferred tax assets and liabilities as non-current on the balance sheet. ASU 2015-17 is effective for fiscal years beginning after December 15, 2016, including interim periods within those years. Early adoption is permitted. The guidance may be applied either prospectively, for all deferred tax assets and liabilities, or retrospectively to all periods presented. We have not selected a transition method or determined whether to early adopt ASU 2015-17 in 2016. Other than the revised balance sheet presentation of current deferred tax assets and liabilities, we do not believe the adoption of ASU 2015-17 will have a material impact on our financial position, results of operations and cash flows.

[0001564590-16-022906:notes:11]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years, with early adoption permitted. A modified retrospective approach is required. We are currently evaluating the impact that the adoption of ASU 2016-02 will have on our financial position, results of operations and cash flows.

[0001564590-16-022906:notes:12]
In March 2016, the FASB issued Accounting Standards Update No. 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09). ASU 2016-09 simplifies several aspects of accounting for share-based compensation arrangements, including income tax effects, the classification of tax-related cash flows on the statement of cash flows, and accounting for forfeitures. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016, including interim periods within those years. Early adoption is permitted. We are currently evaluating the impact that the adoption of ASU 2016-09 will have on our financial position, results of operations and cash flows.

[0001564590-16-022906:notes:13]
During the first quarter of 2016, we adopted the following accounting standards, which had no material effect on our financial position, results of operations or cash flows:

[0001564590-16-022906:notes:14]
In April 2015, the FASB issued Accounting Standards Update No. 2015-05, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on accounting for fees paid by a customer in a cloud computing arrangement. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. ASU 2015-05 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within that reporting period. The amendments may be applied either prospectively to all arrangements entered into or materially modified after the effective date or retrospectively. We adopted ASU 2015-05 during the first quarter of 2016 and will apply the new standard prospectively. The adoption of ASU 2015-05 did not have a material impact on our financial position, results of operations and cash flows.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-022906:notes:15]
[same as prior period, unchanged from 0001193125-16-576994:notes:100]

[0001564590-16-022906:notes:16]
Our effective tax rate decreased from 39.1% in the six months ended June 30, 2015 to 37.9% in the six months ended June 30, 2016. The decrease in the effective tax rate between the two periods is primarily attributable to the research and development tax credit being made permanent.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-16-022906:notes:17]
[same as prior period, unchanged from 0001193125-16-576994:notes:6]

[0001564590-16-022906:notes:18]
We maintain a defined benefit pension plan covering employees in certain foreign countries.

[0001564590-16-022906:notes:19]
The following table summarizes the components of net periodic pension cost for the three and six months ended June 30, 2016 and 2015:

[0001564590-16-022906:notes:20]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Service cost |  | $ | 310 |  |  | $ | 324 |  |  | $ | 607 |  |  | $ | 664 |  |
| Interest cost |  |  | 184 |  |  |  | 152 |  |  |  | 360 |  |  |  | 311 |  |
| Expected return on plan assets |  |  | (271 | ) |  |  | (250 | ) |  |  | (530 | ) |  |  | (511 | ) |
| Amortization of actuarial losses |  |  | 45 |  |  |  | 100 |  |  |  | 88 |  |  |  | 205 |  |
| Net periodic pension cost |  | $ | 268 |  |  | $ | 326 |  |  | $ | 525 |  |  | $ | 669 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-16-022906:notes:21]
[same as prior period, unchanged from 0001193125-16-576994:notes:122]

[0001564590-16-022906:notes:22]
The following table summarizes the stock-based compensation expense related to stock options, restricted stock units (RSUs) and restricted stock for the three and six months ended June 30, 2016 and 2015, which was recognized as follows:

[0001564590-16-022906:notes:23]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 95 |  |  | $ | 53 |  |  | $ | 194 |  |  | $ | 143 |  |
| Selling, general and administrative expense |  |  | 788 |  |  |  | 723 |  |  |  | 1,557 |  |  |  | 1,414 |  |
| Research and development expense |  |  | 668 |  |  |  | 699 |  |  |  | 1,358 |  |  |  | 1,557 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,456 |  |  |  | 1,422 |  |  |  | 2,915 |  |  |  | 2,971 |  |
| Total stock-based compensation expense |  |  | 1,551 |  |  |  | 1,475 |  |  |  | 3,109 |  |  |  | 3,114 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (213 | ) |  |  | (222 | ) |  |  | (425 | ) |  |  | (402 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,338 |  |  | $ | 1,253 |  |  | $ | 2,684 |  |  | $ | 2,712 |  |

[0001564590-16-022906:notes:24]
The fair value of our stock options is estimated using the Black-Scholes model. The determination of the fair value of stock options on the date of grant using the Black-Scholes model is affected by our stock price as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate.

[0001564590-16-022906:notes:25]
There were no options granted during the three months ended June 30, 2015. The weighted-average assumptions and value of options granted for the three and six months ended June 30, 2016 and the six months ended June 30, 2015 are as follows:

[0001564590-16-022906:notes:26]
|  |  | Three and Six Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| Expected volatility |  |  | 34.74 | % |  |  | 38.75 | % |
| Risk-free interest rate |  |  | 1.33 | % |  |  | 1.46 | % |
| Expected dividend yield |  |  | 1.91 | % |  |  | 1.60 | % |
| Expected life (in years) |  |  | 6.26 |  |  |  | 6.47 |  |
| Weighted-average estimated value |  | $ | 5.42 |  |  | $ | 7.63 |  |

[0001564590-16-022906:notes:27]
The fair value of our RSUs is calculated using a Monte Carlo Simulation valuation method. No RSUs were granted or vested during the three and six months ended June 30, 2016 and 2015. Twelve thousand RSUs were forfeited during the six months ended June 30, 2015.

[0001564590-16-022906:notes:28]
The fair value of restricted stock is equal to the closing price of our stock on the date of grant. Two thousand shares of restricted stock were granted during the six months ended June 30, 2016. Two thousand shares of restricted stock vested during the three and six months ended June 30, 2015.

[0001564590-16-022906:notes:29]
Stock-based compensation expense recognized in our Consolidated Statements of Income for the three and six months ended June 30, 2016 and 2015 is based on options, RSUs and restricted stock ultimately expected to vest, and has been reduced for estimated forfeitures. Estimated forfeitures for stock options are based upon historical experience and approximate 3.7% annually. We estimated a 0% forfeiture rate for our RSUs and restricted stock due to the limited number of recipients and historical experience for these awards.

[0001564590-16-022906:notes:30]
As of June 30, 2016, total compensation expense related to non-vested stock options, RSUs and restricted stock not yet recognized was approximately $11.5 million, which is expected to be recognized over an average remaining recognition period of 2.4 years.

[0001564590-16-022906:notes:31]
The following table is a summary of our stock options outstanding as of December 31, 2015 and June 30, 2016 and the changes that occurred during the six months ended June 30, 2016:

[0001564590-16-022906:notes:32]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2015 |  |  | 7,108 |  |  | $ | 21.97 |  |  |  | 6.42 |  |  | $ | 3,284 |  |
| Options granted |  |  | 1 |  |  | $ | 18.83 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (33 | ) |  | $ | 16.58 |  |  |  |  |  |  |  |  |  |
| Options forfeited |  |  | (42 | ) |  | $ | 17.88 |  |  |  |  |  |  |  |  |  |
| Options expired |  |  | (54 | ) |  | $ | 25.65 |  |  |  |  |  |  |  |  |  |
| Options outstanding, June 30, 2016 |  |  | 6,980 |  |  | $ | 22.00 |  |  |  | 5.93 |  |  | $ | 6,522 |  |
| Options vested and expected to vest, June 30, 2016 |  |  | 6,865 |  |  | $ | 22.09 |  |  |  | 5.88 |  |  | $ | 6,260 |  |
| Options exercisable, June 30, 2016 |  |  | 4,420 |  |  | $ | 24.35 |  |  |  | 4.44 |  |  | $ | 2,298 |  |

[0001564590-16-022906:notes:33]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between the closing price of our stock on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on June 30, 2016. The aggregate intrinsic value will change based on the fair market value of our stock.

[0001564590-16-022906:notes:34]
The total pre-tax intrinsic value of options exercised during the three and six months ended June 30, 2016 was $0.1 million.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-16-022906:notes:35]
5. INVESTMENTS

[0001564590-16-022906:notes:36]
At June 30, 2016, we held the following securities and investments, recorded at either fair value or cost.

[0001564590-16-022906:notes:37]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,516 |  |  | $ | 1,628 |  |  | $ | (49 | ) |  | $ | 13,095 |  |
| Corporate bonds |  |  | 54,044 |  |  |  | 149 |  |  |  | (61 | ) |  |  | 54,132 |  |
| Municipal fixed-rate bonds |  |  | 16,889 |  |  |  | 59 |  |  |  | - |  |  |  | 16,948 |  |
| Asset-backed bonds |  |  | 23,526 |  |  |  | 53 |  |  |  | (6 | ) |  |  | 23,573 |  |
| Mortgage/Agency-backed bonds |  |  | 19,214 |  |  |  | 44 |  |  |  | (39 | ) |  |  | 19,219 |  |
| U.S. Government bonds |  |  | 33,498 |  |  |  | 308 |  |  |  | - |  |  |  | 33,806 |  |
| Variable rate demand notes |  |  | 11,740 |  |  |  | - |  |  |  | - |  |  |  | 11,740 |  |
| Marketable equity securities |  |  | 32,948 |  |  |  | 1,901 |  |  |  | (1,478 | ) |  |  | 33,371 |  |
| Available-for-sale securities held at fair value |  | $ | 203,375 |  |  | $ | 4,142 |  |  | $ | (1,633 | ) |  | $ | 205,884 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,232 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 237,116 |  |

[0001564590-16-022906:notes:38]
At December 31, 2015, we held the following securities and investments, recorded at either fair value or cost.

[0001564590-16-022906:notes:39]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,325 |  |  | $ | 1,575 |  |  | $ | (66 | ) |  | $ | 12,834 |  |
| Corporate bonds |  |  | 58,328 |  |  |  | 20 |  |  |  | (734 | ) |  |  | 57,614 |  |
| Municipal fixed-rate bonds |  |  | 26,414 |  |  |  | 28 |  |  |  | (18 | ) |  |  | 26,424 |  |
| Asset-backed bonds |  |  | 19,281 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 19,239 |  |
| Mortgage/Agency-backed bonds |  |  | 15,463 |  |  |  | 1 |  |  |  | (91 | ) |  |  | 15,373 |  |
| U.S. Government bonds |  |  | 35,646 |  |  |  | - |  |  |  | (248 | ) |  |  | 35,398 |  |
| Marketable equity securities |  |  | 31,643 |  |  |  | 4,301 |  |  |  | (1,693 | ) |  |  | 34,251 |  |
| Available-for-sale securities held at fair value |  | $ | 198,100 |  |  | $ | 5,927 |  |  | $ | (2,894 | ) |  | $ | 201,133 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,289 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 232,422 |  |

[0001564590-16-022906:notes:40]
As of June 30, 2016, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, and U.S. government bonds had the following contractual maturities:

[0001564590-16-022906:notes:41]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. Government bonds |  |
| Less than one year |  | $ | 20,729 |  |  | $ | 10,473 |  |  | $ | - |  |  | $ | 4,972 |  |  | $ | 2,953 |  |
| One to two years |  |  | 24,884 |  |  |  | 4,488 |  |  |  | 822 |  |  |  | 2,569 |  |  |  | 7,481 |  |
| Two to three years |  |  | 6,099 |  |  |  | 1,536 |  |  |  | 9,077 |  |  |  | 2,058 |  |  |  | 11,344 |  |
| Three to five years |  |  | 2,420 |  |  |  | 451 |  |  |  | 10,991 |  |  |  | - |  |  |  | 12,028 |  |
| Five to ten years |  |  | - |  |  |  | - |  |  |  | 2,506 |  |  |  | 1,036 |  |  |  | - |  |
| More than ten years |  |  | - |  |  |  | - |  |  |  | 177 |  |  |  | 8,584 |  |  |  | - |  |
| Total |  | $ | 54,132 |  |  | $ | 16,948 |  |  | $ | 23,573 |  |  | $ | 19,219 |  |  | $ | 33,806 |  |

[0001564590-16-022906:notes:42]
Actual maturities may differ from contractual maturities because some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-16-022906:notes:43]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-16-022906:notes:44]
At June 30, 2016, we held a $30.0 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $28.9 million at June 30, 2016 and December 31, 2015. At June 30, 2016, the estimated fair value of the Bond using a level 2 valuation technique was approximately $29.4 million, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

[0001564590-16-022906:notes:45]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and six months ended June 30, 2016 and 2015, other-than-temporary impairment charges were not significant.

[0001564590-16-022906:notes:46]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments.

[0001564590-16-022906:notes:47]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Gross realized gains |  | $ | 1,517 |  |  | $ | 3,459 |  |  | $ | 3,881 |  |  | $ | 6,604 |  |
| Gross realized losses |  | $ | (407 | ) |  | $ | (204 | ) |  | $ | (1,043 | ) |  | $ | (234 | ) |

[0001564590-16-022906:notes:48]
As of June 30, 2016 and 2015, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.

[0001564590-16-022906:notes:49]
We have categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows:  Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-16-022906:notes:50]
|  |  | Fair Value Measurements at June 30, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,915 |  |  | $ | 1,915 |  |  | $ | - |  |  | $ | - |  |
| Commercial Paper |  |  | 15,996 |  |  |  | - |  |  |  | 15,996 |  |  |  | - |  |
| Cash equivalents |  |  | 17,911 |  |  |  | 1,915 |  |  |  | 15,996 |  |  |  | - |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,095 |  |  |  | 13,095 |  |  |  | - |  |  |  | - |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 54,132 |  |  |  | - |  |  |  | 54,132 |  |  |  | - |  |
| Municipal fixed-rate bonds |  |  | 16,948 |  |  |  | - |  |  |  | 16,948 |  |  |  | - |  |
| Asset-backed bonds |  |  | 23,573 |  |  |  | - |  |  |  | 23,573 |  |  |  | - |  |
| Mortgage/Agency-backed bonds |  |  | 19,219 |  |  |  | - |  |  |  | 19,219 |  |  |  | - |  |
| U.S. Government bonds |  |  | 33,806 |  |  |  | 33,806 |  |  |  | - |  |  |  | - |  |
| Variable rate demand notes |  |  | 11,740 |  |  |  | - |  |  |  | 11,740 |  |  |  | - |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 4,386 |  |  |  | 4,386 |  |  |  | - |  |  |  | - |  |
| Marketable equity securities – other |  |  | 28,985 |  |  |  | 28,985 |  |  |  | - |  |  |  | - |  |
| Available-for-sale securities |  |  | 205,884 |  |  |  | 80,272 |  |  |  | 125,612 |  |  |  | - |  |
| Total |  | $ | 223,795 |  |  | $ | 82,187 |  |  | $ | 141,608 |  |  | $ | - |  |

[0001564590-16-022906:notes:51]
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,271 |  |  | $ | 1,271 |  |  | $ | - |  |  | $ | - |  |
| Commercial Paper |  |  | 11,696 |  |  |  | - |  |  |  | 11,696 |  |  |  | - |  |
| Cash equivalents |  |  | 12,967 |  |  |  | 1,271 |  |  |  | 11,696 |  |  |  | - |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,834 |  |  |  | 12,834 |  |  |  | - |  |  |  | - |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 57,614 |  |  |  | - |  |  |  | 57,614 |  |  |  | - |  |
| Municipal fixed-rate bonds |  |  | 26,424 |  |  |  | - |  |  |  | 26,424 |  |  |  | - |  |
| Asset-backed bonds |  |  | 19,239 |  |  |  | - |  |  |  | 19,239 |  |  |  | - |  |
| Mortgage/Agency-backed bonds |  |  | 15,373 |  |  |  | - |  |  |  | 15,373 |  |  |  | - |  |
| U.S. Government bonds |  |  | 35,398 |  |  |  | 35,398 |  |  |  | - |  |  |  | - |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,384 |  |  |  | 5,384 |  |  |  | - |  |  |  | - |  |
| Marketable equity securities – other |  |  | 28,867 |  |  |  | 28,867 |  |  |  | - |  |  |  | - |  |
| Available-for-sale securities |  |  | 201,133 |  |  |  | 82,483 |  |  |  | 118,650 |  |  |  | - |  |
| Total |  | $ | 214,100 |  |  | $ | 83,754 |  |  | $ | 130,346 |  |  | $ | - |  |

[0001564590-16-022906:notes:52]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-16-022906:notes:53]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-16-022906:notes:54]
[same as prior period, unchanged from 0001193125-16-576994:notes:107]

[0001564590-16-022906:notes:55]
We have certain customers and suppliers who are invoiced or pay in a non-functional currency. Changes in the monetary exchange rates may adversely affect our results of operations and financial condition, as these are remeasured to the functional currency through profit and loss. When appropriate, we enter into various derivative transactions to enhance our ability to manage the volatility relating to these typical business exposures. We do not hold or issue derivative instruments for trading or other speculative purposes. Our derivative instruments are recorded in the Consolidated Balance Sheets at their fair values. Our derivative instruments do not qualify for hedge accounting, and accordingly, all changes in the fair value of the instruments are recognized as other income (expense) in the Consolidated Statements of Income. The maximum contractual period for our derivatives is currently less than twelve months. Our derivative instruments are not subject to master netting arrangements and are not offset in the Consolidated Balance Sheets.

[0001564590-16-022906:notes:56]
As of June 30, 2016, we had forward contracts outstanding with notional amounts totaling €6.0 million ($6.7 million), which mature in the third quarter of 2016.

[0001564590-16-022906:notes:57]
The fair values of our derivative instruments recorded in the Consolidated Balance Sheet as of June 30, 2016 and December 31, 2015 were as follows:

[0001564590-16-022906:notes:58]
| (In thousands) |  | Balance Sheet Location |  | June 30, 2016 |  |  | December 31, 2015 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 188 |  |  | $ | - |  |

[0001564590-16-022906:notes:59]
The change in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the three and six months ended June 30, 2016 and 2015 were as follows:

[0001564590-16-022906:notes:60]
|  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Income Statement |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | Location |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | 237 |  |  | $ | (1,299 | ) |  | $ | 190 |  |  | $ | 177 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-16-022906:notes:61]
[same as prior period, unchanged from 0001193125-16-576994:notes:98]

[0001564590-16-022906:notes:62]
At June 30, 2016 and December 31, 2015, inventory consisted of the following:

[0001564590-16-022906:notes:63]
|  |  | June 30, |  |  | December 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Raw materials |  | $ | 35,761 |  |  | $ | 34,223 |  |
| Work in process |  |  | 2,322 |  |  |  | 2,893 |  |
| Finished goods |  |  | 48,853 |  |  |  | 54,417 |  |
| Total |  | $ | 86,936 |  |  | $ | 91,533 |  |

[0001564590-16-022906:notes:64]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At June 30, 2016 and December 31, 2015, raw materials reserves totaled $18.0 million and $17.5 million, respectively, and finished goods inventory reserves totaled $9.8 million and $9.2 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-16-022906:notes:65]
[same as prior period, unchanged from 0001193125-16-576994:notes:36]

[0001564590-16-022906:notes:66]
Goodwill, all of which relates to our acquisition of Bluesocket, Inc., was $3.5 million at June 30, 2016 and December 31, 2015, and was previously recorded in our Enterprise Networks reportable segment. As a result of our new reporting structure, which is discussed further in Note 11, we reallocated goodwill from our Enterprise Networks reportable segment to our two, new reportable segments – Network Solutions and Services & Support. As a result, goodwill of $3.1 million and $0.4 million was reallocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-16-022906:notes:67]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2015, we concluded that it was not necessary to perform the two-step impairment test. There have been no impairment losses recognized since the acquisition in 2011.

[0001564590-16-022906:notes:68]
Intangible assets are included in other assets in the accompanying Consolidated Balance Sheets and include intangibles acquired in conjunction with our acquisitions of Objectworld Communications Corporation on September 15, 2009, Bluesocket, Inc. on August 4, 2011, and the NSN BBA business on May 4, 2012.

[0001564590-16-022906:notes:69]
The following table presents our intangible assets as of June 30, 2016 and December 31, 2015:

[0001564590-16-022906:notes:70]
| (In thousands) |  | June 30, 2016 |  |  | December 31, 2015 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 5,925 |  |  | $ | (2,966 | ) |  | $ | 2,959 |  |  | $ | 5,828 |  |  | $ | (2,627 | ) |  | $ | 3,201 |  |
| Developed technology |  |  | 5,778 |  |  |  | (4,767 | ) |  |  | 1,011 |  |  |  | 5,720 |  |  |  | (4,329 | ) |  |  | 1,391 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (2,021 | ) |  |  | 319 |  |  |  | 2,340 |  |  |  | (1,854 | ) |  |  | 486 |  |
| Trade names |  |  | 270 |  |  |  | (270 | ) |  |  | - |  |  |  | 270 |  |  |  | (265 | ) |  |  | 5 |  |
| Total |  | $ | 14,313 |  |  | $ | (10,024 | ) |  | $ | 4,289 |  |  | $ | 14,158 |  |  | $ | (9,075 | ) |  | $ | 5,083 |  |

[0001564590-16-022906:notes:71]
Amortization expense, all of which relates to business acquisitions, was $0.4 million and $0.5 million for the three months ended June 30, 2016 and 2015, respectively, and $0.9 million and $1.0 million for the six months ended June 30, 2016 and 2015, respectively.

[0001564590-16-022906:notes:72]
As of June 30, 2016, the estimated future amortization expense of our intangible assets is as follows:

[0001564590-16-022906:notes:73]
| (In thousands) |  | Amount |  |
| Remainder of 2016 |  | $ | 807 |  |
| 2017 |  |  | 1,162 |  |
| 2018 |  |  | 702 |  |
| 2019 |  |  | 308 |  |
| 2020 |  |  | 285 |  |
| Thereafter |  |  | 1,025 |  |
| Total |  | $ | 4,289 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-16-022906:notes:74]
[same as prior period, unchanged from 0001193125-16-576994:notes:110]

[0001564590-16-022906:notes:75]
A summary of the changes in stockholders’ equity for the six months ended June 30, 2016 is as follows:

[0001564590-16-022906:notes:76]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2015 |  | $ | 480,160 |  |
| Net income |  |  | 15,242 |  |
| Dividend payments |  |  | (8,860 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (26 | ) |
| Net unrealized losses on available-for-sale securities (net of tax) |  |  | (420 | ) |
| Defined benefit plan adjustments |  |  | 67 |  |
| Foreign currency translation adjustment |  |  | 627 |  |
| Proceeds from stock option exercises |  |  | 541 |  |
| Purchase of treasury stock |  |  | (16,579 | ) |
| Income tax effect of stock compensation arrangements |  |  | (137 | ) |
| Stock-based compensation expense |  |  | 3,109 |  |
| Balance, June 30, 2016 |  | $ | 473,724 |  |

[0001564590-16-022906:notes:77]
[same as prior period, unchanged from 0001193125-16-576994:notes:111]

[0001564590-16-022906:notes:78]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2016, we repurchased 0.9 million shares of our common stock at an average price of $18.48 per share. As of June 30, 2016, we have the authority to purchase an additional 4.9 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-16-022906:notes:79]
[same as prior period, unchanged from 0001193125-16-576994:notes:113]

[0001564590-16-022906:notes:80]
We issued 33 thousand shares of treasury stock during the six months ended June 30, 2016 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $0.5 million from the exercise of these stock options during the six months ended June 30, 2016.

[0001564590-16-022906:notes:81]
[same as prior period, unchanged from 0001193125-16-576994:notes:115]

[0001564590-16-022906:notes:82]
During the six months ended June 30, 2016, we paid cash dividends as follows (in thousands except per share amounts):

[0001564590-16-022906:notes:83]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 4, 2016 |  | February 18, 2016 |  | $ | 0.09 |  |  | $ | 4,453 |  |
| April 28, 2016 |  | May 12, 2016 |  | $ | 0.09 |  |  | $ | 4,407 |  |

[0001564590-16-022906:notes:84]
[same as prior period, unchanged from 0001193125-16-576994:notes:116]

[0001564590-16-022906:notes:85]
Other comprehensive income consists of unrealized gains (losses) on available-for-sale securities, reclassification adjustments for amounts included in net income related to impairments of available-for-sale securities, realized gains (losses) on available-for-sale securities, and amortization of actuarial gains (losses) related to our defined benefit plan, defined benefit plan adjustments, and foreign currency translation adjustments.

[0001564590-16-022906:notes:86]
The following tables present changes in accumulated other comprehensive income, net of tax, by component for the three months ended June 30, 2016 and 2015:

[0001564590-16-022906:notes:87]
|  |  | Three Months Ended June 30, 2016 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,677 |  |  | $ | (3,850 | ) |  | $ | (5,778 | ) |  | $ | (7,951 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 481 |  |  |  | - |  |  |  | (601 | ) |  |  | (120 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (646 | ) |  |  | 22 |  |  |  | - |  |  |  | (624 | ) |
| Net current period other comprehensive income (loss) |  |  | (165 | ) |  |  | 22 |  |  |  | (601 | ) |  |  | (744 | ) |
| Ending balance |  | $ | 1,512 |  |  | $ | (3,828 | ) |  | $ | (6,379 | ) |  | $ | (8,695 | ) |

[0001564590-16-022906:notes:88]
|  |  | Three Months Ended June 30, 2015 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 8,461 |  |  | $ | (5,689 | ) |  | $ | (6,600 | ) |  | $ | (3,828 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 177 |  |  |  | - |  |  |  | 872 |  |  |  | 1,049 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,960 | ) |  |  | 72 |  |  |  | - |  |  |  | (1,888 | ) |
| Net current period other comprehensive income (loss) |  |  | (1,783 | ) |  |  | 72 |  |  |  | 872 |  |  |  | (839 | ) |
| Ending balance |  | $ | 6,678 |  |  | $ | (5,617 | ) |  | $ | (5,728 | ) |  | $ | (4,667 | ) |

[0001564590-16-022906:notes:89]
The following tables present changes in accumulated other comprehensive income, net of tax, by component for the six months ended June 30, 2016 and 2015:

[0001564590-16-022906:notes:90]
|  |  | Six Months Ended June 30, 2016 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,932 |  |  | $ | (3,895 | ) |  | $ | (7,006 | ) |  | $ | (8,969 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,239 |  |  |  | - |  |  |  | 627 |  |  |  | 1,866 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,659 | ) |  |  | 67 |  |  |  | - |  |  |  | (1,592 | ) |
| Net current period other comprehensive income (loss) |  |  | (420 | ) |  |  | 67 |  |  |  | 627 |  |  |  | 274 |  |
| Ending balance |  | $ | 1,512 |  |  | $ | (3,828 | ) |  | $ | (6,379 | ) |  | $ | (8,695 | ) |

[0001564590-16-022906:notes:91]
|  |  | Six Months Ended June 30, 2015 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 8,964 |  |  | $ | (5,757 | ) |  | $ | (3,282 | ) |  | $ | (75 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,537 |  |  |  | - |  |  |  | (2,446 | ) |  |  | (909 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (3,823 | ) |  |  | 140 |  |  |  | - |  |  |  | (3,683 | ) |
| Net current period other comprehensive income (loss) |  |  | (2,286 | ) |  |  | 140 |  |  |  | (2,446 | ) |  |  | (4,592 | ) |
| Ending balance |  | $ | 6,678 |  |  | $ | (5,617 | ) |  | $ | (5,728 | ) |  | $ | (4,667 | ) |

[0001564590-16-022906:notes:92]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the three months ended June 30, 2016 and 2015:

[0001564590-16-022906:notes:93]
| (In thousands) |  | Three Months Ended June 30, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,354 |  |  | Net realized investment gain |
| Impairment expense |  |  | (295 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (33 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,026 |  |  |  |
| Tax (expense) benefit |  |  | (402 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 624 |  |  |  |

[0001564590-16-022906:notes:94]
[same as prior period, unchanged from 0001193125-16-576994:notes:120]

[0001564590-16-022906:notes:95]
| (In thousands) |  | Three Months Ended June 30, 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 3,264 |  |  | Net realized investment gain |
| Impairment expense |  |  | (51 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (105 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 3,108 |  |  |  |
| Tax (expense) benefit |  |  | (1,220 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,888 |  |  |  |

[0001564590-16-022906:notes:96]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the six months ended June 30, 2016 and 2015:

[0001564590-16-022906:notes:97]
| (In thousands) |  | Six Months Ended June 30, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 3,115 |  |  | Net realized investment gain |
| Impairment expense |  |  | (395 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (98 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 2,622 |  |  |  |
| Tax (expense) benefit |  |  | (1,030 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,592 |  |  |  |

[0001564590-16-022906:notes:98]
| (In thousands) |  | Six Months Ended June 30, 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 6,340 |  |  | Net realized investment gain |
| Impairment expense |  |  | (73 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (203 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 6,064 |  |  |  |
| Tax (expense) benefit |  |  | (2,381 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 3,683 |  |  |  |

[0001564590-16-022906:notes:99]
The following table presents the tax effects related to the change in each component of other comprehensive income for the three months ended June 30, 2016 and 2015:

[0001564590-16-022906:notes:100]
|  |  | Three Months Ended June 30, 2016 |  |  | Three Months Ended June 30, 2015 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 789 |  |  | $ | (308 | ) |  | $ | 481 |  |  | $ | 290 |  |  | $ | (113 | ) |  | $ | 177 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (1,059 | ) |  |  | 413 |  |  |  | (646 | ) |  |  | (3,213 | ) |  |  | 1,253 |  |  |  | (1,960 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 33 |  |  |  | (11 | ) |  |  | 22 |  |  |  | 105 |  |  |  | (33 | ) |  |  | 72 |  |
| Foreign currency translation adjustment |  |  | (601 | ) |  |  | - |  |  |  | (601 | ) |  |  | 872 |  |  |  | - |  |  |  | 872 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (838 | ) |  | $ | 94 |  |  | $ | (744 | ) |  | $ | (1,946 | ) |  | $ | 1,107 |  |  | $ | (839 | ) |

[0001564590-16-022906:notes:101]
The following table presents the tax effects related to the change in each component of other comprehensive income for the six months ended June 30, 2016 and 2015:

[0001564590-16-022906:notes:102]
|  |  | Six Months Ended June 30, 2016 |  |  | Six Months Ended June 30, 2015 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 2,031 |  |  | $ | (792 | ) |  | $ | 1,239 |  |  | $ | 2,520 |  |  | $ | (983 | ) |  | $ | 1,537 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (2,720 | ) |  |  | 1,061 |  |  |  | (1,659 | ) |  |  | (6,267 | ) |  |  | 2,444 |  |  |  | (3,823 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 98 |  |  |  | (31 | ) |  |  | 67 |  |  |  | 203 |  |  |  | (63 | ) |  |  | 140 |  |
| Foreign currency translation adjustment |  |  | 627 |  |  |  | - |  |  |  | 627 |  |  |  | (2,446 | ) |  |  | - |  |  |  | (2,446 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 36 |  |  | $ | 238 |  |  | $ | 274 |  |  | $ | (5,990 | ) |  | $ | 1,398 |  |  | $ | (4,592 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-022906:notes:103]
[same as prior period, unchanged from 0001193125-16-576994:notes:146]

[0001564590-16-022906:notes:104]
A summary of the calculation of basic and diluted earnings per share for the three and six months ended June 30, 2016 and 2015 is as follows:

[0001564590-16-022906:notes:105]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 10,228 |  |  | $ | 2,544 |  |  | $ | 15,242 |  |  | $ | 5,861 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,831 |  |  |  | 51,822 |  |  |  | 49,026 |  |  |  | 52,607 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 161 |  |  |  | 72 |  |  |  | 138 |  |  |  | 122 |  |
| Restricted stock and restricted stock units |  |  | 56 |  |  |  | 23 |  |  |  | 54 |  |  |  | 13 |  |
| Weighted average number of shares – diluted |  |  | 49,048 |  |  |  | 51,917 |  |  |  | 49,218 |  |  |  | 52,742 |  |
| Net income per share – basic |  | $ | 0.21 |  |  | $ | 0.05 |  |  | $ | 0.31 |  |  | $ | 0.11 |  |
| Net income per share – diluted |  | $ | 0.21 |  |  | $ | 0.05 |  |  | $ | 0.31 |  |  | $ | 0.11 |  |

[0001564590-16-022906:notes:106]
Anti-dilutive options to purchase common stock outstanding were excluded from the above calculations. Anti-dilutive options totaled 5.6 million and 6.1 million for the three months ended June 30, 2016 and 2015, respectively, and 5.8 million and 5.7 million for the six months ended June 30, 2016 and 2015, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-022906:notes:107]
[same as prior period, unchanged from 0001193125-16-576994:notes:47]

[0001564590-16-022906:notes:108]
In 2015, we began a realignment of our organizational structure to better match our market opportunities, technological development initiatives, and improve efficiencies. During the first quarter of 2016, our chief operating decision maker requested changes in the information that he regularly reviews for purposes of allocating resources and assessing performance. As a result, beginning with the quarter ended March 31, 2016, we began reporting our financial performance based on two, new reportable segments – Network Solutions and Services & Support. Network Solutions includes hardware products and next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes our suite of ProCloud® managed services, network installation, engineering and maintenance services, and fee-based technical support and equipment repair/replacement plans.

[0001564590-16-022906:notes:109]
We evaluate the performance of our new segments based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net realized investment gain/loss, other income/expense and provision for taxes are reported on a company-wide, functional basis only. Historical financial information by reportable segment and category, as discussed below, has been recast to conform to our new reporting structure. There are no inter-segment revenues.

[0001564590-16-022906:notes:110]
The following table presents information about the reported sales and gross profit of our reportable segments for the three and six months ended June 30, 2016 and 2015. We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-16-022906:notes:111]
|  |  | Three Months Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 138,549 |  |  | $ | 70,705 |  |  | $ | 144,098 |  |  | $ | 59,888 |  |
| Services & Support |  |  | 24,152 |  |  |  | 8,250 |  |  |  | 16,040 |  |  |  | 8,358 |  |
| Total |  | $ | 162,701 |  |  | $ | 78,955 |  |  | $ | 160,138 |  |  | $ | 68,246 |  |

[0001564590-16-022906:notes:112]
|  |  | Six Months Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 262,432 |  |  | $ | 130,515 |  |  | $ | 273,603 |  |  | $ | 117,833 |  |
| Services & Support |  |  | 42,473 |  |  |  | 14,234 |  |  |  | 29,370 |  |  |  | 15,976 |  |
| Total |  | $ | 304,905 |  |  | $ | 144,749 |  |  | $ | 302,973 |  |  | $ | 133,809 |  |

[0001564590-16-022906:notes:113]
[same as prior period, unchanged from 0001193125-16-576994:notes:52]

[0001564590-16-022906:notes:114]
In addition to our new reporting segments, we will also report revenue for the following three categories – Access & Aggregation, Customer Devices, and Traditional & Other Products.

[0001564590-16-022906:notes:115]
Access & Aggregation generally includes software and hardware based products and services that communication service providers (CSPs) use to aggregate and/or originate network access technologies. The portfolio of ADTRAN solutions within this category includes a wide array of modular or fixed physical form factors designed to deliver the best technology and economic fit for our customers based on the target subscriber density and environmental conditions.

[0001564590-16-022906:notes:116]
The Access & Aggregation category includes product and service families such as:

[0001564590-16-022906:notes:117]
|  | · | Total Access® 5000 Series Fiber to the Premises (FTTP) and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001564590-16-022906:notes:118]
|  | · | hiX 5600 Series fiber aggregation and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001564590-16-022906:notes:119]
|  | · | Fiber to the Distribution Point (FTTdp) Optical Network Units (ONU) |

[0001564590-16-022906:notes:120]
|  | · | Optical Line Terminals (OLT) |

[0001564590-16-022906:notes:121]
|  | · | Optical Networking Edge (ONE) aggregation |

[0001564590-16-022906:notes:122]
|  | · | Distribution Point Units (DPUs) |

[0001564590-16-022906:notes:123]
|  | · | IP Digital Subscriber Line Access Multiplexers (DSLAMs) |

[0001564590-16-022906:notes:124]
|  | · | Cabinet and Outside-Plant (OSP) enclosures and services |

[0001564590-16-022906:notes:125]
|  | · | Network Management and Cloud based software platforms and applications |

[0001564590-16-022906:notes:126]
|  | · | Pluggable optical transceivers (i.e., SFP, SFP+, XFP, QSFP), cables and other miscellaneous materials |

[0001564590-16-022906:notes:127]
|  | · | Other products and services that are generally applicable to Access & Aggregation |

[0001564590-16-022906:notes:128]
Customer Devices generally includes the products and services that provide end users access to the CSP network.  The Customer Devices portfolio includes a comprehensive array of service provider and enterprise hardware and software products and services.

[0001564590-16-022906:notes:129]
The Customer Devices category includes products and services such as:

[0001564590-16-022906:notes:130]
|  | · | Broadband customer premise solutions, including Passive Optical Network (PON) and point-to-point Ethernet Optical Network Terminals (ONTs) |

[0001564590-16-022906:notes:131]
|  | · | Residential and business gateways |

[0001564590-16-022906:notes:132]
|  | · | Wi-Fi access points and associated powering and switching infrastructure |

[0001564590-16-022906:notes:133]
|  | · | enterprise Session Border Controllers (eSBC) |

[0001564590-16-022906:notes:134]
|  | · | Branch office and access routers |

[0001564590-16-022906:notes:135]
|  | · | Carrier Ethernet services termination devices |

[0001564590-16-022906:notes:136]
|  | · | VoIP media gateways |

[0001564590-16-022906:notes:137]
|  | · | ProServices® |

[0001564590-16-022906:notes:138]
|  | · | Planning, engineering, program management, maintenance, installation and commissioning services to implement the customer devices solutions into consumer, small business and enterprise locations |

[0001564590-16-022906:notes:139]
|  | · | Other products and services that are generally applicable to customer devices |

[0001564590-16-022906:notes:140]
Traditional & Other Products generally includes a mix of prior generation technologies’ products and services, as well as other products and services that do not fit within the Access & Aggregation or Customer Devices categories.

[0001564590-16-022906:notes:141]
The Traditional & Other Products category includes products and services such as:

[0001564590-16-022906:notes:142]
|  | · | Time Division Multiplexed (TDM) and Asynchronous Transfer Mode (ATM) based aggregation systems and customer devices |

[0001564590-16-022906:notes:143]
|  | · | HDSL, ADSL and other mature technologies used to deliver business and residential services over the CSP access and customer networks |

[0001564590-16-022906:notes:144]
|  | · | Other products and services that do not fit within the Access & Aggregation and Customer Devices categories |

[0001564590-16-022906:notes:145]
The table below presents sales information by category for the three and six months ended June 30, 2016 and 2015:

[0001564590-16-022906:notes:146]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Access & Aggregation |  | $ | 102,232 |  |  | $ | 112,732 |  |  | $ | 196,087 |  |  | $ | 205,583 |  |
| Customer Devices |  |  | 40,876 |  |  |  | 30,042 |  |  |  | 73,229 |  |  |  | 61,746 |  |
| Traditional & Other Products |  |  | 19,593 |  |  |  | 17,364 |  |  |  | 35,589 |  |  |  | 35,644 |  |
| Total |  | $ | 162,701 |  |  | $ | 160,138 |  |  | $ | 304,905 |  |  | $ | 302,973 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-16-022906:notes:147]
[same as prior period, unchanged from 0001193125-16-576994:notes:12]

[0001564590-16-022906:notes:148]
Our products generally include warranties of 90 days to ten years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.9 million and $8.7 million at June 30, 2016 and December 31, 2015, respectively. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0001564590-16-022906:notes:149]
A summary of warranty expense and write-off activity for the three and six months ended June 30, 2016 and 2015 is as follows:

[0001564590-16-022906:notes:150]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | June 30, |  | June 30, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 9,042 |  |  | $ | 8,684 |  | $ | 8,739 |  |  | $ | 8,415 |  |
| Plus:Amounts charged to cost and expenses |  |  | 1,431 |  |  |  | 667 |  |  | 2,329 |  |  |  | 1,128 |  |
| Less:Deductions |  |  | (1,538 | ) |  |  | (418 | ) |  | (2,133 | ) |  |  | (610 | ) |
| Balance at end of period |  | $ | 8,935 |  |  | $ | 8,933 |  | $ | 8,935 |  |  | $ | 8,933 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-022906:notes:151]
13. COMMITMENTS AND CONTINGENCIES

[0001564590-16-022906:notes:152]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-16-022906:notes:153]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2016, of which $7.7 million has been applied to these commitments.


## us-gaap:SubsequentEventsTextBlock

[0001564590-16-022906:notes:154]
14. SUBSEQUENT EVENTS

[0001564590-16-022906:notes:155]
On July 12, 2016, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on July 28, 2016. The payment date will be August 11, 2016. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-16-022906:notes:156]
During the third quarter and as of August 5, 2016, we have repurchased 0.3 million shares of our common stock through open market purchases at an average cost of $17.99 per share. We currently have the authority to purchase an additional 4.6 million shares of our common stock under the current plan approved by the Board of Directors.
