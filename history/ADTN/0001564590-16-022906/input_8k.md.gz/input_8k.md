# ADTN 8-K — 0001193125-16-646816 filed 2016-07-13

## item codes, every 8-K on or before 2016-08-05

- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2016-08-05

- none on or before 2016-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-646816:8k_2_02:1]
EX-99.1
2
d194802dex991.htm
EX-99.1

[0001193125-16-646816:8k_2_02:2]
EX-99.1

[0001193125-16-646816:8k_2_02:3]
EXHIBIT 99.1

[0001193125-16-646816:8k_2_02:4]
ADTRAN, Inc.

[0001193125-16-646816:8k_2_02:5]
REPORTS
RESULTS for the SECOND QUARTER 2016

[0001193125-16-646816:8k_2_02:6]
and DECLARES QUARTERLY CASH DIVIDEND

[0001193125-16-646816:8k_2_02:7]
HUNTSVILLE, AL.—July 12, 2016—ADTRAN, Inc. (NASDAQ:ADTN) reported results for the second quarter 2016. For the quarter, sales were $162,701,000
compared to $160,138,000 for the second quarter of 2015. Net income was $10,228,000 compared to $2,544,000 for the second quarter of 2015. Earnings per share, assuming dilution, were $0.21 compared to $0.05 for the second quarter of 2015. Non-GAAP
earnings per share were $0.25 compared to $0.10 for the second quarter of 2015. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-16-646816:8k_2_02:8]
ADTRAN Chief Executive Officer Tom Stanton stated, “ADTRAN delivered solid revenue and earnings results for the quarter due to strength in our domestic
market and gross margin improvement. Growth in the U.S. market was led by our FTTP and 100 megabit portfolios, along with continued growth in our CAF II and Ethernet solutions. Our Services business also continued its strong growth with a 51%
revenue increase year-over-year. Customers around the world are increasingly recognizing the benefits of deploying ultra-high speed broadband and are leveraging ADTRAN’s unique domain leadership and expertise in planning, developing and
deploying business and residential services.”

[0001193125-16-646816:8k_2_02:9]
The Company also announced that its Board of Directors declared a cash dividend for the second quarter
of 2016. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on July 28, 2016. The ex-dividend date is July 26, 2016 and the payment date is August 11, 2016.

[0001193125-16-646816:8k_2_02:10]
The Company confirmed that its second quarter conference call will be held Wednesday, July 13, 2016 at 9:30 a.m. Central Time. This conference call will be
web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the call and click on the conference call link provided.

[0001193125-16-646816:8k_2_02:11]
An online replay of the conference call will be available for seven days at www.streetevents.com. In addition, an online replay of the conference call, as
well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following the call.

[0001193125-16-646816:8k_2_02:12]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet
communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit
www.adtran.com.

[0001193125-16-646816:8k_2_02:13]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web, visit
www.adtran.com.

[0001193125-16-646816:8k_2_02:14]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known.
However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs,
manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2015 and Form 10-Q for the quarter ended March 31, 2016. These risks and uncertainties could cause actual results to
differ materially from those in the forward-looking statements included in this press release.

[0001193125-16-646816:8k_2_02:15]
| CONTACT: Roger Shannon Senior Vice President & CFO 256-963-8775 |  | INVESTOR SERVICES/ASSISTANCE: Gayle Ellis Investor Services 256-963-8220 |

[0001193125-16-646816:8k_2_02:16]
Condensed Consolidated Balance Sheet

[0001193125-16-646816:8k_2_02:17]
(Unaudited)

[0001193125-16-646816:8k_2_02:18]
(In
thousands)

[0001193125-16-646816:8k_2_02:19]
|  |  | June 30,2016 |  |  | December 31,2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 70,914 |  |  | $ | 84,550 |  |
| Short-term investments |  |  | 50,867 |  |  |  | 34,396 |  |
| Accounts receivable, net |  |  | 89,386 |  |  |  | 71,917 |  |
| Other receivables |  |  | 11,676 |  |  |  | 19,321 |  |
| Income tax receivable, net |  |  | 2,405 |  |  |  | — |  |
| Inventory |  |  | 86,936 |  |  |  | 91,533 |  |
| Prepaid expenses and other current assets |  |  | 13,563 |  |  |  | 10,145 |  |
| Deferred tax assets, net |  |  | 18,488 |  |  |  | 18,924 |  |
| Total Current Assets |  |  | 344,235 |  |  |  | 330,786 |  |
| Property, plant and equipment, net |  |  | 74,115 |  |  |  | 73,233 |  |
| Deferred tax assets, net |  |  | 19,127 |  |  |  | 18,091 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 9,340 |  |  |  | 9,276 |  |
| Long-term investments |  |  | 186,249 |  |  |  | 198,026 |  |
| Total Assets |  | $ | 636,558 |  |  | $ | 632,904 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 59,211 |  |  | $ | 48,668 |  |
| Unearned revenue |  |  | 15,982 |  |  |  | 16,615 |  |
| Accrued expenses |  |  | 12,126 |  |  |  | 12,108 |  |
| Accrued wages and benefits |  |  | 15,702 |  |  |  | 12,857 |  |
| Income tax payable, net |  |  | — |  |  |  | 2,395 |  |
| Total Current Liabilities |  |  | 103,021 |  |  |  | 92,643 |  |
| Non-current unearned revenue |  |  | 6,437 |  |  |  | 7,965 |  |
| Other non-current liabilities |  |  | 25,476 |  |  |  | 24,236 |  |
| Bonds payable |  |  | 27,900 |  |  |  | 27,900 |  |
| Total Liabilities |  |  | 162,834 |  |  |  | 152,744 |  |
| Stockholders’ Equity |  |  | 473,724 |  |  |  | 480,160 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 636,558 |  |  | $ | 632,904 |  |

[0001193125-16-646816:8k_2_02:20]
Consolidated Statements of Income

[0001193125-16-646816:8k_2_02:21]
(Unaudited)

[0001193125-16-646816:8k_2_02:22]
(In
thousands, except per share data)

[0001193125-16-646816:8k_2_02:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 138,549 |  |  | $ | 144,098 |  |  | $ | 262,432 |  |  | $ | 273,603 |  |
| Services |  |  | 24,152 |  |  |  | 16,040 |  |  |  | 42,473 |  |  |  | 29,370 |  |
| Total Sales |  |  | 162,701 |  |  |  | 160,138 |  |  |  | 304,905 |  |  |  | 302,973 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 67,844 |  |  |  | 84,210 |  |  |  | 131,917 |  |  |  | 155,770 |  |
| Services |  |  | 15,902 |  |  |  | 7,682 |  |  |  | 28,239 |  |  |  | 13,394 |  |
| Total Cost of Sales |  |  | 83,746 |  |  |  | 91,892 |  |  |  | 160,156 |  |  |  | 169,164 |  |
| Gross Profit |  |  | 78,955 |  |  |  | 68,246 |  |  |  | 144,749 |  |  |  | 133,809 |  |
| Selling, general and administrative expenses |  |  | 32,866 |  |  |  | 32,123 |  |  |  | 63,651 |  |  |  | 63,187 |  |
| Research and development expenses |  |  | 31,277 |  |  |  | 35,479 |  |  |  | 60,765 |  |  |  | 68,015 |  |
| Operating Income |  |  | 14,812 |  |  |  | 644 |  |  |  | 20,333 |  |  |  | 2,607 |  |
| Interest and dividend income |  |  | 927 |  |  |  | 908 |  |  |  | 1,782 |  |  |  | 1,841 |  |
| Interest expense |  |  | (142 | ) |  |  | (149 | ) |  |  | (287 | ) |  |  | (297 | ) |
| Net realized investment gain |  |  | 1,110 |  |  |  | 3,255 |  |  |  | 2,838 |  |  |  | 6,370 |  |
| Other expense, net |  |  | (251 | ) |  |  | (547 | ) |  |  | (132 | ) |  |  | (900 | ) |
| Income before provision for income taxes |  |  | 16,456 |  |  |  | 4,111 |  |  |  | 24,534 |  |  |  | 9,621 |  |
| Provision for income taxes |  |  | (6,228 | ) |  |  | (1,567 | ) |  |  | (9,292 | ) |  |  | (3,760 | ) |
| Net Income |  | $ | 10,228 |  |  | $ | 2,544 |  |  | $ | 15,242 |  |  | $ | 5,861 |  |
| Weighted average shares outstanding - basic |  |  | 48,831 |  |  |  | 51,822 |  |  |  | 49,026 |  |  |  | 52,607 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 49,048 |  |  |  | 51,917 |  |  |  | 49,218 |  |  |  | 52,742 |  |
| Earnings per common share - basic |  | $ | 0.21 |  |  | $ | 0.05 |  |  | $ | 0.31 |  |  | $ | 0.11 |  |
| Earnings per common share - diluted (1) |  | $ | 0.21 |  |  | $ | 0.05 |  |  | $ | 0.31 |  |  | $ | 0.11 |  |

[0001193125-16-646816:8k_2_02:24]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001193125-16-646816:8k_2_02:25]
Consolidated Statements of Comprehensive Income

[0001193125-16-646816:8k_2_02:26]
(Unaudited)

[0001193125-16-646816:8k_2_02:27]
(In
thousands)

[0001193125-16-646816:8k_2_02:28]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Net Income |  | $ | 10,228 |  |  | $ | 2,544 |  |  | $ | 15,242 |  |  | $ | 5,861 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized losses on available-for-sale securities |  |  | (165 | ) |  |  | (1,783 | ) |  |  | (420 | ) |  |  | (2,286 | ) |
| Defined benefit plan adjustments |  |  | 22 |  |  |  | 72 |  |  |  | 67 |  |  |  | 140 |  |
| Foreign currency translation |  |  | (601 | ) |  |  | 872 |  |  |  | 627 |  |  |  | (2,446 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  | (744 | ) |  |  | (839 | ) |  |  | 274 |  |  |  | (4,592 | ) |
| Comprehensive Income, net of tax |  | $ | 9,484 |  |  | $ | 1,705 |  |  | $ | 15,516 |  |  | $ | 1,269 |  |

[0001193125-16-646816:8k_2_02:29]
Consolidated Statements of Cash Flows

[0001193125-16-646816:8k_2_02:30]
(Unaudited)

[0001193125-16-646816:8k_2_02:31]
(In
thousands)

[0001193125-16-646816:8k_2_02:32]
|  |  | Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 15,242 |  |  | $ | 5,861 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 6,689 |  |  |  | 7,256 |  |
| Amortization of net premium on available-for-sale investments |  |  | 376 |  |  |  | 1,578 |  |
| Net realized gain on long-term investments |  |  | (2,838 | ) |  |  | (6,370 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 5 |  |  |  | 160 |  |
| Stock-based compensation expense |  |  | 3,109 |  |  |  | 3,114 |  |
| Deferred income taxes |  |  | (354 | ) |  |  | (1,743 | ) |
| Tax impact from stock option exercises |  |  | — |  |  |  | (23 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | — |  |  |  | 38 |  |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (17,192 | ) |  |  | (2,003 | ) |
| Other receivables |  |  | 7,876 |  |  |  | (119 | ) |
| Inventory |  |  | 4,938 |  |  |  | (14,254 | ) |
| Prepaid expenses and other assets |  |  | (4,263 | ) |  |  | (1,433 | ) |
| Accounts payable |  |  | 10,354 |  |  |  | 30,938 |  |
| Accrued expenses and other liabilities |  |  | 1,474 |  |  |  | 2,175 |  |
| Income tax payable/receivable, net |  |  | (4,799 | ) |  |  | (3,961 | ) |
| Net cash provided by operating activities |  |  | 20,617 |  |  |  | 21,214 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (6,679 | ) |  |  | (5,392 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 8 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 109,993 |  |  |  | 120,422 |  |
| Purchases of available-for-sale investments |  |  | (112,903 | ) |  |  | (62,626 | ) |
| Net cash provided by (used in) investing activities |  |  | (9,589 | ) |  |  | 52,412 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 541 |  |  |  | 833 |  |
| Purchases of treasury stock |  |  | (16,579 | ) |  |  | (49,307 | ) |
| Dividend payments |  |  | (8,860 | ) |  |  | (9,509 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | — |  |  |  | (38 | ) |
| Net cash used in financing activities |  |  | (24,898 | ) |  |  | (58,021 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (13,870 | ) |  |  | 15,605 |  |
| Effect of exchange rate changes |  |  | 234 |  |  |  | (1,829 | ) |
| Cash and cash equivalents, beginning of period |  |  | 84,550 |  |  |  | 73,439 |  |
| Cash and cash equivalents, end of period |  | $ | 70,914 |  |  | $ | 87,215 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 554 |  |  | $ | 270 |  |

[0001193125-16-646816:8k_2_02:33]
Supplemental Information

[0001193125-16-646816:8k_2_02:34]
Restructuring Expenses

[0001193125-16-646816:8k_2_02:35]
(Unaudited)

[0001193125-16-646816:8k_2_02:36]
(In
thousands)

[0001193125-16-646816:8k_2_02:37]
Restructuring expenses were recorded in the following Consolidated Statements of Income categories for the three and six months ended
June 30, 2016 and 2015:

[0001193125-16-646816:8k_2_02:38]
|  |  | Three and Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| Restructuring expense included in cost of sales |  | $ | — |  |  | $ | 98 |  |
| Selling, general and administrative expense |  |  | — |  |  |  | 644 |  |
| Research and development expense |  |  | — |  |  |  | 1,383 |  |
| Restructuring expense included in operating expenses |  |  | — |  |  |  | 2,027 |  |
| Total restructuring expense |  |  | — |  |  |  | 2,125 |  |
| Provision for income taxes |  |  | — |  |  |  | (829 | ) |
| Total restructuring expense, net of tax |  | $ | — |  |  | $ | 1,296 |  |

[0001193125-16-646816:8k_2_02:39]
Supplemental Information

[0001193125-16-646816:8k_2_02:40]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-16-646816:8k_2_02:41]
(Unaudited)

[0001193125-16-646816:8k_2_02:42]
(In
thousands)

[0001193125-16-646816:8k_2_02:43]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the
Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and six months ended June 30, 2016 and 2015 for both transactions are as follows:

[0001193125-16-646816:8k_2_02:44]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 173 |  |  | $ | 226 |  |  | $ | 346 |  |  | $ | 452 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 228 |  |  |  | 229 |  |  |  | 455 |  |  |  | 470 |  |
| Amortization of other purchase accounting adjustments |  |  | 44 |  |  |  | 140 |  |  |  | 80 |  |  |  | 294 |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | 35 |  |  |  | — |  |  |  | 41 |  |
| Subtotal |  |  | 272 |  |  |  | 404 |  |  |  | 535 |  |  |  | 805 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 445 |  |  |  | 630 |  |  |  | 881 |  |  |  | 1,257 |  |
| Provision for income taxes |  |  | (152 | ) |  |  | (213 | ) |  |  | (301 | ) |  |  | (426 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 293 |  |  | $ | 417 |  |  | $ | 580 |  |  | $ | 831 |  |

[0001193125-16-646816:8k_2_02:45]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three and six months ended June 30, 2016 and 2015:

[0001193125-16-646816:8k_2_02:46]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 131 |  |
| Cost of goods sold |  |  | 13 |  |  |  | 33 |  |  |  | 20 |  |  |  | 45 |  |
| Subtotal |  |  | 13 |  |  |  | 97 |  |  |  | 20 |  |  |  | 176 |  |
| Selling, general and administrative expenses |  |  | 4 |  |  |  | 39 |  |  |  | 7 |  |  |  | 51 |  |
| Research and development expenses |  |  | 428 |  |  |  | 494 |  |  |  | 854 |  |  |  | 1,030 |  |
| Subtotal |  |  | 432 |  |  |  | 533 |  |  |  | 861 |  |  |  | 1,081 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 445 |  |  |  | 630 |  |  |  | 881 |  |  |  | 1,257 |  |
| Provision for income taxes |  |  | (152 | ) |  |  | (213 | ) |  |  | (301 | ) |  |  | (426 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 293 |  |  | $ | 417 |  |  | $ | 580 |  |  | $ | 831 |  |

[0001193125-16-646816:8k_2_02:47]
Supplemental Information

[0001193125-16-646816:8k_2_02:48]
Stock-based Compensation Expense

[0001193125-16-646816:8k_2_02:49]
(Unaudited)

[0001193125-16-646816:8k_2_02:50]
(In
thousands)

[0001193125-16-646816:8k_2_02:51]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 95 |  |  | $ | 53 |  |  | $ | 194 |  |  | $ | 143 |  |
| Selling, general and administrative expense |  |  | 788 |  |  |  | 723 |  |  |  | 1,557 |  |  |  | 1,414 |  |
| Research and development expense |  |  | 668 |  |  |  | 699 |  |  |  | 1,358 |  |  |  | 1,557 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,456 |  |  |  | 1,422 |  |  |  | 2,915 |  |  |  | 2,971 |  |
| Total stock-based compensation expense |  |  | 1,551 |  |  |  | 1,475 |  |  |  | 3,109 |  |  |  | 3,114 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (213 | ) |  |  | (222 | ) |  |  | (425 | ) |  |  | (402 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,338 |  |  | $ | 1,253 |  |  | $ | 2,684 |  |  | $ | 2,712 |  |

[0001193125-16-646816:8k_2_02:52]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-16-646816:8k_2_02:53]
Non-GAAP net income per share, diluted

[0001193125-16-646816:8k_2_02:54]
(Unaudited)

[0001193125-16-646816:8k_2_02:55]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| GAAP earnings per common share – diluted |  | $ | 0.21 |  |  | $ | 0.05 |  |  | $ | 0.31 |  |  | $ | 0.11 |  |
| Restructuring expense |  |  | — |  |  |  | 0.02 |  |  |  | — |  |  |  | 0.02 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.02 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.02 |  |  |  | 0.05 |  |  |  | 0.05 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.25 |  |  | $ | 0.10 |  |  | $ | 0.37 |  |  | $ | 0.20 |  |
