# ADTN notes — 0001564590-18-012467


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-18-012467:notes:1]
[same as prior period, unchanged from 0001564590-17-022183:notes:1]

[0001564590-18-012467:notes:2]
[same as prior period, unchanged from 0001564590-17-022183:notes:2]

[0001564590-18-012467:notes:3]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (ADTRAN) have been prepared pursuant to the rules and regulations for reporting on Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles for complete financial statements are not included herein. The December 31, 2017 Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.

[0001564590-18-012467:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim statements should be read in conjunction with the financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2017, filed on February 23, 2018 with the SEC.

[0001564590-18-012467:notes:5]
[same as prior period, unchanged from 0001564590-17-022183:notes:5]

[0001564590-18-012467:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-18-012467:notes:7]
[same as prior period, unchanged from 0001564590-17-022183:notes:7]

[0001564590-18-012467:notes:8]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of ASU 2016-02 will have a material impact on our financial position; however, we do not believe adoption will have a material impact on our results of operations. We believe the most significant impact relates to our accounting for operating leases for office space and equipment.

[0001564590-18-012467:notes:9]
In January 2017, the FASB issued Accounting Standards Update No. 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04). ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material impact on our financial position, results of operations or cash flows.

[0001564590-18-012467:notes:10]
In August 2017, the FASB issued Accounting Standards Update No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (ASU 2017-12). ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating the impact ASU 2017-12 will have on our financial position, results of operations and cash flows.

[0001564590-18-012467:notes:11]
During 2018, we adopted the following accounting standards, which had no material effect on our financial position, results of operations or cash flows:

[0001564590-18-012467:notes:12]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We adopted ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method, which was applied to all contracts on the date of initial adoption.

[0001564590-18-012467:notes:13]
The two primary areas of impact of these ASUs were network implementation service revenue performance obligations and contract costs. The output method will be used to measure network implementation services progress. The primary impact will be accelerated revenue recognition for certain performance obligations related to service revenue arrangements that were previously deferred until customer acceptance and capitalization and amortization of incremental costs of obtaining a contract as described below.

[0001564590-18-012467:notes:14]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we adopted ASC 340-40, Other Assets and Deferred Costs - Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract will need to be capitalized, including sales commissions, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. The primary impact was capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and amortization of those costs over the period that the related revenue is recognized.

[0001564590-18-012467:notes:15]
The cumulative effect of the changes made to our Consolidated Balance Sheet on January 1, 2018 for the adoption of ASU 2014-09 and the related ASUs was as follows:

[0001564590-18-012467:notes:16]
| (In thousands) |  | Balance at December 31, 2017 |  |  | Adjustments due to ASU 2014-09 |  |  | Balance at January 1, 2018 |  |
| Other receivables |  | $ | 26,578 |  |  |  | 374 |  |  | $ | 26,952 |  |
| Deferred tax assets, net |  | $ | 23,428 |  |  |  | (96 | ) |  | $ | 23,332 |  |
| Retained earnings |  | $ | 922,178 |  |  |  | 278 |  |  | $ | 922,456 |  |

[0001564590-18-012467:notes:17]
The impact of the adoption of ASU 2014-09 and the related ASUs on our financial statements was as follows:

[0001564590-18-012467:notes:18]
|  |  | For the three months ended March 31, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Change Higher/(Lower) |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 105,253 |  |  |  | 105,439 |  |  | $ | (186 | ) |
| Services |  | $ | 15,553 |  |  |  | 14,700 |  |  | $ | 853 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 68,612 |  |  |  | 68,723 |  |  | $ | (111 | ) |
| Services |  | $ | 12,461 |  |  |  | 11,925 |  |  | $ | 536 |  |
| Loss before benefit for income taxes |  | $ | (14,745 | ) |  |  | (14,987 | ) |  | $ | 242 |  |
| Benefit for income taxes |  | $ | 3,931 |  |  |  | 3,998 |  |  | $ | (67 | ) |
| Net loss |  | $ | (10,814 | ) |  |  | (10,989 | ) |  | $ | 175 |  |

[0001564590-18-012467:notes:19]
|  |  | As of March 31, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Change Higher/(Lower) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other receivables |  | $ | 35,124 |  |  |  | 35,060 |  |  | $ | 64 |  |
| Inventory |  | $ | 120,021 |  |  |  | 119,910 |  |  | $ | 111 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 909,611 |  |  |  | 909,436 |  |  | $ | 175 |  |

[0001564590-18-012467:notes:20]
In January 2016, the FASB issued Accounting Standards Update 2016-01, Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities (ASU 2016-01) which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. ASU 2016-01 was effective beginning January 1, 2018 and we are now recognizing any changes in the fair value of certain equity investments in net income as prescribed by the new standard rather than in other comprehensive income. We adopted ASU 2016-01 on January 1, 2018 using the modified retrospective method, which resulted in $3.2 million reclassification of net unrealized gains from accumulated other comprehensive income to opening retained earnings.

[0001564590-18-012467:notes:21]
In March 2017, the FASB issued Accounting Standards Update No. 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost (ASU 2017-07). ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. We adopted ASU 2017-07 on January 1, 2018. We retrospectively adopted the presentation of service cost separate from other components of net periodic pension costs. As a result, $0.1 million was reclassified from cost of sales, selling, general and administrative expenses, and research and development expense to other income (expense), net for the three months ended March 31, 2017.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-012467:notes:22]
[same as prior period, unchanged from 0001564590-17-022183:notes:19]

[0001564590-18-012467:notes:23]
On March 19, 2018, we acquired Sumitomo Electric Lightwave Corp.’s (SEL) North American EPON business and entered into a technology license and OEM supply agreement with Sumitomo Electric Industries, Ltd. (SEI). This acquisition establishes ADTRAN as the North American market leader for EPON solutions for the cable MSO industry and will accelerate the MSO market’s adoption of our open, programmable and scalable architectures. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. These revenues are included in the Access & Aggregation and Customer Devices categories within the Network Solutions reportable segment.

[0001564590-18-012467:notes:24]
We recorded a bargain purchase gain of $11.3 million during the first quarter of 2018, net of income taxes, which is subject to customary working capital adjustments between the parties. The bargain purchase gain of $11.3 million represents the difference between the fair value of the net assets acquired over the cash paid. SEI, an OEM supplier based in Japan, is a market leader in EPON. SEI’s Broadband Networks Division through its SEL subsidiary operated a North American EPON business including sales, marketing, support, and region-specific engineering development. The North American EPON market is primarily driven by the Tier 1 cable MSO operators and has developed slower than anticipated. Through the transaction, SEI divested its North American EPON assets and established a relationship with ADTRAN. The transfer of these assets to ADTRAN, which included key customer relationships and required assumption by ADTRAN of relatively low incremental expenses, along with the value of the technology license and OEM supply agreement, resulted in the bargain purchase gain. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and have concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-18-012467:notes:25]
The preliminary allocation of the purchase price to the estimated fair value of the assets acquired at the acquisition date is as follows:

[0001564590-18-012467:notes:26]
| (In Thousands) |  |  |  |
| Assets |  |  |  |
| Other receivables | $ | 104 |  |
| Inventory |  | 510 |  |
| Property, plant and equipment |  | 392 |  |
| Intangible assets |  | 22,100 |  |
| Total assets acquired |  | 23,106 |  |
| Liabilities |  |  |  |
| Deferred income taxes |  | (3,978 | ) |
| Total liabilities assumed |  | (3,978 | ) |
| Total net assets |  | 19,128 |  |
| Gain on bargain purchase of a business, net of tax |  | (11,322 | ) |
| Total purchase price | $ | 7,806 |  |

[0001564590-18-012467:notes:27]
The actual revenue and net loss included in our Consolidated Statements of Income for the period March 19, 2018 to March 31, 2018 are as follows:

[0001564590-18-012467:notes:28]
|  | March 19 to |  |
| (In thousands) | March 31, 2018 |  |
| Revenue | $ | — |  |
| Net loss | $ | (77 | ) |

[0001564590-18-012467:notes:29]
[same as prior period, unchanged from 0001564590-17-022183:notes:24]

[0001564590-18-012467:notes:30]
| In thousands | Value |  |  | Life (years) |  |
| Customer relationships | $ | 13,400 |  |  |  | 12.0 |  |
| Licensed technology |  | 5,900 |  |  |  | 9.0 |  |
| Supplier relationship |  | 2,800 |  |  |  | 2.0 |  |
| Total | $ | 22,100 |  |  |  |  |  |

[0001564590-18-012467:notes:31]
The following unaudited supplemental pro forma information presents the financial results as if the acquisition had occurred on January 1, 2017. This unaudited supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2017, nor is it indicative of any future results. Aside from revising the 2017 and 2018 net income for the effect of the bargain purchase gain, there were no material, non-recurring adjustments to this unaudited pro forma information.

[0001564590-18-012467:notes:32]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Pro forma revenue |  | $ | 122,066 |  |  | $ | 170,692 |  |
| Pro forma net income |  | $ | (22,720 | ) |  | $ | 17,201 |  |
| Pro forma earnings per share - basic |  | $ | (0.47 | ) |  | $ | 0.36 |  |
| Pro forma earnings per share - diluted |  | $ | (0.47 | ) |  | $ | 0.35 |  |

[0001564590-18-012467:notes:33]
For the three months ended March 31, 2018, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $0.2 million related to this acquisition.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-18-012467:notes:34]
3. REVENUE

[0001564590-18-012467:notes:35]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product or service to the customer. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices using the most likely amount. The stand-alone selling prices are determined based on the prices at which we sell the separate products and services. For items that are not sold separately, we estimate stand-alone selling prices primarily using reasonable internal analysis. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value added, and other taxes collected concurrent with revenue-producing activities are excluded from revenue. Costs of obtaining a contract are capitalized and amortized over the period that the related revenue is recognized. We have elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0001564590-18-012467:notes:36]
The following is a description of the principal activities from which we generate our revenue by reportable segment.

[0001564590-18-012467:notes:37]
Network Solutions Segment

[0001564590-18-012467:notes:38]
Network Solutions includes hardware products and next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

[0001564590-18-012467:notes:39]
Hardware

[0001564590-18-012467:notes:40]
The majority of the revenue from this segment is from hardware sales and is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. Revenue is recorded net of discounts and rebates using the most likely amount. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

[0001564590-18-012467:notes:41]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment, which have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term.

[0001564590-18-012467:notes:42]
Services & Support Segment

[0001564590-18-012467:notes:43]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, solutions integration and managed services, which include hosted, cloud services and subscription services.

[0001564590-18-012467:notes:44]
Maintenance

[0001564590-18-012467:notes:45]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period, which is recorded in current or non-current unearned revenue depending on the length of the service period. Maintenance services are provided on an as-needed basis and our customers benefit evenly throughout the contract term. Accordingly, we recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue.

[0001564590-18-012467:notes:46]
Network Implementation

[0001564590-18-012467:notes:47]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services, when performance obligations are complete at a point in time. If we have recognized revenue, but not billed the customer, the right to consideration is recognized as a contract asset, which is included in other receivables in the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the right to consideration to payment becomes unconditional.

[0001564590-18-012467:notes:48]
As of March 31, 2018, we did not have any remaining performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

[0001564590-18-012467:notes:49]
The following table provides information about receivables, contract assets, and unearned revenue from contracts with customers:

[0001564590-18-012467:notes:50]
| (In thousands) |  | March 31, 2018 |  |  | December 31, 2017 |  |
| Accounts receivable |  | $ | 80,883 |  |  | $ | 144,150 |  |
| Contract assets |  |  | 1,442 |  |  |  | — |  |
| Unearned revenue |  |  | 13,948 |  |  |  | 13,070 |  |
| Non-current unearned revenue |  |  | 4,154 |  |  |  | 4,556 |  |

[0001564590-18-012467:notes:51]
During the three months ended March 31, 2018, we recognized $3.5 million of revenue that was included in unearned revenue at the beginning of the period.

[0001564590-18-012467:notes:52]
The following table disaggregates our revenue by major source:

[0001564590-18-012467:notes:53]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,385 |  |  | $ | 12,295 |  |  | $ | 81,680 |  |
| Customer Devices |  |  | 28,777 |  |  |  | 1,324 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,091 |  |  |  | 1,934 |  |  |  | 9,025 |  |
| Total |  | $ | 105,253 |  |  | $ | 15,553 |  |  | $ | 120,806 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-012467:notes:54]
4. INCOME TAXES

[0001564590-18-012467:notes:55]
Our effective tax rate decreased from 20.3% in the three months ended March 31, 2017, to 15.1%, excluding the tax impact of the bargain purchase gain, in the three months ended March 31, 2018. The decrease in the effective tax rate between the two periods is primarily attributable to the impact of the Tax Cuts and Jobs Act, which was signed into law on December 22, 2017.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-18-012467:notes:56]
5. PENSION BENEFIT PLAN

[0001564590-18-012467:notes:57]
[same as prior period, unchanged from 0001564590-17-022183:notes:32]

[0001564590-18-012467:notes:58]
The following table summarizes the components of net periodic pension cost for the three months ended March 31, 2018 and 2017:

[0001564590-18-012467:notes:59]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Service cost |  | $ | 308 |  |  | $ | 297 |  |
| Interest cost |  |  | 187 |  |  |  | 143 |  |
| Expected return on plan assets |  |  | (399 | ) |  |  | (299 | ) |
| Amortization of actuarial losses |  |  | 64 |  |  |  | 73 |  |
| Net periodic pension cost |  | $ | 160 |  |  | $ | 214 |  |

[0001564590-18-012467:notes:60]
The components of net periodic pension cost other than the service cost component are included in the line item “Other income (expense), net” in the Consolidated Statements of Income.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-012467:notes:61]
6. STOCK-BASED COMPENSATION

[0001564590-18-012467:notes:62]
The following table summarizes the stock-based compensation expense related to stock options, performance stock units (PSUs), restricted stock units (RSUs) and restricted stock for the three months ended March 31, 2018 and 2017, which was recognized as follows:

[0001564590-18-012467:notes:63]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 95 |  |  | $ | 91 |  |
| Selling, general and administrative expense |  |  | 1,035 |  |  |  | 1,016 |  |
| Research and development expense |  |  | 689 |  |  |  | 776 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,724 |  |  |  | 1,792 |  |
| Total stock-based compensation expense |  |  | 1,819 |  |  |  | 1,883 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (384 | ) |  |  | (380 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,435 |  |  | $ | 1,503 |  |

[0001564590-18-012467:notes:64]
[same as prior period, unchanged from 0001564590-17-022183:notes:38]

[0001564590-18-012467:notes:65]
The following table is a summary of our stock options outstanding as of December 31, 2017 and March 31, 2018 and the changes that occurred during the three months ended March 31, 2018:

[0001564590-18-012467:notes:66]
| (In thousands, except per share amounts) |  | Number of Stock Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Stock options outstanding, December 31, 2017 |  |  | 5,148 |  |  | $ | 22.65 |  |  |  | 4.87 |  |  | $ | 6,109 |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (24 | ) |  | $ | 15.48 |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (27 | ) |  | $ | 16.59 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (58 | ) |  | $ | 26.87 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, March 31, 2018 |  |  | 5,039 |  |  | $ | 22.66 |  |  |  | 4.50 |  |  | $ | 271 |  |
| Stock options vested and expected to vest, March 31, 2018 |  |  | 5,039 |  |  | $ | 22.66 |  |  |  | 4.50 |  |  | $ | 271 |  |
| Stock options exercisable, March 31, 2018 |  |  | 4,286 |  |  | $ | 23.75 |  |  |  | 4.00 |  |  | $ | 157 |  |

[0001564590-18-012467:notes:67]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between the closing price of our stock on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money stock options) that would have been received by the option holders had all option holders exercised their options on March 31, 2018. The aggregate intrinsic value will change based on the fair market value of our stock.

[0001564590-18-012467:notes:68]
The total pre-tax intrinsic value of options exercised during the three months ended March 31, 2018 was $33 thousand.

[0001564590-18-012467:notes:69]
As of March 31, 2018, there was $2.5 million of unrecognized compensation expense related to unvested stock options, which is expected to be recognized over an average remaining recognition period of 1.3 years.

[0001564590-18-012467:notes:70]
[same as prior period, unchanged from 0001564590-17-022183:notes:44]

[0001564590-18-012467:notes:71]
There were no stock options granted during the three months ended March 31, 2018 or 2017.

[0001564590-18-012467:notes:72]
[same as prior period, unchanged from 0001564590-17-022183:notes:47]

[0001564590-18-012467:notes:73]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2017 and the changes that occurred during the three months ended March 31, 2018:

[0001564590-18-012467:notes:74]
| (In thousands, except per share amounts) |  | Number of Shares |  |  | Weighted Avg. Grant Date Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2017 |  |  | 1,292 |  |  | $ | 21.33 |  |
| PSUs, RSUs and restricted stock granted |  |  | 8 |  |  | $ | 20.71 |  |
| PSUs, RSUs and restricted stock vested |  |  | (5 | ) |  | $ | 20.00 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (62 | ) |  | $ | 21.50 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, March 31, 2018 |  |  | 1,233 |  |  | $ | 21.31 |  |

[0001564590-18-012467:notes:75]
[same as prior period, unchanged from 0001564590-17-022183:notes:50]

[0001564590-18-012467:notes:76]
As of March 31, 2018, there was $12.9 million of unrecognized compensation expense related to unvested market-based PSUs, RSUs and restricted stock, which is expected to be recognized over an average remaining recognition period of 2.9 years. In addition, there was $10.7 million of unrecognized compensation expense related to unvested performance-based PSUs, which will be recognized over the requisite service period of three years as achievement of the performance objective becomes probable. For the three months ended March 31, 2018, no compensation expense was recognized related to these performance-based PSU awards.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-18-012467:notes:77]
7. INVESTMENTS

[0001564590-18-012467:notes:78]
Debt Securities and Other Investments

[0001564590-18-012467:notes:79]
At March 31, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-18-012467:notes:80]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  |  | 49,109 |  |  |  | 43 |  |  |  | (333 | ) |  |  | 48,819 |  |
| Municipal fixed-rate bonds |  |  | 2,413 |  |  |  | — |  |  |  | (30 | ) |  |  | 2,383 |  |
| Asset-backed bonds |  |  | 13,334 |  |  |  | — |  |  |  | (44 | ) |  |  | 13,290 |  |
| Mortgage/Agency-backed bonds |  |  | 8,906 |  |  |  | 2 |  |  |  | (72 | ) |  |  | 8,836 |  |
| U.S. government bonds |  |  | 14,703 |  |  |  | 10 |  |  |  | (204 | ) |  |  | 14,509 |  |
| Foreign government bonds |  |  | 1,228 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 1,231 |  |
| Available-for-sale debt securities held at fair value |  | $ | 89,693 |  |  | $ | 59 |  |  | $ | (684 | ) |  | $ | 89,068 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 26,700 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 520 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 116,288 |  |

[0001564590-18-012467:notes:81]
At December 31, 2017, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-18-012467:notes:82]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  |  | 32,654 |  |  |  | 44 |  |  |  | (155 | ) |  |  | 32,543 |  |
| Municipal fixed-rate bonds |  |  | 2,902 |  |  |  | 2 |  |  |  | (22 | ) |  |  | 2,882 |  |
| Asset-backed bonds |  |  | 6,545 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 6,526 |  |
| Mortgage/Agency-backed bonds |  |  | 5,554 |  |  |  | 1 |  |  |  | (46 | ) |  |  | 5,509 |  |
| U.S. government bonds |  |  | 14,477 |  |  |  | — |  |  |  | (174 | ) |  |  | 14,303 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 5 |  |  |  | — |  |  |  | 730 |  |
| Available-for-sale debt securities held at fair value |  | $ | 62,857 |  |  | $ | 53 |  |  | $ | (417 | ) |  | $ | 62,493 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 90,840 |  |

[0001564590-18-012467:notes:83]
As of March 31, 2018, our debt securities had the following contractual maturities:

[0001564590-18-012467:notes:84]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 11,391 |  |  | $ | 490 |  |  | $ | 4,520 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 18,406 |  |  |  | 737 |  |  | $ | 2,459 |  |  |  | — |  |  |  | 6,149 |  |  |  | — |  |
| Two to three years |  |  | 10,639 |  |  |  | 210 |  |  |  | 2,669 |  |  |  | — |  |  |  | 2,491 |  |  |  | 1,231 |  |
| Three to five years |  |  | 8,383 |  |  |  | 946 |  |  |  | 1,631 |  |  |  | 2,046 |  |  |  | 5,869 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 974 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 2,011 |  |  |  | 5,816 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 48,819 |  |  | $ | 2,383 |  |  | $ | 13,290 |  |  | $ | 8,836 |  |  | $ | 14,509 |  |  | $ | 1,231 |  |

[0001564590-18-012467:notes:85]
Actual maturities may differ from contractual maturities because some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-18-012467:notes:86]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:

[0001564590-18-012467:notes:87]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Gross realized gains |  | $ | — |  |  | $ | — |  |
| Gross realized losses |  | $ | (73 | ) |  | $ | (15 | ) |

[0001564590-18-012467:notes:88]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-18-012467:notes:89]
At March 31, 2018, we held a $26.7 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $26.7 million at March 31, 2018 and December 31, 2017. At March 31, 2018 and December 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $26.6 million and $26.7 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

[0001564590-18-012467:notes:90]
Marketable Equity Securities

[0001564590-18-012467:notes:91]
Our marketable equity securities consist of publicly traded stocks or funds measured at fair value.

[0001564590-18-012467:notes:92]
Prior to January 1, 2018, our marketable equity securities were classified as available-for-sale. Realized gains and losses on marketable equity securities were included in net realized investment gain (loss). Unrealized gains and losses were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet.

[0001564590-18-012467:notes:93]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net realized investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income to opening retained earnings.

[0001564590-18-012467:notes:94]
Realized and unrealized gains and losses for our marketable equity securities for the three months ended March 31, 2018 were as follows:

[0001564590-18-012467:notes:95]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (1 | ) |
| Unrealized gains (losses) on equity securities held |  |  | (23 | ) |
| Total gain (loss) recognized, net |  | $ | (24 | ) |

[0001564590-18-012467:notes:96]
As of March 31, 2018 and 2017, gross unrealized losses related to individual investments in a continuous loss position for 12 months or longer were not significant.

[0001564590-18-012467:notes:97]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows:  Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-18-012467:notes:98]
|  |  | Fair Value Measurements at March 31, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,770 |  |  | $ | 6,770 |  |  | $ | — |  |  | $ | — |  |
| Asset-backed securities |  |  | 1,000 |  |  |  | — |  |  |  | 1,000 |  |  |  | — |  |
| Cash equivalents |  |  | 7,770 |  |  |  | 6,770 |  |  |  | 1,000 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 48,819 |  |  |  | — |  |  |  | 48,819 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,383 |  |  |  | — |  |  |  | 2,383 |  |  |  | — |  |
| Asset-backed bonds |  |  | 13,290 |  |  |  | — |  |  |  | 13,290 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,836 |  |  |  | — |  |  |  | 8,836 |  |  |  | — |  |
| U.S. government bonds |  |  | 14,509 |  |  |  | 14,509 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,231 |  |  |  | — |  |  |  | 1,231 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 36,519 |  |  |  | 36,519 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,067 |  |  |  | 20,067 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 145,654 |  |  |  | 71,095 |  |  |  | 74,559 |  |  |  | — |  |
| Total |  | $ | 153,424 |  |  | $ | 77,865 |  |  | $ | 75,559 |  |  | $ | — |  |

[0001564590-18-012467:notes:99]
|  |  | Fair Value Measurements at December 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,851 |  |  | $ | 5,851 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 3,999 |  |  |  | — |  |  |  | 3,999 |  |  |  | — |  |
| Cash equivalents |  |  | 9,850 |  |  |  | 5,851 |  |  |  | 3,999 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 32,543 |  |  |  | — |  |  |  | 32,543 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,882 |  |  |  | — |  |  |  | 2,882 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,526 |  |  |  | — |  |  |  | 6,526 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,509 |  |  |  | — |  |  |  | 5,509 |  |  |  | — |  |
| U.S. government bonds |  |  | 14,303 |  |  |  | 14,303 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 730 |  |  |  | — |  |  |  | 730 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,662 |  |  |  | 35,662 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 19,883 |  |  |  | 19,883 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 118,038 |  |  |  | 69,848 |  |  |  | 48,190 |  |  |  | — |  |
| Total |  | $ | 127,888 |  |  | $ | 75,699 |  |  | $ | 52,189 |  |  | $ | — |  |

[0001564590-18-012467:notes:100]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-012467:notes:101]
8. DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001564590-18-012467:notes:102]
[same as prior period, unchanged from 0001564590-17-022183:notes:72]

[0001564590-18-012467:notes:103]
[same as prior period, unchanged from 0001564590-17-022183:notes:73]

[0001564590-18-012467:notes:104]
Our cash flow hedging activities utilize foreign exchange forward contracts to reduce the risk that movements in exchange rates will adversely affect the net cash flows resulting from the planned purchase of products from foreign suppliers. Purchases of U.S. denominated inventory by our European subsidiary represent our primary exposure. Changes in the fair value of derivatives designated as cash flow hedges are not recognized in current operating results, but are recorded in accumulated other comprehensive income.  Amounts related to cash flow hedges are reclassified from accumulated other comprehensive income when the underlying hedged item impacts earnings. This reclassification is recorded in the same line item of the consolidated statements of income at which the effects of the hedged item are recorded, which is cost of sales.

[0001564590-18-012467:notes:105]
[same as prior period, unchanged from 0001564590-17-022183:notes:75]

[0001564590-18-012467:notes:106]
[same as prior period, unchanged from 0001564590-17-022183:notes:76]

[0001564590-18-012467:notes:107]
[same as prior period, unchanged from 0001564590-17-022183:notes:78]

[0001564590-18-012467:notes:108]
As of March 31, 2018, we had no foreign exchange forward contracts.

[0001564590-18-012467:notes:109]
The change in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the three months ended March 31, 2018 and 2017 were as follows:

[0001564590-18-012467:notes:110]
|  |  |  |  | Three Months Ended |  |
|  |  | Income Statement |  | March 31, |  |
| (In thousands) |  | Location |  | 2018 |  |  | 2017 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | 13 |  |  | $ | (34 | ) |

[0001564590-18-012467:notes:111]
The change in our derivatives designated as hedging instruments recorded in other comprehensive income (OCI) and reclassified to income, net of tax, during the three months ended March 31, 2018 and 2017 were as follows:

[0001564590-18-012467:notes:112]
|  |  | Amount of Gains (Losses) Recognized in |  |  |  |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  |  |  | from AOCI into Income |  |
|  |  | Three Months Ended |  |  | Location of Gains |  | Three Months Ended |  |
|  |  | March 31, |  |  | (Losses) Reclassified |  | March 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | from AOCI into Income |  | 2018 |  |  | 2017 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | — |  |  | $ | 79 |  |  | Cost of Sales |  | $ | — |  |  | $ | — |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-18-012467:notes:113]
9. INVENTORY

[0001564590-18-012467:notes:114]
At March 31, 2018 and December 31, 2017, inventory consisted of the following:

[0001564590-18-012467:notes:115]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Raw materials |  | $ | 45,772 |  |  | $ | 44,185 |  |
| Work in process |  |  | 2,242 |  |  |  | 1,939 |  |
| Finished goods |  |  | 72,007 |  |  |  | 76,418 |  |
| Total |  | $ | 120,021 |  |  | $ | 122,542 |  |

[0001564590-18-012467:notes:116]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At March 31, 2018 and December 31, 2017, raw materials reserves totaled $15.2 million and $15.0 million, respectively, and finished goods inventory reserves totaled $8.9 million and $8.3 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-18-012467:notes:117]
10. GOODWILL AND INTANGIBLE ASSETS

[0001564590-18-012467:notes:118]
Goodwill, all of which relates to our acquisition of Bluesocket, Inc., was $3.5 million at March 31, 2018 and December 31, 2017, of which $3.1 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-18-012467:notes:119]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2017, we concluded that it was not necessary to perform the two-step impairment test. There have been no impairment losses recognized since the acquisition in 2011.

[0001564590-18-012467:notes:120]
Intangible assets are included in other assets in the accompanying Consolidated Balance Sheets and include intangibles acquired in conjunction with our acquisitions of Bluesocket, Inc. on August 4, 2011, the NSN BBA business on May 4, 2012, CommScope’s active fiber access business on September 13, 2016 and Sumitomo Electric Lightwave Corp.’s North American EPON business and technology license and OEM supply agreement with Sumitomo Electric Industries, Ltd. on March 19, 2018.

[0001564590-18-012467:notes:121]
The following table presents our intangible assets as of March 31, 2018 and December 31, 2017. Fully amortized intangible assets have been removed from prior year balances for comparability.

[0001564590-18-012467:notes:122]
| (In thousands) |  | March 31, 2018 |  |  | December 31, 2017 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 20,998 |  |  | $ | (4,576 | ) |  | $ | 16,422 |  |  | $ | 7,474 |  |  | $ | (4,283 | ) |  | $ | 3,191 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (27 | ) |  |  | 5,873 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Developed technology |  |  | 5,597 |  |  |  | (4,827 | ) |  |  | 770 |  |  |  | 5,524 |  |  |  | (4,663 | ) |  |  | 861 |  |
| Supplier relationship |  |  | 2,800 |  |  |  | (58 | ) |  |  | 2,742 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Intellectual property |  |  | 930 |  |  |  | (886 | ) |  |  | 44 |  |  |  | 930 |  |  |  | (852 | ) |  |  | 78 |  |
| Patent |  |  | 500 |  |  |  | (106 | ) |  |  | 394 |  |  |  | 500 |  |  |  | (89 | ) |  |  | 411 |  |
| Non-compete |  |  | 200 |  |  |  | (137 | ) |  |  | 63 |  |  |  | 200 |  |  |  | (115 | ) |  |  | 85 |  |
| Trade names |  |  | 100 |  |  |  | (77 | ) |  |  | 23 |  |  |  | 100 |  |  |  | (65 | ) |  |  | 35 |  |
| Total |  | $ | 37,025 |  |  | $ | (10,694 | ) |  | $ | 26,331 |  |  | $ | 14,728 |  |  | $ | (10,067 | ) |  | $ | 4,661 |  |

[0001564590-18-012467:notes:123]
Amortization expense, all of which relates to business acquisitions, was $0.4 million and $1.1 million for the three months ended March 31, 2018 and 2017, respectively.

[0001564590-18-012467:notes:124]
As of March 31, 2018, the estimated future amortization expense of our intangible assets is as follows:

[0001564590-18-012467:notes:125]
| (In thousands) |  | Amount |  |
| Remainder of 2018 |  | $ | 2,833 |  |
| 2019 |  |  | 3,559 |  |
| 2020 |  |  | 2,676 |  |
| 2021 |  |  | 2,380 |  |
| 2022 |  |  | 2,366 |  |
| Thereafter |  |  | 12,517 |  |
| Total |  | $ | 26,331 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-18-012467:notes:126]
11. STOCKHOLDERS’ EQUITY

[0001564590-18-012467:notes:127]
A summary of the changes in stockholders’ equity for the three months ended March 31, 2018 is as follows:

[0001564590-18-012467:notes:128]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2017 |  | $ | 497,911 |  |
| Net income |  |  | (10,814 | ) |
| Dividend payments |  |  | (4,367 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (2 | ) |
| Net unrealized gains (losses) on available-for-sale securities (net of tax) |  |  | (3,412 | ) |
| Defined benefit plan adjustments (net of tax) |  |  | 62 |  |
| Foreign currency translation adjustment |  |  | 842 |  |
| Proceeds from stock option exercises |  |  | 369 |  |
| Purchase of treasury stock |  |  | (10,171 | ) |
| Adoption of new accounting standards (see note 1) |  |  | 3,499 |  |
| Stock-based compensation expense |  |  | 1,819 |  |
| Balance, March 31, 2018 |  | $ | 475,736 |  |

[0001564590-18-012467:notes:129]
[same as prior period, unchanged from 0001564590-17-022183:notes:102]

[0001564590-18-012467:notes:130]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the three months ended March 31, 2018, we repurchased 0.6 million shares of our common stock at an average price of $16.18 per share. As of March 31, 2018, we have the authority to purchase an additional 2.9 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-18-012467:notes:131]
[same as prior period, unchanged from 0001564590-17-022183:notes:104]

[0001564590-18-012467:notes:132]
We issued 24 thousand shares of treasury stock during the three months ended March 31, 2018 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $0.4 million from the exercise of these stock options during the three months ended March 31, 2018.

[0001564590-18-012467:notes:133]
[same as prior period, unchanged from 0001564590-17-022183:notes:106]

[0001564590-18-012467:notes:134]
During the three months ended March 31, 2018, we paid cash dividends as follows (in thousands except per share amounts):

[0001564590-18-012467:notes:135]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| January 31, 2018 |  | February 14, 2018 |  | $ | 0.09 |  |  | $ | 4,367 |  |

[0001564590-18-012467:notes:136]
[same as prior period, unchanged from 0001564590-17-022183:notes:109]

[0001564590-18-012467:notes:137]
[same as prior period, unchanged from 0001564590-17-022183:notes:110]

[0001564590-18-012467:notes:138]
The following tables present the changes in accumulated other comprehensive income, net of tax, by component for the three months ended March 31, 2018 and 2017:

[0001564590-18-012467:notes:139]
|  |  | Three Months Ended March 31, 2018 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 2,567 |  |  | $ | (4,286 | ) |  | $ | (1,576 | ) |  | $ | (3,295 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (257 | ) |  |  | — |  |  |  | 842 |  |  |  | 585 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | 65 |  |  |  | 62 |  |  |  | — |  |  |  | 127 |  |
| Amounts reclassified to retained earnings (1) |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |
| Net current period other comprehensive income (loss) |  |  | (3,412 | ) |  |  | 62 |  |  |  | 842 |  |  |  | (2,508 | ) |
| Ending balance |  | $ | (845 | ) |  | $ | (4,224 | ) |  | $ | (734 | ) |  | $ | (5,803 | ) |

[0001564590-18-012467:notes:140]
|  | (1) | With the adoption of ASU 2016-01, the unrealized gains on our equity investments were reclassified to retained earnings. See note 1 for more information. |

[0001564590-18-012467:notes:141]
|  |  | Three Months Ended March 31, 2017 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 404 |  |  | $ | — |  |  | $ | (5,017 | ) |  | $ | (7,575 | ) |  | $ | (12,188 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,620 |  |  |  | 79 |  |  |  | — |  |  |  | 1,242 |  |  |  | 2,941 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (285 | ) |  |  | — |  |  |  | 55 |  |  |  | — |  |  |  | (230 | ) |
| Net current period other comprehensive income (loss) |  |  | 1,335 |  |  |  | 79 |  |  |  | 55 |  |  |  | 1,242 |  |  |  | 2,711 |  |
| Ending balance |  | $ | 1,739 |  |  | $ | 79 |  |  | $ | (4,962 | ) |  | $ | (6,333 | ) |  | $ | (9,477 | ) |

[0001564590-18-012467:notes:142]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the three months ended March 31, 2018 and 2017:

[0001564590-18-012467:notes:143]
| (In thousands) |  | Three Months Ended March 31, 2018 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | (73 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (90 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (163 | ) |  |  |
| Tax (expense) benefit |  |  | 36 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (127 | ) |  |  |

[0001564590-18-012467:notes:144]
| (1) | Included in the computation of net periodic pension cost. See Note 5 of Notes to Consolidated Financial Statements. |

[0001564590-18-012467:notes:145]
| (In thousands) |  | Three Months Ended March 31, 2017 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 572 |  |  | Net realized investment gain |
| Impairment expense |  |  | (103 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (80 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 389 |  |  |  |
| Tax (expense) benefit |  |  | (159 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 230 |  |  |  |

[0001564590-18-012467:notes:146]
|  | (1) | Included in the computation of net periodic pension cost. See Note 5 of Notes to Consolidated Financial Statements. |

[0001564590-18-012467:notes:147]
The following table presents the tax effects related to the change in each component of other comprehensive income for the three months ended March 31, 2018 and 2017:

[0001564590-18-012467:notes:148]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (347 | ) |  | $ | 90 |  |  | $ | (257 | ) |  | $ | 2,656 |  |  | $ | (1,036 | ) |  | $ | 1,620 |  |
| Unrealized gains (losses) on cash flow hedges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 79 |  |  |  | — |  |  |  | 79 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | 73 |  |  |  | (8 | ) |  |  | 65 |  |  |  | (469 | ) |  |  | 184 |  |  |  | (285 | ) |
| Reclassification adjustment for amounts reclassed to retained earnings related to the adoption of ASU 2016-01 |  |  | (3,220 | ) |  |  | — |  |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 90 |  |  |  | (28 | ) |  |  | 62 |  |  |  | 80 |  |  |  | (25 | ) |  |  | 55 |  |
| Foreign currency translation adjustment |  |  | 842 |  |  |  | — |  |  |  | 842 |  |  |  | 1,242 |  |  |  | — |  |  |  | 1,242 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (2,562 | ) |  | $ | 54 |  |  | $ | (2,508 | ) |  | $ | 3,588 |  |  | $ | (877 | ) |  | $ | 2,711 |  |


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-012467:notes:149]
12. EARNINGS PER SHARE

[0001564590-18-012467:notes:150]
A summary of the calculation of basic and diluted earnings per share for the three months ended March 31, 2018 and 2017 is as follows:

[0001564590-18-012467:notes:151]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (10,814 | ) |  | $ | 6,651 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,232 |  |  |  | 48,430 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| Stock options |  |  | 24 |  |  |  | 416 |  |
| PSUs, RSUs and restricted stock |  |  | 36 |  |  |  | 93 |  |
| Weighted average number of shares – diluted |  |  | 48,292 |  |  |  | 48,939 |  |
| Net income (loss) per share – basic |  | $ | (0.22 | ) |  | $ | 0.14 |  |
| Net income (loss) per share – diluted |  | $ | (0.22 | ) |  | $ | 0.14 |  |

[0001564590-18-012467:notes:152]
Anti-dilutive options to purchase common stock outstanding were excluded from the above calculations. Anti-dilutive options totaled 4.8 million and 4.0 million for the three months ended March 31, 2018 and 2017, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-012467:notes:153]
13. SEGMENT INFORMATION

[0001564590-18-012467:notes:154]
[same as prior period, unchanged from 0001564590-17-022183:notes:133]

[0001564590-18-012467:notes:155]
[same as prior period, unchanged from 0001564590-17-022183:notes:134]

[0001564590-18-012467:notes:156]
The following table presents information about the reported sales and gross profit of our reportable segments for the three months ended March 31, 2018 and 2017. We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-18-012467:notes:157]
|  |  | Three Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 105,253 |  |  | $ | 36,641 |  |  | $ | 143,597 |  |  | $ | 66,933 |  |
| Services & Support |  |  | 15,553 |  |  |  | 3,092 |  |  |  | 26,682 |  |  |  | 6,776 |  |
| Total |  | $ | 120,806 |  |  | $ | 39,733 |  |  | $ | 170,279 |  |  | $ | 73,709 |  |

[0001564590-18-012467:notes:158]
[same as prior period, unchanged from 0001564590-17-022183:notes:138]

[0001564590-18-012467:notes:159]
[same as prior period, unchanged from 0001564590-17-022183:notes:139]

[0001564590-18-012467:notes:160]
The table below presents sales information by category for the three months ended March 31, 2018 and 2017.

[0001564590-18-012467:notes:161]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Access & Aggregation |  | $ | 81,680 |  |  | $ | 120,143 |  |
| Customer Devices |  |  | 30,101 |  |  |  | 36,268 |  |
| Traditional & Other Products |  |  | 9,025 |  |  |  | 13,868 |  |
| Total |  | $ | 120,806 |  |  | $ | 170,279 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-18-012467:notes:162]
14. LIABILITY FOR WARRANTY RETURNS

[0001564590-18-012467:notes:163]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $9.7 million at March 31, 2018 and December 31, 2017. During the three months ended March 31, 2017, we recorded a receivable and a reduction in warranty expense related to a settlement with a third party supplier for a defective component, the impact of which is reflected in the table below. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0001564590-18-012467:notes:164]
A summary of warranty expense and write-off activity for the three months ended March 31, 2018 and 2017 is as follows:

[0001564590-18-012467:notes:165]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 9,724 |  |  | $ | 8,548 |  |
| Plus: Amounts charged to cost and expenses |  |  | 1,822 |  |  |  | (741 | ) |
| Less: Deductions |  |  | (1,859 | ) |  |  | 1,181 |  |
| Balance at end of period |  | $ | 9,687 |  |  | $ | 8,988 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-012467:notes:166]
15. COMMITMENTS AND CONTINGENCIES

[0001564590-18-012467:notes:167]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-18-012467:notes:168]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2018, of which $7.7 million has been applied to these commitments.


## us-gaap:SubsequentEventsTextBlock

[0001564590-18-012467:notes:169]
16. SUBSEQUENT EVENTS

[0001564590-18-012467:notes:170]
On April 17, 2018, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on May 2, 2018. The payment date will be May 16, 2018. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
