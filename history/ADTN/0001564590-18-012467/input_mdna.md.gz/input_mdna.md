# ADTN MD&A — 0001564590-18-012467


## mdna

[0001564590-18-012467:mdna:1]
[same as prior period, unchanged from 0001564590-17-022183:mdna:1]

[0001564590-18-012467:mdna:2]
[same as prior period, unchanged from 0001564590-17-022183:mdna:2]

[0001564590-18-012467:mdna:3]
[same as prior period, unchanged from 0001564590-17-022183:mdna:3]

[0001564590-18-012467:mdna:4]
[same as prior period, unchanged from 0001564590-17-022183:mdna:4]

[0001564590-18-012467:mdna:5]
[same as prior period, unchanged from 0001564590-17-022183:mdna:5]

[0001564590-18-012467:mdna:6]
[same as prior period, unchanged from 0001564590-17-022183:mdna:6]

[0001564590-18-012467:mdna:7]
[same as prior period, unchanged from 0001564590-17-022183:mdna:7]

[0001564590-18-012467:mdna:8]
[same as prior period, unchanged from 0001564590-17-022183:mdna:21]

[0001564590-18-012467:mdna:9]
[same as prior period, unchanged from 0001564590-17-022183:mdna:34]

[0001564590-18-012467:mdna:10]
See Note 13 of Notes to Consolidated Financial Statements in this report for further information regarding these product categories.

[0001564590-18-012467:mdna:11]
Sales were $120.8 million for the three months ended March 31, 2018, compared to $170.3 million for the three months ended March 31, 2017. Our gross margin decreased to 32.9% in the three months ended March 31, 2018 from 43.3% in the three months ended March 31, 2017. Our operating income margin decreased to (22.1)% for the three months ended March 31, 2018, from 4.1% for the three months ended March 31, 2017. Net income (loss) was $(10.8) million for the three months ended March 31, 2018, compared to $6.7 million for the three months ended March 31, 2017. Our effective tax rate, excluding the effect of the bargain purchase gain in 2018, decreased to 15.1% for the three months ended March 31, 2018, from 20.3% for the three months ended March 31, 2017.  Earnings (loss) per share, assuming dilution, were $(0.22) for the three months ended March 31, 2018, compared to $0.14 for the three months ended March 31, 2017.

[0001564590-18-012467:mdna:12]
[same as prior period, unchanged from 0001564590-17-022183:mdna:41]

[0001564590-18-012467:mdna:13]
[same as prior period, unchanged from 0001564590-17-022183:mdna:42]

[0001564590-18-012467:mdna:14]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Item 1A of Part I in our most recent Annual Report on Form 10-K for the year ended December 31, 2017, filed on February 23, 2018 with the SEC.

[0001564590-18-012467:mdna:15]
[same as prior period, unchanged from 0001564590-17-022183:mdna:44]

[0001564590-18-012467:mdna:16]
Our critical accounting policies and estimates have not changed significantly from those detailed in our most recent Annual Report on Form 10-K for the year ended December 31, 2017, filed on February 23, 2018 with the SEC.

[0001564590-18-012467:mdna:17]
[same as prior period, unchanged from 0001564590-17-022183:mdna:46]

[0001564590-18-012467:mdna:18]
[same as prior period, unchanged from 0001564590-17-022183:mdna:47]

[0001564590-18-012467:mdna:19]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2018 COMPARED TO THREE MONTHS ENDED MARCH 31, 2017

[0001564590-18-012467:mdna:20]
[same as prior period, unchanged from 0001564590-17-022183:mdna:49]

[0001564590-18-012467:mdna:21]
Our sales decreased 29.1% from $170.3 million in the three months ended March 31, 2017 to $120.8 million in the three months ended March 31, 2018. The decrease in sales for the three months ended March 31, 2018 is primarily attributable to a merger-related review and slowdown in spending at a domestic Tier 1 customer that particularly affected our Access & Aggregation products. Our Access & Aggregation category decreased $38.5 million over the same period last year as the decline in the previously mentioned domestic Tier 1 customer was partially offset by an increase in sales to an international Tier 1 customer. Compared to the same period last year, we also experienced a $6.2 million decrease in sales of our Customer Devices products and a $4.8 million decrease in sales of our Traditional & Other Products.

[0001564590-18-012467:mdna:22]
Network Solutions sales decreased 26.7% from $143.6 million in the three months ended March 31, 2017 to $105.3 million in the three months ended March 31, 2018. The decrease in sales of our Access & Aggregation products for the three months ended March 31, 2018 is primarily attributable to a merger-related review and slowdown in spending at a domestic Tier 1 customer, partially offset by an increase in sales to an international Tier 1 customer as discussed further below. The decrease in sales of our Customer Devices products for the three months ended March 31, 2018 is primarily attributable to decreased sales of fiber CPE products. While we expect that revenues from Traditional & Other Products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-18-012467:mdna:23]
Services & Support sales decreased 41.7% from $26.7 million in the three months ended March 31, 2017 to $15.6 million in the three months ended March 31, 2018. The decrease in sales for the three months ended March 31, 2018 is primarily attributable to a decrease in network installation services for Access & Aggregation products related to the above mentioned merger-related review and slowdown in spending at a domestic Tier 1 customer.

[0001564590-18-012467:mdna:24]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, increased 15.1% from $51.0 million in the three months ended March 31, 2017 to $58.7 million in the three months ended March 31, 2018. International sales, as a percentage of total sales, increased from 30.0.% for the three months ended March 31, 2017 to 48.6%  for the three months ended March 31, 2018. The increase in sales for the three months ended March 31, 2018 is primarily attributable to an increase in sales in EMEA, partially offset by a decrease in sales in APAC. The increase is sales in EMEA is primarily attributable to a network expansion program and a Services award by a large European tier-1 customer.

[0001564590-18-012467:mdna:25]
Our international revenues are largely focused on broadband infrastructure and are impacted by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. For example, the European Commission launched a Gigabit Society initiative, and before that, the Digital Agenda, which has provided a favorable market environment for the deployment of ultra-broadband and Gigabit network solutions. Although the overall environment and market demand for broadband service deployment in the European Union has improved, some new broadband technologies are still being reviewed for regulatory and standards completion, which may affect the timing of those technologies. In Mexico, regulatory changes have created uncertainty for customers, which have resulted in slowdowns in network buying patterns. The competitive landscape in certain international markets is also impacted by the increased presence of Asian manufacturers that seek to compete aggressively on price. A strengthening U.S. dollar can also negatively impact our revenues in regions such as Latin America, where our products are traditionally priced in U.S. dollars, while in regions where our products are sold in local currency, such as Europe, a stronger U.S. dollar can negatively impact operating income. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue to create expanded market opportunities for us, the factors described above may result in pressure on revenues and operating income. However, we do not presently foresee a significant negative impact to our financial condition based on our strong liquidity and the generally positive environment described above.

[0001564590-18-012467:mdna:26]
We recognized a positive impact to our revenues in the first half of 2017 due to our being awarded a network expansion program by a large European tier-1 customer. During the first quarter of 2018, this European Tier 1 customer undertook an additional network expansion project. We anticipate that as our Latin American customers resume their network upgrade projects, we may experience further enhancement to our revenues. We have recently announced receipt of a new nationwide award in the APAC region, as well as additional awards based on new ADTRAN technologies in the EMEA region that we believe will likely result in a positive impact to our revenues. However, a resolution of the regulatory changes affecting a major customer in Mexico has been slower than anticipated, and business with our customer in that region has not yet returned to a more normal level. We are continuing to pursue opportunities with new customers in this region.

[0001564590-18-012467:mdna:27]
[same as prior period, unchanged from 0001564590-17-022183:mdna:56]

[0001564590-18-012467:mdna:28]
As a percentage of sales, cost of sales increased from 56.7% in the three months ended March 31, 2017 to 67.1% in the three months ended March 31, 2018. The increase in cost of sales as a percentage of sales for the three months ended March 31, 2018 is primarily attributable to a regional revenue shift, customer and product mix, services and support mix, an increase in labor expense due to a restructuring program, an increase in warranty expense due to a settlement in Q1 2017 with a third party supplier for a defective component and purchase discounts received from a contract manufacturer in Q1 2017.

[0001564590-18-012467:mdna:29]
Network Solutions cost of sales, as a percent of that segment’s sales, increased from 53.4% in the three months ended March 31, 2017 to 65.2% in the three months ended March 31, 2018. The increase in cost of sales as a percentage of sales for the three months ended March 31, 2018 is primarily attributable to a regional revenue shift, customer and product mix, an increase in labor expense due to a restructuring program, an increase in warranty expense due to a settlement in Q1 2017 with a third party supplier for a defective component and purchase discounts received from a contract manufacturer in Q1 2017.

[0001564590-18-012467:mdna:30]
[same as prior period, unchanged from 0001564590-17-022183:mdna:59]

[0001564590-18-012467:mdna:31]
Services & Support cost of sales, as a percent of that segment’s sales, increased from 74.6% in the three months ended March 31, 2017 to 80.1% in the three months ended March 31, 2018. The increase in cost of sales as a percentage of sales for the three months ended March 31, 2018 is primarily attributable to services and support mix and an increase in labor expense due to a restructuring program.

[0001564590-18-012467:mdna:32]
[same as prior period, unchanged from 0001564590-17-022183:mdna:61]

[0001564590-18-012467:mdna:33]
[same as prior period, unchanged from 0001564590-17-022183:mdna:62]

[0001564590-18-012467:mdna:34]
[same as prior period, unchanged from 0001564590-17-022183:mdna:63]

[0001564590-18-012467:mdna:35]
Selling, general and administrative expenses decreased 3.6% from $34.8 million in the three months ended March 31, 2017 to $33.5 million in the three months ended March 31, 2018. The decrease in selling, general and administrative expenses for the three months ended March 31, 2018 is primarily attributable to decreases in deferred compensation expense, travel expense, performance-based compensation expense, independent contractor expense, and legal expense, partially offset by an increase in labor expense due to a restructuring program.

[0001564590-18-012467:mdna:36]
As a percentage of sales, selling, general and administrative expenses increased from 20.4% in the three months ended March 31, 2017 to 27.8% in the three months ended March 31, 2018. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-18-012467:mdna:37]
[same as prior period, unchanged from 0001564590-17-022183:mdna:66]

[0001564590-18-012467:mdna:38]
Research and development expenses increased 2.7% from $32.0 million in the three months ended March 31, 2017 to $32.8 million in the three months ended March 31, 2018. The increase in research and development expenses for the three months ended March 31, 2018 is primarily attributable to an increase in labor expense due to a restructuring program, partially offset by a decrease in amortization of intangibles acquired in the third quarter of 2016.

[0001564590-18-012467:mdna:39]
As a percentage of sales, research and development expenses increased from 18.8% in the three months ended March 31, 2017 to 27.2% in the three months ended March 31, 2018. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001564590-18-012467:mdna:40]
[same as prior period, unchanged from 0001564590-17-022183:mdna:69]

[0001564590-18-012467:mdna:41]
[same as prior period, unchanged from 0001564590-17-022183:mdna:70]

[0001564590-18-012467:mdna:42]
Interest and dividend income decreased 7.2% from $933 thousand in the three months ended March 31, 2017 to $866 thousand in the three months ended March 31, 2018. The decrease in interest and dividend income for the three months ended March 31, 2018 is primarily attributable to a decrease in investment balances and a decrease in the rate of return on those investments.

[0001564590-18-012467:mdna:43]
[same as prior period, unchanged from 0001564590-17-022183:mdna:72]

[0001564590-18-012467:mdna:44]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended March 31, 2017 and 2018, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-18-012467:mdna:45]
[same as prior period, unchanged from 0001564590-17-022183:mdna:74]

[0001564590-18-012467:mdna:46]
Net realized investment gains decreased 120.6% from $0.5 million in the three months ended March 31, 2017 to $(0.1) million in the three months ended March 31, 2018. The decrease in net realized investment gains for the three months ended March 31, 2018 is primarily attributable to changes in fair value on equity securities recognized during the period under ASC 2016-01. Prior to January 1, 2018, changes in fair value were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet. See note 1, note 7 and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-18-012467:mdna:47]
OTHER INCOME (EXPENSE), NET

[0001564590-18-012467:mdna:48]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, gains and losses on foreign exchange forward contracts, investment account management fees, and scrap raw material sales, changed 142.5% from $0.1 million of income in the three months ended March 31, 2017 to $0.1 million of expense in the three months ended March 31, 2018. The change in other income (expense), net for the three months ended March 31, 2018 is primarily attributable to increased losses on our foreign exchange contracts.

[0001564590-18-012467:mdna:49]
[same as prior period, unchanged from 0001564590-17-022183:mdna:78]

[0001564590-18-012467:mdna:50]
Gain on bargain purchase of a business is related to our acquisition of Sumitomo Electric Lightwave Corp.’s North American EPON business and entry into a technology license and supply agreement with Sumitomo Electric Industries, Ltd. on March 19, 2018. See Note 2 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-012467:mdna:51]
[same as prior period, unchanged from 0001564590-17-022183:mdna:80]

[0001564590-18-012467:mdna:52]
Our effective tax rate decreased from 20.3% in the three months ended March 31, 2017 to 15.1%, excluding the tax impact of the bargain purchase gain, in the three months ended March 31, 2018. The decrease in the effective tax rate between the two periods is primarily attributable to the impact of the Tax Cuts and Jobs Act, which was signed into law on December 22, 2017.

[0001564590-18-012467:mdna:53]
NET INCOME (LOSS)

[0001564590-18-012467:mdna:54]
As a result of the above factors, net income (loss) decreased $17.5 million from $6.7 million in the three months ended March 31, 2017 to $(10.8) million in the three months ended March 31, 2018.

[0001564590-18-012467:mdna:55]
[same as prior period, unchanged from 0001564590-17-022183:mdna:85]

[0001564590-18-012467:mdna:56]
[same as prior period, unchanged from 0001564590-17-022183:mdna:86]

[0001564590-18-012467:mdna:57]
[same as prior period, unchanged from 0001564590-17-022183:mdna:87]

[0001564590-18-012467:mdna:58]
At March 31, 2018, cash on hand was $82.6 million and short-term investments were $16.4 million, which resulted in available short-term liquidity of $99.0 million, of which $63.7 million was held by our foreign subsidiaries. At December 31, 2017, cash on hand was $86.4 million and short-term investments were $16.1 million, which resulted in available short-term liquidity of $102.6 million, of which $56.8 million was held by our foreign subsidiaries. We intend to permanently reinvest these funds outside the U.S. and our current business plans do not indicate a need to repatriate these funds to finance domestic operations. The decrease in short-term liquidity from December 31, 2017 to March 31, 2018 is primarily attributable to shifts among available investment option tenures to provide funds for our short-term cash needs.

[0001564590-18-012467:mdna:59]
[same as prior period, unchanged from 0001564590-17-022183:mdna:89]

[0001564590-18-012467:mdna:60]
Our working capital, which consists of current assets less current liabilities, decreased 20.9% from $306.3 million as of December 31, 2017 to $242.2 million as of March 31, 2018, and our current ratio, defined as current assets divided by current liabilities, decreased from 3.87 as of December 31, 2017 to 3.36 as of March 31, 2018 The decrease in our working capital and current ratio is primarily attributable to a decrease in accounts receivable and prepaid expenses and other current assets, partially offset by a decrease in accounts payable and an increase in other receivables. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.31 as of December 31, 2017 to 1.75 as of March 31, 2018. The decrease in the quick ratio is primarily attributable to a decrease in accounts receivable, partially offset by a decrease in accounts payable.

[0001564590-18-012467:mdna:61]
Accounts receivable decreased 43.9% from $144.2 million at December 31, 2017 to $80.9 million at March 31, 2018. We had no allowance for doubtful accounts at December 31, 2017 or March 31, 2018. Quarterly accounts receivable days sales outstanding (DSO) decreased from 105 days as of December 31, 2017 to 60 days as of March 31, 2018 The decrease in net accounts receivable is due to the collection of customer specific payment terms that became due in the first quarter of 2018 and the timing of sales and collections during the quarter. Additionally, certain international customers can have longer payment terms than U.S. customers.

[0001564590-18-012467:mdna:62]
Other receivables increased 32.2% from $26.6 million at December 31, 2017 to $35.1 million at March 31, 2018. The increase in other receivables is primarily attributable to an increase in tax receivable and the timing of filing returns and collections of VAT receivables in our international subsidiaries, partially offset by the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001564590-18-012467:mdna:63]
Quarterly inventory turnover decreased from 3.09 turns as of December 31, 2017 to 2.67 turns at March 31, 2018. Inventory decreased 2.1% from $122.5 million at December 31, 2017 to $120.0 million at March 31, 2018. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-18-012467:mdna:64]
Prepaid expense and other current assets decreased 43.9% from $17.3 million at December 31, 2017 to $9.7 million at March 31, 2018. The decrease in prepaid expenses and other current assets is primarily attributable to the recognition of deferred costs related to network installation services that were completed during the quarter.

[0001564590-18-012467:mdna:65]
Accounts payable decreased 16.5% from $60.6 million at December 31, 2017 to $50.7 million at March 31, 2018. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-18-012467:mdna:66]
[same as prior period, unchanged from 0001564590-17-022183:mdna:95]

[0001564590-18-012467:mdna:67]
Capital expenditures totaled approximately $2.0 million and $3.9 million for the three months ended March 31, 2018 and 2017, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-18-012467:mdna:68]
Our combined short-term and long-term investments increased $26.5 million from $146.4 million at December 31, 2017 to $172.9 million at March 31, 2018. This increase reflects funds available for investment provided by our operating activities and stock option exercises by our employees, as well as net realized and unrealized gains and losses and amortization of net premiums on our combined investments, partially offset by our cash needs for capital expenditures, purchases of treasury stock, and shareholder dividends.

[0001564590-18-012467:mdna:69]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At March 31, 2018 these investments included corporate bonds of $48.8 million, municipal fixed-rate bonds of $2.4 million, asset-backed bonds of $13.3 million, mortgage/agency-backed bonds of $8.8 million, U.S. government bonds of $14.5 million, and foreign government bonds of $1.2 million. At December 31, 2017, these investments included corporate bonds of $32.5 million, municipal fixed-rate bonds of $2.9 million, asset-backed bonds of $6.5 million, mortgage/agency-backed bonds of $5.5 million, U.S. government bonds of $14.3 million, and foreign government bonds of $0.7 million. As of March 31, 2018, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds were classified as available-for-sale and had a combined duration of 1.25 years with an average Standard & Poor’s credit rating of A+. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-18-012467:mdna:70]
Our long-term investments increased 20.1% from $130.3 million at December 31, 2017 to $156.5 million at March 31, 2018. Long-term investments at March 31, 2018 and December 31, 2017 included an investment in a certificate of deposit of $26.7 million and $27.8 million, respectively, which serves as collateral for our revenue bond. See “Debt” below for additional information. We have various equity investments included in long-term investments with a fair value of $36.5 million and $35.7 million, at March 31, 2018 and December 31, 2017, respectively.

[0001564590-18-012467:mdna:71]
Long-term investments at March 31, 2018 and December 31, 2017 also included $20.1 million and $19.9 million, respectively, related to our deferred compensation plans, and $0.5 million of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001564590-18-012467:mdna:72]
[same as prior period, unchanged from 0001564590-17-022183:mdna:102]

[0001564590-18-012467:mdna:73]
[same as prior period, unchanged from 0001564590-17-022183:mdna:103]

[0001564590-18-012467:mdna:74]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the three months ended March 31, 2018, we paid dividends totaling $4.4 million.

[0001564590-18-012467:mdna:75]
[same as prior period, unchanged from 0001564590-17-022183:mdna:105]

[0001564590-18-012467:mdna:76]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $26.7 million at March 31, 2018 and December 31, 2017. At March 31, 2018, the estimated fair value of the Bond was approximately $26.6 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $26.7 million and $27.8 million at March 31, 2018 and December 31, 2017, respectively, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.1 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at March 31, 2018.

[0001564590-18-012467:mdna:77]
[same as prior period, unchanged from 0001564590-17-022183:mdna:107]

[0001564590-18-012467:mdna:78]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. During the three months ended March 31, 2018, we repurchased 0.6 million shares of our common stock at an average price of $16.18 per share. As of March 31, 2018, we have the authority to purchase an additional 2.9 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-18-012467:mdna:79]
[same as prior period, unchanged from 0001564590-17-022183:mdna:109]

[0001564590-18-012467:mdna:80]
We issued 24 thousand shares of treasury stock during the three months ended March 31, 2018 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $0.4 million from the exercise of these stock options during the three months ended March 31, 2018.

[0001564590-18-012467:mdna:81]
[same as prior period, unchanged from 0001564590-17-022183:mdna:111]

[0001564590-18-012467:mdna:82]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the three months ended March 31, 2018, there have been no material changes in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2017 filed on February 23, 2018 with the SEC.

[0001564590-18-012467:mdna:83]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2018, of which $7.7 million has been applied to these commitments.
