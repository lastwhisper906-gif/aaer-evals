# ADTN note change history — 0001564590-17-022183 → 0001564590-18-012467


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-09):
[0001564590-18-012467:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2018, of which $7.7 million has been applied to these commitments.
  (was, 2017-11-07, similarity 0.9652):
[0001564590-17-022183:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2017, of which $7.7 million has been applied to these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-09):
[0001564590-18-012467:note_history:2]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We adopted ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method, which was applied to all contracts on the date of initial adoption.
  (was, 2017-11-07, similarity 0.9431):
[0001564590-17-022183:note_history:2]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We plan to adopt ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method. We are continuing to evaluate and assess the potential impacts of these ASUs through an analysis of revenue streams, contract reviews, and our control environment.

- added (2018-05-09):
[0001564590-18-012467:note_history:3]
The two primary areas of impact of these ASUs were network implementation service revenue performance obligations and contract costs. The output method will be used to measure network implementation services progress. The primary impact will be accelerated revenue recognition for certain performance obligations related to service revenue arrangements that were previously deferred until customer acceptance and capitalization and amortization of incremental costs of obtaining a contract as described below.

- changed (2018-05-09):
[0001564590-18-012467:note_history:4]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we adopted ASC 340-40, Other Assets and Deferred Costs - Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract will need to be capitalized, including sales commissions, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. The primary impact was capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and amortization of those costs over the period that the related revenue is recognized.
  (was, 2017-11-07, similarity 0.9249):
[0001564590-17-022183:note_history:4]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we will also adopt ASC 340-40, Other Assets and Deferred Costs - Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract may need to be capitalized, including sales commissions, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. We believe the primary impact will be capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and costs associated with our capital lease arrangements that are billed monthly, and amortization of those costs over the period that the related revenue is recognized.

- added (2018-05-09):
[0001564590-18-012467:note_history:5]
The cumulative effect of the changes made to our Consolidated Balance Sheet on January 1, 2018 for the adoption of ASU 2014-09 and the related ASUs was as follows:

- added (2018-05-09):
[0001564590-18-012467:note_history:6]
| (In thousands) |  | Balance at December 31, 2017 |  |  | Adjustments due to ASU 2014-09 |  |  | Balance at January 1, 2018 |  |
| Other receivables |  | $ | 26,578 |  |  |  | 374 |  |  | $ | 26,952 |  |
| Deferred tax assets, net |  | $ | 23,428 |  |  |  | (96 | ) |  | $ | 23,332 |  |
| Retained earnings |  | $ | 922,178 |  |  |  | 278 |  |  | $ | 922,456 |  |

- added (2018-05-09):
[0001564590-18-012467:note_history:7]
The impact of the adoption of ASU 2014-09 and the related ASUs on our financial statements was as follows:

- added (2018-05-09):
[0001564590-18-012467:note_history:8]
|  |  | For the three months ended March 31, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Change Higher/(Lower) |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 105,253 |  |  |  | 105,439 |  |  | $ | (186 | ) |
| Services |  | $ | 15,553 |  |  |  | 14,700 |  |  | $ | 853 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 68,612 |  |  |  | 68,723 |  |  | $ | (111 | ) |
| Services |  | $ | 12,461 |  |  |  | 11,925 |  |  | $ | 536 |  |
| Loss before benefit for income taxes |  | $ | (14,745 | ) |  |  | (14,987 | ) |  | $ | 242 |  |
| Benefit for income taxes |  | $ | 3,931 |  |  |  | 3,998 |  |  | $ | (67 | ) |
| Net loss |  | $ | (10,814 | ) |  |  | (10,989 | ) |  | $ | 175 |  |

- added (2018-05-09):
[0001564590-18-012467:note_history:9]
|  |  | As of March 31, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Change Higher/(Lower) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other receivables |  | $ | 35,124 |  |  |  | 35,060 |  |  | $ | 64 |  |
| Inventory |  | $ | 120,021 |  |  |  | 119,910 |  |  | $ | 111 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 909,611 |  |  |  | 909,436 |  |  | $ | 175 |  |

- added (2018-05-09):
[0001564590-18-012467:note_history:10]
In January 2016, the FASB issued Accounting Standards Update 2016-01, Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities (ASU 2016-01) which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. ASU 2016-01 was effective beginning January 1, 2018 and we are now recognizing any changes in the fair value of certain equity investments in net income as prescribed by the new standard rather than in other comprehensive income. We adopted ASU 2016-01 on January 1, 2018 using the modified retrospective method, which resulted in $3.2 million reclassification of net unrealized gains from accumulated other comprehensive income to opening retained earnings.

- changed (2018-05-09):
[0001564590-18-012467:note_history:11]
In March 2017, the FASB issued Accounting Standards Update No. 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost (ASU 2017-07). ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. We adopted ASU 2017-07 on January 1, 2018. We retrospectively adopted the presentation of service cost separate from other components of net periodic pension costs. As a result, $0.1 million was reclassified from cost of sales, selling, general and administrative expenses, and research and development expense to other income (expense), net for the three months ended March 31, 2017.
  (was, 2017-11-07, similarity 0.7173):
[0001564590-17-022183:note_history:11]
In March 2017, the FASB issued Accounting Standards Update No. 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost (ASU 2017-07). ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. ASU 2017-07 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted. We do not expect ASU 2017-07 will have a material impact on our financial position, results of operations or cash flows.

- removed (2018-05-09):
[0001564590-17-022183:note_history:12]
We are finalizing our assessment of the proper method of measuring progress toward satisfaction of each respective contract performance obligation for our network installation services revenues. At this time, we believe the output method will be used to measure network installation services progress. We believe the primary impact will be accelerated revenue recognition for certain performance obligations related to revenue arrangements that are currently deferred until customer acceptance.

- removed (2018-05-09):
[0001564590-17-022183:note_history:13]
We do not believe there will be a significant impact to product or maintenance revenues.  However, we are still assessing the impact of the allocation of revenue between deliverables with multiple performance obligations and timing of revenue recognition.

- removed (2018-05-09):
[0001564590-17-022183:note_history:14]
In July 2015, the FASB issued Accounting Standards Update No.  2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We adopted ASU 2015-11 in the first quarter of 2017, and there was no material impact on our financial position, results of operations or cash flows.

- removed (2018-05-09):
[0001564590-17-022183:note_history:15]
In January 2017, we adopted ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. As a result, beginning in the first quarter of 2017, we began recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit as a discrete event. The treatment of forfeitures has changed as we have elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur. As a result, we recorded an increase in additional paid in capital of $0.1 million, a charge to beginning retained earnings of $0.1 million, and an increase in the deferred tax assets related to non-qualified stock options and RSUs of $10 thousand. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows within operating activities. We elected to retrospectively apply the changes in presentation to the statements of cash flows and no longer classify excess tax benefits as a financing activity, which had an immaterial impact on our cash flows for the nine months ended September 30, 2016. There was no material impact on our financial position, results of operations or cash flows as a result of these changes.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-05-09):
[0001564590-18-012467:note_history:16]
Debt Securities and Other Investments

- changed (2018-05-09):
[0001564590-18-012467:note_history:17]
At March 31, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:
  (was, 2017-11-07, similarity 0.9074):
[0001564590-17-022183:note_history:17]
At December 31, 2016, we held the following securities and investments, recorded at either fair value or cost:

- changed (2018-05-09):
[0001564590-18-012467:note_history:18]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  |  | 49,109 |  |  |  | 43 |  |  |  | (333 | ) |  |  | 48,819 |  |
| Municipal fixed-rate bonds |  |  | 2,413 |  |  |  | — |  |  |  | (30 | ) |  |  | 2,383 |  |
| Asset-backed bonds |  |  | 13,334 |  |  |  | — |  |  |  | (44 | ) |  |  | 13,290 |  |
| Mortgage/Agency-backed bonds |  |  | 8,906 |  |  |  | 2 |  |  |  | (72 | ) |  |  | 8,836 |  |
| U.S. government bonds |  |  | 14,703 |  |  |  | 10 |  |  |  | (204 | ) |  |  | 14,509 |  |
| Foreign government bonds |  |  | 1,228 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 1,231 |  |
| Available-for-sale debt securities held at fair value |  | $ | 89,693 |  |  | $ | 59 |  |  | $ | (684 | ) |  | $ | 89,068 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 26,700 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 520 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 116,288 |  |
  (was, 2017-11-07, similarity 0.9127):
[0001564590-17-022183:note_history:18]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 15,898 |  |  | $ | 3,230 |  |  | $ | (15 | ) |  | $ | 19,113 |  |
| Corporate bonds |  |  | 45,223 |  |  |  | 75 |  |  |  | (79 | ) |  |  | 45,219 |  |
| Municipal fixed-rate bonds |  |  | 4,887 |  |  |  | 4 |  |  |  | (17 | ) |  |  | 4,874 |  |
| Asset-backed bonds |  |  | 7,791 |  |  |  | 5 |  |  |  | (11 | ) |  |  | 7,785 |  |
| Mortgage/Agency-backed bonds |  |  | 7,364 |  |  |  | 7 |  |  |  | (41 | ) |  |  | 7,330 |  |
| U.S. government bonds |  |  | 21,000 |  |  |  | 3 |  |  |  | (109 | ) |  |  | 20,894 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 3 |  |  | — |  |  |  | 728 |  |
| Marketable equity securities |  |  | 32,394 |  |  |  | 2,649 |  |  |  | (961 | ) |  |  | 34,082 |  |
| Available-for-sale securities held at fair value |  | $ | 135,282 |  |  | $ | 5,976 |  |  | $ | (1,233 | ) |  | $ | 140,025 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 168,372 |  |

- changed (2018-05-09):
[0001564590-18-012467:note_history:19]
At December 31, 2017, we held the following debt securities and other investments, recorded at either fair value or cost:
  (was, 2017-11-07, similarity 0.9273):
[0001564590-17-022183:note_history:19]
At September 30, 2017, we held the following securities and investments, recorded at either fair value or cost:

- changed (2018-05-09):
[0001564590-18-012467:note_history:20]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  |  | 32,654 |  |  |  | 44 |  |  |  | (155 | ) |  |  | 32,543 |  |
| Municipal fixed-rate bonds |  |  | 2,902 |  |  |  | 2 |  |  |  | (22 | ) |  |  | 2,882 |  |
| Asset-backed bonds |  |  | 6,545 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 6,526 |  |
| Mortgage/Agency-backed bonds |  |  | 5,554 |  |  |  | 1 |  |  |  | (46 | ) |  |  | 5,509 |  |
| U.S. government bonds |  |  | 14,477 |  |  |  | — |  |  |  | (174 | ) |  |  | 14,303 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 5 |  |  |  | — |  |  |  | 730 |  |
| Available-for-sale debt securities held at fair value |  | $ | 62,857 |  |  | $ | 53 |  |  | $ | (417 | ) |  | $ | 62,493 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 90,840 |  |
  (was, 2017-11-07, similarity 0.8098):
[0001564590-17-022183:note_history:20]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 12,367 |  |  | $ | 2,271 |  |  | $ | (42 | ) |  | $ | 14,596 |  |
| Corporate bonds |  |  | 66,522 |  |  |  | 64 |  |  |  | (174 | ) |  |  | 66,412 |  |
| Municipal fixed-rate bonds |  |  | 11,799 |  |  |  | 12 |  |  |  | (37 | ) |  |  | 11,774 |  |
| Asset-backed bonds |  |  | 10,201 |  |  |  | 19 |  |  |  | (14 | ) |  |  | 10,206 |  |
| Mortgage/Agency-backed bonds |  |  | 13,080 |  |  |  | 15 |  |  |  | (91 | ) |  |  | 13,004 |  |
| U.S. government bonds |  |  | 30,022 |  |  |  | 15 |  |  |  | (270 | ) |  |  | 29,767 |  |
| Foreign government bonds |  |  | 3,729 |  |  |  | 2 |  |  |  | (1 | ) |  |  | 3,730 |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | — |  |  |  | 11,855 |  |
| Marketable equity securities |  |  | 30,571 |  |  |  | 311 |  |  |  | (1,503 | ) |  |  | 29,379 |  |
| Available-for-sale securities held at fair value |  | $ | 190,146 |  |  | $ | 2,709 |  |  | $ | (2,132 | ) |  | $ | 190,723 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 767 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 219,290 |  |

- added (2018-05-09):
[0001564590-18-012467:note_history:21]
As of March 31, 2018, our debt securities had the following contractual maturities:

- changed (2018-05-09):
[0001564590-18-012467:note_history:22]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 11,391 |  |  | $ | 490 |  |  | $ | 4,520 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 18,406 |  |  |  | 737 |  |  | $ | 2,459 |  |  |  | — |  |  |  | 6,149 |  |  |  | — |  |
| Two to three years |  |  | 10,639 |  |  |  | 210 |  |  |  | 2,669 |  |  |  | — |  |  |  | 2,491 |  |  |  | 1,231 |  |
| Three to five years |  |  | 8,383 |  |  |  | 946 |  |  |  | 1,631 |  |  |  | 2,046 |  |  |  | 5,869 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 974 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 2,011 |  |  |  | 5,816 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 48,819 |  |  | $ | 2,383 |  |  | $ | 13,290 |  |  | $ | 8,836 |  |  | $ | 14,509 |  |  | $ | 1,231 |  |
  (was, 2017-11-07, similarity 0.9658):
[0001564590-17-022183:note_history:22]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 20,232 |  |  | $ | 2,250 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,903 |  |  | $ | — |  |
| One to two years |  |  | 11,678 |  |  |  | 724 |  |  | $ | 2,638 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 10,029 |  |  |  | 730 |  |  |  | 2,235 |  |  |  | — |  |  |  | 10,413 |  |  |  | 728 |  |
| Three to five years |  |  | 3,280 |  |  |  | 1,170 |  |  |  | 1,550 |  |  |  | 917 |  |  |  | 1,578 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 450 |  |  |  | 1,348 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 912 |  |  |  | 5,065 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 45,219 |  |  | $ | 4,874 |  |  | $ | 7,785 |  |  | $ | 7,330 |  |  | $ | 20,894 |  |  | $ | 728 |  |

- changed (2018-05-09):
[0001564590-18-012467:note_history:23]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:
  (was, 2017-11-07, similarity 0.9364):
[0001564590-17-022183:note_history:23]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments:

- added (2018-05-09):
[0001564590-18-012467:note_history:24]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Gross realized gains |  | $ | — |  |  | $ | — |  |
| Gross realized losses |  | $ | (73 | ) |  | $ | (15 | ) |

- changed (2018-05-09):
[0001564590-18-012467:note_history:25]
At March 31, 2018, we held a $26.7 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $26.7 million at March 31, 2018 and December 31, 2017. At March 31, 2018 and December 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $26.6 million and $26.7 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.
  (was, 2017-11-07, similarity 0.9654):
[0001564590-17-022183:note_history:25]
At September 30, 2017, we held a $27.8 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $27.8 million at September 30, 2017 and December 31, 2016. At September 30, 2017 and December 31, 2016, the estimated fair value of the Bond using a level 2 valuation technique was approximately $28.0 million and $28.1 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

- added (2018-05-09):
[0001564590-18-012467:note_history:26]
Marketable Equity Securities

- added (2018-05-09):
[0001564590-18-012467:note_history:27]
Our marketable equity securities consist of publicly traded stocks or funds measured at fair value.

- added (2018-05-09):
[0001564590-18-012467:note_history:28]
Prior to January 1, 2018, our marketable equity securities were classified as available-for-sale. Realized gains and losses on marketable equity securities were included in net realized investment gain (loss). Unrealized gains and losses were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet.

- added (2018-05-09):
[0001564590-18-012467:note_history:29]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net realized investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income to opening retained earnings.

- added (2018-05-09):
[0001564590-18-012467:note_history:30]
Realized and unrealized gains and losses for our marketable equity securities for the three months ended March 31, 2018 were as follows:

- added (2018-05-09):
[0001564590-18-012467:note_history:31]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (1 | ) |
| Unrealized gains (losses) on equity securities held |  |  | (23 | ) |
| Total gain (loss) recognized, net |  | $ | (24 | ) |

- changed (2018-05-09):
[0001564590-18-012467:note_history:32]
As of March 31, 2018 and 2017, gross unrealized losses related to individual investments in a continuous loss position for 12 months or longer were not significant.
  (was, 2017-11-07, similarity 0.9196):
[0001564590-17-022183:note_history:32]
As of September 30, 2017 and 2016, gross unrealized losses related to individual securities in a continuous loss position for 12 months or longer were not significant.

- changed (2018-05-09):
[0001564590-18-012467:note_history:33]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows:  Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.
  (was, 2017-11-07, similarity 0.981):
[0001564590-17-022183:note_history:33]
We have categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows:  Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

- added (2018-05-09):
[0001564590-18-012467:note_history:34]
|  |  | Fair Value Measurements at March 31, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,770 |  |  | $ | 6,770 |  |  | $ | — |  |  | $ | — |  |
| Asset-backed securities |  |  | 1,000 |  |  |  | — |  |  |  | 1,000 |  |  |  | — |  |
| Cash equivalents |  |  | 7,770 |  |  |  | 6,770 |  |  |  | 1,000 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 48,819 |  |  |  | — |  |  |  | 48,819 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,383 |  |  |  | — |  |  |  | 2,383 |  |  |  | — |  |
| Asset-backed bonds |  |  | 13,290 |  |  |  | — |  |  |  | 13,290 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,836 |  |  |  | — |  |  |  | 8,836 |  |  |  | — |  |
| U.S. government bonds |  |  | 14,509 |  |  |  | 14,509 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,231 |  |  |  | — |  |  |  | 1,231 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 36,519 |  |  |  | 36,519 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,067 |  |  |  | 20,067 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 145,654 |  |  |  | 71,095 |  |  |  | 74,559 |  |  |  | — |  |
| Total |  | $ | 153,424 |  |  | $ | 77,865 |  |  | $ | 75,559 |  |  | $ | — |  |

- changed (2018-05-09):
[0001564590-18-012467:note_history:35]
|  |  | Fair Value Measurements at December 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,851 |  |  | $ | 5,851 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 3,999 |  |  |  | — |  |  |  | 3,999 |  |  |  | — |  |
| Cash equivalents |  |  | 9,850 |  |  |  | 5,851 |  |  |  | 3,999 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 32,543 |  |  |  | — |  |  |  | 32,543 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,882 |  |  |  | — |  |  |  | 2,882 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,526 |  |  |  | — |  |  |  | 6,526 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,509 |  |  |  | — |  |  |  | 5,509 |  |  |  | — |  |
| U.S. government bonds |  |  | 14,303 |  |  |  | 14,303 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 730 |  |  |  | — |  |  |  | 730 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,662 |  |  |  | 35,662 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 19,883 |  |  |  | 19,883 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 118,038 |  |  |  | 69,848 |  |  |  | 48,190 |  |  |  | — |  |
| Total |  | $ | 127,888 |  |  | $ | 75,699 |  |  | $ | 52,189 |  |  | $ | — |  |
  (was, 2017-11-07, similarity 0.7964):
[0001564590-17-022183:note_history:35]
|  |  | Fair Value Measurements at September 30, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 8,115 |  |  | $ | 8,115 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 35,436 |  |  |  | — |  |  |  | 35,436 |  |  |  | — |  |
| Cash equivalents |  |  | 43,551 |  |  |  | 8,115 |  |  |  | 35,436 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 19,113 |  |  |  | 19,113 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 45,219 |  |  |  | — |  |  |  | 45,219 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 4,874 |  |  |  | — |  |  |  | 4,874 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,785 |  |  |  | — |  |  |  | 7,785 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 7,330 |  |  |  | — |  |  |  | 7,330 |  |  |  | — |  |
| U.S. government bonds |  |  | 20,894 |  |  |  | 20,894 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 728 |  |  |  | — |  |  |  | 728 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 34,082 |  |  |  | 34,082 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 140,025 |  |  |  | 74,089 |  |  |  | 65,936 |  |  |  | — |  |
| Total |  | $ | 183,576 |  |  | $ | 82,204 |  |  | $ | 101,372 |  |  | $ | — |  |

- removed (2018-05-09):
[0001564590-17-022183:note_history:36]
As of September 30, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds and foreign government bonds had the following contractual maturities:

- removed (2018-05-09):
[0001564590-17-022183:note_history:37]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and nine months ended September 30, 2017 and 2016, other-than-temporary impairment charges were not significant.

- removed (2018-05-09):
[0001564590-17-022183:note_history:38]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Gross realized gains |  | $ | 1,094 |  |  | $ | 1,346 |  |  | $ | 3,324 |  |  | $ | 5,226 |  |
| Gross realized losses |  | $ | (85 | ) |  | $ | (30 | ) |  | $ | (455 | ) |  | $ | (1,072 | ) |

- removed (2018-05-09):
[0001564590-17-022183:note_history:39]
|  |  | Fair Value Measurements at December 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,878 |  |  | $ | 6,878 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 17,222 |  |  |  | — |  |  |  | 17,222 |  |  |  | — |  |
| Cash equivalents |  |  | 24,100 |  |  |  | 6,878 |  |  |  | 17,222 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 14,596 |  |  |  | 14,596 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 66,412 |  |  |  | — |  |  |  | 66,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 11,774 |  |  |  | — |  |  |  | 11,774 |  |  |  | — |  |
| Asset-backed bonds |  |  | 10,206 |  |  |  | — |  |  |  | 10,206 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 13,004 |  |  |  | — |  |  |  | 13,004 |  |  |  | — |  |
| U.S. government bonds |  |  | 29,767 |  |  |  | 29,767 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 3,730 |  |  |  | — |  |  |  | 3,730 |  |  |  | — |  |
| Variable Rate Demand Notes |  |  | 11,855 |  |  |  | — |  |  |  | 11,855 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 29,379 |  |  |  | 29,379 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 190,723 |  |  |  | 73,742 |  |  |  | 116,981 |  |  |  | — |  |
| Total |  | $ | 214,823 |  |  | $ | 80,620 |  |  | $ | 134,203 |  |  | $ | — |  |

- removed (2018-05-09):
[0001564590-17-022183:note_history:40]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-09):
[0001564590-18-012467:note_history:41]
During the three months ended March 31, 2018, we recognized $3.5 million of revenue that was included in unearned revenue at the beginning of the period.

- added (2018-05-09):
[0001564590-18-012467:note_history:42]
The following table disaggregates our revenue by major source:

- added (2018-05-09):
[0001564590-18-012467:note_history:43]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,385 |  |  | $ | 12,295 |  |  | $ | 81,680 |  |
| Customer Devices |  |  | 28,777 |  |  |  | 1,324 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,091 |  |  |  | 1,934 |  |  |  | 9,025 |  |
| Total |  | $ | 105,253 |  |  | $ | 15,553 |  |  | $ | 120,806 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-05-09):
[0001564590-18-012467:note_history:44]
3. REVENUE

- added (2018-05-09):
[0001564590-18-012467:note_history:45]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product or service to the customer. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices using the most likely amount. The stand-alone selling prices are determined based on the prices at which we sell the separate products and services. For items that are not sold separately, we estimate stand-alone selling prices primarily using reasonable internal analysis. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value added, and other taxes collected concurrent with revenue-producing activities are excluded from revenue. Costs of obtaining a contract are capitalized and amortized over the period that the related revenue is recognized. We have elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

- added (2018-05-09):
[0001564590-18-012467:note_history:46]
The following is a description of the principal activities from which we generate our revenue by reportable segment.

- added (2018-05-09):
[0001564590-18-012467:note_history:47]
Network Solutions Segment

- added (2018-05-09):
[0001564590-18-012467:note_history:48]
Network Solutions includes hardware products and next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

- added (2018-05-09):
[0001564590-18-012467:note_history:49]
Hardware

- added (2018-05-09):
[0001564590-18-012467:note_history:50]
The majority of the revenue from this segment is from hardware sales and is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. Revenue is recorded net of discounts and rebates using the most likely amount. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

- added (2018-05-09):
[0001564590-18-012467:note_history:51]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment, which have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term.

- added (2018-05-09):
[0001564590-18-012467:note_history:52]
Services & Support Segment

- added (2018-05-09):
[0001564590-18-012467:note_history:53]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, solutions integration and managed services, which include hosted, cloud services and subscription services.

- added (2018-05-09):
[0001564590-18-012467:note_history:54]
Maintenance

- added (2018-05-09):
[0001564590-18-012467:note_history:55]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period, which is recorded in current or non-current unearned revenue depending on the length of the service period. Maintenance services are provided on an as-needed basis and our customers benefit evenly throughout the contract term. Accordingly, we recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue.

- added (2018-05-09):
[0001564590-18-012467:note_history:56]
Network Implementation

- added (2018-05-09):
[0001564590-18-012467:note_history:57]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services, when performance obligations are complete at a point in time. If we have recognized revenue, but not billed the customer, the right to consideration is recognized as a contract asset, which is included in other receivables in the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the right to consideration to payment becomes unconditional.

- added (2018-05-09):
[0001564590-18-012467:note_history:58]
As of March 31, 2018, we did not have any remaining performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

- added (2018-05-09):
[0001564590-18-012467:note_history:59]
The following table provides information about receivables, contract assets, and unearned revenue from contracts with customers:

- added (2018-05-09):
[0001564590-18-012467:note_history:60]
| (In thousands) |  | March 31, 2018 |  |  | December 31, 2017 |  |
| Accounts receivable |  | $ | 80,883 |  |  | $ | 144,150 |  |
| Contract assets |  |  | 1,442 |  |  |  | — |  |
| Unearned revenue |  |  | 13,948 |  |  |  | 13,070 |  |
| Non-current unearned revenue |  |  | 4,154 |  |  |  | 4,556 |  |

- added (2018-05-09):
[0001564590-18-012467:note_history:61]
During the three months ended March 31, 2018, we recognized $3.5 million of revenue that was included in unearned revenue at the beginning of the period.

- added (2018-05-09):
[0001564590-18-012467:note_history:62]
The following table disaggregates our revenue by major source:

- added (2018-05-09):
[0001564590-18-012467:note_history:63]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,385 |  |  | $ | 12,295 |  |  | $ | 81,680 |  |
| Customer Devices |  |  | 28,777 |  |  |  | 1,324 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,091 |  |  |  | 1,934 |  |  |  | 9,025 |  |
| Total |  | $ | 105,253 |  |  | $ | 15,553 |  |  | $ | 120,806 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2018-05-09):
[0001564590-18-012467:note_history:64]
On April 17, 2018, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on May 2, 2018. The payment date will be May 16, 2018. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
  (was, 2017-11-07, similarity 0.9641):
[0001564590-17-022183:note_history:64]
On October 17, 2017, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on November 1, 2017. The payment date will be November 15, 2017. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
