# ADTN 8-K — 0001564590-18-008361 filed 2018-04-18

## item codes, every 8-K on or before 2018-05-09

- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2018-05-09

- none on or before 2018-05-09

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-008361:8k_2_02:1]
EX-99.1
2
adtn-ex991_7.htm
EX-99.1

[0001564590-18-008361:8k_2_02:2]
adtn-ex991_7.htm

[0001564590-18-008361:8k_2_02:3]
EXHIBIT 99.1

[0001564590-18-008361:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the First Quarter 2018 and Declares Quarterly Cash Dividend

[0001564590-18-008361:8k_2_02:5]
HUNTSVILLE, Ala.--(BUSINESS WIRE)—April 17, 2018-- ADTRAN, Inc. (NASDAQ:ADTN) reported results for the first quarter 2018. For the quarter, sales were $120.8 million compared to $170.3 million for the first quarter of 2017. Net loss was $9.1 million compared to net income of $6.7 million for the first quarter of 2017. Earnings per share, assuming dilution, were a loss of $0.19 compared to income of $0.14 for the first quarter of 2017. Non-GAAP earnings per share were a loss of $0.29 compared to income of $0.18 for the first quarter of 2017. GAAP earnings per share include the benefit of an acquisition-related bargain purchase gain, as well as the expense of a restructuring program. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001564590-18-008361:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “As we expected, our performance this quarter continued to be impacted by a merger-related review and slowdown in the spending at a domestic Tier 1 customer. While our international Tier 1 revenue exceeded expectations, lower overall product volumes resulting from the domestic slowdown, coupled with restructuring expenses and lower international gross margins, negatively affected our profit margins for the quarter and further hampered our results.  Looking ahead, we expect continued strength in our European business in the second quarter and a rebound in our North American business in the second half.  Our level of engagement with domestic and international Tier 1 customers remains at all-time highs, and our recent acquisition of the market leadership in EPON for the North American cable/MSO market positions us for further growth moving forward.”

[0001564590-18-008361:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the first quarter of 2018. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on May 2, 2018. The ex-dividend date is May 1, 2018, and the payment date is May 16, 2018.

[0001564590-18-008361:8k_2_02:8]
The Company confirmed that its first quarter conference call will be held Wednesday, April 18, 2018, at 9:30 a.m. Central Time. ADTRAN will webcast this conference. To listen, simply visit the Investor Relations site at www.investors.adtran.com approximately 10 minutes prior to the start of the call and click on the conference call link provided.

[0001564590-18-008361:8k_2_02:9]
An online replay and transcript of the conference call will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months.

[0001564590-18-008361:8k_2_02:10]
ADTRAN, Inc. is the leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit us at www.adtran.com, LinkedIn and Twitter.

[0001564590-18-008361:8k_2_02:11]
For more information, contact the company at 256-963-8220 or via email at investor.relations@adtran.com. On the Web, visit www.adtran.com.

[0001564590-18-008361:8k_2_02:12]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2017. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-18-008361:8k_2_02:13]
Condensed Consolidated Balance Sheet

[0001564590-18-008361:8k_2_02:14]
(Unaudited)

[0001564590-18-008361:8k_2_02:15]
(In thousands)

[0001564590-18-008361:8k_2_02:16]
|  | March 31, |  |  | December 31, |  |
|  | 2018 |  |  | 2017 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 82,623 |  |  | $ | 86,433 |  |
| Short-term investments |  | 16,402 |  |  |  | 16,129 |  |
| Accounts receivable, net |  | 80,883 |  |  |  | 144,150 |  |
| Other receivables |  | 34,690 |  |  |  | 26,578 |  |
| Inventory, net |  | 120,021 |  |  |  | 122,542 |  |
| Prepaid expenses and other current assets |  | 9,693 |  |  |  | 17,282 |  |
| Total Current Assets |  | 344,312 |  |  |  | 413,114 |  |
| Property, plant and equipment, net |  | 83,875 |  |  |  | 85,079 |  |
| Deferred tax assets, net |  | 21,661 |  |  |  | 23,428 |  |
| Goodwill |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  | 32,635 |  |  |  | 13,725 |  |
| Long-term investments |  | 156,472 |  |  |  | 130,256 |  |
| Total Assets | $ | 642,447 |  |  | $ | 669,094 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 50,653 |  |  | $ | 60,632 |  |
| Unearned revenue |  | 13,948 |  |  |  | 13,070 |  |
| Accrued expenses |  | 13,826 |  |  |  | 13,232 |  |
| Accrued wages and benefits |  | 15,863 |  |  |  | 15,948 |  |
| Income tax payable |  | 7,708 |  |  |  | 3,936 |  |
| Total Current Liabilities |  | 101,998 |  |  |  | 106,818 |  |
| Non-current unearned revenue |  | 4,154 |  |  |  | 4,556 |  |
| Other non-current liabilities |  | 34,590 |  |  |  | 34,209 |  |
| Bonds payable |  | 25,600 |  |  |  | 25,600 |  |
| Total Liabilities |  | 166,342 |  |  |  | 171,183 |  |
| Stockholders' Equity |  | 476,105 |  |  |  | 497,911 |  |
| Total Liabilities and Stockholders' Equity | $ | 642,447 |  |  | $ | 669,094 |  |

[0001564590-18-008361:8k_2_02:17]
Consolidated Statements of Income

[0001564590-18-008361:8k_2_02:18]
(Unaudited)

[0001564590-18-008361:8k_2_02:19]
(In thousands, except per share data)

[0001564590-18-008361:8k_2_02:20]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Sales |  |  |  |  |  |  |  |  |
| Products |  | $ | 105,253 |  |  | $ | 143,597 |  |
| Services |  |  | 15,553 |  |  |  | 26,682 |  |
| Total Sales |  |  | 120,806 |  |  |  | 170,279 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |
| Products |  |  | 68,612 |  |  |  | 76,664 |  |
| Services |  |  | 12,461 |  |  |  | 19,906 |  |
| Total Cost of Sales |  |  | 81,073 |  |  |  | 96,570 |  |
| Gross Profit |  |  | 39,733 |  |  |  | 73,709 |  |
| Selling, general and administrative expenses |  |  | 33,531 |  |  |  | 34,789 |  |
| Research and development expenses |  |  | 32,849 |  |  |  | 31,971 |  |
| Operating Income (Loss) |  |  | (26,647 | ) |  |  | 6,949 |  |
| Interest and dividend income |  |  | 866 |  |  |  | 933 |  |
| Interest expense |  |  | (132 | ) |  |  | (141 | ) |
| Net realized investment gain |  |  | 1,991 |  |  |  | 470 |  |
| Other income (expense), net |  |  | (57 | ) |  |  | 134 |  |
| Gain on bargain purchase of a business |  |  | 11,322 |  |  |  | — |  |
| Income (loss) before provision for income taxes |  |  | (12,657 | ) |  |  | 8,345 |  |
| Provision for income taxes |  |  | 3,521 |  |  |  | (1,694 | ) |
| Net Income (Loss) |  | $ | (9,136 | ) |  | $ | 6,651 |  |
| Weighted average shares outstanding – basic |  |  | 48,232 |  |  |  | 48,430 |  |
| Weighted average shares outstanding – diluted |  |  | 48,292 |  |  |  | 48,939 |  |
| Earnings per common share – basic |  | $ | (0.19 | ) |  | $ | 0.14 |  |
| Earnings per common share – diluted |  | $ | (0.19 | ) |  | $ | 0.14 |  |

[0001564590-18-008361:8k_2_02:21]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-18-008361:8k_2_02:22]
Consolidated Statements of Comprehensive Income

[0001564590-18-008361:8k_2_02:23]
(Unaudited)

[0001564590-18-008361:8k_2_02:24]
(In thousands)

[0001564590-18-008361:8k_2_02:25]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Net Income (Loss) |  | $ | (9,136 | ) |  | $ | 6,651 |  |
| Other Comprehensive Income (Loss), net of tax |  |  |  |  |  |  |  |  |
| Net unrealized gains (losses) on available-for-sale securities |  |  | (1,500 | ) |  |  | 1,335 |  |
| Net unrealized gains (losses) on cash flow hedges |  |  | — |  |  |  | 79 |  |
| Defined benefit plan adjustments |  |  | 62 |  |  |  | 55 |  |
| Foreign currency translation |  |  | 842 |  |  |  | 1,242 |  |
| Other Comprehensive Income (Loss), net of tax |  |  | (596 | ) |  |  | 2,711 |  |
| Comprehensive Income (Loss), net of tax |  | $ | (9,732 | ) |  | $ | 9,362 |  |

[0001564590-18-008361:8k_2_02:26]
Consolidated Statements of Cash Flows

[0001564590-18-008361:8k_2_02:27]
(Unaudited)

[0001564590-18-008361:8k_2_02:28]
(In thousands)

[0001564590-18-008361:8k_2_02:29]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (9,136 | ) |  | $ | 6,651 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,614 |  |  |  | 4,323 |  |
| Amortization of net premium on available-for-sale investments |  |  | 42 |  |  |  | 124 |  |
| Net realized gain on long-term investments |  |  | (1,991 | ) |  |  | (470 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | 67 |  |  |  | (16 | ) |
| Gain on bargain purchase of a business |  |  | (11,322 | ) |  |  | — |  |
| Stock-based compensation expense |  |  | 1,819 |  |  |  | 1,883 |  |
| Deferred income taxes |  |  | (1,332 | ) |  |  | (1,947 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 63,904 |  |  |  | 7,247 |  |
| Other receivables |  |  | (6,164 | ) |  |  | 1,884 |  |
| Inventory |  |  | 3,368 |  |  |  | (7,399 | ) |
| Prepaid expenses and other assets |  |  | 10,583 |  |  |  | (2,413 | ) |
| Accounts payable |  |  | (10,233 | ) |  |  | (1,713 | ) |
| Accrued expenses and other liabilities |  |  | 826 |  |  |  | (3,166 | ) |
| Income tax payable |  |  | 2,184 |  |  |  | 4,049 |  |
| Net cash provided by operating activities |  |  | 46,229 |  |  |  | 9,037 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (1,950 | ) |  |  | (3,872 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 16 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 49,074 |  |  |  | 24,471 |  |
| Purchases of available-for-sale investments |  |  | (75,960 | ) |  |  | (29,517 | ) |
| Acquisition of business |  |  | (7,806 | ) |  |  | — |  |
| Net cash used in investing activities |  |  | (36,642 | ) |  |  | (8,902 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 369 |  |  |  | 1,377 |  |
| Purchases of treasury stock |  |  | (10,171 | ) |  |  | (5,559 | ) |
| Dividend payments |  |  | (4,367 | ) |  |  | (4,369 | ) |
| Net cash used in financing activities |  |  | (14,169 | ) |  |  | (8,551 | ) |
| Net decrease in cash and cash equivalents |  |  | (4,582 | ) |  |  | (8,416 | ) |
| Effect of exchange rate changes |  |  | 772 |  |  |  | 1,079 |  |
| Cash and cash equivalents, beginning of period |  |  | 86,433 |  |  |  | 79,895 |  |
| Cash and cash equivalents, end of period |  | $ | 82,623 |  |  | $ | 72,558 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 95 |  |  | $ | 509 |  |

[0001564590-18-008361:8k_2_02:30]
Supplemental Information

[0001564590-18-008361:8k_2_02:31]
Restructuring Expenses

[0001564590-18-008361:8k_2_02:32]
(Unaudited)

[0001564590-18-008361:8k_2_02:33]
(In thousands)

[0001564590-18-008361:8k_2_02:34]
Restructuring expense was recorded in the following Consolidated Statements of Income categories for three months ended March 31, 2018 and 2017:

[0001564590-18-008361:8k_2_02:35]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Restructuring expense included in cost of sales |  | $ | 2,370 |  |  | $ | — |  |
| Selling, general and administrative expense |  |  | 1,766 |  |  |  | — |  |
| Research and development expense |  |  | 1,814 |  |  |  | — |  |
| Restructuring expense included in operating expenses |  |  | 3,580 |  |  |  | — |  |
| Total restructuring expense |  |  | 5,950 |  |  |  | — |  |
| Provision for income taxes |  |  | (1,547 | ) |  |  | — |  |
| Total restructuring expense, net of tax |  | $ | 4,403 |  |  | $ | — |  |

[0001564590-18-008361:8k_2_02:36]
Supplemental Information

[0001564590-18-008361:8k_2_02:37]
Acquisition Related Expenses, Amortizations and Adjustments

[0001564590-18-008361:8k_2_02:38]
(Unaudited)

[0001564590-18-008361:8k_2_02:39]
(In thousands)

[0001564590-18-008361:8k_2_02:40]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc., on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA), on September 13, 2016, we closed on the acquisition of CommScope’s active fiber business (CommScope), and on March 19, 2018, we closed on the acquisition of Sumitomo Electric Lightwave Corp.’s North American EPON business (Sumitomo). Acquisition related expenses, amortizations and adjustments for the three months ended March 31, 2018 and 2017 for all four transactions are as follows:

[0001564590-18-008361:8k_2_02:41]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 158 |  |  | $ | 158 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 92 |  |  |  | 208 |  |
| Amortization of other purchase accounting adjustments |  |  | — |  |  |  | 28 |  |
| Subtotal - NSN BBA acquisition |  |  | 92 |  |  |  | 236 |  |
| CommScope acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 125 |  |  |  | 686 |  |
| Amortization of other purchase accounting adjustments |  |  | 1 |  |  |  | 50 |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | 8 |  |
| Subtotal - CommScope acquisition |  |  | 126 |  |  |  | 744 |  |
| Sumitomo acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 110 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | 97 |  |  |  | — |  |
| Subtotal - Sumitomo acquisition |  |  | 207 |  |  |  | — |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 583 |  |  |  | 1,138 |  |
| Provision for income taxes |  |  | (156 | ) |  |  | (425 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 427 |  |  | $ | 713 |  |

[0001564590-18-008361:8k_2_02:42]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three months ended March 31, 2018 and 2017:

[0001564590-18-008361:8k_2_02:43]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Cost of goods sold |  | $ | 59 |  |  | $ | 50 |  |
| Selling, general and administrative expenses |  |  | 266 |  |  |  | 62 |  |
| Research and development expenses |  |  | 258 |  |  |  | 1,026 |  |
| Total acquisition related expenses, amortizations and adjustments included in operating expenses |  |  | 524 |  |  |  | 1,088 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 583 |  |  |  | 1,138 |  |
| Provision for income taxes |  |  | (156 | ) |  |  | (425 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 427 |  |  | $ | 713 |  |

[0001564590-18-008361:8k_2_02:44]
Supplemental Information

[0001564590-18-008361:8k_2_02:45]
Stock-based Compensation Expense

[0001564590-18-008361:8k_2_02:46]
(Unaudited)

[0001564590-18-008361:8k_2_02:47]
(In thousands)

[0001564590-18-008361:8k_2_02:48]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 95 |  |  | $ | 91 |  |
| Selling, general and administrative expense |  |  | 1,035 |  |  |  | 1,016 |  |
| Research and development expense |  |  | 689 |  |  |  | 776 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,724 |  |  |  | 1,792 |  |
| Total stock-based compensation expense |  |  | 1,819 |  |  |  | 1,883 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (384 | ) |  |  | (380 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,435 |  |  | $ | 1,503 |  |

[0001564590-18-008361:8k_2_02:49]
Reconciliation of GAAP net income per share, diluted, to

[0001564590-18-008361:8k_2_02:50]
Non-GAAP net income per share, diluted

[0001564590-18-008361:8k_2_02:51]
(Unaudited)

[0001564590-18-008361:8k_2_02:52]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2018 |  |  |  | 2017 |  |
| GAAP earnings per common share - diluted |  | $ | (0.19 | ) |  |  | 0.14 |  |
| Restructuring expense |  |  | 0.09 |  |  |  | — |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |
| Gain on bargain purchase of a business |  |  | (0.23 | ) |  |  | — |  |
| Non-GAAP earnings per common share - diluted |  | $ | (0.29 | ) |  |  | 0.18 |  |
