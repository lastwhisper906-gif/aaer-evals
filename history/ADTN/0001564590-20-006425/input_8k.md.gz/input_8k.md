# ADTN 8-K — 0001564590-20-006448 filed 2020-02-25

## item codes, every 8-K on or before 2020-02-25

- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2020-02-25

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-006448:8k_2_02:1]
EX-99.1
2
adtn-ex991_6.htm
EX-99.1

[0001564590-20-006448:8k_2_02:2]
adtn-ex991_6.htm

[0001564590-20-006448:8k_2_02:3]
EXHIBIT 99.1

[0001564590-20-006448:8k_2_02:4]
Supplemental Information

[0001564590-20-006448:8k_2_02:5]
Reconciliation of Operating Loss to Non-GAAP Operating Loss

[0001564590-20-006448:8k_2_02:6]
(Unaudited)

[0001564590-20-006448:8k_2_02:7]
|  |  | Three Months ended December 31, |  |  |  |  | Twelve Months ended December 31, |  |  |  |  |
|  |  | 2019 |  |  |  |  | 2018 |  |  |  |  | 2019 |  |  |  |  | 2018 |  |  |  |  |
| Operating Loss |  | $ | (14,070 | ) |  |  |  | $ | (3,783 | ) |  |  |  | $ | (39,963 | ) |  |  |  | $ | (45,422 | ) |  |  |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,357 |  |  | (1 | ) |  | 1,433 |  |  | (5 | ) |  | 5,703 |  |  | (8) |  |  | 4,084 |  |  | (14) |  |
| Stock-based compensation expense |  |  | 1,778 |  |  | (2 | ) |  | 1,912 |  |  | (6 | ) |  | 6,962 |  |  | (9) |  |  | 7,155 |  |  | (15) |  |
| Restructuring expenses |  |  | 1,356 |  |  | (3 | ) |  | 25 |  |  | (7 | ) |  | 6,014 |  |  | (10 | ) |  | 7,261 |  |  | (16) |  |
| Deferred compensation income (expense) |  |  | 536 |  |  | (4 | ) |  | (3,739 | ) |  | (4 | ) |  | 2,767 |  |  | (4) |  |  | (3,119 | ) |  | (4) |  |
| Asset impairments |  |  | — |  |  |  |  |  | — |  |  |  |  |  | 3,872 |  |  | (11 | ) |  | — |  |  |  |  |
| Gain on contingency |  |  | — |  |  |  |  |  | — |  |  |  |  |  | (1,230 | ) |  | (12 | ) |  | — |  |  |  |  |
| Settlement income |  |  | — |  |  |  |  |  | — |  |  |  |  |  | (746 | ) |  | (13 | ) |  | — |  |  |  |  |
| Non-GAAP Operating Loss |  | $ | (9,043 | ) |  |  |  | $ | (4,152 | ) |  |  |  | $ | (16,621 | ) |  |  |  | $ | (30,041 | ) |  |  |  |

[0001564590-20-006448:8k_2_02:8]
(1) $0.4 million is included in total cost of sales, $0.5 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:9]
(2) $0.1 million is included in total cost of sales, $1.0 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:10]
(3) $0.3 million is included in selling, general and administrative expenses and $1.1 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:11]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN, Inc. Deferred Compensation Program for Employees (as amended and restated as of June 1, 2010) per ASU 2016-01, all of which is included in selling, general and administrative expenses on the consolidated statement of income.

[0001564590-20-006448:8k_2_02:12]
(5) $0.5 million is included in total cost of sales, $0.6 million is included in selling, general and administrative expenses and $0.3 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:13]
(6) $0.1 million is included in total cost of sales, $1.1 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:14]
(7) $0.1 million is included in selling, general and administrative expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:15]
(8) $1.7 million is included in total cost of sales, $2.1 million is included in selling, general and administrative expenses and $1.9 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:16]
(9) $0.4 million is included in total cost of sales, $3.9 million is included in selling, general and administrative expenses and $2.7 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:17]
(10) $0.8 million is included in total cost of sales, $2.3 million is included in selling, general and administrative expenses and $2.9 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:18]
(11) Includes abandonment of certain information technology projects.

[0001564590-20-006448:8k_2_02:19]
(12) Includes gain related to unearned contingent liabilities recognized upon the acquisition of a business in November 2018.

[0001564590-20-006448:8k_2_02:20]
(13) Includes income related to certain freight forwarder claim settlements which were received during the three months ended June 30, 2019, all of which is included in total cost of sales on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:21]
(14) $1.4 million is included in total cost of sales, $1.5 million is included in selling, general and administrative expenses and $1.2 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:22]
(15) $0.4 million is included in total cost of sales, $4.0 million is included in selling, general and administrative expenses and $2.8 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:23]
(16) $2.8 million is included in total cost of sales, $2.7 million is included in selling, general and administrative expenses and $1.8 million is included in research and development expenses on the consolidated statements of income.

[0001564590-20-006448:8k_2_02:24]
Supplemental Information

[0001564590-20-006448:8k_2_02:25]
Reconciliation of Net Loss and Loss per Common Share – Basic and Diluted to Non-GAAP

[0001564590-20-006448:8k_2_02:26]
Net Income (Loss) and Non-GAAP Earnings (Loss) per Common Share – Basic and Diluted

[0001564590-20-006448:8k_2_02:27]
(Unaudited)

[0001564590-20-006448:8k_2_02:28]
|  |  | Three Months ended December 31, |  |  |  | Twelve Months ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  |  | 2019 |  |  | 2018 |  |
| Net Loss |  | $ | (11,624 | ) |  | $ | (8,447 | ) |  |  | $ | (52,982 | ) |  | $ | (19,342 | ) |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,357 |  |  |  | 1,433 |  |  |  |  | 5,703 |  |  |  | 4,084 |  |
| Stock-based compensation expense |  |  | 1,778 |  |  |  | 1,912 |  |  |  |  | 6,962 |  |  |  | 7,155 |  |
| Restructuring expenses |  |  | 1,356 |  |  |  | 25 |  |  |  |  | 6,014 |  |  |  | 7,261 |  |
| Pension expense(1) |  |  | 195 |  |  |  | 59 |  |  |  |  | 795 |  |  |  | 247 |  |
| Valuation allowance |  |  | 5,723 |  |  |  | — |  |  |  |  | 42,778 |  |  |  | — |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  |  | 3,872 |  |  |  | — |  |
| Gain on contingency |  |  | — |  |  |  | — |  |  |  |  | (1,230 | ) |  |  | — |  |
| Settlement income |  |  | — |  |  |  | — |  |  |  |  | (746 | ) |  |  | — |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | (11,322 | ) |
| Tax effect of adjustments to net income (loss) |  |  | (1,251 | ) |  |  | (818 | ) |  |  |  | (5,675 | ) |  |  | (4,476 | ) |
| Non-GAAP Net Income (Loss) |  | $ | (2,466 | ) |  | $ | (5,836 | ) |  |  | $ | 5,491 |  |  | $ | (16,393 | ) |
| Weighted average shares outstanding – basic |  |  | 47,936 |  |  |  | 47,730 |  |  |  |  | 47,836 |  |  |  | 47,880 |  |
| Weighted average shares outstanding – diluted |  |  | 47,936 |  |  |  | 47,730 |  |  |  |  | 47,836 |  |  |  | 47,880 |  |
| Loss per common share - basic |  | $ | (0.24 | ) |  | $ | (0.18 | ) |  |  | $ | (1.11 | ) |  | $ | (0.40 | ) |
| Loss per common share - diluted |  | $ | (0.24 | ) |  | $ | (0.18 | ) |  |  | $ | (1.11 | ) |  | $ | (0.40 | ) |
| Non-GAAP earnings (loss) per common share - basic |  | $ | (0.05 | ) |  | $ | (0.12 | ) |  |  | $ | 0.11 |  |  | $ | (0.34 | ) |
| Non-GAAP earnings (loss) per common share - diluted |  | $ | (0.05 | ) |  | $ | (0.12 | ) |  |  | $ | 0.11 |  |  | $ | (0.34 | ) |

[0001564590-20-006448:8k_2_02:29]
(1) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.
