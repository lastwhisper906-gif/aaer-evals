# ADTN note change history — 0001564590-19-035143 → 0001564590-19-040490


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-11-05):
[0001564590-19-040490:note_history:1]
Securities Class Action Lawsuit

- added (2019-11-05):
[0001564590-19-040490:note_history:2]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers.  The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019.  The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and shipments from a Latin American customer.  Investors in ADTRAN securities have until December 16, 2019 to move the court to serve as lead plaintiff in this action.  We disagree with the claims made in the complaint and intend to vigorously defend against this lawsuit.  At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

- added (2019-11-05):
[0001564590-19-040490:note_history:3]
Other Legal Matters

- added (2019-11-05):
[0001564590-19-040490:note_history:4]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes.  Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources.  Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions.  While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

- added (2019-11-05):
[0001564590-19-040490:note_history:5]
Investment Commitment

- changed (2019-11-05):
[0001564590-19-040490:note_history:6]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied as of September 30, 2019.
  (was, 2019-09-20, similarity 0.8961):
[0001564590-19-035143:note_history:6]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied to these commitments as of June 30, 2019.

- removed (2019-11-05):
[0001564590-19-035143:note_history:7]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants may seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001564590-19-040490:note_history:8]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 28, 2019 (as amended on September 20, 2019, the “2018 Form 10-K”).
  (was, 2019-09-20, similarity 0.9232):
[0001564590-19-035143:note_history:8]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K/A for the year ended December 31, 2018, filed on September 20, 2019, with the SEC.

- changed (2019-11-05):
[0001564590-19-040490:note_history:9]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the excess and obsolete inventory reserves, warranty reserves, customer rebates, determination of the deferred and accrued revenue components of multiple performance obligations sales agreements, estimated costs to complete obligations associated with deferred and accrued revenue, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.
  (was, 2019-09-20, similarity 0.9901):
[0001564590-19-035143:note_history:9]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the excess, obsolete and slow moving inventory reserves, warranty reserves, customer rebates, determination of the deferred and accrued revenue components of multiple performance obligations sales agreements, estimated costs to complete obligations associated with deferred and accrued revenue, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

- changed (2019-11-05):
[0001564590-19-040490:note_history:10]
During the three months ended June 30, 2019, the Company revised the methodology used in estimating its excess and obsolete inventory reserves. Under the revised methodology, we establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on historical usage, known trends, inventory age, and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserves. See Note 8 for additional information.
  (was, 2019-09-20, similarity 0.9232):
[0001564590-19-035143:note_history:10]
During the three months ended June 30, 2019, the Company revised the methodology in how it estimates its excess and obsolete inventory reserves. Under the revised methodology, we establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on historical usage, known trends, inventory age, and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 8 of Notes to Condensed Consolidated Financial Statements for additional information.

- changed (2019-11-05):
[0001564590-19-040490:note_history:11]
Correction of Immaterial Misstatements
  (was, 2019-09-20, similarity 0.987):
[0001564590-19-035143:note_history:11]
Correction of Immaterial Misstatements.

- changed (2019-11-05):
[0001564590-19-040490:note_history:12]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserves and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in the Company’s excess and obsolete inventory reserves and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company has corrected this misstatement in the Unaudited Condensed Consolidated Statement of Cash Flows for the nine months ended September 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management has determined that these misstatements were not material to any of its previously issued financial statements and that correction of the misstatements is also not material to the current or estimated annual 2019 financial results on either a quantitative and qualitative basis.
  (was, 2019-09-20, similarity 0.9314):
[0001564590-19-035143:note_history:12]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The accompanying Unaudited Condensed Consolidated Statement of Cash Flows for the six months ended June 30, 2019 correctly reflects the $1.0 million insurance recovery as a cash inflow from investing activities. Management has determined that these misstatements were not material to any of its previously issued financial statements and that correction of the misstatements is also not material to the current or estimated annual 2019 financial results on both a quantitative and qualitative basis.

- changed (2019-11-05):
[0001564590-19-040490:note_history:13]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but do not expect it will have a material effect on our financial statement disclosures.
  (was, 2019-09-20, similarity 0.9861):
[0001564590-19-035143:note_history:13]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of Accounting Standards Codification (“ASC”) 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but do not expect it will have a material effect on our financial statement disclosures.

- changed (2019-11-05):
[0001564590-19-040490:note_history:14]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but do not expect it will have a material effect on our financial statement disclosures.
  (was, 2019-09-20, similarity 0.9932):
[0001564590-19-035143:note_history:14]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (PBO) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (ABO) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but do not expect it will have a material effect on our financial statement disclosures.

- added (2019-11-05):
[0001564590-19-040490:note_history:15]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provided for an optional transition method allowing for the application of the legacy lease guidance, Leases (Topic 840), including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. In March 2019, the FASB issued ASU 2019-01, Leases (Topic 842) Codification Improvements, which removed the requirement for an entity to disclose in the interim periods after adoption, the effect of the change on income from continuing operations, net income, any other affected financial statement line item, and any affected per share amount. For lessors, the new leasing standard requires leases to be classified as sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard and related updates were effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.

- changed (2019-11-05):
[0001564590-19-040490:note_history:16]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. At that time, the Company elected to carry forward the legacy ASC 840 disclosures for comparative periods and, therefore, did not adjust the comparative period financial information prior to January 1, 2019. In addition, the Company elected the package of practical expedients which allows for companies to not reassess whether any expired or existing contracts are or contain leases, not reassess historical lease classifications for expired or existing contracts and not reassess initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and non-lease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our Condensed Consolidated Balance Sheet of $10.3 million as of January 1, 2019, primarily related to our operating leases for office space, automobiles and other equipment.
  (was, 2019-09-20, similarity 0.9763):
[0001564590-19-035143:note_history:16]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. The Company has elected to carry forward the legacy ASC 840 disclosures for comparative periods and, therefore, did not adjust the comparative period financial information prior to January 1, 2019. In addition, the Company elected the package of practical expedients which allows for companies to not reassess whether any expired or existing contracts are or contain leases, not reassess historical lease classifications for expired or existing contracts and not reassess initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and non-lease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our Condensed Consolidated Balance Sheet of $10.3 million, primarily related to our operating leases for office space, automobiles and other equipment.

- changed (2019-11-05):
[0001564590-19-040490:note_history:17]
As a lessee, the adoption of this standard did not have a material impact on our Condensed Consolidated Statement of Income or Statement of Cash Flows. See Note 12 for additional information.
  (was, 2019-09-20, similarity 0.9974):
[0001564590-19-035143:note_history:17]
As a lessee, the adoption of this standard did not have a material impact on our Condensed Consolidated Statement of Income or Statement of Cash Flow. See Note 11 for additional information.

- changed (2019-11-05):
[0001564590-19-040490:note_history:18]
As a lessor, the adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Balance Sheet, Condensed Consolidated Statement of Income or Condensed Consolidated Statement of Cash Flows. Prior to and after adoption, all of our leases in which we are the lessor were classified as sales-type leases.
  (was, 2019-09-20, similarity 0.9771):
[0001564590-19-035143:note_history:18]
As a lessor, the adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Balance Sheet, Condensed Consolidated Statement of Income or Condensed Statement of Cash Flow. Prior to and after adoption, all of our leases in which we are the lessor were classified as sales-types leases.

- changed (2019-11-05):
[0001564590-19-040490:note_history:19]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expanded and refined hedge accounting for both financial and non-financial risk components, aligned the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and included certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness.  In October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (“SOFR”) Overnight Index Swap (“OIS”) Rate as a Benchmark Interest Rate for Hedge Accounting, which permits the OIS rate based on SOFR as a U.S. benchmark interest rate. Both ASU 2017-12 and ASU 2018-16 were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2017-12 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements as we did not have any hedging instruments as of the date of adoption.
  (was, 2019-09-20, similarity 0.9458):
[0001564590-19-035143:note_history:19]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expanded and refined hedge accounting for both financial and non-financial risk components, aligned the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and included certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness.  In October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting, which permits the OIS rate based on SOFR as a U.S. benchmark interest rate. Both ASU 2017-12 and ASU 2018-16 were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2017-12 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements as we currently do not have any hedging instruments.

- removed (2019-11-05):
[0001564590-19-035143:note_history:20]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provided for an optional transition method allowing for the application of the legacy lease guidance, Leases (Topic 840), including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. In March 2019, the FASB issued ASU 2019-01, Leases (Topic 842) Codification Improvements, which removed the requirement for an entity to disclose in the interim periods after adoption, the effect of the change on income from continuing operations, net income, any other affected financial statement line item, and any affected per share amount. For lessors, the new leasing standard requires leases to be classified as sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard and related updates were effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001564590-19-040490:note_history:21]
At September 30, 2019, we held the following debt securities and other investments, recorded at fair value:
  (was, 2019-09-20, similarity 0.9074):
[0001564590-19-035143:note_history:21]
At December 31, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:

- changed (2019-11-05):
[0001564590-19-040490:note_history:22]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,733 |  |  | $ | 95 |  |  | $ | — |  |  | $ | 10,828 |  |
| Municipal fixed-rate bonds |  |  | 931 |  |  |  | — |  |  |  | (1 | ) |  |  | 930 |  |
| Asset-backed bonds |  |  | 7,222 |  |  |  | 35 |  |  |  | (2 | ) |  |  | 7,255 |  |
| Mortgage/Agency-backed bonds |  |  | 7,366 |  |  |  | 29 |  |  |  | (7 | ) |  |  | 7,388 |  |
| U.S. government bonds |  |  | 9,160 |  |  |  | 4 |  |  |  | (21 | ) |  |  | 9,143 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (3 | ) |  |  | 369 |  |
| Available-for-sale debt securities held at fair value |  | $ | 35,784 |  |  | $ | 163 |  |  | $ | (34 | ) |  | $ | 35,913 |  |
  (was, 2019-09-20, similarity 0.8338):
[0001564590-19-035143:note_history:22]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 20,777 |  |  | $ | 19 |  |  | $ | (112 | ) |  | $ | 20,684 |  |
| Municipal fixed-rate bonds |  |  | 1,339 |  |  |  | — |  |  |  | (26 | ) |  |  | 1,313 |  |
| Asset-backed bonds |  |  | 5,230 |  |  |  | 5 |  |  |  | (14 | ) |  |  | 5,221 |  |
| Mortgage/Agency-backed bonds |  |  | 3,833 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 3,791 |  |
| U.S. government bonds |  |  | 9,271 |  |  |  | 1 |  |  |  | (66 | ) |  |  | 9,206 |  |
| Foreign government bonds |  |  | 592 |  |  |  | — |  |  |  | (8 | ) |  |  | 584 |  |
| Available-for-sale debt securities held at fair value |  | $ | 41,042 |  |  | $ | 27 |  |  | $ | (270 | ) |  | $ | 40,799 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 397 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 66,796 |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:23]
At December 31, 2018, we held the following debt securities and other investments, recorded at fair value:
  (was, 2019-09-20, similarity 0.8815):
[0001564590-19-035143:note_history:23]
At June 30, 2019, we held the following debt securities and other investments, recorded at either fair value or cost:

- changed (2019-11-05):
[0001564590-19-040490:note_history:24]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 20,777 |  |  | $ | 19 |  |  | $ | (112 | ) |  | $ | 20,684 |  |
| Municipal fixed-rate bonds |  |  | 1,339 |  |  |  | — |  |  |  | (26 | ) |  |  | 1,313 |  |
| Asset-backed bonds |  |  | 5,230 |  |  |  | 5 |  |  |  | (14 | ) |  |  | 5,221 |  |
| Mortgage/Agency-backed bonds |  |  | 3,833 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 3,791 |  |
| U.S. government bonds |  |  | 9,271 |  |  |  | 1 |  |  |  | (66 | ) |  |  | 9,206 |  |
| Foreign government bonds |  |  | 592 |  |  |  | — |  |  |  | (8 | ) |  |  | 584 |  |
| Available-for-sale debt securities held at fair value |  | $ | 41,042 |  |  | $ | 27 |  |  | $ | (270 | ) |  | $ | 40,799 |  |
  (was, 2019-09-20, similarity 0.8386):
[0001564590-19-035143:note_history:24]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 14,132 |  |  | $ | 111 |  |  | $ | (4 | ) |  | $ | 14,239 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | (3 | ) |  |  | 927 |  |
| Asset-backed bonds |  |  | 6,580 |  |  |  | 32 |  |  |  | (3 | ) |  |  | 6,609 |  |
| Mortgage/Agency-backed bonds |  |  | 5,362 |  |  |  | 23 |  |  |  | (6 | ) |  |  | 5,379 |  |
| U.S. government bonds |  |  | 5,027 |  |  |  | 6 |  |  |  | (6 | ) |  |  | 5,027 |  |
| Foreign government bonds |  |  | 1,852 |  |  |  | 1 |  |  |  | (1 | ) |  |  | 1,852 |  |
| Available-for-sale debt securities held at fair value |  | $ | 33,883 |  |  | $ | 173 |  |  | $ | (23 | ) |  | $ | 34,033 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,199 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 60,832 |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:25]
As of September 30, 2019, our debt securities had the following contractual maturities:
  (was, 2019-09-20, similarity 0.9299):
[0001564590-19-035143:note_history:25]
As of June 30, 2019, our debt securities had the following contractual maturities:

- changed (2019-11-05):
[0001564590-19-040490:note_history:26]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 3,154 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 4,316 |  |  |  | 930 |  |  |  | 941 |  |  |  | 215 |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 3,068 |  |  |  | — |  |  |  | 2,475 |  |  |  | 1,072 |  |  |  | 7,528 |  |  |  | — |  |
| Three to five years |  |  | 290 |  |  |  | — |  |  |  | 1,593 |  |  |  | 920 |  |  |  | 1,615 |  |  |  | 369 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,666 |  |  |  | 680 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 580 |  |  |  | 4,501 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 10,828 |  |  | $ | 930 |  |  | $ | 7,255 |  |  | $ | 7,388 |  |  | $ | 9,143 |  |  | $ | 369 |  |
  (was, 2019-09-20, similarity 0.9009):
[0001564590-19-035143:note_history:26]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 2,749 |  |  | $ | — |  |  | $ | 96 |  |  | $ | — |  |  | $ | 2,443 |  |  | $ | — |  |
| One to two years |  |  | 8,460 |  |  |  | 927 |  |  |  | 430 |  |  |  | 264 |  |  |  | — |  |  |  | 891 |  |
| Two to three years |  |  | 3,030 |  |  |  | — |  |  |  | 1,667 |  |  |  | 588 |  |  |  | 1,346 |  |  |  | 961 |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 2,018 |  |  |  | 510 |  |  |  | 1,238 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,772 |  |  |  | 425 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 626 |  |  |  | 3,592 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 14,239 |  |  | $ | 927 |  |  | $ | 6,609 |  |  | $ | 5,379 |  |  | $ | 5,027 |  |  | $ | 1,852 |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:27]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Gross realized gains on debt securities |  | $ | 36 |  |  | $ | 24 |  |  | $ | 85 |  |  | $ | 49 |  |
| Gross realized losses on debt securities |  |  | (7 | ) |  |  | (50 | ) |  |  | (40 | ) |  |  | (365 | ) |
| Total gain (loss) recognized, net |  | $ | 29 |  |  | $ | (26 | ) |  | $ | 45 |  |  | $ | (316 | ) |
  (was, 2019-09-20, similarity 0.8238):
[0001564590-19-035143:note_history:27]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Gross realized gains on debt securities |  | $ | 8 |  |  | $ | 25 |  |  | $ | 49 |  |  | $ | 25 |  |
| Gross realized losses on debt securities |  |  | (14 | ) |  |  | (241 | ) |  |  | (33 | ) |  |  | (315 | ) |
| Total gain (loss) recognized, net |  | $ | (6 | ) |  | $ | (216 | ) |  | $ | 16 |  |  | $ | (290 | ) |

- changed (2019-11-05):
[0001564590-19-040490:note_history:28]
At September 30, 2019, we held a $25.6 million restricted certificate of deposit that is carried at cost and matures on January 8, 2020. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the “Bond”), which totaled $25.6 million at September 30, 2019 and December 31, 2018. At September 30, 2019 and December 31, 2018, the estimated fair value of the Bond using a level 2 valuation technique was approximately $25.6 million and $25.4 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AA+. We have the right to offset the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the State of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. We have made annual principal payments in addition to the interest amounts that are due. The restricted funds held as collateral against the outstanding principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity.
  (was, 2019-09-20, similarity 0.9554):
[0001564590-19-035143:note_history:28]
At June 30, 2019, we held a $25.6 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the “Bond”), which totaled $25.6 million at June 30, 2019 and December 31, 2018. At June 30, 2019 and December 31, 2018, the estimated fair value of the Bond using a level 2 valuation technique was approximately $25.6 million and $25.4 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to offset the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the State of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. We have made annual principal payments in addition to the interest amounts that are due. The restricted funds held as collateral against the outstanding principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity on January 1, 2020.

- changed (2019-11-05):
[0001564590-19-040490:note_history:29]
ASU 2016-01 also provides a measurement alternative for equity investments that do not have a readily determinable fair value in which investments can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. We elected to record our equity investment that does not have a readily determinable fair value using the measurement alternative method. As of December 31, 2018, the Company had a note receivable of approximately $4.3 million, which was included in other receivables on the Condensed Consolidated Balance Sheet. During the three months ended March 31, 2019, this amount was repaid and reissued in the form of debt and equity. Approximately $3.4 million was issued as an equity investment, which represented a non-cash investing activity. The carrying value of this investment under the measurement alternative was $3.4 million as of September 30, 2019. The remaining amount, approximately $0.9 million, was converted into a new note receivable, which is included in other receivables on the Condensed Consolidated Balance Sheet and represents a non-cash operating activity.
  (was, 2019-09-20, similarity 0.9231):
[0001564590-19-035143:note_history:29]
ASU 2016-01 also provides a measurement alternative for equity investments that do not have a readily determinable fair value in which investments can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. We elected to record our equity investment that does not have a readily determinable fair value using the measurement alternative method. As of December 31, 2018, the Company had a note receivable of approximately $4.3 million, which was included in other receivables on the Condensed Consolidated Balance Sheet. During the three months ended March 31, 2019, this amount was repaid as follows. Approximately $3.4 million was issued as an equity investment, which represented a non-cash investing activity. The carrying value of this investment under the measurement alternative was $3.4 million as of June 30, 2019. The remaining amount was converted into a new note receivable, which is included in other receivables on the Condensed Consolidated Balance Sheet and represents a non-cash operating activity.

- changed (2019-11-05):
[0001564590-19-040490:note_history:30]
Realized and unrealized gains and losses for our marketable equity securities for the three and nine months ended September 30, 2019 and 2018 were as follows:
  (was, 2019-09-20, similarity 0.9456):
[0001564590-19-035143:note_history:30]
Realized and unrealized gains and losses for our marketable equity securities for the three and six months ended June 30, 2019 and 2018 were as follows:

- changed (2019-11-05):
[0001564590-19-040490:note_history:31]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (20 | ) |  | $ | 1,240 |  |  | $ | (83 | ) |  | $ | 1,587 |  |
| Unrealized gains (losses) on equity securities held |  |  | (225 | ) |  |  | 3,293 |  |  |  | 8,233 |  |  |  | 4,129 |  |
| Total gain (loss) recognized, net |  | $ | (245 | ) |  | $ | 4,533 |  |  | $ | 8,150 |  |  | $ | 5,716 |  |
  (was, 2019-09-20, similarity 0.7783):
[0001564590-19-035143:note_history:31]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (49 | ) |  | $ | (52 | ) |  | $ | (63 | ) |  | $ | 347 |  |
| Unrealized gains on equity securities held |  |  | 2,540 |  |  |  | 1,258 |  |  |  | 8,458 |  |  |  | 836 |  |
| Total gain recognized, net |  | $ | 2,491 |  |  | $ | 1,206 |  |  | $ | 8,395 |  |  | $ | 1,183 |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:32]
As of September 30, 2019 and 2018, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.
  (was, 2019-09-20, similarity 0.9651):
[0001564590-19-035143:note_history:32]
As of June 30, 2019 and 2018, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.

- changed (2019-11-05):
[0001564590-19-040490:note_history:33]
|  |  |  |  |  |  | Fair Value Measurements at September 30, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,817 |  |  | $ | 1,817 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 1,295 |  |  |  | — |  |  |  | 1,295 |  |  |  | — |  |
| Cash equivalents |  |  | 3,112 |  |  |  | 1,817 |  |  |  | 1,295 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,828 |  |  |  | — |  |  |  | 10,828 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,255 |  |  |  | — |  |  |  | 7,255 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 7,388 |  |  |  | — |  |  |  | 7,388 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,143 |  |  |  | 9,143 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 369 |  |  |  | — |  |  |  | 369 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 32,543 |  |  |  | 32,543 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 165 |  |  |  | 165 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,580 |  |  |  | 20,580 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 89,201 |  |  |  | 62,431 |  |  |  | 26,770 |  |  |  | — |  |
| Total |  | $ | 92,313 |  |  | $ | 64,248 |  |  | $ | 28,065 |  |  | $ | — |  |
  (was, 2019-09-20, similarity 0.925):
[0001564590-19-035143:note_history:33]
|  |  |  |  |  |  | Fair Value Measurements at June 30, 2019 Using |  |
| (In thousands) |  | Cost or Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,337 |  |  | $ | 1,337 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 2,973 |  |  |  | — |  |  |  | 2,973 |  |  |  | — |  |
| Cash equivalents |  |  | 4,310 |  |  |  | 1,337 |  |  |  | 2,973 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 14,239 |  |  |  | — |  |  |  | 14,239 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 927 |  |  |  | — |  |  |  | 927 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,609 |  |  |  | — |  |  |  | 6,609 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,379 |  |  |  | — |  |  |  | 5,379 |  |  |  | — |  |
| U.S. government bonds |  |  | 5,027 |  |  |  | 5,027 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,852 |  |  |  | — |  |  |  | 1,852 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 32,548 |  |  |  | 32,548 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 185 |  |  |  | 185 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,228 |  |  |  | 21,228 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 87,994 |  |  |  | 58,988 |  |  |  | 29,006 |  |  |  | — |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other investments |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other investments held at cost |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 95,679 |  |  | $ | 60,325 |  |  | $ | 31,979 |  |  | $ | — |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:34]
|  |  |  |  |  |  | Fair Value Measurements at December 31, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,554 |  |  | $ | 1,554 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 1,554 |  |  |  | 1,554 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,684 |  |  |  | — |  |  |  | 20,684 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,313 |  |  |  | — |  |  |  | 1,313 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,221 |  |  |  | — |  |  |  | 5,221 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 3,791 |  |  |  | — |  |  |  | 3,791 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,206 |  |  |  | 9,206 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 584 |  |  |  | — |  |  |  | 584 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,763 |  |  |  | 26,763 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 253 |  |  |  | 253 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 18,256 |  |  |  | 18,256 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 86,071 |  |  |  | 54,478 |  |  |  | 31,593 |  |  |  | — |  |
| Total |  | $ | 87,625 |  |  | $ | 56,032 |  |  | $ | 31,593 |  |  | $ | — |  |
  (was, 2019-09-20, similarity 0.9971):
[0001564590-19-035143:note_history:34]
|  |  |  |  |  |  | Fair Value Measurements at December 31, 2018 Using |  |
| (In thousands) |  | Cost or Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,554 |  |  | $ | 1,554 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 1,554 |  |  |  | 1,554 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,684 |  |  |  | — |  |  |  | 20,684 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,313 |  |  |  | — |  |  |  | 1,313 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,221 |  |  |  | — |  |  |  | 5,221 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 3,791 |  |  |  | — |  |  |  | 3,791 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,206 |  |  |  | 9,206 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 584 |  |  |  | — |  |  |  | 584 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,763 |  |  |  | 26,763 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 253 |  |  |  | 253 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 18,256 |  |  |  | 18,256 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 86,071 |  |  |  | 54,478 |  |  |  | 31,593 |  |  |  | — |  |
| Total |  | $ | 87,625 |  |  | $ | 56,032 |  |  | $ | 31,593 |  |  | $ | — |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:35]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.
  (was, 2019-09-20, similarity 0.967):
[0001564590-19-035143:note_history:35]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001564590-19-040490:note_history:36]
The following table disaggregates our revenue by reportable segment and revenue category for the three months ended September 30, 2019 and 2018:
  (was, 2019-09-20, similarity 0.9588):
[0001564590-19-035143:note_history:36]
The following table disaggregates our revenue by reportable segment and revenue category for the three months ended June 30, 2019 and 2018:

- changed (2019-11-05):
[0001564590-19-040490:note_history:37]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 48,902 |  |  | $ | 16,212 |  |  | $ | 65,114 |  |  | $ | 76,046 |  |  | $ | 15,855 |  |  | $ | 91,901 |  |
| Subscriber Solutions & Experience(1) |  |  | 40,382 |  |  |  | 2,094 |  |  |  | 42,476 |  |  |  | 37,313 |  |  |  | 1,239 |  |  |  | 38,552 |  |
| Traditional & Other Products |  |  | 4,734 |  |  |  | 1,768 |  |  |  | 6,502 |  |  |  | 7,684 |  |  |  | 2,198 |  |  |  | 9,882 |  |
| Total |  | $ | 94,018 |  |  | $ | 20,074 |  |  | $ | 114,092 |  |  | $ | 121,043 |  |  | $ | 19,292 |  |  | $ | 140,335 |  |
  (was, 2019-09-20, similarity 0.9521):
[0001564590-19-035143:note_history:37]
|  |  | For the Three Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 96,262 |  |  | $ | 13,159 |  |  | $ | 109,421 |  |  | $ | 75,222 |  |  | $ | 9,520 |  |  | $ | 84,742 |  |
| Subscriber Solutions & Experience(1) |  |  | 38,444 |  |  |  | 2,058 |  |  |  | 40,502 |  |  |  | 33,306 |  |  |  | 1,254 |  |  |  | 34,560 |  |
| Traditional & Other Products |  |  | 4,461 |  |  |  | 2,007 |  |  |  | 6,468 |  |  |  | 6,535 |  |  |  | 2,211 |  |  |  | 8,746 |  |
| Total |  | $ | 139,167 |  |  | $ | 17,224 |  |  | $ | 156,391 |  |  | $ | 115,063 |  |  | $ | 12,985 |  |  | $ | 128,048 |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:38]
The following table disaggregates our revenue by reportable segment and revenue category for the nine months ended September 30, 2019 and 2018:
  (was, 2019-09-20, similarity 0.9394):
[0001564590-19-035143:note_history:38]
The following table disaggregates our revenue by reportable segment and revenue category for the six months ended June 30, 2019 and 2018:

- changed (2019-11-05):
[0001564590-19-040490:note_history:39]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 230,837 |  |  | $ | 43,476 |  |  | $ | 274,313 |  |  | $ | 220,653 |  |  | $ | 37,670 |  |  | $ | 258,323 |  |
| Subscriber Solutions & Experience(1) |  |  | 113,545 |  |  |  | 6,186 |  |  |  | 119,731 |  |  |  | 99,396 |  |  |  | 3,817 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 14,625 |  |  |  | 5,605 |  |  |  | 20,230 |  |  |  | 21,310 |  |  |  | 6,343 |  |  |  | 27,653 |  |
| Total |  | $ | 359,007 |  |  | $ | 55,267 |  |  | $ | 414,274 |  |  | $ | 341,359 |  |  | $ | 47,830 |  |  | $ | 389,189 |  |
  (was, 2019-09-20, similarity 0.946):
[0001564590-19-035143:note_history:39]
|  |  | For the Six Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 181,935 |  |  | $ | 27,264 |  |  | $ | 209,199 |  |  | $ | 144,607 |  |  | $ | 21,815 |  |  | $ | 166,422 |  |
| Subscriber Solutions & Experience(1) |  |  | 73,163 |  |  |  | 4,092 |  |  |  | 77,255 |  |  |  | 62,083 |  |  |  | 2,578 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 9,891 |  |  |  | 3,837 |  |  |  | 13,728 |  |  |  | 13,626 |  |  |  | 4,145 |  |  |  | 17,771 |  |
| Total |  | $ | 264,989 |  |  | $ | 35,193 |  |  | $ | 300,182 |  |  | $ | 220,316 |  |  | $ | 28,538 |  |  | $ | 248,854 |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:40]
The table below presents sales information by category for the three and nine months ended September 30, 2019 and 2018:
  (was, 2019-09-20, similarity 0.9259):
[0001564590-19-035143:note_history:40]
The table below presents sales information by category for the three and six months ended June 30, 2019 and 2018:

- changed (2019-11-05):
[0001564590-19-040490:note_history:41]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Access & Aggregation |  | $ | 65,114 |  |  | $ | 91,901 |  |  | $ | 274,313 |  |  | $ | 258,323 |  |
| Subscriber Solutions & Experience |  |  | 42,476 |  |  |  | 38,552 |  |  |  | 119,731 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 6,502 |  |  |  | 9,882 |  |  |  | 20,230 |  |  |  | 27,653 |  |
| Total |  | $ | 114,092 |  |  | $ | 140,335 |  |  | $ | 414,274 |  |  | $ | 389,189 |  |
  (was, 2019-09-20, similarity 0.9392):
[0001564590-19-035143:note_history:41]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Access & Aggregation |  | $ | 109,421 |  |  | $ | 84,742 |  |  | $ | 209,199 |  |  | $ | 166,422 |  |
| Subscriber Solutions & Experience |  |  | 40,502 |  |  |  | 34,560 |  |  |  | 77,255 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 6,468 |  |  |  | 8,746 |  |  |  | 13,728 |  |  |  | 17,771 |  |
| Total |  | $ | 156,391 |  |  | $ | 128,048 |  |  | $ | 300,182 |  |  | $ | 248,854 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001564590-19-040490:note_history:42]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.
  (was, 2019-09-20, similarity 0.6067):
[0001564590-19-035143:note_history:42]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services.

- added (2019-11-05):
[0001564590-19-040490:note_history:43]
Sales by Category

- changed (2019-11-05):
[0001564590-19-040490:note_history:44]
In addition to our reporting segments, we also report revenue in the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.
  (was, 2019-09-20, similarity 0.9973):
[0001564590-19-035143:note_history:44]
In addition to our reporting segments, we also report revenue in the following three categories – Access & Aggregation, Subscriber Solutions & Experience, and Traditional & Other Products.

- changed (2019-11-05):
[0001564590-19-040490:note_history:45]
The following table disaggregates our revenue by reportable segment and revenue category for the three months ended September 30, 2019 and 2018:
  (was, 2019-09-20, similarity 0.9588):
[0001564590-19-035143:note_history:45]
The following table disaggregates our revenue by reportable segment and revenue category for the three months ended June 30, 2019 and 2018:

- changed (2019-11-05):
[0001564590-19-040490:note_history:46]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 48,902 |  |  | $ | 16,212 |  |  | $ | 65,114 |  |  | $ | 76,046 |  |  | $ | 15,855 |  |  | $ | 91,901 |  |
| Subscriber Solutions & Experience(1) |  |  | 40,382 |  |  |  | 2,094 |  |  |  | 42,476 |  |  |  | 37,313 |  |  |  | 1,239 |  |  |  | 38,552 |  |
| Traditional & Other Products |  |  | 4,734 |  |  |  | 1,768 |  |  |  | 6,502 |  |  |  | 7,684 |  |  |  | 2,198 |  |  |  | 9,882 |  |
| Total |  | $ | 94,018 |  |  | $ | 20,074 |  |  | $ | 114,092 |  |  | $ | 121,043 |  |  | $ | 19,292 |  |  | $ | 140,335 |  |
  (was, 2019-09-20, similarity 0.9521):
[0001564590-19-035143:note_history:46]
|  |  | For the Three Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 96,262 |  |  | $ | 13,159 |  |  | $ | 109,421 |  |  | $ | 75,222 |  |  | $ | 9,520 |  |  | $ | 84,742 |  |
| Subscriber Solutions & Experience(1) |  |  | 38,444 |  |  |  | 2,058 |  |  |  | 40,502 |  |  |  | 33,306 |  |  |  | 1,254 |  |  |  | 34,560 |  |
| Traditional & Other Products |  |  | 4,461 |  |  |  | 2,007 |  |  |  | 6,468 |  |  |  | 6,535 |  |  |  | 2,211 |  |  |  | 8,746 |  |
| Total |  | $ | 139,167 |  |  | $ | 17,224 |  |  | $ | 156,391 |  |  | $ | 115,063 |  |  | $ | 12,985 |  |  | $ | 128,048 |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:47]
The following table disaggregates our revenue by reportable segment and revenue category for the nine months ended September 30, 2019 and 2018:
  (was, 2019-09-20, similarity 0.9394):
[0001564590-19-035143:note_history:47]
The following table disaggregates our revenue by reportable segment and revenue category for the six months ended June 30, 2019 and 2018:

- changed (2019-11-05):
[0001564590-19-040490:note_history:48]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 230,837 |  |  | $ | 43,476 |  |  | $ | 274,313 |  |  | $ | 220,653 |  |  | $ | 37,670 |  |  | $ | 258,323 |  |
| Subscriber Solutions & Experience(1) |  |  | 113,545 |  |  |  | 6,186 |  |  |  | 119,731 |  |  |  | 99,396 |  |  |  | 3,817 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 14,625 |  |  |  | 5,605 |  |  |  | 20,230 |  |  |  | 21,310 |  |  |  | 6,343 |  |  |  | 27,653 |  |
| Total |  | $ | 359,007 |  |  | $ | 55,267 |  |  | $ | 414,274 |  |  | $ | 341,359 |  |  | $ | 47,830 |  |  | $ | 389,189 |  |
  (was, 2019-09-20, similarity 0.946):
[0001564590-19-035143:note_history:48]
|  |  | For the Six Months Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 181,935 |  |  | $ | 27,264 |  |  | $ | 209,199 |  |  | $ | 144,607 |  |  | $ | 21,815 |  |  | $ | 166,422 |  |
| Subscriber Solutions & Experience(1) |  |  | 73,163 |  |  |  | 4,092 |  |  |  | 77,255 |  |  |  | 62,083 |  |  |  | 2,578 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 9,891 |  |  |  | 3,837 |  |  |  | 13,728 |  |  |  | 13,626 |  |  |  | 4,145 |  |  |  | 17,771 |  |
| Total |  | $ | 264,989 |  |  | $ | 35,193 |  |  | $ | 300,182 |  |  | $ | 220,316 |  |  | $ | 28,538 |  |  | $ | 248,854 |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:49]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). As of September 30, 2019, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.
  (was, 2019-09-20, similarity 0.7576):
[0001564590-19-035143:note_history:49]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). As of June 30, 2019, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

- changed (2019-11-05):
[0001564590-19-040490:note_history:50]
| (In thousands) |  | September 30, 2019 |  |  | December 31, 2018 |  |
| Accounts receivable, net |  | $ | 90,647 |  |  | $ | 99,385 |  |
| Contract assets(1) |  | $ | 2,434 |  |  | $ | 3,766 |  |
| Unearned revenue |  | $ | 14,022 |  |  | $ | 17,940 |  |
| Non-current unearned revenue |  | $ | 4,581 |  |  | $ | 5,296 |  |
  (was, 2019-09-20, similarity 0.9201):
[0001564590-19-035143:note_history:50]
| (In thousands) |  | June 30, 2019 |  |  | December 31, 2018 |  |
| Accounts receivable, net |  | $ | 116,661 |  |  | $ | 99,385 |  |
| Contract assets(1) |  | $ | 2,251 |  |  | $ | 3,766 |  |
| Unearned revenue |  | $ | 12,910 |  |  | $ | 17,940 |  |
| Non-current unearned revenue |  | $ | 4,265 |  |  | $ | 5,296 |  |

- changed (2019-11-05):
[0001564590-19-040490:note_history:51]
Of the outstanding unearned revenue balance at December 31, 2018, $1.2 million and $11.7 million was recognized as revenue during the three and nine months ended September 30, 2019, respectively.
  (was, 2019-09-20, similarity 0.9543):
[0001564590-19-035143:note_history:51]
Of the outstanding unearned revenue balance at December 31, 2018, $3.6 million and $10.5 million was recognized as revenue during the three and six months ended June 30, 2019, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2019-11-05):
[0001564590-19-040490:note_history:52]
On October 30, 2019, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 14, 2019. The payment date will be December 2, 2019 in the aggregate amount of approximately $4.3 million.

- removed (2019-11-05):
[0001564590-19-035143:note_history:53]
On July 17, 2019, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on August 1, 2019. The dividend was paid on August 15, 2019 and totaled $4.3 million.

- removed (2019-11-05):
[0001564590-19-035143:note_history:54]
In September 2019, we entered into an operating lease for office space in India. This lease has an initial term of five years and includes an option to renew for an additional five-year period. As a result of this agreement, we will record a right-of-use asset and corresponding lease liability of approximately $10.2 million in our Condensed Consolidated Balance Sheet during the third quarter of 2019.
