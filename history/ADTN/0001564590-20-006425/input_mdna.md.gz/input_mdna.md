# ADTN MD&A — 0001564590-20-006425


## mdna

[0001564590-20-006425:mdna:1]
| ITEM 7. | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001564590-20-006425:mdna:2]
You should read the following discussion of our financial condition and results of operations in conjunction with our audited consolidated financial statements and the related notes included in Part II, Item 8 of this Annual Report on Form 10-K.  We have omitted discussion of the earliest of the three years of financial condition and results of operations and this information can be found in Part I, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the fiscal year ended December 31, 2018, filed with the SEC on February 28, 2019, which is available free of charge on the SEC's website at sec.gov and on our website at www.adtran.com.

[0001564590-20-006425:mdna:3]
Overview

[0001564590-20-006425:mdna:4]
ADTRAN is a leading global provider of networking and communications equipment, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, cable/MSOs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. In order to service our customers and grow revenue, we are constantly conducting research and development of new products addressing customer needs and testing those products for the particular specifications of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have research and development facilities in strategic global locations.

[0001564590-20-006425:mdna:5]
An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek to be a high-quality, and in most instances the low-cost, provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001564590-20-006425:mdna:6]
We ended the first half of 2019 with 20.6% year-over-year revenue growth and good geographical diversity with 50.8% of our revenue coming from international markets.  During the third quarter of 2019, we experienced a slowdown in capital spending by a Tier-1 customer in Europe and an unforeseen pause in spending from a LATAM Tier-1 customer. While shipments to the LATAM customer resumed in the fourth quarter, these delays, combined with seasonality, resulted in a softer than expected second half of the year. During 2019, we had three 10% revenue customers geographically diversified with one each in the U.S., Europe and LATAM. Our domestic revenue growth of 4.2% year-over-year was driven by an increase in sales to RSPs and additional fiber deployments across all customers. In addition, we saw an increase in sales to a Tier-1 customer with diversified business among our fiber access and CPE, service provider CPE and services as well as sales to a Tier-2 customer. Our LATAM Tier-1 customer expanded their FTTx deployments in 2019 with ADTRAN solutions. In Europe, a Tier-1 customer continued expansion of their vectoring and super-vectoring VDSL2 solutions. We also experienced increases in our service provider CPE business in 2019. Among our customers, we made progress with our fiber and fiber-extension solutions, including Gfast and PON, while also continuing to engage various Services & Support opportunities that we expect will contribute in 2020 and beyond. In addition, we believe we are at the beginning of a significant investment cycle for fiber deployment driven by technology advancements, regulatory influences and vendor disruption. The transition to next-generation network architectures is beginning, and we are seeing demand for our next-generation SD-Access solutions. In the latter part of 2020, we anticipate that payments to service providers under government funding programs such as the FCC Rural Digital Opportunity Fund will begin and continue into 2021.

[0001564590-20-006425:mdna:7]
We made two acquisitions in 2018, strengthening our position in both the cable/MSOs and connected home markets. In the first quarter of 2018, we acquired Sumitomo Electric Lightwave Corp.’s North American EPON business and certain assets for North America and entered into a technology license and original equipment manufacturer supply agreement with Sumitomo Electric Industries, Ltd. These solutions, combined with our organic fiber access product portfolio and our distributed access expertise, present new opportunities in the cable/MSO market. Also, in the fourth quarter of 2018, we acquired U.S.-based SmartRG, an industry-leading provider of carrier-class, connected-home software platforms and cloud services for broadband service providers. With this acquisition, ADTRAN now offers a complete cloud-to-consumer portfolio of virtualized management, data analytics, Wi-Fi-enabled residential gateways and software platforms.

[0001564590-20-006425:mdna:8]
In addition to classifying our operations into two reportable segments, we report revenue across three categories of products and services – (1) Access & Aggregation, (2) Subscriber Solutions & Experience (formerly Customer Devices) and (3) Traditional & Other Products.

[0001564590-20-006425:mdna:9]
Our Access & Aggregation solutions are used by CSPs to connect their network infrastructure to subscribers. This revenue category includes hardware- and software-based products and services that aggregate and/or originate access technologies. ADTRAN solutions within this category include a wide array of modular or fixed platforms designed to deliver the best technology and economy based on subscriber density and environmental conditions.

[0001564590-20-006425:mdna:10]
Our Subscriber Solutions & Experience portfolio is used by service providers to terminate their infrastructure at the customers premises while providing an immersive and interactive experience for the subscriber. These solutions include copper and fiber WAN termination, LAN switching, Wi-Fi access, and cloud software services, for both residential and business markets.

[0001564590-20-006425:mdna:11]
In alignment with our increased focus on enhancing the customer experience for both business and consumer broadband customers as well as the addition of SmartRG during 2018, what was previously known as our Customer Devices category became our Subscriber Solutions & Experience category, as this more accurately represents this revenue category and our vision moving forward.

[0001564590-20-006425:mdna:12]
Our Traditional & Other Products category generally includes a mix of prior-generation technologies’ products and services, as well as other products and services that do not fit within the other revenue categories.

[0001564590-20-006425:mdna:13]
Our operating results have fluctuated, and may continue to fluctuate, on a quarterly basis due to a number of factors, including customer order activity and backlog. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days. These factors normally result in a varying order backlog and limited order flow visibility. Additionally, backlog levels may vary because of seasonal trends, the timing of customer projects, and other factors that affect customer order lead times. Because many of our customers require prompt delivery of products, we are required to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001564590-20-006425:mdna:14]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter. During 2019, the Company implemented restructuring plans to realign its expense structure with the reduction in revenue experienced in recent years and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and has implemented certain cost savings initiatives, where possible. We expect to see a reduction in our operating expenses, both in the U.S. and internationally, as a result of our implementation of these restructuring plans.

[0001564590-20-006425:mdna:15]
Our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. See Note 19 of Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report, for additional information on quarterly results for 2018 and 2019. For a discussion of risks associated with our operating results, see Part I, Item 1A of this report.

[0001564590-20-006425:mdna:16]
Results of Operations

[0001564590-20-006425:mdna:17]
The following table presents selected financial information derived from our Consolidated Statements of Income (Loss) expressed as a percentage of sales for the years indicated. Amounts may not foot due to rounding.

[0001564590-20-006425:mdna:18]
|  |  | Year Ended December 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 85.9 | % |  |  | 86.6 | % |  |  | 81.0 | % |
| Services & Support |  |  | 14.1 |  |  |  | 13.4 |  |  |  | 19.0 |  |
| Total sales |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 49.7 |  |  |  | 52.7 |  |  |  | 41.9 |  |
| Services & Support |  |  | 8.9 |  |  |  | 8.8 |  |  |  | 12.6 |  |
| Total cost of sales |  |  | 58.7 |  |  |  | 61.5 |  |  |  | 54.5 |  |
| Gross profit |  |  | 41.3 |  |  |  | 38.5 |  |  |  | 45.5 |  |
| Selling, general and administrative expenses |  |  | 24.6 |  |  |  | 23.5 |  |  |  | 20.3 |  |
| Research and development expenses |  |  | 23.8 |  |  |  | 23.5 |  |  |  | 19.6 |  |
| Asset impairments |  |  | 0.7 |  |  |  | — |  |  |  | — |  |
| Gain on contingency |  |  | (0.2 | ) |  |  | — |  |  |  | — |  |
| Operating income (loss) |  |  | (7.5 | ) |  |  | (8.6 | ) |  |  | 5.6 |  |
| Interest and dividend income |  |  | 0.5 |  |  |  | 0.8 |  |  |  | 0.7 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Net investment gain (loss) |  |  | 2.2 |  |  |  | (0.8 | ) |  |  | 0.7 |  |
| Other income (expense), net |  |  | 0.3 |  |  |  | 0.2 |  |  |  | (0.2 | ) |
| Gain on bargain purchase of a business |  |  | — |  |  |  | 2.1 |  |  |  | — |  |
| Income (Loss) Before Income Taxes |  |  | (4.7 | ) |  |  | (6.3 | ) |  |  | 6.7 |  |
| Income tax (expense) benefit |  |  | (5.3 | ) |  |  | 2.7 |  |  |  | (3.1 | ) |
| Net income (loss) |  |  | (10.0 | )% |  |  | (3.7 | )% |  |  | 3.6 | % |

[0001564590-20-006425:mdna:19]
The following discussion and financial information are presented to aid in an understanding of our current consolidated financial position, changes in financial position, results of operations and cash flows and should be read in conjunction with the audited Consolidated Financial Statements and notes thereto included herein. The emphasis of the discussion is a comparison of the years ended December 31, 2019 and December 31, 2018.  For a discussion of a comparison of the years ended December 31, 2018 and December 31, 2017, please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 28, 2019.

[0001564590-20-006425:mdna:20]
Comparison of Years Ended December 31, 2019 and December 31, 2018

[0001564590-20-006425:mdna:21]
Sales

[0001564590-20-006425:mdna:22]
Our sales increased 0.1% from $529.3 million for the year ended December 31, 2018 to $530.1 million for the year ended December 31, 2019. Our Services & Support sales increased $3.8 million compared to 2018 and our Network Solutions sales decreased $3.0 million versus the prior year. The increase in our 2019 sales was primarily attributable to an increase in Subscriber Solutions & Experience sales of $18.5 million, partially offset by decreases in Access & Aggregation sales of $10.0 million and Traditional & Other Products sales of $7.7 million.

[0001564590-20-006425:mdna:23]
Network Solutions sales decreased by 0.7% from $458.2 million in 2018 to $455.2 million in 2019, due primarily to a decrease in sales of our Access & Aggregation products and Traditional & Other Products. The decrease in sales of 3.9% of our Access & Aggregation products for 2019 was primarily attributable to decreased FTTN products, offset by an increase in sales of Gfast DPUs. The increase of 12.1% in 2019 for sales of our Subscriber Solutions & Experience products was primarily attributable to increased residential CPE and fiber CPE sales, partially offset by a decrease in sales of SP Business CPE and WiFi access points and infrastructure. While we expect that revenues from Traditional & Other Products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-20-006425:mdna:24]
Services & Support sales increased by 5.3% from $71.0 million in 2018 to $74.8 million in 2019. The increase in sales for 2019 was primarily attributable to an increase in network installation and maintenance services for Access & Aggregation products and Subscriber Solutions & Experience.

[0001564590-20-006425:mdna:25]
Domestic sales increased 4.2% from $288.8 million in 2018 to $300.9 million in 2019. Our domestic growth was driven by an increase in sales to the RSP market segment and additional fiber deployments across all customers. In addition, such growth was driven by an increase in sales to a Tier-1 customer with diversified business among our fiber access and CPE, service provider CPE and services, as well as increased sales to a Tier-2 customer.

[0001564590-20-006425:mdna:26]
International sales, which are included in the amounts for the Network Solutions and Services & Support segments amounts discussed above, decreased 4.7% from $240.4 million for the year ended December 31, 2018 to $229.2 for the year ended December 31, 2019. International sales, as a percentage of total sales, decreased from 45.4% for the year ended December 31, 2018 to 43.2% for the year ended December 31, 2019.  The decrease in international sales for 2019 was primarily attributable to the slowdown in shipments to two international Tier-1 customers.

[0001564590-20-006425:mdna:27]
Our international revenue is largely focused on broadband infrastructure and is affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. The competitive landscape in certain international markets is also affected by the increased presence of Asian manufacturers that seek to compete aggressively on price. Our revenue and operating income in some international markets can be negatively impacted by a strengthening U.S. dollar. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in negative pressure on revenue and operating income.

[0001564590-20-006425:mdna:28]
Cost of Sales

[0001564590-20-006425:mdna:29]
As a percentage of sales, cost of sales decreased from 61.5% for the year ended December 31, 2018 to 58.7% for the year ended December 31, 2019. The decrease was primarily attributable to regional revenue shifts, changes in customer and product mix, changes in services and support mix and a decrease in labor expense as a result of restructuring programs which were initiated in 2018 and continued throughout 2019.

[0001564590-20-006425:mdna:30]
Network Solutions cost of sales, as a percent of that segment’s sales, decreased from 60.9% of sales in 2018 to 57.9% of sales in 2019. The decrease in Network Solutions cost of sales as a percentage of that segment’s sales was primarily attributable to regional revenue shifts, changes in customer and product mix and a decrease in labor expense due to restructuring programs which were initiated in 2018 and continued throughout 2019, offset by an increase in freight and shipping charges.

[0001564590-20-006425:mdna:31]
An important part of our strategy is to reduce the cost of each succeeding generation of product and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-20-006425:mdna:32]
Services & Support cost of sales, as a percent of that segment’s sales, decreased from 65.8% of sales in 2018 to 63.1% of sales in 2019. The decrease in Services & Support cost of sales as a percentage of that segment’s sales in 2019 was primarily attributable to lower fixed personnel costs due to restructuring programs which were initiated in 2018 and continued throughout 2019, changes in customer mix, changes in services support mix and an increase in volume.

[0001564590-20-006425:mdna:33]
Our Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services.

[0001564590-20-006425:mdna:34]
As our network planning and implementation revenue grew to become the largest component of our Services & Support segment business, our Services & Support segment gross margins decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support segment revenue comprising a larger percentage of our overall revenue, and because our Services & Support segment gross margins are generally below those of the Network Solutions segment, our overall corporate gross margins may decline as that business continues to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-20-006425:mdna:35]
Selling, General and Administrative Expenses

[0001564590-20-006425:mdna:36]
Selling, general and administrative expenses as a percentage of sales increased from 23.5% for the year ended December 31, 2018 to 24.6% for the year ended December 31, 2019. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared as these costs are relatively fixed in the short term.

[0001564590-20-006425:mdna:37]
Selling, general and administrative expenses increased by 4.7% from $124.4 million for the year ended December 31, 2018 to $130.3 million for the year ended December 31, 2019. Selling, general and administrative expenses include personnel costs for administration, finance, information technology, human resources, sales and marketing and general management, as well as rent, utilities, legal and accounting expenses, advertising, promotional material, trade show expenses and related travel costs. The increase in selling, general and administrative expenses was primarily attributable to deferred compensation related costs, incremental expenses as a result of the SmartRG acquisition, IP litigation and other legal related costs, partially offset by decreases in labor expense and use tax expense.

[0001564590-20-006425:mdna:38]
Research and Development Expenses

[0001564590-20-006425:mdna:39]
Research and development expenses as a percentage of sales increased from 23.5% for the year ended December 31, 2018 to 23.8% for the year ended December 31, 2019. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenues for the periods being compared.

[0001564590-20-006425:mdna:40]
Research and development expenses increased by 1.3% from $124.5 million for the year ended December 31, 2018 to $126.2 million for the year ended December 31, 2019. The increase in research and development expenses was primarily attributable to increases in incremental expenses as a result of the SmartRG acquisition and lease expense offset by a decrease in labor expense, certain material engineering costs and contract services.

[0001564590-20-006425:mdna:41]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product and market opportunities and engage in significant research and development efforts which provide for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001564590-20-006425:mdna:42]
Asset Impairments

[0001564590-20-006425:mdna:43]
Asset impairments, which were $3.9 million for the year ended December 31, 2019, relate to the abandonment of certain information technology implementation projects which we had previously capitalized costs for these projects. There were no asset impairments recognized during the year ended December 31, 2018. See Note 1 and Note 8 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-20-006425:mdna:44]
Gain on Contingency

[0001564590-20-006425:mdna:45]
Gain on contingency, which was $1.2 million for the year ended December 31, 2019, relates to the reversal of contingent liabilities which were initially recognized upon the acquisition of SmartRG in the fourth quarter of 2018. See Note 2 of the Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information. There was no gain on contingency recognized during the year ended December 31, 2018.

[0001564590-20-006425:mdna:46]
Interest and Dividend Income

[0001564590-20-006425:mdna:47]
Interest and dividend income decreased by 31.3% from $4.0 million for the year ended December 31, 2018 to $2.8 million for the year ended December 31, 2019. The decrease in interest and dividend income was primarily attributable to a decrease in interest income. Our investments increased from $112.1 million as of December 31, 2018 to $127.7 million as of December 31, 2019.

[0001564590-20-006425:mdna:48]
Interest Expense

[0001564590-20-006425:mdna:49]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.5 million for the years ended December 31, 2019 and 2018, as we had no substantial change in our fixed-rate borrowing. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001564590-20-006425:mdna:50]
Net Investment Gain (Loss)

[0001564590-20-006425:mdna:51]
We recognized a net investment loss of $4.0 million for the year ended December 31, 2018 and a net investment gain of $11.4 million for the year ended December 31, 2019. The fluctuation in our net investment gain was primarily attributable to changes in fair value of equity securities recognized during the period. We expect that any future equity market volatility will result in continued volatility in gains or losses from our equity investment portfolios. See “Investing Activities” in “Liquidity and Capital Resources” and Note 1 and Note 5 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-20-006425:mdna:52]
Other Income (Expense), net

[0001564590-20-006425:mdna:53]
Other income (expense), net, which is comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, net periodic pension costs, investment account management fees and gains and losses on foreign exchange forward contracts, increased 16.5% from income of $1.3 million for the year ended December 31, 2018 to income of $1.5 million for the year ended December 31, 2019. The change was primarily attributable to a gain on a life insurance recovery recognized in 2019 partially offset by losses on foreign exchange contracts and transactions in 2019 as compared to foreign exchange gains in 2018.

[0001564590-20-006425:mdna:54]
Gain on Bargain Purchase of a Business

[0001564590-20-006425:mdna:55]
Gain on bargain purchase of a business is related to our acquisition of Sumitomo Electric Lightwave Corp.’s North American EPON business and entry into a technology license and supply agreement with Sumitomo Electric Industries, Ltd. in March 2018. See Note 2 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-20-006425:mdna:56]
Income Tax (Expense) Benefit

[0001564590-20-006425:mdna:57]
Our effective tax rate increased from a benefit of 42.0%, excluding the tax effect of the bargain purchase gain, for the year ended December 31, 2018 to an expense of (113.9%) for the year ended December 31, 2019. The increase in the effective tax rate between the two periods was primarily driven by the establishment of a valuation allowance against our domestic deferred tax assets in the amount of $42.8 million during the year ended December 31, 2019, offset by a 15.5% rate reduction related to the generation of federal research and development credits, and a 16.7% rate reduction for the generation of foreign tax credits. See Note 13 of the Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-20-006425:mdna:58]
Net Loss

[0001564590-20-006425:mdna:59]
As a result of the above factors, our net loss increased from $19.3 million for the year ended December 31, 2018 to a net loss of $53.0 million for the year ended December 31, 2019. As a percentage of sales, net loss increased from 3.7% for the year ended December 31, 2018 to 10.0% for the year ended December 31, 2019.

[0001564590-20-006425:mdna:60]
Liquidity and Capital Resources

[0001564590-20-006425:mdna:61]
Liquidity

[0001564590-20-006425:mdna:62]
We have historically and we currently expect to finance our ongoing business with existing cash and cash flow from operations. We have used, and expect to continue to use, existing cash and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expansion of our sales and marketing activities and capital expenditures. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-20-006425:mdna:63]
As of December 31, 2019, cash on hand was $73.8 million and short-term investments were $33.2 million, which resulted in available short-term liquidity of $107.0 million, of which $52.3 million was held by our foreign subsidiaries. As of December 31, 2018, cash on hand was $105.5 million and short-term investments were $3.2 million, which resulted in available short-term liquidity of $108.7 million, of which $87.1 million was held by our foreign subsidiaries. The decrease in short-term liquidity from December 31, 2018 to December 31, 2019 was primarily attributable to the use of cash for operating, investing and financing activities and income tax payments, offset by the reclassification of our certificate of deposit from long-term to short-term investments.

[0001564590-20-006425:mdna:64]
Operating Activities

[0001564590-20-006425:mdna:65]
Our working capital, which consists of current assets less current liabilities, decreased 12.6% from $237.4 million as of December 31, 2018 to $207.6 million as of December 31, 2019. The current ratio, defined as current assets divided by current liabilities, decreased from 3.01 as of December 31, 2018 to 2.84 as of December 31, 2019. The decrease in our working capital and current ratio was primarily attributable to a decrease in cash and cash equivalents, net accounts receivable and other receivables as described below. The quick ratio, defined as cash and cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 1.76 as of December 31, 2018 to 1.75 as of December 31, 2019. The decrease in the quick ratio was primarily attributable to a decrease in cash and cash equivalents and net accounts receivable.  This decrease was offset by an increase in short-term investments.

[0001564590-20-006425:mdna:66]
Net accounts receivable decreased 8.91% from $99.4 million as of December 31, 2018 to $90.5 million as of December 31, 2019. Our allowance for doubtful accounts was $0.1 million as of December 31, 2018 and $38 thousand as of December 31, 2019. Quarterly accounts receivable DSO increased from 65 days as of December 31, 2018 to 72 days as of December 31, 2019. The decrease in net accounts receivable and increase in DSO was attributable to the timing of sales in the fourth quarter, customer specific payment terms and other collections during the quarter.

[0001564590-20-006425:mdna:67]
Other receivables decreased 54.9% from $36.7 million as of December 31, 2018 to $16.6 million as of December 31, 2019. The decrease in other receivables was primarily attributable to a decrease in current lease payments receivable related to our sales-type leases, income tax receivables and purchasing shipments.

[0001564590-20-006425:mdna:68]
Annual inventory turnover increased from 2.93 turns as of December 31, 2018 to 3.14 turns as of December 31, 2019. Inventory decreased 1.6% from $99.8 million as of December 31, 2018 to $98.3 million as of December 31, 2019. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing the risk of excess inventory.

[0001564590-20-006425:mdna:69]
Accounts payable decreased 25.3% from $60.1 million as of December 31, 2018 to $44.9 million as of December 31, 2019. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-20-006425:mdna:70]
Investing Activities

[0001564590-20-006425:mdna:71]
Capital expenditures totaled approximately $9.5 million, $8.1 million and $14.7 million for the years ended December 31, 2019, 2018 and 2017, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment and for building improvements.

[0001564590-20-006425:mdna:72]
Our combined short-term and long-term investments increased $15.7 million from $112.1 million as of December 31, 2018 to $127.7 million as of December 31, 2019. This increase reflects the increase in fair market value of our equity investments.

[0001564590-20-006425:mdna:73]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. See Note 5 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information. As of December 31, 2019, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds were classified as available-for-sale and had a combined duration of 1.71 years with an average credit rating of AA. Because our bond portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-20-006425:mdna:74]
Our long-term investments decreased 16.5% from $108.8 million as of December 31, 2018 to $94.5 million as of December 31, 2019. Long-term investments as of December 31, 2018 included an investment in a certificate of deposit of $25.6 million, which served as collateral for our revenue bonds. This certificate of deposit was included in short-term investments as of December 31, 2019, as these bonds matured on January 1, 2020, and were repaid in full on January 2, 2020. We also have investments in various marketable equity securities classified as long-term investments with a fair market value of $35.8 million and $27.0 million, as of December 31, 2019 and December 31, 2018, respectively. Long-term investments as of December 31, 2019 and 2018 also included $21.7 million and $18.3 million, respectively, related to our deferred compensation plan, and $0.3 million and $0.4 million, respectively, of other investments, consisting of interests in two private equity funds.

[0001564590-20-006425:mdna:75]
No businesses were acquired during the year ended December 31, 2019. Acquisition of businesses, net of cash acquired, totaled $22.0 million for the year ended December 31, 2018. See Note 2 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-20-006425:mdna:76]
Financing Activities

[0001564590-20-006425:mdna:77]
In conjunction with the 1995 expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (“the Authority”). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds (the “Taxable Revenue Bonds”) and loaned the proceeds from the sale of the Taxable Revenue Bonds to ADTRAN. Further advances on the Taxable Revenue Bonds were made by the Authority, bringing the total amount outstanding to $50.0 million. The bonds matured on January 1, 2020, and the current outstanding balance of $24.6 million was repaid in full on January 2, 2020. We were required to make payments to the Authority in amounts necessary to pay the interest on the Taxable Revenue Bonds which totaled $1.0 million, $1.1 million and $1.1 million, respectively, for the years ended December 31, 2019, 2018 and 2017. See Note 12 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-20-006425:mdna:78]
Dividends

[0001564590-20-006425:mdna:79]
During 2019, 2018 and 2017, we paid shareholder dividends totaling $17.2 million, $17.3 million and $17.4 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained. The following table shows dividends per common share paid to our shareholders in each quarter of 2019, 2018 and 2017.

[0001564590-20-006425:mdna:80]
| Dividends per Common Share |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001564590-20-006425:mdna:81]
Stock Repurchase Program

[0001564590-20-006425:mdna:82]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. For the years ended December 31, 2019, 2018 and 2017, we repurchased 13 thousand shares, 1.0 million shares and 0.9 million shares, respectively, for $0.2 million, $15.5 million and $17.3 million, respectively, at an average price of $14.06, $15.52 and $20.27 per share, respectively. We currently have authorization to repurchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-20-006425:mdna:83]
Stock Option Exercises

[0001564590-20-006425:mdna:84]
To accommodate employee stock option exercises, we issued 34 thousand shares of treasury stock for $0.5 million during the year ended December 31, 2019, 0.1 million shares of treasury stock for $1.5 million during the year ended December 31, 2018 and 0.7 million shares of treasury stock for $13.4 million during the year ended December 31, 2017.

[0001564590-20-006425:mdna:85]
Employee Pension Plan

[0001564590-20-006425:mdna:86]
We maintain a defined benefit pension plan, covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations.

[0001564590-20-006425:mdna:87]
Our defined benefit plan assets consist of a balanced portfolio of equity funds, bond funds, real estate funds and managed futures. Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. Central to the policy are target allocation ranges by asset class, which is currently 50% for bond funds, 40% for equity funds and 10% cash, real estate and managed futures. The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies. The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations. At December 31, 2019, the estimated fair market value of our defined benefit pension plans assets increased to $28.0 million from $24.2 million at December 31, 2018.

[0001564590-20-006425:mdna:88]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations, and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations. The projected benefit obligation for our defined benefit pension plans was $43.9 million and $37.2 million as of December 31, 2019 and 2018, respectively.

[0001564590-20-006425:mdna:89]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Consolidated Statements of Income (Loss). The components of net periodic pension cost and amounts recognized in other comprehensive income (loss) for the years ended December 31, 2019, 2018 and 2017 was $3.2 million, $6.1 million and $(0.2) million, respectively.

[0001564590-20-006425:mdna:90]
Actuarial gains and losses are recorded in accumulated other comprehensive income (loss). To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants. We estimate that $0.8 million will be amortized from accumulated other comprehensive income (loss) into net periodic pension cost in 2020 for the net actuarial loss. The net actuarial loss recognized in accumulated other comprehensive income (loss) as of December 2019 and 2018 was $(13.0) million and $(11.3) million, respectively.

[0001564590-20-006425:mdna:91]
See Note 14 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-20-006425:mdna:92]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001564590-20-006425:mdna:93]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of, or requirements for, capital resources.

[0001564590-20-006425:mdna:94]
Contractual Obligations

[0001564590-20-006425:mdna:95]
We have various contractual obligations and commercial commitments. The following table sets forth the annual payments we are required to make under contractual cash obligations and other commercial commitments as of December 31, 2019:

[0001564590-20-006425:mdna:96]
| (In thousands) |  | Total |  |  | 2020 |  |  | 2021 |  |  | 2022 |  |  | 2023 |  |  | 2024 |  |  | After 2024 |  |
| Bonds payable(1) |  | $ | 24,600 |  |  | $ | 24,600 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Purchase obligations(2) |  |  | 99,210 |  |  |  | 98,324 |  |  |  | 759 |  |  |  | 83 |  |  |  | 28 |  |  |  | 16 |  |  |  | — |  |
| Operating lease obligations(3) |  |  | 8,879 |  |  |  | 2,856 |  |  |  | 2,412 |  |  |  | 1,705 |  |  |  | 1,160 |  |  |  | 482 |  |  |  | 264 |  |
| Totals |  | $ | 132,689 |  |  | $ | 125,780 |  |  | $ | 3,171 |  |  | $ | 1,788 |  |  | $ | 1,188 |  |  | $ | 498 |  |  | $ | 264 |  |

[0001564590-20-006425:mdna:97]
(1) As of December 31, 2019, we were required to make payments necessary to pay the interest on the Taxable Revenue Bonds, which were outstanding in the aggregate principal amount of $24.6 million as of December 31, 2019. The bonds had an interest rate of 2% per annum and matured on January 1, 2020. Included in short-term investments as of December 31, 2019 was a certificate of deposit of $25.6 million, which served a collateral deposit against the principal amount of the bonds. See Note 12 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-20-006425:mdna:98]
(2) Primarily relates to open purchase orders to our contract manufacturers, component suppliers, service partners and other vendors.

[0001564590-20-006425:mdna:99]
(3) Primarily relates to future minimum rental payments under non-cancelable operating leases, including renewals determined to be reasonably assured, with original maturities of greater than 12 months.

[0001564590-20-006425:mdna:100]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied to these commitments. The additional $0.2 million commitment has been excluded from the table above due to the uncertainty of when it will be applied.

[0001564590-20-006425:mdna:101]
Certain contracts, customers and/or jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2019, we had commitments related to these bonds totaling $9.3 million, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default in our performance under each contract, the probability of which we believe is remote.

[0001564590-20-006425:mdna:102]
We also have obligations related to uncertain income tax positions that have been excluded from the table above due to the uncertainty of when the related expense will be recognized. See Note 13 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-20-006425:mdna:103]
Critical Accounting Policies and Estimates

[0001564590-20-006425:mdna:104]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part II, Item 8 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0001564590-20-006425:mdna:105]
Revenue Recognition

[0001564590-20-006425:mdna:106]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product or service to the customer. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. The stand-alone selling prices are determined based on the prices at which we sell the separate products and services and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0001564590-20-006425:mdna:107]
The following is a description of the principal activities from which we generate our revenue by reportable segment.

[0001564590-20-006425:mdna:108]
Network Solutions Segment

[0001564590-20-006425:mdna:109]
Network Solutions includes software and hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales.

[0001564590-20-006425:mdna:110]
Hardware and Software Revenue

[0001564590-20-006425:mdna:111]
Revenue from hardware sales is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. This segment also includes revenues from software license sales which is recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

[0001564590-20-006425:mdna:112]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term. In relation to these lease agreements, during the years ended December 31, 2019, 2018 and 2017 we recognized revenue of $1.7 million, $13.7 million and $16.5 million, respectively.

[0001564590-20-006425:mdna:113]
Services & Support Segment

[0001564590-20-006425:mdna:114]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, and solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-20-006425:mdna:115]
Maintenance Revenue

[0001564590-20-006425:mdna:116]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue as our customers benefit evenly throughout the contract term and deferred revenues are recorded in current and non-current unearned revenue.

[0001564590-20-006425:mdna:117]
Network Implementation Revenue

[0001564590-20-006425:mdna:118]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services, at a point in time when each performance obligation is complete. If we have recognized revenue, but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables in the Consolidated Balance Sheets. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0001564590-20-006425:mdna:119]
Inventory

[0001564590-20-006425:mdna:120]
We carry our inventory at the lower of cost and net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor, and manufacturing overhead are used to value inventory and are updated at least a quarterly. Any variances are expensed in the current period, therefore, our inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and marketing conditions. If actual trends and market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $34.1 million and $30.0 million at December 31, 2019 and 2018, respectively. Inventory disposals charged against the reserve were $1.8 million, $0.4 million and $8.3 million for the years ended December 31, 2019, 2018 and 2017, respectively.

[0001564590-20-006425:mdna:121]
Stock-Based Compensation

[0001564590-20-006425:mdna:122]
For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable, single measure of the fair value of our stock option awards. For purposes of determining the estimated fair value of our market-based performance stock unit (PSU) awards on the date of grant, we use a Monte Carlo Simulation valuation method. These PSUs are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of performance-based PSUs, restricted stock units (RSUs) and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. Compensation expense related to unvested performance-based PSUs will be recognized over the requisite service period of three years as the achievement of the performance obligation becomes probable. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period.

[0001564590-20-006425:mdna:123]
Business Combinations

[0001564590-20-006425:mdna:124]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying Consolidated Statements of Operations since their dates of acquisition. Costs incurred to complete the business combination, such as legal, accounting, or other professional fees, are charged to general and administrative expenses as they are incurred.

[0001564590-20-006425:mdna:125]
Goodwill

[0001564590-20-006425:mdna:126]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to by-pass a qualitative assessment to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount and, in turn, performed a step-1 analysis of goodwill. Based on the results of our step-1 analysis, no impairment charges on goodwill were recognized during the years ended December 31, 2019, 2018 and 2017.

[0001564590-20-006425:mdna:127]
Income Taxes

[0001564590-20-006425:mdna:128]
We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. We continually review the adequacy of our valuation allowance and recognize the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes (ASC 740). Due to our recent decrease in revenue and profitability for 2019, and all other positive and negative objective evidence considered as part of our analysis, our ability to consider other subjective evidence such as projections for future growth is limited when evaluating whether our deferred tax assets will be realized. As such, the Company is no longer able to conclude that it is more likely than not that our domestic deferred tax assets will be realized and a valuation allowance against our Domestic deferred tax assets was established in the third quarter of 2019. The amount of the deferred tax assets considered realizable, however, could be adjusted in future periods in the event sufficient evidence is present to support a conclusion that it is more likely than not that all or a portion of our domestic deferred tax assets will be realized.

[0001564590-20-006425:mdna:129]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain.  We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001564590-20-006425:mdna:130]
Liability for Warranty

[0001564590-20-006425:mdna:131]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our historical return rate and an estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.4 million and $8.6 million at December 31, 2019 and 2018, respectively. These liabilities are included in accrued expenses in the accompanying consolidated balance sheets.

[0001564590-20-006425:mdna:132]
Pension Benefit Obligations

[0001564590-20-006425:mdna:133]
Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $15.9 million and $13.1 million at December 31, 2019 and 2018, respectively. This liability is included in pension liability in the accompanying Consolidated Balance Sheets.

[0001564590-20-006425:mdna:134]
Recently Issued Accounting Pronouncements

[0001564590-20-006425:mdna:135]
For a discussion of recently issued accounting pronouncements, see Note 1 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-20-006425:mdna:136]
Subsequent Events

[0001564590-20-006425:mdna:137]
On January 2, 2020, we paid off the outstanding balance of $24.6 million of the Taxable Revenue Bonds upon their maturity. We used a certificate of deposit which was held as collateral to repay the outstanding balance.

[0001564590-20-006425:mdna:138]
On February 5, 2020, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on February 20, 2020. The quarterly dividend payment will be paid on March 5, 2020 in the aggregate amount of approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
