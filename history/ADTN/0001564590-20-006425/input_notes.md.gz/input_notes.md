# ADTN notes — 0001564590-20-006425


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001564590-20-006425:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001564590-20-006425:notes:2]
Portions of the Proxy Statement for the Annual Meeting of Stockholders to be held on May 13, 2020 are incorporated herein by reference in Part III.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-20-006425:notes:3]
Note 1 – Nature of Business

[0001564590-20-006425:notes:4]
ADTRAN, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications solutions. Our vision is to enable a fully connected world where the power to communicate is available to everyone, everywhere. Our unique approach, unmatched industry expertise and innovative solutions enable us to address almost any customer need. Our products and services are utilized by a diverse global customer base of network operators that range from those having national or regional reach, operating as telephone or cable television network operators, to alternative network providers such as municipalities or utilities, as well as managed service providers who serve small- and medium-sized businesses and distributed enterprises.

[0001564590-20-006425:notes:5]
Principles of Consolidation

[0001564590-20-006425:notes:6]
The accompanying Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the U.S. (“U.S. GAAP”) and include the financial position, results of operations, comprehensive income (loss), changes in equity and cash flows of ADTRAN and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-20-006425:notes:7]
Use of Estimates

[0001564590-20-006425:notes:8]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expenses during the reporting period. Our more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability, fair value of investments and evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-20-006425:notes:9]
Correction of Immaterial Misstatement

[0001564590-20-006425:notes:10]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserves and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in the Company’s excess and obsolete inventory reserves and cost of goods sold.

[0001564590-20-006425:notes:11]
Summary of Significant Accounting Policies

[0001564590-20-006425:notes:12]
Cash and Cash Equivalents

[0001564590-20-006425:notes:13]
Cash and cash equivalents represent demand deposits, money market funds and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions and determined the risk of material financial loss due to the exposure of such credit risk to be minimal. As of December 31, 2019, $71.6 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits.

[0001564590-20-006425:notes:14]
Financial Instruments

[0001564590-20-006425:notes:15]
The carrying amounts reported in the Consolidated Balance Sheets for cash and cash equivalents, accounts receivable, and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments. The carrying amount reported for bonds payable was $24.6 million, which was its fair value as of December 31, 2019.

[0001564590-20-006425:notes:16]
Investments with contractual maturities beyond one year may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe we have the ability to quickly sell them to the remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. All income generated from these investments was recorded as interest income. We have not recorded any losses relating to variable rate demand notes.

[0001564590-20-006425:notes:17]
Long-term investments is comprised of deferred compensation plan assets, corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. and foreign government bonds, marketable equity securities and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Any changes in fair value are recognized in net investment gain (loss). Realized gains and losses on sales of debt securities are computed under the specific identification method and are included in other income (expense). See Note 5 for additional information.

[0001564590-20-006425:notes:18]
Accounts Receivable

[0001564590-20-006425:notes:19]
We record accounts receivable at net realizable value. Prior to establishing payment terms for a new customer, we evaluate the credit risk of the customer. Credit limits and payment terms established for new customers are re-evaluated periodically based on customer collection experience and other financial factors. As of December 31, 2019, single customers comprising more than 10% of our total accounts receivable balance included four customers, which accounted for 53.2% of our total accounts receivable. As of December 31, 2018, single customers comprising more than 10% of our total accounts receivable balance included two customers, which accounted for 36.9% of our total accounts receivable.

[0001564590-20-006425:notes:20]
We regularly review the need to maintain an allowance for doubtful accounts and consider factors such as the age of accounts receivable balances, the current economic conditions that may affect a customer’s ability to pay, significant one-time events impacting these customers and our historical experience. If the financial condition of a customer deteriorates, resulting in an impairment of their ability to make payments, we may be required to record an allowance for doubtful accounts. If circumstances change with regard to individual receivable balances that have previously been determined to be uncollectible, and for which a specific reserve has been established, a reduction in our allowance for doubtful accounts may be required. Our allowance for doubtful accounts was $38 thousand and $0.1 million as of December 31, 2019 and December 31, 2018, respectively.

[0001564590-20-006425:notes:21]
Inventory

[0001564590-20-006425:notes:22]
Inventory is carried at the lower of cost and estimated net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory and are updated at least quarterly. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 7 for additional information.

[0001564590-20-006425:notes:23]
Property, Plant and Equipment

[0001564590-20-006425:notes:24]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. We depreciate building and land improvements from five to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years, and computer software from three to five years. Expenditures for repairs and maintenance are charged to expense as incurred. Major improvements that materially prolong the lives of the assets are capitalized. Gains and losses on the disposal of property, plant and equipment are recorded in operating income (loss). See Note 8 for additional information.

[0001564590-20-006425:notes:25]
Intangible Assets

[0001564590-20-006425:notes:26]
Purchased intangible assets with finite lives are carried at cost less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets, which is two to 14 years. See Note 11 for additional information.

[0001564590-20-006425:notes:27]
Impairment of Long-Lived Assets and Intangibles

[0001564590-20-006425:notes:28]
Long-lived assets used in operations and intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. An impairment loss would be recognized in the amount by which the recorded value of the asset exceeds the fair value of the asset, measured by the quoted market price of an asset or an estimate based on the best information available in the circumstances. During the year ended December 31, 2019, we recognized an impairment loss of approximately $3.9 million related to the abandonment of certain information technology implementation projects which we had previously capitalized expenses related to these projects. There were no impairment losses for long-lived assets during the years ended December 31, 2018 or 2017, or for intangible assets recognized during the years ended December 31, 2019, 2018 or 2017.

[0001564590-20-006425:notes:29]
Goodwill

[0001564590-20-006425:notes:30]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to by-pass a qualitative assessment to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount and, in turn, performed a step-1 analysis of goodwill. Based on the results of our step-1 analysis, no impairment charges on goodwill were recognized during the years ended December 31, 2019, 2018 and 2017.

[0001564590-20-006425:notes:31]
Liability for Warranty

[0001564590-20-006425:notes:32]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.4 million and $8.6 million as of December 31, 2019 and 2018, respectively. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets. During 2017, we recorded a reduction in warranty expense related to a settlement with a third-party supplier for a defective component, the impact of which is reflected in the following table.

[0001564590-20-006425:notes:33]
A summary of warranty expense and write-off activity for the years ended December 31, 2019, 2018 and 2017 is as follows:

[0001564590-20-006425:notes:34]
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Year Ended December 31, |  |  |  |  |  |  |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 8,623 |  |  | $ | 9,724 |  |  | $ | 8,548 |  |
| Plus: Amounts charged to cost and expenses |  |  | 4,569 |  |  |  | 7,392 |  |  |  | 6,951 |  |
| Less: Deductions |  |  | (4,798 | ) |  |  | (8,493 | ) |  |  | (5,775 | ) |
| Balance at end of period |  | $ | 8,394 |  |  | $ | 8,623 |  |  | $ | 9,724 |  |

[0001564590-20-006425:notes:35]
Pension Benefit Plan Obligations

[0001564590-20-006425:notes:36]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $15.9 million and $13.1 million as of December 31, 2019 and 2018, respectively.

[0001564590-20-006425:notes:37]
Stock-Based Compensation

[0001564590-20-006425:notes:38]
We have two stock incentive plans from which stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock are available for grant to employees and directors. Costs related to these awards are recognized over their vesting periods. All employee and director stock options granted under our stock option plans have an exercise price equal to the fair market value of the award, as defined in the plan, of the underlying common stock on the grant date. All of our outstanding stock option awards are classified as equity awards and therefore are measured at fair value on their grant date.

[0001564590-20-006425:notes:39]
Stock-based compensation expense recognized for the years ended December 31, 2019, 2018 and 2017 was approximately $7.0 million, $7.2 million and $7.4 million, respectively. As of December 31, 2019, total unrecognized compensation cost related to non-vested stock options, PSUs, RSUs and restricted stock was approximately $17.2 million, which is expected to be recognized over an average remaining recognition period of 3.0 years. See Note 4 for additional information.

[0001564590-20-006425:notes:40]
Research and Development Costs

[0001564590-20-006425:notes:41]
Research and development costs include compensation for engineers and support personnel, outside contracted services, depreciation and material costs associated with new product development, enhancement of current products and product cost reductions. We continually evaluate new product opportunities and engage in intensive research and product development efforts. Research and development costs totaled $126.2 million, $124.5 million and $130.7 million for the years ended December 31, 2019, 2018 and 2017, respectively.

[0001564590-20-006425:notes:42]
Other Comprehensive Income (Loss)

[0001564590-20-006425:notes:43]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by components of accumulated other comprehensive income (loss) for the years ended December 31, 2019 2018 and 2017:

[0001564590-20-006425:notes:44]
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (2) |  |  | Total |  |
| Balance as of December 31, 2016 |  | $ | 404 |  |  | $ | — |  |  | $ | (5,017 | ) |  | $ | (7,575 | ) |  | $ | — |  |  | $ | (12,188 | ) |
| Other comprehensive income before reclassifications |  |  | 5,020 |  |  |  | (619 | ) |  |  | 451 |  |  |  | 5,999 |  |  |  | — |  |  |  | 10,851 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | (2,857 | ) |  |  | 619 |  |  |  | 280 |  |  |  | — |  |  |  | — |  |  |  | (1,958 | ) |
| Balance as of December 31, 2017 |  |  | 2,567 |  |  |  | — |  |  |  | (4,286 | ) |  |  | (1,576 | ) |  |  | — |  |  |  | (3,295 | ) |
| Other comprehensive loss before reclassifications |  |  | 685 |  |  |  | — |  |  |  | (3,890 | ) |  |  | (4,236 | ) |  |  | — |  |  |  | (7,441 | ) |
| Amounts reclassified to retained earnings (1) |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | (595 | ) |  |  | — |  |  |  | 135 |  |  |  | — |  |  |  | — |  |  |  | (460 | ) |
| Balance as of December 31, 2018 |  |  | (563 | ) |  |  | — |  |  |  | (8,041 | ) |  |  | (5,812 | ) |  |  | — |  |  |  | (14,416 | ) |
| Other comprehensive loss before reclassifications |  |  | 573 |  |  |  | — |  |  |  | (1,717 | ) |  |  | (1,480 | ) |  |  | — |  |  |  | (2,624 | ) |
| Amounts reclassified to retained earnings (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |  |  | 385 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | (294 | ) |  |  | — |  |  |  | 532 |  |  |  | — |  |  |  | — |  |  |  | 238 |  |
| Balance as of December 31, 2019 |  | $ | (284 | ) |  | $ | — |  |  | $ | (9,226 | ) |  | $ | (7,292 | ) |  | $ | 385 |  |  | $ | (16,417 | ) |

[0001564590-20-006425:notes:45]
|  | (1) | With the adoption of ASU 2016-01, the unrealized gains on our equity investments were reclassified to retained earnings. See Recently Issued Accounting Standards below for more information. |

[0001564590-20-006425:notes:46]
|  | (2) | With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings. See Note 13 for additional information. |

[0001564590-20-006425:notes:47]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the years ended December 31, 2019, 2018 and 2017:

[0001564590-20-006425:notes:48]
| (In thousands) |  | 2019 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Loss |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 397 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (771 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (374 | ) |  |  |
| Tax benefit |  |  | 136 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (238 | ) |  |  |

[0001564590-20-006425:notes:49]
|  | (1) | Included in the computation of net periodic pension cost. See Note 14 for additional information. |

[0001564590-20-006425:notes:50]
| (In thousands) |  | 2018 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Loss |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 804 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (196 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 608 |  |  |  |
| Tax expense |  |  | (148 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 460 |  |  |  |

[0001564590-20-006425:notes:51]
| (In thousands) |  | 2017 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Loss |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 4,864 |  |  | Net investment gain (loss) |
| Impairment expense |  |  | (180 | ) |  | Net investment gain (loss) |
| Net losses on derivatives designated as hedging instruments |  |  | (897 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (406 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 3,381 |  |  |  |
| Tax expense |  |  | (1,423 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,958 |  |  |  |

[0001564590-20-006425:notes:52]
The following tables present the tax effects related to the change in each component of other comprehensive income (loss) for the years ended December 31, 2019, 2018 and 2017:

[0001564590-20-006425:notes:53]
|  |  | 2019 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 774 |  |  | $ | (201 | ) |  | $ | 573 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net loss |  |  | (397 | ) |  |  | 103 |  |  |  | (294 | ) |
| Defined benefit plan adjustments |  |  | (2,488 | ) |  |  | 771 |  |  |  | (1,717 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net loss |  |  | 771 |  |  |  | (239 | ) |  |  | 532 |  |
| Foreign currency translation adjustment |  |  | (1,480 | ) |  |  | — |  |  |  | (1,480 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (2,820 | ) |  | $ | 434 |  |  | $ | (2,386 | ) |

[0001564590-20-006425:notes:54]
|  |  | 2018 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 926 |  |  | $ | (241 | ) |  | $ | 685 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net loss |  |  | (804 | ) |  |  | 209 |  |  |  | (595 | ) |
| Reclassification adjustment for amounts reclassed to retained earnings related to the adoption of ASU 2016-01 |  |  | (4,351 | ) |  |  | 1,131 |  |  |  | (3,220 | ) |
| Defined benefit plan adjustments |  |  | (5,638 | ) |  |  | 1,748 |  |  |  | (3,890 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net loss |  |  | 196 |  |  |  | (61 | ) |  |  | 135 |  |
| Foreign currency translation adjustment |  |  | (4,236 | ) |  |  | — |  |  |  | (4,236 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (13,907 | ) |  | $ | 2,786 |  |  | $ | (11,121 | ) |

[0001564590-20-006425:notes:55]
|  |  | 2017 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 8,230 |  |  | $ | (3,210 | ) |  | $ | 5,020 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (4,684 | ) |  |  | 1,827 |  |  |  | (2,857 | ) |
| Unrealized gains (losses) on cash flow hedges |  |  | (897 | ) |  |  | 278 |  |  |  | (619 | ) |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | 897 |  |  |  | (278 | ) |  |  | 619 |  |
| Defined benefit plan adjustments |  |  | 654 |  |  |  | (203 | ) |  |  | 451 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 406 |  |  |  | (126 | ) |  |  | 280 |  |
| Foreign currency translation adjustment |  |  | 5,999 |  |  |  | — |  |  |  | 5,999 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 10,605 |  |  | $ | (1,712 | ) |  | $ | 8,893 |  |

[0001564590-20-006425:notes:56]
Income Taxes

[0001564590-20-006425:notes:57]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax bases of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0001564590-20-006425:notes:58]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001564590-20-006425:notes:59]
Foreign Currency

[0001564590-20-006425:notes:60]
We record transactions denominated in foreign currencies using appropriate exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are remeasured at the balance sheet dates using the closing rates of exchange between those foreign currencies and the functional currency with any transaction gains or losses reported in other income (expense). Our primary exposures to foreign currency exchange rate movements are with our German subsidiary, whose functional currency is the Euro, our Australian subsidiary, whose functional currency is the Australian dollar and our Mexican subsidiary, whose functional currency is the U.S. dollar as most invoices are paid in Mexican Pesos. Adjustments resulting from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive income (loss).

[0001564590-20-006425:notes:61]
Revenue

[0001564590-20-006425:notes:62]
On January 1, 2018, we adopted ASU 2014-09, Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition.

[0001564590-20-006425:notes:63]
Accounting Policy under Topic 606

[0001564590-20-006425:notes:64]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. Review of contracts with customers, for both direct customers and distributors, are performed and assessment made regarding principal versus agent considerations to determine primary responsibility for delivery of performance obligation, presumed inventory risk, and discretion in establishing pricing. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which we sell the separate products and services and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract, if material, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to account for shipping fees as a cost of fulfilling the related contract. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0001564590-20-006425:notes:65]
The following is a description of the principal activities from which we generate our revenue by reportable segment.

[0001564590-20-006425:notes:66]
Network Solutions Segment

[0001564590-20-006425:notes:67]
Network Solutions includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales.

[0001564590-20-006425:notes:68]
Hardware and Software Revenue

[0001564590-20-006425:notes:69]
Revenue from hardware sales is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. This segment also includes revenues from software license sales which is recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

[0001564590-20-006425:notes:70]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services.

[0001564590-20-006425:notes:71]
Services & Support Segment

[0001564590-20-006425:notes:72]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-20-006425:notes:73]
Maintenance Revenue

[0001564590-20-006425:notes:74]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenues, when applicable, are recorded in current and non-current unearned revenue.

[0001564590-20-006425:notes:75]
Network Implementation Revenue

[0001564590-20-006425:notes:76]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0001564590-20-006425:notes:77]
Accounting Policy under Topic 605

[0001564590-20-006425:notes:78]
Revenue was generally recognized when persuasive evidence of an arrangement exists, delivery has occurred, the product price was fixed or determinable, collection of the resulting receivable was reasonably assured, and product returns were reasonably estimable. For product sales, revenue was generally recognized upon shipment of the product to our customer in accordance with the title transfer terms of the sales agreement, generally Ex Works, per International Commercial Terms. In the case of consigned inventory, revenue was recognized when the end customer assumes ownership of the product. Contracts that contained multiple deliverables were evaluated to determine the units of accounting, and the consideration from the arrangement was allocated to each unit of accounting based on the relative selling price and corresponding terms of the contract. When this was not available, we were generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. In these instances, we used best estimates to allocate consideration to each respective unit of accounting. These estimates included analysis of respective bills of material and review and analysis of similar product and service offerings. We recorded revenue associated with installation services when respective contractual obligations are complete. In instances where customer acceptance was required, revenue was deferred until respective acceptance criteria were met. Contracts that included both installation services and product sales were evaluated for revenue recognition in accordance with contract terms. As a result, installation services may have been considered a separate deliverable or may have been considered a combined single unit of accounting with the delivered product. Generally, either the purchaser, ADTRAN, or a third party would perform the installation of our products. Shipping fees were recorded as revenue and the related costs were included in cost of sales. Sales taxes invoiced to customers were included in revenues and represented less than one percent of total revenues. The corresponding sales taxes paid were included in cost of goods sold. Value-added taxes collected from customers in international jurisdictions were recorded in accrued expenses as a liability. Revenue was recorded net of discounts. Sales returns were recorded as a reduction of revenue and accrued based on historical sales return experience, which we believed provided a reasonable estimate of future returns.

[0001564590-20-006425:notes:79]
Unearned Revenue

[0001564590-20-006425:notes:80]
Unearned revenue primarily represents customer billings on our maintenance service programs and unearned revenues related to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one month to five years. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. In addition, we provide software maintenance and a variety of hardware maintenance services to customers under contracts with terms up to ten years. When we defer revenue related to multiple performance obligations where we still have contractual obligations, we also defer the related costs. Current deferred costs are included in prepaid expenses and other current assets on the accompanying Consolidated Balance Sheets and totaled $1.6 million and $2.4 million as of December 31, 2019 and 2018, respectively. Non-current deferred costs are included in other assets on the accompanying Consolidated Balance Sheets and totaled $0.1 million and $0.8 million as of December 31, 2019 and 2018, respectively.

[0001564590-20-006425:notes:81]
Earnings (Loss) per Share

[0001564590-20-006425:notes:82]
Earnings (loss) per common share and earnings (loss) per common share assuming dilution, are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year. See Note 17 for additional information.

[0001564590-20-006425:notes:83]
Business Combinations

[0001564590-20-006425:notes:84]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets and liabilities assumed acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired and liabilities assumed exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying Consolidated Statements of Operations since their dates of acquisition. Costs incurred to complete the business combination, such as legal, accounting or other professional fees are charged to selling, general and administrative expenses as incurred.

[0001564590-20-006425:notes:85]
Derivative Instruments and Hedging Activities

[0001564590-20-006425:notes:86]
Historically, we have participated in foreign exchange forward contracts in connection with the management of exposure to fluctuations in foreign exchange rates as outlined below.

[0001564590-20-006425:notes:87]
Cash Flow Hedges

[0001564590-20-006425:notes:88]
Our cash flow hedging activities utilize foreign exchange forward contracts to reduce the risk that movements in exchange rates will adversely affect the net cash flows resulting from the planned purchase of products from foreign suppliers. Purchases of U.S. denominated inventory by our European subsidiary represent our primary exposure. Changes in the fair value of derivatives designated as cash flow hedges are recorded in accumulated other comprehensive income. Amounts related to cash flow hedges are reclassified from accumulated other comprehensive income to earnings when the underlying hedged item impacts earnings. This reclassification is recorded in the same line item of the consolidated statements of income as where the effects of the hedged item are recorded, which is cost of sales.

[0001564590-20-006425:notes:89]
Undesignated Hedges

[0001564590-20-006425:notes:90]
We have certain customers and suppliers who are invoiced or pay in a non-functional currency. Changes in the monetary exchange rates may adversely affect our results of operations and financial condition, as outstanding non-functional balances are revalued to the functional currency through earnings. When appropriate, we utilize foreign exchange forward contracts to help manage the volatility relating to these valuation exposures. All changes in the fair value of our derivative instruments that do not qualify for, or are not designated for, hedged accounting transactions are recognized in other income (expense), net in the Consolidated Statements of Income.

[0001564590-20-006425:notes:91]
We do not hold or issue derivative instruments for trading or other speculative purposes. Our derivative instruments are recorded on the Consolidated Balance Sheets at their fair values. Our derivative instruments are not subject to master netting arrangements and are not offset on the Consolidated Balance Sheets.

[0001564590-20-006425:notes:92]
Recent Accounting Pronouncements Not Yet Adopted

[0001564590-20-006425:notes:93]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the leases standard. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as, providing disclosure relief for accrued interest receivables. All of these ASUs are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect these ASUs will have on our consolidated financial statements.

[0001564590-20-006425:notes:94]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating ASU 2017-04, but do not expect it will have a material effect on our consolidated financial statements.

[0001564590-20-006425:notes:95]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but do not expect it will have a material effect on our financial statement disclosures.

[0001564590-20-006425:notes:96]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but do not expect it will have a material effect on our financial statement disclosures.

[0001564590-20-006425:notes:97]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect of ASU 2018-15, but do not expect it will have a material effect on our consolidated financial statements.

[0001564590-20-006425:notes:98]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in this update simplify the accounting for income taxes by removing various exceptions, such as, the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update, also simplify the accounting for income taxes related to income-based franchise taxes and requiring that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. ASU 2019-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020, with early adoption permitted. We are currently evaluating the effect of ASU 2019-12, but do not expect it will have a material effect on our consolidated financial statements.

[0001564590-20-006425:notes:99]
Recently Adopted Accounting Pronouncements

[0001564590-20-006425:notes:100]
During 2019, we adopted the following accounting standards, which had the following impacts on our consolidated financial statements:

[0001564590-20-006425:notes:101]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provided for an optional transition method allowing for the application of the legacy lease guidance, Leases (Topic 840), including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. In March 2019, the FASB issued ASU 2019-01, Leases (Topic 842) Codification Improvements, which removed the requirement for an entity to disclose in the interim periods after adoption, the effect of the change on income from continuing operations, net income, any other affected financial statement line item and any affected per share amount. For lessors, the new leasing standard requires leases to be classified as sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard, and its related updates, were effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.

[0001564590-20-006425:notes:102]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. At that time, the Company elected to carry forward the legacy ASC 840 disclosures for comparative periods and, therefore, did not adjust the comparative period financial information prior to January 1, 2019. In addition, the Company elected the package of practical expedients which allows for companies to not reassess whether any expired or existing contracts are or contain leases, not reassess historical lease classifications for expired or existing contracts and not reassess initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and nonlease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our Consolidated Balance Sheets of $10.3 million as of January 1, 2019, primarily related to our operating leases for office space, automobiles and other equipment.

[0001564590-20-006425:notes:103]
As a lessee, the adoption of this standard did not have a material impact on our Consolidated Statement of Income or Statement of Cash Flows. See Note 9 for additional information.

[0001564590-20-006425:notes:104]
As a lessor, the adoption of this standard did not have a material impact on our Consolidated Balance Sheet, Consolidated Statement of Income or Consolidated Statement of Cash Flows. Prior to and after adoption, all of our leases in which we are the lessor were classified as sales-type leases.

[0001564590-20-006425:notes:105]
In March 2017, the FASB issued ASU 2017-08, Receivables – Nonrefundable Fees and Other Costs (Subtopic 310-20): Premium Amortization on Purchased Callable Debt Securities, which shortened the amortization period for the premium on certain purchased callable debt securities to the earliest call date. ASU 2017-08 was effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2018. The amendments were required to be applied through a modified-retrospective transition approach that required a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The Company adopted ASU 2017-08 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-20-006425:notes:106]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expanded and refined hedge accounting for both financial and non-financial risk components, aligned the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and included certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness.  In October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (“SOFR”) Overnight Index Swap (“OIS”) Rate as a Benchmark Interest Rate for Hedge Accounting, which permits the OIS rate based on SOFR as a U.S. benchmark interest rate. Both ASU 2017-12 and ASU 2018-16 were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2017-12 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements as we did not have any hedging instruments as of the date of adoption.

[0001564590-20-006425:notes:107]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allowed for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 was effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2018-02 on January 1, 2019, and upon adoption reclassified $0.4 million of stranded tax effects created by rate changes related to the Tax Cuts and Jobs Act of 2017 to retained earnings.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-20-006425:notes:108]
Note 2 – Business Combinations

[0001564590-20-006425:notes:109]
In November 2018, we acquired SmartRG, Inc., a provider of carrier-class, open-source connected home platforms and cloud services for broadband service providers for cash consideration. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. These revenues are included in the Subscriber Solutions & Experience category within the Network Solutions and Services & Support reportable segments.

[0001564590-20-006425:notes:110]
Contingent liabilities with a fair value totaling $1.2 million were recognized at the acquisition date, the payments of which were dependent upon SmartRG achieving future revenue, EBIT or customer purchase order milestones during the first half of 2019. The required milestones were not achieved and therefore, we recognized a gain of $1.2 million upon the reversal of these liabilities during the second quarter of 2019.

[0001564590-20-006425:notes:111]
An escrow in the amount of $2.8 million was set up at the acquisition date to fund post-closing working capital settlements and to satisfy indemnity obligations to the Company arising from any inaccuracy or breach of representations, warranties, covenants, agreements or obligations of the sellers. The escrow is subject to arbitration. In December 2019, $1.3 million of the $2.8 million was released from the escrow account pursuant to the agreement, with the final settlement of the remaining balance expected during the fourth quarter of 2020. The remaining minimum and maximum potential release of funds to the seller ranges from no payment to $1.5 million.

[0001564590-20-006425:notes:112]
We recorded goodwill of $3.5 million as a result of this acquisition, which represents the excess of the purchase price over the fair value of net assets acquired and liabilities assumed. We assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-20-006425:notes:113]
On March 19, 2018, we acquired Sumitomo Electric Lightwave Corp.’s (SEL) North American EPON business and entered into a technology license and OEM supply agreement with Sumitomo Electric Industries, Ltd. (SEI). This acquisition establishes ADTRAN as the North American market leader for EPON solutions for the cable MSO industry and it will accelerate the MSO market’s adoption of our open, programmable and scalable architectures. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. These revenues are included in the Access & Aggregation and Subscriber Solutions & Experience categories within the Network Solutions reportable segment.

[0001564590-20-006425:notes:114]
We recorded a bargain purchase gain of $11.3 million during the first quarter of 2018, net of income taxes, which is subject to customary working capital adjustments between the parties. The bargain purchase gain of $11.3 million represents the difference between the fair-value of the net assets acquired over the cash paid. SEI, an OEM supplier based in Japan, is the global market leader in EPON. SEI’s Broadband Networks Division, through its SEL subsidiary, operated a North American EPON business that included sales, marketing, support, and region-specific engineering development. The North American EPON market is primarily driven by the Tier 1 cable MSO operators and has developed more slowly than anticipated. Through the transaction, SEI divested its North American EPON assets and established a relationship with ADTRAN. The transfer of these assets to ADTRAN, which included key customer relationships and a required assumption by ADTRAN of relatively low incremental expenses, along with the value of the technology license and OEM supply agreement, resulted in the bargain purchase gain. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and we have concluded that our valuation procedures and resulting measures were appropriate.  The gain is included in the line item ”Gain on bargain purchase of a business” in the 2018 Consolidated Statements of Income.

[0001564590-20-006425:notes:115]
The final allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date for SmartRG and the final allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date for Sumitomo are as follows:

[0001564590-20-006425:notes:116]
| (In thousands) |  | Sumitomo |  |  | SmartRG |  |
| Assets |  |  |  |  |  |  |  |  |
| Tangible assets acquired |  | $ | 1,006 |  |  | $ | 8,594 |  |
| Intangible assets |  |  | 22,100 |  |  |  | 9,960 |  |
| Goodwill |  |  | — |  |  |  | 3,476 |  |
| Total assets acquired |  |  | 23,106 |  |  |  | 22,030 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Liabilities assumed |  |  | (3,978 | ) |  |  | (6,001 | ) |
| Total liabilities assumed |  |  | (3,978 | ) |  |  | (6,001 | ) |
| Total net assets |  |  | 19,128 |  |  |  | 16,029 |  |
| Gain on bargain purchase of a business, net of tax |  |  | (11,322 | ) |  |  | — |  |
| Total purchase price |  | $ | 7,806 |  |  | $ | 16,029 |  |

[0001564590-20-006425:notes:117]
Our Consolidated Statements of Income include the following revenue and net loss attributable to SmartRG and Sumitomo since the date of acquisition:

[0001564590-20-006425:notes:118]
| (In thousands) |  | March 19, 2018 to December 31, 2018 |  |
| Revenue |  | $ | 9,186 |  |
| Net loss |  | $ | (1,297 | ) |

[0001564590-20-006425:notes:119]
The details of the acquired intangible assets from the SmartRG and Sumitomo acquisitions are as follows:

[0001564590-20-006425:notes:120]
| (In thousands) |  | Value |  |  | Life (in years) |
| Customer relationships |  | $ | 15,190 |  |  | 3 - 12 |
| Developed technology |  |  | 7,400 |  |  | 7 |
| Licensed technology |  |  | 5,900 |  |  | 9 |
| Supplier relationship |  |  | 2,800 |  |  | 2 |
| Licensing agreements |  |  | 560 |  |  | 5 - 10 |
| Trade name |  |  | 210 |  |  | 3 |
| Total |  | $ | 32,060 |  |  |  |

[0001564590-20-006425:notes:121]
The following unaudited supplemental pro forma information presents the financial results as if the acquisition of SmartRG and Sumitomo had occurred on January 1, 2017. This unaudited supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2017, nor is it indicative of any future results. Aside from revising the 2017 net income for the effect of the bargain purchase gains, there were no material, non-recurring adjustments to this unaudited pro-forma information.

[0001564590-20-006425:notes:122]
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Pro forma revenue |  | $ | 559,050 |  |  | $ | 702,573 |  |
| Pro forma net loss |  | $ | (33,862 | ) |  | $ | 33,206 |  |

[0001564590-20-006425:notes:123]
For the years ended December 31, 2019 and 2018, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $5.0 million and $2.9 million, respectively, related to the SmartRG and Sumitomo acquisitions. No acquisition expenses related to the SmartRG and Sumitomo acquisitions were recorded during the year ended December 31, 2017.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-006425:notes:124]
Note 3 - Revenue

[0001564590-20-006425:notes:125]
The following table disaggregates our revenue by major source for the year ended December 31, 2019:

[0001564590-20-006425:notes:126]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 289,980 |  |  | $ | 58,894 |  |  | $ | 348,874 |  |
| Subscriber Solutions & Experience(1) |  |  | 144,651 |  |  |  | 8,269 |  |  |  | 152,920 |  |
| Traditional & Other Products |  |  | 20,595 |  |  |  | 7,672 |  |  |  | 28,267 |  |
| Total |  | $ | 455,226 |  |  | $ | 74,835 |  |  | $ | 530,061 |  |

[0001564590-20-006425:notes:127]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |

[0001564590-20-006425:notes:128]
The following table disaggregates our revenue by major source for the year ended December 31, 2018:

[0001564590-20-006425:notes:129]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 301,801 |  |  | $ | 57,069 |  |  | $ | 358,870 |  |
| Subscriber Solutions & Experience(1) |  |  | 129,067 |  |  |  | 5,393 |  |  |  | 134,460 |  |
| Traditional & Other Products |  |  | 27,364 |  |  |  | 8,583 |  |  |  | 35,947 |  |
| Total |  | $ | 458,232 |  |  | $ | 71,045 |  |  | $ | 529,277 |  |

[0001564590-20-006425:notes:130]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration greater than one year. As of December 31, 2019, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts recognize revenue equal to the amounts we are entitled to invoice which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $13.3 million as of December 31, 2018. The amount related to these performance obligations was $13.6 million as of December 31, 2019, and the Company expects to recognize 64% of such revenue over the next 12 months with the remainder thereafter.

[0001564590-20-006425:notes:131]
The following table provides information about accounts receivables, contract assets and unearned revenue from contracts with customers:

[0001564590-20-006425:notes:132]
| (In thousands) |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Accounts receivable |  | $ | 90,531 |  |  | $ | 99,385 |  |
| Contract assets(1) |  | $ | 2,812 |  |  | $ | 3,766 |  |
| Unearned revenue |  | $ | 11,963 |  |  | $ | 17,940 |  |
| Non-current unearned revenue |  | $ | 6,012 |  |  | $ | 5,296 |  |

[0001564590-20-006425:notes:133]
(1) Included in other receivables on the Consolidated Balance Sheets

[0001564590-20-006425:notes:134]
Of the outstanding unearned revenue balance as of December 31, 2018, $12.7 million was recognized as revenue during the year ended December 31, 2019.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-20-006425:notes:135]
The following tables disaggregates our revenue by major source for the years ended December 31, 2019, 2018 and 2017:

[0001564590-20-006425:notes:136]
|  |  | 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 289,980 |  |  | $ | 58,894 |  |  | $ | 348,874 |  |
| Subscriber Solutions & Experience(1) |  |  | 144,651 |  |  |  | 8,269 |  |  |  | 152,920 |  |
| Traditional & Other Products |  |  | 20,595 |  |  |  | 7,672 |  |  |  | 28,267 |  |
| Total |  | $ | 455,226 |  |  | $ | 74,835 |  |  | $ | 530,061 |  |

[0001564590-20-006425:notes:137]
|  |  | 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 301,801 |  |  | $ | 57,069 |  |  | $ | 358,870 |  |
| Subscriber Solutions & Experience(1) |  |  | 129,067 |  |  |  | 5,393 |  |  |  | 134,460 |  |
| Traditional & Other Products |  |  | 27,364 |  |  |  | 8,583 |  |  |  | 35,947 |  |
| Total |  | $ | 458,232 |  |  | $ | 71,045 |  |  | $ | 529,277 |  |

[0001564590-20-006425:notes:138]
|  |  | 2017 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 361,955 |  |  | $ | 111,989 |  |  | $ | 473,944 |  |
| Subscriber Solutions & Experience(1) |  |  | 132,294 |  |  |  | 6,162 |  |  |  | 138,456 |  |
| Traditional & Other Products |  |  | 46,147 |  |  |  | 8,353 |  |  |  | 54,500 |  |
| Total |  | $ | 540,396 |  |  | $ | 126,504 |  |  | $ | 666,900 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-006425:notes:139]
Note 4 – Stock-Based Compensation

[0001564590-20-006425:notes:140]
Stock Incentive Program Descriptions

[0001564590-20-006425:notes:141]
In January 2006, the Board of Directors adopted the ADTRAN, Inc. 2006 Employee Stock Incentive Plan (the “2006 Plan”), which authorized 13.0 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock. The 2006 Plan was adopted by stockholder approval at our annual meeting of stockholders held in May 2006. Options granted under the 2006 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and had a ten-year contractual term. The 2006 Plan was replaced in May 2015 by the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (the “2015 Plan”). Expiration dates of options outstanding as of December 31, 2019 under the 2006 Plan range from 2020 to 2024.

[0001564590-20-006425:notes:142]
In January 2015, the Board of Directors adopted the 2015 Plan, which authorized 7.7 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, PSUs, RSUs and restricted stock. The 2015 Plan was adopted by stockholder approval at our annual meeting of stockholders held in May 2015. PSUs, RSUs and restricted stock granted under the 2015 Plan reduce the shares authorized for issuance under the 2015 Plan by 2.5 shares of common stock for each share underlying the award. Options granted under the 2015 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Expiration dates of options outstanding as of December 31, 2019 under the 2015 Plan range from 2025 to 2026.

[0001564590-20-006425:notes:143]
Our stockholders approved the 2010 Directors Stock Plan (the “2010 Directors Plan”) in May 2010, under which 0.5 million shares of common stock have been reserved for issuance. This plan replaced the 2005 Directors Stock Option Plan. Under the 2010 Directors Plan, the Company may issue stock options, restricted stock and RSUs to our non-employee directors. Stock awards issued under the 2010 Directors Plan become vested in full on the first anniversary of the grant date. Options issued under the 2010 Directors Plan had a ten-year contractual term. All remaining options under the 2010 Directors Plan expired in 2019.

[0001564590-20-006425:notes:144]
The following table summarizes stock-based compensation expense related to stock options, PSUs, RSUs and restricted stock for the years ended December 31, 2019, 2018 and 2017, which was recognized as follows:

[0001564590-20-006425:notes:145]
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 369 |  |  | $ | 418 |  |  | $ | 379 |  |
| Selling, general and administrative expense |  |  | 3,889 |  |  |  | 3,989 |  |  |  | 4,063 |  |
| Research and development expense |  |  | 2,704 |  |  |  | 2,748 |  |  |  | 2,991 |  |
| Stock-based compensation expense included in operating expenses |  |  | 6,593 |  |  |  | 6,737 |  |  |  | 7,054 |  |
| Total stock-based compensation expense |  |  | 6,962 |  |  |  | 7,155 |  |  |  | 7,433 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (1,659 | ) |  |  | (1,432 | ) |  |  | (1,699 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 5,303 |  |  | $ | 5,723 |  |  | $ | 5,734 |  |

[0001564590-20-006425:notes:146]
PSUs, RSUs and restricted stock

[0001564590-20-006425:notes:147]
Under the 2015 Plan, awards other than stock options, including PSUs, RSUs and restricted stock, may be granted to certain employees and officers.

[0001564590-20-006425:notes:148]
Under our market-based PSU program, the number of shares of common stock earned by a recipient is subject to a market condition based on ADTRAN’s relative total shareholder return against all companies in the NASDAQ Telecommunications Index at the end of a three-year performance period. Depending on the relative total shareholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the PSUs, with the shares earned distributed upon the vesting. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted PSUs vests and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of ADTRAN, as defined by the 2015 Plan. The recipients of the PSUs receive dividend credits based on the shares of common stock underlying the PSUs. The dividend credits vest and are earned in the same manner as the PSUs and are paid in cash upon the issuance of common stock for the PSUs.

[0001564590-20-006425:notes:149]
During the first quarter of 2017, the Compensation Committee of the Board of Directors approved a one-time PSU grant of 0.5 million shares that contained performance conditions and would have vested at the end of a three-year period if such performance conditions were met. The fair value of these performance-based PSU awards was equal to the closing price of our stock on the date of grant. These awards were forfeited during the first quarter of 2020 as the performance conditions were not achieved.

[0001564590-20-006425:notes:150]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. RSUs and restricted stock vest ratably over four-year and one-year periods, respectively.

[0001564590-20-006425:notes:151]
We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0001564590-20-006425:notes:152]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2018 and 2019 and the changes that occurred during 2019:

[0001564590-20-006425:notes:153]
| (In thousands, except per share amounts) |  | Number of shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2018 |  |  | 1,570 |  |  | $ | 18.52 |  |
| PSUs, RSUs and restricted stock granted |  |  | 897 |  |  | $ | 9.63 |  |
| PSUs, RSUs and restricted stock vested |  |  | (368 | ) |  | $ | 17.23 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (208 | ) |  | $ | 18.24 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2019 |  |  | 1,891 |  |  | $ | 14.58 |  |

[0001564590-20-006425:notes:154]
As of December 31, 2019, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $17.2 million, which is expected to be recognized over an average remaining recognition period of 2.9 years and adjusted for actual forfeitures as they occur.

[0001564590-20-006425:notes:155]
The following table details the significant assumptions that impact the fair value estimate of the market-based PSUs:

[0001564590-20-006425:notes:156]
|  |  | 2019 |  | 2018 |  |  | 2017 |  |
| Estimated fair value per share |  | $9.53 to $18.05 |  | $ | 16.59 |  |  | $ | 24.17 |  |
| Expected volatility |  | 32.7% to 38.9% |  | 27.98% to 31.58% |  |  |  | 27.03 | % |
| Risk-free interest rate |  | 1.6% to 2.46% |  | 2.11% to 2.99% |  |  |  | 1.78 | % |
| Expected dividend yield |  | 2.3% to 4.09% |  | 1.83% to 2.49% |  |  |  | 1.74 | % |

[0001564590-20-006425:notes:157]
As of December 31, 2019, 1.0 million shares were available for issuance under shareholder-approved equity plans in connection with the grant and exercise of stock options, PSU’s, RSU’s or restricted stock.

[0001564590-20-006425:notes:158]
Stock Options

[0001564590-20-006425:notes:159]
The following table is a summary of our stock options outstanding as of December 31, 2019 and 2018 and the changes that occurred during 2019:

[0001564590-20-006425:notes:160]
|  |  | Number of Options (in thousands) |  |  | Weighted Average Exercise Price (per share) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Aggregate Intrinsic Value (in thousands) |  |
| Stock options outstanding, December 31, 2018 |  |  | 4,382 |  |  | $ | 22.91 |  |  |  | 4.10 |  |  | $ | — |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (34 | ) |  | $ | 15.53 |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (32 | ) |  | $ | 15.56 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (744 | ) |  | $ | 23.72 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, December 31, 2019 |  |  | 3,572 |  |  | $ | 22.88 |  |  |  | 3.40 |  |  | $ | — |  |
| Stock options exercisable, December 31, 2019 |  |  | 3,570 |  |  | $ | 22.89 |  |  |  | 3.40 |  |  | $ | — |  |

[0001564590-20-006425:notes:161]
All of the options above were issued at exercise prices that approximated fair market value at the date of grant. As of December 31, 2019, total unrecognized compensation expense related to non-vested stock options was approximately $11 thousand, which is expected to be recognized over an average remaining recognition period of one year and will be adjusted for actual forfeitures as they occur.

[0001564590-20-006425:notes:162]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of 2019 and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2019. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock and was $0 as of December 31, 2019.

[0001564590-20-006425:notes:163]
The total pre-tax intrinsic value of options exercised during 2019, 2018 and 2017 was $0.1 million, $0.2 million and $3.4 million, respectively. The fair value of options fully vesting during 2019, 2018 and 2017 was $0.9 million, $2.5 million and $4.3 million, respectively.

[0001564590-20-006425:notes:164]
The following table further describes our stock options outstanding as of December 31, 2019:

[0001564590-20-006425:notes:165]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range of Exercise Prices |  | Options Outstanding at December 31, 2019 (In thousands) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Weighted Average Exercise Price |  |  | Options Exercisable at December 31, 2019 (In thousands) |  |  | Weighted Average Exercise Price |  |
| $14.88 – $18.96 |  |  | 1,135 |  |  |  | 4.90 |  |  | $ | 15.89 |  |  |  | 1,133 |  |  | $ | 15.89 |  |
| $18.97 – $23.45 |  |  | 685 |  |  |  | 4.70 |  |  | $ | 19.10 |  |  |  | 685 |  |  | $ | 19.10 |  |
| $23.46 – $30.35 |  |  | 686 |  |  |  | 3.67 |  |  | $ | 24.17 |  |  |  | 686 |  |  | $ | 24.17 |  |
| $30.36 – $41.92 |  |  | 1,066 |  |  |  | 1.29 |  |  | $ | 31.93 |  |  |  | 1,066 |  |  | $ | 31.93 |  |
|  |  |  | 3,572 |  |  |  |  |  |  |  |  |  |  |  | 3,570 |  |  |  |  |  |

[0001564590-20-006425:notes:166]
The Black-Scholes option pricing model (the “Black-Scholes Model”) is used to determine the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0001564590-20-006425:notes:167]
There were no stock options granted in during the years ended December 31, 2019, 2018 or 2017.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-20-006425:notes:168]
Note 5 – Investments

[0001564590-20-006425:notes:169]
Debt Securities and Other Investments

[0001564590-20-006425:notes:170]
As of  December 31, 2019, we held the following debt securities and other investments, recorded at fair value:

[0001564590-20-006425:notes:171]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,304 |  |  | $ | 80 |  |  | $ | — |  |  | $ | 9,384 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | 930 |  |
| Asset-backed bonds |  |  | 6,867 |  |  |  | 26 |  |  |  | (3 | ) |  |  | 6,890 |  |
| Mortgage/Agency-backed bonds |  |  | 6,944 |  |  |  | 26 |  |  |  | (8 | ) |  |  | 6,962 |  |
| U.S. government bonds |  |  | 12,311 |  |  |  | 21 |  |  |  | (9 | ) |  |  | 12,323 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (1 | ) |  |  | 371 |  |
| Variable rate demand notes |  |  | 800 |  |  |  | — |  |  |  | — |  |  |  | 800 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,528 |  |  | $ | 153 |  |  | $ | (21 | ) |  | $ | 37,660 |  |

[0001564590-20-006425:notes:172]
As of December 31, 2018, we held the following debt securities and other investments, recorded at fair value:

[0001564590-20-006425:notes:173]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 20,777 |  |  | $ | 19 |  |  | $ | (112 | ) |  | $ | 20,684 |  |
| Municipal fixed-rate bonds |  |  | 1,339 |  |  |  | — |  |  |  | (26 | ) |  |  | 1,313 |  |
| Asset-backed bonds |  |  | 5,230 |  |  |  | 5 |  |  |  | (14 | ) |  |  | 5,221 |  |
| Mortgage/Agency-backed bonds |  |  | 3,833 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 3,791 |  |
| U.S. government bonds |  |  | 9,271 |  |  |  | 1 |  |  |  | (66 | ) |  |  | 9,206 |  |
| Foreign government bonds |  |  | 592 |  |  |  | — |  |  |  | (8 | ) |  |  | 584 |  |
| Available-for-sale debt securities held at fair value |  | $ | 41,042 |  |  | $ | 27 |  |  | $ | (270 | ) |  | $ | 40,799 |  |

[0001564590-20-006425:notes:174]
As of December 31, 2019, our debt securities had the following contractual maturities:

[0001564590-20-006425:notes:175]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage / Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 4,005 |  |  | $ | — |  |  | $ | 396 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 4,120 |  |  |  | 930 |  |  |  | 760 |  |  |  | 213 |  |  |  | 1,347 |  |  |  | — |  |
| Two to three years |  |  | 967 |  |  |  | — |  |  |  | 1,632 |  |  |  | 1,424 |  |  |  | 9,344 |  |  |  | — |  |
| Three to five years |  |  | 292 |  |  |  | — |  |  |  | 2,092 |  |  |  | 494 |  |  |  | 1,632 |  |  |  | 371 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,719 |  |  |  | 792 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 291 |  |  |  | 4,039 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 9,384 |  |  | $ | 930 |  |  | $ | 6,890 |  |  | $ | 6,962 |  |  | $ | 12,323 |  |  | $ | 371 |  |

[0001564590-20-006425:notes:176]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-20-006425:notes:177]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities for the years ended December 31, 2019, 2018 and 2017:

[0001564590-20-006425:notes:178]
| (In thousands) Year Ended December 31, |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Gross realized gains on debt securities |  | $ | 108 |  |  | $ | 57 |  |  | $ | 169 |  |
| Gross realized losses on debt securities |  |  | (50 | ) |  |  | (592 | ) |  |  | (226 | ) |
| Total gain (loss) recognized, net |  | $ | 58 |  |  | $ | (535 | ) |  | $ | (57 | ) |

[0001564590-20-006425:notes:179]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-20-006425:notes:180]
The following table presents the breakdown of debt securities and other investments with unrealized losses as of December 31, 2019:

[0001564590-20-006425:notes:181]
|  |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  |  | 203 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 203 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 797 |  |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | 797 |  |  |  | (3 | ) |
| Mortgage/Agency-backed bonds |  |  | 2,594 |  |  |  | (6 | ) |  |  | 136 |  |  |  | (2 | ) |  |  | 2,730 |  |  |  | (8 | ) |
| U.S. government bonds |  |  | 4,070 |  |  |  | (9 | ) |  |  | — |  |  |  | — |  |  |  | 4,070 |  |  |  | (9 | ) |
| Marketable equity securities |  |  | 371 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 371 |  |  |  | (1 | ) |
| Total |  | $ | 8,965 |  |  | $ | (19 | ) |  | $ | 136 |  |  | $ | (2 | ) |  | $ | 9,101 |  |  | $ | (21 | ) |

[0001564590-20-006425:notes:182]
The following table presents the breakdown of debt securities and other investments with unrealized losses as of December 31, 2018:

[0001564590-20-006425:notes:183]
|  |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  | $ | 11,129 |  |  | $ | (60 | ) |  | $ | 3,608 |  |  | $ | (52 | ) |  | $ | 14,737 |  |  | $ | (112 | ) |
| Municipal fixed-rate bonds |  |  | — |  |  |  | — |  |  |  | 1,136 |  |  |  | (26 | ) |  |  | 1,136 |  |  |  | (26 | ) |
| Asset-backed bonds |  |  | 1,874 |  |  |  | (2 | ) |  |  | 1,257 |  |  |  | (12 | ) |  |  | 3,131 |  |  |  | (14 | ) |
| Mortgage/Agency-backed bonds |  |  | 1,021 |  |  |  | (5 | ) |  |  | 1,918 |  |  |  | (39 | ) |  |  | 2,939 |  |  |  | (44 | ) |
| U.S. government bonds |  |  | 6,527 |  |  |  | (48 | ) |  |  | 537 |  |  |  | (18 | ) |  |  | 7,064 |  |  |  | (66 | ) |
| Foreign government bonds |  |  | 584 |  |  |  | (8 | ) |  |  | — |  |  |  | — |  |  |  | 584 |  |  |  | (8 | ) |
| Total |  | $ | 21,135 |  |  | $ | (123 | ) |  | $ | 8,456 |  |  | $ | (147 | ) |  | $ | 29,591 |  |  | $ | (270 | ) |

[0001564590-20-006425:notes:184]
The decrease in unrealized losses during 2019, as reflected in the table above, results from changes in market positions associated with our fixed income portfolio.

[0001564590-20-006425:notes:185]
Marketable Equity Securities

[0001564590-20-006425:notes:186]
Our marketable equity securities consist of publicly traded stocks or funds measured at fair value.

[0001564590-20-006425:notes:187]
Prior to January 1, 2018, our marketable equity securities were classified as available-for-sale. Realized gains and losses on marketable equity securities were included in net investment gain (loss). Unrealized gains and losses were recognized in accumulated other comprehensive income (loss), net of deferred taxes, on the balance sheet.

[0001564590-20-006425:notes:188]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to opening retained earnings.

[0001564590-20-006425:notes:189]
ASU 2016-01 also provides a measurement alternative for equity investments that do not have a readily determinable fair value in which investments can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. We elected to record our equity investment that does not have a readily determinable fair value using the measurement alternative method. As of December 31, 2018, the Company had a note receivable of approximately $4.3 million, which was included in other receivables on the Consolidated Balance Sheets. During the three months ended March 31, 2019, this amount was repaid and reissued in the form of debt and equity. Approximately $3.4 million was issued as an equity investment, which represented a non-cash investing activity. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. The remaining amount, approximately $0.9 million, was converted into a new note receivable, which is included in other receivables on the Consolidated Balance Sheets and represents a non-cash operating activity.

[0001564590-20-006425:notes:190]
Realized and unrealized gains and losses for our marketable equity securities for the twelve months ended December 31, 2019 were as follows:

[0001564590-20-006425:notes:191]
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (96 | ) |  | $ | 1,306 |  |
| Unrealized gains (losses) on equity securities held |  |  | 11,472 |  |  |  | (4,821 | ) |
| Total gain (loss) recognized, net |  | $ | 11,376 |  |  | $ | (3,515 | ) |

[0001564590-20-006425:notes:192]
As of December 31, 2019 and 2018, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.

[0001564590-20-006425:notes:193]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0001564590-20-006425:notes:194]
|  | • | Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market; |

[0001564590-20-006425:notes:195]
|  | • | Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; |

[0001564590-20-006425:notes:196]
|  | • | Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees. |

[0001564590-20-006425:notes:197]
We have categorized our cash equivalents and our investments held at fair value into this hierarchy as follows:

[0001564590-20-006425:notes:198]
|  |  | Fair Value Measurements as of December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,309 |  |  | $ | 1,309 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,384 |  |  |  | — |  |  |  | 9,384 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,890 |  |  |  | — |  |  |  | 6,890 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 6,962 |  |  |  | — |  |  |  | 6,962 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,323 |  |  |  | 12,323 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 371 |  |  |  | — |  |  |  | 371 |  |  |  | — |  |
| Variable rate demand notes |  |  | 800 |  |  |  | — |  |  |  | 800 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,501 |  |  |  | 35,501 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 298 |  |  |  | 298 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,698 |  |  |  | 21,698 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,442 |  |  |  | 2,442 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 98,908 |  |  | $ | 73,571 |  |  | $ | 25,337 |  |  | $ | — |  |

[0001564590-20-006425:notes:199]
|  |  | Fair Value Measurements as of December 31, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,554 |  |  | $ | 1,554 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,684 |  |  |  | — |  |  |  | 20,684 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,313 |  |  |  | — |  |  |  | 1,313 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,221 |  |  |  | — |  |  |  | 5,221 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 3,791 |  |  |  | — |  |  |  | 3,791 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,206 |  |  |  | 9,206 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 584 |  |  |  | — |  |  |  | 584 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,763 |  |  |  | 26,763 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 253 |  |  |  | 253 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 18,256 |  |  |  | 18,256 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 87,625 |  |  | $ | 56,032 |  |  | $ | 31,593 |  |  | $ | — |  |

[0001564590-20-006425:notes:200]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-20-006425:notes:201]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-20-006425:notes:202]
Note 6 – Derivative Instruments and Hedging Activities

[0001564590-20-006425:notes:203]
As of December 31, 2019 and 2018, we had no foreign exchange forward contracts.

[0001564590-20-006425:notes:204]
The change in the fair values of our derivative instruments recorded in the Consolidated Statements of Income (Loss) during the years ended December 31, 2019, 2018 and 2017 were as follows:

[0001564590-20-006425:notes:205]
| (In thousands) |  | Income Statement Location |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | — |  |  | $ | 13 |  |  | $ | (754 | ) |

[0001564590-20-006425:notes:206]
The change in our derivatives designated as hedging instruments recorded in other comprehensive income and reclassified to income, net of tax, during the twelve months ended December 31, 2019, 2018 and 2017 were as follows:

[0001564590-20-006425:notes:207]
|  |  | Location of |  | Amount of Losses Reclassified |  |
|  |  | Losses Reclassified |  | from AOCI into Income |  |
| (In thousands) |  | from AOCI into Income |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Cost of Sales |  | $ | — |  |  | $ | — |  |  | $ | (897 | ) |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-20-006425:notes:208]
Note 7 – Inventory

[0001564590-20-006425:notes:209]
As of December 31, 2019 and 2018, inventory was comprised of the following:

[0001564590-20-006425:notes:210]
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Raw materials |  | $ | 36,987 |  |  | $ | 45,333 |  |
| Work in process |  |  | 1,085 |  |  |  | 1,638 |  |
| Finished goods |  |  | 60,233 |  |  |  | 52,877 |  |
| Total Inventory, net |  | $ | 98,305 |  |  | $ | 99,848 |  |

[0001564590-20-006425:notes:211]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. As of December 31, 2019 and 2018, our inventory reserve was $34.1 million and $30.0 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-20-006425:notes:212]
Note 8 – Property, Plant and Equipment

[0001564590-20-006425:notes:213]
As of December 31, 2019 and 2018, property, plant and equipment was comprised of the following:

[0001564590-20-006425:notes:214]
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 34,797 |  |  |  | 34,379 |  |
| Building |  |  | 68,157 |  |  |  | 68,183 |  |
| Furniture and fixtures |  |  | 19,959 |  |  |  | 19,831 |  |
| Computer hardware and software |  |  | 74,399 |  |  |  | 92,071 |  |
| Engineering and other equipment |  |  | 130,430 |  |  |  | 127,060 |  |
| Total Property, Plant and Equipment |  |  | 332,317 |  |  |  | 346,099 |  |
| Less accumulated depreciation |  |  | (258,609 | ) |  |  | (265,464 | ) |
| Total Property, Plant and Equipment, net |  | $ | 73,708 |  |  | $ | 80,635 |  |

[0001564590-20-006425:notes:215]
Depreciation expense was $12.5 million, $12.7 million and $12.8 million for the years ended December 31, 2019, 2018 and 2017, respectively, which is recorded in cost of sales, selling, general and administrative expense and research and development expense in the consolidated statements of income.

[0001564590-20-006425:notes:216]
We assess long-lived assets used in operations for potential impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. During the year ended December 31, 2019, the Company recognized impairment charges of $3.9 million related to the abandonment of certain information technology projects in which we had previously capitalized expenses related to these projects. The impairment charges were determined based on actual costs incurred as part of the projects. No impairment charges were recognized during the years ended December 31, 2018 and 2017.


## adtn:LeasesDisclosureTextBlock

[0001564590-20-006425:notes:217]
Note 9 – Leases

[0001564590-20-006425:notes:218]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. We also reviewed other contracts, such as manufacturing agreements and service agreements, for potential embedded leases. We specifically reviewed these other contracts to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease.

[0001564590-20-006425:notes:219]
As of December 31, 2019, our operating leases had remaining lease terms of one month to six years, some of which included options to extend the leases for up to nine years, and some of which included options to terminate the leases within three months. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. Leases with an initial term of 12 months or less were not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. Lease expense related to these short-term leases was $0.4 million for the twelve months ended December 31, 2019, and is included in cost of sales, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Income. Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.9 million for the twelve months ended December 31, 2019. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and nonlease components. Our lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-20-006425:notes:220]
Supplemental balance sheet information related to operating leases is as follows:

[0001564590-20-006425:notes:221]
|  |  |  |  | December 31, |  |  | January 1, |  |
| (In thousands) |  | Classification |  | 2019 |  |  | 2019 (1) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |
| Right of use lease assets |  | Other assets |  | $ | 8,452 |  |  | $ | 10,322 |  |
| Total lease asset |  |  |  | $ | 8,452 |  |  | $ | 10,322 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |
| Current lease liability |  | Accrued expenses |  | $ | 2,676 |  |  | $ | 2,948 |  |
| Non-current lease liability |  | Other non-current liabilities |  |  | 5,818 |  |  |  | 7,374 |  |
| Total lease liability |  |  |  | $ | 8,494 |  |  | $ | 10,322 |  |

[0001564590-20-006425:notes:222]
| (1) | Reflects the adoption of the new lease accounting standard on January 1, 2019. |

[0001564590-20-006425:notes:223]
The components of lease expense included in the Consolidated Statements of Income for the twelve months ended December 31, 2019 were as follows:

[0001564590-20-006425:notes:224]
|  |  | For the Year Ended December 31, |  |
| (In thousands) |  | 2019 |  |
| Research and development expenses |  | $ | 2,417 |  |
| Selling, general and administrative expenses |  |  | 1,400 |  |
| Cost of sales |  |  | 64 |  |
| Total operating lease expense |  | $ | 3,881 |  |

[0001564590-20-006425:notes:225]
As of December 31, 2019, operating lease liabilities included on the Consolidated Balance Sheet by future maturity were as follows:

[0001564590-20-006425:notes:226]
| (In thousands) |  | Amount |  |
| 2020 |  | $ | 2,856 |  |
| 2021 |  |  | 2,412 |  |
| 2022 |  |  | 1,705 |  |
| 2023 |  |  | 1,160 |  |
| 2024 |  |  | 482 |  |
| Thereafter |  |  | 264 |  |
| Total lease payments |  |  | 8,879 |  |
| Less: Interest |  |  | (385 | ) |
| Present value of lease liabilities |  | $ | 8,494 |  |

[0001564590-20-006425:notes:227]
Future operating lease payments include $0.7 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0001564590-20-006425:notes:228]
As of December 31, 2018, future minimum rental payments under non-cancelable operating leases, including renewals determined to be reasonably assured as of December 31, 2018, with original maturities of greater than 12 months, were as follows:

[0001564590-20-006425:notes:229]
| (In thousands) |  | Amount (1) |  |
| 2019 |  | $ | 3,873 |  |
| 2020 |  |  | 3,580 |  |
| 2021 |  |  | 2,771 |  |
| 2022 |  |  | 2,053 |  |
| 2023 |  |  | 1,317 |  |
| Thereafter |  |  | 762 |  |
| Total |  | $ | 14,356 |  |

[0001564590-20-006425:notes:230]
|  | (1) | Certain renewal options were subsequently determined to not be reasonably assured of renewal upon the Company’s adoption of the new lease accounting standard on January 1, 2019. |

[0001564590-20-006425:notes:231]
Our leases do not provide an implicit rate and therefore we use an incremental borrowing rate based on the information available at commencement date in determining the present value of lease payments. We used the incremental borrowing rate on January 1, 2019, for operating leases that commenced on or prior to that date. The incremental borrowing rate was determined on a portfolio basis by grouping leases with similar terms as well as grouping leases based on a U.S. dollar or Euro functional currency.  The actual rate was then determined based on a credit spread over LIBOR as well as the Bloomberg Curve Matrix for the U.S. Communications section. The following table provides information about our weighted average lease terms and weighted average discount rates as of December 31, 2019:

[0001564590-20-006425:notes:232]
|  |  | As of December 31, |  |
|  |  | 2019 |  |
| Weighted average remaining lease term (years) |  |  |  |  |
| Operating leases with USD functional currency |  |  | 2.6 |  |
| Operating leases with Euro functional currency |  |  | 4.4 |  |
| Weighted average discount rate |  |  |  |  |
| Operating leases with USD functional currency |  |  | 4.02 | % |
| Operating leases with Euro functional currency |  |  | 1.84 | % |

[0001564590-20-006425:notes:233]
Supplemental cash flow information related to operating leases is as follows:

[0001564590-20-006425:notes:234]
|  |  | As of December 31, |  |
| (In thousands) |  | 2019 |  |
| Cash paid for amounts included in the measurement of operating lease assets / liabilities |  |  |  |  |
| Cash used in operating activities related to operating leases |  | $ | 3,439 |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 11,615 |  |

[0001564590-20-006425:notes:235]
Sales-Type Leases

[0001564590-20-006425:notes:236]
We are the lessor in sales-type lease arrangements for network equipment, which have initial terms of up to five years. Our sales-type lease arrangements contain either a provision whereby the network equipment reverts back to us upon the expiration of the lease or a provision that allows the lessee to purchase the network equipment at a bargain purchase amount at the end of the lease. In addition, our sales-type lease arrangements do not contain any residual value guarantees or material restrictive covenants. The allocation of the consideration between lease and nonlease components is determined by stand-alone selling price by component. The net investment in sales-type leases consists of lease receivables less unearned income. Collectability of sales-type leases is evaluated periodically at an individual customer level. The Company has elected to exclude taxes related to sales-type leases from revenue and the associated expense of such taxes. As of December 31, 2019 and 2018, we did not have an allowance for credit losses for our net investment in sales-type leases. As of December 31, 2019 and 2018, the components of the net investment in sales-type leases were as follows:

[0001564590-20-006425:notes:237]
|  |  | December 31, |  |  | December 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Current minimum lease payments receivable(1) |  | $ | 1,201 |  |  | $ | 11,339 |  |
| Non-current minimum lease payments receivable(2) |  |  | 889 |  |  |  | 1,670 |  |
| Total minimum lease payments receivable |  |  | 2,090 |  |  |  | 13,009 |  |
| Less: Current unearned revenue(1) |  |  | 365 |  |  |  | 631 |  |
| Less: Non-current unearned revenue(2) |  |  | 163 |  |  |  | 473 |  |
| Net investment in sales-type leases |  | $ | 1,562 |  |  | $ | 11,905 |  |

[0001564590-20-006425:notes:238]
|  | (1) | Included in other receivables on the Consolidated Balance Sheet. |

[0001564590-20-006425:notes:239]
|  | (2) | Included in other assets on the Consolidated Balance Sheet. |

[0001564590-20-006425:notes:240]
The components of sales-type lease gross profit recognized at the lease commencement date and interest and dividend income, included in the Consolidated Statements of Income for the twelve months ended December 31, 2019 were as follows:

[0001564590-20-006425:notes:241]
| (In thousands) |  | For the Year Ended December 31, 2019 |  |
| Sales - Network Solutions |  | $ | 1,723 |  |
| Cost of sales - Network Solutions |  |  | 675 |  |
| Gross profit |  | $ | 1,048 |  |
| Interest and dividend income |  | $ | 357 |  |

[0001564590-20-006425:notes:242]
As of December 31, 2019 future minimum lease payments to be received from sales-type leases were as follows:

[0001564590-20-006425:notes:243]
| (In thousands) |  | Amount |  |
| 2020 |  | $ | 1,201 |  |
| 2021 |  |  | 565 |  |
| 2022 |  |  | 232 |  |
| 2023 |  |  | 86 |  |
| 2024 |  |  | 6 |  |
| Total |  | $ | 2,090 |  |


## adtn:ScheduleOfWeightedAverageRemainingLeaseTermAndWeightedAverageDiscountRateTableTextBlock

[0001564590-20-006425:notes:244]
The following table provides information about our weighted average lease terms and weighted average discount rates as of December 31, 2019


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-20-006425:notes:245]
Note 10 – Goodwill

[0001564590-20-006425:notes:246]
Goodwill, all of which relates to our acquisitions of Bluesocket, Inc. in 2011 and SmartRG in 2018, was $7.0 million as of December 31, 2019 and $7.1 million as of December 31, 2018 of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively, for the year ended December 31, 2019, and of which $6.7 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively, for the year ended December 31, 2018. Goodwill related to our SmartRG acquisition was reduced by $0.1 million during the twelve months ended December 31, 2019 as a result of a measurement period adjustment.

[0001564590-20-006425:notes:247]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment for the years ended December 31, 2019, 2018 and 2017, there were no events or circumstances that occurred that would more likely than not reduce the fair value of goodwill below its carrying value.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-20-006425:notes:248]
Note 11 – Intangible Assets

[0001564590-20-006425:notes:249]
As of December 31, 2019 and 2018, our intangible assets were comprised of the following:

[0001564590-20-006425:notes:250]
|  |  | 2019 |  |  | 2018 |  |
| (In thousands) |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 22,356 |  |  | $ | (7,233 | ) |  | $ | 15,123 |  |  | $ | 22,455 |  |  | $ | (5,380 | ) |  | $ | 17,075 |  |
| Developed technology |  |  | 10,170 |  |  |  | (3,379 | ) |  |  | 6,791 |  |  |  | 12,801 |  |  |  | (4,867 | ) |  |  | 7,934 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (1,174 | ) |  |  | 4,726 |  |  |  | 5,900 |  |  |  | (520 | ) |  |  | 5,380 |  |
| Supplier relationships |  |  | 2,800 |  |  |  | (2,508 | ) |  |  | 292 |  |  |  | 2,800 |  |  |  | (1,108 | ) |  |  | 1,692 |  |
| Intellectual property |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 930 |  |  |  | (930 | ) |  |  | — |  |
| Licensing agreements |  |  | 560 |  |  |  | (79 | ) |  |  | 481 |  |  |  | 560 |  |  |  | (5 | ) |  |  | 555 |  |
| Patents |  |  | 500 |  |  |  | (226 | ) |  |  | 274 |  |  |  | 500 |  |  |  | (157 | ) |  |  | 343 |  |
| Trade names |  |  | 310 |  |  |  | (176 | ) |  |  | 134 |  |  |  | 310 |  |  |  | (106 | ) |  |  | 204 |  |
| Non-compete |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 200 |  |  |  | (200 | ) |  |  | — |  |
| Total |  | $ | 42,596 |  |  | $ | (14,775 | ) |  | $ | 27,821 |  |  | $ | 46,456 |  |  | $ | (13,273 | ) |  | $ | 33,183 |  |

[0001564590-20-006425:notes:251]
Amortization expense was $5.3 million, $2.3 million and $2.9 million for the years ended December 31, 2019, 2018 and 2017, respectively.

[0001564590-20-006425:notes:252]
As of December 31, 2019, the estimated future amortization expense of intangible assets is as follows:

[0001564590-20-006425:notes:253]
| (In thousands) |  | Amount |  |
| 2020 |  | $ | 4,444 |  |
| 2021 |  |  | 4,095 |  |
| 2022 |  |  | 3,471 |  |
| 2023 |  |  | 3,320 |  |
| 2024 |  |  | 3,226 |  |
| Thereafter |  |  | 9,265 |  |
| Total |  | $ | 27,821 |  |


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001564590-20-006425:notes:254]
Note 12 – Alabama State Industrial Development Authority Financing and Economic Incentives

[0001564590-20-006425:notes:255]
In conjunction with the 1995 expansion of our Huntsville, Alabama facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (“the Authority”). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds (the “Taxable Revenue Bonds”) and loaned the proceeds from the sale of the Taxable Revenue Bonds to ADTRAN. Further advances on the Taxable Revenue Bonds were made by the Authority, bringing the total amount outstanding to $50.0 million. The Taxable Revenue Bonds bore interest, payable monthly with an interest rate of 2% per annum. The Taxable Revenue Bond’s outstanding aggregate principal amount of $24.6 million matured on January 1, 2020 and was repaid in full on January 2, 2020. The fair value of the bond as of December 31, 2019 was $24.6 million. We are required to make payments to the Authority in amounts necessary to pay the interest on the Taxable Revenue Bonds. Included in short-term investments as of December 31, 2019 is $25.6 million which is invested in a certificate of deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the balance of the Taxable Revenue Bonds with the collateral deposit in order to reduce the balance of the indebtedness.

[0001564590-20-006425:notes:256]
In conjunction with this program, we were eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we were required to remit to the state for those employment positions that qualify under the program. We realized economic incentives related to payroll withholdings totaling $1.2 million, $1.4 million and $1.5 million for the years ended December 31, 2019, 2018 and 2017, respectively. This program concluded on January 2, 2020 following the maturity of the Taxable Revenue Bonds. No additional benefits will be received in future periods.

[0001564590-20-006425:notes:257]
We made principal payments of $1.0 million and $1.1 million for the years ended December 31, 2019 and 2018. No additional principal payments will be made in future periods.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-006425:notes:258]
Note 13 – Income Taxes

[0001564590-20-006425:notes:259]
A summary of the components of the expense (benefit) for income taxes for the years ended December 31, 2019, 2018 and 2017 is as follows:

[0001564590-20-006425:notes:260]
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (518 | ) |  | $ | (8,001 | ) |  | $ | 466 |  |
| State |  |  | (1,065 | ) |  |  | (476 | ) |  |  | (150 | ) |
| International |  |  | (282 | ) |  |  | 11,705 |  |  |  | 6,458 |  |
| Total Current |  |  | (1,865 | ) |  |  | 3,228 |  |  |  | 6,774 |  |
| Deferred |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 24,801 |  |  |  | (14,448 | ) |  |  | 8,024 |  |
| State |  |  | 5,815 |  |  |  | (3,390 | ) |  |  | 1,882 |  |
| International |  |  | (546 | ) |  |  | 581 |  |  |  | 4,167 |  |
| Total Deferred |  |  | 30,070 |  |  |  | (17,257 | ) |  |  | 14,073 |  |
| Total Income Tax Expense (Benefit) |  | $ | 28,205 |  |  | $ | (14,029 | ) |  | $ | 20,847 |  |

[0001564590-20-006425:notes:261]
Our effective income tax rate differs from the federal statutory rate due to the following:

[0001564590-20-006425:notes:262]
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Tax provision computed at the federal statutory rate |  |  | 21.00 | % |  |  | 21.00 | % |  |  | 35.00 | % |
| State income tax provision, net of federal benefit |  |  | 6.97 |  |  |  | 14.53 |  |  |  | 2.17 |  |
| Federal research credits |  |  | 15.53 |  |  |  | 14.23 |  |  |  | (11.88 | ) |
| Foreign taxes |  |  | 2.83 |  |  |  | (11.45 | ) |  |  | (2.27 | ) |
| Tax-exempt income |  |  | 0.49 |  |  |  | 0.45 |  |  |  | (0.75 | ) |
| State tax incentives |  |  | 3.85 |  |  |  | 3.15 |  |  |  | (2.71 | ) |
| Change in valuation allowance |  |  | (172.82 | ) |  |  | — |  |  |  | — |  |
| Foreign tax credits |  |  | 16.69 |  |  |  | — |  |  |  | — |  |
| Stock-based compensation |  |  | (6.01 | ) |  |  | (2.87 | ) |  |  | 1.43 |  |
| Domestic production activity deduction |  |  | — |  |  |  | — |  |  |  | (1.13 | ) |
| Bargain purchase |  |  | — |  |  |  | 8.82 |  |  |  | — |  |
| Impact of U.S. tax reform |  |  | — |  |  |  | 12.00 |  |  |  | 26.70 |  |
| Global intangible low-taxed income ("GILTI") |  |  | (1.87 | ) |  |  | (17.48 | ) |  |  | — |  |
| Other, net |  |  | (0.49 | ) |  |  | (0.34 | ) |  |  | 0.09 |  |
| Effective Tax Rate |  |  | (113.83 | )% |  |  | 42.04 | % |  |  | 46.65 | % |

[0001564590-20-006425:notes:263]
Income (loss) before expense (benefit) for income taxes for the years ended December 31, 2019, 2018 and 2017 is as follows:

[0001564590-20-006425:notes:264]
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| U.S. entities |  | $ | (29,829 | ) |  | $ | (74,131 | ) |  | $ | 26,552 |  |
| International entities |  |  | 5,052 |  |  |  | 40,760 |  |  |  | 18,135 |  |
| Total |  | $ | (24,777 | ) |  | $ | (33,371 | ) |  | $ | 44,687 |  |

[0001564590-20-006425:notes:265]
Income (loss) before expense (benefit) for income taxes for international entities reflects income (loss) based on statutory transfer pricing agreements. This amount does not correlate to consolidated international revenue, many of which occur from our U.S. entity.

[0001564590-20-006425:notes:266]
Deferred income taxes on the Consolidated Balance Sheets result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The principal components of our current and non-current deferred taxes were as follows:

[0001564590-20-006425:notes:267]
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Deferred tax assets |  |  |  |  |  |  |  |  |
| Inventory |  | $ | 7,144 |  |  | $ | 6,609 |  |
| Accrued expenses |  |  | 2,330 |  |  |  | 2,850 |  |
| Investments |  |  | — |  |  |  | 1,122 |  |
| Deferred compensation |  |  | 5,660 |  |  |  | 4,779 |  |
| Stock-based compensation |  |  | 2,451 |  |  |  | 3,069 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 241 |  |  |  | 326 |  |
| Pensions |  |  | 7,074 |  |  |  | 5,538 |  |
| Foreign losses |  |  | 2,925 |  |  |  | 3,097 |  |
| State losses and credit carry-forwards |  |  | 3,995 |  |  |  | 8,164 |  |
| Federal loss and research carry-forwards |  |  | 12,171 |  |  |  | 17,495 |  |
| Lease liabilities |  |  | 2,496 |  |  |  | — |  |
| Capitalized research and development expenditures |  |  | 22,230 |  |  |  | — |  |
| Valuation allowance |  |  | (48,616 | ) |  |  | (5,816 | ) |
| Total Deferred Tax Assets |  |  | 20,101 |  |  |  | 47,233 |  |
| Deferred tax liabilities |  |  |  |  |  |  |  |  |
| Property, plant and equipment |  |  | (2,815 | ) |  |  | (3,515 | ) |
| Intellectual property |  |  | (5,337 | ) |  |  | (6,531 | ) |
| Right of use lease assets |  |  | (2,496 | ) |  |  | — |  |
| Investments |  |  | (1,892 | ) |  |  | — |  |
| Total Deferred Tax Liabilities |  |  | (12,540 | ) |  |  | (10,046 | ) |
| Net Deferred Tax Assets |  | $ | 7,561 |  |  | $ | 37,187 |  |

[0001564590-20-006425:notes:268]
In December 2017, the Tax Cuts and Jobs Act (“the Act”) was signed into law. As a result of the Act, we recognized an estimated expense of $11.9 million in the fourth quarter of 2017, of which $9.2 million related to the write-down of deferred tax assets and $2.7 million related to tax on unrepatriated foreign earnings. We calculated our best estimate of the impact of the Act in our 2017 year-end income tax provision in accordance with Staff Accounting Bulletin No. 118, which was issued to address the application of U.S. GAAP in situations when a registrant does not have the necessary information available, prepared or analyzed to finalize the accounting for certain income tax effects of the Act. Additional work to complete a more detailed analysis of historical foreign earnings, as well as the full impact relating to the write-down of deferred tax assets, was completed in the third quarter of 2018 and resulted in a tax benefit of $4.0 million for the year ended December 31, 2018.

[0001564590-20-006425:notes:269]
As of December 31, 2019 and 2018, non-current deferred taxes related to our investments and our defined benefit pension plan reflect deferred taxes on the net unrealized gains and losses on available-for-sale investments and deferred taxes on unrealized losses in our pension plan. The net change in non-current deferred taxes associated with these items, which resulted in a deferred tax benefit of $0.4 million and $2.8 million in 2019 and 2018, respectively, was recorded as an adjustment to other comprehensive income (loss), presented in the Consolidated Statements of Comprehensive Income (Loss).

[0001564590-20-006425:notes:270]
The Company continually reviews the adequacy of our valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes. Due to our recent decrease in revenue and profitability for 2019, and all other positive and negative objective evidence considered as part of our analysis, our ability to consider other subjective evidence such as projections for future growth is limited when evaluating whether our deferred tax assets will be realized. As such, the Company was no longer able to conclude that it was more likely than not that our domestic deferred tax assets would be realized and a valuation allowance against our domestic deferred tax assets was established in the third quarter of 2019. The amount of the deferred tax assets considered realizable may be adjusted in future periods in the event that sufficient evidence is present to support a conclusion that it is more likely than not that all or a portion of our domestic deferred tax assets will be realized.

[0001564590-20-006425:notes:271]
As of December 31, 2019, the Company had gross deferred tax assets totaling $56.2 million offset by a valuation allowance totaling $48.6 million. Of the valuation allowance, $42.8 million was established in the current year primarily related to our domestic deferred tax assets. The remaining $5.8 million established in prior periods related to state research and development credit carryforwards and foreign net operating loss and research and development credit carryforwards where we lack sufficient activity to realize those deferred tax assets. The remaining $7.6 million in deferred tax assets that were not offset by a valuation allowance are located in various foreign jurisdictions where the Company believes it is more likely than not we will realize these deferred tax assets.

[0001564590-20-006425:notes:272]
Supplemental balance sheet information related to deferred tax assets is as follows:

[0001564590-20-006425:notes:273]
|  |  | December 31, 2019 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 46,266 |  |  | $ | (46,266 | ) |  | $ | — |  |
| International |  |  | 9,911 |  |  |  | (2,350 | ) |  |  | 7,561 |  |
| Total |  | $ | 56,177 |  |  | $ | (48,616 | ) |  | $ | 7,561 |  |

[0001564590-20-006425:notes:274]
As of December 31, 2019 and 2018, the deferred tax assets for foreign and domestic loss carry-forwards, research and development tax credits, unamortized research and development costs and state credit carry-forwards totaled $41.3 million and $28.8 million, respectively. As of December 31, 2019, $19.1 million of these deferred tax assets will expire at various times between 2020 and 2039. The remaining deferred tax assets will either amortize through 2029 or carryforward indefinitely.

[0001564590-20-006425:notes:275]
As of December 31, 2019 and 2018, respectively, our cash and cash equivalents were $73.8 million and $105.5 million and short-term investments were $33.2 million and $3.2 million, which provided available short-term liquidity of $107.0 million and $108.7 million. Of these amounts, our foreign subsidiaries held cash of $52.3 million and $87.1 million, respectively, representing approximately 48.9% and 80.1% of available short-term liquidity, which is used to fund on-going liquidity needs of these subsidiaries. We intend to permanently reinvest these funds outside the U.S. except to the extent any of these funds can be repatriated without withholding tax and our current business plans do not indicate a need to repatriate to fund domestic operations. However, if all of these funds were repatriated to the U.S. or used for U.S. operations, certain amounts could be subject to tax. Due to the timing and circumstances of repatriation of such earnings, if any, it is not practical to determine the amount of funds subject to unrecognized deferred tax liability.

[0001564590-20-006425:notes:276]
During 2019, 2018 and 2017, no income tax benefit or expense was recorded for stock options exercised as an adjustment to equity.

[0001564590-20-006425:notes:277]
The change in the unrecognized income tax benefits for the years ended December 31, 2019, 2018 and 2017 is reconciled below:

[0001564590-20-006425:notes:278]
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 1,868 |  |  | $ | 2,366 |  |  | $ | 2,226 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | 3 |  |  |  | 465 |  |
| Current year |  |  | 161 |  |  |  | 254 |  |  |  | 285 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | (71 | ) |  |  | — |  |  |  | (14 | ) |
| Expiration of applicable statute of limitations |  |  | (471 | ) |  |  | (755 | ) |  |  | (596 | ) |
| Balance at end of period |  | $ | 1,487 |  |  | $ | 1,868 |  |  | $ | 2,366 |  |

[0001564590-20-006425:notes:279]
As of December 31, 2019, 2018 and 2017, our total liability for unrecognized tax benefits was $1.5 million, $1.9 million and $2.4 million, respectively, of which $1.4 million, $1.7 million and $2.2 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of December 31, 2019, 2018 and 2017, the balances of accrued interest and penalties were $0.5 million, $0.7 million and $0.8 million, respectively.

[0001564590-20-006425:notes:280]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date. We file income tax returns in the U.S. for federal and various state jurisdictions and several foreign jurisdictions. We are not currently under audit by the Internal Revenue Service. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2016.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-20-006425:notes:281]
Note 14 – Employee Benefit Plans

[0001564590-20-006425:notes:282]
Pension Benefit Plan

[0001564590-20-006425:notes:283]
We maintain a defined benefit pension plan covering employees in certain foreign countries.

[0001564590-20-006425:notes:284]
The pension benefit plan obligations and funded status as of December 31, 2019 and 2018, were as follows:

[0001564590-20-006425:notes:285]
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 37,245 |  |  | $ | 34,893 |  |
| Service cost |  |  | 1,471 |  |  |  | 1,193 |  |
| Interest cost |  |  | 634 |  |  |  | 727 |  |
| Actuarial loss - experience |  |  | 453 |  |  |  | 38 |  |
| Actuarial loss - assumptions |  |  | 5,091 |  |  |  | 2,139 |  |
| Benefit payments |  |  | (166 | ) |  |  | (138 | ) |
| Effects of foreign currency exchange rate changes |  |  | (826 | ) |  |  | (1,607 | ) |
| Projected benefit obligation at end of period |  |  | 43,902 |  |  |  | 37,245 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  |  | 24,159 |  |  |  | 26,624 |  |
| Actual gain (loss) on plan assets |  |  | 4,392 |  |  |  | (2,024 | ) |
| Contributions |  |  | — |  |  |  | 688 |  |
| Effects of foreign currency exchange rate changes |  |  | (535 | ) |  |  | (1,129 | ) |
| Fair value of plan assets at end of period |  |  | 28,016 |  |  |  | 24,159 |  |
| Unfunded status at end of period |  | $ | (15,886 | ) |  | $ | (13,086 | ) |

[0001564590-20-006425:notes:286]
The accumulated benefit obligation was $43.9 million and $37.2 million as of December 31, 2019 and 2018, respectively. The increase in the accumulated benefit obligation and the actuarial loss was primarily attributable to a decrease in the discount rate during 2019.

[0001564590-20-006425:notes:287]
The net amounts recognized in the balance sheet for the unfunded pension liability as of December 31, 2019 and 2018 were as follows:

[0001564590-20-006425:notes:288]
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Current liability |  | $ | — |  |  | $ | — |  |
| Pension liability |  |  | 15,886 |  |  |  | 13,086 |  |
| Total |  | $ | 15,886 |  |  | $ | 13,086 |  |

[0001564590-20-006425:notes:289]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Consolidated Statements of Income (Loss). The components of net periodic pension cost and amounts recognized in other comprehensive income (loss) for the years ended December 31, 2019, 2018 and 2017 were as follows:

[0001564590-20-006425:notes:290]
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,471 |  |  | $ | 1,193 |  |  | $ | 1,260 |  |
| Interest cost |  |  | 634 |  |  |  | 727 |  |  |  | 607 |  |
| Expected return on plan assets |  |  | (1,392 | ) |  |  | (1,548 | ) |  |  | (1,267 | ) |
| Amortization of actuarial losses |  |  | 795 |  |  |  | 247 |  |  |  | 309 |  |
| Net periodic benefit cost |  |  | 1,508 |  |  |  | 619 |  |  |  | 909 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | 2,488 |  |  |  | 5,638 |  |  |  | (654 | ) |
| Amortization of actuarial losses |  |  | (771 | ) |  |  | (196 | ) |  |  | (406 | ) |
| Amount recognized in other comprehensive income (loss) |  |  | 1,717 |  |  |  | 5,442 |  |  |  | (1,060 | ) |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) |  | $ | 3,225 |  |  | $ | 6,061 |  |  | $ | (151 | ) |

[0001564590-20-006425:notes:291]
The amounts recognized in accumulated other comprehensive income (loss) as of December 31, 2019 and 2018 were as follows:

[0001564590-20-006425:notes:292]
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Net actuarial loss |  | $ | (12,973 | ) |  | $ | (11,256 | ) |

[0001564590-20-006425:notes:293]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations, and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations.

[0001564590-20-006425:notes:294]
The weighted-average assumptions that were used to determine the net periodic benefit cost for the years ended December 31, 2019, 2018 and 2017 were as follows:

[0001564590-20-006425:notes:295]
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Discount rate |  |  | 1.75 | % |  |  | 2.13 | % |  |  | 1.90 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.00 | % |  |  | 2.00 | % |
| Expected long-term rates of return |  |  | 5.90 | % |  |  | 5.90 | % |  |  | 5.90 | % |

[0001564590-20-006425:notes:296]
The weighted-average assumptions that were used to determine the benefit obligation as of December 31, 2019 and 2018:

[0001564590-20-006425:notes:297]
|  |  | 2019 |  |  | 2018 |  |
| Discount rate |  |  | 1.00 | % |  |  | 1.75 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.00 | % |

[0001564590-20-006425:notes:298]
Actuarial gains and losses are recorded in accumulated other comprehensive income (loss). To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants. We estimate that $0.8 million will be amortized from accumulated other comprehensive income (loss) into net periodic pension cost in 2020 for the net actuarial loss.

[0001564590-20-006425:notes:299]
We do not anticipate making any contributions to the pension plan in 2020.

[0001564590-20-006425:notes:300]
The following pension benefit payments, which reflect expected future service, as appropriate, are expected to be paid to participants:

[0001564590-20-006425:notes:301]
| (In thousands) |  |  |  |  |
| 2020 |  | $ | 515 |  |
| 2021 |  |  | 582 |  |
| 2022 |  |  | 619 |  |
| 2023 |  |  | 706 |  |
| 2024 |  |  | 789 |  |
| Thereafter |  |  | 4,872 |  |
| Total |  | $ | 8,083 |  |

[0001564590-20-006425:notes:302]
|  |  | Fair Value Measurements at December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash and cash equivalents |  | $ | 691 |  |  | $ | 691 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Government bonds |  |  | 6,645 |  |  |  | 6,645 |  |  |  | — |  |  |  | — |  |
| Corporate bonds |  |  | 5,514 |  |  |  | 5,514 |  |  |  | — |  |  |  | — |  |
| Emerging markets bonds |  |  | 531 |  |  |  | 531 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global equity |  |  | 11,071 |  |  |  | 11,071 |  |  |  | — |  |  |  | — |  |
| Emerging markets |  |  | 956 |  |  |  | 956 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 863 |  |  |  | 863 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 312 |  |  |  | 312 |  |  |  | — |  |  |  | — |  |
| Global real estate fund |  |  | 902 |  |  |  | 902 |  |  |  | — |  |  |  | — |  |
| Managed futures fund |  |  | 531 |  |  |  | 531 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 27,325 |  |  |  | 27,325 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 28,016 |  |  | $ | 28,016 |  |  | $ | — |  |  | $ | — |  |

[0001564590-20-006425:notes:303]
|  |  | Fair Value Measurements at December 31, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash and cash equivalents |  | $ | 1,010 |  |  | $ | 1,010 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Government bonds |  |  | 6,268 |  |  |  | 6,268 |  |  |  | — |  |  |  | — |  |
| Corporate bonds |  |  | 4,840 |  |  |  | 4,840 |  |  |  | — |  |  |  | — |  |
| Emerging markets bonds |  |  | 443 |  |  |  | 443 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global equity |  |  | 7,743 |  |  |  | 7,743 |  |  |  | — |  |  |  | — |  |
| Emerging markets |  |  | 1,188 |  |  |  | 1,188 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 815 |  |  |  | 815 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 262 |  |  |  | 262 |  |  |  | — |  |  |  | — |  |
| Global real estate fund |  |  | 926 |  |  |  | 926 |  |  |  | — |  |  |  | — |  |
| Managed futures fund |  |  | 664 |  |  |  | 664 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 23,149 |  |  |  | 23,149 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 24,159 |  |  | $ | 24,159 |  |  | $ | — |  |  | $ | — |  |

[0001564590-20-006425:notes:304]
Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. Central to the policy are target allocation ranges by asset class, which is currently 50% for bond funds, 40% for equity funds and 10% cash, real estate and managed futures. The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies.

[0001564590-20-006425:notes:305]
The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations.

[0001564590-20-006425:notes:306]
401(k) Savings Plan

[0001564590-20-006425:notes:307]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (the “Savings Plan”) for the benefit of our eligible employees. The Savings Plan is intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (the “Code”), and is intended to be a “safe harbor” 401(k) plan under Code Section 401(k)(12). The Savings Plan allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plan also requires us to contribute a “safe harbor” amount each year. We match up to 4% of employee contributions (100% of an employee’s first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s one-year anniversary date. In calculating our matching contribution, we only use compensation up to the statutory maximum under the Code ($280,000 for 2019). All matching contributions under the Savings Plan vest immediately. Employer contribution expense and plan administration costs for the Savings Plan amounted to approximately $4.4 million, $4.4 million and $4.6 million in 2019, 2018 and 2017, respectively.

[0001564590-20-006425:notes:308]
Deferred Compensation Plans

[0001564590-20-006425:notes:309]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors.

[0001564590-20-006425:notes:310]
For our executive management employees, the ADTRAN, Inc. Deferred Compensation Program for Employees is offered as a supplement to our tax-qualified 401(k) plan and is available to certain executive management employees who have been designated by our Board of Directors. This deferred compensation plan allows participants to defer all or a portion of certain specified bonuses and up to 25% of remaining cash compensation and permits us to make matching contributions on a discretionary basis without the limitations that apply to the 401(k) plan. To date, we have not made any matching contributions under this plan. We also maintain the ADTRAN, Inc. Equity Deferral Program for Employees. Under this plan, participants may elect to defer all or a portion of their vested PSUs and RSUs to the plan. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the participant.

[0001564590-20-006425:notes:311]
For our Board of Directors, we maintain the ADTRAN, Inc. Deferred Compensation Program for Directors. This program allows our Board of Directors to defer all or a portion of monetary remuneration paid to the Director, including, but not limited to, meeting fees and annual retainers. We also maintain the ADTRAN, Inc. Equity Deferral Program for Directors. Under this plan, participants may elect to defer all or a portion of their vested restricted stock awards. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the director.

[0001564590-20-006425:notes:312]
We have set aside the plan assets for all plans in a rabbi trust (the “Trust”) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant and the participant’s bookkeeping account is credited with the earnings and losses attributable to those investments. Benefits are scheduled to be distributed six months after termination of employment in a single lump sum payment or annual installments paid over a three or ten-year term based on the participant’s election. Distributions will be made on a pro-rata basis from each of the hypothetical investments of the participant’s account in cash. Any whole shares of ADTRAN, Inc. common stock that are distributed will be distributed in-kind.

[0001564590-20-006425:notes:313]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging from equities to money market instruments. These mutual funds are publicly quoted and reported at fair value. The fair value of the assets held by the Trust and the amounts payable to the plan participants as of December 31, 2019 and 2018 were as follows:

[0001564590-20-006425:notes:314]
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |  |  |
| Long-term investments |  | $ | 21,698 |  |  | $ | 18,256 |  |
| Total Fair Value of Plan Assets |  | $ | 21,698 |  |  | $ | 18,256 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |  |  |
| Deferred compensation liability |  | $ | 21,698 |  |  | $ | 18,256 |  |
| Total Amounts Payable to Plan Participants |  | $ | 21,698 |  |  | $ | 18,256 |  |

[0001564590-20-006425:notes:315]
Interest and dividend income of the Trust are included in interest and dividend income in the accompanying 2019, 2018 and 2017 Consolidated Statements of Income (Loss). Changes in the fair value of the plan assets held by the Trust have been included in other income (expense) in the accompanying 2019, 2018 and 2017 Consolidated Statements of Income (Loss). Changes in the fair value of the deferred compensation liability are included as selling, general and administrative expense in the accompanying 2019, 2018 and 2017 Consolidated Statements of Income (Loss). Based on the changes in the total fair value of the Trust’s assets, we recorded deferred compensation income (expense) in 2019, 2018 and 2017 of $3.6 million, $(2.1) million and $(2.6) million, respectively.

[0001564590-20-006425:notes:316]
Retiree Medical Coverage

[0001564590-20-006425:notes:317]
We provided medical, dental and prescription drug coverage to two spouses of retired former officers on the same terms as provided to our active officers for up to 30 years. As of December 31, 2019 and 2018, this liability totaled $0.1 million.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-006425:notes:318]
Note 15 – Segment Information and Major Customers

[0001564590-20-006425:notes:319]
Our chief operating decision maker regularly reviews our financial performance based on two reportable segments across our segments– (1) Network Solutions and (2) Services & Support. Network Solutions includes hardware and software products and next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes a portfolio of maintenance, network implementation and solutions integration services, which include hosted cloud services and subscription services.

[0001564590-20-006425:notes:320]
We evaluate the performance of our segments based on gross profit. Selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense) and income tax (expense) benefit are reported on a company-wide, functional basis only. There are no inter-segment revenues.

[0001564590-20-006425:notes:321]
The following table presents information about the reported sales and gross profit of our reportable segments for each of the years ended December 31, 2019, 2018 and 2017. Asset information by reportable segment is not reported, since we do not produce such information internally.

[0001564590-20-006425:notes:322]
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
|  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 455,226 |  |  | $ | 191,549 |  |  | $ | 458,232 |  |  | $ | 179,303 |  |  | $ | 540,396 |  |  | $ | 260,833 |  |
| Services & Support |  |  | 74,835 |  |  |  | 27,618 |  |  |  | 71,045 |  |  |  | 24,262 |  |  |  | 126,504 |  |  |  | 42,802 |  |
| Total |  | $ | 530,061 |  |  | $ | 219,167 |  |  | $ | 529,277 |  |  | $ | 203,565 |  |  | $ | 666,900 |  |  | $ | 303,635 |  |

[0001564590-20-006425:notes:323]
Sales by Category

[0001564590-20-006425:notes:324]
In addition to the above reporting segments, we also report revenue for the following three categories – (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products.

[0001564590-20-006425:notes:325]
Additional Information

[0001564590-20-006425:notes:326]
The following table presents sales information by geographic area for the years ended December 31, 2019, 2018 and 2017:

[0001564590-20-006425:notes:327]
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| United States |  | $ | 300,853 |  |  | $ | 288,843 |  |  | $ | 508,178 |  |
| Mexico |  |  | 90,795 |  |  |  | 12,186 |  |  |  | 2,246 |  |
| Germany |  |  | 78,062 |  |  |  | 167,251 |  |  |  | 119,502 |  |
| Other international |  |  | 60,351 |  |  |  | 60,997 |  |  |  | 36,974 |  |
| Total |  | $ | 530,061 |  |  | $ | 529,277 |  |  | $ | 666,900 |  |

[0001564590-20-006425:notes:328]
Customers comprising more than 10% of revenue can change from year to year. Single customers comprising more than 10% of our revenue in 2019 included three customers at 19%, 17% and 13%. Single customers comprising more than 10% of our revenue in 2018 included two customers at 27% and 17%. Single customers comprising more than 10% of our revenue in 2017 included two customers at 40% and 16%. Other than those with more than 10% of revenues disclosed above, and excluding distributors, our next five largest customers can change, and has historically changed, from year-to-year. These combined customers represented 15%, 18% and 15% of total revenue in 2019, 2018 and 2017, respectively.

[0001564590-20-006425:notes:329]
As of December 31, 2019, property, plant and equipment, net totaled $73.7 million, which included $69.9 million held in the U.S. and $3.9 million held outside the U.S. As of December 31, 2018, property, plant and equipment, net totaled $80.6 million, which included $77.3 million held in the U.S. and $3.3 million held outside the U.S. Property, plant and equipment, net is reported on a company-wide, functional basis only.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-006425:notes:330]
Note 16 – Commitments and Contingencies

[0001564590-20-006425:notes:331]
Securities Class Action Lawsuit

[0001564590-20-006425:notes:332]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and shipments to a Latin American customer.  Investors in ADTRAN securities had until December 16, 2019 to move the court to serve as lead plaintiff in this action.

[0001564590-20-006425:notes:333]
On December 16, 2019, two purported investors in ADTRAN securities filed motions seeking to be appointed lead plaintiff in the case. On January 6, 2020, the United States District Court for the Southern District of New York granted Defendants’ unopposed request to transfer the case to the United States District Court for the Northern District of Alabama, where the case is now pending as Burbridge v. ADTRAN, Inc. et al., Docket No. 5:20-cv-00050-LCB. On January 27, 2020, the two prospective lead plaintiff movants filed a stipulation among plaintiffs seeking to be appointed as co-lead plaintiffs in the case.

[0001564590-20-006425:notes:334]
We disagree with the claims made in the complaint and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-20-006425:notes:335]
Other Legal Matters

[0001564590-20-006425:notes:336]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001564590-20-006425:notes:337]
Investment Commitment

[0001564590-20-006425:notes:338]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied to these commitments as of December 31, 2019.

[0001564590-20-006425:notes:339]
Performance Bonds

[0001564590-20-006425:notes:340]
Certain contracts, customers and/or jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2019, we had commitments related to these bonds totaling $9.3 million which expire at various dates through August 2024. As of December 31, 2018, we had commitments related to these bonds totaling $6.5 million. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default in our under each contract, the probability of which we believe is remote.


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-006425:notes:341]
Note 17 – Earnings (Loss) per Share

[0001564590-20-006425:notes:342]
A summary of the calculation of basic and diluted earnings (loss) per share for the years ended December 31, 2019, 2018 and 2017 is as follows:

[0001564590-20-006425:notes:343]
| (In thousands, except for per share amounts) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income (Loss) |  | $ | (52,982 | ) |  | $ | (19,342 | ) |  | $ | 23,840 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,836 |  |  |  | 47,880 |  |  |  | 48,153 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |  |  | 406 |  |
| Restricted stock and restricted stock units |  |  | — |  |  |  | — |  |  |  | 140 |  |
| Weighted average number of shares – diluted |  |  | 47,836 |  |  |  | 47,880 |  |  |  | 48,699 |  |
| Earnings (loss) per share – basic |  | $ | (1.11 | ) |  | $ | (0.40 | ) |  | $ | 0.50 |  |
| Earnings (loss) per share – diluted |  | $ | (1.11 | ) |  | $ | (0.40 | ) |  | $ | 0.49 |  |

[0001564590-20-006425:notes:344]
For each of the years ended December 31, 2019 and 2018, 5.7 million and 2.5 million, respectively, shares of unvested stock options, PSUs, RSUs and restricted stock were excluded from the calculation of diluted EPS due to their anti-dilutive effect.

[0001564590-20-006425:notes:345]
For the year ended December 31, 2017, 3.2 million stock options were outstanding but were not included in the computation of diluted earnings (loss) per share because the options’ exercise prices were greater than the average market price of the common shares, therefore making them anti-dilutive under the treasury stock method.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-006425:notes:346]
Note 18 – Restructuring

[0001564590-20-006425:notes:347]
During the second half of 2019, the Company implemented a restructuring plan to realign its expense structure with the reduction in revenue experienced in recent years and overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, where possible. As part of this restructuring plan, the Company announced plans to reduce its overall operating expenses, both in the U.S and internationally.

[0001564590-20-006425:notes:348]
In February 2019, the Company announced the restructuring of certain of our workforce predominantly in Germany, which included the closure of our office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. We also offered voluntary early retirement to certain other employees, which was announced in March 2019.

[0001564590-20-006425:notes:349]
In January 2018, the Company announced an early retirement incentive program for employees that met certain defined requirements. The cumulative amount incurred during the year ended December 31, 2018 related to this restructuring program was $7.3 million. We did not incur any additional expenses related to this restructuring program during the year ended December 31, 2019.

[0001564590-20-006425:notes:350]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Consolidated Balance Sheets as of December 31, 2019 and 2018, is as follows:

[0001564590-20-006425:notes:351]
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 185 |  |  | $ | 205 |  |
| Plus: Amounts charged to cost and expense |  |  | 6,014 |  |  |  | 7,261 |  |
| Less: Amounts paid |  |  | (4,631 | ) |  |  | (7,281 | ) |
| Balance at end of period |  | $ | 1,568 |  |  | $ | 185 |  |

[0001564590-20-006425:notes:352]
The components of restructuring expense in the Consolidated Statements of Income are for the years ended December 31, 2019, 2018 and 2017:

[0001564590-20-006425:notes:353]
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Selling, general and administrative expenses |  | $ | 2,360 |  |  | $ | 2,655 |  |  | $ | 152 |  |
| Research and development expenses |  |  | 2,869 |  |  |  | 1,831 |  |  |  | 122 |  |
| Cost of sales |  |  | 785 |  |  |  | 2,775 |  |  |  | — |  |
| Total restructuring expenses |  | $ | 6,014 |  |  | $ | 7,261 |  |  | $ | 274 |  |

[0001564590-20-006425:notes:354]
The following table represents the components of restructuring expense by geographic area for the years ended December 31, 2019, 2018 and 2017:

[0001564590-20-006425:notes:355]
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| United States |  | $ | 3,336 |  |  | $ | 7,120 |  |  | $ | 274 |  |
| International |  |  | 2,678 |  |  |  | 141 |  |  |  | — |  |
| Total restructuring expenses |  | $ | 6,014 |  |  | $ | 7,261 |  |  | $ | 274 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001564590-20-006425:notes:356]
Note 19 – Summarized Quarterly Financial Data (Unaudited)

[0001564590-20-006425:notes:357]
The following table presents unaudited quarterly operating results for each of our last eight fiscal quarters. This information has been prepared on a basis consistent with our audited financial statements and includes all adjustments, consisting only of normal recurring adjustments, considered necessary for a fair presentation of the data.

[0001564590-20-006425:notes:358]
Unaudited Quarterly Operating Results

[0001564590-20-006425:notes:359]
|  |  | Three Months Ended |  |
| (In thousands, except for per share amounts) |  | March 31, 2019 |  |  | June 30, 2019 |  |  | September 30, 2019 |  |  | December 31, 2019 |  |
| Net sales |  | $ | 143,791 |  |  | $ | 156,391 |  |  | $ | 114,092 |  |  | $ | 115,787 |  |
| Gross profit |  | $ | 60,612 |  |  | $ | 65,015 |  |  | $ | 46,331 |  |  | $ | 47,209 |  |
| Operating income (loss) |  | $ | (6,167 | ) |  | $ | 562 |  |  | $ | (20,288 | ) |  | $ | (14,070 | ) |
| Net income (loss) |  | $ | 770 |  |  | $ | 3,995 |  |  | $ | (46,123 | ) |  | $ | (11,624 | ) |
| Earnings (loss) per common share - basic |  | $ | 0.02 |  |  | $ | 0.08 |  |  | $ | (0.96 | ) |  | $ | (0.25 | ) |
| Earnings (loss) per common share - diluted |  | $ | 0.02 |  | (1) | $ | 0.08 |  | (1) | $ | (0.96 | ) |  | $ | (0.25 | ) |

[0001564590-20-006425:notes:360]
|  |  | Three Months Ended |  |
| (In thousands, except for per share amounts) |  | March 31, 2018 |  |  | June 30, 2018 |  |  | September 30, 2018 |  |  | December 31, 2018 |  |
| Net sales |  | $ | 120,806 |  |  | $ | 128,048 |  |  | $ | 140,335 |  |  | $ | 140,088 |  |
| Gross profit |  | $ | 39,733 |  |  | $ | 49,996 |  |  | $ | 58,448 |  |  | $ | 55,388 |  |
| Operating income (loss) |  | $ | (26,647 | ) |  | $ | (12,813 | ) |  | $ | (2,179 | ) |  | $ | (3,783 | ) |
| Net income (loss) |  | $ | (10,814 | ) |  | $ | (7,670 | ) |  | $ | 7,589 |  |  | $ | (8,447 | ) |
| Earnings (loss) per common share - basic |  | $ | (0.22 | ) |  | $ | (0.16 | ) |  | $ | 0.16 |  |  | $ | (0.18 | ) |
| Earnings (loss) per common share - diluted |  | $ | (0.22 | ) |  | $ | (0.16 | ) |  | $ | 0.16 |  | (1) | $ | (0.18 | ) |

[0001564590-20-006425:notes:361]
|  | (1) | Assumes exercise of dilutive securities calculated under the treasury stock method. |


## us-gaap:SubsequentEventsTextBlock

[0001564590-20-006425:notes:362]
Note 20 – Subsequent Events

[0001564590-20-006425:notes:363]
On January 2, 2020, we paid off the outstanding balance of $24.6 million of the Taxable Revenue Bonds upon their maturity. We used a restricted certificate of deposit which was held as collateral to repay the outstanding balance.

[0001564590-20-006425:notes:364]
On February 5, 2020, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on February 20, 2020. The quarterly dividend will be paid on March 5, 2019 payment in the aggregate amount of approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001564590-20-006425:notes:365]
SCHEDULE II

[0001564590-20-006425:notes:366]
VALUATION AND QUALIFYING ACCOUNTS

[0001564590-20-006425:notes:367]
| (In thousands) |  | Balance at Beginning of Period |  |  | Charged to Costs & Expenses |  |  | Deductions |  |  | Balance at End of Period |  |
| Year ended December 31, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 128 |  |  |  | 38 |  |  |  | 128 |  |  | $ | 38 |  |
| Inventory Reserve |  | $ | 30,009 |  |  |  | 5,893 |  |  |  | 1,740 |  |  | $ | 34,162 |  |
| Warranty Liability |  | $ | 8,623 |  |  |  | 4,569 |  |  |  | 4,798 |  |  | $ | 8,394 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 5,816 |  |  |  | 43,560 |  |  |  | 760 |  |  | $ | 48,616 |  |
| Year ended December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | — |  |  |  | 128 |  |  |  | — |  |  | $ | 128 |  |
| Inventory Reserve |  | $ | 23,355 |  |  |  | 7,006 |  |  |  | 352 |  |  | $ | 30,009 |  |
| Warranty Liability |  | $ | 9,724 |  |  |  | 7,392 |  |  |  | 8,493 |  |  | $ | 8,623 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 6,006 |  |  |  | — |  |  |  | 190 |  |  | $ | 5,816 |  |
| Year ended December 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | — |  |  |  | — |  |  |  | — |  |  | $ | — |  |
| Inventory Reserve |  | $ | 25,249 |  |  |  | 6,406 |  |  |  | 8,300 |  |  | $ | 23,355 |  |
| Warranty Liability |  | $ | 8,548 |  |  |  | 6,951 |  |  |  | 5,775 |  |  | $ | 9,724 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 6,149 |  |  |  | 18 |  |  |  | 161 |  |  | $ | 6,006 |  |
