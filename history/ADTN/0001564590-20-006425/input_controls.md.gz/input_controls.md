# ADTN 10-K controls and the auditor's report


## auditors_report

[0001564590-20-006425:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001564590-20-006425:auditors_report:2]
To the Board of Directors and Stockholders of ADTRAN, Inc.

[0001564590-20-006425:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001564590-20-006425:auditors_report:4]
We have audited the accompanying consolidated balance sheets of ADTRAN, Inc. and its subsidiaries (the “Company”) as of December 31, 2019 and 2018, and the related consolidated statements of income (loss), comprehensive income (loss), changes in stockholders’ equity and cash flows for each of the three years in the period ended December 31, 2019, including the related notes and financial statement schedule listed in the accompanying index (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of December 31, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001564590-20-006425:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2019 and 2018, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2019 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company did not maintain, in all material respects, effective internal control over financial reporting as of December 31, 2019, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO because a material weakness in internal control over financial reporting existed as of that date related to  ineffective controls over the Company’s determination of its estimated reserve for excess and obsolete inventory.

[0001564590-20-006425:auditors_report:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weakness referred to above is described in Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. We considered this material weakness in determining the nature, timing, and extent of audit tests applied in our audit of the 2019 consolidated financial statements, and our opinion regarding the effectiveness of the Company’s internal control over financial reporting does not affect our opinion on those consolidated financial statements.

[0001564590-20-006425:auditors_report:7]
Basis for Opinions

[0001564590-20-006425:auditors_report:8]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in management's report referred to above. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-20-006425:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001564590-20-006425:auditors_report:10]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001564590-20-006425:auditors_report:11]
51

[0001564590-20-006425:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001564590-20-006425:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001564590-20-006425:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001564590-20-006425:auditors_report:15]
Critical Audit Matters

[0001564590-20-006425:auditors_report:16]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001564590-20-006425:auditors_report:17]
Excess and Obsolete Inventory Reserve

[0001564590-20-006425:auditors_report:18]
As described in Notes 1 and 7 to the consolidated financial statements, the Company’s consolidated net inventory and inventory reserves as of December 31, 2019 were $98.3 million and $34.1 million, respectively. Management establishes reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age, and market conditions.

[0001564590-20-006425:auditors_report:19]
The principal considerations for our determination that performing procedures relating to the excess and obsolete inventory reserve is a critical audit matter are there was significant judgment by management in estimating the excess and obsolete inventory reserve, which in turn led to a high degree of auditor judgment, subjectivity and effort in performing procedures and evaluating the reasonableness of the significant assumptions used in developing the reserve, including the estimated reserve percentages. As described in the "Opinions on the Financial Statements and Internal Control over Financial Reporting" section, a material weakness was identified as of December 31, 2019 related to ineffective controls over the Company’s determination of its estimated reserve for excess and obsolete inventory.

[0001564590-20-006425:auditors_report:20]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included, among others, testing management’s process for developing the excess and obsolete inventory reserve; evaluating the appropriateness of the approach; testing the completeness and accuracy of underlying data used in the approach, including historical usage and inventory age; and evaluating the reasonableness of the estimated reserve percentages used by management to determine the excess and obsolete inventory reserve. Evaluating the reasonableness of the estimated reserve percentages involved assessing whether they were consistent with the historical data and evidence obtained in other areas of the audit.

[0001564590-20-006425:auditors_report:21]
/s/ PricewaterhouseCoopers LLP

[0001564590-20-006425:auditors_report:22]
Birmingham, Alabama

[0001564590-20-006425:auditors_report:23]
February 25, 2020

[0001564590-20-006425:auditors_report:24]
We have served as the Company’s auditor since 1986.

[0001564590-20-006425:auditors_report:25]
52

[0001564590-20-006425:auditors_report:26]
Financial Statements

[0001564590-20-006425:auditors_report:27]
ADTRAN, INC.


## item_9a

[0001564590-20-006425:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES |

[0001564590-20-006425:item_9a:2]
Evaluation of Disclosure Controls and Procedures.

[0001564590-20-006425:item_9a:3]
We maintain disclosure controls and procedures that are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure. Because of the inherent limitations to the effectiveness of any system of disclosure controls and procedures, no evaluation of disclosure controls and procedures can provide absolute assurance that all control issues, if any, with a company have been prevented or detected on a timely basis. Even disclosure controls and procedures determined to be effective can only provide reasonable assurance that their objectives are achieved.

[0001564590-20-006425:item_9a:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and our Chief Financial Officer, of the effectiveness of our disclosure controls and procedures (as defined in Exchange Act Rule 13a-15(e)) pursuant to Rule 13a-15 of the Exchange Act. Based on that evaluation, our Chief Executive Officer and our Chief Financial Officer concluded that, due to the material weakness in our internal control over financial reporting described below in Management’s Report on Internal Control over Financial Reporting, our disclosure controls and procedures were not effective as of December 31, 2019.

[0001564590-20-006425:item_9a:5]
Despite the existence of the material weakness described below, we believe that the consolidated financial statements included in this report present fairly, in all material respects, our financial position, results of operations and cash flows for the periods presented, in conformity with accounting principles generally accepted in the United States of America.

[0001564590-20-006425:item_9a:6]
Internal Control over Financial Reporting.

[0001564590-20-006425:item_9a:7]
Section 404 of the Sarbanes-Oxley Act of 2002 requires management to include in our Annual Report on Form 10-K a report on management’s assessment of the effectiveness of our internal control over financial reporting, as well as a report from our independent registered public accounting firm on the effectiveness of our internal control over financial reporting. Management’s report on internal control over financial reporting is included below, and the related report from our independent registered public accounting firm is located in Part II, Item 8, “Financial Statements and Supplementary Data,” of this Annual Report on Form 10-K.

[0001564590-20-006425:item_9a:8]
Management’s Report on Internal Control over Financials Reporting

[0001564590-20-006425:item_9a:9]
Management of ADTRAN, Inc. is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934, as amended. ADTRAN’s internal control over financial reporting is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. ADTRAN’s internal control over financial reporting includes those policies and procedures that:

[0001564590-20-006425:item_9a:10]
|  | • | pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of ADTRAN; |

[0001564590-20-006425:item_9a:11]
|  | • | provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of ADTRAN are being made only in accordance with authorizations of management and directors of ADTRAN; and |

[0001564590-20-006425:item_9a:12]
|  | • | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of ADTRAN’s assets that could have a material effect on the financial statements. |

[0001564590-20-006425:item_9a:13]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001564590-20-006425:item_9a:14]
96

[0001564590-20-006425:item_9a:15]
Management assessed the effectiveness of ADTRAN’s internal control over financial reporting as of December 31, 2019. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in Internal Control-Integrated Framework (2013).

[0001564590-20-006425:item_9a:16]
A material weakness is a significant deficiency, or combination of significant deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the Company’s annual or interim financial statements will not be prevented or detected on a timely basis. In its assessment of the effectiveness of internal control over financial reporting as of December 31, 2019, management determined that there was a deficiency in ADTRAN’s internal control over financial reporting that constituted a material weakness. Specifically, management determined that the Company did not design and maintain effective internal control over the valuation of inventory:

[0001564590-20-006425:item_9a:17]
|  | • | Management determined that controls were not effectively designed and maintained over the determination of the estimated reserve for excess and obsolete inventory including the review of significant inputs and assumptions used to determine our excess and obsolete inventory reserve, and to ensure the completeness and accuracy of key reports and related data used in the calculation of this reserve. |

[0001564590-20-006425:item_9a:18]
This material weakness did not result in any material misstatements of the Company’s financial statements or disclosures for any period presented in the accompanying consolidated financial statements. While the above material weakness did not result in a material misstatement of the Company’s consolidated financial statements, the material weakness could result in a misstatement of the Company’s interim or annual consolidated financial statements and disclosures that would result in a material misstatement that would not be prevented or detected.  As a result, management has concluded that the Company did not maintain effective internal control over financial reporting as of December 31, 2019 based on the criteria in Internal Control-Integrated Framework (2013) issued by COSO.

[0001564590-20-006425:item_9a:19]
Remediation of Previously Identified Material Weakness and Continuing Material Weakness.

[0001564590-20-006425:item_9a:20]
The Company has redesigned, enhanced and added controls and procedures to ensure the completeness of our cycle count program and the completeness and accuracy of key reports and related data used to monitor the results of this cycle count program. Key reports and report writing tools have been integrated into our enterprise management system under IT governance to ensure completeness and accuracy of the information. We reconciled all locations under the cycle count program to ensure existence of locations. We performed a full physical inventory count of our raw material warehouse. We verified that all locations were counted at the appropriate frequency to ensure the physical existence of the inventory for accuracy of financial reporting. As a result of these remediation efforts, management has determined that, as of December 31, 2019, our controls related to our cycle count program were effectively designed, documented and maintained, and the material weakness related to these controls no longer existed.

[0001564590-20-006425:item_9a:21]
Additionally, the Company has been working to redesign and implement enhanced controls and procedures related to the review of significant inputs and assumptions used to determine our excess and obsolete inventory reserve, and to ensure the completeness and accuracy of key reports and related data used in the calculation of the excess and obsolete inventory reserve. Key reports and calculations have been redesigned and fully integrated into our enterprise resource planning system to ensure completeness and the accuracy of significant inputs. New controls and procedures have also been established by the Company around the consideration of historical usage, known trends, market conditions, and estimated net realizable value of the inventory. The implementation of these measures is ongoing, and, while we believe that they will ultimately be effective in remediating the material weakness, management has concluded that, as of December 31, 2019, our controls related to our excess and obsolete inventory reserve were not effectively designed and maintained, and the material weakness related to these controls continued to exist.

[0001564590-20-006425:item_9a:22]
The effectiveness of our internal control over financial reporting has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which appears under Part II, Item 8, “Financial Statements and Supplementary Data,” of this Annual Report on Form 10-K.

[0001564590-20-006425:item_9a:23]
Changes in Internal Control over Financial Reporting.

[0001564590-20-006425:item_9a:24]
Except as noted in the preceding paragraphs, there were no changes in our internal control over financial reporting that occurred during the fiscal quarter ended December 31, 2019 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001564590-20-006425:item_9a:25]
97
