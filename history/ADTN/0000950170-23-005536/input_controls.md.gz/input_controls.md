# ADTN 10-K controls and the auditor's report


## auditors_report

[0000950170-23-005536:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000950170-23-005536:auditors_report:2]
To the Board of Directors and Stockholders of ADTRAN Holdings, Inc.

[0000950170-23-005536:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000950170-23-005536:auditors_report:4]
We have audited the accompanying consolidated balance sheets of ADTRAN Holdings, Inc. and its subsidiaries (the “Company”) as of December 31, 2022 and 2021, and the related consolidated statements of (loss) income, of comprehensive (loss) income, of changes in equity and of cash flows for each of the three years in the period ended December 31, 2022, including the related notes and financial statement schedule listed in the accompanying index (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of December 31, 2022, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000950170-23-005536:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2022 and 2021, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2022 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2022, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0000950170-23-005536:auditors_report:6]
Basis for Opinions

[0000950170-23-005536:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000950170-23-005536:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000950170-23-005536:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000950170-23-005536:auditors_report:10]
As described in Management’s Report on Internal Control over Financial Reporting, management has excluded ADVA Optical Networking SE from its assessment of internal control over financial reporting as of December 31, 2022, because it was acquired by the Company in a purchase business combination during 2022.We have also excluded ADVA Optical Networking SE from our audit of internal control over financial reporting. ADVA Optical Networking SE is a subsidiary whose total assets and total revenues excluded from management’s assessment and our audit of internal control over financial reporting represent 41.42% and 35.68%, respectively, of the related consolidated financial statement amounts as of and for the year ended December 31, 2022.

[0000950170-23-005536:auditors_report:11]
74

[0000950170-23-005536:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0000950170-23-005536:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000950170-23-005536:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000950170-23-005536:auditors_report:15]
Critical Audit Matters

[0000950170-23-005536:auditors_report:16]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000950170-23-005536:auditors_report:17]
Acquisition of ADVA Optical Networking SE – Valuation of Developed Technology, Customer Relationships, and Backlog Intangible Assets

[0000950170-23-005536:auditors_report:18]
As described in Note 2 to the consolidated financial statements, the Company completed the acquisition of ADVA Optical Networking SE for total purchase consideration of $578.3 million on July 15, 2022. Assets acquired and liabilities assumed were recognized at their respective fair values as of July 15, 2022, which resulted in the recognition of $403.8 million of identifiable intangible assets. The fair value of the identifiable intangible assets acquired as of the acquisition date primarily consisted of developed technology of $291.9 million, customer relationships of $32.7 million, and backlog of $52.2 million. In determining the fair value, management utilized various methods of the income approach depending on the asset. The estimation of fair value required significant judgment by management related to net cash flows reflecting the risk inherent in each cash flow stream, competitive trends, market comparables and other factors. Inputs were generally determined by taking into account historical data, current and anticipated market conditions, and growth rates. Developed technology and customer relationships were valued using the multi-period excess earnings method. Backlog was valued using the distributor method. Significant assumptions used in the discounted cash flow analysis for (i) developed technology were the revenue growth rates, long-term revenue growth rate, discount rate, earnings before interest, taxes, depreciation, and amortization (EBITDA) margins, obsolescence factors, income tax rate, tax depreciation, and economic depreciation; (ii) customer relationships were earnings before interest and taxes (EBIT) margins, contributory asset charges, and customer attrition rate; and (iii) backlog were EBIT margins, adjusted EBIT margins, and contributory asset charges.

[0000950170-23-005536:auditors_report:19]
The principal considerations for our determination that performing procedures relating to the valuation of the developed technology, customer relationships, and backlog intangible assets acquired in the acquisition of ADVA Optical Networking SE is a critical audit matter are (i) the significant judgment by management when developing the fair value estimates of the identifiable intangible assets acquired; (ii) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s significant assumptions related to the revenue growth rates, long-term revenue growth rate, discount rate, EBITDA margins, obsolescence factors, income tax rate, tax depreciation, and economic depreciation used in the valuation of the developed technology; EBIT margins, contributory asset charges, and customer attrition rate used in the valuation of the customer relationships; and EBIT margins, adjusted EBIT margins, and contributory asset charges used in the valuation of the backlog; and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0000950170-23-005536:auditors_report:20]
75

[0000950170-23-005536:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the acquisition accounting, including controls over the valuation of the identifiable intangible assets acquired. These procedures also included, among others (i) reading the purchase agreement; (ii) testing management’s process for developing the fair value estimates of the developed technology, customer relationships, and backlog intangible assets; (iii) evaluating the appropriateness of the multi-period excess earnings and distributor methods; (iv) testing the completeness and accuracy of underlying data used by management in the valuation methods; and (v) evaluating the reasonableness of significant assumptions used by management related to the revenue growth rates, long-term revenue growth rate, discount rate, EBITDA margins, obsolescence factors, income tax rate, tax depreciation, and economic depreciation used in the valuation of the developed technology; EBIT margins, contributory asset charges, and customer attrition rate used in the valuation of the customer relationships; and EBIT margins, adjusted EBIT margins, and contributory asset charges used in the valuation of the backlog. Evaluating the reasonableness of management’s significant assumptions related to the revenue growth rates, long-term revenue growth rate, EBITDA margins, obsolescence factors, income tax rate, tax depreciation, and economic depreciation related to the developed technology; the EBIT margins, contributory asset charges, and customer attrition rate related to the customer relationships; and EBIT margins, adjusted EBIT margins, and contributory asset charges related to backlog involved considering (i) the past performance of the acquired business; (ii) the consistency with external market and industry data; and (iii) whether these assumptions were consistent with evidence obtained in other areas of the audit. Professionals with specialized skill and knowledge were used to assist in evaluating (i) the appropriateness of the valuation methods used and (ii) the reasonableness of the discount rate significant assumption.

[0000950170-23-005536:auditors_report:22]
/s/ PricewaterhouseCoopers LLP

[0000950170-23-005536:auditors_report:23]
Birmingham, Alabama

[0000950170-23-005536:auditors_report:24]
March 1, 2023

[0000950170-23-005536:auditors_report:25]
We have served as the Company’s auditor since 1986.

[0000950170-23-005536:auditors_report:26]
76

[0000950170-23-005536:auditors_report:27]
Financial Statements

[0000950170-23-005536:auditors_report:28]
ADTRAN Holdings, Inc.


## item_9a

[0000950170-23-005536:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0000950170-23-005536:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000950170-23-005536:item_9a:3]
We maintain disclosure controls and procedures that are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure. Because of the inherent limitations to the effectiveness of any system of disclosure controls and procedures, no evaluation of disclosure controls and procedures can provide absolute assurance that all control issues, if any, with a company have been prevented or detected on a timely basis. Even disclosure controls and procedures determined to be effective can only provide reasonable assurance that their objectives are achieved.

[0000950170-23-005536:item_9a:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and our Chief Financial Officer, of the effectiveness of our disclosure controls and procedures, as such term is defined under Rule 13a-15(e) promulgated under the Exchange Act. Based on that evaluation, which excluded the impact of the acquisition of a controlling equity stake in ADVA discussed below, our Chief Executive Officer and our Chief Financial Officer concluded that our disclosure controls and procedures were effective at the reasonable assurance level as of December 31, 2022.

[0000950170-23-005536:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0000950170-23-005536:item_9a:6]
Management of ADTRAN Holdings, Inc. is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rule 13a-15(f) under the Securities Exchange Act of 1934, as amended. ADTRAN’s internal control over financial reporting is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. ADTRAN’s internal control over financial reporting includes those policies and procedures that:

[0000950170-23-005536:item_9a:7]
•
pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of ADTRAN;

[0000950170-23-005536:item_9a:8]
•
provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of ADTRAN are being made only in accordance with authorizations of management and directors of ADTRAN; and

[0000950170-23-005536:item_9a:9]
•
provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of ADTRAN’s assets that could have a material effect on the financial statements.

[0000950170-23-005536:item_9a:10]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000950170-23-005536:item_9a:11]
Management assessed the effectiveness of ADTRAN’s internal control over financial reporting as of December 31, 2022. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO") in Internal Control-Integrated Framework (2013).

[0000950170-23-005536:item_9a:12]
As permitted by SEC guidance, we currently exclude ADVA in our evaluation of internal control over financial reporting and related disclosure controls and procedures for the first year after the Business Combination. See “Changes in Internal Control over Financial Reporting” for additional discussion.

[0000950170-23-005536:item_9a:13]
Based on our assessment and those criteria, management has concluded that ADTRAN maintained effective internal control over financial reporting as of December 31, 2022.

[0000950170-23-005536:item_9a:14]
The effectiveness of the Company’s internal control over financial reporting as of December 31, 2022 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which appears in Item 8.

[0000950170-23-005536:item_9a:15]
129

[0000950170-23-005536:item_9a:16]
Auditor Attestation Report on Internal Control over Financial Reporting

[0000950170-23-005536:item_9a:17]
The attestation report of our registered public accounting firm on our internal control over financial reporting is included in Part II, Item 8, “Financial Statements and Supplementary Data,” of this report.

[0000950170-23-005536:item_9a:18]
Changes in Internal Control over Financial Reporting.

[0000950170-23-005536:item_9a:19]
On July 15, 2022, the Company acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of such date, as further described in Note 2 of the Notes to the Condensed Consolidated Financial Statements. At December 31, 2022, ADVA’s assets represented approximately 41.4% of our consolidated assets. For the year ended December 31, 2022, ADVA’s revenues represented approximately 35.7% of our consolidated revenues and loss before income taxes represented approximately 43.8% of our consolidated loss before income taxes. As permitted by SEC guidance, we currently exclude ADVA in our evaluation of internal control over financial reporting and related disclosure controls and procedures for the first year after the Business Combination. However, we are in the process of extending our oversight and monitoring processes that support our internal control over financial reporting and disclosure controls and procedures to include ADVA’s operations. There were no other changes in the Company’s internal control over financial reporting that occurred during the most recent fiscal quarter covered by this report that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.

[0000950170-23-005536:item_9a:20]
130
