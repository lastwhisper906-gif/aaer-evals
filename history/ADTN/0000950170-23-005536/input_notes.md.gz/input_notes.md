# ADTN notes — 0000950170-23-005536


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-23-005536:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0000950170-23-005536:notes:2]
Portions of the Proxy Statement for the registrant's 2023 Annual Meeting of Stockholders are incorporated herein by reference in Part III to the extent described in Part III.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-23-005536:notes:3]
Note 1 – Nature of Business

[0000950170-23-005536:notes:4]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, alternative service providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-23-005536:notes:5]
In 2022, following the business combination (the “Business Combination”) with ADVA Optical Networking SE (“ADVA”), which included the Merger, we became the sole owner of and successor to ADTRAN, Inc. and the majority shareholder of ADVA. ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video, and internet communications across any network infrastructure. Its award-winning end-to-end fiber broadband solutions portfolio spans from OLTs to in-home services and intelligent SaaS solutions. ADVA is a global provider of open networking solutions with over 25 years of experience in optical networking, carrier Ethernet access and network synchronization. ADVA has led the industry for over two decades with open and secure networking solutions that carefully balance space, power and cost. Together, we serve customers in a broad range of industries in over 100 countries.

[0000950170-23-005536:notes:6]
Principles of Consolidation

[0000950170-23-005536:notes:7]
The accompanying Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the U.S. (“U.S. GAAP”) and include the financial position, results of operations, comprehensive (loss) income, changes in equity and cash flows of ADTRAN and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000950170-23-005536:notes:8]
Use of Estimates

[0000950170-23-005536:notes:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

[0000950170-23-005536:notes:10]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus), supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of December 31, 2022 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints and inflationary pressures could result in further impacts to the Company's consolidated financial statements in future reporting periods.

[0000950170-23-005536:notes:11]
Correction of Immaterial Misstatements

[0000950170-23-005536:notes:12]
During the first quarter of 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out-of-period adjustment in the three months ended March 31, 2020 and the twelve months ended December 31, 2020, by remeasuring the investment assets to their historical cost basis through the

[0000950170-23-005536:notes:13]
recording of a net investment gain of $1.5 million in the Consolidated Statement of (Loss) Income and then correcting the classification by decreasing the long-term investment balance at its remeasured cost basis of $2.8 million to treasury stock in the Consolidated 2020 Balance Sheet. Management has determined that this misstatement was not material to any of its previously issued financial statements and that correction of the misstatement was not material to the 2020 annual financial results on either a quantitative or qualitative basis.

[0000950170-23-005536:notes:14]
Summary of Significant Accounting Policies

[0000950170-23-005536:notes:15]
Cash and Cash Equivalents

[0000950170-23-005536:notes:16]
Cash and cash equivalents represent demand deposits, money market funds and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. As of December 31, 2022, $100.1 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions and determined the risk of material financial loss due to the exposure of such credit risk to be minimal.

[0000950170-23-005536:notes:17]
Fair Value of Financial Instruments

[0000950170-23-005536:notes:18]
Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models may be applied. Assets and liabilities recorded at fair value in our consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair values.

[0000950170-23-005536:notes:19]
The carrying amounts reported in the Consolidated Balance Sheets for cash and cash equivalents, accounts receivable and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments.

[0000950170-23-005536:notes:20]
The fair value measurements of our derivative instruments are determined using models that maximize the use of the observable market inputs including interest rate curves and both forward and spot prices for currencies, and are classified as Level II under the fair value hierarchy. The fair values of our derivatives are included in Note 12.

[0000950170-23-005536:notes:21]
The estimated fair value of our notes payable, approximates the carrying value and is classified as Level II under the fair value hierarchy. The carrying value of our notes payable is included in Note 14.

[0000950170-23-005536:notes:22]
Investments with contractual maturities beyond one year may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe we have the ability to quickly sell them to the remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. All income generated from these investments is recorded as interest income. We have not recorded any losses relating to variable rate demand notes.

[0000950170-23-005536:notes:23]
Long-term investments is comprised of deferred compensation plan assets, corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. and foreign government bonds, marketable equity securities and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Any changes in fair value are recognized in net investment (loss) gain. Realized gains and losses on sales of debt securities are computed under the specific identification method and are included in other income (expense). See Note 6 for additional information.

[0000950170-23-005536:notes:24]
For financing receivables, the Company does not measure the allowance for credit losses for accrued interest receivables, as the uncollectable accrued interest receivable is written off by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable).

[0000950170-23-005536:notes:25]
Accounts Receivable

[0000950170-23-005536:notes:26]
We record accounts receivable at amortized cost. Prior to establishing payment terms for a new customer, we evaluate the credit risk of the customer. Credit limits and payment terms established for new customers are re-evaluated periodically based on customer collection experience and other financial factors. As of December 31, 2022, single customers comprising more than 10% of our total accounts receivable balance included three customers, which accounted for 33.1% of our total accounts receivable. As of December 31, 2022, these three customers individually accounted for 11.4%, 11.1% and 10.6%, respectively, of our total accounts receivable. As of December 31, 2021, single customers comprising more than 10% of our total accounts receivable balance included three customers, which accounted for 59.9% of our total accounts receivable. As of December 31, 2021, these three customers individually accounted for 35.8%, 12.1% and 12.0%, respectively, of our total accounts receivable.

[0000950170-23-005536:notes:27]
We regularly review the need for an allowance for credit losses related to our outstanding accounts receivable balances using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of

[0000950170-23-005536:notes:28]
relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition or credit rating by geographic location, as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. Based on this assessment, an allowance for credit losses would be recorded if the Company determined that, based on our historical write-offs, which have been immaterial, and such asset specific risks, there was risk in collectability of the full amount of any accounts receivable.

[0000950170-23-005536:notes:29]
Accounts Receivable Factoring

[0000950170-23-005536:notes:30]
The Company has entered into a factoring agreement to sell certain receivables to an unrelated third-party financial institution on a non-recourse basis. These transactions are accounted for in accordance with Accounting Standards Codification ("ASC") Topic 860, Transfers and Servicing, and result in a reduction in accounts receivable because the agreements transfer effective control over and risk related to the receivables to the buyers. Trade accounts receivables balances sold are removed from the Consolidated Balance Sheets and cash received is reflected as cash provided by (used in) operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest expense on the Consolidated Statements of Loss. On each sale date, the financial institution retains from the sale price a default reserve, up to a required balance, which are held by the financial institution in a reserve account and pledged to the Company. The financial institution is entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account is included in other assets on the Consolidated Balance Sheets.

[0000950170-23-005536:notes:31]
Inventory

[0000950170-23-005536:notes:32]
Inventory is carried at the lower of cost and estimated net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory and are updated at least quarterly. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 7 for additional information.

[0000950170-23-005536:notes:33]
Property, Plant and Equipment

[0000950170-23-005536:notes:34]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. We depreciate building and land improvements from five to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years, and computer software from three to five years. Expenditures for repairs and maintenance are charged to expense as incurred. Major improvements that materially prolong the lives of the assets are capitalized. Gains and losses on the disposal of property, plant and equipment are recorded in operating loss. See Note 8 for additional information.

[0000950170-23-005536:notes:35]
Intangible Assets

[0000950170-23-005536:notes:36]
Purchased intangible assets with finite lives are carried at cost less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets. See Note 11 for additional information.

[0000950170-23-005536:notes:37]
Impairment of Long-Lived Assets and Intangibles

[0000950170-23-005536:notes:38]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result the Company recognized impairment charges of $17.4 million during the year ended December 31, 2022 related to capitalized implementation costs for a cloud computing arrangement. The impairment charges were determined based on actual costs incurred. There were no impairment losses for long-lived assets during the years ended December 31, 2021 and 2020, or for intangible assets recognized during the years ended December 31, 2022, 2021 or 2020.

[0000950170-23-005536:notes:39]
Goodwill

[0000950170-23-005536:notes:40]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The carrying value of goodwill is tested for impairment in the fourth quarter of each year or more frequently if events or circumstances indicate it may be impaired. The quantitative goodwill impairment test is performed at the level of the reporting unit. The identification of our reporting units begins at the operating segment level and considers whether components one level below the operating segment levels should be identified as reporting units for purpose of testing goodwill for impairment. For goodwill impairment testing purposes, the Company determined the Company's reporting units are generally the same as its operating segments, which are identified in Note 18 to the Consolidated Financial Statements.

[0000950170-23-005536:notes:41]
Our general policy is to qualitatively assess the carrying value of goodwill each reporting period for events or changes in circumstances that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Related to the Business Combination with ADVA the Company recognized $350.5 million of goodwill upon the merger on July 15, 2022. Therefore, we decided to proceed directly to the quantitative test of goodwill and forego the qualitative assessment. We estimate the fair value of our reporting units based on an income approach, whereby we calculate the fair value of a reporting unit based on the present value of estimated future cash flows. A discounted cash flow analysis requires us to make various judgmental assumptions about future sales, operating margins, growth rates and discount rates, which are based on our budgets, business plans, economic projections, anticipated future cash flows and market participants. We also estimate the fair value of our reporting units based on a peer group analysis, whereby companies in the telecommunications industry or with a comparable product and market structure are used to calculate a fair enterprise value using revenue, EBITDA and debt multiples of trading value. Based on our analysis, management concluded that there was no impairment of goodwill as of December 31, 2022. No impairment charges on goodwill were recognized during the years ended December 31, 2021 and 2020.

[0000950170-23-005536:notes:42]
Other Non-Current Assets

[0000950170-23-005536:notes:43]
Implementation costs incurred for hosting arrangements that are related to service contracts are capitalized and amortized over the term of the arrangement. Capitalized implementation costs totaled $6.2 million and $21.0 million as of December 31, 2022 and 2021, respectively and are included in other non-current assets on the Consolidated Balance Sheets. In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result the Company recognized impairment charges of $16.9 million during the year ended December 31, 2022 related to capitalized implementation costs for a cloud computing arrangement. The impairment charges were determined based on actual costs incurred. During the year ended December 31, 2021 and 2020, no impairment charges were recognized. We depreciate capitalized implementation costs on a straight-line basis over ten years. Amortization expense was $3.9 million and $1.0 million for the years ended December 31, 2022 and 2021, respectively, which is recorded almost entirely in selling, general and administrative expenses in the Consolidated Statements of (Loss) Income. No amortization expense was recognized for the year ended December 31, 2020.

[0000950170-23-005536:notes:44]
Liability for Warranty

[0000950170-23-005536:notes:45]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Our liability for warranty returns totaled $7.2 million and $5.4 million as of December 31, 2022 and 2021, respectively.

[0000950170-23-005536:notes:46]
Pension Benefit Plan Obligations

[0000950170-23-005536:notes:47]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $10.6 million and $11.4 million as of December 31, 2022 and 2021, respectively.

[0000950170-23-005536:notes:48]
Lease Obligations

[0000950170-23-005536:notes:49]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain potential embedded leases. These other contracts are specifically reviewed to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease. Some of our leases include options to renew, with renewal terms of up to five years. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. The exercise of lease renewal options is at our sole discretion. The depreciable life of leased assets and leasehold improvements are limited by the expected lease term. Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. Our lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-23-005536:notes:50]
Stock-Based Compensation

[0000950170-23-005536:notes:51]
We have two stock incentive plans from which stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock are available for grant to employees and directors. Costs related to these awards are recognized over their vesting periods.

[0000950170-23-005536:notes:52]
Stock-based compensation expense recognized for the years ended December 31, 2022, 2021 and 2020 was approximately $28.3 million, $7.5 million, and $6.8 million, respectively. See Note 5 for additional information.

[0000950170-23-005536:notes:53]
Research and Development Costs

[0000950170-23-005536:notes:54]
Research and development costs include compensation for engineers and support personnel, contracted services, depreciation and material costs associated with new product development, enhancement of current products and product cost reductions. We continually evaluate new product opportunities and engage in intensive research for product and software development efforts. Research and development costs totaled $173.8 million, $108.7 million and $113.3 million for the years ended December 31, 2022, 2021 and 2020, respectively.

[0000950170-23-005536:notes:55]
ADVA has arrangements with governmental entities for the purposes of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the year ended December 31, 2022, the Company recognized $1.1 million as a reduction of research and development expense.

[0000950170-23-005536:notes:56]
Income Taxes

[0000950170-23-005536:notes:57]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax basis of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0000950170-23-005536:notes:58]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0000950170-23-005536:notes:59]
Foreign Currency

[0000950170-23-005536:notes:60]
Transactions with customers that are denominated in foreign currencies are recorded using the appropriate exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are remeasured at the balance sheet dates using the closing rates of exchange between those foreign currencies and the functional currency with any transaction gains or losses reported in other income (expense). Our primary exposures to foreign currency exchange rate movements are with our German subsidiary, whose functional currency is the Euro and our Australian subsidiary, whose functional currency is the Australian dollar. Adjustments resulting from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive (loss) income.

[0000950170-23-005536:notes:61]
Revenue

[0000950170-23-005536:notes:62]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. Review of contracts with customers, for both direct customers and distributors, are performed and assessment made regarding principal versus agent considerations to determine primary responsibility for delivery of performance obligation, presumed inventory risk, and discretion in establishing pricing, when applicable. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost is included in cost of revenue. Revenue, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract, if material, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to account for shipping fees as a cost of fulfilling the related contract. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0000950170-23-005536:notes:63]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0000950170-23-005536:notes:64]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware revenue.

[0000950170-23-005536:notes:65]
Hardware and Software Revenue

[0000950170-23-005536:notes:66]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenue from software license sales is recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time products are delivered.

[0000950170-23-005536:notes:67]
Services & Support Segment - Includes a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services to complement our Network Solutions segment.

[0000950170-23-005536:notes:68]
Maintenance Revenue

[0000950170-23-005536:notes:69]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenue, when applicable, are recorded in current and non-current unearned revenue.

[0000950170-23-005536:notes:70]
Network Implementation Revenue

[0000950170-23-005536:notes:71]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0000950170-23-005536:notes:72]
See Notes 4 and 18 for additional information on reportable segments.

[0000950170-23-005536:notes:73]
Unearned Revenue

[0000950170-23-005536:notes:74]
Unearned revenue primarily represents customer billings on maintenance service programs and unearned revenue related to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one month to five years. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. In addition, we provide software maintenance and a variety of hardware maintenance services to customers under contracts with terms up to ten years. When we defer revenue related to multiple performance obligations where we still have contractual obligations, we also defer the related costs. Current deferred costs are included in prepaid expenses and other current assets on the accompanying Consolidated Balance Sheets and totaled $1.5 million and $0.7 million as of December 31, 2022 and 2021, respectively. Non-current deferred costs are included in other non-current assets on the accompanying Consolidated Balance Sheets and less than $0.1 million as of December 31, 2022 and $0.1 million as of December 31, 2021.

[0000950170-23-005536:notes:75]
(Loss) Earnings per Share

[0000950170-23-005536:notes:76]
(Loss) earnings per common share and (loss) earnings per common share assuming dilution are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year. See Note 22 for additional information.

[0000950170-23-005536:notes:77]
Business Combinations

[0000950170-23-005536:notes:78]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition subject to purchase accounting adjustments. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets and liabilities assumed or acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired and liabilities assumed exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying Consolidated Statements of (Loss) Income since their dates of acquisition. Costs incurred to complete the Business Combination, such as legal, accounting or other professional fees are charged to selling, general and administrative expenses as incurred.

[0000950170-23-005536:notes:79]
Non-Controlling Interest

[0000950170-23-005536:notes:80]
Non-controlling interest represents the equity interest in ADVA held by holders other than the Company. On July 15, 2022, upon the close of the Business Combination, the ADVA stockholders’ equity ownership percentage in ADVA was approximately 36%. The Company has consolidated the financial position and results of operations of ADVA and reflected the proportionate interest held by the ADVA stockholders as non-controlling interest in the accompanying condensed consolidated balance sheet. As of December 31, 2022, the ADVA stockholders’ equity ownership percentage in ADVA was approximately 34.7%.

[0000950170-23-005536:notes:81]
Recent Accounting Pronouncements Not Yet Adopted

[0000950170-23-005536:notes:82]
There are currently no recently issued accounting pronouncements not yet adopted which would have a material effect on the Condensed Consolidated Financial Statements.

[0000950170-23-005536:notes:83]
Recently Adopted Accounting Pronouncements

[0000950170-23-005536:notes:84]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. The Company early adopted ASU 2021-08 on July 1, 2022 and the standard was applied retrospectively beginning with January 1, 2022.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-005536:notes:85]
Note 2 – Business Combination Agreement

[0000950170-23-005536:notes:86]
ADVA Optical Networking SE

[0000950170-23-005536:notes:87]
On August 30, 2021, ADTRAN and ADVA, entered into a Business Combination Agreement, pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, ADTRAN Holdings, Inc. (formerly

[0000950170-23-005536:notes:88]
known as Acorn HoldCo, Inc.) which was formed as a wholly-owned subsidiary of ADTRAN in order to consummate the transactions under the Business Combination Agreement. Under the terms of the Business Combination Agreement, on July 8, 2022, Acorn MergeCo, Inc, a Delaware corporation and wholly-owned direct subsidiary of the Company, merged with and into ADTRAN Holdings, Inc. leaving ADTRAN Holdings, Inc. surviving the Business Combination as a wholly-owned direct subsidiary of the Company.

[0000950170-23-005536:notes:89]
Additionally, pursuant to the Business Combination Agreement, on July 15, 2022, the Company made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of Company Common Stock, par value $0.01 per share of the Company. The Exchange Offer was settled on Exchange Offer Settlement Date, on which date the Company acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of Company Common Stock. Additionally, pursuant to the Business Combination Agreement, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN, Inc. The fair value of the ADVA stock options assumed by ADTRAN, Inc. was $12.8 million, estimated using the Monte Carlo method.

[0000950170-23-005536:notes:90]
ADTRAN, Inc. and ADVA became subsidiaries of ADTRAN Holdings, Inc. as a result of the Business Combination. ADTRAN was determined to be the accounting acquirer of ADVA based on ADTRAN shareholders’ majority equity stake in the combined company, the composition of the board of directors and senior management of the combined company, among other factors. The Business Combination of ADVA has been accounted for using the acquisition method of accounting as per the provisions of Accounting Standards Codification 805, “Business Combinations” (“ASC 805”). The Business Combination Agreement used a fixed exchange ratio of Company Common Stock for ADVA shares of common stock, which resulted in a 36% equity stake for ADVA stockholders and 64% equity stake for ADTRAN stockholders in the post-closing combined company (calculated on a fully diluted basis and utilizing the tender of 65.43% of ADVA’s current issued and outstanding share capital). Therefore, ADTRAN shareholders continue to hold a majority interest in the combined company after the Business Combination was completed. Additionally, the Board of Directors is comprised of six members from ADTRAN and three members from ADVA; the current ADTRAN chief executive officer acts as the chairman of the Board of Directors and the former ADVA chief executive officer as the vice chairman of the Board of Directors. Additionally, the current ADTRAN chief executive officer and ADTRAN chief financial officer hold these positions within the combined company. Based upon these and other considerations as outlined in ASC 805, ADTRAN represents the accounting acquirer.

[0000950170-23-005536:notes:91]
The following table summarizes the purchase price for the ADVA business combination:

[0000950170-23-005536:notes:92]
| (In thousands, except shares, share price and exchange ratio) |  | Purchase Price |  |
| ADVA shares exchanged |  |  | 33,957,538 |  |
| Exchange ratio |  |  | 0.8244 |  |
| ADTRAN Holdings, Inc. shares issued |  |  | 27,994,595 |  |
| ADTRAN Holdings, Inc. share price on July 15, 2022 |  | $ | 20.20 |  |
| Purchase price paid for ADVA shares |  | $ | 565,491 |  |
| Equity compensation (1) |  | $ | 12,769 |  |
| Total purchase price |  | $ | 578,260 |  |

[0000950170-23-005536:notes:93]
(1) Represents the portion of replacement share-based payment awards that relates to pre-combination vesting.

[0000950170-23-005536:notes:94]
Assets acquired and liabilities assumed were recognized at their respective fair values as of July 15, 2022. In determining the fair value, the Company utilized various methods of the income, cost and market approaches depending on the asset or liability being fair valued. The estimation of fair value required significant judgment related to future net cash flows reflecting the risk inherent in each cash flow stream, competitive trends, market comparables and other factors. Inputs were generally determined by taking into account historical data, current and anticipated market conditions, and growth rates.

[0000950170-23-005536:notes:95]
Developed technology and customer relationships were valued using the multi-period excess earnings method. Backlog was valued using the distributor method. Significant assumptions used in the discounted cash flow analysis for (i) developed technology were the revenue growth rates, long-term revenue growth rate, discount rate, and earnings before interest, taxes, depreciation and amortization (“EBITDA”) margins, obsolescence factors, income tax rate, tax depreciation, and economic depreciation; (ii) customer relationships were earnings before interest and taxes (“EBIT”) margins, contributory asset charges, and customer attrition rate; and (iii) backlog were EBIT margins, adjusted EBIT margins, and contributory asset charges.

[0000950170-23-005536:notes:96]
The allocation of the purchase price to the assets acquired and liabilities assumed was subject to adjustment within the measurement period (up to one year from the acquisition date). The measurement period adjustments since initial preliminary estimates resulted from changes to the fair value estimates of the acquired assets and assumed liabilities based on finalizing the valuations of inventory, prepaid expenses and other current assets, property plant and equipment, intangible assets, other non-current assets and deferred tax assets and liabilities. The cumulative effect of all measurement period adjustments resulted in a decrease to recognized goodwill of $8.7 million.

[0000950170-23-005536:notes:97]
The following table summarizes the preliminary purchase price allocation for each major class of assets acquired and liabilities assumed in the acquisition of ADVA (in thousands):

[0000950170-23-005536:notes:98]
| (In thousands) |  |  |  |
| Total purchase price |  | $ | 578,260 |  |
| Non-controlling interest |  | $ | 316,415 |  |
| Net Assets: |  |  |  |
| Cash and cash equivalents |  | $ | 44,003 |  |
| Accounts receivable |  |  | 114,659 |  |
| Other receivables |  |  | 1,457 |  |
| Inventory |  |  | 200,331 |  |
| Prepaid expenses and other current assets |  |  | 28,208 |  |
| Property plant and equipment |  |  | 55,480 |  |
| Deferred tax assets |  |  | 1,759 |  |
| Identifiable intangible assets |  |  | 403,780 |  |
| Other non-current assets |  |  | 31,074 |  |
| Accounts payable |  |  | (98,587 | ) |
| Current unearned revenue |  |  | (26,047 | ) |
| Accrued expenses and other liabilities |  |  | (59,600 | ) |
| Income tax payable, net |  |  | (4,898 | ) |
| Current portion of notes payable |  |  | (25,254 | ) |
| Tax liabilities |  |  | (1,400 | ) |
| Non-current unearned revenue |  |  | (11,498 | ) |
| Pension liability |  |  | (6,820 | ) |
| Other non-current liabilities |  |  | (6,094 | ) |
| Non-current portion of revolving credit agreements and notes payable |  |  | (15,250 | ) |
| Non-current lease obligations |  |  | (20,046 | ) |
| Deferred tax liabilities |  |  | (61,040 | ) |
| Total net assets acquired |  | $ | 544,217 |  |
| Goodwill |  | $ | 350,458 |  |

[0000950170-23-005536:notes:99]
The allocation of the purchase price and fair value assessment of goodwill, deferred tax assets, and deferred tax liabilities continues to be preliminary. The acquisition accounting is subject to revision once the Company receives final information. It is possible that the final assessment of fair value may differ materially from the preliminary assessment. If the final assessment differs from this preliminary assessment, the measurement period adjustments will be recorded in the period in which they are determined as if they had been completed at the acquisition date.

[0000950170-23-005536:notes:100]
The preliminary fair value of the assets acquired include accounts receivable of $114.7 million and other receivables of $1.5 million. The unpaid principal balance under these receivables is $118.5 million and $1.5 million, respectively. The difference between the fair value and the unpaid principal balance primarily represents amounts expected to be uncollectible.

[0000950170-23-005536:notes:101]
The fair value of the identifiable intangible assets acquired as of the acquisition date:

[0000950170-23-005536:notes:102]
| (In thousands) | Estimated-average useful life (in years) (1) |  |  | Fair value |  |  | Income Statement Amortization Classification |
| Developed technology |  | 8.5 |  |  | $ | 291,925 |  |  | Cost of revenue - Network Solutions |
| Backlog |  | 1.4 |  |  |  | 52,165 |  |  | Cost of revenue - Network Solutions and Services & Support |
| Customer relationships |  | 10.5 |  |  |  | 32,704 |  |  | Selling, general and administrative expenses |
| Trade name |  | 2.8 |  |  |  | 26,986 |  |  | Selling, general and administrative expenses |
| Total |  |  |  | $ | 403,780 |  |  |  |

[0000950170-23-005536:notes:103]
(1) Determination of the weighted average period of the individual categories of intangible assets was based on the nature of the applicable intangible asset and the expected future cash flows to be derived from the intangible asset. Amortization of intangible assets with definite lives is recognized over the period of time the assets are expected to contribute to future cash flows.

[0000950170-23-005536:notes:104]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and intangible assets acquired. Based on preliminary estimates, the ADVA acquisition resulted in the recognition of goodwill of $350.5 million, which the Company believes is attributable to the value driven by the Company’s expected growth of the business, synergies, and expanded market and product opportunities. Goodwill created as a result of the ADVA acquisition is not deductible for tax purposes.

[0000950170-23-005536:notes:105]
After the Business Combination, the chief operating decision maker assessed and will continue to assess the Company’s performance and allocate resources to its two segments (1) Network Solutions and (2) Services & Support. Based on preliminary estimates, the goodwill resulting from the Business Combination of $272.8 million was allocated to the Network Solutions segment, and $77.7 million was allocated to the Services & Support segment. See Note 18 of the Notes to Consolidated Financial Statements, included in this report for more information about the Company’s segments.

[0000950170-23-005536:notes:106]
As of the acquisition date, the fair value of the non-controlling interest was approximately $316.4 million and determined using a market approach. As a portion of ADVA shares will remain trading after the Business Combination, the non-controlling interest was calculated using 17,941,496 ADVA shares held by non-controlling interest multiplied by the ADVA closing share price of €17.58 ($17.64 using the July 15, 2022 EUR to USD conversion rate of $1.00318) on July 15, 2022.

[0000950170-23-005536:notes:107]
The Company included the financial results of ADVA in its consolidated financial statements since July 15, 2022, the acquisition date. The net revenue and net loss from the ADVA business since July 15, 2022, were $365.9 million and $12.9 million, respectively, which are included in the Company’s Consolidated Statement of Loss. The net loss attributable to non-controlling interest from the ADVA business for the year ended December 31, 2022 was $6.9 million.

[0000950170-23-005536:notes:108]
As of December 31, 2022, the Company has incurred $26.1 million of transaction costs related to the Business Combination, of which $14.2 million and $11.9 million were incurred during the years ended December 31, 2022 and 2021, respectively. These transaction costs are recorded in selling, general and administrative expense in the Consolidated Statements of Loss.

[0000950170-23-005536:notes:109]
Supplemental Pro Forma Information (Unaudited)

[0000950170-23-005536:notes:110]
The unaudited pro forma financial information in the table below summarizes the combined results of operations for ADTRAN and ADVA as though the Business Combination had occurred on January 1, 2021. The pro forma amounts have been adjusted for differences in basis of accounting which are determined before taking into effect the impacts of purchase accounting and Business Combination accounting impacts.

[0000950170-23-005536:notes:111]
The following unaudited pro forma information is presented for illustrative purposes only. It is not necessarily indicative of the results of operations of future periods, the results of operations that actually would have been realized had the entities been a single company as of January 1, 2021, or the future operating results of the combined entities. The unaudited pro forma information does not give effect to the potential impact of current financial conditions, regulatory matters or any anticipated synergies, operating efficiencies or cost savings that may be associated with the acquisition. The unaudited pro forma information also does not include any integration costs that the Company may incur related to the acquisition as part of combining the operations of the companies.

[0000950170-23-005536:notes:112]
|  | For the Years Ended December 31, |  |
| (In thousands) | 2022 |  |  | 2021 |  |
| Revenue | $ | 1,410,296 |  |  | $ | 1,210,201 |  |
| Net loss attributable to ADTRAN Holdings, Inc. | $ | (46,204 | ) |  | $ | (91,423 | ) |


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000950170-23-005536:notes:113]
Note 3 – Cash, Cash Equivalents and Restricted Cash

[0000950170-23-005536:notes:114]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the Consolidated Balance Sheet that sum to the total of the same such amounts shown in the Consolidated Statement of Cash Flows:

[0000950170-23-005536:notes:115]
| (In thousands) |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Cash and cash equivalents |  | $ | 108,644 |  |  | $ | 56,603 |  |
| Restricted cash |  |  | — |  |  |  | 215 |  |
| Cash, cash equivalents and restricted cash |  | $ | 108,644 |  |  | $ | 56,818 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-23-005536:notes:116]
Note 4 - Revenue

[0000950170-23-005536:notes:117]
The following is a description of the principal activities from which revenue is generated by reportable segment:

[0000950170-23-005536:notes:118]
Network Solutions Segment - Includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

[0000950170-23-005536:notes:119]
Services & Support Segment - Includes network design, implementation, maintenance and cloud-hosted services supporting the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

[0000950170-23-005536:notes:120]
Revenue by Category

[0000950170-23-005536:notes:121]
In addition to the Company's reportable segments, revenue is also reported for the following three categories – Subscriber Solutions, Access & Aggregation Solutions and Optical Networking Solutions.

[0000950170-23-005536:notes:122]
Prior to the Business Combination with ADVA on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with ADVA, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable ADVA solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable ADVA solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of ADVA’s portfolio.

[0000950170-23-005536:notes:123]
Our Subscriber Solutions portfolio is used by service providers to terminate their access services infrastructure at the customer premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

[0000950170-23-005536:notes:124]
Our Access & Aggregation Solutions are solutions that are used by communications service providers to connect residential subscribers, business subscribers and mobile radio networks to the service providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions, and access orchestration solutions that ensure highly reliable and efficient network performance.

[0000950170-23-005536:notes:125]
Our Optical Networking Solutions are used by communications service providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems, and automation platforms that are used to build high-scale, secure and assured optical networks.

[0000950170-23-005536:notes:126]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2022:

[0000950170-23-005536:notes:127]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 364,238 |  |  | $ | 26,216 |  |  | $ | 390,454 |  |
| Access & Aggregation Solutions |  |  | 326,934 |  |  |  | 47,068 |  |  |  | 374,002 |  |
| Optical Networking Solutions |  |  | 225,621 |  |  |  | 35,459 |  |  |  | 261,080 |  |
| Total |  | $ | 916,793 |  |  | $ | 108,743 |  |  | $ | 1,025,536 |  |

[0000950170-23-005536:notes:128]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2021:

[0000950170-23-005536:notes:129]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 189,825 |  |  | $ | 16,385 |  |  | $ | 206,210 |  |
| Access & Aggregation Solutions |  |  | 309,009 |  |  |  | 47,785 |  |  |  | 356,794 |  |
| Optical Networking Solutions |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 498,834 |  |  | $ | 64,170 |  |  | $ | 563,004 |  |

[0000950170-23-005536:notes:130]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2020:

[0000950170-23-005536:notes:131]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 163,349 |  |  | $ | 15,315 |  |  | $ | 178,664 |  |
| Access & Aggregation Solutions |  |  | 274,666 |  |  |  | 53,180 |  |  |  | 327,846 |  |
| Optical Networking Solutions |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 438,015 |  |  | $ | 68,495 |  |  | $ | 506,510 |  |

[0000950170-23-005536:notes:132]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of December 31, 2022 and December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $277.2 million and $101.1 million, respectively. As of December 31, 2022, approximately 66% is expected to be recognized over the next 12 months, and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at December 31, 2022 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-23-005536:notes:133]
The following table provides information about accounts receivable, contract assets and unearned revenue from contracts with customers:

[0000950170-23-005536:notes:134]
| (In thousands) |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Accounts receivable |  | $ | 279,435 |  |  | $ | 158,742 |  |
| Contract assets(1) |  | $ | 1,852 |  |  | $ | 464 |  |
| Unearned revenue |  | $ | 41,193 |  |  | $ | 17,737 |  |
| Non-current unearned revenue |  | $ | 19,239 |  |  | $ | 9,271 |  |

[0000950170-23-005536:notes:135]
(1) Included in other receivables on the Consolidated Balance Sheets.

[0000950170-23-005536:notes:136]
The Company is party to a receivables purchase agreement with a third party financial institution (the “Factor”). As of December 31, 2022, accounts receivable totaling $14.9 million were sold, of which $1.2 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Consolidated Balance Sheets. As of December 31, 2022, the Company has an allowance for doubtful accounts related to factored accounts receivable totaling less than $0.1 million. The cost of receivables purchase agreement is included in interest expense in the Consolidated Statements of Loss and totaled $0.3 million for the year ended December 31, 2022.

[0000950170-23-005536:notes:137]
Of the outstanding unearned revenue balances as of December 31, 2021, $14.0 million was recognized as revenue during the year ended December 31, 2022, respectively. Of the outstanding unearned revenue balances as of December 31, 2020, $11.2 million was recognized as revenue during the year ended December 31, 2021.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-005536:notes:138]
Note 5 – Stock-Based Compensation

[0000950170-23-005536:notes:139]
The following table summarizes stock-based compensation expense related to stock options, PSUs, RSUs and restricted stock for the years ended December 31, 2022, 2021 and 2020:

[0000950170-23-005536:notes:140]
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Stock-based compensation expense included in cost of revenue |  | $ | 2,876 |  |  | $ | 543 |  |  | $ | 426 |  |
| Selling, general and administrative expenses |  |  | 20,844 |  |  |  | 4,571 |  |  |  | 4,036 |  |
| Research and development expenses |  |  | 4,602 |  |  |  | 2,366 |  |  |  | 2,372 |  |
| Stock-based compensation expense included in operating expenses |  |  | 25,446 |  |  |  | 6,937 |  |  |  | 6,408 |  |
| Total stock-based compensation expense |  |  | 28,322 |  |  |  | 7,480 |  |  |  | 6,834 |  |
| Tax benefit for expense associated with non-qualified stock options, PSUs, RSUs and restricted stock |  |  | (5,152 | ) |  |  | (1,849 | ) |  |  | (1,629 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 23,170 |  |  | $ | 5,631 |  |  | $ | 5,205 |  |

[0000950170-23-005536:notes:141]
Stock Incentive Program Descriptions

[0000950170-23-005536:notes:142]
2020 Stock Incentive Plans

[0000950170-23-005536:notes:143]
At the annual meeting of stockholders held on May 13, 2020, the Company’s stockholders approved, upon recommendation of the Board of Directors, the adoption of the ADTRAN, Inc. 2020 Employee Stock Incentive Plan (the “2020 Employee Plan”) as well as the

[0000950170-23-005536:notes:144]
ADTRAN, Inc. 2020 Directors Stock Plan (the “2020 Directors Plan”), which were assumed by the Company upon consummation of the Merger. No additional awards will be granted under the Company’s previous stock incentive plans, the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (the “2015 Employee Plan”) or the 2010 Directors Stock Plan (the “2010 Directors Plan”) subsequent to the stockholders’ approval of these new stock plans. Outstanding awards granted under the 2015 Employee Plan and the 2010 Directors Plan will remain subject to the terms of such plans, and shares underlying awards granted under such plans that are cancelled or forfeited will be available for issuance under the 2020 Employee Plan or the 2020 Directors Plan, as applicable.

[0000950170-23-005536:notes:145]
Under the 2020 Employee Plan, the Company is authorized to issue 2.8 million shares of common stock to certain employees, key service providers and advisors through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock, any of which may be subject to performance-based conditions. RSUs and restricted stock granted under the 2020 Employee Plan will typically vest pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date. Stock options granted under the 2020 Employee Plan will typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Stock options, RSUs and restricted stock granted under the 2020 Employee Plan reduce the shares authorized for issuance under the 2020 Employee Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations or expirations of awards granted under the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan, with forfeitures, cancellations or expirations of RSUs and restricted stock increasing the shares authorized for issuance by 2.5 shares of common stock for each share underlying the award. Forfeitures, cancellations or expirations of stock options from the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan by one share of common stock for each share underlying the award.

[0000950170-23-005536:notes:146]
Under the 2020 Directors Plan, the Company is authorized to issue 0.4 million shares of common stock through stock options, restricted stock and RSUs to non-employee directors. Stock awards issued under the 2020 Directors Plan typically will become vested in full on the first anniversary of the grant date. Stock options issued under the 2020 Directors Plan will have a ten-year contractual term. Stock options, restricted stock and RSUs granted under the 2020 Directors Plan reduce the shares authorized for issuance under the 2020 Directors Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the 2010 Directors Stock Plan increase the shares authorized for issuance under the 2020 Directors Plan by one share of common stock for each share underlying the award.

[0000950170-23-005536:notes:147]
Previous Stock Incentive Plans

[0000950170-23-005536:notes:148]
In January 2015, the Board of Directors adopted the 2015 Employee Plan, which authorized 7.7 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, PSUs, RSUs and restricted stock. The 2015 Employee Plan was adopted by stockholder approval at our annual meeting of stockholders held in May 2015. PSUs, RSUs and restricted stock granted under the 2015 Plan reduce the shares authorized for issuance under the 2015 Employee Plan by 2.5 shares of common stock for each share underlying the award. Options granted under the 2015 Employee Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Expiration dates of options outstanding as of December 31, 2022 under the 2015 Employee Plan range from 2025 to 2026.

[0000950170-23-005536:notes:149]
In January 2006, the Board of Directors adopted the ADTRAN, Inc. 2006 Employee Stock Incentive Plan (the “2006 Plan”), which authorized 13.0 million shares of common stock for issuance to officers and certain employees through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock. Options granted under the 2006 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and had a ten-year contractual term. The 2006 Plan was replaced in May 2015 by the 2015 Employee Plan. Expiration dates of options outstanding as of December 31, 2022 under the 2006 Plan range from 2022 to 2024.

[0000950170-23-005536:notes:150]
In May 2010, the Company’s stockholders approved the 2010 Directors Plan, under which 0.5 million shares of common stock have been reserved for issuance. This plan replaced the 2005 Directors Stock Option Plan. Under the 2010 Directors Plan, the Company may issue stock options, restricted stock and RSUs to our non-employee directors. Stock awards issued under the 2010 Directors Plan become vested in full on the first anniversary of the grant date. Options issued under the 2010 Directors Plan had a ten-year contractual term. All remaining options under the 2010 Directors Plan expired in 2019.

[0000950170-23-005536:notes:151]
PSUs, RSUs and restricted stock - ADTRAN Holdings, Inc.

[0000950170-23-005536:notes:152]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2021 and 2022 and the changes that occurred during 2022:

[0000950170-23-005536:notes:153]
|  |  | Number ofshares (In thousands) |  |  | WeightedAverage GrantDate Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2021 |  |  | 1,930 |  |  | $ | 14.11 |  |
| PSUs, RSUs and restricted stock granted |  |  | 645 |  |  | $ | 20.56 |  |
| PSUs, RSUs and restricted stock vested |  |  | (1,440 | ) |  | $ | 12.81 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (49 | ) |  | $ | 14.22 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2022 |  |  | 1,086 |  |  | $ | 17.54 |  |

[0000950170-23-005536:notes:154]
The following table details the significant assumptions that impact the fair value estimate of the market-based PSUs:

[0000950170-23-005536:notes:155]
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Estimated fair value per share |  | $ | 24.01 |  |  | $ | 26.07 |  |  | $ | 14.43 |  |
| Expected volatility |  |  | 45.77 | % |  |  | 53.27 | % |  |  | 51.88 | % |
| Risk-free interest rate |  |  | 4.28 | % |  |  | 0.85 | % |  |  | 0.24 | % |
| Expected dividend yield |  |  | 1.76 | % |  |  | 1.63 | % |  |  | 2.85 | % |

[0000950170-23-005536:notes:156]
For market-based PSUs, the number of shares of common stock earned by a recipient is subject to a market condition based on ADTRAN’s relative total shareholder return against all companies in the NASDAQ Telecommunications Index at the end of a three-year performance period. Depending on the relative total shareholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the PSUs, with the shares earned distributed upon the vesting. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted PSUs vests and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of ADTRAN, as defined by the 2020 Employee Plan. The recipients of the PSUs receive dividend credits based on the shares of common stock underlying the PSUs. The dividend credits vest and are earned in the same manner as the PSUs and are paid in cash upon the issuance of common stock for the PSUs.

[0000950170-23-005536:notes:157]
During each of the years ended December, 2022, 2021 and 2020, the Company granted 0.3 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over one-year, two-year and three-year periods, respectively, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements. Pursuant to the Business Combination, the unearned performance-based PSUs converted to time-based RSUs which were treated as an award modification during the third quarter of 2022. This resulted in incremental compensation expense totaling $17.8 million being recognized during the twelve months ended December 31, 2022. These awards were fully vested as of December 31, 2022.

[0000950170-23-005536:notes:158]
Pursuant to the Business Combination, 0.3 million shares of market-based PSU awards converted to time-based RSU's awards which were treated as an award modification during the third quarter of 2022. Given that the fair value of these awards after the modification was less than the fair value of the awards immediately before the modification, no incremental compensation expense was recognized. The Company continued to recognize compensation expense based on the award's original grant date fair value. As of December 31, 2022, there was $1.4 million of unrecognized compensation expense related to these awards which will be recognized over the weighted average remaining service period of 1.57 years.

[0000950170-23-005536:notes:159]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the grant date. RSUs and restricted stock vest ratably over four-year and one-year periods, respectively.

[0000950170-23-005536:notes:160]
We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0000950170-23-005536:notes:161]
As of December 31, 2022, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $15.8 million, which is expected to be recognized over an average remaining recognition period of 2.25 years and will be adjusted for actual forfeitures as they occur.

[0000950170-23-005536:notes:162]
As of December 31, 2022, 3.3 million shares were available for issuance under shareholder-approved equity plans in connection with the grant and exercise of stock options, PSU’s, RSU’s or restricted stock.

[0000950170-23-005536:notes:163]
Stock Options - ADTRAN Holdings, Inc.

[0000950170-23-005536:notes:164]
The following table is a summary of stock options outstanding as of December 31, 2022 and 2021 and the changes that occurred during 2022:

[0000950170-23-005536:notes:165]
|  |  | Number ofOptions(In thousands) |  |  | WeightedAverageExercise Price(Per share) |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | AggregateIntrinsic Value(In thousands) |  |
| Stock options outstanding, December 31, 2021 |  |  | 1,721 |  |  | $ | 19.37 |  |  |  | 2.39 |  |  | $ | 6,669 |  |
| ADVA stock options replaced by ADTRAN Holdings stock options(1) |  |  | 2,094 |  |  | $ | 11.12 |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (519 | ) |  | $ | 15.70 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (10 | ) |  | $ | 10.28 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (138 | ) |  | $ | 22.73 |  |  |  |  |  |  |  |
| Stock options outstanding, December 31, 2022 |  |  | 3,148 |  |  | $ | 14.37 |  |  |  | 3.42 |  |  | $ | 16,251 |  |
| Stock options exercisable, December 31, 2022 |  |  | 1,711 |  |  | $ | 15.95 |  |  |  | 1.95 |  |  | $ | 7,104 |  |

[0000950170-23-005536:notes:166]
(1) Each ADVA stock option surrendered was exchanged for 0.8244 ADTRAN Holdings stock options.

[0000950170-23-005536:notes:167]
As of December 31, 2022, there was $8.3 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 2.4 years.

[0000950170-23-005536:notes:168]
Pursuant to the Business Combination, which closed on July 15, 2022, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings. The maximum number of shares of ADTRAN Holdings stock potentially issuable upon such assumption was 2.3 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.1 million shares of ADTRAN Holdings stock are subject to assumed ADVA options. The determination of the fair value of stock options assumed by ADTRAN Holdings was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors.

[0000950170-23-005536:notes:169]
All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0000950170-23-005536:notes:170]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2022. The amount of aggregate intrinsic value was $16.3 million as of December 31, 2022 and will change based on the fair market value of ADTRAN’s stock. The total pre-tax intrinsic value of options exercised during the year ended December 31, 2022 was $4.0 million.

[0000950170-23-005536:notes:171]
The following table further describes our stock options outstanding as of December 31, 2022:

[0000950170-23-005536:notes:172]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range ofExercise Prices |  | OptionsOutstanding atDecember 31, 2022(In thousands) |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | WeightedAverageExercisePrice |  |  | OptionsExercisable atDecember 31, 2022(In thousands) |  |  | WeightedAverageExercisePrice |  |
| $6.06 – $8.67 |  |  | 755 |  |  |  | 3.21 |  |  | $ | 7.37 |  |  |  | 320 |  |  | $ | 6.47 |  |
| $8.68 – $13.74 |  |  | 833 |  |  |  | 4.65 |  |  | $ | 11.45 |  |  |  | 207 |  |  | $ | 9.63 |  |
| $13.75 – $17.15 |  |  | 427 |  |  |  | 3.27 |  |  | $ | 15.33 |  |  |  | 368 |  |  | $ | 15.33 |  |
| $17.16 – $21.36 |  |  | 679 |  |  |  | 3.92 |  |  | $ | 19.02 |  |  |  | 369 |  |  | $ | 18.97 |  |
| $21.37 – $23.64 |  |  | 454 |  |  |  | 0.83 |  |  | $ | 23.64 |  |  |  | 447 |  |  | $ | 23.64 |  |
|  |  |  | 3,148 |  |  |  |  |  |  |  |  |  | 1,711 |  |  |  |  |

[0000950170-23-005536:notes:173]
The Black-Scholes option pricing model (the “Black-Scholes Model”) is used to determine the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0000950170-23-005536:notes:174]
The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0000950170-23-005536:notes:175]
The weighted-average estimated fair value of stock options granted to employees during the year ended December 31,2022 was $5.81 per share with the following weighted-average assumptions:

[0000950170-23-005536:notes:176]
|  |  | 2022 |  |
| Expected volatility |  |  | 45.00 | % |
| Risk-free interest rate |  |  | 3.00 | % |
| Expected dividend yield |  |  | 1.77 | % |
| Expected life (in years) |  |  | 2.4 |  |

[0000950170-23-005536:notes:177]
There were no stock options granted in during the years ended December 31, 2021 and 2020.

[0000950170-23-005536:notes:178]
Stock Options - ADVA Optical Networking SE

[0000950170-23-005536:notes:179]
The following table summarizes ADVA Optical Networking SE stock options outstanding as of July 15, 2022 (the Business Combination closing date) and December 31, 2022 and the changes that occurred between July 15, 2022 and December 31, 2022:

[0000950170-23-005536:notes:180]
|  |  | Number ofOptions(In thousands) |  |  | WeightedAverageExercise Price(Per share) |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | AggregateIntrinsic Value(In thousands) |  |
| Stock options outstanding, July 15, 2022 |  |  | 2,745 |  |  | $ | 9.09 |  |  |  | 4.60 |  |  | $ | 27,205 |  |
| Stock options exercised |  |  | (102 | ) |  | $ | 8.02 |  |  |  |  |  |  |  |
| ADVA stock options replaced by ADTRAN Holdings stock options(1) |  |  | (2,550 | ) |  | $ | 9.80 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (12 | ) |  | $ | 9.57 |  |  |  |  |  |  |  |
| Stock options outstanding, December 31, 2022 |  |  | 81 |  |  | $ | 8.58 |  |  |  | 4.00 |  |  | $ | 1,222 |  |
| Stock options exercisable, December 31, 2022 |  |  | 27 |  |  | $ | 7.37 |  |  |  | 2.39 |  |  | $ | 432 |  |

[0000950170-23-005536:notes:181]
As of December 31, 2022, there was $0.1 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 1.17 years.

[0000950170-23-005536:notes:182]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADVA's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2022. The amount of aggregate intrinsic value was $1.2 million as of December 31, 2022 and will change based on the fair market value of ADVA's stock. The total pre-tax intrinsic value of options exercised during the period July 15, 2022 through December 31, 2022 was $1.6 million.

[0000950170-23-005536:notes:183]
The following table further describes ADVA's stock options outstanding as of December 31, 2022:

[0000950170-23-005536:notes:184]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range ofExercise Prices |  | OptionsOutstanding atDecember 31, 2022(In thousands) |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | WeightedAverageExercisePrice |  |  | OptionsExercisable atDecember 31, 2022(In thousands) |  |  | WeightedAverageExercisePrice |  |
| €4.98 - €7.05 |  |  | 35 |  |  |  | 3.52 |  |  | $ | 6.97 |  |  |  | 9 |  |  | $ | 5.34 |  |
| €7.06 - €8.70 |  |  | 18 |  |  |  | 2.60 |  |  | $ | 8.41 |  |  |  | 18 |  |  | $ | 8.41 |  |
| €8.71 - €15.68 |  |  | 28 |  |  |  | 5.48 |  |  | $ | 10.73 |  |  |  | — |  |  | $ | — |  |
|  |  |  | 81 |  |  |  |  |  |  |  |  |  | 27 |  |  |  |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-23-005536:notes:185]
Note 6 – Investments

[0000950170-23-005536:notes:186]
Debt Securities and Other Investments

[0000950170-23-005536:notes:187]
As of December 31, 2022, the following debt securities and other investments were included in short-term investments and long-term investments on the Consolidated Balance Sheet and recorded at fair value:

[0000950170-23-005536:notes:188]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,538 |  |  | $ | 5 |  |  | $ | (81 | ) |  | $ | 2,462 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  |  |  |  | (5 | ) |  |  | 180 |  |
| Asset-backed bonds |  |  | 818 |  |  |  | 1 |  |  |  | (24 | ) |  |  | 795 |  |
| Mortgage/Agency-backed bonds |  |  | 1,853 |  |  |  |  |  |  | (105 | ) |  |  | 1,748 |  |
| U.S. government bonds |  |  | 3,870 |  |  |  | 3 |  |  |  | (188 | ) |  |  | 3,685 |  |
| Foreign government bonds |  |  | 407 |  |  |  |  |  |  | (24 | ) |  |  | 383 |  |
| Available-for-sale debt securities held at fair value |  | $ | 9,671 |  |  | $ | 9 |  |  | $ | (427 | ) |  | $ | 9,253 |  |

[0000950170-23-005536:notes:189]
As of December 31, 2021, the following debt securities and other investments were included in short-term investments and long-term investments on the Consolidated Balance Sheet and recorded at fair value:

[0000950170-23-005536:notes:190]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,776 |  |  | $ | 6 |  |  | $ | (35 | ) |  | $ | 10,747 |  |
| Municipal fixed-rate bonds |  |  | 1,553 |  |  |  | 2 |  |  |  | (4 | ) |  |  | 1,551 |  |
| Asset-backed bonds |  |  | 322 |  |  |  | 3 |  |  |  | (3 | ) |  |  | 322 |  |
| Mortgage/Agency-backed bonds |  |  | 4,754 |  |  |  | 15 |  |  |  | (33 | ) |  |  | 4,736 |  |
| U.S. government bonds |  |  | 12,251 |  |  |  | 12 |  |  |  | (92 | ) |  |  | 12,171 |  |
| Foreign government bonds |  |  | 543 |  |  |  | — |  |  |  | (4 | ) |  |  | 539 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,199 |  |  | $ | 38 |  |  | $ | (171 | ) |  | $ | 30,066 |  |

[0000950170-23-005536:notes:191]
As of December 31, 2022, our debt securities had the following contractual maturities:

[0000950170-23-005536:notes:192]
| (In thousands) |  | Corporatebonds |  |  | Municipalfixed-ratebonds |  |  | Asset-backedbonds |  |  | Mortgage /Agency-backedbonds |  |  | U.S.governmentbonds |  |  | Foreigngovernmentbonds |  |
| Less than one year |  | $ | — |  |  | $ | 180 |  |  | $ | — |  |  | $ | — |  |  | $ | 160 |  |  | $ | — |  |
| One to two years |  |  | 1,450 |  |  |  | — |  |  |  | 96 |  |  |  | 162 |  |  |  | 2,787 |  |  |  | 276 |  |
| Two to three years |  |  | 1,012 |  |  |  | — |  |  |  | 186 |  |  |  | 598 |  |  |  | 617 |  |  |  | 107 |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 335 |  |  |  | 253 |  |  |  | 121 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 317 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 178 |  |  |  | 418 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 2,462 |  |  | $ | 180 |  |  | $ | 795 |  |  | $ | 1,748 |  |  | $ | 3,685 |  |  | $ | 383 |  |

[0000950170-23-005536:notes:193]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0000950170-23-005536:notes:194]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities for the years ended December 31, 2022, 2021 and 2020:

[0000950170-23-005536:notes:195]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Gross realized gains on debt securities |  | $ | 17 |  |  | $ | 241 |  |  | $ | 459 |  |
| Gross realized losses on debt securities |  |  | (1,211 | ) |  |  | (159 | ) |  |  | (58 | ) |
| Total (loss) gain recognized, net |  | $ | (1,194 | ) |  | $ | 82 |  |  | $ | 401 |  |

[0000950170-23-005536:notes:196]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt with credit deterioration during the years ended December 31, 2022, 2021 and 2020.

[0000950170-23-005536:notes:197]
The following table presents the breakdown of debt securities and other investments with unrealized losses as of December 31, 2022:

[0000950170-23-005536:notes:198]
|  |  | Continuous UnrealizedLoss Position for Lessthan 12 Months |  |  | Continuous UnrealizedLoss Position for 12Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |
| Corporate bonds |  | $ | 1,367 |  |  | $ | (39 | ) |  | $ | 583 |  |  | $ | (42 | ) |  | $ | 1,950 |  |  | $ | (81 | ) |
| Municipal fixed-rate bonds |  |  | — |  |  |  | — |  |  |  | 178 |  |  |  | (5 | ) |  |  | 180 |  |  |  | (5 | ) |
| Asset-backed bonds |  |  | 524 |  |  |  | (14 | ) |  |  | 117 |  |  |  | (10 | ) |  |  | 641 |  |  |  | (24 | ) |
| Mortgage/Agency-backed bonds |  |  | 825 |  |  |  | (23 | ) |  |  | 844 |  |  |  | (82 | ) |  |  | 1,668 |  |  |  | (105 | ) |
| U.S. government bonds |  |  | 2,215 |  |  |  | (106 | ) |  |  | 1,063 |  |  |  | (82 | ) |  |  | 3,278 |  |  |  | (188 | ) |
| Foreign government bonds |  |  | — |  |  |  | — |  |  |  | 383 |  |  |  | (24 | ) |  |  | 383 |  |  |  | (24 | ) |
| Total |  | $ | 4,931 |  |  | $ | (182 | ) |  | $ | 3,168 |  |  | $ | (245 | ) |  | $ | 8,100 |  |  | $ | (427 | ) |

[0000950170-23-005536:notes:199]
The following table presents the breakdown of debt securities and other investments with unrealized losses as of December 31, 2021:

[0000950170-23-005536:notes:200]
|  |  | Continuous UnrealizedLoss Position for Lessthan 12 Months |  |  | Continuous UnrealizedLoss Position for 12Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |
| Corporate bonds |  | $ | 6,795 |  |  | $ | (35 | ) |  | $ | — |  |  | $ | — |  |  | $ | 6,795 |  |  | $ | (35 | ) |
| Municipal fixed-rate bonds |  |  | 1,129 |  |  |  | (4 | ) |  |  | — |  |  |  | — |  |  |  | 1,129 |  |  |  | (4 | ) |
| Asset-backed bonds |  |  | 198 |  |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | 198 |  |  |  | (3 | ) |
| Mortgage/Agency-backed bonds |  |  | 3,006 |  |  |  | (33 | ) |  |  | — |  |  |  | — |  |  |  | 3,006 |  |  |  | (33 | ) |
| U.S. government bonds |  |  | 10,552 |  |  |  | (92 | ) |  |  | — |  |  |  | — |  |  |  | 10,552 |  |  |  | (92 | ) |
| Foreign government bonds |  |  | 294 |  |  |  | (4 | ) |  |  | — |  |  |  | — |  |  |  | 294 |  |  |  | (4 | ) |
| Total |  | $ | 21,974 |  |  | $ | (171 | ) |  | $ | — |  |  | $ | — |  |  | $ | 21,974 |  |  | $ | (171 | ) |

[0000950170-23-005536:notes:201]
The increase in unrealized losses during 2022 resulted from changes in market positions associated with our fixed income portfolio.

[0000950170-23-005536:notes:202]
Marketable Equity Securities

[0000950170-23-005536:notes:203]
Marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost, where appropriate.

[0000950170-23-005536:notes:204]
Realized and unrealized gains and losses for our marketable equity securities for the year ended December 31, 2022, 2021 and 2020 were as follows:

[0000950170-23-005536:notes:205]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2019 |  |
| Realized losses on equity securities sold |  | $ | (1,675 | ) |  | $ | (992 | ) |  | $ | (2,382 | ) |
| Unrealized (losses) gains on equity securities held |  |  | (8,470 | ) |  |  | 2,671 |  |  |  | 6,831 |  |
| Total (loss) gain recognized, net |  | $ | (10,145 | ) |  | $ | 1,679 |  |  | $ | 4,449 |  |

[0000950170-23-005536:notes:206]
As of December 31, 2022 and 2021, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.

[0000950170-23-005536:notes:207]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-23-005536:notes:208]
•
Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-23-005536:notes:209]
•
Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-23-005536:notes:210]
•
Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement; inputs could include information supplied by investees.

[0000950170-23-005536:notes:211]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-23-005536:notes:212]
|  |  | Fair Value Measurements as of December 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 228 |  |  | $ | 228 |  |  |  |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 2,462 |  |  |  |  |  |  | 2,462 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 180 |  |  |  |  |  |  | 180 |  |  |  | — |  |
| Asset-backed bonds |  |  | 795 |  |  |  |  |  |  | 795 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,748 |  |  |  |  |  |  | 1,748 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,685 |  |  |  | 3,685 |  |  |  |  |  |  | — |  |
| Foreign government bonds |  |  | 383 |  |  |  |  |  |  | 383 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities - various industries |  |  | 804 |  |  |  | 804 |  |  |  |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,942 |  |  |  | 22,942 |  |  |  |  |  |  | — |  |
| Total |  | $ | 33,227 |  |  | $ | 27,659 |  |  | $ | 5,568 |  |  | $ | — |  |

[0000950170-23-005536:notes:213]
|  |  | Fair Value Measurements as of December 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 652 |  |  | $ | 652 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,747 |  |  |  | — |  |  |  | 10,747 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,551 |  |  |  | — |  |  |  | 1,551 |  |  |  | — |  |
| Asset-backed bonds |  |  | 322 |  |  |  | — |  |  |  | 322 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,736 |  |  |  | — |  |  |  | 4,736 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,171 |  |  |  | 12,171 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 539 |  |  |  | — |  |  |  | 539 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities - various industries |  |  | 12,606 |  |  |  | 12,606 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,935 |  |  |  | 26,935 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 70,259 |  |  | $ | 52,364 |  |  | $ | 17,895 |  |  | $ | — |  |

[0000950170-23-005536:notes:214]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0000950170-23-005536:notes:215]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consisted of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.

[0000950170-23-005536:notes:216]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-23-005536:notes:217]
Note 7 – Inventory

[0000950170-23-005536:notes:218]
As of December 31, 2022 and 2021, inventory, net was comprised of the following:

[0000950170-23-005536:notes:219]
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Raw materials |  | $ | 186,346 |  |  | $ | 74,709 |  |
| Work in process |  |  | 12,087 |  |  |  | 2,143 |  |
| Finished goods |  |  | 229,098 |  |  |  | 63,039 |  |
| Total Inventory, net |  | $ | 427,531 |  |  | $ | 139,891 |  |

[0000950170-23-005536:notes:220]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. As of December 31, 2022 and 2021, our inventory reserve was $57.0 million and $44.6 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-23-005536:notes:221]
Note 8 – Property, Plant and Equipment

[0000950170-23-005536:notes:222]
As of December 31, 2022 and 2021, property, plant and equipment, net was comprised of the following:

[0000950170-23-005536:notes:223]
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Engineering and other equipment |  | $ | 170,785 |  |  | $ | 134,771 |  |
| Building |  |  | 82,932 |  |  |  | 68,157 |  |
| Computer hardware and software |  |  | 80,455 |  |  |  | 72,274 |  |
| Building and land improvements |  |  | 47,861 |  |  |  | 35,578 |  |
| Furniture and fixtures |  |  | 22,403 |  |  |  | 19,917 |  |
| Land |  |  | 5,364 |  |  |  | 4,575 |  |
| Total Property, Plant and Equipment |  |  | 409,800 |  |  |  | 335,272 |  |
| Less: accumulated depreciation |  |  | (299,101 | ) |  |  | (279,506 | ) |
| Total Property, Plant and Equipment, net |  | $ | 110,699 |  |  | $ | 55,766 |  |

[0000950170-23-005536:notes:224]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result, the Company recognized impairment charges of $0.5 million during the year ended December 31, 2022 related to software and web site development. The impairment charges were determined based on actual costs incurred. During the year ended December 31, 2021, no impairment charges were recognized. During the year ended December 31, 2020, the Company recognized impairment charges of $0.1 million.

[0000950170-23-005536:notes:225]
Depreciation expense was $20.9 million, $12.0 million and $12.2 million for the years ended December 31, 2022, 2021 and 2020, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of (Loss) Income.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000950170-23-005536:notes:226]
Note 9 – Leases

[0000950170-23-005536:notes:227]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. As of December 31, 2022, our operating leases had remaining lease terms of one month to 119 months, some of which included options to extend the leases for up to five years, and some of which included options to terminate the leases within three months. Supplemental balance sheet information related to operating leases is as follows:

[0000950170-23-005536:notes:228]
|  |  |  |  | December 31, |  |  | December 31, |  |
| (In thousands) |  | Classification |  | 2022 |  |  | 2021 |  |
| Assets |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Other non-current assets |  | $ | 30,340 |  |  | $ | 4,922 |  |
| Total lease asset |  |  |  | $ | 30,340 |  |  | $ | 4,922 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses and other liabilities |  | $ | 7,596 |  |  | $ | 1,730 |  |
| Non-current operating lease liability |  | Other non-current liabilities |  |  | 22,807 |  |  |  | 3,269 |  |
| Total lease liability |  |  |  | $ | 30,403 |  |  | $ | 4,999 |  |

[0000950170-23-005536:notes:229]
Lease expense related to short-term leases was less than $0.1 million for the twelve months ended December 31, 2022, 2021 and 2020, and is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of (Loss) Income. Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.6 million, $0.5 million and $0.7 million for the twelve months ended December 31, 2022, 2021 and 2020, respectively.

[0000950170-23-005536:notes:230]
The components of lease expense included in the Consolidated Statements of (Loss) Income were as follows:

[0000950170-23-005536:notes:231]
|  |  | For the Year Ended December 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Cost of revenue |  | $ | 110 |  |  | $ | 51 |  |  | $ | 113 |  |
| Research and development expenses |  |  | 942 |  |  |  | 1,071 |  |  |  | 1,121 |  |
| Selling, general and administrative expenses |  |  | 3,961 |  |  |  | 883 |  |  |  | 1,311 |  |
| Total operating lease expense |  | $ | 5,013 |  |  | $ | 2,005 |  |  | $ | 2,545 |  |

[0000950170-23-005536:notes:232]
As of December 31, 2022, operating lease liabilities included on the Consolidated Balance Sheet by future maturity were as follows:

[0000950170-23-005536:notes:233]
| (In thousands) |  | Amount |  |
| 2023 |  |  | 8,992 |  |
| 2024 |  |  | 8,076 |  |
| 2025 |  |  | 6,740 |  |
| 2026 |  |  | 3,825 |  |
| 2027 |  |  | 2,865 |  |
| Thereafter |  |  | 4,478 |  |
| Total lease payments |  |  | 34,976 |  |
| Less: Interest |  |  | (4,573 | ) |
| Present value of lease liabilities |  | $ | 30,403 |  |

[0000950170-23-005536:notes:234]
Future operating lease payments include $4.4 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0000950170-23-005536:notes:235]
An incremental borrowing rate is used based on information available at the commencement date in determining the present value of lease payments. The incremental borrowing rate is determined on a portfolio basis by grouping leases with similar terms, as well as grouping leases based on a U.S. dollar or Euro functional currency. The following table provides information about our weighted average lease terms and weighted average discount rates:

[0000950170-23-005536:notes:236]
|  |  | As of December 31, |  |
| Weighted average remaining lease term (years) |  | 2022 |  |  | 2021 |  |
| Operating leases with USD functional currency |  |  | 7.9 |  |  |  | 1.8 |  |
| Operating leases with Euro functional currency |  |  | 4.2 |  |  |  | 3.5 |  |
| Weighted average discount rate |  |  |  |  |  |  |
| Operating leases with USD functional currency |  |  | 3.77 | % |  |  | 3.49 | % |
| Operating leases with Euro functional currency |  |  | 3.70 | % |  |  | 1.22 | % |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-23-005536:notes:237]
Note 10 – Goodwill

[0000950170-23-005536:notes:238]
The changes in the carrying amount of goodwill for the year ended December 31, 2022 are as follows:

[0000950170-23-005536:notes:239]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2021 |  | $ | 6,570 |  |  | $ | 398 |  |  | $ | 6,968 |  |
| Goodwill from Business Combination with ADVA |  |  | 272,797 |  |  |  | 77,661 |  |  |  | 350,458 |  |
| Foreign currency translation adjustments |  |  | 18,913 |  |  |  | 5,385 |  |  |  | 24,298 |  |
| As of December 31, 2022 |  | $ | 298,280 |  |  | $ | 83,444 |  |  | $ | 381,724 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-23-005536:notes:240]
Note 11 – Intangible Assets

[0000950170-23-005536:notes:241]
Intangible assets as of December 31, 2022 and 2021, consisted of the following:

[0000950170-23-005536:notes:242]
|  |  |  |  | 2022 |  |  | 2021 |  |
| (In thousands) | Weighted Average Useful Life(in years) |  |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |
| Customer relationships |  | 10.9 |  |  | $ | 55,517 |  |  | $ | (12,772 | ) |  | $ | 42,745 |  |  | $ | 20,796 |  |  | $ | (9,906 | ) |  | $ | 10,890 |  |
| Backlog |  | 1.6 |  |  |  | 55,782 |  |  |  | (22,725 | ) |  |  | 33,057 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Developed technology |  | 8.5 |  |  |  | 320,364 |  |  |  | (21,856 | ) |  |  | 298,508 |  |  |  | 8,200 |  |  |  | (3,683 | ) |  |  | 4,517 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (3,141 | ) |  |  | 2,759 |  |  |  | 5,900 |  |  |  | (2,486 | ) |  |  | 3,414 |  |
| Licensing agreements |  | 8.5 |  |  |  | 560 |  |  |  | (298 | ) |  |  | 262 |  |  |  | 560 |  |  |  | (225 | ) |  |  | 335 |  |
| Patents |  | 7.3 |  |  |  | 500 |  |  |  | (431 | ) |  |  | 69 |  |  |  | 500 |  |  |  | (363 | ) |  |  | 137 |  |
| Trade names |  | 3.0 |  |  |  | 29,066 |  |  |  | (5,255 | ) |  |  | 23,811 |  |  |  | 210 |  |  |  | (210 | ) |  |  | — |  |
| Total |  |  |  | $ | 467,689 |  |  | $ | (66,478 | ) |  | $ | 401,211 |  |  | $ | 36,166 |  |  | $ | (16,873 | ) |  | $ | 19,293 |  |

[0000950170-23-005536:notes:243]
As part of the purchase price allocation related to the Business Combination with ADVA, the Company recognized $403.8 million of intangible assets on July 15, 2022. Intangible assets are reviewed for impairment whenever events and circumstances indicate impairment may have occurred. The Company assessed impairment triggers related to intangible assets during each financial period in 2022, 2021 and 2020. As a result, no quantitative impairment test of long-lived assets was performed as of December 31, 2022, 2021 and 2020, and no impairment losses of intangible assets were recorded during the years ended December 31, 2022, 2021 and 2020.

[0000950170-23-005536:notes:244]
Amortization expense was $47.3 million, $4.1 million and $4.4 million for the years ended December 31, 2022, 2021 and 2020, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of (Loss) Income.

[0000950170-23-005536:notes:245]
As of December 31, 2022, estimated future amortization expense of intangible assets was as follows:

[0000950170-23-005536:notes:246]
| (In thousands) |  | Amount |  |
| 2023 |  | $ | 82,080 |  |
| 2024 |  |  | 57,545 |  |
| 2025 |  |  | 46,095 |  |
| 2026 |  |  | 42,851 |  |
| 2027 |  |  | 41,491 |  |
| Thereafter |  |  | 131,149 |  |
| Total |  | $ | 401,211 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-005536:notes:247]
Note 12 - Hedging

[0000950170-23-005536:notes:248]
The Company has certain forward rate agreements to hedge foreign currency exposure of expected future cash flows in foreign currency. The Company does not hold or issue derivative instruments for trading or other speculative purposes. Derivatives are initially recognized at fair value on the date a derivative contract is entered into and are subsequently re-measured to their fair value at the end of each reporting period. All changes in the fair value of derivative instruments are recognized as other income (expense) in the Consolidated Statements of Income. The derivative instruments are not subject to master netting agreements and are not offset in the Consolidated Balance Sheets. We are exposed to risk from credit-related losses resulting from nonperformance by counterparties to our financial instruments. We perform credit evaluations of our counterparties under forward exchange contracts and expect all counterparties to meet their obligations. We have not experienced credit losses from our counterparties.
 As of December 31, 2022, the Company had 47 forward rate contracts outstanding.

[0000950170-23-005536:notes:249]
Foreign Currency Hedging Agreement

[0000950170-23-005536:notes:250]
On November 3, 2022, the Company entered into a Euro/U.S. dollar cross-currency swap arrangement (the “Swap”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Swap, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its Euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Swap, the Company will exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of $160.0 million will be divided into eight quarterly tranches of $20.0 million. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Swap may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-23-005536:notes:251]
The fair values of the Company's derivative instruments recorded in the Condensed Consolidated Balance Sheet as of December 31, 2022 were as follows:

[0000950170-23-005536:notes:252]
| (In thousands) |  | Balance Sheet Location |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  | $ | 11,992 |  |  | $ | — |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  | $ | (633 | ) |  | $ | — |  |
| Total derivatives |  |  |  | $ | 11,359 |  |  | $ | — |  |

[0000950170-23-005536:notes:253]
The change in the fair values of the Company's derivative instruments recorded in the Condensed Consolidated Statements of Income during the years ended December 31, 2022, 2021 and 2020 were as follows:

[0000950170-23-005536:notes:254]
| (In thousands) |  | Income StatementLocation |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense), net |  | $ | 10,793 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-005536:notes:255]
Note 13 – Revolving Credit Agreements

[0000950170-23-005536:notes:256]
The carrying amounts of the Company's revolving credit agreements in its Consolidated Balance Sheets were as follows:

[0000950170-23-005536:notes:257]
|  |  | As of December 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Wells Fargo credit agreement |  | $ | 60,000 |  |  | $ | — |  |
| Nord/LB revolving line of credit |  |  | 16,091 |  |  |  | — |  |
| Syndicated credit agreement working capital line of credit |  |  | 10,727 |  |  |  | — |  |
| DZ bank revolving line of credit |  |  | 9,118 |  |  |  | — |  |
| Wells Fargo revolving credit agreement |  |  | — |  |  |  | — |  |
| Cadence revolving credit agreement |  |  | — |  |  |  | — |  |
| Total revolving credit agreements |  | $ | 95,936 |  |  | $ | — |  |

[0000950170-23-005536:notes:258]
As of December 31, 2022, the weighted average interest rate on our revolving credit agreements was 4.12%.

[0000950170-23-005536:notes:259]
Wells Fargo Credit Agreement

[0000950170-23-005536:notes:260]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allows for borrowings of up to $100.0 million in aggregate principal amount, subject to being increased to up to $400.0 million in aggregate principal amount upon the Company or Borrower’s execution of a DPLTA with ADVA or a parent of ADVA, among other conditions (the “Senior Credit Facilities Increase”). The DPLTA as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of ADVA (Jena). See Note 24 of the Notes to Consolidated Financial Statements for further information.

[0000950170-23-005536:notes:261]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

[0000950170-23-005536:notes:262]
As of December 31, 2022, ADTRAN, Inc.’s borrowings under the revolving line of credit were $60.0 million in tranches that mature during the first quarter of 2023 and can either be repaid or borrowed again for a one month, three month or six month period. In addition, we may issue up to $25.0 million in letters of credit against our $100.0 million dollar total facility. As of December 31, 2022, we had a total of $21.3 million in letters of credit with ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $18.7 million available for future borrowings. In February 2023, the borrowings under the Credit Agreement were paid down by $7.5 million, leaving, $180.0 million of borrowings as of February 28, 2023. After considering our outstanding letters of credit, this leaves the Company approximately $198.7 million available for future borrowings as of February 28, 2023. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-23-005536:notes:263]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All EU borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-23-005536:notes:264]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participations in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-23-005536:notes:265]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the consolidated total net leverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the consolidated interest coverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of December 31, 2022, the Company was in compliance with all material covenants. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions.

[0000950170-23-005536:notes:266]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

[0000950170-23-005536:notes:267]
Nord/LB Revolving Line of Credit

[0000950170-23-005536:notes:268]
On August 8, 2022, ADVA entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and which matures in August 2023. During the term of the loan, ADVA is obligated to maintain an adjusted net debt to cover ratio that is equal to or less than 2.75. As of December 31, 2022, The Company was in compliance with the adjusted net debt to cover ratio. As of December 31, 2022, ADVA’s borrowings under the revolving line of credit were $16.1 million, with no amounts available for future borrowings. On January 31, 2023, the Company increased its borrowings under the Wells Fargo Credit Agreement. A portion of the proceeds from the borrowings were used to retire the outstanding borrowings under the Nord/LB revolving line of credit.

[0000950170-23-005536:notes:269]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-23-005536:notes:270]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. The interest rate for the working capital line of credit is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of December 31, 2022. The working capital line of credit matures in September 2023. As of December 31, 2022, borrowings under the working capital line of credit totaled $10.7 million, with no amounts available for future borrowings. On January 31, 2023, the Company increased its borrowings under the Wells Fargo Credit Agreement. A portion of the proceeds from the borrowings were used to retire the outstanding borrowings under the syndicated credit agreement working capital line of credit.

[0000950170-23-005536:notes:271]
DZ Bank Money Market Facility

[0000950170-23-005536:notes:272]
As of December 31, 2022, ADVA’s borrowings under the revolving line of credit totaled $9.1 million, with no amounts available for future borrowings. The interest rate is currently a rate of 2.8%, which resets monthly based on renewal of the loan.

[0000950170-23-005536:notes:273]
Prior Wells Fargo Revolving Credit Agreement

[0000950170-23-005536:notes:274]
On April 1, 2022, ADTRAN, Inc. entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Prior Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provided the Company with a $25.0 million secured revolving credit facility. During the year ended December 31, 2022, the Company made draws totaling $10.0 million under the Prior Wells Revolving Credit Agreement all of which had been repaid as of December 31, 2022. The Wells Fargo Credit Agreement replaced the Prior Wells Fargo Revolving Credit Agreement and all outstanding borrowings have been repaid and the prior agreement was terminated.

[0000950170-23-005536:notes:275]
Prior Cadence Revolving Credit Agreement

[0000950170-23-005536:notes:276]
On May 19, 2022, ADTRAN, Inc., as borrower, modified its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The modified Prior Cadence Revolving Credit Agreement provided the Company with a $25.0 million secured revolving credit facility. During the year ended December 31, 2022, the Company made draws totaling $18.0 million under the Prior Cadence Revolving Credit Agreement all of which had been repaid as of December 31, 2022. The Wells Fargo Credit Agreement replaced the Prior Cadence Revolving Credit Agreement and all outstanding borrowings have been repaid and the prior agreement was terminated.


## adtn:NotesPayableDisclosureTextBlock

[0000950170-23-005536:notes:277]
Note 14 – Notes Payable

[0000950170-23-005536:notes:278]
The carrying amounts of the Company's notes payable in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-23-005536:notes:279]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | December 31, 2022 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Syndicated credit agreement note payable |  | $ | 24,598 |  |  | $ | 24,598 |  |  | $ | — |  |
| Deutsche Bank term loan |  |  | — |  |  |  | — |  |  |  | — |  |
| Total Notes Payable |  | $ | 24,598 |  |  | $ | 24,598 |  |  | $ | — |  |

[0000950170-23-005536:notes:280]
Syndicated Credit Agreement Note Payable

[0000950170-23-005536:notes:281]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. As of December 31, 2022, the amount outstanding under the note payable is $24.6 million. The interest rate for the note payable is adjusted periodically based on a defined leverage ratio and is currently 2.49% as of December 31, 2022. The note payable matures in September 2023.

[0000950170-23-005536:notes:282]
Deutsche Bank Term Loan

[0000950170-23-005536:notes:283]
In October 2019, ADVA entered into a $9.8 million term loan with Deutsche Bank that bears interest of EURIBOR plus 1.1%. The term loan matured in September 2022 and was repaid as of December 31, 2022.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-005536:notes:284]
Note 15 – Income Taxes

[0000950170-23-005536:notes:285]
The components of income tax expense (benefit) for the years ended December 31, 2022, 2021 and 2020 are as follows:

[0000950170-23-005536:notes:286]
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Current |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 4,572 |  |  | $ | 11 |  |  | $ | (10,574 | ) |
| State |  |  | 88 |  |  |  | (63 | ) |  |  | (329 | ) |
| International |  |  | (4,347 | ) |  |  | 4,166 |  |  |  | 3,635 |  |
| Total Current |  |  | 313 |  |  |  | 4,114 |  |  |  | (7,268 | ) |
| Deferred |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (47,429 | ) |  |  | — |  |  |  | — |  |
| State |  |  | (6,776 | ) |  |  | — |  |  |  | — |  |
| International |  |  | (8,183 | ) |  |  | (1,784 | ) |  |  | (1,356 | ) |
| Total Deferred |  |  | (62,388 | ) |  |  | (1,784 | ) |  |  | (1,356 | ) |
| Total Income Tax (Benefit) Expense |  | $ | (62,075 | ) |  | $ | 2,330 |  |  | $ | (8,624 | ) |

[0000950170-23-005536:notes:287]
The effective income tax rate differs from the federal statutory rate due to the following:

[0000950170-23-005536:notes:288]
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Tax provision computed at the federal statutory rate |  |  | 21.00 | % |  |  | 21.00 | % |  |  | 21.00 | % |
| State income tax provision, net of federal benefit |  |  | 2.60 |  |  |  | 13.33 |  |  |  | 11.10 |  |
| Federal research credits |  |  | 6.74 |  |  |  | 53.77 |  |  |  | 57.63 |  |
| Foreign taxes |  |  | 6.29 |  |  |  | (4.69 | ) |  |  | (17.83 | ) |
| Tax-exempt income |  |  | 0.21 |  |  |  | 3.75 |  |  |  | 1.93 |  |
| Change in valuation allowance |  |  | 63.92 |  |  |  | (75.26 | ) |  |  | 44.79 |  |
| Non-deductible transaction costs |  |  | (2.74 | ) |  |  | (39.48 | ) |  |  | — |  |
| Foreign tax credits |  |  | (0.40 | ) |  |  | 0.14 |  |  |  | 17.90 |  |
| Stock-based compensation |  |  | (2.09 | ) |  |  | 10.74 |  |  |  | (23.36 | ) |
| Withholding taxes |  |  | 0.03 |  |  |  | 0.14 |  |  |  | (20.83 | ) |
| Alabama law change |  |  | — |  |  |  | (25.39 | ) |  |  | — |  |
| Impact of CARES Act |  |  | — |  |  |  | — |  |  |  | 45.65 |  |
| Return to accrual |  |  | 0.24 |  |  |  | 9.48 |  |  |  | — |  |
| Global intangible low-taxed income ("GILTI") |  |  | (8.08 | ) |  |  | (4.29 | ) |  |  | (0.49 | ) |
| Other, net |  |  | (0.24 | ) |  |  | (0.19 | ) |  |  | 0.56 |  |
| Effective Tax Rate |  |  | 87.48 | % |  |  | (36.95 | )% |  |  | 138.05 | % |

[0000950170-23-005536:notes:289]
(Loss) income before expense (benefit) for income taxes for the years ended December 31, 2022, 2021 and 2020 is as follows:

[0000950170-23-005536:notes:290]
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| U.S. entities |  | $ | (33,720 | ) |  | $ | (14,982 | ) |  | $ | (12,833 | ) |
| International entities |  |  | (37,243 | ) |  |  | 8,677 |  |  |  | 6,587 |  |
| Total |  | $ | (70,963 | ) |  | $ | (6,305 | ) |  | $ | (6,246 | ) |

[0000950170-23-005536:notes:291]
(Loss) income before expense (benefit) for income taxes for international entities reflects (loss) income based on statutory transfer pricing agreements. This amount does not correlate to consolidated international revenue, which occurs from our U.S. entity.

[0000950170-23-005536:notes:292]
Deferred income taxes on the Consolidated Balance Sheets result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The significant components of current and non-current deferred taxes as of December 31, 2022 and 2021 consist of the following:

[0000950170-23-005536:notes:293]
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Inventory |  | $ | 5,818 |  |  | $ | 9,538 |  |
| Accrued expenses |  |  | 7,865 |  |  |  | 3,851 |  |
| Deferred compensation |  |  | 5,792 |  |  |  | 7,027 |  |
| Stock-based compensation |  |  | 1,373 |  |  |  | 1,469 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 102 |  |  |  | 124 |  |
| Pensions |  |  | 5,952 |  |  |  | 6,061 |  |
| Foreign losses |  |  | 4,744 |  |  |  | 2,862 |  |
| State losses and credit carry-forwards |  |  | 3,516 |  |  |  | 5,914 |  |
| Federal loss and research carry-forwards |  |  | 64,995 |  |  |  | 21,606 |  |
| Lease liabilities |  |  | 4,093 |  |  |  | 1,471 |  |
| Capitalized research and development expenditures |  |  | 31,248 |  |  |  | 9,349 |  |
| Investments |  |  | 160 |  |  |  | — |  |
| Valuation allowance |  |  | (5,201 | ) |  |  | (50,564 | ) |
| Total Deferred Tax Assets |  |  | 130,457 |  |  |  | 18,708 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Property, plant and equipment |  |  | (8,982 | ) |  |  | (3,590 | ) |
| Intellectual property |  |  | (108,671 | ) |  |  | (3,230 | ) |
| Right of use lease assets |  |  | (6,594 | ) |  |  | (1,459 | ) |
| Investments |  |  | — |  |  |  | (1,350 | ) |
| Total Deferred Tax Liabilities |  |  | (124,247 | ) |  |  | (9,629 | ) |
| Net Deferred Tax Assets |  | $ | 6,210 |  |  | $ | 9,079 |  |

[0000950170-23-005536:notes:294]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was signed into law. Subsequently, the Internal Revenue Service (“IRS”) released its final GILTI regulations on July 9, 2020. The passage of the CARES Act and subsequent issuance of the GILTI final regulations together resulted in the Company’s recognition of a tax benefit in the amount of $10.8 million during 2020, $7.9 million of which related to the utilization of deferred tax assets which had previously been offset with a valuation allowance and $2.9 million primarily related to the tax rate differential on carrying back losses from 2018 and 2019 tax years to prior years in which the U.S. Corporate tax rate was 35% versus the current 21% federal tax rate.

[0000950170-23-005536:notes:295]
On February 12, 2021, the Alabama Business Tax Competitiveness Act (the "Act") was signed into law. As a result of the Act, we recognized an expense of $1.6 million in the three months ended March 31, 2021 related to the revaluation of our deferred tax assets, which was offset by changes in our valuation allowance previously recorded against our domestic deferred tax assets.

[0000950170-23-005536:notes:296]
During the three months ended September 30, 2021, Management decided to pursue a claim for refund related to the revocation of our IRC Section 59(e) election that was made on our originally filed 2018 U.S. federal tax return. The Company filed a related carryback claim of net operating losses generated in 2018 to prior years as allowed under the CARES Act that was passed in 2020. An IRS Section 59(e) election is generally non-revocable except in cases for which IRS Commissioner’s approval is given. Approval is granted only in rare and unusual circumstances. We filed a private letter ruling (“PLR”) request to revoke our election. During the three months ended December 31, 2021, a response to our PLR was published denying our request to revoke the previously made 59(e). As a result of these filings, and Management’s position to pursue them through appeals, we have established a receivable in the amount of $15.2 million and a deferred tax asset related to additional research and development credit carryforward in the amount of $1.8 million that would be available if our revocation request is successful, offset with an uncertain tax liability of $17.0 million.

[0000950170-23-005536:notes:297]
As of December 31, 2022 and 2021, non-current deferred taxes reflected deferred taxes on net unrealized gains and losses on available-for-sale investments and deferred taxes on unrealized losses in our pension plan. The net change in non-current deferred taxes associated with these items, which resulted in a deferred tax expense of $2.0 million and $1.6 million in 2022 and 2021, respectively, was recorded as an adjustment to other comprehensive (loss) income, presented in the Consolidated Statements of Comprehensive (Loss) Income.

[0000950170-23-005536:notes:298]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. Our assessment of the realizability of our deferred tax assets includes the evaluation of evidence, some of which requires significant judgment, including historical operating results, the evaluation of a three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and additional valuation allowance or a partial or full release of the valuation allowance become necessary, it could have a material effect on our consolidated financial statements. During the fourth quarter of 2022, after considering all quantitative and qualitative evidence, including our cumulative income position, historical operating performance and future income projections, we have determined that the positive evidence overcame the negative evidence and have concluded that it is more likely than not that a substantial portion of our U.S. federal and certain other state deferred tax assets were realizable. As a result we have released the majority of our valuation allowance against those assets.

[0000950170-23-005536:notes:299]
As of December 31, 2022 and 2021, the Company had gross deferred tax assets totaling $11.4 million offset by a valuation allowance totaling $5.2 million and gross deferred tax assets totaling $59.6 million offset by a valuation allowance of $50.6 million, respectively. Of the current valuation allowance, $3.2 million was established against our domestic deferred tax assets and the remaining $2.0 million is related to foreign net operating loss and research and development credit carryforwards where we lacked sufficient activity to realize those deferred tax assets. The change in our valuation allowance for the year ending December 31, 2022 was a decrease of $45.4 million. The change in the valuation allowance was primarily related to the previously mentioned release of the valuation allowance in the fourth quarter of 2022. The large increase during the year in our international deferred tax liabilities was primarily related to purchase price accounting, partially offset with acquired deferred tax assets as a result of the ADVA acquisition, that was completed in the third quarter of 2022.

[0000950170-23-005536:notes:300]
Supplemental balance sheet information related to deferred tax assets (liabilities) as of December 31, 2022 and 2021 were as follows:

[0000950170-23-005536:notes:301]
|  |  | December 31, 2022 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Assets (Liabilities), net |  |
| Domestic |  | $ | 61,726 |  |  | $ | (3,177 | ) |  | $ | 58,549 |  |
| International |  |  | (50,315 | ) |  |  | (2,024 | ) |  |  | (52,339 | ) |
| Total |  | $ | 11,411 |  |  | $ | (5,201 | ) |  | $ | 6,210 |  |

[0000950170-23-005536:notes:302]
|  |  | December 31, 2021 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 48,265 |  |  | $ | (48,265 | ) |  | $ | — |  |
| International |  |  | 11,378 |  |  |  | (2,299 | ) |  |  | 9,079 |  |
| Total |  | $ | 59,643 |  |  | $ | (50,564 | ) |  | $ | 9,079 |  |

[0000950170-23-005536:notes:303]
As of December 31, 2022 and 2021, the deferred tax assets for foreign and domestic loss carry-forwards, research and development tax credits, unamortized research and development costs and state credit carry-forwards totaled $104.5 million and $39.7 million, respectively. As of December 31, 2022, $21.8 million of these deferred tax assets will expire at various times between 2023 and 2038. The remaining deferred tax assets will either amortize through 2038 or carryforward indefinitely.

[0000950170-23-005536:notes:304]
As of December 31, 2022 and 2021, respectively, our cash and cash equivalents were $108.6 million and $56.6 million and short-term investments were $0.3 million and $0.4 million, which provided available short-term liquidity of $108.9 million and 57.0 million. Of these amounts, our foreign subsidiaries held cash of $86.3 million and $47.7 million, respectively, representing approximately 79% and 84% of available short-term liquidity, which is used to fund ongoing liquidity needs of these subsidiaries. As part of our restructuring plan, the Company’s assertion on being indefinitely reinvested changed in a particular jurisdiction in a previous year. The Company has a withholding tax liability of $0.4 million and $0.7 million as of December 31, 2022 and 2021, respectively. The Company maintains its assertion in all other jurisdictions that it is indefinitely reinvesting its funds held in foreign jurisdictions outside of the U.S., except to the extent any of these funds can be repatriated without withholding tax. However, if all of these funds were repatriated to the U.S., or used for U.S. operations, certain amounts could be subject to tax. Due to the timing and circumstances of repatriation of such earnings, if any, it is not practicable to determine the amount of funds subject to unrecognized deferred tax liability.

[0000950170-23-005536:notes:305]
During 2022, 2021 and 2020, no income tax benefit or expense was recorded for stock options exercised as an adjustment to equity.

[0000950170-23-005536:notes:306]
The change in the unrecognized income tax benefits for the years ended December 31, 2022, 2021 and 2020 were as follows:

[0000950170-23-005536:notes:307]
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 17,836 |  |  | $ | 1,078 |  |  | $ | 1,487 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | 17,025 |  |  |  | 4 |  |
| Current year |  |  | 123 |  |  |  | 136 |  |  |  | 165 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | (13 | ) |  |  | (27 | ) |  |  | — |  |
| Expiration of applicable statute of limitations |  |  | (61 | ) |  |  | (376 | ) |  |  | (578 | ) |
| Balance at end of period |  | $ | 17,885 |  |  | $ | 17,836 |  |  | $ | 1,078 |  |

[0000950170-23-005536:notes:308]
As of December 31, 2022, 2021 and 2020, our total liability for unrecognized tax benefits was $17.9 million, $17.8 million and $1.1 million, respectively, of which $17.9 million, $17.8 million and $1.0 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of December 31, 2022, 2021 and 2020, the balances of accrued interest and penalties were $0.1 million, $0.2 million and $0.3 million, respectively.

[0000950170-23-005536:notes:309]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date, unless a resolution is reached regarding the appeal of our PLR denial noted above. We file income tax returns in the U.S. for federal and various state jurisdictions and several foreign jurisdictions. We are not currently under audit by the Internal Revenue Service. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2018.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-23-005536:notes:310]
Note 16 – Employee Benefit Plans

[0000950170-23-005536:notes:311]
Pension Benefit Plan

[0000950170-23-005536:notes:312]
We maintain a defined benefit pension plan covering employees in certain foreign countries.

[0000950170-23-005536:notes:313]
In connection with the Business Combination, we acquired $29.6 million of additional obligations and $22.3 million of assets related to postemployment benefit plans for certain groups of employees at our new operations outside of the U.S. Plans vary depending on the legal, economic, and tax environments of the respective country. For defined benefit plans, accruals for pensions and similar commitments have been included in the results for this year. The new defined benefit plans are for employees in Switzerland, Italy, Israel and India:

[0000950170-23-005536:notes:314]
•
In Switzerland, there are two defined benefit pension plans. Both plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service, salary and on a participants old age account. The plans are financed by contributions paid by the participants and by the Company.

[0000950170-23-005536:notes:315]
•
In Italy, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis. Employees receive their pension payments as a function of salary, inflation and a notional account.

[0000950170-23-005536:notes:316]
•
In Israel, there is a defined benefit pension plan that provides benefits in the event of a participant being dismissed involuntarily, retirement or death. The plan's benefits are based on the higher of the severance benefit required by law or the cash surrender value of the severance benefit component of any qualifying insurance policy or long-term employee benefit fund that is registered in the participants name. The plan is financed by contributions paid by the Company.

[0000950170-23-005536:notes:317]
•
In India, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis.

[0000950170-23-005536:notes:318]
The pension benefit plan obligations and funded status as of December 31, 2022 and 2021, were as follows:

[0000950170-23-005536:notes:319]
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 73,779 |  | (1) | $ | 50,927 |  |
| Service cost |  |  | 1,426 |  |  |  | 1,229 |  |
| Interest cost |  |  | 1,168 |  |  |  | 339 |  |
| Actuarial gain - experience |  |  | (2,039 | ) |  |  | (750 | ) |
| Actuarial gain - assumptions |  |  | (11,128 | ) |  |  | (3,327 | ) |
| Benefit payments |  |  | (1,400 | ) |  |  | (756 | ) |
| Effects of foreign currency exchange rate changes |  |  | (2,462 | ) |  |  | (3,498 | ) |
| Projected benefit obligation at end of period |  |  | 59,344 |  |  |  | 44,164 |  |
| Change in plan assets: |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  |  | 55,084 |  | (1) |  | 32,263 |  |
| Actual (loss) gain on plan assets |  |  | (4,372 | ) |  |  | 2,943 |  |
| Contributions |  |  | 382 |  |  |  | — |  |
| Effects of foreign currency exchange rate changes |  |  | (2,374 | ) |  |  | (2,444 | ) |
| Fair value of plan assets at end of period |  |  | 48,720 |  |  |  | 32,762 |  |
| Unfunded status at end of period |  | $ | (10,624 | ) |  | $ | (11,402 | ) |

[0000950170-23-005536:notes:320]
(1)
In connection with the Business Combination, we acquired $29.6 million of additional projected benefit obligations and.$22.3 million of plan assets whose beginning of period measurement date is July 15, 2022.

[0000950170-23-005536:notes:321]
The accumulated benefit obligation was $56.8 million and $44.2 million as of December 31, 2022 and 2021, respectively. The decrease in the accumulated benefit obligation, projected benefit obligation and the actuarial loss was primarily attributable to an increase in the discount rate during 2022.

[0000950170-23-005536:notes:322]
The net amounts recognized in the Consolidated Balance Sheets for the unfunded pension liability as of December 31, 2022 and 2021 were as follows:

[0000950170-23-005536:notes:323]
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Current liability |  | $ | — |  |  | $ | — |  |
| Pension liability |  |  | 10,624 |  |  |  | 11,402 |  |
| Total |  | $ | 10,624 |  |  | $ | 11,402 |  |

[0000950170-23-005536:notes:324]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Consolidated Statements of (Loss) Income. The components of net periodic pension cost and amounts recognized in other comprehensive (loss) income for the years ended December 31, 2022, 2021 and 2020 were as follows:

[0000950170-23-005536:notes:325]
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,426 |  |  | $ | 1,229 |  |  | $ | 1,270 |  |
| Interest cost |  |  | 1,168 |  |  |  | 339 |  |  |  | 444 |  |
| Expected return on plan assets |  |  | (2,129 | ) |  |  | (1,842 | ) |  |  | (1,679 | ) |
| Amortization of actuarial losses |  |  | 355 |  |  |  | 1,088 |  |  |  | 970 |  |
| Net periodic benefit cost |  |  | 820 |  |  |  | 814 |  |  |  | 1,005 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive (loss) income: |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | (6,549 | ) |  |  | (4,984 | ) |  |  | 1,784 |  |
| Amortization of actuarial losses |  |  | (113 | ) |  |  | (825 | ) |  |  | (1,212 | ) |
| Amount recognized in other comprehensive (loss) income |  |  | (6,662 | ) |  |  | (5,809 | ) |  |  | 572 |  |
| Total recognized in net periodic benefit cost and other comprehensive (loss) income |  | $ | (5,842 | ) |  | $ | (4,995 | ) |  | $ | 1,577 |  |

[0000950170-23-005536:notes:326]
The amounts recognized in accumulated other comprehensive (loss) income as of December 31, 2022 and 2021 were as follows:

[0000950170-23-005536:notes:327]
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Net actuarial loss |  | $ | (1,073 | ) |  | $ | (7,736 | ) |

[0000950170-23-005536:notes:328]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our plans assets is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations.

[0000950170-23-005536:notes:329]
The weighted-average assumptions that were used to determine the net periodic benefit cost for the years ended December 31, 2022, 2021 and 2020 were as follows:

[0000950170-23-005536:notes:330]
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Discount rate |  |  | 3.24 | % |  |  | 1.16 | % |  |  | 1.00 | % |
| Rate of compensation increase |  |  | 2.17 | % |  |  | 2.00 | % |  |  | 2.00 | % |
| Expected long-term rates of return |  |  | 4.65 | % |  |  | 5.90 | % |  |  | 5.90 | % |

[0000950170-23-005536:notes:331]
The weighted-average assumptions that were used to determine the benefit obligation as of December 31, 2022 and 2021:

[0000950170-23-005536:notes:332]
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Discount rate |  |  | 3.10 | % |  |  | 1.16 | % |  |  | 0.69 | % |
| Rate of compensation increase |  |  | 2.17 | % |  |  | 2.00 | % |  |  | 2.00 | % |

[0000950170-23-005536:notes:333]
Actuarial gains and losses are recorded in accumulated other comprehensive (loss) income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants.

[0000950170-23-005536:notes:334]
The Company anticipates making approximately $1.8 million in contributions to the pension plans in 2023

[0000950170-23-005536:notes:335]
The following pension benefit payments, which reflect expected future service, as appropriate, are expected to be paid to participants:

[0000950170-23-005536:notes:336]
| (In thousands) |  |  |  |
| 2023 |  | $ | 2,377 |  |
| 2024 |  |  | 2,303 |  |
| 2025 |  |  | 3,331 |  |
| 2026 |  |  | 3,092 |  |
| 2027 |  |  | 3,710 |  |
| 2028 - 2032 |  |  | 18,287 |  |
| Total |  | $ | 33,100 |  |

[0000950170-23-005536:notes:337]
•
Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-23-005536:notes:338]
We have categorized our cash equivalents and our investments held at fair value into this hierarchy as follows:

[0000950170-23-005536:notes:339]
|  |  | Fair Value Measurements at December 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash and cash equivalents |  | $ | 1,423 |  |  | $ | 1,423 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,256 |  |  |  | 13,256 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 5,490 |  |  |  | 5,490 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Global equity |  |  | 15,452 |  |  |  | 15,452 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 5,190 |  |  |  | 5,190 |  |  |  | — |  |  |  | — |  |
| Emerging markets |  |  | 1,707 |  |  |  | 1,707 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 194 |  |  |  | 194 |  |  |  | — |  |  |  | — |  |
| Global real estate fund |  |  | 6,008 |  |  |  | 6,008 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 47,297 |  |  |  | 47,297 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 48,720 |  |  | $ | 48,720 |  |  | $ | — |  |  | $ | — |  |

[0000950170-23-005536:notes:340]
|  |  | Fair Value Measurements at December 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash and cash equivalents |  | $ | 801 |  |  | $ | 801 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 7,528 |  |  |  | 7,528 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 5,721 |  |  |  | 5,721 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |
| Global equity |  |  | 12,170 |  |  |  | 12,170 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 2,919 |  |  |  | 2,919 |  |  |  | — |  |  |  | — |  |
| Emerging markets |  |  | 2,259 |  |  |  | 2,259 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 235 |  |  |  | 235 |  |  |  | — |  |  |  | — |  |
| Global real estate fund |  |  | 1,129 |  |  |  | 1,129 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 31,961 |  |  |  | 31,961 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 32,762 |  |  | $ | 32,762 |  |  | $ | — |  |  | $ | — |  |

[0000950170-23-005536:notes:341]
Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies.

[0000950170-23-005536:notes:342]
The investment policy is periodically reviewed by the Company and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations.

[0000950170-23-005536:notes:343]
401(k) Savings Plan

[0000950170-23-005536:notes:344]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (the “Savings Plan”) for the benefit of eligible employees. The Savings Plan is intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (the “Code”), and is intended to be a “safe harbor” 401(k) plan under Code Section 401(k)(12). The Savings Plan allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plan also requires us to contribute a “safe harbor” amount each year. We match up to 4% of employee contributions (100% of an employee’s first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s one-year anniversary date. In calculating our matching contribution, compensation up to the statutory maximum under the Code is used ($305,000 for 2022). All matching contributions under the Savings Plan vest immediately. Employer contribution expense and plan administration costs for the Savings Plan amounted to approximately $4.1 million, $3.9 million and $4.0 million in 2022, 2021 and 2020, respectively.

[0000950170-23-005536:notes:345]
Deferred Compensation Plans

[0000950170-23-005536:notes:346]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors.

[0000950170-23-005536:notes:347]
The ADTRAN, Inc. Deferred Compensation Program for Employees is offered as a supplement to our tax-qualified 401(k) plan and is available to certain executive management employees who have been designated by our Board of Directors. This deferred compensation plan allows participants to defer all or a portion of certain specified bonuses and up to 25% of remaining cash compensation and permits us to make matching contributions on a discretionary basis without the limitations that apply to the 401(k) plan. To date, we have not made any matching contributions under this plan. We also maintain the ADTRAN, Inc. Equity Deferral Program for Employees. Under this plan, participants may elect to defer all or a portion of their vested PSUs and RSUs to the plan. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the participant.

[0000950170-23-005536:notes:348]
For our Board of Directors, we maintain the ADTRAN, Inc. Deferred Compensation Program for Directors. This program allows our Board of Directors to defer all or a portion of monetary remuneration paid to the Director, including, but not limited to, meeting fees and annual retainers. We also maintain the ADTRAN, Inc. Equity Deferral Program for Directors. Under this plan, participants may elect to defer all or a portion of their vested restricted stock awards. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the director.

[0000950170-23-005536:notes:349]
We have set aside the plan assets for all plans in a rabbi trust (the “Trust”) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant and the participant’s bookkeeping account is credited with the earnings and losses attributable to those investments. Benefits are scheduled to be distributed six months after termination of employment in a single lump sum payment or annual installments paid over a three or ten-year term based on the participant’s election. Distributions will be made on a pro-rata basis from each of the hypothetical investments of the participant’s account in cash. Any whole shares of ADTRAN, Inc. common stock that are distributed will be distributed in-kind.

[0000950170-23-005536:notes:350]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging from equities to money market instruments. These mutual funds are publicly quoted and reported at fair value. The fair value of the assets held by the Trust and the amounts payable to the plan participants as of December 31, 2022 and 2021 were as follows:

[0000950170-23-005536:notes:351]
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |
| Long-term investments |  | $ | 22,943 |  |  | $ | 26,935 |  |
| Total Fair Value of Plan Assets |  | $ | 22,943 |  |  | $ | 26,935 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |
| Deferred compensation liability |  | $ | 26,668 |  |  | $ | 31,383 |  |
| Total Amounts Payable to Plan Participants |  | $ | 26,668 |  |  | $ | 31,383 |  |

[0000950170-23-005536:notes:352]
The Trust held $3.7 million and $4.1 million of common stock in the Company as of December 31, 2022 and 2021, respectively. Shares of the Company held by the Trust are recorded at cost and classified as treasury stock on the Consolidated Balance Sheet.

[0000950170-23-005536:notes:353]
Interest and dividend income of the Trust are included in interest and dividend income in the accompanying 2022, 2021 and 2020 Consolidated Statements of (Loss) Income. Changes in the fair value of the plan assets held by the Trust have been included in other income (expense) in the accompanying 2022, 2021 and 2020 Consolidated Statements of (Loss) Income. Changes in the fair value of the deferred compensation liability are included as selling, general and administrative expense in the accompanying 2022, 2021 and 2020 Consolidated Statements of (Loss) Income. Based on the changes in the total fair value of the Trust’s assets, the Company recorded deferred compensation income in 2022, 2021 and 2020 of $6.3 million, $0.9 million and $4.3 million, respectively.

[0000950170-23-005536:notes:354]
Retiree Medical Coverage

[0000950170-23-005536:notes:355]
Medical, dental and prescription drug coverage is provided to certain spouses and former spouses of current and former officers on the same terms as provided to our active officers for up to 30 years. As of December 31, 2022 and 2021, this liability totaled $0.2 million and $0.3 million, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-23-005536:notes:356]
Note 17 – Equity

[0000950170-23-005536:notes:357]
The following table presents changes in accumulated other comprehensive (loss) income, net of tax, by components of accumulated other comprehensive (loss) income for the years ended December 31, 2022, 2021 and 2020:

[0000950170-23-005536:notes:358]
| (In thousands) |  | UnrealizedGains (Losses)on Available-for-SaleSecurities |  |  | DefinedBenefit PlanAdjustments |  |  | ForeignCurrencyAdjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| Balance as of December 31, 2019 |  | $ | (284 | ) |  | $ | (9,226 | ) |  | $ | (7,292 | ) |  | $ | 385 |  |  | $ | (16,417 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | 749 |  |  |  | (1,231 | ) |  |  | 4,857 |  |  |  | — |  |  |  | 4,375 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (433 | ) |  |  | 836 |  |  |  | — |  |  |  | — |  |  |  | 403 |  |
| Balance as of December 31, 2020 |  |  | 32 |  |  |  | (9,621 | ) |  |  | (2,435 | ) |  |  | 385 |  |  |  | (11,639 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (705 | ) |  |  | 3,439 |  |  |  | (3,699 | ) |  |  | — |  |  |  | (965 | ) |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | 121 |  |  |  | 569 |  |  |  | — |  |  |  | — |  |  |  | 690 |  |
| Balance as of December 31, 2021 |  |  | (552 | ) |  |  | (5,613 | ) |  |  | (6,134 | ) |  |  | 385 |  |  |  | (11,914 | ) |
| Other comprehensive (loss) income before reclassifications |  |  | (41 | ) |  |  | 4,519 |  |  |  | 53,396 |  |  |  | — |  |  |  | 57,874 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (243 | ) |  |  | 78 |  |  |  | — |  |  |  | — |  |  |  | (165 | ) |
| Net current period other comprehensive (loss) income |  |  | (284 | ) |  |  | 4,597 |  |  |  | 53,396 |  |  |  | — |  |  |  | 57,709 |  |
| Less: Comprehensive Loss attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | (918 | ) |  |  | — |  |  |  | (918 | ) |
| Balance as of December 31, 2022 |  | $ | (836 | ) |  | $ | (1,016 | ) |  | $ | 48,180 |  |  | $ | 385 |  |  | $ | 46,713 |  |

[0000950170-23-005536:notes:359]
(1)
With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings.

[0000950170-23-005536:notes:360]
The following tables present the details of reclassifications out of accumulated other comprehensive (loss) income for the years ended December 31, 2022, 2021 and 2020:

[0000950170-23-005536:notes:361]
| (In thousands) |  | For the year ended December 31, |  |  |  |
| Details about Accumulated Other Comprehensive (Loss)Income Components |  | 2022 |  |  | 2021 |  |  | 2020 |  |  | Affected Line Item in theStatement Where Net (Loss) Income Is Presented |
| Unrealized (loss) gains on available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | 328 |  |  | $ | (164 | ) |  | $ | 585 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (113 | ) |  |  | (825 | ) |  |  | (1,212 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 215 |  |  |  | (989 | ) |  |  | (627 | ) |  |  |
| Tax (benefit) expense |  |  | (50 | ) |  |  | 299 |  |  |  | 224 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 165 |  |  | $ | (690 | ) |  | $ | (403 | ) |  |  |

[0000950170-23-005536:notes:362]
(1)
Included in the computation of net periodic pension cost. See Note 16 for additional information.

[0000950170-23-005536:notes:363]
The following tables present the tax effects related to the change in each component of other comprehensive (loss) income for the years ended December 31, 2022, 2021 and 2020:

[0000950170-23-005536:notes:364]
|  |  | 2022 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (55 | ) |  | $ | 14 |  |  | $ | (41 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | (328 | ) |  |  | 85 |  |  |  | (243 | ) |
| Defined benefit plan adjustments |  |  | 6,549 |  |  |  | (2,030 | ) |  |  | 4,519 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 113 |  |  |  | (35 | ) |  |  | 78 |  |
| Foreign currency translation adjustment |  |  | 53,396 |  |  |  | — |  |  |  | 53,396 |  |
| Total Other Comprehensive (Loss) Income |  | $ | 59,675 |  |  | $ | (1,966 | ) |  | $ | 57,709 |  |

[0000950170-23-005536:notes:365]
|  |  | 2021 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (953 | ) |  | $ | 248 |  |  | $ | (705 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 164 |  |  |  | (43 | ) |  |  | 121 |  |
| Defined benefit plan adjustments |  |  | 4,984 |  |  |  | (1,545 | ) |  |  | 3,439 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 825 |  |  |  | (256 | ) |  |  | 569 |  |
| Foreign currency translation adjustment |  |  | (3,699 | ) |  |  | — |  |  |  | (3,699 | ) |
| Total Other Comprehensive (Loss) Income |  | $ | 1,321 |  |  | $ | (1,596 | ) |  | $ | (275 | ) |

[0000950170-23-005536:notes:366]
|  |  | 2020 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 1,012 |  |  | $ | (263 | ) |  | $ | 749 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) income |  |  | (585 | ) |  |  | 152 |  |  |  | (433 | ) |
| Defined benefit plan adjustments |  |  | (1,784 | ) |  |  | 553 |  |  |  | (1,231 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) income |  |  | 1,212 |  |  |  | (376 | ) |  |  | 836 |  |
| Foreign currency translation adjustment |  |  | 4,857 |  |  |  | — |  |  |  | 4,857 |  |
| Total Other Comprehensive (Loss) Income |  | $ | 4,712 |  |  | $ | 66 |  |  | $ | 4,778 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-005536:notes:367]
Note 18 – Segment Information and Major Customers

[0000950170-23-005536:notes:368]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support.

[0000950170-23-005536:notes:369]
The Network Solutions segment includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions. The Company's cloud-managed Wi-Fi gateways, virtualization software, and switches provide a mix of wired and wireless connectivity at the customer premises. In addition, its Carrier Ethernet products support a variety of applications at the network edge ranging from mobile backhaul to connecting enterprise customers (“Subscriber Solutions"). The Company's portfolio includes products for multi-gigabit service delivery over fiber or alternative media to homes and businesses.

[0000950170-23-005536:notes:370]
The Services & Support segment offers a comprehensive portfolio of network design, implementation, maintenance and cloud-hosted services supporting its Subscriber, Access and Aggregation, and Optical Networking Solutions. These services assist operators in the deployment of multi-vendor networks while reducing their cost to maintain these networks. The cloud-hosted services include a suite of SaaS applications under the Company's Mosaic One platform that manages end-to-end network and service optimization for both fiber access infrastructure and mesh Wi-Fi connectivity. The Company backs these services with a global support organization that offers on-site and off-site support services with varying SLAs.

[0000950170-23-005536:notes:371]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment (loss) gain, other income, net and income tax benefit (expense) are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-23-005536:notes:372]
The following table presents information about revenue and gross profit of our reportable segments for each of the years ended December 31, 2022, 2021 and 2020:

[0000950170-23-005536:notes:373]
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 916,793 |  |  | $ | 269,688 |  |  | $ | 498,834 |  |  | $ | 190,993 |  |  | $ | 438,015 |  |  | $ | 193,789 |  |
| Services & Support |  |  | 108,743 |  |  |  | 57,564 |  |  |  | 64,170 |  |  |  | 27,384 |  |  |  | 68,495 |  |  |  | 23,762 |  |
| Total |  | $ | 1,025,536 |  |  | $ | 327,252 |  |  | $ | 563,004 |  |  | $ | 218,377 |  |  | $ | 506,510 |  |  | $ | 217,551 |  |

[0000950170-23-005536:notes:374]
For the years ended December 31, 2022, 2021 and 2020, $3.2 million, $1.2 million and $1.4 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the years ended December 31, 2022, 2021 and 2020, $10 thousand, $14 thousand and $32 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0000950170-23-005536:notes:375]
In addition to its reportable segments, revenue is also reported for the following three categories – Subscriber Solutions, Access & Aggregation Solutions, and Optical Networking Solutions.

[0000950170-23-005536:notes:376]
Prior to the Business Combination with ADVA on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with ADVA, the Company has recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable ADVA solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable ADVA solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of ADVA’s portfolio.

[0000950170-23-005536:notes:377]
The following tables disaggregate our revenue by category for the years ended December 31, 2022, 2021 and 2020:

[0000950170-23-005536:notes:378]
|  |  | 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 364,238 |  |  | $ | 26,216 |  |  | $ | 390,454 |  |
| Access & Aggregation Solutions |  |  | 326,934 |  |  |  | 47,068 |  |  |  | 374,002 |  |
| Optical Networking Solutions |  |  | 225,621 |  |  |  | 35,459 |  |  |  | 261,080 |  |
| Total |  | $ | 916,793 |  |  | $ | 108,743 |  |  | $ | 1,025,536 |  |

[0000950170-23-005536:notes:379]
|  |  | 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 189,825 |  |  | $ | 16,385 |  |  | $ | 206,210 |  |
| Access & Aggregation Solutions |  |  | 309,009 |  |  |  | 47,785 |  |  |  | 356,794 |  |
| Optical Networking Solutions |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 498,834 |  |  | $ | 64,170 |  |  | $ | 563,004 |  |

[0000950170-23-005536:notes:380]
|  |  | 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 163,349 |  |  | $ | 15,315 |  |  | $ | 178,664 |  |
| Access & Aggregation Solutions |  |  | 274,666 |  |  |  | 53,180 |  |  |  | 327,846 |  |
| Optical Networking Solutions |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 438,015 |  |  | $ | 68,495 |  |  | $ | 506,510 |  |

[0000950170-23-005536:notes:381]
Additional Information

[0000950170-23-005536:notes:382]
The following table presents revenue information by geographic area for the years ended December 31, 2022, 2021 and 2020:

[0000950170-23-005536:notes:383]
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| United States |  | $ | 517,433 |  |  | $ | 374,600 |  |  | $ | 352,079 |  |
| United Kingdom |  |  | 189,685 |  |  |  | 56,355 |  |  |  | 13,799 |  |
| Germany |  |  | 146,797 |  |  |  | 65,229 |  |  |  | 74,882 |  |
| Other international |  |  | 171,621 |  |  |  | 66,820 |  |  |  | 65,750 |  |
| Total |  | $ | 1,025,536 |  |  | $ | 563,004 |  |  | $ | 506,510 |  |

[0000950170-23-005536:notes:384]
Customers comprising more than 10% of revenue can change from year to year. Single customers comprising more than 10% of revenue in 2022 included one customer, at 10.4%, which was a service provider and was included in both our Network Solutions and Services & Support segments. Single customers comprising more than 10% of revenue in 2021 included one customer at 18% and was included in both our Network Solutions and Services & Support segments. Single customers comprising more than 10% of revenue in 2020 included three customers at 15%, 12% and 10% and was included in both our Network Solutions and Services & Support segments. Other than those with more than 10% of revenue disclosed above our next five largest customers can change, and have historically changed, from year-to-year. The next five largest customers combined represented 33%, 38% and 34% of total revenue in 2022, 2021 and 2020, respectively.

[0000950170-23-005536:notes:385]
As of December 31, 2022, property, plant and equipment, net totaled $110.7 million, which included $56.2 million held in the U.S. and $54.5 million held outside the U.S. As of December 31, 2021, property, plant and equipment, net totaled $55.8 million, which included $53.0 million held in the U.S. and $2.8 million held outside the U.S. Property, plant and equipment, net is reported on a Company-wide, functional basis only.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-23-005536:notes:386]
Note 19 – Liability for Warranty Returns

[0000950170-23-005536:notes:387]
The liability for warranty obligations totaled $7.2 million and $5.4 million as of December 31, 2022 and 2021, respectively. These liabilities are included in accrued expenses and other liabilities and other non-current liabilities in the accompanying Consolidated Balance Sheets.

[0000950170-23-005536:notes:388]
A summary of warranty expense and write-off activity for the years ended December 31, 2022, 2021 and 2020 is as follows:

[0000950170-23-005536:notes:389]
|  |  | Year Ended December 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 5,403 |  |  | $ | 7,146 |  |  | $ | 8,394 |  |
| Plus: ADVA acquisition |  |  | 3,756 |  |  |  | — |  |  |  | — |  |
| Plus: Amounts charged to cost and expenses |  |  | 3,104 |  |  |  | 855 |  |  |  | 1,538 |  |
| Plus: Foreign currency translation adjustments |  |  | 334 |  |  |  |  |  |  |  |
| Less: Deductions |  |  | (5,401 | ) |  |  | (2,598 | ) |  |  | (2,786 | ) |
| Balance at end of period |  | $ | 7,196 |  |  | $ | 5,403 |  |  | $ | 7,146 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-005536:notes:390]
Note 20 – Commitments and Contingencies

[0000950170-23-005536:notes:391]
Legal Matters

[0000950170-23-005536:notes:392]
From time to time the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

[0000950170-23-005536:notes:393]
Performance Bonds

[0000950170-23-005536:notes:394]
Certain contracts, customers and jurisdictions in which the Company do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2022 and December 31, 2021, the Company had commitments related to these bonds totaling $22.0 million and $22.9 million, respectively, which expire at various dates through April

[0000950170-23-005536:notes:395]
2031. In general the Company would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which the Company believes is remote.

[0000950170-23-005536:notes:396]
Purchase Commitments

[0000950170-23-005536:notes:397]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of December 31, 2022, purchase commitments totaled $552.4 million.


## us-gaap:CreditLossFinancialInstrumentTextBlock

[0000950170-23-005536:notes:398]
Note 21 – Current Expected Credit Losses

[0000950170-23-005536:notes:399]
Under ASC 326 – Financial Instruments – Credit Losses, the Company estimates credit losses for the contractual life of assets that are measured at amortized cost and are within the scope of this guidance, which includes accounts receivable, net investment in sales-type leases, contract assets under the revenue recognition model and outstanding notes receivable. Where appropriate, the Company pools assets if similar risk characteristics exist. Additionally, the Company analyzes its available-for-sale debt securities for impairment and records a credit loss allowance as needed.

[0000950170-23-005536:notes:400]
Assets Measured at Amortized Cost

[0000950170-23-005536:notes:401]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. Accounts receivable balances are considered past due when payment has not been received by the date indicated on the relevant invoice or based on agreed upon terms between the customer and the Company.

[0000950170-23-005536:notes:402]
As of December 31, 2022 and 2021, the Company’s net outstanding accounts receivable balance was $279.4 million and $158.7 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The Company’s historical losses related to accounts receivable have been immaterial as evidenced by its historical allowance and write-offs due to collectability. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0000950170-23-005536:notes:403]
Credit losses totaling less than $0.1 million were recorded for the year ended December 31, 2022, related to accounts receivable. No credit losses were recorded for the years ended December 31, 2021 and 2020 related to accounts receivable. The Company's allowance for credit losses related to accounts receivable was less than $0.1 as of December 31, 2022. The Company had no allowance for credit losses related to accounts receivable as of December 31, 2021.

[0000950170-23-005536:notes:404]
Contract Assets

[0000950170-23-005536:notes:405]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of December 31, 2022 and 2021, the Company’s outstanding contract asset balance was $1.9 million and $0.5 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0000950170-23-005536:notes:406]
No allowance for credit losses was recorded for the year ended December 31, 2022 and 2021 related to contract assets.

[0000950170-23-005536:notes:407]
Off-Balance Sheet Arrangements

[0000950170-23-005536:notes:408]
The Company did not have any off-balance sheet arrangements as of December 31, 2022, 2021 or January 1, 2021.

[0000950170-23-005536:notes:409]
Available-for-Sale Debt Securities

[0000950170-23-005536:notes:410]
As of December 31, 2022 and 2021 the Company’s available-for-sale debt securities totaled $9.3 million and $30.1 million, respectively. These securities were analyzed at the individual investment level, by Committee on Uniform Securities Identification Procedures (“CUSIP”), to limit credit losses, if applicable, to reflect only the amount by which the fair value of the security was less than its amortized cost. The Company noted that, as of December 31, 2022 and, 2021, there was no intent to sell any of its available-for-sale debt securities before maturity, and, therefore, the Company assessed the need for an allowance for each of its available-for-sale debt securities in which the fair value was less than its amortized cost as of December 31, 2022 and 2021. Accrued interest receivable on available-for-sale debt securities, which is included in other receivables on the Consolidated Balance Sheets as of December 31, 2022 and 2021, which totaled less than $0.1 million and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election. Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Consolidated Statements of (Loss) Income.

[0000950170-23-005536:notes:411]
The Company had 99 positions in available-for-sale debt securities that were in an unrealized loss position as of December 31, 2022. See Note 6 for additional information.

[0000950170-23-005536:notes:412]
For those available-for-sale debt securities whose fair value was less than its amortized cost basis, the Company analyzed additional criteria such as adverse conditions specifically related to the security, an industry or geographic area, failure of the issuer of the security to make scheduled interest or principal payments, if applicable, and any changes to the rating of the security by a rating agency to determine if a credit loss existed. The Company used information provided by its investment manager to determine if any scheduled interest or principal payments had not been received and used a third party to determine if any changes to credit ratings had occurred. Principal and interest payments are considered past due when payment has not been received based on scheduled terms of each debt security. The Company ceases to accrue interest on debt securities on a case by case basis. As of December 31, 2022, the Company noted that all principal and interest payments had been received as scheduled and that there had been no changes in credit ratings year-over-year or period-over-period that warranted further review.

[0000950170-23-005536:notes:413]
No allowance for credit losses was recorded for the years ended December 31, 2022 and 2021 related to the Company’s available-for-sale debt securities.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-005536:notes:414]
Note 22 – (Loss) Earnings per Share

[0000950170-23-005536:notes:415]
The calculations of basic and diluted (loss) earnings per share for the years ended December 31, 2022, 2021 and 2020 are as follows:

[0000950170-23-005536:notes:416]
| (In thousands, except for per share amounts) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Numerator |  |  |  |  |  |  |  |  |  |
| Net (Loss) Income attributable to ADTRAN Holdings, Inc. |  | $ | (2,037 | ) |  | $ | (8,635 | ) |  | $ | 2,378 |  |
| Denominator |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 62,346 |  |  |  | 48,582 |  |  |  | 47,996 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | — |  |  |  | 292 |  |
| Weighted average number of shares – diluted |  |  | 62,346 |  |  |  | 48,582 |  |  |  | 48,288 |  |
| (Loss) earnings per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.03 | ) |  | $ | (0.18 | ) |  | $ | 0.05 |  |
| (Loss) earnings per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.03 | ) |  | $ | (0.18 | ) |  | $ | 0.05 |  |

[0000950170-23-005536:notes:417]
For each of the years ended December 31, 2022, 2021 and 2020, less than 0.1 million, 0.1 million and 0.1 million shares of unvested or unearned, as applicable, PSUs, RSUs and restricted stock were excluded from the calculation of diluted (loss) earnings per share due to their anti-dilutive effect.

[0000950170-23-005536:notes:418]
For the year ended December 31, 2022, 2021 and 2020, 0.2 million, 0.3 million and 3.6 million stock options, respectively, were outstanding but were not included in the computation of diluted (loss) earnings per share due to their exercise prices being greater than the average market price of the common shares during the quarter, making them anti-dilutive under the treasury stock method.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-005536:notes:419]
Note 23 – Restructuring

[0000950170-23-005536:notes:420]
During the fourth quarter of 2022, the Company initiated a multi-year integration program designed to optimize the assets, business processes, and information technology systems of the Company in relation to the Business Combination with ADVA. The integration program is expected to maximize cost synergies by realizing operation scale, combining sales channels, streamlining corporate and general and administrative functions and combining sourcing and production costs.

[0000950170-23-005536:notes:421]
During the second half of 2019, the Company initiated a restructuring plan to realign its expense structure with the reduction in revenue experienced in recent years and overall Company objectives. As part of this restructuring plan, the Company announced plans to reduce its overall operating expenses, both in the U.S. and internationally. This plan was completed and all amounts paid in 2021.

[0000950170-23-005536:notes:422]
In February 2019, the Company announced the restructuring of a certain portion of its workforce predominantly in Germany, which included the closure of the Company’s office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. Voluntary early retirement was offered to certain other employees and was announced in March 2019 and again in August 2020. This plan was completed in 2021 and all amounts paid in 2022.

[0000950170-23-005536:notes:423]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Consolidated Balance Sheets as of December 31, 2022 and 2021, is as follows:

[0000950170-23-005536:notes:424]
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 1,514 |  |  | $ | 4,186 |  |
| Plus: Amounts charged to cost and expense |  |  | 1,629 |  |  |  | 411 |  |
| Less: Amounts paid |  |  | (2,984 | ) |  |  | (3,083 | ) |
| Balance at end of period |  | $ | 159 |  |  | $ | 1,514 |  |

[0000950170-23-005536:notes:425]
Restructuring expenses included in the Consolidated Statements of (Loss) Income are for the years ended December 31, 2022, 2021 and 2020:

[0000950170-23-005536:notes:426]
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Network solutions - cost of revenue |  | $ | 8 |  |  | $ | 13 |  |  | $ | 220 |  |
| Services & support - cost of revenue |  |  | — |  |  |  | 3 |  |  |  | 235 |  |
| Cost of revenue |  | $ | 8 |  |  | $ | 16 |  |  | $ | 455 |  |
| Selling, general and administrative expenses |  |  | 117 |  |  |  | 221 |  |  |  | 1,832 |  |
| Research and development expenses |  |  | 1,504 |  |  |  | 174 |  |  |  | 3,942 |  |
| Total restructuring expenses |  | $ | 1,629 |  |  | $ | 411 |  |  | $ | 6,229 |  |

[0000950170-23-005536:notes:427]
The following table represents the components of restructuring expense by geographic area for the years ended December 31, 2022, 2021 and 2020:

[0000950170-23-005536:notes:428]
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| United States |  | $ | 2 |  |  | $ | 289 |  |  | $ | 2,234 |  |
| International |  |  | 1,627 |  |  |  | 122 |  |  |  | 3,995 |  |
| Total restructuring expenses |  | $ | 1,629 |  |  | $ | 411 |  |  | $ | 6,229 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-23-005536:notes:429]
Note 24 – Subsequent Events

[0000950170-23-005536:notes:430]
Dividend approval

[0000950170-23-005536:notes:431]
On February 20, 2023, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record at the close of business on March 7, 2023. The payment date will be March 21, 2023 in the aggregate amount of approximately $7.0 million.

[0000950170-23-005536:notes:432]
Effectiveness of the Domination and Profit and Loss Transfer Agreement

[0000950170-23-005536:notes:433]
The DPLTA between the Company, as the controlling company, and ADVA Optical Networking SE, as the controlled company as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of ADVA (Jena).

[0000950170-23-005536:notes:434]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is

[0000950170-23-005536:notes:435]
entitled to issue binding instructions to the management board of ADVA, (ii) ADVA will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by ADVA. The obligation of ADVA to transfer its annual profit to the Company applies for the first time to the profit generated in the ADVA fiscal year 2023. The obligation of the Company to absorb ADVA’s annual net loss applies for the first time to the loss generated in the ADVA fiscal year 2023.

[0000950170-23-005536:notes:436]
Expansion of Wells Fargo Line of Credit & Payoff of ADVA Loans.

[0000950170-23-005536:notes:437]
Upon the DPLTA becoming effective on January 16, 2023, the available total borrowings under the Wells Fargo Credit Agreement increased from $100 million to $400 million. On January 31, 2023, the Company increased its borrowings under the Credit Agreement from $60.0 million to $187.5 million. In February 2023, the borrowings under the Credit Agreement were paid down by $7.5 million, leaving $180.0 million of borrowings as of February 28, 2023. After considering our outstanding letters of credit, this leaves the Company approximately $198.7 million available for future borrowings as of February 28, 2023. The Company used approximately $51.4 million of the proceeds from the borrowings under the Credit Agreement to retire the outstanding borrowings under ADVA's syndicated credit agreement note payable, syndicated credit agreement working capital line of credit and the Nord/LB revolving line of credit. ADVA's $9.1 million of borrowings under their revolving line of credit with DZ bank remains outstanding.

[0000950170-23-005536:notes:438]
Integration Bonus Plan

[0000950170-23-005536:notes:439]
On March 1, 2023, the Compensation Committee of the Board of Directors of the Company established an “Integration Bonus Plan” consisting of a combination of performance-based performance stock units ("PSUs") and cash bonus award amounts (together with the PSUs, the “Integration Awards”). Under the Integration Bonus Plan, certain key employees of the Company, including the Company’s named executive officers as disclosed in the most recent proxy statement filed by the Company with the SEC (the “Participants”), are eligible to earn the Integration Awards over a performance period beginning upon the date of the grant and ending on December 31, 2024 based on the achievement of cost savings targets related to the Business Combination. See Item 9B. Other Information of this report for addition information.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000950170-23-005536:notes:440]
SCHEDULE II

[0000950170-23-005536:notes:441]
VALUATION AND QUALIFYING ACCOUNTS

[0000950170-23-005536:notes:442]
| (In thousands) |  | Balance atBeginningof Period |  |  | Charged toCosts &Expenses |  |  | Deductions |  |  | Balance atEnd ofPeriod |  |
| Year ended December 31, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | — |  |  |  | 49 |  |  |  | — |  |  | $ | 49 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 50,564 |  |  |  | — |  |  |  | 45,363 |  |  | $ | 5,201 |  |
| Year ended December 31, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 38 |  |  |  | (38 | ) |  |  | — |  |  | $ | — |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 45,818 |  |  |  | 6,347 |  |  |  | 1,601 |  |  | $ | 50,564 |  |
| Year ended December 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 38 |  |  |  | — |  |  |  | — |  |  | $ | 38 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 48,616 |  |  |  | 5,120 |  |  |  | 7,918 |  |  | $ | 45,818 |  |
