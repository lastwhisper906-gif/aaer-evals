# ADTN note change history — 0000950170-22-015058 → 0000950170-22-023803


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-09):
[0000950170-22-023803:note_history:1]
Legal Maters
  (was, 2022-08-05, similarity 0.7742):
[0000950170-22-015058:note_history:1]
Other Legal Matters

- changed (2022-11-09):
[0000950170-22-023803:note_history:2]
From time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.
  (was, 2022-08-05, similarity 0.9754):
[0000950170-22-015058:note_history:2]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

- changed (2022-11-09):
[0000950170-22-023803:note_history:3]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2022 and December 31, 2021, we had commitments related to these bonds totaling $21.1 million and $22.9 million, respectively, which expire at various dates through April 2025. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2022-08-05, similarity 0.9874):
[0000950170-22-015058:note_history:3]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2022 and December 31, 2021, we had commitments related to these bonds totaling $21.8 million and $22.9 million, respectively, which expire at various dates through April 2025. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- added (2022-11-09):
[0000950170-22-023803:note_history:4]
Purchase Commitments

- added (2022-11-09):
[0000950170-22-023803:note_history:5]
We purchase components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2022, purchase commitments totaled $454.1 million.

- changed (2022-11-09):
[0000950170-22-023803:note_history:6]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of September 30, 2022.
  (was, 2022-08-05, similarity 0.9611):
[0000950170-22-015058:note_history:6]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of June 30, 2022.

- removed (2022-11-09):
[0000950170-22-015058:note_history:7]
Shareholder Derivative Lawsuit

- removed (2022-11-09):
[0000950170-22-015058:note_history:8]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. Stanton, et al., Case No. 5:20-cv-00447, was filed in the U.S. District Court for the Northern District of Alabama against two of the Company’s current executive officers, one of its former executive officers, and certain current and former members of its Board of Directors, alleging, among other things, that the defendants made or caused the Company to make materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The plaintiff in the shareholder derivative suit sent a demand letter dated June 29, 2021 to ADTRAN’s Board of Directors. The letter contains similar allegations to those made in the plaintiff’s filed complaint and in the now dismissed securities class action, and it demands, among other things, that the Board of Directors commence an investigation into the alleged wrongdoing. On December 10, 2021, after investigating the allegations in the plaintiff’s demand with the assistance of independent counsel, the independent members of the Board of Directors concluded that pursuing the claims asserted in the demand would not be in the Company's best interests and exercised their business judgment to refuse the demand. The plaintiff subsequently dismissed the case. On February 25, 2022, the Court entered an order on the parties’ joint stipulation dismissing the case without prejudice.

- removed (2022-11-09):
[0000950170-22-015058:note_history:9]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. In conjunction with the Company entering into the revolving credit facility with Wells Fargo during the three months ended June 30, 2022, our obligation to maintain the pledged collateral was released.  This pledged collateral value fluctuated as the Company changed the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value was required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. For additional information on the Wells Fargo revolving credit facility see Note 12 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-11-09):
[0000950170-22-023803:note_history:10]
GENERAL

- changed (2022-11-09):
[0000950170-22-023803:note_history:11]
On July 8, 2022, Acorn MergeCo, Inc. (“Merger Sub”), a Delaware corporation and wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (f/k/a Acorn HoldCo, Inc.), merged with and into ADTRAN, Inc., with ADTRAN, Inc. surviving the merger as a wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (the “Merger”). The Merger was consummated pursuant to the Business Combination Agreement, dated as of August 30, 2021 (the “Business Combination Agreement”), by and among ADTRAN Holdings, Inc., ADTRAN, Inc., ADVA Optical Networking SE, a company organized and existing under the laws of Germany (“ADVA”), and Merger Sub. In accordance with the Business Combination Agreement, ADTRAN Holdings, Inc. made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of common stock, par value $0.01 per share (the “Company Common Stock”), of ADTRAN Holdings, Inc. (the “Exchange Offer” and, together with the Merger, the “Business Combination”). On July 15, 2022 (the “Exchange Offer Settlement Date”), ADTRAN Holdings, Inc. completed the Exchange Offer, in which ADTRAN Holdings, Inc. acquired 34.0 million bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 28.0 million shares of Company Common Stock. See Note 2 for additional information.
  (was, 2022-08-05, similarity 0.9416):
[0000950170-22-015058:note_history:11]
On July 8, 2022, Acorn MergeCo, Inc. (“Merger Sub”), a Delaware corporation and wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (formerly known as Acorn HoldCo), merged with and into ADTRAN, Inc., with ADTRAN, Inc. surviving the merger as a wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (the “Merger”).  The Merger was consummated pursuant to the Business Combination Agreement, dated as of August 30, 2021 (the “Business Combination Agreement”), by and among ADTRAN Holdings, Inc., ADTRAN, Inc., ADVA Optical Networking SE, a company organized and existing under the laws of Germany (“ADVA”), and Merger Sub.  In accordance with the Business Combination Agreement, ADTRAN Holdings, Inc. made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of common stock, par value $0.01 per share (the “Company Common Stock”), of ADTRAN Holdings, Inc. (the “Exchange Offer” and, together with the Merger, the “Business Combination”).  On July 15, 2022 (the “Exchange Offer Settlement Date”), ADTRAN Holdings, Inc. completed the Exchange Offer, in which ADTRAN Holdings, Inc. acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of common stock of ADTRAN Holdings, Inc.

- added (2022-11-09):
[0000950170-22-023803:note_history:12]
On October 18, 2022, the Board of Directors of the Company and the management board of ADVA agreed on a final draft of a domination and profit and loss transfer agreement (the “DPLTA”) between the Company, as the controlling company, and ADVA, as the controlled company. The parties’ execution of the DPLTA remains subject to approval of the DPLTA by shareholders of ADVA with 75% of the votes cast in an extraordinary general meeting, which is scheduled to be held on November 30, 2022. If and when signed, effectiveness of the DPLTA is subject to the subsequent registration of the DPLTA with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered offices of ADVA, with such effectiveness to occur no earlier than January 1, 2023. The Company currently holds 33,957,538 shares of ADVA, representing 65.35% of ADVA’s outstanding shares on September 30, 2022. Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to “ADTRAN,” the “Company,” “we,” “us” and “our” refer to ADTRAN, Inc. and its consolidated subsidiaries prior to the Merger on July 8, 2022, and to ADTRAN Holdings, Inc. and its consolidated subsidiaries following the Merger.

- changed (2022-11-09):
[0000950170-22-023803:note_history:13]
The accompanying unaudited Condensed Consolidated Financial Statements of ADTRAN Holdings, Inc. and its subsidiaries have been prepared pursuant to the rules and regulations of the SEC applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. Certain prior year amounts have been reclassified to conform to the current period presentation. The December 31, 2021 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.
  (was, 2022-08-05, similarity 0.8452):
[0000950170-22-015058:note_history:13]
The accompanying unaudited condensed consolidated financial statements of ADTRAN and its subsidiaries have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. Certain prior year amounts have been reclassified to conform to the current period presentation. The December 31, 2021 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

- changed (2022-11-09):
[0000950170-22-023803:note_history:14]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.
  (was, 2022-08-05, similarity 0.9656):
[0000950170-22-015058:note_history:14]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

- changed (2022-11-09):
[0000950170-22-023803:note_history:15]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus), supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of September 30, 2022 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints and inflationary pressures could result in further impacts to the Company's consolidated financial statements in future reporting periods.
  (was, 2022-08-05, similarity 0.876):
[0000950170-22-015058:note_history:15]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus) as well as supply chain constraints as of June 30, 2022 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints, could result in further impacts to our consolidated financial statements in future reporting periods.

- added (2022-11-09):
[0000950170-22-023803:note_history:16]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. The Company early adopted ASU 2021-08 on July 1, 2022 and the standard was applied retrospectively beginning with January 1, 2022. The effect of the adoption of this standard on the Company's Condensed Consolidated Financial Statements as of the date of this report is included in Note 2 of the Notes to Condensed Consolidated Financial Statements.

- changed (2022-11-09):
[0000950170-22-023803:note_history:17]
There are currently no accounting pronouncements not yet adopted that had a material effect on the Condensed Consolidated Financial Statements.
  (was, 2022-08-05, similarity 0.885):
[0000950170-22-015058:note_history:17]
There are currently no recently adopted accounting pronouncements that had a material effect on the condensed consolidated financial statements.

- removed (2022-11-09):
[0000950170-22-015058:note_history:18]
Except as otherwise indicated, references in these notes to “ADTRAN,” the “Company,” “we,” “us” and “our” for time periods at and before the effectiveness of the Merger, including all fiscal periods ended on or prior to June 30, 2022, shall be deemed to refer to ADTRAN, Inc. as the predecessor registrant to ADTRAN Holdings, Inc.

- removed (2022-11-09):
[0000950170-22-015058:note_history:19]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. ASU 2021-08 is effective for annual periods beginning after December 15, 2022, including interim periods within those fiscal years. Adoption of the ASU should be applied prospectively. Early adoption is also permitted, including adoption in an interim period. If early adopted, the amendments are applied retrospectively to all business combinations for which the acquisition date occurred during the fiscal year of adoption. Given that the Business Combination with ADVA was finalized in July 2022, the Company plans to early adopt ASU 2021-08 during the third quarter of 2022. ASU 2021-08 will be effective as of January 1, 2022 and will be applied on a prospective basis. However, we are unable to estimate the effect on our Condensed Consolidated Financial Statements as of the date of this report.


## adtn:NotesPayableDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-11-09):
[0000950170-22-023803:note_history:20]
14. NOTES PAYABLE

- added (2022-11-09):
[0000950170-22-023803:note_history:21]
The carrying amounts of the Company's notes payable in its Condensed Consolidated Balance Sheets were as follows:

- added (2022-11-09):
[0000950170-22-023803:note_history:22]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | September 30, 2022 |  |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Syndicated credit agreement note payable |  | $ | 29,611 |  |  | $ | 29,782 |  |  | $ | — |  |
| Deutsche Bank term loan |  |  | — |  |  |  | — |  |  |  | — |  |
| Total Notes Payable |  | $ | 29,611 |  |  | $ | 29,782 |  |  | $ | — |  |

- added (2022-11-09):
[0000950170-22-023803:note_history:23]
Syndicated Credit Agreement Note Payable

- added (2022-11-09):
[0000950170-22-023803:note_history:24]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. The interest rate for the note payable is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of September 30, 2022. The note payable matures in September 2023.

- added (2022-11-09):
[0000950170-22-023803:note_history:25]
Deutsche Bank Term Loan

- added (2022-11-09):
[0000950170-22-023803:note_history:26]
In October 2019, ADVA entered into a $9.8 million revolving line of credit with Deutsche Bank that bears interest of EURIBOR plus 1.1%. The line of credit matured in September 2022 and was repaid as of September 30, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-11-09):
[0000950170-22-023803:note_history:27]
The carrying amounts of the Company's revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:

- added (2022-11-09):
[0000950170-22-023803:note_history:28]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Wells Fargo credit agreement |  | $ | 60,000 |  |  | $ | — |  |
| Nord/LB revolving line of credit |  |  | 14,702 |  |  |  | — |  |
| Syndicated credit agreement working capital line of credit |  |  | 9,801 |  |  |  | — |  |
| Wells Fargo revolving credit agreement |  |  | — |  |  |  | — |  |
| Cadence revolving credit agreement |  |  | — |  |  |  | — |  |
| Total revolving credit agreements |  | $ | 84,503 |  |  | $ | — |  |

- added (2022-11-09):
[0000950170-22-023803:note_history:29]
As of September 30, 2022, the weighted average interest rate on our revolving credit agreements was 4.05%

- changed (2022-11-09):
[0000950170-22-023803:note_history:30]
Wells Fargo Credit Agreement
  (was, 2022-08-05, similarity 0.8485):
[0000950170-22-015058:note_history:30]
Wells Fargo Revolving Credit Agreement

- added (2022-11-09):
[0000950170-22-023803:note_history:31]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allows for borrowings of up to $100 million in aggregate principal amount, subject to being increased to up to $400 million in aggregate principal amount upon the Company or Borrower’s execution of a DPLTA with ADVA or a parent of ADVA, among other conditions (the “Senior Credit Facilities Increase”). On October 18, 2022, the Board of Directors of the Company. and the management board of ADVA, agreed on a final draft of a DPLTA between the Company, as the controlling company, and ADVA, as the controlled company. See Note 21 of the Notes to Condensed Consolidated Financial Statements for further information.

- added (2022-11-09):
[0000950170-22-023803:note_history:32]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

- added (2022-11-09):
[0000950170-22-023803:note_history:33]
As of September 30, 2022, ADTRAN, Inc.’s borrowings under the revolving line of credit were $60.0 million in tranches that mature during the fourth quarter of 2022 and can either be repaid or borrowed again for a one month, three month or six month period. In addition, we may issue up to $25 million in letters of credit against our $100 million dollar total facility. As of September 30, 2022, we had a total of $16.0 million in letters of credit with ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $24.0 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

- added (2022-11-09):
[0000950170-22-023803:note_history:34]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

- added (2022-11-09):
[0000950170-22-023803:note_history:35]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participations in letters of credit at the then applicable rate for SOFR Loans.

- added (2022-11-09):
[0000950170-22-023803:note_history:36]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the consolidated total net leverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the consolidated interest coverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of September 30, 2022, the Company was in compliance with all material covenants. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions.

- added (2022-11-09):
[0000950170-22-023803:note_history:37]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

- added (2022-11-09):
[0000950170-22-023803:note_history:38]
Nord/LB Revolving Line of Credit

- added (2022-11-09):
[0000950170-22-023803:note_history:39]
August 8, 2022, ADVA entered into a $14.7 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate + 1.4% and which matures in August 2023. During the term of the loan, ADVA is obligated to maintain an adjusted net debt to cover ratio that is equal to or less than 2.75. As of September 30, 2022, The Company was in compliance with the adjusted net debt to cover ratio. The revolving line of credit grants Nord/LB a lien on assets of any kind which come into the possession of ADVA. Assets of any kind includes goods, foreign exchange, securities including interest, annuity and

- added (2022-11-09):
[0000950170-22-023803:note_history:40]
profit notes, collective securities deposits, subscription rights, checks, bills of exchange, bills of lading, storage and loading slips. As of September 30, 2022, ADVA’s borrowings under the revolving line of credit were $14.7 million, with no amounts available for future borrowings.

- added (2022-11-09):
[0000950170-22-023803:note_history:41]
Syndicated Credit Agreement Working Capital Line of Credit

- added (2022-11-09):
[0000950170-22-023803:note_history:42]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $9.8 million as part of a working capital line of credit. The interest rate for the working capital line of credit is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of September 30, 2022. The working capital line of credit matures in September 2023. As of September 30, 2022, borrowings under the working capital line of credit totaled $9.8 million, with no amounts available for future borrowings.

- changed (2022-11-09):
[0000950170-22-023803:note_history:43]
Prior Wells Fargo Revolving Credit Agreement
  (was, 2022-08-05, similarity 0.7179):
[0000950170-22-015058:note_history:43]
Cadence Revolving Credit Agreement

- added (2022-11-09):
[0000950170-22-023803:note_history:44]
On April 1, 2022, ADTRAN, Inc. entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Prior Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provided the Company with a $25.0 million secured revolving credit facility. During the first nine months of 2022, the Company made draws totaling $10.0 million under the Prior Wells Revolving Credit Agreement all of which had been repaid as of September 30, 2022. The Wells Fargo Credit Agreement replaced the Prior Wells Fargo Revolving Credit Agreement and all outstanding borrowings have been repaid and the prior agreement was terminated.

- added (2022-11-09):
[0000950170-22-023803:note_history:45]
Prior Cadence Revolving Credit Agreement

- added (2022-11-09):
[0000950170-22-023803:note_history:46]
On May 19, 2022, ADTRAN, Inc., as borrower, modified its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The modified Prior Cadence Revolving Credit Agreement provided the Company with a $25.0 million secured revolving credit facility. During the first nine months of 2022, the Company made draws totaling $18.0 million under the Prior Cadence Revolving Credit Agreement all of which had been repaid as of September 30, 2022. The Wells Fargo Credit Agreement replaced the Prior Cadence Revolving Credit Agreement and all outstanding borrowings have been repaid and the prior agreement was terminated.

- removed (2022-11-09):
[0000950170-22-015058:note_history:47]
On May 19, 2022, the Company, as borrower, modified its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The modified Cadence Revolving Credit Agreement provides the Company with a $25.0 million secured revolving credit facility. Loans under the Cadence Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Cadence Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Cadence Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Cadence Revolving Credit Agreement, at a maximum loan-to-value ratio of 85% determined by dividing the full commitment amount under the Cadence Revolving Credit Agreement on the date of testing, determined by the Cadence Lender each fiscal quarter, by the market value of the collateral. The Cadence Revolving Credit Agreement matures on November 3, 2022, subject to earlier termination upon the concurrence of certain events of default. The Company entered into the Cadence Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. During the first half of 2022, the Company made draws totaling $18.0 million under the Cadence Revolving Credit Agreement all of which had been repaid as of June 30, 2022. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company. As of June 30, 2022, the Company was in compliance with all contractual requirements under the Cadence Revolving Credit Agreement.

- removed (2022-11-09):
[0000950170-22-015058:note_history:48]
On April 1, 2022, the Company entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provides the Company with a new $25.0 million secured revolving credit facility. The Wells Revolving Credit Agreement matures on April 1, 2023, subject to earlier termination upon the occurrence of certain events of default as set forth in the Wells Revolving Credit Agreement. Loans under the Wells Revolving Credit Agreement will bear interest at a fluctuating rate per annum equal to: (i) the Daily Simple SOFR (as defined herein) plus (ii) an applicable margin, which will equal 1.00%, 1.25%, 1.5% or 2.0% per annum depending on the Company’s senior funded debt to EBITDA ratio. The “Daily Simple SOFR” is calculated based upon the greater of (x) a floor of 0.00% and (b) the Secured Overnight Financing Rate, as established by the Federal Reserve Bank of New York (or a successor thereto) from time to time. Accrued interest is payable on the last day of each quarter, commencing June 30, 2022. Borrowings under the Wells Revolving Credit Agreement may be used solely for issuing letters of credit, financing capital expenditures, and working capital and general corporate purposes. Loans under the Wells Revolving Credit Agreement are secured by a first priority security interest in all of the accounts receivable of the Company and its subsidiary, ADTRAN International, Inc. Specifically, in connection with the Wells Revolving Credit Agreement, the Company entered into a security agreement, dated April 1, 2022, pursuant to which the Company pledged to the Wells Lender all of the rights to payment, accounts, deposit accounts, chattel paper (whether electronic or tangible), instruments, promissory notes, documents, licenses, general intangibles, payment intangibles, software, letter of credit rights and healthcare insurance receivables existing as of the date of execution or arising at any time thereafter.  During the first half of 2022, the Company made draws totaling $10.0 million under the Wells Revolving Credit Agreement all of which had been repaid as of June 30, 2022. As of June 30, 2022, the Company was in compliance with all contractual requirements under the Wells Fargo Credit Agreement.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-09):
[0000950170-22-023803:note_history:49]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value:
  (was, 2022-08-05, similarity 0.9964):
[0000950170-22-015058:note_history:49]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

- changed (2022-11-09):
[0000950170-22-023803:note_history:50]
|  |  | As of September 30, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,358 |  |  | $ | — |  |  | $ | (374 | ) |  | $ | 8,984 |  |
| Municipal fixed-rate bonds |  |  | 1,411 |  |  |  | — |  |  |  | (54 | ) |  |  | 1,357 |  |
| Asset-backed bonds |  |  | 2,988 |  |  |  | — |  |  |  | (77 | ) |  |  | 2,911 |  |
| Mortgage/Agency-backed bonds |  |  | 4,720 |  |  |  | — |  |  |  | (280 | ) |  |  | 4,440 |  |
| U.S. government bonds |  |  | 11,231 |  |  |  | — |  |  |  | (642 | ) |  |  | 10,589 |  |
| Foreign government bonds |  |  | 409 |  |  |  | — |  |  |  | (27 | ) |  |  | 382 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,117 |  |  | $ | — |  |  | $ | (1,454 | ) |  | $ | 28,663 |  |
  (was, 2022-08-05, similarity 0.6969):
[0000950170-22-015058:note_history:50]
|  |  | As of June 30, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,854 |  |  | $ | 1 |  |  | $ | (286 | ) |  | $ | 10,569 |  |
| Municipal fixed-rate bonds |  |  | 1,563 |  |  |  | — |  |  |  | (49 | ) |  |  | 1,514 |  |
| Asset-backed bonds |  |  | 1,018 |  |  |  | 1 |  |  |  | (16 | ) |  |  | 1,003 |  |
| Mortgage/Agency-backed bonds |  |  | 4,199 |  |  |  | — |  |  |  | (185 | ) |  |  | 4,014 |  |
| U.S. government bonds |  |  | 12,287 |  |  |  | — |  |  |  | (503 | ) |  |  | 11,784 |  |
| Foreign government bonds |  |  | 410 |  |  |  | — |  |  |  | (22 | ) |  |  | 388 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,331 |  |  | $ | 2 |  |  | $ | (1,061 | ) |  | $ | 29,272 |  |

- changed (2022-11-09):
[0000950170-22-023803:note_history:51]
|  |  | As of September 30, 2022 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 96 |  |  | $ | 525 |  |  | $ | — |  |  | $ | 182 |  |  | $ | — |  |  | $ | — |  |  |
| One to two years |  |  | 5,371 |  |  |  | 722 |  |  |  | 95 |  |  |  | 464 |  |  |  | 7,421 |  |  |  | 275 |  |  |
| Two to three years |  |  | 3,517 |  |  |  | 110 |  |  |  | 715 |  |  |  | 1,321 |  |  |  | 2,889 |  |  |  | 107 |  |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 1,306 |  |  |  | 166 |  |  |  | 279 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 382 |  |  |  | 810 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 413 |  |  |  | 1,497 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 8,984 |  |  | $ | 1,357 |  |  | $ | 2,911 |  |  | $ | 4,440 |  |  | $ | 10,589 |  |  | $ | 382 |  |  |
  (was, 2022-08-05, similarity 0.94):
[0000950170-22-015058:note_history:51]
|  |  | As of June 30, 2022 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 621 |  |  | $ | 148 |  |  | $ | — |  |  | $ | 637 |  |  | $ | 367 |  |  | $ | — |  |  |
| One to two years |  |  | 6,484 |  |  |  | 1,254 |  |  |  | — |  |  |  | 472 |  |  |  | 8,315 |  |  |  | 279 |  |  |
| Two to three years |  |  | 3,339 |  |  |  | 112 |  |  |  | 248 |  |  |  | 621 |  |  |  | 3,102 |  |  |  | 109 |  |  |
| Three to five years |  |  | 125 |  |  |  | — |  |  |  | 313 |  |  |  | 189 |  |  |  | — |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 215 |  |  |  | 925 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 227 |  |  |  | 1,170 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 10,569 |  |  | $ | 1,514 |  |  | $ | 1,003 |  |  | $ | 4,014 |  |  | $ | 11,784 |  |  | $ | 388 |  |  |

- changed (2022-11-09):
[0000950170-22-023803:note_history:52]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to its debt securities:
  (was, 2022-08-05, similarity 0.9854):
[0000950170-22-015058:note_history:52]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to our debt securities:

- changed (2022-11-09):
[0000950170-22-023803:note_history:53]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Gross realized gain on debt securities |  | $ | 1 |  |  | $ | 22 |  |  | $ | 14 |  |  | $ | 206 |  |
| Gross realized loss on debt securities |  |  | (116 | ) |  |  | (17 | ) |  |  | (242 | ) |  |  | (53 | ) |
| Total (loss) gain recognized, net |  | $ | (115 | ) |  | $ | 5 |  |  | $ | (228 | ) |  | $ | 153 |  |
  (was, 2022-08-05, similarity 0.9362):
[0000950170-22-015058:note_history:53]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | 97 |  |  | $ | 12 |  |  | $ | 184 |  |
| Gross realized loss on debt securities |  |  | (85 | ) |  |  | (20 | ) |  |  | (125 | ) |  |  | (36 | ) |
| Total (loss) gain recognized, net |  | $ | (85 | ) |  | $ | 77 |  |  | $ | (113 | ) |  | $ | 148 |  |

- changed (2022-11-09):
[0000950170-22-023803:note_history:54]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. No allowance for credit losses was recorded for the nine months ended September 30, 2022 and 2021 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the nine months ended September 30, 2022.
  (was, 2022-08-05, similarity 0.9115):
[0000950170-22-015058:note_history:54]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income. No allowance for credit losses was recorded for the six months ended June 30, 2022 and 2021 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the six months ended June 30, 2022.

- changed (2022-11-09):
[0000950170-22-023803:note_history:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Realized (loss) gain on equity securities sold |  | $ | (1,358 | ) |  | $ | — |  |  | $ | (1,675 | ) |  | $ | (55 | ) |
| Unrealized (loss) gain on equity securities held |  |  | (1,217 | ) |  |  | (68 | ) |  |  | (8,849 | ) |  |  | 2,844 |  |
| Total (loss) gain recognized, net |  | $ | (2,575 | ) |  | $ | (68 | ) |  | $ | (10,524 | ) |  | $ | 2,789 |  |
  (was, 2022-08-05, similarity 0.8458):
[0000950170-22-015058:note_history:55]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Realized (loss) gain on equity securities sold |  | $ | (293 | ) |  | $ | (79 | ) |  | $ | (318 | ) |  | $ | (55 | ) |
| Unrealized (loss) gain on equity securities held |  |  | (4,268 | ) |  |  | 2,011 |  |  |  | (7,630 | ) |  |  | 2,912 |  |
| Total (loss) gain recognized, net |  | $ | (4,561 | ) |  | $ | 1,932 |  |  | $ | (7,948 | ) |  | $ | 2,857 |  |

- changed (2022-11-09):
[0000950170-22-023803:note_history:56]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:
  (was, 2022-08-05, similarity 0.9834):
[0000950170-22-015058:note_history:56]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

- changed (2022-11-09):
[0000950170-22-023803:note_history:57]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 698 |  |  | $ | 698 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 8,984 |  |  |  | — |  |  |  | 8,984 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,357 |  |  |  | — |  |  |  | 1,357 |  |  |  | — |  |
| Asset-backed bonds |  |  | 2,911 |  |  |  | — |  |  |  | 2,911 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,440 |  |  |  | — |  |  |  | 4,440 |  |  |  | — |  |
| U.S. government bonds |  |  | 10,589 |  |  |  | 10,589 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 382 |  |  |  | — |  |  |  | 382 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 760 |  |  |  | 760 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,511 |  |  |  | 21,511 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 51,632 |  |  | $ | 33,558 |  |  | $ | 18,074 |  |  | $ | — |  |
  (was, 2022-08-05, similarity 0.9943):
[0000950170-22-015058:note_history:57]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 409 |  |  | $ | 409 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,569 |  |  |  | — |  |  |  | 10,569 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,514 |  |  |  | — |  |  |  | 1,514 |  |  |  | — |  |
| Asset-backed bonds |  |  | 1,003 |  |  |  | — |  |  |  | 1,003 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,014 |  |  |  | — |  |  |  | 4,014 |  |  |  | — |  |
| U.S. government bonds |  |  | 11,784 |  |  |  | 11,784 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 388 |  |  |  | — |  |  |  | 388 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 873 |  |  |  | 873 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,567 |  |  |  | 22,567 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 53,121 |  |  | $ | 35,633 |  |  | $ | 17,488 |  |  | $ | — |  |

- changed (2022-11-09):
[0000950170-22-023803:note_history:58]
The fair value of its Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.
  (was, 2022-08-05, similarity 0.9924):
[0000950170-22-015058:note_history:58]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

- removed (2022-11-09):
[0000950170-22-015058:note_history:59]
Marketable Equity Securities

- removed (2022-11-09):
[0000950170-22-015058:note_history:60]
Our marketable equity securities consist of publicly traded stock, interests in funds and certain other investments measured at fair value or cost (where appropriate).

- removed (2022-11-09):
[0000950170-22-015058:note_history:61]
The Company has an equity investment which does not have a readily determinable fair value and is recorded using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of the equity investment as of June 30, 2022 and December 31, 2021 was $1.0 million. During the year ended December 31, 2021, impairment charges totaling $0.4 million, were recorded related to the equity investment. As of June 30 2022, cumulative impairment charges totaling $2.4 million were recorded related to the equity investment. There were no impairment charges during the three and six months ended June 30, 2022 and 2021. During the year ended December 31, 2021, an unsecured loan totaling $0.5 million was converted to equity which increased the Company's carrying value of the equity investment.

- removed (2022-11-09):
[0000950170-22-015058:note_history:62]
The Company has a secured note receivable as of June 30, 2022 and December 31, 2021 which totaled $0.4 million and is included in long term investments on the Consolidated Balance Sheets. During the year ended December 31, 2021, an impairment charge of $0.5 million was recognized against the secured note receivable. There were no impairment charges during the three and six months ended June 30, 2022 and 2021.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-11-09):
[0000950170-22-023803:note_history:63]
The carrying amounts of the Company's notes payable in its Condensed Consolidated Balance Sheets were as follows:

- added (2022-11-09):
[0000950170-22-023803:note_history:64]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | September 30, 2022 |  |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Syndicated credit agreement note payable |  | $ | 29,611 |  |  | $ | 29,782 |  |  | $ | — |  |
| Deutsche Bank term loan |  |  | — |  |  |  | — |  |  |  | — |  |
| Total Notes Payable |  | $ | 29,611 |  |  | $ | 29,782 |  |  | $ | — |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-11-09):
[0000950170-22-023803:note_history:65]
The following tables disaggregate revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

- added (2022-11-09):
[0000950170-22-023803:note_history:66]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 125,338 |  |  | $ | 8,337 |  |  | $ | 133,675 |  |  | $ | 42,704 |  |  | $ | 4,163 |  |  | $ | 46,867 |  |
| Access & Aggregation Solutions |  |  | 76,591 |  |  |  | 11,598 |  |  |  | 88,189 |  |  |  | 78,063 |  |  |  | 13,151 |  |  |  | 91,214 |  |
| Optical Networking Solutions |  |  | 103,011 |  |  |  | 15,834 |  |  |  | 118,845 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 304,940 |  |  | $ | 35,769 |  |  | $ | 340,709 |  |  | $ | 120,767 |  |  | $ | 17,314 |  |  | $ | 138,081 |  |

- added (2022-11-09):
[0000950170-22-023803:note_history:67]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 252,899 |  |  | $ | 17,248 |  |  | $ | 270,147 |  |  | $ | 140,257 |  |  | $ | 12,232 |  |  | $ | 152,489 |  |
| Access & Aggregation Solutions |  |  | 243,396 |  |  |  | 34,877 |  |  |  | 278,273 |  |  |  | 219,768 |  |  |  | 36,589 |  |  |  | 256,357 |  |
| Optical Networking Solutions |  |  | 103,011 |  |  |  | 15,834 |  |  |  | 118,845 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 599,306 |  |  | $ | 67,959 |  |  | $ | 667,265 |  |  | $ | 360,025 |  |  | $ | 48,821 |  |  | $ | 408,846 |  |

- added (2022-11-09):
[0000950170-22-023803:note_history:68]
The table below presents revenue information by category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

- added (2022-11-09):
[0000950170-22-023803:note_history:69]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Subscriber Solutions |  | $ | 133,675 |  |  | $ | 46,867 |  |  | $ | 270,147 |  |  | $ | 152,489 |  |
| Access & Aggregation Solutions |  |  | 88,189 |  |  |  | 91,214 |  |  |  | 278,273 |  |  |  | 256,357 |  |
| Optical Networking Solutions |  |  | 118,845 |  |  |  | — |  |  |  | 118,845 |  |  |  | — |  |
| Total |  | $ | 340,709 |  |  | $ | 138,081 |  |  | $ | 667,265 |  |  | $ | 408,846 |  |

- removed (2022-11-09):
[0000950170-22-015058:note_history:70]
The following tables disaggregate revenue by reportable segment and revenue category:

- removed (2022-11-09):
[0000950170-22-015058:note_history:71]
|  |  | Three Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 78,852 |  |  | $ | 10,909 |  |  | $ | 89,761 |  |  | $ | 78,307 |  |  | $ | 12,657 |  |  | $ | 90,964 |  |
| Subscriber Solutions & Experience |  |  | 75,186 |  |  |  | 2,958 |  |  |  | 78,144 |  |  |  | 45,097 |  |  |  | 2,713 |  |  |  | 47,810 |  |
| Traditional & Other Products |  |  | 1,954 |  |  |  | 2,179 |  |  |  | 4,133 |  |  |  | 2,045 |  |  |  | 2,413 |  |  |  | 4,458 |  |
| Total |  | $ | 155,992 |  |  | $ | 16,046 |  |  | $ | 172,038 |  |  | $ | 125,449 |  |  | $ | 17,783 |  |  | $ | 143,232 |  |

- removed (2022-11-09):
[0000950170-22-015058:note_history:72]
|  |  | Six Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 163,141 |  |  | $ | 22,080 |  |  | $ | 185,221 |  |  | $ | 138,360 |  |  | $ | 21,678 |  |  | $ | 160,038 |  |
| Subscriber Solutions & Experience |  |  | 127,009 |  |  |  | 5,741 |  |  |  | 132,750 |  |  |  | 97,366 |  |  |  | 5,013 |  |  |  | 102,379 |  |
| Traditional & Other Products |  |  | 4,216 |  |  |  | 4,369 |  |  |  | 8,585 |  |  |  | 3,532 |  |  |  | 4,816 |  |  |  | 8,348 |  |
| Total |  | $ | 294,366 |  |  | $ | 32,190 |  |  | $ | 326,556 |  |  | $ | 239,258 |  |  | $ | 31,507 |  |  | $ | 270,765 |  |

- removed (2022-11-09):
[0000950170-22-015058:note_history:73]
The table below presents revenue information by category:

- removed (2022-11-09):
[0000950170-22-015058:note_history:74]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Access & Aggregation |  | $ | 89,761 |  |  | $ | 90,964 |  |  | $ | 185,221 |  |  | $ | 160,038 |  |
| Subscriber Solutions & Experience |  |  | 78,144 |  |  |  | 47,810 |  |  |  | 132,750 |  |  |  | 102,379 |  |
| Traditional & Other Products |  |  | 4,133 |  |  |  | 4,458 |  |  |  | 8,585 |  |  |  | 8,348 |  |
| Total |  | $ | 172,038 |  |  | $ | 143,232 |  |  | $ | 326,556 |  |  | $ | 270,765 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-11-09):
[0000950170-22-023803:note_history:75]
Network Solutions Segment - Includes hardware and software products that enable a digital future.

- added (2022-11-09):
[0000950170-22-023803:note_history:76]
Services & Support Segment - Includes network design, implementation, maintenance and cloud-hosted services supporting the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

- changed (2022-11-09):
[0000950170-22-023803:note_history:77]
In addition to the Company's reportable segments, revenue is also reported for the following three categories – Subscriber Solutions, Access & Aggregation Solutions and Optical Networking Solutions.
  (was, 2022-08-05, similarity 0.7147):
[0000950170-22-015058:note_history:77]
In addition to our reportable segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

- added (2022-11-09):
[0000950170-22-023803:note_history:78]
Prior to the Business Combination with ADVA on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with ADVA, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable ADVA solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable ADVA solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of ADVA’s portfolio.

- added (2022-11-09):
[0000950170-22-023803:note_history:79]
Our Subscriber Solutions portfolio is used by service providers to terminate their access services infrastructure at the customer premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

- added (2022-11-09):
[0000950170-22-023803:note_history:80]
Our Access & Aggregation Solutions are solutions that are used by communications service providers to connect residential subscribers, business subscribers and mobile radio networks to the service providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions, and access orchestration solutions that ensure highly reliable and efficient network performance.

- added (2022-11-09):
[0000950170-22-023803:note_history:81]
Our Optical Networking Solutions are used by communications service providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems, and automation platforms that are used to build high-scale, secure and assured optical networks.

- added (2022-11-09):
[0000950170-22-023803:note_history:82]
The following tables disaggregate revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

- added (2022-11-09):
[0000950170-22-023803:note_history:83]
|  |  | Three Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 125,338 |  |  | $ | 8,337 |  |  | $ | 133,675 |  |  | $ | 42,704 |  |  | $ | 4,163 |  |  | $ | 46,867 |  |
| Access & Aggregation Solutions |  |  | 76,591 |  |  |  | 11,598 |  |  |  | 88,189 |  |  |  | 78,063 |  |  |  | 13,151 |  |  |  | 91,214 |  |
| Optical Networking Solutions |  |  | 103,011 |  |  |  | 15,834 |  |  |  | 118,845 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 304,940 |  |  | $ | 35,769 |  |  | $ | 340,709 |  |  | $ | 120,767 |  |  | $ | 17,314 |  |  | $ | 138,081 |  |

- added (2022-11-09):
[0000950170-22-023803:note_history:84]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 252,899 |  |  | $ | 17,248 |  |  | $ | 270,147 |  |  | $ | 140,257 |  |  | $ | 12,232 |  |  | $ | 152,489 |  |
| Access & Aggregation Solutions |  |  | 243,396 |  |  |  | 34,877 |  |  |  | 278,273 |  |  |  | 219,768 |  |  |  | 36,589 |  |  |  | 256,357 |  |
| Optical Networking Solutions |  |  | 103,011 |  |  |  | 15,834 |  |  |  | 118,845 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 599,306 |  |  | $ | 67,959 |  |  | $ | 667,265 |  |  | $ | 360,025 |  |  | $ | 48,821 |  |  | $ | 408,846 |  |

- added (2022-11-09):
[0000950170-22-023803:note_history:85]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of September 30, 2022 and December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $276.5 million and $101.1 million, respectively. As of September 30, 2022, approximately 82% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at September 30, 2022 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2022-11-09):
[0000950170-22-023803:note_history:86]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2022 |  |  | December 31, 2021 |  |
| Accounts receivable, net |  | $ | 302,401 |  |  | $ | 158,742 |  |
| Contract assets(1) |  | $ | 1,790 |  |  | $ | 464 |  |
| Unearned revenue |  | $ | 40,993 |  |  | $ | 17,737 |  |
| Non-current unearned revenue |  | $ | 18,269 |  |  | $ | 9,271 |  |
  (was, 2022-08-05, similarity 0.9279):
[0000950170-22-015058:note_history:86]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2022 |  |  | December 31, 2021 |  |
| Accounts receivable, net |  | $ | 172,088 |  |  | $ | 158,742 |  |
| Contract assets(1) |  | $ | 1,749 |  |  | $ | 464 |  |
| Unearned revenue |  | $ | 22,705 |  |  | $ | 17,737 |  |
| Non-current unearned revenue |  | $ | 10,133 |  |  | $ | 9,271 |  |

- added (2022-11-09):
[0000950170-22-023803:note_history:87]
The Company is party to a receivables purchase agreement with a financial institution (the “Factor”). Pursuant to the terms of the arrangement, the Company, on a revolving basis, sells to the Factor certain of its accounts receivable balances without recourse. On each sale date, the Factor retains from the sale price a default reserve, up to a required balance, which are held by the Factor in a reserve account and pledged to the Company. The Factor is entitled to withdraw from the reserve account the sale price of a defaulted receivable. As of September 30, 2022, accounts receivable totaling $16.1 million were sold, of which $1.3 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of September 30, 2022, the Company has an allowance for doubtful accounts related to factored accounts receivable totaling $0.1 million. As of September 30, 2022, accounts receivables include $31.1 million related to the existing sale of receivables for which the transfer of the receivable has not taken place. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three and nine months ended September 30, 2022.

- changed (2022-11-09):
[0000950170-22-023803:note_history:88]
Of the outstanding unearned revenue balances as of December 31, 2021, $2.8 million and $12.3 million was recognized as revenue during the three and nine months ended September 30, 2022, respectively. Of the $14.1 million of outstanding unearned revenue balances as of December 31, 2020, $2.0 million and $9.8 million was recognized as revenue during the three and nine months ended September 30, 2021, respectively.
  (was, 2022-08-05, similarity 0.8713):
[0000950170-22-015058:note_history:88]
Of the outstanding unearned revenue balances as of December 31, 2021, $4.1 million and $9.5 million was recognized as revenue during the three and six months ended June 30, 2022, respectively. Of the $14.1 million of outstanding unearned revenue balances as of December 31, 2020, $2.9 million and $7.9 million was recognized as revenue during the three and six months ended June 30, 2021, respectively.

- added (2022-11-09):
[0000950170-22-023803:note_history:89]
Accounts Receivable

- added (2022-11-09):
[0000950170-22-023803:note_history:90]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. Accounts receivable balances are considered past due when payment has not been received by the date indicated on the relevant invoice or based on agreed upon terms between the customer and the Company.

- added (2022-11-09):
[0000950170-22-023803:note_history:91]
As of September 30, 2022 and December 31, 2021, the Company’s outstanding accounts receivable balance was $302.4 million, and $158.7 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

- added (2022-11-09):
[0000950170-22-023803:note_history:92]
The allowance for credit losses was $0.2 million as of September 30, 2022 related to accounts receivable. No allowance for credit losses was recorded as of December 31, 2021 related to accounts receivable.

- added (2022-11-09):
[0000950170-22-023803:note_history:93]
Contract Assets

- added (2022-11-09):
[0000950170-22-023803:note_history:94]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of September 30, 2022 and December 31, 2021, the Company’s outstanding contract asset balance was $1.8 million and $0.5 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

- added (2022-11-09):
[0000950170-22-023803:note_history:95]
No allowance for credit losses was recorded for the year ended September 30, 2022 and December 31, 2021 related to contract assets.

- removed (2022-11-09):
[0000950170-22-015058:note_history:96]
Network Solutions Segment - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

- removed (2022-11-09):
[0000950170-22-015058:note_history:97]
Services & Support Segment - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

- removed (2022-11-09):
[0000950170-22-015058:note_history:98]
The following tables disaggregate revenue by reportable segment and revenue category:

- removed (2022-11-09):
[0000950170-22-015058:note_history:99]
|  |  | Three Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 78,852 |  |  | $ | 10,909 |  |  | $ | 89,761 |  |  | $ | 78,307 |  |  | $ | 12,657 |  |  | $ | 90,964 |  |
| Subscriber Solutions & Experience |  |  | 75,186 |  |  |  | 2,958 |  |  |  | 78,144 |  |  |  | 45,097 |  |  |  | 2,713 |  |  |  | 47,810 |  |
| Traditional & Other Products |  |  | 1,954 |  |  |  | 2,179 |  |  |  | 4,133 |  |  |  | 2,045 |  |  |  | 2,413 |  |  |  | 4,458 |  |
| Total |  | $ | 155,992 |  |  | $ | 16,046 |  |  | $ | 172,038 |  |  | $ | 125,449 |  |  | $ | 17,783 |  |  | $ | 143,232 |  |

- removed (2022-11-09):
[0000950170-22-015058:note_history:100]
|  |  | Six Months Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 163,141 |  |  | $ | 22,080 |  |  | $ | 185,221 |  |  | $ | 138,360 |  |  | $ | 21,678 |  |  | $ | 160,038 |  |
| Subscriber Solutions & Experience |  |  | 127,009 |  |  |  | 5,741 |  |  |  | 132,750 |  |  |  | 97,366 |  |  |  | 5,013 |  |  |  | 102,379 |  |
| Traditional & Other Products |  |  | 4,216 |  |  |  | 4,369 |  |  |  | 8,585 |  |  |  | 3,532 |  |  |  | 4,816 |  |  |  | 8,348 |  |
| Total |  | $ | 294,366 |  |  | $ | 32,190 |  |  | $ | 326,556 |  |  | $ | 239,258 |  |  | $ | 31,507 |  |  | $ | 270,765 |  |

- removed (2022-11-09):
[0000950170-22-015058:note_history:101]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2022 and December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $164.5 million and $101.1 million, respectively. As of June 30, 2022, approximately 84% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at June 30, 2022 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-11-09):
[0000950170-22-023803:note_history:102]
Dividend Approval

- changed (2022-11-09):
[0000950170-22-023803:note_history:103]
On November 7, 2022, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 22, 2022. The payment date will be December 6, 2022 in the aggregate amount of approximately $7.0 million.
  (was, 2022-08-05, similarity 0.6832):
[0000950170-22-015058:note_history:103]
On August 3, 2022, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 18, 2022. The payment date will be September 1, 2022 in the aggregate amount of approximately $7.0 million.

- changed (2022-11-09):
[0000950170-22-023803:note_history:104]
Pursuant to the Business Combination which closed on July 15, 2022, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings, Inc. The period in which such options could be assumed ended July 22, 2022. However, that period was subsequently extended and a total of 0.1 million shares of ADTRAN Holdings, Inc. stock are subject to additional assumed ADVA options. The fair value of the stock options assumed by ADTRAN Holdings, Inc. will be estimated using a Black-Scholes model. The valuation of this component of consideration is not yet complete.
  (was, 2022-08-05, similarity 0.6445):
[0000950170-22-015058:note_history:104]
Pursuant to the Business Combination which closed on July 15, 2022, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings. The maximum number of shares of ADTRAN Holdings stock potentially issuable upon such assumption was 2.1 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.0 million shares of ADTRAN Holdings stock are subject to assumed ADVA options. The fair value of the stock options assumed by ADTRAN Holdings will be estimated using a Black-Scholes model. Our valuation of this component of consideration is not yet complete.

- added (2022-11-09):
[0000950170-22-023803:note_history:105]
Approval of Proposed Domination and Profit and Loss Transfer Agreement

- added (2022-11-09):
[0000950170-22-023803:note_history:106]
On October 18, 2022, the Board of Directors of the Company and the management board of ADVA, agreed on a final draft of a domination and profit and loss transfer agreement (the “DPLTA”) between the Company, as the controlling company, and ADVA, as the controlled company. The parties’ execution of the DPLTA remains subject to the approval of the DPLTA by shareholders of ADVA with 75% of the votes cast in an extraordinary general meeting, which is scheduled to be held on November 30, 2022. The Company currently holds 33,957,538 shares of ADVA, representing 65.35% of ADVA’s outstanding shares as of September 30, 2022.

- added (2022-11-09):
[0000950170-22-023803:note_history:107]
Subject to the approval of the DPLTA shareholders and the subsequent registration of the DPLTA with the commercial register of the local court at ADVA’s registered offices, the Company will offer, at the election of each shareholder of ADVA (other than the Company), (i) to acquire the shares of such shareholder for a compensation (Abfindung) of EUR 17.21 per share pursuant to Sec. 305 German Stock Corporation Akt (Aktiengesetz, “AktG”), or (ii) to pay such shareholder a fixed annual recurring compensation payment (Ausgleichszahlung) pursuant to Sec. 304 AktG in an amount of EUR 0.59 (EUR 0.52 net under the current taxation regime), subject to adjustment prior to execution of the DPLTA due to changes in interest rates and borrowing costs prior to November 30, 2022, which is the reference date for the valuation of ADVA shares ("Annual Recurring Compensation").

- added (2022-11-09):
[0000950170-22-023803:note_history:108]
The amount of the Annual Recurring Compensation payment of EUR 0.59 (EUR 0.52 net) is determined on the basis of a rounded annuity interest rate (Verrentungszinssatz) of 3.00% and still subject to an adjustment in case of a change of interest rates and borrowing costs prior to November 30, 2022 which is the reference date for the valuation. An increase of borrowing costs could lead to an increase of the Annual Recurring Compensation payment. The potential increase ranges from EUR 0.62 (EUR 0.54 net), if the annuity interest rate is increased by 25 basis points to 3.25%, up to an Annual Recurring Compensation payment at the amount of EUR 1.00 (EUR 0.87 net), if the annuity interest rate is increased by 250 basis points to 5.50%.

- added (2022-11-09):
[0000950170-22-023803:note_history:109]
Board Approval Purchase of ADVA Common Stock

- added (2022-11-09):
[0000950170-22-023803:note_history:110]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of ADVA through open market purchases not to exceed 15,346,544 shares.

- added (2022-11-09):
[0000950170-22-023803:note_history:111]
Foreign Currency Hedging Agreement

- added (2022-11-09):
[0000950170-22-023803:note_history:112]
On November 3, 2022, the Company entered into a Euro/U.S. dollar cross-currency swap arrangement (the “Swap”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Swap, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its Euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Swap, the Company will exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of $160.0 million will be divided into eight quarterly tranches of $20.0 million. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Swap may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

- removed (2022-11-09):
[0000950170-22-015058:note_history:113]
Closing of the Business Combination with ADVA

- removed (2022-11-09):
[0000950170-22-015058:note_history:114]
As previously disclosed, on July 8, 2022, Acorn MergeCo, Inc. (“Merger Sub”), a Delaware corporation and wholly-owned direct subsidiary of ADTRAN Holdings, Inc. (f/k/a Acorn HoldCo, Inc.) (the “Company”), merged with and into ADTRAN, Inc. (“ADTRAN”), with ADTRAN surviving the merger as a wholly-owned direct subsidiary of the Company (the “Merger”). The Merger was consummated pursuant to the Business Combination Agreement (the “Business Combination Agreement”), dated as of August 30, 2021, by and among the Company, ADTRAN, ADVA Optical Networking SE, a company organized and existing under the laws of Germany (“ADVA”), and Merger Sub.

- removed (2022-11-09):
[0000950170-22-015058:note_history:115]
Pursuant to the Business Combination Agreement, the Company made a public offer to exchange each issued and outstanding no-par value bearer share of ADVA for 0.8244 shares of common stock, par value $0.01 per share (the “Company Common Stock”), of the Company (the “Exchange Offer” and, together with the Merger, the “Business Combination”). The acceptance period for the Exchange Offer ended on February 14, 2022, and on July 6, 2022, the Company announced that all special offer conditions to the consummation of the Exchange Offer had been satisfied. The Exchange Offer was settled on July 15, 2022 (the “Exchange Offer Settlement Date”) in which the Company acquired 33,957,538 bearer shares of ADVA, or 65.43% of ADVA’s outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of Company Common Stock. Based on the Company's closing share price as of July 15, 2022 of $20.20, the value of the Company Common Stock provided in exchange for ADVA common stock was approximately $565.5 million.

- removed (2022-11-09):
[0000950170-22-015058:note_history:116]
The issuance of shares of Company Common Stock in connection with the Business Combination was registered under the Securities Act of 1933, as amended (the “Securities Act”), pursuant to a registration statement on Form S-4 (the “Registration Statement”) (File No. 333-259251), which was declared effective by the U.S. Securities and Exchange Commission on December 2, 2021, and which included a proxy statement of ADTRAN for the special meeting of the stockholders of ADTRAN at which ADTRAN’s stockholders voted to adopt the Business Combination Agreement and that also constituted a prospectus for the Company (the “Proxy Statement”).

- removed (2022-11-09):
[0000950170-22-015058:note_history:117]
The Company Common Stock is listed on the Nasdaq Global Select Market (“Nasdaq”) and trades under the symbol “ADTN”. The Company Common Stock was also approved for listing on the regulated market segment (regulierter Markt) of the Frankfurt Stock Exchange (Frankfurter Wertpapierbörse) with simultaneous admission to the sub-segment thereof with additional post-admission obligations (Prime Standard) on July 13, 2022 and trades there under the symbol “QH9”.

- removed (2022-11-09):
[0000950170-22-015058:note_history:118]
For the three and six months ended June 30, 2022, the Company incurred $0.9 million and $1.8 million of transaction costs and were recognized as selling, general and administrative expense and research and development expense in our Condensed Consolidated Statements of Income, respectively. For the three and six months ended June 30, 2021, the Company incurred $2.4 million and $3.4 million of transaction costs and were recognized as selling, general and administrative expense and research and development expense in our Condensed Consolidated Statements of Income, respectively.

- removed (2022-11-09):
[0000950170-22-015058:note_history:119]
We expect that the business combination will be accounted for using the acquisition method of accounting under ASC 805, with ADTRAN Holdings, Inc. representing the accounting acquirer under this guidance. Due to the timing of the acquisition subsequent to our June 30, 2022 reporting period end, the initial accounting, including the allocation of purchase price and supplemental pro forma information, is incomplete as of the filing date and, therefore, related disclosures are not included herein.

- removed (2022-11-09):
[0000950170-22-015058:note_history:120]
Wells Fargo Credit Agreement

- removed (2022-11-09):
[0000950170-22-015058:note_history:121]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allows for borrowings of up to $100 million in aggregate principal amount, subject to being increased to up to $400 million in aggregate principal amount upon the Company or Borrower’s execution of a domination and profit and loss transfer agreement with ADVA or a parent of ADVA, among other conditions (the “Senior Credit Facilities Increase”).

- removed (2022-11-09):
[0000950170-22-015058:note_history:122]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

- removed (2022-11-09):
[0000950170-22-015058:note_history:123]
As of August 5, 2022, ADTRAN, Inc.’s borrowings under the revolving line of credit were $50.0 million. In addition, a $17.5 million letter of credit with ADTRAN, Inc. remains outstanding. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

- removed (2022-11-09):
[0000950170-22-015058:note_history:124]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”).  All E.U. borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from  1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

- removed (2022-11-09):
[0000950170-22-015058:note_history:125]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participations in letters of credit at the then applicable rate for SOFR Loans.

- removed (2022-11-09):
[0000950170-22-015058:note_history:126]
The Credit Agreement will mature on July 14, 2027, with the Company’s option to request extensions subject to customary conditions.  The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans).

- removed (2022-11-09):
[0000950170-22-015058:note_history:127]
The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements.  It also contains customary events of default (subject to customary cure periods and materiality thresholds).

- removed (2022-11-09):
[0000950170-22-015058:note_history:128]
Furthermore, the Credit Agreement requires that the Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not to exceed 3.25 to 1.00 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the Consolidated Interest Coverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00.

- removed (2022-11-09):
[0000950170-22-015058:note_history:129]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.
