# ADTN MD&A — 0000950170-23-005536


## mdna

[0000950170-23-005536:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000950170-23-005536:mdna:2]
The following discussion should be read in conjunction with our audited consolidated financial statements and the related notes included in Part II, Item 8 of this report. We have omitted discussion of the earliest of the three years of financial condition and results of operations and this information can be found in Part I, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the fiscal year ended December 31, 2021, filed with the SEC on February 25, 2022, which is available free of charge on the SEC's website at http://www.sec.gov and on our website at www.adtran.com.

[0000950170-23-005536:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 2 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part I, Item 1A, Risk Factors, of this Form 10-K.

[0000950170-23-005536:mdna:4]
Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to "ADTRAN", the “Company,” “we,” “us” and “our” refer to ADTRAN Holdings, Inc. and its consolidated subsidiaries for periods subsequent to the Merger and to ADTRAN, Inc. and its consolidated subsidiaries for periods prior to the Merger. The prior period results do not include the results of ADVA prior to the Merger.

[0000950170-23-005536:mdna:5]
Overview

[0000950170-23-005536:mdna:6]
The Company is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, alternative service providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales, administrative and research and development facilities in strategic global locations.

[0000950170-23-005536:mdna:7]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of ADVA Optical Networking SE ("ADVA"). ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. ADVA is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge.

[0000950170-23-005536:mdna:8]
In addition to the Company's reportable segments, revenue is also reported for the following three categories – Subscriber Solutions, Access & Aggregation Solutions, and Optical Networking Solutions.

[0000950170-23-005536:mdna:9]
Prior to the Business Combination with ADVA on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with ADVA, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable ADVA solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable ADVA solutions to create Subscriber Solutions and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of ADVA’s portfolio.

[0000950170-23-005536:mdna:10]
Our Subscriber Solutions portfolio is used by service providers to terminate their access services infrastructure at the customer premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers and cloud software solutions covering a mix of subscriber types.

[0000950170-23-005536:mdna:11]
Our Access & Aggregation Solutions are solutions that are used by communications service providers to connect residential subscribers, business subscribers and mobile radio networks to the service providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions and access orchestration solutions that ensure highly reliable and efficient network performance.

[0000950170-23-005536:mdna:12]
Our Optical Networking Solutions are used by communications service providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems and automation platforms that are used to build high-scale, secure and assured optical networks.

[0000950170-23-005536:mdna:13]
ADVA Domination and Profit and Loss Transfer Agreement

[0000950170-23-005536:mdna:14]
The DPLTA between the Company, as the controlling company, and ADVA Optical Networking SE, as the controlled company, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of ADVA (Jena).

[0000950170-23-005536:mdna:15]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is
entitled to issue binding instructions to the management board of ADVA, (ii) ADVA will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by ADVA. The obligation of ADVA to transfer its annual profit to the Company applies for the first time to the profit, if any, generated in the ADVA fiscal year 2023. The obligation of the Company to absorb ADVA’s annual net loss applies for the first time to the loss, if any, generated in the ADVA fiscal year 2023.

[0000950170-23-005536:mdna:16]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that ADVA shareholders (other than us) be offered, at their election, (i) to put their ADVA shares to the Company in exchange for a compensation in cash of EUR 17.21 per share (the “Exit Compensation”), or (ii) to remain ADVA shareholders and receive a recurring compensation in cash of EUR 0.59 (EUR 0.52 net under the current tax regime) per share for each full fiscal year of ADVA (the “Annual Recurring Compensation”). The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of ADVA for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of ADVA in 2024. The adequacy of both forms of compensation have been challenged by minority shareholders of ADVA via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

[0000950170-23-005536:mdna:17]
The opportunity for outside ADVA shareholders to tender ADVA shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-005536:mdna:18]
We currently hold 33,961,170 no-par value bearer shares of ADVA, representing 65.30% of ADVA’s outstanding shares as of February 14, 2023.

[0000950170-23-005536:mdna:19]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which is incorporated by reference to Exhibit 10.5 of this Annual Report on Form 10-K.

[0000950170-23-005536:mdna:20]
During the year ended December 31, 2022, we recognized $14.2 million of transaction costs relating to the Business Combination. We expect to incur integration costs and costs associated with the implementation of the DPLTA during 2023 and such costs are expected to be material.

[0000950170-23-005536:mdna:21]
Multi-Year Integration Program

[0000950170-23-005536:mdna:22]
During the fourth quarter of 2022, the Company initiated a multi-year integration program designed to optimize the assets, business processes, and information technology systems of the Company.

[0000950170-23-005536:mdna:23]
The program has identified several potential cost synergies, including:

[0000950170-23-005536:mdna:24]
•
realizing operational scale;

[0000950170-23-005536:mdna:25]
•
combined sales channels;

[0000950170-23-005536:mdna:26]
•
streamlining corporate and general and administrative functions; and

[0000950170-23-005536:mdna:27]
•
combined sourcing and production costs.

[0000950170-23-005536:mdna:28]
We have and will continue to invest significant dollars to restructure the workforce, optimize legacy systems, streamline legal entities and consolidate real estate holdings. By executing these integration activities, we expect to deliver greater innovation for customers, career enrichment opportunities for employees, and enhanced value for shareholders. See Note 23 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report for additional information.

[0000950170-23-005536:mdna:29]
Financial Performance and Trends

[0000950170-23-005536:mdna:30]
We ended 2022 with a year-over-year revenue increase of 82.2% as compared to the year ended December 31, 2021, driven by increased volume of sales activity due to the Business Combination with ADVA and to service provider customers. During 2022, we had one 10% revenue customer which was a domestic service provider customer and our five largest customers comprised 38.3% of our revenue. Our year-over-year domestic revenue increased by 38.1%, driven by increased sales volume due to the Business Combination with ADVA and an increased sales volume of residential gateways and optical network terminals in our Network Solutions segment. Internationally, our revenue increased by 169.7% compared to the prior year period, primarily driven by increased volume of sales activity due to the Business Combination with ADVA and increased shipments to a Tier-1 network operator in Europe. We experienced strong demand for our solutions during 2022 and achieved significant year-over-year bookings growth. Bookings are defined as orders received for a product or service during a fiscal period that will be delivered or performed sometime in the future and is a forward looking metric that we utilize to help us understand future revenue growth for the Company. Bookings are generally subject to modification and or cancellation per the terms of the order. Our increase in demand comes from service providers planning to deploy our fiber access platforms, in-home service delivery platforms and SaaS applications. We expect this growth to accelerate. During 2021 and 2022, we secured several Tier-1 next-generation fiber customers, and previously announced Tier-1 fiber customers significantly increased their bookings for our fiber access platforms. Although we expect our revenue growth and profitability in the near-term to continue to be negatively impacted by supply chain issues, our outlook continues to strengthen given the increased demand for our products and our expectation of an improving supply chain over the longer term.

[0000950170-23-005536:mdna:31]
A substantial portion of our shipments of inventory in any fiscal period relate to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days. However, with the current global supply chain and transportation constraints, and limited availability of semiconductor chips and other components of our products, we have experienced and may continue to experience extended lead times, increased logistics intervals and costs, and lower volume of products deliveries, which have had and may continue to have a material adverse effect on our operating results and could have a material adverse effect on our customer relations and our financial condition.

[0000950170-23-005536:mdna:32]
The extent of the impact of the novel coronavirus (“COVID-19”) pandemic on our business remains uncertain and difficult to predict because of the dynamic and evolving nature of the situation. Despite the widespread availability of COVID-19 vaccines and related treatments, the global impact of the outbreak continues to adversely affect many industries, and different geographies continue to reflect the effects of public health restrictions in various ways. The economic recovery following the impact of the COVID-19 pandemic is only partially underway and has been gradual, uneven and characterized by meaningful dispersion across sectors and regions with uncertainty regarding its ultimate length and trajectory. The COVID-19 pandemic and related countermeasures have previously impacted our operations. During 2022, notwithstanding improvement in many markets in which we operate due to a return to more normalized business operations, certain markets continued to be adversely impacted by COVID-19 or as a result of policies relating to COVID-19.

[0000950170-23-005536:mdna:33]
Additionally, due to the pandemic and a global semiconductor chip shortage, we experienced disruption and delays in our supply chain and significant price increases with certain of our manufacturing partners, and those disruptions, delays and price increases may continue. For example, in the second half of 2021 and throughout 2022, our results of operations were negatively impacted by increased expenses resulting from supply chain disruptions. With the current global supply chain and transportation constraints, including delays in supply chain deliveries and the related global semi-conductor chip shortage may continue to have a material adverse effect on our operating results and could have a material adverse effect on customer relations and our financial condition. We believe these supply chain challenges and their adverse impact on our industry will continue to ease during 2023. However, there can be no assurance that the ongoing disruptions due to COVID-19, the related global semiconductor chip shortage or other supply chain constraints or price increases will be resolved in the near term, which could continue to adversely affect our business, financial condition, and results of operations. We will continue to evaluate the nature and extent of the impact of COVID-19 on our business.

[0000950170-23-005536:mdna:34]
Our operating results have fluctuated, and may continue to fluctuate, on a quarterly basis due to several factors, including customer order activity, supply chain constraints, component availability, the Company's consolidation, purchase accounting, and integration with ADVA. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days requiring us to maintain higher inventory levels. These factors may result in limited order flow visibility. However, with the current global supply chain and transportation constraints, and limited availability of semiconductor chips and other components of our products, we have experienced and may continue to experience extended lead times, increased logistics intervals and costs, and lower volume of products deliveries, which have had and may continue to have a material adverse effect on our operating results and could have a material adverse effect on customer relations and our financial condition. We believe these supply chain challenges and their adverse impact on our industry will continue at least through fiscal 2023 and expect that the extended lead times and elevated supply chain costs experienced by our industry will persist for the reasonably foreseeable future. It is unclear when the supply environment will become less volatile and what impacts the supply environment will have on the industry in future periods. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0000950170-23-005536:mdna:35]
53

[0000950170-23-005536:mdna:36]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that initially resulted from the COVID-19 pandemic and that may recur and foreign currency exchange rate movements, inflation, regional conflicts, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Specifically, we expect inflationary pressures on input costs, such as raw materials and labor, and distribution costs to increase. We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors, and customers to address and to limit the disruption to our operations and order fulfillment. Our attempts to offset these cost pressures, such as through increases in the selling prices of some of our products and services, may not be successful and could negatively affect our operating results. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results.

[0000950170-23-005536:mdna:37]
We are exposed to changes in foreign currencies relative to the U.S. dollar, which are references to the differences between the foreign-exchanges rates we use to convert the financial results of our international operations from local currencies into U.S. dollars for financial reporting purposes. This impact of foreign-exchange rate changes is calculated based on the difference between the current period’s currency exchange rates and that of the comparable prior period. Our primary exposures to foreign currency exchange rate movements are with the Euro and the British pound sterling. As a result of our global operations, our revenue, gross margins, operating expense and operating income in some international markets have been and may continue to be affected by foreign currency fluctuations.

[0000950170-23-005536:mdna:38]
Our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. For a discussion of risks associated with our operating results, see Part I, Item 1A, Risk Factors of this report.

[0000950170-23-005536:mdna:39]
Results of Operations

[0000950170-23-005536:mdna:40]
The following table presents selected financial information derived from our Consolidated Statements of (Loss) Income expressed as a percentage of revenue for the years indicated. Amounts may not foot due to rounding.

[0000950170-23-005536:mdna:41]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Revenue |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 89.4 | % |  |  | 88.6 | % |  |  | 86.5 | % |
| Services & Support |  |  | 10.6 |  |  |  | 11.4 |  |  |  | 13.5 |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 63.1 |  |  |  | 54.7 |  |  |  | 48.2 |  |
| Services & Support |  |  | 5.0 |  |  |  | 6.5 |  |  |  | 8.8 |  |
| Total Cost of Revenue |  |  | 68.1 |  |  |  | 61.2 |  |  |  | 57.0 |  |
| Gross Profit |  |  | 31.9 |  |  |  | 38.8 |  |  |  | 43.0 |  |
| Selling, general and administrative expenses |  |  | 20.4 |  |  |  | 22.1 |  |  |  | 22.5 |  |
| Research and development expenses |  |  | 16.9 |  |  |  | 19.3 |  |  |  | 22.4 |  |
| Asset impairments |  |  | 1.7 |  |  |  | — |  |  |  | — |  |
| Operating Loss |  |  | (7.1 | ) |  |  | (2.6 | ) |  |  | (1.9 | ) |
| Interest and dividend income |  |  | 0.2 |  |  |  | 0.5 |  |  |  | 0.4 |  |
| Interest expense |  |  | (0.3 | ) |  |  | — |  |  |  | — |  |
| Net investment (loss) gain |  |  | (1.1 | ) |  |  | 0.3 |  |  |  | 1.0 |  |
| Other income (expense), net |  |  | 1.4 |  |  |  | 0.7 |  |  |  | (0.6 | ) |
| Loss Before Income Taxes |  |  | (6.9 | ) |  |  | (1.1 | ) |  |  | (1.2 | ) |
| Income tax benefit (expense) |  |  | 6.1 |  |  |  | (0.4 | ) |  |  | 1.7 |  |
| Net (Loss) Income |  |  | (0.9 | )% |  |  | (1.5 | )% |  |  | 0.5 | % |
| Less: Net Loss attributable to non-controlling interest |  |  | (0.7 | ) |  |  | — |  |  |  | — |  |
| Net (Loss) Income attributable to ADTRAN Holdings, Inc. |  |  | (0.2 | )% |  |  | (1.5 | )% |  |  | 0.5 | % |

[0000950170-23-005536:mdna:42]
The following discussion and financial information are presented to aid in an understanding of our current consolidated financial position, changes in financial position, results of operations and cash flows and should be read in conjunction with the audited consolidated financial statements and notes thereto included herein. The emphasis of the discussion is a comparison of the years ended December 31, 2022 and December 31, 2021. For a discussion of a comparison of the years ended December 31, 2021 and December 31, 2020, please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022.

[0000950170-23-005536:mdna:43]
Comparison of Years Ended December 31, 2022 and December 31, 2021

[0000950170-23-005536:mdna:44]
Revenue

[0000950170-23-005536:mdna:45]
Our revenue increased 82.2% from $563.0 million for the year ended December 31, 2021 to $1,026 million for the year ended December 31, 2022. The increase in revenue for the year ended December 31, 2022 is primarily attributable to a $365.9 million increase in volume of sales activity due to the Business Combination with ADVA and a $96.6 million increase in volume of sales activity related to our ADTRAN, Inc. operations. The increase in revenue by category for the year ended December 31, 2022 was primarily attributable to a $261.1 million increase in Optical Networking Solutions products due to the Business Combination with ADVA and a $184.2 million increase in Subscriber Solutions products. Although our revenue increased, supply of semiconductor chips and other components of our products has become constrained resulting in extended lead times and increased costs. Transportation constraints, including shortages for both air and surface freight, as well as labor shortages in the transportation industry, have also affected the timing and the cost of obtaining raw materials and production supplies. Although our revenue growth and profitability in the near-term may be impacted by these global supply chain issues, our longer term outlook continues to strengthen given our progress with new customer opportunities and the increased customer demand.

[0000950170-23-005536:mdna:46]
Network Solutions segment revenue increased 83.8% from $498.8 million in 2021 to $916.8 million in 2022, due primarily to the increase of $320.3 million in volume of sales activity due to the Business Combination with ADVA and the increase in revenue for Subscriber Solutions products of $107.0 million, partially offset by a decrease in Access & Aggregation Solutions products of $9.3 million revenue in our ADTRAN, Inc. operations.

[0000950170-23-005536:mdna:47]
Services & Support revenue increased by 69.5% from $64.2 million in 2021 to $108.7 million in 2022. The increase in revenue for 2022 was primarily attributable to the increase of $45.6 million in volume of sales activity from the Business Combination with ADVA partially offset by a $3.1 million decrease in revenue for Access & Aggregation Solutions products in our ADTRAN, Inc. operations.

[0000950170-23-005536:mdna:48]
Domestic revenue increased by 38.1% from $374.6 million in 2021 to $517.4 million in 2022, driven by increased volume of network termination and fiber CPE in our Network Solutions segment. In addition, such growth was a result of increased revenue to Tier-2 and Tier-3 customers with diversified business among our fiber access and CPE, service provider CPE and services.

[0000950170-23-005536:mdna:49]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., increased by 169.7% from $188.4 million for the year ended December 31, 2021 to $508.1 million for the year ended December 31, 2022. International revenue, as a percentage of total revenue, increased from 33.5% for the year ended December 31, 2021 to 49.5% for the year ended December 31, 2022. The increase in international revenue for 2022 was primarily attributable to the increase in volume of $263.8 million in sales activity from the Business Combination with ADVA and increased shipments to a Tier-1 network operator and multiple alternative network operators in Europe. While international revenue has increased to approximately 49.5% of total revenues for the year ended December 31, 2022, the mix of our Network Solutions and Services & Support segments as a percentage of total international revenue remains relatively linear. For the year ended December 31, 2022 as compared to the year ended December 31, 2021, changes in foreign currencies relative to the U.S dollar decreased our net sales by approximately $41.5 million.

[0000950170-23-005536:mdna:50]
Our ADTRAN, Inc. international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income. Our ADVA international revenue is largely focused on the manufacture and selling of networking solutions that are based on three core areas of expertise: fiber-optic transmission technology (cloud interconnect), cloud access technology for rapid creation of innovative services around the network edge and solutions for precise timing and synchronization of networks. In addition, ADVA's international operations offers a comprehensive portfolio of network design, implementation and maintenance services to assist operators in the deployment of market-leading networks while reducing their cost to maintain these networks.

[0000950170-23-005536:mdna:51]
Cost of Revenue

[0000950170-23-005536:mdna:52]
As a percentage of revenue, cost of revenue increased from 61.2% for the year ended December 31, 2021 to 68.1% for the year ended December 31, 2022. The increase was primarily attributable to acquisition related expenses, adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with ADVA, as well as supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations. As our current inventory that was acquired in the Business Combination with ADVA is sold, we expect that our cost of revenue as a percentage of revenue will return to more normalized levels. For the year ended December 31, 2022, changes in foreign currencies relative to the U.S. dollar decreased our cost of revenue by approximately $9.6 million.

[0000950170-23-005536:mdna:53]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 61.7% of revenue in 2021 to 70.6% of revenue in 2022. The increase in cost of revenue as a percentage of revenue was primarily attributable to acquisition related expenses, amortizations and adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with ADVA, as well as supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations.

[0000950170-23-005536:mdna:54]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 57.3% of revenue in 2021 to 47.1% of revenue in 2022. The decrease in cost of revenue as a percentage of revenue was primarily attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with ADVA.

[0000950170-23-005536:mdna:55]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0000950170-23-005536:mdna:56]
Gross Profit

[0000950170-23-005536:mdna:57]
As a percentage of revenue, gross profit decreased from 38.8% for the year ended December 31, 2021 to 31.9% for the year ended December 31, 2022. The decrease was primarily attributable to increases in cost of revenue related to acquisition related expenses, adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with ADVA, as well as supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations partially offset by an increase in volume of sales activity due to the Business Combination with ADVA and an increase in volume of sales activity related to our ADTRAN, Inc. operations.

[0000950170-23-005536:mdna:58]
As a percentage of that segment's revenue, Network Solutions gross profit decreased from 38.3% for the year ended December 31, 2021 to 29.4% for the year ended December 31, 2022. The decrease was primarily attributable to increases in cost of revenue related to acquisition related expenses, adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with ADVA, as well as supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations partially offset by an increase in volume of sales activity due to the Business Combination with ADVA and an increase in volume of sales activity related to our ADTRAN, Inc. operations.

[0000950170-23-005536:mdna:59]
As a percentage of that segment's revenue, Services & Support gross profit increased from 42.7% for the year ended December 31, 2021 to 52.9% for the year ended December 31, 2022. The increase was primarily attributable to an increase in volume of sales activity due to the Business Combination with ADVA, an increase in volume of sales activity related to our ADTRAN, Inc. and a decrease in cost of revenue attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with ADVA.

[0000950170-23-005536:mdna:60]
Selling, General and Administrative Expenses

[0000950170-23-005536:mdna:61]
Selling, general and administrative expenses as a percentage of revenue decreased from 22.1% for the year ended December 31, 2021 to 20.4% for the year ended December 31, 2022. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared as these costs are relatively fixed in the short term.

[0000950170-23-005536:mdna:62]
Selling, general and administrative expenses increased by 67.9% from $124.4 million for the year ended December 31, 2021 to $208.9 million for the year ended December 31, 2022. Selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The increase in selling, general and administrative expenses was primarily attributable to increased expenses related to the Business Combination with ADVA such as employee-related costs due to an increase in the number of employees, amortization of intangible assets, depreciation of property, plant and equipment and transactions costs. For the year ended December 31, 2022 as compared to the year ended December 31, 2021, changes in foreign currencies relative to the U.S dollar decreased our selling, general and administrative expenses by approximately $4.4 million.

[0000950170-23-005536:mdna:63]
Research and Development Expenses

[0000950170-23-005536:mdna:64]
Research and development expenses as a percentage of revenue decreased from 19.3% for the year ended December 31, 2021 to 16.9% for the year ended December 31, 2022. Research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared as these costs are relatively fixed in the short term.

[0000950170-23-005536:mdna:65]
Research and development expenses increased by 59.9% from $108.7 million for the year ended December 31, 2021 to $173.8 million for the year ended December 31, 2022. The increase in research and development expenses was primarily attributable to increased expenses related to the Business Combination with ADVA such as employee-related costs due to an increase in the number of employees and expenses related to our multi-year integration program, amortization of intangible assets and depreciation of property, plant and equipment. For the year ended December 31, 2022 as compared to the year ended December 31, 2021, changes in foreign currencies relative to the U.S. dollar decreased our research and development expenses by approximately $5.2 million.

[0000950170-23-005536:mdna:66]
ADVA has arrangements with governmental entities for the purposes of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the year ended December 31, 2022, the Company recognized $1.1 million as a reduction of research and development expense.

[0000950170-23-005536:mdna:67]
We expect to continue to incur research and development expenses in connection with our new and existing products. We continually evaluate new product opportunities and engage in significant research and product development efforts, which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0000950170-23-005536:mdna:68]
Asset Impairments

[0000950170-23-005536:mdna:69]
In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result, the Company recognized impairment charges of $17.4 million during the year ended December 31, 2022, primarily attributable to capitalized implementation costs for a cloud computing arrangement. There were no asset impairments recognized during the year ended December 31, 2021. See Note 11 of the Notes to the Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-23-005536:mdna:70]
Interest and Dividend Income

[0000950170-23-005536:mdna:71]
Interest and dividend income decreased by 25.4% from $2.8 million for the year ended December 31, 2021 to $2.1 million for the year ended December 31, 2022. The decrease in interest and dividend income was primarily attributable to a decrease in the investment balance for the twelve months ended December 31, 2022. Our investments decreased from $71.0 million as of December 31, 2021 to $33.0 million as of December 31, 2022 and was primarily attributable to the sale of certain equity and fixed income investments for working capital and other purposes.

[0000950170-23-005536:mdna:72]
Interest Expense

[0000950170-23-005536:mdna:73]
Interest expense increased from less than $0.1 million for the year ended December 31, 2021 to $3.4 million for the year ended December 31, 2022. The increase in interest expense was primarily related to an increase in assumed debt associated with the Business Combination with ADVA and the new Wells Fargo Credit Agreement. See Note 13 and Note 14 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report and “Financing Activities” in “Liquidity and Capital Resources” below.

[0000950170-23-005536:mdna:74]
Net Investment (Loss) Gain

[0000950170-23-005536:mdna:75]
We recognized a net investment gain of $1.8 million and a loss of $11.3 million for the years ended December 31, 2021 and 2022, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See “Investing Activities” in “Liquidity and Capital Resources” of this report and Note 1 and Note 6 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-23-005536:mdna:76]
Other Income (Expense), net

[0000950170-23-005536:mdna:77]
Other income (expense), net, increased from income of $3.8 million for the year ended December 31, 2021 to income of $14.5 million for the year ended December 31, 2022. For the years ended December 31, 2022 and 2021, other income (expense), net, is comprised primarily of unrealized gains on foreign exchange contracts, gains and losses on foreign currency transactions and income from excess material sales. See Note 12 of Notes to Consolidated Financial Statements included in Part II, Item 8 of the report for additional information on foreign exchange contracts.

[0000950170-23-005536:mdna:78]
Income Tax Benefit (Expense)

[0000950170-23-005536:mdna:79]
Our effective tax rate changed from an expense of 37.0%, for the year ended December 31, 2021 to a benefit of 87.5% for the year ended December 31, 2022. The change in the effective tax rate for the year ended December 31, 2022, was driven primarily by the release of the majority of our valuation allowance against our domestic deferred tax assets during the fourth quarter of 2022, that was partially offset by increased international tax expense primarily as a result of our closing of the Business Combination with ADVA during the third quarter of 2022. See Note 15 of the Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-23-005536:mdna:80]
Net (Loss) Income Attributable to ADTRAN Holdings, Inc.

[0000950170-23-005536:mdna:81]
As a result of the above factors, our net loss attributable to ADTRAN Holdings, Inc. decreased from $8.6 million for the year ended December 31, 2021 to a net loss of $2.0 million for the year ended December 31, 2022. As a percentage of revenue, net loss was 1.5% for the year ended December 31, 2021 and net loss was 0.2% for the year ended December 31, 2022.

[0000950170-23-005536:mdna:82]
Liquidity and Capital Resources

[0000950170-23-005536:mdna:83]
Liquidity

[0000950170-23-005536:mdna:84]
We have historically financed, our ongoing business with existing cash, investments and cash flow from operations. In the current supply environment we also expect to utilize our credit arrangements to manage our working capital needs. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital, business acquisitions, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures. As of December 31, 2022, the Company has incurred a total of $26.1 million of transaction costs related to the Business Combination. We will also be obligated to compensate any annual net loss of ADVA under the DPLTA. Additionally, pursuant to the terms of the DPLTA, each

[0000950170-23-005536:mdna:85]
ADVA shareholder (other than the Company) has received an offer to elect either (1) to remain an ADVA shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation. Assuming all of the minority holders of currently outstanding ADVA shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments of approximately EUR 310.6 million or approximately $333.2 million, based on an exchange rate as of December 31, 2022. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside ADVA shareholders to tender ADVA shares in exchange for Exit Compensation expires on March 16, 2023 (subject to appraisal proceedings). Our obligation to pay Annual Recurring Compensation under the DPLTA would lead to a continuing payment obligation, which would amount to approximately EUR 10.6 million or $11.4 million (based on the current exchange rate), per year assuming none of the minority ADVA shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany.

[0000950170-23-005536:mdna:86]
We believe that our cash and cash equivalents, investments, cash generated from operations and access to funds under the new Wells Fargo credit facility (described below) will be adequate to meet our operating and capital needs and our obligations under the Business Combination and the DPLTA for at least the next 12 months.

[0000950170-23-005536:mdna:87]
As of December 31, 2022, cash on hand was $108.6 million and short-term investments were $0.3 million, which resulted in available short-term liquidity of $108.9 million, of which $86.3 million was held by our foreign subsidiaries. As of December 31, 2021, cash on hand was $56.6 million and short-term investments were $0.4 million, which resulted in available short-term liquidity of $57.0 million, of which $47.7 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax. The decrease in short-term liquidity from December 31, 2021 to December 31, 2022 was primarily attributable to the sale of certain equity and fixed income investments for working capital and other purposes.

[0000950170-23-005536:mdna:88]
In addition to our cash and cash equivalents and the credit facility, we may fund a portion or all of the Exit Compensation through the sale of securities. There can be no assurances that we would be successful in effecting these actions on commercially reasonable terms or at all.

[0000950170-23-005536:mdna:89]
Operating Activities

[0000950170-23-005536:mdna:90]
Net cash used in operating activities of $44.2 million during the year ended December 31, 2022 decreased by $47.2 million compared to $3.0 million of net cash provided during the year ended December 31, 2021. This decrease was primarily due to net cash outflows from working capital, specifically, an inventory build related to component availability, an increase in accounts receivables and transaction costs related to the Business Combination partially offset by an increase in the average number of days payable to our trade suppliers. Additional details related to our working capital and its drivers are discussed below.

[0000950170-23-005536:mdna:91]
Net accounts receivable increased 76.0% from $158.7 million as of December 31, 2021 to $279.4 million as of December 31, 2022. There was an allowance for credit losses of less than $0.1 million as of December 31, 2022 and no allowance for credit losses as of December 31, 2021. The increase in net accounts receivable was due primarily to the increase in sales volume related to the Business Combination with ADVA and an increase in sales volume in our ADTRAN, Inc. operations. Quarterly accounts receivable DSO decreased from 95 days as of December 31, 2021 to 72 days as of December 31, 2022. The decrease in DSO was due to customer and geographical mix associated with the Business Combination with ADVA and timing of sales within the quarter.

[0000950170-23-005536:mdna:92]
Other receivables increased 192.4% from $11.2 million as of December 31, 2021 to $32.8 million as of December 31, 2022. The increase in other receivables was primarily attributable to an increase in prepaid taxes associated with Business Combination with ADVA and contract assets partially offset by a decrease in our receivables for sales of raw materials and reclaimed duty drawbacks.

[0000950170-23-005536:mdna:93]
Annual inventory turnover decreased from 2.60 turns as of December 31, 2021 to 2.46 turns as of December 31, 2022. Inventory increased 205.6% from $139.9 million as of December 31, 2021 to $427.5 million as of December 31, 2022. The increase in inventory was due to Business Combination with ADVA and strategic inventory buffer purchases given extended component lead times and availability constraints as well as new product ramp ups to ensure supply continuity. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to supply chain uncertainties.

[0000950170-23-005536:mdna:94]
Accounts payable increased 131.9% from $102.5 million as of December 31, 2021 to $237.7 million as of December 31, 2022. The increase in accounts payable was primarily due to the increase in volume of operating costs associated with the Business Combination with ADVA, additional purchases of raw material inventory and extended payment terms. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-23-005536:mdna:95]
Investing Activities

[0000950170-23-005536:mdna:96]
Capital expenditures totaled approximately $17.1 million and $5.7 million for the years ended December 31, 2022 and 2021, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements.

[0000950170-23-005536:mdna:97]
Our combined short-term and long-term investments decreased $38.0 million from $71.0 million as of December 31, 2021 to $33.0 million as of December 31, 2022. This decrease reflects the impact of the sale of portions of our equity and fixed income investments and the net unrealized and realized gains and losses on our investments.

[0000950170-23-005536:mdna:98]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 6 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-23-005536:mdna:99]
As of December 31, 2022, our corporate bonds, municipal bonds, asset-backed bonds, mortgage/agency bonds, U.S. government bonds and other government bonds were classified as available-for-sale and had a combined duration of 1.74 years with an average Standard & Poor’s credit rating of AA-. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0000950170-23-005536:mdna:100]
Our long-term investments decreased 53.7% from $70.6 million as of December 31, 2021 to $32.7 million as of December 31, 2022. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $0.8 million and $12.6 million, as of December 31, 2022 and 2021, respectively. Long-term investments as of December 31, 2022 and 2021 also included $22.9 million and $26.9 million, respectively, related to our deferred compensation plan.

[0000950170-23-005536:mdna:101]
Financing Activities

[0000950170-23-005536:mdna:102]
Dividends

[0000950170-23-005536:mdna:103]
During 2022 and 2021, we paid shareholder dividends totaling $22.9 million and $17.5 million, respectively. The continued payment of dividends is at the discretion of the Company's Board of Directors and is subject to general business conditions and ongoing financial results of the Company. The following table shows dividends per common share paid to our shareholders in each quarter of 2022 and 2021:

[0000950170-23-005536:mdna:104]
| Dividends per Common Share |  |
|  |  | 2022 |  |  | 2021 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0000950170-23-005536:mdna:105]
On February 20, 2023, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record at the close of business on March 7, 2023. The dividends will be paid on March 21, 2023 in the aggregate amount of approximately $7.0 million.

[0000950170-23-005536:mdna:106]
Stock Repurchase Program

[0000950170-23-005536:mdna:107]
There were no stock repurchases during the years ended December 31, 2022 and 2021, and there currently is no authorized stock repurchase plan.

[0000950170-23-005536:mdna:108]
Stock Option Exercises

[0000950170-23-005536:mdna:109]
To accommodate employee stock option exercises, the Company issued 0.5 million and 0.4 million shares of common stock and treasury stock which resulted in proceeds of $6.9 million and $6.4 million during the years ended December 31, 2022 and 2021, respectively. Additionally, to accommodate ADVA Optical Networking SE stock option exercises, ADVA Optical Networking SE issued 0.1 million of ADVA Optical Networking SE common stock which resulted in proceeds of $0.8 million, during the period July 15, 2022 to December 31, 2022. ADVA Optical Networking SE stock options outstanding as of December 31, 2022 totaled 81 thousand (representing less than 0.2% of ADVA's outstanding shares), of which 27 thousand were exercisable.

[0000950170-23-005536:mdna:110]
Employee Pension Plan

[0000950170-23-005536:mdna:111]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations.

[0000950170-23-005536:mdna:112]
In connection with the Business Combination, we acquired $29.6 million of additional obligations and $22.3 million of assets related to postemployment benefit plans for certain groups of employees at our new operations outside of the U.S. Plans vary depending on the legal, economic, and tax environments of the respective country. For defined benefit plans, accruals for pensions and similar commitments have been included in the results for this year. The new defined benefit plans are for employees in Switzerland, Italy, Israel and India:

[0000950170-23-005536:mdna:113]
•
In Switzerland, there are two defined benefit pension plans. Both plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service, salary and on a participants old age account. The plans are financed by contributions paid by the participants and by the Company.

[0000950170-23-005536:mdna:114]
•
In Italy, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay-as-you-go basis. Employees receive their pension payments as a function of salary, inflation and a notional account.

[0000950170-23-005536:mdna:115]
•
In Israel, there is a defined benefit plan that provides benefits in the event of a participant being dismissed involuntarily, retirement or death. The plan's benefits are based on the higher of the severance benefit required by law or the cash surrender value of the severance benefit component of any qualifying insurance policy or long-term employee benefit fund that is registered in the participants name. The plan is financed by contributions paid by the Company.

[0000950170-23-005536:mdna:116]
•
In India, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay-as-you-go basis.

[0000950170-23-005536:mdna:117]
Our defined benefit plan assets consist of a balanced portfolio of equity funds, bond funds, emerging market funds, real estate funds and balanced funds. Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. The objectives of our investment policy are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies. The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. At December 31, 2022, the estimated fair market value of our defined benefit pension plans' assets increased to $48.7 million from $32.7 million at December 31, 2021.

[0000950170-23-005536:mdna:118]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations. The projected benefit obligation for our defined benefit pension plans was $59.3 million and $44.2 million as of December 31, 2022 and 2021, respectively.

[0000950170-23-005536:mdna:119]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Consolidated Statements of (Loss) Income. The components of net periodic pension cost and amounts recognized in other comprehensive (loss) income for the years ended December 31, 2022 and 2021 were ($5.8) million and ($5.0) million, respectively.

[0000950170-23-005536:mdna:120]
Actuarial gains and losses are recorded in accumulated other comprehensive (loss) income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants. We estimate that less than $0.1 million will be amortized from accumulated other comprehensive (loss) income into net periodic pension cost in 2023 for the net actuarial loss. The net actuarial loss recognized in accumulated other comprehensive loss as of December 31, 2022 and 2021 was $1.1 million and $7.7 million, respectively. See Note 15 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-23-005536:mdna:121]
Off-Balance Sheet Arrangements

[0000950170-23-005536:mdna:122]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0000950170-23-005536:mdna:123]
Cash Requirements

[0000950170-23-005536:mdna:124]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of December 31, 2022, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA and currency hedging arrangements, which are discussed below).

[0000950170-23-005536:mdna:125]
| (In thousands) |  | Total |  |  | 2023 |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | After 2027 |  |
| Wells Fargo credit agreement(1) |  | $ | 60,000 |  |  | $ | 60,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Nord/LB revolving line of credit(2) |  |  | 16,091 |  |  |  | 16,091 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Syndicated credit agreement working capital line of credit(3) |  |  | 10,727 |  |  |  | 10,727 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| DZ Bank revolving line of credit (4) |  |  | 9,118 |  |  |  | 9,118 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Syndicated credit agreement note payable(5) |  |  | 24,598 |  |  |  | 24,598 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations(6) |  |  | 552,440 |  |  |  | 527,562 |  |  |  | 24,141 |  |  |  | 309 |  |  |  | 167 |  |  |  | 261 |  |  |  | — |  |
| Operating lease obligations(7) |  |  | 34,976 |  |  |  | 8,992 |  |  |  | 8,076 |  |  |  | 6,740 |  |  |  | 3,825 |  |  |  | 2,865 |  |  |  | 4,478 |  |
| Totals |  | $ | 707,950 |  |  | $ | 657,088 |  |  | $ | 32,217 |  |  | $ | 7,049 |  |  | $ | 3,992 |  |  | $ | 3,126 |  |  | $ | 4,478 |  |

[0000950170-23-005536:mdna:126]
(6) We have purchase obligations related to open purchase orders to our contract manufacturers, ODMs, component suppliers, service partners and other vendors. The settlement of our purchase obligations will occur at various dates beginning in 2023 and going through 2027. See Note 20 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report for more information.

[0000950170-23-005536:mdna:127]
(7) We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Our operating leases had remaining lease terms ranging from one month to 119 months as of December 31, 2022.

[0000950170-23-005536:mdna:128]
New Wells Fargo Credit Agreement

[0000950170-23-005536:mdna:129]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allows for borrowings of up to $100 million in aggregate principal amount, subject to being increased to up to $400 million in aggregate principal amount upon the Company or Borrower’s execution of a DPLTA with ADVA or a parent of ADVA, among other conditions (the “Senior Credit Facilities Increase”). The DPLTA as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of ADVA (Jena). See Note 24 of the Notes to Consolidated Financial Statements for further information.

[0000950170-23-005536:mdna:130]
As of December 31, 2022, ADTRAN, Inc.’s borrowings under the revolving line of credit were $60.0 million in tranches that mature during the first quarter of 2023 and can either be repaid or borrowed again for a one month, three month or six month period. In addition, we may issue up to $25 million in letters of credit against the first $100 million in our total facility. As of December 31, 2022, we had a total of $21.3 million in letters of credit with ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $18.7 million available for future borrowings. Upon the DPLTA becoming effective on January 16, 2023, the available total borrowings under the Wells Fargo Credit Agreement increased from $100 million to $400 million. On January 31, 2023, the Company increased its borrowings under the Credit Agreement from $60.0 million to $187.5 million. In February 2023, the borrowings under the Credit Agreement were paid down by $7.5 million, leaving $180.0 million of borrowings as of February 28, 2023. After considering our outstanding letters of credit, this leaves the Company approximately $198.7 million available for future borrowings as of February 28, 2023. The Company used approximately $51.4 million of the proceeds from the borrowings under the Credit Agreement to retire the outstanding borrowings under ADVA's syndicated credit agreement note payable, syndicated credit agreement working capital line of credit and the Nord/LB revolving line of credit. ADVA's $9.1 million of borrowings under its revolving line of credit with DZ Bank remain outstanding. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-23-005536:mdna:131]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All EU borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-23-005536:mdna:132]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participations in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-23-005536:mdna:133]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the Consolidated Interest Coverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions.

[0000950170-23-005536:mdna:134]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

[0000950170-23-005536:mdna:135]
63

[0000950170-23-005536:mdna:136]
Nord/LB Revolving Line of Credit

[0000950170-23-005536:mdna:137]
On August 8, 2022, ADVA entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and which matures in August 2023. During the term of the loan, ADVA is obligated to maintain an adjusted net debt to cover ratio that is equal to or less than 2.75. As of December 31, 2022, ADVA’s borrowings under the revolving line of credit were $16.1 million. On January 31, 2023, the Company increased its borrowings under the Wells Fargo Credit Agreement. A portion of the proceeds from the borrowings were used to retire the outstanding borrowings under the Nord/LB revolving line of credit.

[0000950170-23-005536:mdna:138]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-23-005536:mdna:139]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. The interest rate for the working capital line of credit is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of December 31, 2022. The working capital line of credit matures in September 2023. As of December 31, 2022, borrowings under the working capital line of credit totaled $10.7 million. On January 31, 2023, the Company increased its borrowings under the Wells Fargo Credit Agreement. A portion of the proceeds from the borrowings were used to retire the outstanding borrowings under the syndicated credit agreement working capital line of credit.

[0000950170-23-005536:mdna:140]
DZ Bank Money Market Facility

[0000950170-23-005536:mdna:141]
As of December 31, 2022, ADVA’s borrowings under its revolving line of credit with DZ Bank totaled $9.1 million, with no amounts available for future borrowings. The interest rate is currently a fixed rate of 2.85%, which resets monthly based on renewal of the loan.

[0000950170-23-005536:mdna:142]
Syndicated Credit Agreement Note Payable

[0000950170-23-005536:mdna:143]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. As of December 31, 2022, the amount outstanding under the note payable is $24.6 million. The interest rate for the note payable is adjusted periodically based on a defined leverage ratio and is currently EURIBOR plus 1.35% as of December 31, 2022. The note payable matures in September 2023. On January 31, 2023, the Company increased its borrowings under the Wells Fargo Credit Agreement. A portion of the proceeds from the borrowings were used to retire the outstanding borrowings under the syndicated credit agreement note payable.

[0000950170-23-005536:mdna:144]
Currency Hedging Arrangements

[0000950170-23-005536:mdna:145]
On November 3, 2022, the Company entered into a Euro/U.S. dollar cross-currency swap arrangement (the “Swap”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Swap, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enable the Company to convert a portion of its Euro denominated payment obligations under the DPLTA into U.S. Dollars. Under the Swap, the Company will exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of $160.0 million will be divided into eight quarterly tranches of $20.0 million. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Swap may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-23-005536:mdna:146]
ADVA Domination and Profit and Loss Transfer Agreement

[0000950170-23-005536:mdna:147]
On December 1, 2022, we, as the controlling company, entered into the DPLTA with ADVA, as the controlled company (the “DPLTA”). The DPLTA, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of ADVA (Jena).

[0000950170-23-005536:mdna:148]
Under the DPLTA, subject to certain limitations pursuant to applicable law, (i) we are entitled to issue binding instructions to the management board of ADVA, (ii) ADVA will transfer all of its annual profits to us, subject to, among other things, the creation or dissolution of certain reserves, and (iii) we will generally absorb all annual losses incurred by ADVA. The obligation of ADVA to transfer its annual profit to us, as well as our obligation to absorb ADVA’s annual net loss, applies for the first time to the profits or losses generated in the ADVA fiscal year 2023.

[0000950170-23-005536:mdna:149]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that ADVA shareholders (other than us) be offered, at their election, (i) to put their ADVA shares to the Company in exchange for a compensation in cash of EUR 17.21 per share (the “Exit Compensation”), or (ii) to remain ADVA shareholders and receive a recurring compensation in cash of EUR 0.59 (EUR 0.52 net under the current tax regime) per share for each full fiscal year of ADVA (the “Annual Recurring Compensation”). The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of ADVA for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of ADVA in 2024. The adequacy of both forms of compensation have been challenged by minority shareholders of ADVA via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA. Our aggregate potential payment obligations under the DPLTA are discussed above under "Liquidity".

[0000950170-23-005536:mdna:150]
The opportunity for outside ADVA shareholders to tender ADVA shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-005536:mdna:151]
We currently hold 33,961,170 no-par value bearer shares of ADVA, representing 65.30% of ADVA’s outstanding shares as of February 14, 2023.

[0000950170-23-005536:mdna:152]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which incorporated by reference to Exhibit 10.5 of this Annual Report on Form 10-K.

[0000950170-23-005536:mdna:153]
During the year ended December 31, 2022, we recognized $14.2 million of transaction costs relating to the Business Combination. We expect to incur integration costs and costs associated with the implementation of the DPLTA during 2023 and such costs are expected to be material.

[0000950170-23-005536:mdna:154]
Performance Bonds

[0000950170-23-005536:mdna:155]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2022 and 2021, we had commitments related to these bonds totaling $21.1 million and $22.9 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract; the probability of which we believe is remote.

[0000950170-23-005536:mdna:156]
Critical Accounting Policies and Estimates

[0000950170-23-005536:mdna:157]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part II, Item 8 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000950170-23-005536:mdna:158]
Revenue

[0000950170-23-005536:mdna:159]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. Review of contracts with customers, for both direct customers and distributors, are performed and assessed for principal versus agent considerations to determine primary responsibility for delivery of performance obligation, presumed inventory risk, and discretion in establishing pricing, when applicable. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost which we have elected to account for as a cost of fulfilling the related contract is included in cost of revenue. Revenue, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract, if material, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0000950170-23-005536:mdna:160]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0000950170-23-005536:mdna:161]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware revenue.

[0000950170-23-005536:mdna:162]
Hardware and Software Revenue

[0000950170-23-005536:mdna:163]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenue from software license sales is recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time products are delivered.

[0000950170-23-005536:mdna:164]
Services & Support Segment - Includes a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services to complement our Network Solutions segment.

[0000950170-23-005536:mdna:165]
Maintenance Revenue

[0000950170-23-005536:mdna:166]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenue, when applicable, is recorded in unearned revenue and non-current unearned revenue. The total balance of our unearned revenue was $60.4 million and $27.0 million as of December 31, 2022 and 2021, respectively.

[0000950170-23-005536:mdna:167]
Network Implementation Revenue

[0000950170-23-005536:mdna:168]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheets. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0000950170-23-005536:mdna:169]
Accounts Receivable Factoring

[0000950170-23-005536:mdna:170]
The Company has entered into a factoring agreement to sell certain receivables to an unrelated third-party financial institution on a non-recourse basis. These transactions are accounted for in accordance with Accounting Standards Codification ("ASC") Topic 860, Transfers and Servicing, and result in a reduction in accounts receivable because the agreements transfer effective control over and risk related to the receivables to the buyers. Trade accounts receivables balances sold are removed from the Consolidated Balance Sheets and cash received is reflected as cash provided by (used in) operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest expense on the Consolidated Statements of (Loss) Income. On each sale date, the financial institution retains from the sale price a default reserve, up to a required balance, which is held by the financial institution in a reserve account and pledged to the Company. The financial institution is entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account is included in other assets on the Consolidated Balance Sheets.

[0000950170-23-005536:mdna:171]
Inventory

[0000950170-23-005536:mdna:172]
We carry our inventory at the lower of cost and net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor, and manufacturing overhead are used to value inventory and are updated at least quarterly. Most variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. If actual trends and market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $51.8 million and $44.6 million at December 31, 2022 and 2021, respectively. Inventory disposals charged against the reserve were $2.9 million and $1.0 million for the years ended December 31, 2022 and December 31, 2021, respectively.

[0000950170-23-005536:mdna:173]
Stock-Based Compensation

[0000950170-23-005536:mdna:174]
For purposes of determining the estimated fair value of market-based PSU awards on the date of grant, the Monte Carlo Simulation valuation method is used. These PSUs are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of performance-based PSUs, RSUs and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. Compensation expense related to unvested performance-based PSUs is recognized over the requisite service period of two to three years as the achievement of the performance obligation becomes probable. For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable, single measure of the fair value of our stock option awards. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. As of December 31, 2022, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $15.8 million.

[0000950170-23-005536:mdna:175]
Pursuant to the Business Combination, which closed on July 15, 2022, ADVA stock option holders were entitled to have their ADVA stock options assumed by ADTRAN Holdings (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings. The maximum number of shares of ADTRAN Holdings stock potentially issuable upon such assumption was 2.3 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.1 million shares of ADTRAN Holdings stock are subject to assumed ADVA options. The determination of the fair value of stock options assumed by ADTRAN Holdings was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors. As of December 31, 2022, total unrecognized compensation expense related to the non-vested portion of stock options was approximately $8.3 million.

[0000950170-23-005536:mdna:176]
Goodwill

[0000950170-23-005536:mdna:177]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The carrying value of goodwill is tested for impairment in the fourth quarter of each year or more frequently if events or circumstances indicate it may be impaired. The quantitative goodwill impairment test is performed at the level of the reporting unit. The identification of our reporting units begins at the operating segment level and considers whether components one level below the operating segment levels should be identified as reporting units for the purpose of testing goodwill for impairment. For goodwill impairment testing purposes, we determined the Company's reporting units are generally the same as its operating segments, which are identified in Note 18 to the Consolidated Financial Statements.

[0000950170-23-005536:mdna:178]
Our general policy is to qualitatively assess the carrying value of goodwill each reporting period for events or changes in circumstances that would more likely than not reduce the fair value of the reporting unit below its carrying amount. In connection with the Business Combination with ADVA the Company recognized $350.5 million of goodwill upon the closing of the exchange offer on July 15, 2022. Therefore, we decided to proceed directly to the quantitative test of goodwill and forego the qualitative assessment. We estimate the fair value of our reporting units based on an income approach, whereby we calculate the fair value of a reporting unit based on the present value of estimated future cash flows. A discounted cash flow analysis requires us to make various judgmental assumptions about future sales, operating margins, growth rates and discount rates, which are based on our budgets, business plans, economic projections, anticipated future cash flows and market participants. We also estimate the fair value of our reporting units based on a peer group analysis, whereby companies in the telecommunications industry or with a comparable product and market structure are used to calculate a fair enterprise value using revenue, EBITDA and debt multiples of trading value. Based on our analysis, management concluded that there was no impairment of goodwill as of December 31, 2022. No goodwill impairment charges were recognized during the years ended December 31, 2021 and 2020. The balance of our goodwill was $381.7 million and $7.0 million as of December 31, 2022 and 2021, respectively.

[0000950170-23-005536:mdna:179]
Intangible Assets

[0000950170-23-005536:mdna:180]
Purchased intangible assets with finite lives are carried at cost less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets.

[0000950170-23-005536:mdna:181]
As part of the purchase price allocation related to the Business Combination with ADVA, the Company recognized $403.8 million of intangible assets on July 15, 2022. Intangible assets are reviewed for impairment whenever events and circumstances indicate impairment may have occurred. The Company assessed impairment triggers related to intangible assets during the fourth quarter of 2022, 2021 and 2020. As a result, no quantitative impairment test of long-lived assets was performed as of December 31, 2022, 2021 and 2020, and no impairment losses of intangible assets were recorded during the years ended December 31, 2022, 2021 and 2020. The balance of our intangible assets was $401.2 million and $19.3 million as of December 31, 2022 and 2021, respectively.

[0000950170-23-005536:mdna:182]
Income Taxes

[0000950170-23-005536:mdna:183]
We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. We continually review the adequacy of our valuation allowance and recognize the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes. During the fourth quarter of 2022, after considering all quantitative and qualitative evidence, including our cumulative income position, historical operating performance and future income projections, we have determined that the positive evidence overcame the negative evidence and have concluded that it is more likely than not that a substantial portion of our U.S. federal and certain other state deferred tax assets were realizable. As a result we have released the majority of our valuation allowance against those assets. However, the amount of deferred tax assets considered realizable could be adjusted in future periods in the event that sufficient evidence is no longer present to support a conclusion that it is more likely than not that all or a portion of our domestic deferred tax assets will be realized.

[0000950170-23-005536:mdna:184]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0000950170-23-005536:mdna:185]
Liability for Warranty

[0000950170-23-005536:mdna:186]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and an estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $7.2 million and $5.4 million at December 31, 2022 and 2021, respectively. These liabilities are included in accrued expenses and other liabilities in the accompanying Consolidated Balance Sheets.

[0000950170-23-005536:mdna:187]
Pension Benefit Plan Obligations

[0000950170-23-005536:mdna:188]
Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $10.6 million and $11.4 million at December 31, 2022 and December 31, 2021, respectively. This liability is included in pension liability in the accompanying Consolidated Balance Sheets.

[0000950170-23-005536:mdna:189]
Lease Obligations

[0000950170-23-005536:mdna:190]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain potential embedded leases. These other contracts are specifically reviewed to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease. Some of our leases include options to renew. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. The exercise of lease renewal options is at our sole discretion. The depreciable life of leased assets and leasehold improvements are limited by the expected lease term. Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. Our lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-23-005536:mdna:191]
Business Combinations

[0000950170-23-005536:mdna:192]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition subject to purchase accounting adjustments. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets and liabilities assumed or acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired and liabilities assumed exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying Consolidated Statements of (Loss) Income since their dates of acquisition. Costs incurred to complete the Business Combination, such as legal, accounting or other professional fees, are charged to selling, general and administrative expenses as incurred.

[0000950170-23-005536:mdna:193]
Recently Issued Accounting Pronouncements

[0000950170-23-005536:mdna:194]
For a discussion of recently issued accounting pronouncements, see Note 1 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-23-005536:mdna:195]
70
