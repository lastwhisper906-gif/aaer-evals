# ADTN 8-K — 0000950170-23-003277 filed 2023-02-21

## item codes, every 8-K on or before 2023-03-01

- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2023-03-01

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-23-003277:8k_2_02:1]
EX-99
2
adtn-ex99_1.htm
EX-99.1

[0000950170-23-003277:8k_2_02:2]
EX-99

[0000950170-23-003277:8k_2_02:3]
EXHIBIT 99.1

[0000950170-23-003277:8k_2_02:4]
ADTRAN Holdings, Inc. Reports Preliminary Earnings for the Fourth Quarter of 2022 and Declares Quarterly Cash Dividend

[0000950170-23-003277:8k_2_02:5]
HUNTSVILLE, Ala. — (February 20, 2023) — ADTRAN Holdings, Inc., (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” or the “Company”), today announced preliminary and unaudited financial results for the fourth quarter of 2022. All figures in this release are approximate due to the preliminary nature of the announcement. For the quarter, preliminary revenue was $358.3 million. Preliminary net income inclusive of the non-controlling interest for the fourth quarter of 2022 was $35.0 million. Preliminary net income attributable to the Company for the fourth quarter of 2022 was $38.9 million and preliminary diluted earnings per share attributable to the Company was $0.49. Inclusive of non-controlling interests, preliminary non-GAAP net income was $15.7 million. Preliminary non-GAAP net income attributable to the Company was $9.9 million and preliminary non-GAAP diluted earnings per share attributable to the Company was $0.12. Non-GAAP net income and non-GAAP earnings per share exclude acquisition related expenses, amortizations, adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments), stock-based compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, certain asset impairments, restructuring expenses, changes in valuation allowance related to our deferred tax assets, and the tax effect of these adjustments to net income. The reconciliations between the non-GAAP net income measures presented herein and the respective equivalent GAAP financial measures are set forth in the tables provided below.

[0000950170-23-003277:8k_2_02:6]
ADTRAN Holdings Chairman and Chief Executive Officer Tom Stanton stated, “Fourth quarter revenue was in the lower side of our guidance range at $358.3 million, as strength in optical networking solutions helped to offset delays in new product introductions. The supply environment has improved year-over-year, which had a positive effect on our gross margins. We also expect supply bottlenecks to continue to alleviate during 2023. Our strong growth in the EMEA region underlines our increased global presence with greater customer diversity as we move into an unprecedented network upgrade cycle.”

[0000950170-23-003277:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the fourth quarter of 2022. The quarterly cash dividend of $0.09 per common share is to be paid to the Company’s stockholders of record as of the close of business on March 7, 2023. The ex-dividend date is March 6, 2023, and the payment date will be March 21, 2023.

[0000950170-23-003277:8k_2_02:8]
The information contained in this press release is preliminary. Final results for the fourth quarter ended December 31, 2022 will be released on March 1, 2023.

[0000950170-23-003277:8k_2_02:9]
The Company confirmed that it will hold a conference call to discuss its preliminary fourth quarter results on Tuesday, February 21, 2023, at 9:30 a.m. Central Time or 4:30 p.m. Central European Time. ADTRAN Holdings will webcast this conference call. To listen, simply visit our Investor Relations site at investors.adtran.com approximately 10 minutes prior to the start of the call, click on the event “ADTRAN Holdings Releases 4th Quarter 2022 Financial Results and Earnings Call”, and click on the Webcast link.

[0000950170-23-003277:8k_2_02:10]
An online replay of the Company’s conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit investors.adtran.com or email at investor.relations@adtran.com.

[0000950170-23-003277:8k_2_02:11]
About ADTRAN Holdings, Inc.

[0000950170-23-003277:8k_2_02:12]
ADTRAN Holdings, Inc. is the parent company of ADTRAN, Inc., a wholly owned subsidiary and a leading global provider of open, disaggregated networking and communications solutions. ADTRAN Holdings is also the largest shareholder of ADVA, a European headquartered network innovator that empowers operators to deliver the cloud and mobile services that are vital to today’s society.

[0000950170-23-003277:8k_2_02:13]
Cautionary Note Regarding Forward-Looking Statements

[0000950170-23-003277:8k_2_02:14]
impossible to identify all such factors, factors which could cause actual events or results to differ materially from those estimated by ADTRAN Holdings include, but are not limited to: (i) risks and uncertainties related to manufacturing and supply chain constraints, including as a result of the continued impact of the SARS-CoV-2 coronavirus/COVID-19 global pandemic ; (ii) risks and uncertainties related to the completed business combination between the Company, ADTRAN and ADVA, including risks related to the ability to successfully integrate the ADTRAN’s and ADVA’s businesses, the disruption of management time from ongoing business operations due to integration efforts following the business combination, and the risk that ADTRAN Holdings may be unable to achieve expected synergies or that it may take longer or be more costly than expected to achieve those synergies; (iii) the risk of fluctuations in revenue due to lengthy sales and approval processes required by major and other service providers for new products; (iv) the risk posed by potential breaches of information systems and cyber-attacks; (v) the risks that ADTRAN may not be able to effectively compete, including through product improvements and development; and (vi) other risks set forth in ADTRAN Holdings’ public filings made with the Securities and Exchange Commission, including its Annual Report on Form 10-K for the year ended December 31, 2021 and Form 10‑Q for the quarterly period ended September 30, 2022, as well as its Form 10‑K for the year ended December 31, 2022 to be filed with the SEC.

[0000950170-23-003277:8k_2_02:15]
Additionally, the financial measures presented herein are preliminary estimates and are subject to risks and uncertainties, including, among others, changes in connection with quarter-end adjustments. Any variation between the Company’s actual results and the preliminary financial information set forth herein may be material.

[0000950170-23-003277:8k_2_02:16]
Explanation of Use of Non-GAAP Financial Measures

[0000950170-23-003277:8k_2_02:17]
Set forth in the tables below are reconciliations of gross profit, gross margin, operating expenses, operating loss, other income (expense), net income inclusive of the non-controlling interest, net income attributable to the Company, net loss attributable to the no-controlling interest and earnings (loss) per share - basic and diluted, attributable to the Company, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income, non-GAAP net income inclusive of the non-controlling interest, non-GAAP net income attributable to the Company, non-GAAP net income attributable to the non-controlling interest, and non-GAAP earnings per share - basic and diluted, attributable to the Company, respectively. Such non-GAAP measures exclude acquisition related expenses, amortizations and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments), stock-based compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, certain asset impairments, restructuring expenses, changes in valuation allowance related to our deferred tax assets, and the tax effect of these adjustments to net income. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income, non-GAAP net income inclusive of the non-controlling interest, non-GAAP net income attributable to the Company, non-GAAP net income attributable to the non-controlling interest, and non-GAAP earnings per share - basic and diluted, attributable to the Company, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0000950170-23-003277:8k_2_02:18]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0000950170-23-003277:8k_2_02:19]
Investor Services/Assistance:

[0000950170-23-003277:8k_2_02:20]
Rhonda Lambert/256-963-7450

[0000950170-23-003277:8k_2_02:21]
Investor.relations@adtran.com

[0000950170-23-003277:8k_2_02:22]
Condensed Consolidated Balance Sheets

[0000950170-23-003277:8k_2_02:23]
(Preliminary, Unaudited)

[0000950170-23-003277:8k_2_02:24]
(In thousands)

[0000950170-23-003277:8k_2_02:25]
| ASSETS |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Current Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 108,644 |  |  | $ | 56,603 |  |
| Restricted cash |  |  | — |  |  |  | 215 |  |
| Short-term investments |  |  | 340 |  |  |  | 350 |  |
| Accounts receivable, net |  |  | 279,436 |  |  |  | 158,742 |  |
| Other receivables |  |  | 32,831 |  |  |  | 11,228 |  |
| Inventory, net |  |  | 427,531 |  |  |  | 139,891 |  |
| Prepaid expenses and other current assets |  |  | 33,577 |  |  |  | 9,296 |  |
| Total Current Assets |  |  | 882,359 |  |  |  | 376,325 |  |
| Property, plant and equipment, net |  |  | 111,493 |  |  |  | 55,766 |  |
| Deferred tax assets, net |  |  | 6,210 |  |  |  | 9,079 |  |
| Goodwill |  |  | 381,724 |  |  |  | 6,968 |  |
| Intangibles, net |  |  | 401,211 |  |  |  | 19,293 |  |
| Other non-current assets |  |  | 66,203 |  |  |  | 30,971 |  |
| Long-term investments |  |  | 32,665 |  |  |  | 70,615 |  |
| Total Assets |  | $ | 1,881,865 |  |  | $ | 569,017 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |  |
| Accounts payable |  | $ | 237,699 |  |  | $ | 102,489 |  |
| Revolving credit agreements outstanding |  |  | 95,936 |  |  |  | — |  |
| Notes payable |  |  | 24,598 |  |  |  | — |  |
| Unearned revenue |  |  | 41,193 |  |  |  | 17,737 |  |
| Accrued expenses and other liabilities |  |  | 35,235 |  |  |  | 13,673 |  |
| Accrued wages and benefits |  |  | 44,882 |  |  |  | 14,900 |  |
| Income tax payable, net |  |  | 9,032 |  |  |  | 6,560 |  |
| Total Current Liabilities |  |  | 488,575 |  |  |  | 155,359 |  |
| Non-current unearned revenue |  |  | 19,239 |  |  |  | 9,271 |  |
| Pension liability |  |  | 10,624 |  |  |  | 11,402 |  |
| Deferred compensation liability |  |  | 26,668 |  |  |  | 31,383 |  |
| Non-current lease obligations |  |  | 22,807 |  |  |  | 3,269 |  |
| Other non-current liabilities |  |  | 10,339 |  |  |  | 1,231 |  |
| Total Liabilities |  |  | 578,252 |  |  |  | 211,915 |  |
| Equity |  |  |  |  |  |  |
| Common stock |  |  | 781 |  |  |  | 797 |  |
| Additional paid-in capital |  |  | 895,834 |  |  |  | 288,946 |  |
| Accumulated other comprehensive income (loss) |  |  | 46,713 |  |  |  | (11,914 | ) |
| Retained earnings |  |  | 55,338 |  |  |  | 740,820 |  |
| Treasury stock |  |  | (4,125 | ) |  |  | (661,547 | ) |
| Non-controlling interest |  |  | 309,072 |  |  |  | — |  |
| Total Equity |  |  | 1,303,613 |  |  |  | 357,102 |  |
| Total Liabilities and Equity |  | $ | 1,881,865 |  |  | $ | 569,017 |  |

[0000950170-23-003277:8k_2_02:26]
Condensed Consolidated Statements of Income (Loss)

[0000950170-23-003277:8k_2_02:27]
(Preliminary, Unaudited)

[0000950170-23-003277:8k_2_02:28]
(In thousands, except per share amounts)

[0000950170-23-003277:8k_2_02:29]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 317,487 |  |  | $ | 138,809 |  |  | $ | 916,793 |  |  | $ | 498,834 |  |
| Services & Support |  |  | 40,784 |  |  |  | 15,349 |  |  |  | 108,743 |  |  |  | 64,170 |  |
| Total Revenue |  |  | 358,271 |  |  |  | 154,158 |  |  |  | 1,025,536 |  |  |  | 563,004 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 233,925 |  |  |  | 91,797 |  |  |  | 647,105 |  |  |  | 307,841 |  |
| Services & Support |  |  | 16,943 |  |  |  | 7,926 |  |  |  | 51,179 |  |  |  | 36,786 |  |
| Total Cost of Revenue |  |  | 250,868 |  |  |  | 99,723 |  |  |  | 698,284 |  |  |  | 344,627 |  |
| Gross Profit |  |  | 107,403 |  |  |  | 54,435 |  |  |  | 327,252 |  |  |  | 218,377 |  |
| Selling, general and administrative expenses |  |  | 78,243 |  |  |  | 35,141 |  |  |  | 208,889 |  |  |  | 124,414 |  |
| Research and development expenses |  |  | 61,570 |  |  |  | 26,532 |  |  |  | 173,757 |  |  |  | 108,663 |  |
| Asset impairment |  |  | 464 |  |  |  | — |  |  |  | 17,433 |  |  |  | — |  |
| Operating Loss |  |  | (32,874 | ) |  |  | (7,238 | ) |  |  | (72,827 | ) |  |  | (14,700 | ) |
| Interest and dividend income |  |  | 1,355 |  |  |  | 1,957 |  |  |  | 2,123 |  |  |  | 2,844 |  |
| Interest expense |  |  | (2,010 | ) |  |  | (16 | ) |  |  | (3,437 | ) |  |  | (34 | ) |
| Net investment (loss) gain |  |  | (587 | ) |  |  | (1,181 | ) |  |  | (11,339 | ) |  |  | 1,761 |  |
| Other income, net |  |  | 11,568 |  |  |  | 1,151 |  |  |  | 14,517 |  |  |  | 3,824 |  |
| Loss Before Income Taxes |  |  | (22,548 | ) |  |  | (5,327 | ) |  |  | (70,963 | ) |  |  | (6,305 | ) |
| Income tax benefit (expense) |  |  | 57,503 |  |  |  | 1,137 |  |  |  | 62,075 |  |  |  | (2,330 | ) |
| Net Income (Loss) |  | $ | 34,955 |  |  | $ | (4,190 | ) |  | $ | (8,888 | ) |  | $ | (8,635 | ) |
| Less: Net Loss attributable to non-controlling interest |  |  | (3,926 | ) |  |  | — |  |  |  | (6,851 | ) |  |  | — |  |
| Net Income (Loss) attributable to ADTRAN Holdings, Inc. |  | $ | 38,881 |  |  | $ | (4,190 | ) |  | $ | (2,037 | ) |  | $ | (8,635 | ) |
| Weighted average shares outstanding – basic |  |  | 77,659 |  |  |  | 48,914 |  |  |  | 62,346 |  |  |  | 48,582 |  |
| Weighted average shares outstanding – diluted |  |  | 79,243 |  |  |  | 48,914 |  |  |  | 62,346 |  |  |  | 48,582 |  |
| Earnings (Loss) per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | 0.50 |  |  | $ | (0.09 | ) |  | $ | (0.03 | ) |  | $ | (0.18 | ) |
| Earnings (Loss) per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | 0.49 |  |  | $ | (0.09 | ) |  | $ | (0.03 | ) |  | $ | (0.18 | ) |

[0000950170-23-003277:8k_2_02:30]
Condensed Consolidated Statements of Cash Flows

[0000950170-23-003277:8k_2_02:31]
(Preliminary, Unaudited)

[0000950170-23-003277:8k_2_02:32]
(In thousands)

[0000950170-23-003277:8k_2_02:33]
|  |  | Twelve Months Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net (Loss) Income |  | $ | (8,888 | ) |  | $ | (8,635 | ) |
| Adjustments to reconcile net (loss) income to net cash provided by (used in) operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 67,553 |  |  |  | 16,084 |  |
| Asset impairments |  |  | 17,433 |  |  |  | — |  |
| Amortization of debt issuance cost |  |  | 288 |  |  |  | — |  |
| Amortization of net discount on available-for-sale investments |  |  | 19 |  |  |  | 108 |  |
| Loss (gain) on investments |  |  | 9,826 |  |  |  | (5,127 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 85 |  |  |  | 4 |  |
| Stock-based compensation expense |  |  | 28,322 |  |  |  | 7,480 |  |
| Deferred income taxes |  |  | (62,388 | ) |  |  | (1,784 | ) |
| Inventory reserves |  |  | (7,250 | ) |  |  | (5,029 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 788 |  |  |  | (60,864 | ) |
| Other receivables |  |  | (20,088 | ) |  |  | 9,752 |  |
| Inventory |  |  | (68,349 | ) |  |  | (10,638 | ) |
| Prepaid expenses other current assets and other assets |  |  | (6,367 | ) |  |  | (7,146 | ) |
| Accounts payable |  |  | 28,105 |  |  |  | 53,270 |  |
| Accrued expenses and other liabilities |  |  | (20,483 | ) |  |  | 10,063 |  |
| Income taxes payable |  |  | (2,151 | ) |  |  | 5,470 |  |
| Net cash (used in) provided by operating activities |  |  | (43,545 | ) |  |  | 3,008 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (18,453 | ) |  |  | (5,669 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 51,661 |  |  |  | 50,466 |  |
| Purchases of available-for-sale investments |  |  | (23,899 | ) |  |  | (35,031 | ) |
| Proceeds from beneficial interests in securitized accounts receivable |  |  | 1,126 |  |  |  | — |  |
| Proceeds from disposals of property, plant and equipment |  |  | 561 |  |  |  | — |  |
| Insurance proceeds received |  |  | — |  |  |  | 500 |  |
| Acquisition of business, net of cash acquired |  |  | 44,003 |  |  |  | — |  |
| Net cash provided by investing activities |  |  | 54,999 |  |  |  | 10,266 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (6,070 | ) |  |  | (1,860 | ) |
| Proceeds from stock option exercises |  |  | 6,904 |  |  |  | 6,431 |  |
| Dividend payments |  |  | (22,885 | ) |  |  | (17,529 | ) |
| Proceeds from draw on revolving credit agreements |  |  | 141,887 |  |  |  | 10,000 |  |
| Repayment of revolving credit agreements |  |  | (48,000 | ) |  |  | (10,000 | ) |
| Payment of debt issuance cost |  |  | (3,015 | ) |  |  | — |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (4,253 | ) |  |  | — |  |
| Repayment of notes payable |  |  | (17,702 | ) |  |  | — |  |
| Net cash provided by (used in) financing activities |  |  | 46,866 |  |  |  | (12,958 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 58,320 |  |  |  | 316 |  |
| Effect of exchange rate changes |  |  | (6,494 | ) |  |  | (3,677 | ) |
| Cash, cash equivalents and restricted cash, beginning of year |  |  | 56,818 |  |  |  | 60,179 |  |
| Cash, cash equivalents and restricted cash, end of year |  | $ | 108,644 |  |  | $ | 56,818 |  |
| Supplemental disclosure of cash financing activities |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 1,728 |  |  | $ | 13 |  |
| Cash used in operating activities related to operating leases |  | $ | 5,229 |  |  | $ | 1,892 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 3,410 |  |  | $ | 1,875 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 1,165 |  |  | $ | 638 |  |
| ADVA common shares exchanged in acquisition |  | $ | 565,491 |  |  | $ | — |  |
| ADVA options assumed in acquisition |  | $ | 12,769 |  |  | $ | — |  |
| Non-controlling interest related to ADVA |  | $ | 316,415 |  |  | $ | — |  |

[0000950170-23-003277:8k_2_02:34]
Supplemental Information

[0000950170-23-003277:8k_2_02:35]
Reconciliation of Preliminary Gross Profit and Preliminary Gross Margin to

[0000950170-23-003277:8k_2_02:36]
Preliminary Non-GAAP Gross Profit and Preliminary Non-GAAP Gross Margin

[0000950170-23-003277:8k_2_02:37]
(Unaudited)

[0000950170-23-003277:8k_2_02:38]
(In thousands)

[0000950170-23-003277:8k_2_02:39]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |
|  |  | December 31, 2022 |  |  | September 30, 2022 |  |  | December 31, 2021 |  |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Net Income (loss) attributable to ADTRAN Holdings, Inc. |  | $ | 358,271 |  |  | $ | 340,709 |  |  | $ | 154,158 |  |  |  | $ | 1,025,536 |  |  | $ | 563,004 |  |
| Cost of Revenue |  | $ | 250,868 |  |  | $ | 237,682 |  |  | $ | 99,723 |  |  |  | $ | 698,284 |  |  | $ | 344,627 |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | (31,577 | ) | (1) |  | (25,530 | ) | (3) |  | — |  |  |  |  | (57,108 | ) | (5) |  | (12 | ) |
| Stock-based compensation expense |  |  | (1,287 | ) | (2) |  | (1,269 | ) | (4) |  | (154 | ) |  |  |  | (2,876 | ) | (6) |  | (543 | ) |
| Pension adjustments |  |  | 144 |  |  |  | (59 | ) |  |  | — |  |  |  |  | 85 |  |  |  | — |  |
| Restructuring expenses |  |  | (8 | ) |  |  | — |  |  |  | — |  |  |  |  | (8 | ) |  |  | (15 | ) |
| Non-GAAP Cost of Revenue |  | $ | 218,140 |  |  | $ | 210,824 |  |  | $ | 99,569 |  |  |  | $ | 638,377 |  |  | $ | 344,057 |  |
| Gross Profit |  | $ | 107,403 |  |  | $ | 103,027 |  |  | $ | 54,435 |  |  |  | $ | 327,252 |  |  | $ | 218,377 |  |
| Non-GAAP Gross Profit |  | $ | 140,131 |  |  | $ | 129,885 |  |  | $ | 54,589 |  |  |  | $ | 387,159 |  |  | $ | 218,947 |  |
| Gross Margin |  |  | 30.0 | % |  |  | 30.2 | % |  |  | 35.3 | % |  |  |  | 31.9 | % |  |  | 38.8 | % |
| Non-GAAP Gross Margin |  |  | 39.1 | % |  |  | 38.1 | % |  |  | 35.4 | % |  |  |  | 37.8 | % |  |  | 38.9 | % |

[0000950170-23-003277:8k_2_02:40]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $31.6 million is included in total cost of revenue, on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:41]
(2) Includes $1.0 million of cost of revenue expenses incremental stock-based award modification expense related to the business combination on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:42]
(3) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $25.5 million is included in total cost of revenue, on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:43]
(4) Includes $1.0 million of cost of revenue expenses incremental stock-based award modification expense related to the business combination on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:44]
(5) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $57.1 million is included in total cost of revenue, on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:45]
(6) Includes $2.0 million of cost of revenue expenses incremental stock-based award modification expense related to the business combination on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:46]
Supplemental Information

[0000950170-23-003277:8k_2_02:47]
Reconciliation of Preliminary Operating Expenses to Preliminary Non-GAAP Operating Expenses

[0000950170-23-003277:8k_2_02:48]
(Unaudited)

[0000950170-23-003277:8k_2_02:49]
(In thousands)

[0000950170-23-003277:8k_2_02:50]
|  | Three Months Ended |  |  | Twelve Months Ended |  |  |
|  | December 31, 2022 |  |  | September 30, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |  |
| Operating Expenses | $ | 139,813 |  |  | $ | 134,076 |  |  | $ | 61,673 |  |  | $ | 382,646 |  |  | $ | 233,077 |  |  |
| Acquisition-related expenses, amortizations and adjustments |  | (8,328 | ) | (1) |  | (14,780 | ) | (6) |  | (6,529 | ) | (9) |  | (27,561 | ) | (12) |  | (15,988 | ) | (16) |
| Stock-based compensation expense |  | (11,095 | ) | (2) |  | (10,862 | ) | (7) |  | (1,869 | ) | (10) |  | (25,418 | ) | (13) |  | (6,937 | ) | (17) |
| Restructuring expenses |  | (1,618 | ) | (3) |  | — |  |  |  | (102 | ) | (11) |  | (1,620 | ) | (14) |  | (395 | ) | (18) |
| Pension adjustments |  | 43 |  | (4) |  | (185 | ) | (8) |  | — |  |  |  | (142 | ) | (15) |  | — |  |  |
| Deferred compensation adjustments |  | (168 | ) | (5) |  | 740 |  | (5) |  | 2 |  | (5) |  | 7,005 |  | (5) |  | (2,089 | ) | (5) |
| Non-GAAP Operating Expenses | $ | 118,647 |  |  | $ | 108,989 |  |  | $ | 53,175 |  |  | $ | 334,910 |  |  | $ | 207,668 |  |  |

[0000950170-23-003277:8k_2_02:51]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $7.8 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:52]
(2) $9.4 million is included in selling, general and administrative expenses and $1.7 million is included in research and development expenses on the condensed consolidated statements of income (loss). Includes $7.3 million in selling, general and administrative expenses and $0.6 million is included in research and development expenses incremental stock-based award modification expense related to the business combination.

[0000950170-23-003277:8k_2_02:53]
(3) $0.1 is included in selling, general and administrative expenses and $1.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:54]
(4) $0.2 million is included in selling, general and administrative expenses and ($0.3) million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:55]
(5) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of income (loss).

[0000950170-23-003277:8k_2_02:56]
(6) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $14.3 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:57]
(7) $9.2 million is included in selling, general and administrative expenses and $1.7 million is included in research and development expenses on the condensed consolidated statements of income (loss). Includes $7.3 million in selling, general and administrative expenses and $0.6 million is included in research and development expenses incremental stock-based award modification expense related to the business combination.

[0000950170-23-003277:8k_2_02:58]
(8) Less than $0.1 million is included in selling, general and administrative expenses and $0.1 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:59]
(9) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $6.0 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:60]
(10) $1.3 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:61]
(11) Less than $0.1 million is included in selling, general and administrative expenses and less than $0.1 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:62]
(12) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $25.6 million is included in selling, general and administrative expenses and $1.9 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:63]
(13) $20.8 million is included in selling, general and administrative expenses and $4.6 million is included in research and development expenses on the condensed consolidated statements of income (loss). Includes $14.6 million in selling, general and administrative expenses and $1.2 million is included in research and development expenses incremental stock-based award modification expense related to the business combination.

[0000950170-23-003277:8k_2_02:64]
(14) $0.1 is included in selling, general and administrative expenses and $1.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:65]
(15) $0.3 million is included in selling, general and administrative expenses and ($0.2) million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:66]
(16) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, and certain one-time transaction expenses of which $14.1 million is included in selling, general and administrative expenses and $1.9 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:67]
(17) $4.6 million is included in selling, general and administrative expenses and $2.3 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:68]
(18) $0.2 is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0000950170-23-003277:8k_2_02:69]
Supplemental Information

[0000950170-23-003277:8k_2_02:70]
Reconciliation of Preliminary Operating Loss to Preliminary Non-GAAP Operating Income

[0000950170-23-003277:8k_2_02:71]
(Unaudited)

[0000950170-23-003277:8k_2_02:72]
(In thousands)

[0000950170-23-003277:8k_2_02:73]
|  | Three Months Ended |  |  | Twelve Months Ended |  |  |
|  | December 31, 2022 |  |  | September 30, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |  |
| Operating Loss | $ | (32,874 | ) |  | $ | (48,018 | ) |  | $ | (7,238 | ) |  | $ | (72,827 | ) |  | $ | (14,700 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  | 39,904 |  |  |  | 40,310 |  |  |  | 6,529 |  |  |  | 84,667 |  |  |  | 15,999 |  |  |
| Asset impairments |  | 463 |  |  |  | 16,969 |  |  |  | — |  |  |  | 17,432 |  |  |  | — |  |  |
| Stock-based compensation expense |  | 12,383 |  |  |  | 12,131 |  |  |  | 2,023 |  |  |  | 28,295 |  |  |  | 7,480 |  |  |
| Pension adjustments |  | (187 | ) |  |  | 244 |  |  |  | — |  |  |  | 57 |  |  |  | — |  |  |
| Restructuring expenses |  | 1,627 |  |  |  | — |  |  |  | 102 |  |  |  | 1,629 |  |  |  | 411 |  |  |
| Deferred compensation adjustments (1) |  | 168 |  |  |  | (740 | ) |  |  | (2 | ) |  |  | (7,005 | ) |  |  | 2,089 |  |  |
| Non-GAAP Operating Income | $ | 21,484 |  |  | $ | 20,896 |  |  | $ | 1,414 |  |  | $ | 52,248 |  |  | $ | 11,279 |  |  |

[0000950170-23-003277:8k_2_02:74]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of income (loss).

[0000950170-23-003277:8k_2_02:75]
Supplemental Information

[0000950170-23-003277:8k_2_02:76]
Reconciliation of Preliminary Other Income (Expense) to Preliminary Non-GAAP Other Income

[0000950170-23-003277:8k_2_02:77]
(Unaudited)

[0000950170-23-003277:8k_2_02:78]
(In thousands)

[0000950170-23-003277:8k_2_02:79]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |
|  |  | December 31, 2022 |  |  | September 30, 2022 |  |  | December 31, 2021 |  |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Interest and dividend income |  | $ | 1,355 |  |  | $ | 347 |  |  | $ | 1,957 |  |  |  | $ | 2,123 |  |  | $ | 2,844 |  |
| Interest expense |  |  | (2,010 | ) |  |  | (1,303 | ) |  |  | (16 | ) |  |  |  | (3,437 | ) |  |  | (34 | ) |
| Net investment (loss) gain |  |  | (587 | ) |  |  | (2,691 | ) |  |  | (1,181 | ) |  |  |  | (11,339 | ) |  |  | 1,761 |  |
| Other income (expense), net |  |  | 11,568 |  |  |  | 2,494 |  |  |  | 1,151 |  |  |  |  | 14,517 |  |  |  | 3,824 |  |
| Total Other Income (Expense) |  | $ | 10,326 |  |  | $ | (1,153 | ) |  | $ | 1,911 |  |  |  | $ | 1,864 |  |  | $ | 8,395 |  |
| Deferred compensation adjustments (1) |  |  | (349 | ) |  |  | 1,124 |  |  |  | 673 |  |  |  |  | 6,211 |  |  |  | (864 | ) |
| Pension expense (2) |  |  | 77 |  |  |  | 81 |  |  |  | 263 |  |  |  |  | 333 |  |  |  | 1,088 |  |
| Non-GAAP Other Income |  | $ | 10,054 |  |  | $ | 52 |  |  | $ | 2,847 |  |  |  | $ | 8,408 |  |  | $ | 8,619 |  |

[0000950170-23-003277:8k_2_02:80]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0000950170-23-003277:8k_2_02:81]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-23-003277:8k_2_02:82]
Supplemental Information

[0000950170-23-003277:8k_2_02:83]
Reconciliation of Preliminary Net Income (Loss) inclusive of Non-Controlling Interest to

[0000950170-23-003277:8k_2_02:84]
Preliminary Non-GAAP Net Income (Loss) inclusive of Non-Controlling Interest

[0000950170-23-003277:8k_2_02:85]
(Unaudited)

[0000950170-23-003277:8k_2_02:86]
and

[0000950170-23-003277:8k_2_02:87]
Reconciliation of Preliminary Net Loss attributable to Non-Controlling Interest to

[0000950170-23-003277:8k_2_02:88]
Preliminary Non-GAAP Net Income attributable to Non-Controlling Interest

[0000950170-23-003277:8k_2_02:89]
(Unaudited)

[0000950170-23-003277:8k_2_02:90]
and

[0000950170-23-003277:8k_2_02:91]
Reconciliation of Preliminary Net Income (Loss) attributable to ADTRAN Holdings, Inc. and

[0000950170-23-003277:8k_2_02:92]
Preliminary Earnings (Loss) per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0000950170-23-003277:8k_2_02:93]
Preliminary Non-GAAP Net Income attributable to ADTRAN Holdings, Inc. and

[0000950170-23-003277:8k_2_02:94]
Preliminary Non-GAAP Earnings per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0000950170-23-003277:8k_2_02:95]
(Unaudited)

[0000950170-23-003277:8k_2_02:96]
(In thousands, except per share amounts)

[0000950170-23-003277:8k_2_02:97]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |  |
|  |  | December 31, 2022 |  |  | September 30, 2022 |  |  | December 31, 2021 |  |  |  | December 31, 2022 |  |  | December 31, 2021 |  |  |
| Net Income (loss) attributable to ADTRAN Holdings, Inc. |  | $ | 38,881 |  |  | $ | (41,934 | ) |  | $ | (4,190 | ) |  |  | $ | (2,037 | ) |  | $ | (8,635 | ) |  |
| Plus: Net Loss attributable to non-controlling interest (1) |  |  | (3,926 | ) |  |  | (2,925 | ) |  |  | — |  |  |  |  | (6,851 | ) |  |  | — |  |  |
| Net Income (loss) inclusive of non-controlling interest |  | $ | 34,955 |  |  | $ | (44,859 | ) |  | $ | (4,190 | ) |  |  | $ | (8,888 | ) |  | $ | (8,635 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 39,904 |  |  |  | 40,310 |  |  |  | 6,529 |  |  |  |  | 84,667 |  |  |  | 15,999 |  |  |
| Asset impairments |  |  | 463 |  |  |  | 16,969 |  |  |  | — |  |  |  |  | 17,432 |  |  |  | — |  |  |
| Stock-based compensation expense |  |  | 12,383 |  |  |  | 12,131 |  |  |  | 2,023 |  |  |  |  | 28,295 |  |  |  | 7,480 |  |  |
| Valuation allowance |  |  | (60,908 | ) |  |  | 3,182 |  |  |  | 333 |  |  |  |  | (45,358 | ) |  |  | 4,746 |  |  |
| Deferred compensation adjustments(2) |  |  | (182 | ) |  |  | 383 |  |  |  | 673 |  |  |  |  | (794 | ) |  |  | 1,225 |  |  |
| Pension adjustments(3) |  |  | (109 | ) |  |  | 325 |  |  |  | 263 |  |  |  |  | 390 |  |  |  | 1,088 |  |  |
| Restructuring expenses |  |  | 1,627 |  |  |  | — |  |  |  | 102 |  |  |  |  | 1,629 |  |  |  | 411 |  |  |
| Tax effect of adjustments to net income (loss) |  |  | (12,463 | ) |  |  | (16,245 | ) |  |  | (1,016 | ) |  |  |  | (29,892 | ) |  |  | (3,947 | ) |  |
| Non-GAAP Net Income inclusive of non-controlling interest |  | $ | 15,670 |  |  | $ | 12,196 |  |  | $ | 4,717 |  |  |  | $ | 47,481 |  |  | $ | 18,367 |  |  |
| Less: Non-GAAP Net Income attributable to non-controlling interest (1) |  |  | 5,769 |  |  |  | 4,486 |  |  |  | — |  |  |  |  | 10,255 |  |  |  | — |  |  |
| Non-GAAP Net Income attributable to ADTRAN Holdings, Inc. |  | $ | 9,901 |  |  | $ | 7,710 |  |  | $ | 4,717 |  |  |  | $ | 37,226 |  |  | $ | 18,367 |  |  |
| GAAP Net Loss attributable to non-controlling interest (1) |  | $ | (3,926 | ) |  | $ | (2,925 | ) |  | $ | — |  |  |  | $ | (6,851 | ) |  | $ | — |  |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 9,039 |  |  |  | 7,120 |  |  |  | — |  |  |  |  | 16,159 |  |  |  | — |  |  |
| Restructuring expenses |  |  | 402 |  |  |  | — |  |  |  | — |  |  |  |  | 402 |  |  |  | — |  |  |
| Stock-based compensation expense |  |  | 300 |  |  |  | 231 |  |  |  | — |  |  |  |  | 531 |  |  |  | — |  |  |
| Pension adjustments(3) |  |  | (46 | ) |  |  | 60 |  |  |  | — |  |  |  |  | 14 |  |  |  | — |  |  |
| Non-GAAP Net Income attributable to non-controlling interest (1) |  | $ | 5,769 |  |  | $ | 4,486 |  |  | $ | — |  |  |  | $ | 10,255 |  |  | $ | — |  |  |
| Weighted average shares outstanding – basic |  |  | 77,659 |  |  |  | 73,036 |  |  |  | 48,914 |  |  |  |  | 62,346 |  |  |  | 48,582 |  |  |
| Weighted average shares outstanding – diluted |  |  | 79,243 |  |  |  | 73,036 |  |  |  | 48,914 |  |  |  |  | 62,346 |  |  |  | 48,582 |  |  |
| Earnings (loss) per common share attributable to ADTRAN Holdings, Inc. - basic |  | $ | 0.50 |  |  | $ | (0.57 | ) |  | $ | (0.09 | ) |  |  | $ | (0.03 | ) |  | $ | (0.18 | ) |  |
| Earnings (loss) per common share attributable to ADTRAN Holdings, Inc. - diluted |  | $ | 0.49 |  |  | $ | (0.57 | ) |  | $ | (0.09 | ) |  |  | $ | (0.03 | ) |  | $ | (0.18 | ) |  |
| Non-GAAP Earnings per common share attributable to ADTRAN Holdings, Inc. - basic |  | $ | 0.13 |  |  | $ | 0.11 |  |  | $ | 0.10 |  |  |  | $ | 0.60 |  |  | $ | 0.38 |  |  |
| Non-GAAP Earnings per common share attributable to ADTRAN Holdings, Inc. - diluted |  | $ | 0.12 |  |  | $ | 0.11 |  |  | $ | 0.10 |  |  |  | $ | 0.60 |  |  | $ | 0.38 |  |  |

[0000950170-23-003277:8k_2_02:98]
(1) Represents the non-controlling interest portion of the Company's ownership of ADVA.

[0000950170-23-003277:8k_2_02:99]
(2) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-23-003277:8k_2_02:100]
(3) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.
