# ADTN note change history — 0001193125-15-366072 → 0001193125-16-576994


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001193125-16-576994:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of March 31, 2016, of which $7.7 million has been applied to
 these commitments.
  (was, 2015-11-04, similarity 0.9652):
[0001193125-15-366072:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of September 30, 2015, of which $7.7 million has been applied
 to these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001193125-16-576994:note_history:2]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter of 2015. The aggregate
 impact of the corrections was a $0.8 million reduction to pre-tax
 income for the three months ended March 31, 2015 and was not
 material to the prior year quarterly or annual results.
  (was, 2015-11-04, similarity 0.8612):
[0001193125-15-366072:note_history:2]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter of 2015. The aggregate
 impact of the corrections was a $0.8 million reduction to pre-tax
 income for the nine months ended September 30, 2015 and is not
 expected to be material to the current year annual results.

- added (2016-05-04):
[0001193125-16-576994:note_history:3]
In November 2015, the FASB issued Accounting Standards Update
 No. 2015-17, Balance Sheet Classification of Deferred
 Taxes (ASU 2015-17). ASU 2015-17 amends the existing guidance
 on income taxes to require the classification of all deferred tax
 assets and liabilities as non-current on the balance sheet. ASU
 2015-17 is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 years. Early adoption is permitted. The guidance may be applied
 either prospectively, for all deferred tax assets and liabilities,
 or retrospectively to all periods presented. We have not selected a
 transition method or determined whether to early adopt ASU 2015-17
 in 2016. Other than the revised balance sheet presentation of
 current deferred tax assets and liabilities, we do not believe the
 adoption of ASU 2015-17 will have a material impact on our
 financial position, results of operations and cash flows.

- added (2016-05-04):
[0001193125-16-576994:note_history:4]
In February 2016, the FASB issued Accounting Standards Update
 No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU
 2016-02 requires an entity to recognize lease assets and lease
 liabilities on the balance sheet and to disclose key information
 about the entity’s leasing arrangements. ASU 2016-02 is
 effective for fiscal years beginning after December 15, 2018,
 and interim periods within those fiscal years, with early adoption
 permitted. A modified retrospective approach is required. We are
 currently evaluating the impact that the adoption of ASU 2016-02
 will have on our financial position, results of operations and cash
 flows.

- added (2016-05-04):
[0001193125-16-576994:note_history:5]
In March 2016, the FASB issued Accounting Standards Update
 No. 2016-09, Compensation – Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting
 (ASU 2016-09). ASU 2016-09 simplifies several aspects of accounting
 for share-based compensation arrangements, including income tax
 effects, the classification of tax-related cash flows on the
 statement of cash flows, and accounting for forfeitures. ASU
 2016-09 is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 years. Early adoption is permitted. We are currently evaluating the
 impact that the adoption of ASU 2016-09 will have on our financial
 position, results of operations and cash flows.

- added (2016-05-04):
[0001193125-16-576994:note_history:6]
During the first quarter of 2016, we adopted the following
 accounting standards, which had no material effect on our financial
 position, results of operations or cash flows:

- changed (2016-05-04):
[0001193125-16-576994:note_history:7]
In April 2015, the FASB issued Accounting Standards Update
 No. 2015-05, Intangibles – Goodwill and Other –
 Internal-Use Software (Subtopic 350-40): Customer’s
 Accounting for Fees Paid in a Cloud Computing Arrangement (ASU
 2015-05), which provides guidance on accounting for fees paid by a
 customer in a cloud computing arrangement. If a cloud computing
 arrangement includes a software license, then the customer should
 account for the software license element of the arrangement
 consistent with the acquisition of other software licenses. If a
 cloud computing arrangement does not include a software license,
 the customer should account for the arrangement as a service
 contract. ASU 2015-05 is effective for annual reporting periods
 beginning after December 15, 2015, including interim periods
 within that reporting period. The amendments may be applied either
 prospectively to all arrangements entered into or materially
 modified after the effective date or retrospectively. We adopted
 ASU 2015-05 during the first quarter of 2016 and will apply the new
 standard prospectively. The adoption of ASU 2015-05 did not have a
 material impact on our financial position, results of operations
 and cash flows.
  (was, 2015-11-04, similarity 0.8509):
[0001193125-15-366072:note_history:7]
In April 2015, the FASB issued Accounting Standards Update
 No. 2015-05, Intangibles – Goodwill and Other –
 Internal-Use Software (Subtopic 350-40): Customer’s
 Accounting for Fees Paid in a Cloud Computing Arrangement (ASU
 2015-05), which provides guidance on accounting for fees paid by a
 customer in a cloud computing arrangement. If a cloud computing
 arrangement includes a software license, then the customer should
 account for the software license element of the arrangement
 consistent with the acquisition of other software licenses. If a
 cloud computing arrangement does not include a software license,
 the customer should account for the arrangement as a service
 contract. ASU 2015-05 is effective for annual reporting periods
 beginning after December 15, 2015, including interim periods
 within that reporting period. Early adoption is permitted. The
 amendments may be applied either prospectively to all arrangements
 entered into or materially modified after the effective date or
 retrospectively. We do not believe the adoption of ASU 2015-05 will
 have a material impact on our financial position, results of
 operations and cash flows.

- removed (2016-05-04):
[0001193125-15-366072:note_history:8]
Changes in Classifications

- removed (2016-05-04):
[0001193125-15-366072:note_history:9]
We reclassified $2.3 million from other receivables to accounts
 receivable at December 31, 2014 to conform to the current
 period presentation.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001193125-16-576994:note_history:10]
At March 31, 2016, we held the following securities and
 investments, recorded at either fair value or cost.
  (was, 2015-11-04, similarity 0.9515):
[0001193125-15-366072:note_history:10]
At September 30, 2015, we held the following securities and
 investments, recorded at either fair value or cost.

- changed (2016-05-04):
[0001193125-16-576994:note_history:11]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 11,440 |  |  | $ | 1,634 |  |  | $ | (70 | ) |  | $ | 13,004 |  |
| Corporate bonds |  |  | 61,154 |  |  |  | 89 |  |  |  | (386 | ) |  |  | 60,857 |  |
| Municipal fixed-rate bonds |  |  | 15,659 |  |  |  | 54 |  |  |  | (1 | ) |  |  | 15,712 |  |
| Asset-backed bonds |  |  | 20,540 |  |  |  | 28 |  |  |  | (8 | ) |  |  | 20,560 |  |
| Mortgage/Agency-backed bonds |  |  | 14,959 |  |  |  | 19 |  |  |  | (82 | ) |  |  | 14,896 |  |
| Government bonds |  |  | 33,205 |  |  |  | 216 |  |  |  | (2 | ) |  |  | 33,419 |  |
| Variable Rate Demand Notes |  |  | 2,235 |  |  |  | — |  |  |  | — |  |  |  | 2,235 |  |
| Marketable equity securities |  |  | 31,798 |  |  |  | 2,886 |  |  |  | (1,647 | ) |  |  | 33,037 |  |
| Available-for-sale securities held at fair value |  | $ | 190,990 |  |  | $ | 4,926 |  |  | $ | (2,196 | ) |  | $ | 193,720 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,266 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 224,986 |  |
  (was, 2015-11-04, similarity 0.9634):
[0001193125-15-366072:note_history:11]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 14,226 |  |  | $ | 1,536 |  |  | $ | (221 | ) |  | $ | 15,541 |  |
| Corporate bonds |  |  | 87,555 |  |  |  | 38 |  |  |  | (790 | ) |  |  | 86,803 |  |
| Municipal fixed-rate bonds |  |  | 51,971 |  |  |  | 129 |  |  |  | (20 | ) |  |  | 52,080 |  |
| Asset-backed bonds |  |  | 5,490 |  |  |  | — |  |  |  | (3 | ) |  |  | 5,487 |  |
| Mortgage/Agency-backed bonds |  |  | 8,422 |  |  |  | 21 |  |  |  | (15 | ) |  |  | 8,428 |  |
| Government bonds |  |  | 14,217 |  |  |  | 74 |  |  |  | (2 | ) |  |  | 14,289 |  |
| Marketable equity securities |  |  | 29,508 |  |  |  | 5,462 |  |  |  | (2,375 | ) |  |  | 32,595 |  |
| Available-for-sale securities held at fair value |  | $ | 211,389 |  |  | $ | 7,260 |  |  | $ | (3,426 | ) |  | $ | 215,223 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,371 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 246,594 |  |

- changed (2016-05-04):
[0001193125-16-576994:note_history:12]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 11,325 |  |  | $ | 1,575 |  |  | $ | (66 | ) |  | $ | 12,834 |  |
| Corporate bonds |  |  | 58,328 |  |  |  | 20 |  |  |  | (734 | ) |  |  | 57,614 |  |
| Municipal fixed-rate bonds |  |  | 26,414 |  |  |  | 28 |  |  |  | (18 | ) |  |  | 26,424 |  |
| Asset-backed bonds |  |  | 19,281 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 19,239 |  |
| Mortgage/Agency-backed bonds |  |  | 15,463 |  |  |  | 1 |  |  |  | (91 | ) |  |  | 15,373 |  |
| Government bonds |  |  | 35,646 |  |  |  | — |  |  |  | (248 | ) |  |  | 35,398 |  |
| Marketable equity securities |  |  | 31,643 |  |  |  | 4,301 |  |  |  | (1,693 | ) |  |  | 34,251 |  |
| Available-for-sale securities held at fair value |  | $ | 198,100 |  |  | $ | 5,927 |  |  | $ | (2,894 | ) |  | $ | 201,133 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,289 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 232,422 |  |
  (was, 2015-11-04, similarity 0.8906):
[0001193125-15-366072:note_history:12]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 13,897 |  |  | $ | 2,409 |  |  | $ | (12 | ) |  | $ | 16,294 |  |
| Corporate bonds |  |  | 111,261 |  |  |  | 186 |  |  |  | (186 | ) |  |  | 111,261 |  |
| Municipal fixed-rate bonds |  |  | 127,341 |  |  |  | 480 |  |  |  | (34 | ) |  |  | 127,787 |  |
| Municipal variable rate demand notes |  |  | 2,465 |  |  |  | — |  |  |  | — |  |  |  | 2,465 |  |
| Marketable equity securities |  |  | 26,399 |  |  |  | 12,395 |  |  |  | (539 | ) |  |  | 38,255 |  |
| Available-for-sale securities held at fair value |  | $ | 281,363 |  |  | $ | 15,470 |  |  | $ | (771 | ) |  | $ | 296,062 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,506 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 327,568 |  |

- changed (2016-05-04):
[0001193125-16-576994:note_history:13]
As of March 31, 2016, our corporate bonds, municipal
 fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds,
 and government bonds had the following contractual maturities:
  (was, 2015-11-04, similarity 0.9721):
[0001193125-15-366072:note_history:13]
As of September 30, 2015, our corporate bonds, municipal
 fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds,
 and government bonds had the following contractual maturities:

- changed (2016-05-04):
[0001193125-16-576994:note_history:14]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | Government bonds |  |
| Less than one year |  | $ | 17,668 |  |  | $ | 7,147 |  |  | $ | — |  |  | $ | 1,000 |  |  | $ | 1,253 |  |
| One to two years |  |  | 29,883 |  |  |  | 5,566 |  |  |  | 190 |  |  |  | 1,300 |  |  |  | 4,751 |  |
| Two to three years |  |  | 12,490 |  |  |  | 1,373 |  |  |  | 8,158 |  |  |  | 1,774 |  |  |  | 17,992 |  |
| Three to five years |  |  | 816 |  |  |  | 226 |  |  |  | 9,496 |  |  |  | — |  |  |  | 9,423 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 2,540 |  |  |  | 1,180 |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | 1,400 |  |  |  | 176 |  |  |  | 9,642 |  |  |  | — |  |
| Total |  | $ | 60,857 |  |  | $ | 15,712 |  |  | $ | 20,560 |  |  | $ | 14,896 |  |  | $ | 33,419 |  |
  (was, 2015-11-04, similarity 0.9631):
[0001193125-15-366072:note_history:14]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | Government bonds |  |
| Less than one year |  | $ | 23,732 |  |  | $ | 16,034 |  |  | $ | — |  |  | $ | 775 |  |  | $ | — |  |
| One to two years |  |  | 35,429 |  |  |  | 27,312 |  |  |  | — |  |  |  | — |  |  |  | 4,198 |  |
| Two to three years |  |  | 27,642 |  |  |  | 7,310 |  |  |  | 1,065 |  |  |  | 1,000 |  |  |  | 1,878 |  |
| Three to five years |  |  | — |  |  |  | 1,424 |  |  |  | 4,422 |  |  |  | — |  |  |  | 8,213 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 684 |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5,969 |  |  |  | — |  |
| Total |  | $ | 86,803 |  |  | $ | 52,080 |  |  | $ | 5,487 |  |  | $ | 8,428 |  |  | $ | 14,289 |  |

- changed (2016-05-04):
[0001193125-16-576994:note_history:15]
At March 31, 2016, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 March 31, 2016, the estimated fair value of the Bond using a
 level 2 valuation technique was approximately $29.1 million, based
 on a debt security with a comparable interest rate and maturity and
 a Standard and Poor’s credit rating of AAA. For more
 information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.
  (was, 2015-11-04, similarity 0.9816):
[0001193125-15-366072:note_history:15]
At September 30, 2015, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 September 30, 2015, the estimated fair value of the Bond using
 a level 2 valuation technique was approximately $30.1 million,
 based on a debt security with a comparable interest rate and
 maturity and a Standard and Poor’s credit rating of AAA. For
 more information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

- changed (2016-05-04):
[0001193125-16-576994:note_history:16]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three months ended
 March 31, 2016 and 2015, other-than-temporary impairment
 charges were not significant.
  (was, 2015-11-04, similarity 0.9785):
[0001193125-15-366072:note_history:16]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and nine months
 ended September 30, 2015 and 2014, other-than-temporary
 impairment charges were not significant.

- changed (2016-05-04):
[0001193125-16-576994:note_history:17]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Gross realized gains |  | $ | 2,364 |  |  | $ | 3,145 |  |
| Gross realized losses |  | $ | (636 | ) |  | $ | (30 | ) |
  (was, 2015-11-04, similarity 0.7246):
[0001193125-15-366072:note_history:17]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Gross realized gains |  | $ | 2,251 |  |  | $ | 2,728 |  |  | $ | 8,856 |  |  | $ | 7,363 |  |
| Gross realized losses |  | $ | (191 | ) |  | $ | (41 | ) |  | $ | (426 | ) |  | $ | (144 | ) |

- changed (2016-05-04):
[0001193125-16-576994:note_history:18]
As of March 31, 2016 and 2015, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.
  (was, 2015-11-04, similarity 0.9677):
[0001193125-15-366072:note_history:18]
As of September 30, 2015 and 2014, gross unrealized losses
 related to individual securities in a continuous loss position for
 12 months or longer were not significant.

- changed (2016-05-04):
[0001193125-16-576994:note_history:19]
|  |  | Fair Value Measurements at March 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,110 |  |  | $ | 2,110 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 26,442 |  |  |  | — |  |  |  | 26,442 |  |  |  | — |  |
| Cash equivalents |  |  | 28,552 |  |  |  | 2,110 |  |  |  | 26,442 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,004 |  |  |  | 13,004 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 60,857 |  |  |  | — |  |  |  | 60,857 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 15,712 |  |  |  | — |  |  |  | 15,712 |  |  |  | — |  |
| Asset-backed bonds |  |  | 20,560 |  |  |  | — |  |  |  | 20,560 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 14,896 |  |  |  | — |  |  |  | 14,896 |  |  |  | — |  |
| Government bonds |  |  | 33,419 |  |  |  | 33,419 |  |  |  | — |  |  |  | — |  |
| Variable Rate Demand Notes |  |  | 2,235 |  |  |  | — |  |  |  | 2,235 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 4,709 |  |  |  | 4,709 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,328 |  |  |  | 28,328 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 193,720 |  |  |  | 79,460 |  |  |  | 114,260 |  |  |  | — |  |
| Total |  | $ | 222,272 |  |  | $ | 81,570 |  |  | $ | 140,702 |  |  | $ | — |  |
  (was, 2015-11-04, similarity 0.7287):
[0001193125-15-366072:note_history:19]
|  |  | Fair Value Measurements at September 30, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,171 |  |  | $ | 6,171 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,541 |  |  |  | 15,541 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 52,080 |  |  |  | — |  |  |  | 52,080 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,487 |  |  |  | — |  |  |  | 5,487 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,428 |  |  |  | — |  |  |  | 8,428 |  |  |  | — |  |
| Government bonds |  |  | 14,289 |  |  |  | 13,289 |  |  |  | 1,000 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,701 |  |  |  | 5,701 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 26,894 |  |  |  | 26,894 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 215,223 |  |  |  | 61,425 |  |  |  | 153,798 |  |  |  | — |  |
| Total |  | $ | 221,394 |  |  | $ | 67,596 |  |  | $ | 153,798 |  |  | $ | — |  |

- changed (2016-05-04):
[0001193125-16-576994:note_history:20]
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,271 |  |  | $ | 1,271 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 11,696 |  |  |  | — |  |  |  | 11,696 |  |  |  | — |  |
| Cash equivalents |  |  | 12,967 |  |  |  | 1,271 |  |  |  | 11,696 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,834 |  |  |  | 12,834 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 57,614 |  |  |  | — |  |  |  | 57,614 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 26,424 |  |  |  | — |  |  |  | 26,424 |  |  |  | — |  |
| Asset-backed bonds |  |  | 19,239 |  |  |  | — |  |  |  | 19,239 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 15,373 |  |  |  | — |  |  |  | 15,373 |  |  |  | — |  |
| Government bonds |  |  | 35,398 |  |  |  | 35,398 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,384 |  |  |  | 5,384 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,867 |  |  |  | 28,867 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 201,133 |  |  |  | 82,483 |  |  |  | 118,650 |  |  |  | — |  |
| Total |  | $ | 214,100 |  |  | $ | 83,754 |  |  | $ | 130,346 |  |  | $ | — |  |
  (was, 2015-11-04, similarity 0.863):
[0001193125-15-366072:note_history:20]
|  |  | Fair Value Measurements at December 31, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,163 |  |  | $ | 1,163 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 16,294 |  |  |  | 16,294 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 111,261 |  |  |  | — |  |  |  | 111,261 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 127,787 |  |  |  | — |  |  |  | 127,787 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 2,465 |  |  |  | — |  |  |  | 2,465 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 9,661 |  |  |  | 9,661 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,594 |  |  |  | 28,594 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 296,062 |  |  |  | 54,549 |  |  |  | 241,513 |  |  |  | — |  |
| Total |  | $ | 297,225 |  |  | $ | 55,712 |  |  | $ | 241,513 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2016-05-04):
[0001193125-15-366072:note_history:21]
13. RELATED PARTY TRANSACTIONS

- removed (2016-05-04):
[0001193125-15-366072:note_history:22]
During 2014, we employed the law firm of our director emeritus for
 legal services. All bills for services rendered by this firm were
 reviewed and approved by our Chief Financial Officer. We believe
 that the fees for such services were comparable to those charged by
 other firms for services rendered to us. The services of our
 director emeritus ended with his death on September 7, 2014.
 For the three and nine months ended September 30, 2014, we
 incurred fees of $10 thousand and $70 thousand, respectively, for
 these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001193125-16-576994:note_history:23]
On April 12, 2016, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 April 28, 2016. The payment date will be May 12, 2016.
 The quarterly dividend payment will be approximately $4.4 million.
 In July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.
  (was, 2015-11-04, similarity 0.963):
[0001193125-15-366072:note_history:23]
On October 13, 2015, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 October 29, 2015. The payment date will be November 12,
 2015. The quarterly dividend payment will be approximately $4.5
 million. In July 2003, our Board of Directors elected to begin
 declaring quarterly dividends on our common stock considering the
 tax treatment of dividends and adequate levels of Company
 liquidity.

- added (2016-05-04):
[0001193125-16-576994:note_history:24]
During the second quarter and as of May 4, 2016, we have
 repurchased 30 thousand shares of our common stock through
 open market purchases at an average cost of $18.64 per share. We
 currently have the authority to purchase an additional
 5.2 million shares of our common stock under the current plan
 approved by the Board of Directors.
