# ADTN 8-K — 0001193125-16-539019 filed 2016-04-13

## item codes, every 8-K on or before 2016-05-04

- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2016-05-04

- none on or before 2016-05-04

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-539019:8k_2_02:1]
EX-99.1
2
d179722dex991.htm
EX-99.1

[0001193125-16-539019:8k_2_02:2]
EX-99.1

[0001193125-16-539019:8k_2_02:3]
EXHIBIT 99.1

[0001193125-16-539019:8k_2_02:4]
ADTRAN, Inc.

[0001193125-16-539019:8k_2_02:5]
REPORTS RESULTS for the FIRST QUARTER 2016

[0001193125-16-539019:8k_2_02:6]
and DECLARES QUARTERLY CASH DIVIDEND

[0001193125-16-539019:8k_2_02:7]
HUNTSVILLE, AL.—April 12, 2016—ADTRAN, Inc. (NASDAQ:ADTN) reported results for the first quarter 2016. For the quarter, sales were
$142,204,000 compared to $142,835,000 for the first quarter of 2015. Net income was $5,014,000 compared to $3,317,000 for the first quarter of 2015. Earnings per share, assuming dilution, were $0.10 compared to $0.06 for the first quarter of 2015.
Non-GAAP earnings per share were $0.14 compared to $0.10 for the first quarter of 2015. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-16-539019:8k_2_02:8]
ADTRAN Chief Executive Officer Tom Stanton stated, “ADTRAN delivered a solid performance this quarter resulting in earnings coming in ahead of initial
expectations. Compared to the same period last year, Q1 domestic revenue was up over 39% with increases in both our products and services businesses. Improved gross margins and lower operating expenses helped us increase operating income over 181%
versus Q1 of 2015. Longer term, we expect further improvement in the carrier environment as customers accelerate investments in upgrading their network infrastructure to meet customer demand.”

[0001193125-16-539019:8k_2_02:9]
The Company also announced that its Board of Directors declared a cash dividend for the first quarter of 2016. The quarterly cash dividend is $0.09 per common
share to be paid to holders of record at the close of business on April 28, 2016. The ex-dividend date is April 26, 2016 and the payment date is May 12, 2016.

[0001193125-16-539019:8k_2_02:10]
As was previously announced, ADTRAN has changed it financial reporting segments as of the quarter ended March 31, 2016. The Company will now report its
financial performance based on two new reportable segments – Network Solutions and Services & Support. ADTRAN will post supplemental information regarding revenues by operating segment and category under its new and former reporting
structure for the fiscal quarter ended March 31, 2016, and recast financial segment information for the four quarters and full year for fiscal years 2014 and 2015, as if reported under the new operating reporting structure, on the Investor Relations
page of its website at www.adtran.com.

[0001193125-16-539019:8k_2_02:11]
The Company confirmed that its first quarter conference call will be held Wednesday, April 13, 2016 at 9:30
a.m. Central Time. This conference call will be web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the
call and click on the conference call link provided.

[0001193125-16-539019:8k_2_02:12]
An online replay of the conference call will be available for seven days at
www.streetevents.com. In addition, an online replay of the conference call, as well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following
the call.

[0001193125-16-539019:8k_2_02:13]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and
Internet communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please
visit www.adtran.com.

[0001193125-16-539019:8k_2_02:14]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web,
visit www.adtran.com.

[0001193125-16-539019:8k_2_02:15]
This press release contains forward-looking statements which reflect management’s best judgment based on factors
currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component
costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2015. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking
statements included in this press release.

[0001193125-16-539019:8k_2_02:16]
| CONTACT: Roger Shannon Senior Vice President & CFO 256-963-8775 |  | INVESTOR SERVICES/ASSISTANCE: Gayle Ellis Investor Services 256-963-8220 |

[0001193125-16-539019:8k_2_02:17]
Condensed Consolidated Balance Sheet

[0001193125-16-539019:8k_2_02:18]
(Unaudited)

[0001193125-16-539019:8k_2_02:19]
(In
thousands)

[0001193125-16-539019:8k_2_02:20]
|  |  | March 31,2016 |  |  | December 31,2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 91,609 |  |  | $ | 84,550 |  |
| Short-term investments |  |  | 29,303 |  |  |  | 34,396 |  |
| Accounts receivable, net |  |  | 67,492 |  |  |  | 71,917 |  |
| Other receivables |  |  | 9,199 |  |  |  | 19,321 |  |
| Inventory |  |  | 92,107 |  |  |  | 91,533 |  |
| Prepaid expenses and other current assets |  |  | 13,096 |  |  |  | 10,145 |  |
| Deferred tax assets, net |  |  | 17,967 |  |  |  | 18,924 |  |
| Total Current Assets |  |  | 320,773 |  |  |  | 330,786 |  |
| Property, plant and equipment, net |  |  | 73,511 |  |  |  | 73,233 |  |
| Deferred tax assets, net |  |  | 18,878 |  |  |  | 18,091 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 9,157 |  |  |  | 9,276 |  |
| Long-term investments |  |  | 195,683 |  |  |  | 198,026 |  |
| Total Assets |  | $ | 621,494 |  |  | $ | 632,904 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 42,635 |  |  | $ | 48,668 |  |
| Unearned revenue |  |  | 18,683 |  |  |  | 16,615 |  |
| Accrued expenses |  |  | 13,513 |  |  |  | 12,108 |  |
| Accrued wages and benefits |  |  | 11,064 |  |  |  | 12,857 |  |
| Income tax payable, net |  |  | 2,739 |  |  |  | 2,395 |  |
| Total Current Liabilities |  |  | 88,634 |  |  |  | 92,643 |  |
| Non-current unearned revenue |  |  | 7,288 |  |  |  | 7,965 |  |
| Other non-current liabilities |  |  | 25,283 |  |  |  | 24,236 |  |
| Bonds payable |  |  | 27,900 |  |  |  | 27,900 |  |
| Total Liabilities |  |  | 149,105 |  |  |  | 152,744 |  |
| Stockholders’ Equity |  |  | 472,389 |  |  |  | 480,160 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 621,494 |  |  | $ | 632,904 |  |

[0001193125-16-539019:8k_2_02:21]
2

[0001193125-16-539019:8k_2_02:22]
Consolidated Statements of Income

[0001193125-16-539019:8k_2_02:23]
(Unaudited)

[0001193125-16-539019:8k_2_02:24]
(In
thousands, except per share data)

[0001193125-16-539019:8k_2_02:25]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Sales |  |  |  |  |  |  |  |  |
| Products |  | $ | 123,883 |  |  | $ | 129,505 |  |
| Services |  |  | 18,321 |  |  |  | 13,330 |  |
| Total sales |  |  | 142,204 |  |  |  | 142,835 |  |
| Cost of sales |  |  |  |  |  |  |  |  |
| Products |  |  | 64,073 |  |  |  | 71,560 |  |
| Services |  |  | 12,337 |  |  |  | 5,712 |  |
| Total cost of sales |  |  | 76,410 |  |  |  | 77,272 |  |
| Gross Profit |  |  | 65,794 |  |  |  | 65,563 |  |
| Selling, general and administrative expenses |  |  | 30,785 |  |  |  | 31,064 |  |
| Research and development expenses |  |  | 29,488 |  |  |  | 32,536 |  |
| Operating Income |  |  | 5,521 |  |  |  | 1,963 |  |
| Interest and dividend income |  |  | 855 |  |  |  | 933 |  |
| Interest expense |  |  | (145 | ) |  |  | (148 | ) |
| Net realized investment gain |  |  | 1,728 |  |  |  | 3,115 |  |
| Other income (expense), net |  |  | 119 |  |  |  | (353 | ) |
| Income before provision for income taxes |  |  | 8,078 |  |  |  | 5,510 |  |
| Provision for income taxes |  |  | (3,064 | ) |  |  | (2,193 | ) |
| Net Income |  | $ | 5,014 |  |  | $ | 3,317 |  |
| Weighted average shares outstanding - basic |  |  | 49,220 |  |  |  | 53,399 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 49,389 |  |  |  | 53,634 |  |
| Earnings per common share - basic |  | $ | 0.10 |  |  | $ | 0.06 |  |
| Earnings per common share - diluted (1) |  | $ | 0.10 |  |  | $ | 0.06 |  |

[0001193125-16-539019:8k_2_02:26]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001193125-16-539019:8k_2_02:27]
3

[0001193125-16-539019:8k_2_02:28]
Consolidated Statements of Comprehensive Income

[0001193125-16-539019:8k_2_02:29]
(Unaudited)

[0001193125-16-539019:8k_2_02:30]
(In
thousands)

[0001193125-16-539019:8k_2_02:31]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Net Income |  | $ | 5,014 |  |  | $ | 3,317 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |
| Unrealized losses on available-for-sale securities |  |  | (255 | ) |  |  | (503 | ) |
| Defined benefit plan adjustments |  |  | 45 |  |  |  | 68 |  |
| Foreign currency translation |  |  | 1,228 |  |  |  | (3,318 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  | 1,018 |  |  |  | (3,753 | ) |
| Comprehensive Income (Loss), net of tax |  | $ | 6,032 |  |  | $ | (436 | ) |

[0001193125-16-539019:8k_2_02:32]
4

[0001193125-16-539019:8k_2_02:33]
Consolidated Statements of Cash Flows

[0001193125-16-539019:8k_2_02:34]
(Unaudited)

[0001193125-16-539019:8k_2_02:35]
(In
thousands)

[0001193125-16-539019:8k_2_02:36]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 5,014 |  |  | $ | 3,317 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,347 |  |  |  | 3,728 |  |
| Amortization of net premium on available-for-sale investments |  |  | 220 |  |  |  | 910 |  |
| Net realized gain on long-term investments |  |  | (1,728 | ) |  |  | (3,115 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 3 |  |  |  | 8 |  |
| Stock-based compensation expense |  |  | 1,558 |  |  |  | 1,639 |  |
| Deferred income taxes |  |  | 435 |  |  |  | (692 | ) |
| Tax benefit from stock option exercises |  |  | — |  |  |  | 8 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | — |  |  |  | (9 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 4,752 |  |  |  | (4,571 | ) |
| Other receivables |  |  | 10,200 |  |  |  | 511 |  |
| Inventory |  |  | 163 |  |  |  | (7,261 | ) |
| Prepaid expenses and other assets |  |  | (3,083 | ) |  |  | (736 | ) |
| Accounts payable |  |  | (6,520 | ) |  |  | 20,084 |  |
| Accrued expenses and other liabilities |  |  | 902 |  |  |  | (282 | ) |
| Income tax payable, net |  |  | 413 |  |  |  | (524 | ) |
| Net cash provided by operating activities |  |  | 15,676 |  |  |  | 13,015 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (3,166 | ) |  |  | (2,442 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 60,586 |  |  |  | 58,075 |  |
| Purchases of available-for-sale investments |  |  | (52,053 | ) |  |  | (44,584 | ) |
| Net cash provided by investing activities |  |  | 5,367 |  |  |  | 11,049 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 247 |  |  |  | 280 |  |
| Purchases of treasury stock |  |  | (11,003 | ) |  |  | (3,035 | ) |
| Dividend payments |  |  | (4,453 | ) |  |  | (4,811 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | — |  |  |  | 9 |  |
| Net cash used in financing activities |  |  | (15,209 | ) |  |  | (7,557 | ) |
| Net increase in cash and cash equivalents |  |  | 5,834 |  |  |  | 16,507 |  |
| Effect of exchange rate changes |  |  | 1,225 |  |  |  | (2,937 | ) |
| Cash and cash equivalents, beginning of period |  |  | 84,550 |  |  |  | 73,439 |  |
| Cash and cash equivalents, end of period |  | $ | 91,609 |  |  | $ | 87,009 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 485 |  |  | $ | 784 |  |

[0001193125-16-539019:8k_2_02:37]
Supplemental Information

[0001193125-16-539019:8k_2_02:38]
Stock-based Compensation Expense

[0001193125-16-539019:8k_2_02:39]
(Unaudited)

[0001193125-16-539019:8k_2_02:40]
(In
thousands)

[0001193125-16-539019:8k_2_02:41]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 91 |  |  | $ | 90 |  |
| Selling, general and administrative expense |  |  | 810 |  |  |  | 691 |  |
| Research and development expense |  |  | 657 |  |  |  | 858 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,467 |  |  |  | 1,549 |  |
| Total stock-based compensation expense |  |  | 1,558 |  |  |  | 1,639 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (212 | ) |  |  | (180 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,346 |  |  | $ | 1,459 |  |

[0001193125-16-539019:8k_2_02:42]
6

[0001193125-16-539019:8k_2_02:43]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-16-539019:8k_2_02:44]
Non-GAAP net income per share, diluted

[0001193125-16-539019:8k_2_02:45]
(Unaudited)

[0001193125-16-539019:8k_2_02:46]
|  |  | Three Months Ended March 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| GAAP earnings per common share – diluted |  | $ | 0.10 |  |  | $ | 0.06 |  |
| Amortization of acquired intangible assets |  |  | 0.01 |  |  |  | 0.01 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.14 |  |  | $ | 0.10 |  |
