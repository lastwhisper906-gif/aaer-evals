# ADTN notes — 0001193125-16-576994


## us-gaap:DividendsDeclaredTableTextBlock

[0001193125-16-576994:notes:1]
During the three months ended March 31, 2016, we paid cash
 dividends as follows (in thousands except per share amounts):

[0001193125-16-576994:notes:2]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 4, 2016 |  | February 18, 2016 |  | $ | 0.09 |  |  | $ | 4,453 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-16-576994:notes:3]
[same as prior period, unchanged from 0001193125-15-366072:notes:3]

[0001193125-16-576994:notes:4]
|  |  | Fair Value Measurements at March 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,110 |  |  | $ | 2,110 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 26,442 |  |  |  | — |  |  |  | 26,442 |  |  |  | — |  |
| Cash equivalents |  |  | 28,552 |  |  |  | 2,110 |  |  |  | 26,442 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,004 |  |  |  | 13,004 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 60,857 |  |  |  | — |  |  |  | 60,857 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 15,712 |  |  |  | — |  |  |  | 15,712 |  |  |  | — |  |
| Asset-backed bonds |  |  | 20,560 |  |  |  | — |  |  |  | 20,560 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 14,896 |  |  |  | — |  |  |  | 14,896 |  |  |  | — |  |
| Government bonds |  |  | 33,419 |  |  |  | 33,419 |  |  |  | — |  |  |  | — |  |
| Variable Rate Demand Notes |  |  | 2,235 |  |  |  | — |  |  |  | 2,235 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 4,709 |  |  |  | 4,709 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,328 |  |  |  | 28,328 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 193,720 |  |  |  | 79,460 |  |  |  | 114,260 |  |  |  | — |  |
| Total |  | $ | 222,272 |  |  | $ | 81,570 |  |  | $ | 140,702 |  |  | $ | — |  |

[0001193125-16-576994:notes:5]
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,271 |  |  | $ | 1,271 |  |  | $ | — |  |  | $ | — |  |
| Commercial Paper |  |  | 11,696 |  |  |  | — |  |  |  | 11,696 |  |  |  | — |  |
| Cash equivalents |  |  | 12,967 |  |  |  | 1,271 |  |  |  | 11,696 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,834 |  |  |  | 12,834 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 57,614 |  |  |  | — |  |  |  | 57,614 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 26,424 |  |  |  | — |  |  |  | 26,424 |  |  |  | — |  |
| Asset-backed bonds |  |  | 19,239 |  |  |  | — |  |  |  | 19,239 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 15,373 |  |  |  | — |  |  |  | 15,373 |  |  |  | — |  |
| Government bonds |  |  | 35,398 |  |  |  | 35,398 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,384 |  |  |  | 5,384 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,867 |  |  |  | 28,867 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 201,133 |  |  |  | 82,483 |  |  |  | 118,650 |  |  |  | — |  |
| Total |  | $ | 214,100 |  |  | $ | 83,754 |  |  | $ | 130,346 |  |  | $ | — |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-16-576994:notes:6]
[same as prior period, unchanged from 0001193125-15-366072:notes:6]

[0001193125-16-576994:notes:7]
[same as prior period, unchanged from 0001193125-15-366072:notes:7]

[0001193125-16-576994:notes:8]
The following table summarizes the components of net periodic
 pension cost for the three months ended March 31, 2016 and
 2015:

[0001193125-16-576994:notes:9]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Service cost |  | $ | 297 |  |  | $ | 340 |  |
| Interest cost |  |  | 176 |  |  |  | 159 |  |
| Expected return on plan assets |  |  | (259 | ) |  |  | (261 | ) |
| Amortization of actuarial losses |  |  | 43 |  |  |  | 105 |  |
| Net periodic pension cost |  | $ | 257 |  |  | $ | 343 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-16-576994:notes:10]
A summary of the changes in stockholders’ equity for the
 three months ended March 31, 2016 is as follows:

[0001193125-16-576994:notes:11]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2015 |  | $ | 480,160 |  |
| Net income |  |  | 5,014 |  |
| Dividend payments |  |  | (4,453 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (20 | ) |
| Net unrealized losses on available-for-sale securities (net of tax) |  |  | (255 | ) |
| Defined benefit plan adjustments |  |  | 45 |  |
| Foreign currency translation adjustment |  |  | 1,228 |  |
| Proceeds from stock option exercises |  |  | 247 |  |
| Purchase of treasury stock |  |  | (11,003 | ) |
| Income tax effect of stock compensation arrangements |  |  | (132 | ) |
| Stock-based compensation expense |  |  | 1,558 |  |
| Balance, March 31, 2016 |  | $ | 472,389 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-16-576994:notes:12]
[same as prior period, unchanged from 0001193125-15-366072:notes:12]

[0001193125-16-576994:notes:13]
Our products generally include warranties of 90 days to ten years
 for product defects. We accrue for warranty returns at the time
 revenue is recognized based on our estimate of the cost to repair
 or replace the defective products. We engage in extensive product
 quality programs and processes, including actively monitoring and
 evaluating the quality of our component suppliers. Our products
 continue to become more complex in both size and functionality as
 many of our product offerings migrate from line card applications
 to total systems. The increasing complexity of our products will
 cause warranty incidences, when they arise, to be more costly. Our
 estimates regarding future warranty obligations may change due to
 product failure rates, material usage, and other rework costs
 incurred in correcting a product failure. In addition, from time to
 time, specific warranty accruals may be recorded if unforeseen
 problems arise. Should our actual experience relative to these
 factors be worse than our estimates, we will be required to record
 additional warranty expense. Alternatively, if we provide for more
 reserves than we require, we will reverse a portion of such
 provisions in future periods. The liability for warranty
 obligations totaled $9.0 million and $8.7 million at March 31,
 2016 and December 31, 2015, respectively. These liabilities
 are included in accrued expenses in the accompanying Consolidated
 Balance Sheets.

[0001193125-16-576994:notes:14]
A summary of warranty expense and write-off activity for the three
 months ended March 31, 2016 and 2015 is as follows:

[0001193125-16-576994:notes:15]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 8,739 |  |  | $ | 8,415 |  |
| Plus: Amounts charged to cost and expenses |  |  | 898 |  |  |  | 461 |  |
| Less: Deductions |  |  | (595 | ) |  |  | (192 | ) |
| Balance at end of period |  | $ | 9,042 |  |  | $ | 8,684 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-16-576994:notes:16]
5. INVESTMENTS

[0001193125-16-576994:notes:17]
At March 31, 2016, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-16-576994:notes:18]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 11,440 |  |  | $ | 1,634 |  |  | $ | (70 | ) |  | $ | 13,004 |  |
| Corporate bonds |  |  | 61,154 |  |  |  | 89 |  |  |  | (386 | ) |  |  | 60,857 |  |
| Municipal fixed-rate bonds |  |  | 15,659 |  |  |  | 54 |  |  |  | (1 | ) |  |  | 15,712 |  |
| Asset-backed bonds |  |  | 20,540 |  |  |  | 28 |  |  |  | (8 | ) |  |  | 20,560 |  |
| Mortgage/Agency-backed bonds |  |  | 14,959 |  |  |  | 19 |  |  |  | (82 | ) |  |  | 14,896 |  |
| Government bonds |  |  | 33,205 |  |  |  | 216 |  |  |  | (2 | ) |  |  | 33,419 |  |
| Variable Rate Demand Notes |  |  | 2,235 |  |  |  | — |  |  |  | — |  |  |  | 2,235 |  |
| Marketable equity securities |  |  | 31,798 |  |  |  | 2,886 |  |  |  | (1,647 | ) |  |  | 33,037 |  |
| Available-for-sale securities held at fair value |  | $ | 190,990 |  |  | $ | 4,926 |  |  | $ | (2,196 | ) |  | $ | 193,720 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,266 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 224,986 |  |

[0001193125-16-576994:notes:19]
At December 31, 2015, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-16-576994:notes:20]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 11,325 |  |  | $ | 1,575 |  |  | $ | (66 | ) |  | $ | 12,834 |  |
| Corporate bonds |  |  | 58,328 |  |  |  | 20 |  |  |  | (734 | ) |  |  | 57,614 |  |
| Municipal fixed-rate bonds |  |  | 26,414 |  |  |  | 28 |  |  |  | (18 | ) |  |  | 26,424 |  |
| Asset-backed bonds |  |  | 19,281 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 19,239 |  |
| Mortgage/Agency-backed bonds |  |  | 15,463 |  |  |  | 1 |  |  |  | (91 | ) |  |  | 15,373 |  |
| Government bonds |  |  | 35,646 |  |  |  | — |  |  |  | (248 | ) |  |  | 35,398 |  |
| Marketable equity securities |  |  | 31,643 |  |  |  | 4,301 |  |  |  | (1,693 | ) |  |  | 34,251 |  |
| Available-for-sale securities held at fair value |  | $ | 198,100 |  |  | $ | 5,927 |  |  | $ | (2,894 | ) |  | $ | 201,133 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,289 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 232,422 |  |

[0001193125-16-576994:notes:21]
As of March 31, 2016, our corporate bonds, municipal
 fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds,
 and government bonds had the following contractual maturities:

[0001193125-16-576994:notes:22]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | Government bonds |  |
| Less than one year |  | $ | 17,668 |  |  | $ | 7,147 |  |  | $ | — |  |  | $ | 1,000 |  |  | $ | 1,253 |  |
| One to two years |  |  | 29,883 |  |  |  | 5,566 |  |  |  | 190 |  |  |  | 1,300 |  |  |  | 4,751 |  |
| Two to three years |  |  | 12,490 |  |  |  | 1,373 |  |  |  | 8,158 |  |  |  | 1,774 |  |  |  | 17,992 |  |
| Three to five years |  |  | 816 |  |  |  | 226 |  |  |  | 9,496 |  |  |  | — |  |  |  | 9,423 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 2,540 |  |  |  | 1,180 |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | 1,400 |  |  |  | 176 |  |  |  | 9,642 |  |  |  | — |  |
| Total |  | $ | 60,857 |  |  | $ | 15,712 |  |  | $ | 20,560 |  |  | $ | 14,896 |  |  | $ | 33,419 |  |

[0001193125-16-576994:notes:23]
Actual maturities may differ from contractual maturities because
 some borrowers have the right to call or prepay obligations with or
 without call or prepayment penalties.

[0001193125-16-576994:notes:24]
Our investment policy provides limitations for issuer
 concentration, which limits, at the time of purchase, the
 concentration in any one issuer to 5% of the market value of our
 total investment portfolio.

[0001193125-16-576994:notes:25]
At March 31, 2016, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 March 31, 2016, the estimated fair value of the Bond using a
 level 2 valuation technique was approximately $29.1 million, based
 on a debt security with a comparable interest rate and maturity and
 a Standard and Poor’s credit rating of AAA. For more
 information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

[0001193125-16-576994:notes:26]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three months ended
 March 31, 2016 and 2015, other-than-temporary impairment
 charges were not significant.

[0001193125-16-576994:notes:27]
Realized gains and losses on sales of securities are computed under
 the specific identification method. The following table presents
 gross realized gains and losses related to our investments.

[0001193125-16-576994:notes:28]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Gross realized gains |  | $ | 2,364 |  |  | $ | 3,145 |  |
| Gross realized losses |  | $ | (636 | ) |  | $ | (30 | ) |

[0001193125-16-576994:notes:29]
As of March 31, 2016 and 2015, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.

[0001193125-16-576994:notes:30]
The fair value of our Level 2 securities is calculated using a
 weighted average market price for each security. Market prices are
 obtained from a variety of industry standard data providers,
 security master files from large financial institutions, and other
 third-party sources. These multiple market prices are used as
 inputs into a distribution-curve-based algorithm to determine the
 daily market value of each security.

[0001193125-16-576994:notes:31]
Our municipal variable rate demand notes have a structure that
 implies a standard expected market price. The frequent interest
 rate resets make it reasonable to expect the price to stay at par.
 These securities are priced at the expected market price.


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-16-576994:notes:32]
The fair values of our derivative instruments recorded in the
 Consolidated Balance Sheet as of March 31, 2016 and
 December 31, 2015 were as follows:

[0001193125-16-576994:notes:33]
| (In thousands) |  | Balance Sheet Location |  | March 31, 2016 |  |  | December 31, 2015 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – liability derivatives |  | Accounts payable |  | $ | (48 | ) |  | $ | — |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-16-576994:notes:34]
As of March 31, 2016, the estimated future amortization
 expense of our intangible assets is as follows:

[0001193125-16-576994:notes:35]
| (In thousands) |  | Amount |  |
| Remainder of 2016 |  | $ | 1,257 |  |
| 2017 |  |  | 1,175 |  |
| 2018 |  |  | 710 |  |
| 2019 |  |  | 316 |  |
| 2020 |  |  | 292 |  |
| Thereafter |  |  | 1,050 |  |
| Total |  | $ | 4,800 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-16-576994:notes:36]
[same as prior period, unchanged from 0001193125-15-366072:notes:36]

[0001193125-16-576994:notes:37]
Goodwill, all of which relates to our acquisition of Bluesocket,
 Inc., was $3.5 million at March 31, 2016 and December 31,
 2015, and was previously recorded in our Enterprise Networks
 reportable segment. As a result of our new reporting structure,
 which is discussed further in Note 11, we reallocated goodwill from
 our Enterprise Networks reportable segment to our two, new
 reportable segments – Network Solutions and
 Services & Support. As a result, goodwill of $3.1 million
 and $0.4 million was reallocated to our Network Solutions and
 Services & Support reportable segments, respectively.

[0001193125-16-576994:notes:38]
We evaluate the carrying value of goodwill during the fourth
 quarter of each year and between annual evaluations if events occur
 or circumstances change that would more likely than not reduce the
 fair value of the reporting unit below its carrying amount. We have
 elected to first assess the qualitative factors to determine
 whether it is more likely than not that the fair value of the
 reporting unit to which the goodwill is assigned is less than its
 carrying amount as a basis for determining whether it is necessary
 to perform the two-step impairment test. If we determine that it is
 more likely than not that its fair value is less than its carrying
 amount, then the two-step impairment test will be performed. Based
 on the results of our qualitative assessment in 2015, we concluded
 that it was not necessary to perform the two-step impairment test.
 There have been no impairment losses recognized since the
 acquisition in 2011.

[0001193125-16-576994:notes:39]
[same as prior period, unchanged from 0001193125-15-366072:notes:38]

[0001193125-16-576994:notes:40]
The following table presents our intangible assets as of
 March 31, 2016 and December 31, 2015:

[0001193125-16-576994:notes:41]
| (In thousands) |  | March 31, 2016 |  |  | December 31, 2015 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,031 |  |  | $ | (2,856 | ) |  | $ | 3,175 |  |  | $ | 5,828 |  |  | $ | (2,627 | ) |  | $ | 3,201 |  |
| Developed technology |  |  | 5,840 |  |  |  | (4,618 | ) |  |  | 1,222 |  |  |  | 5,720 |  |  |  | (4,329 | ) |  |  | 1,391 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,937 | ) |  |  | 403 |  |  |  | 2,340 |  |  |  | (1,854 | ) |  |  | 486 |  |
| Trade names |  |  | 270 |  |  |  | (270 | ) |  |  | — |  |  |  | 270 |  |  |  | (265 | ) |  |  | 5 |  |
| Total |  | $ | 14,481 |  |  | $ | (9,681 | ) |  | $ | 4,800 |  |  | $ | 14,158 |  |  | $ | (9,075 | ) |  | $ | 5,083 |  |

[0001193125-16-576994:notes:42]
Amortization expense, all of which relates to business
 acquisitions, was $0.4 million and $0.5 million for the three
 months ended March 31, 2016 and 2015, respectively.


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0001193125-16-576994:notes:43]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the three
 months ended March 31, 2016 and 2015:

[0001193125-16-576994:notes:44]
|  |  | Three Months Ended March 31, 2016 |  |  | Three Months Ended March 31, 2015 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 1,244 |  |  | $ | (485 | ) |  | $ | 759 |  |  | $ | 2,230 |  |  | $ | (870 | ) |  | $ | 1,360 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (1,661 | ) |  |  | 648 |  |  |  | (1,013 | ) |  |  | (3,054 | ) |  |  | 1,191 |  |  |  | (1,863 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 64 |  |  |  | (20 | ) |  |  | 44 |  |  |  | 98 |  |  |  | (30 | ) |  |  | 68 |  |
| Foreign currency translation adjustment |  |  | 1,228 |  |  |  | — |  |  |  | 1,228 |  |  |  | (3,318 | ) |  |  | — |  |  |  | (3,318 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 875 |  |  | $ | 143 |  |  | $ | 1,018 |  |  | $ | (4,044 | ) |  | $ | 291 |  |  | $ | (3,753 | ) |


## us-gaap:ScheduleOfDerivativeInstrumentsGainLossInStatementOfFinancialPerformanceTextBlock

[0001193125-16-576994:notes:45]
The change in the fair values of our derivative instruments
 recorded in the Consolidated Statements of Income during the three
 months ended March 31, 2016 and 2015 were as follows:

[0001193125-16-576994:notes:46]
|  |  |  |  | Three Months Ended |  |
|  |  | Income Statement Location |  | March 31, |  |
| (In thousands) |  |  | 2016 |  |  | 2015 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | (47 | ) |  | $ | 1,476 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-576994:notes:47]
[same as prior period, unchanged from 0001193125-15-366072:notes:48]

[0001193125-16-576994:notes:48]
In 2015, we began a realignment of our organizational structure to
 better match our market opportunities, technological development
 initiatives, and improve efficiencies. During the first quarter of
 2016, our chief operating decision maker requested changes in the
 information that he regularly reviews for purposes of allocating
 resources and assessing performance. As a result, beginning with
 the quarter ended March 31, 2016, we began reporting our
 financial performance based on two, new reportable segments –
 Network Solutions and Services & Support. Network
 Solutions includes hardware products and next-generation
 virtualized solutions used in service provider or business
 networks, as well as prior-generation products. Services &
 Support includes our suite of ProCloud® managed
 services, network installation, engineering and maintenance
 services, and fee-based technical support and equipment
 repair/replacement plans.

[0001193125-16-576994:notes:49]
We evaluate the performance of our new segments based on gross
 profit; therefore, selling, general and administrative expenses,
 research and development expenses, interest and dividend income,
 interest expense, net realized investment gain/loss, other
 income/expense and provision for taxes are reported on a
 company-wide, functional basis only. Historical financial
 information by reportable segment and category, as discussed below,
 has been recast to conform to our new reporting structure. There
 are no inter-segment revenues.

[0001193125-16-576994:notes:50]
The following table presents information about the reported sales
 and gross profit of our reportable segments for the three months
 ended March 31, 2016 and 2015. We do not produce asset
 information by reportable segment; therefore, it is not
 reported.

[0001193125-16-576994:notes:51]
|  |  | Three Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 123,883 |  |  | $ | 59,810 |  |  | $ | 129,505 |  |  | $ | 57,945 |  |
| Services & Support |  |  | 18,321 |  |  |  | 5,984 |  |  |  | 13,330 |  |  |  | 7,618 |  |
| Total |  | $ | 142,204 |  |  | $ | 65,794 |  |  | $ | 142,835 |  |  | $ | 65,563 |  |

[0001193125-16-576994:notes:52]
Sales by Category

[0001193125-16-576994:notes:53]
In addition to our new reporting segments, we will also report
 revenue for the following three categories –
 Access & Aggregation, Customer Devices, and
 Traditional & Other Products.

[0001193125-16-576994:notes:54]
Access & Aggregation generally includes software
 and hardware based products and services that communication service
 providers (CSPs) use to aggregate and/or originate network access
 technologies. The portfolio of ADTRAN solutions within this
 category includes a wide array of modular or fixed physical form
 factors designed to deliver the best technology and economic fit
 for our customers based on the target subscriber density and
 environmental conditions.

[0001193125-16-576994:notes:55]
The Access & Aggregation category includes product and
 service families such as:

[0001193125-16-576994:notes:56]
|  | • |  | Total Access® 5000 Series Fiber to the Premises (FTTP) and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001193125-16-576994:notes:57]
|  | • |  | hiX 5600 Series fiber aggregation and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001193125-16-576994:notes:58]
|  | • |  | Fiber to the Distribution Point (FTTdp) Optical Network Units (ONU) |

[0001193125-16-576994:notes:59]
|  | • |  | Optical Line Terminals (OLT) |

[0001193125-16-576994:notes:60]
|  | • |  | Optical Networking Edge (ONE) aggregation |

[0001193125-16-576994:notes:61]
|  | • |  | Distribution Point Units (DPUs) |

[0001193125-16-576994:notes:62]
|  | • |  | IP Digital Subscriber Line Access Multiplexers (DSLAMs) |

[0001193125-16-576994:notes:63]
|  | • |  | Cabinet and Outside-Plant (OSP) enclosures and services |

[0001193125-16-576994:notes:64]
|  | • |  | Network Management and Cloud based software platforms and applications |

[0001193125-16-576994:notes:65]
|  | • |  | Pluggable optical transceivers (i.e., SFP, SFP+, XFP, QSFP), cables and other miscellaneous materials |

[0001193125-16-576994:notes:66]
|  | • |  | Other products and services that are generally applicable to Access & Aggregation |

[0001193125-16-576994:notes:67]
Customer Devices generally includes the products and
 services that provide end users access to the CSP network. The
 Customer Devices portfolio includes a comprehensive array of
 service provider and enterprise hardware and software products and
 services.

[0001193125-16-576994:notes:68]
The Customer Devices category includes products and services such
 as:

[0001193125-16-576994:notes:69]
|  | • |  | Broadband customer premise solutions, including Passive Optical Network (PON) and point-to-point Ethernet Optical Network Terminals (ONTs) |

[0001193125-16-576994:notes:70]
|  | • |  | Residential and business gateways |

[0001193125-16-576994:notes:71]
|  | • |  | Wi-Fi access points and associated powering and switching infrastructure |

[0001193125-16-576994:notes:72]
|  | • |  | enterprise Session Border Controllers (eSBC) |

[0001193125-16-576994:notes:73]
|  | • |  | Branch office and access routers |

[0001193125-16-576994:notes:74]
|  | • |  | Carrier Ethernet services termination devices |

[0001193125-16-576994:notes:75]
|  | • |  | VoIP media gateways |

[0001193125-16-576994:notes:76]
|  | • |  | ProServices® |

[0001193125-16-576994:notes:77]
|  | • |  | Planning, engineering, program management, maintenance, installation and commissioning services to implement the customer devices solutions into consumer, small business and enterprise locations |

[0001193125-16-576994:notes:78]
|  | • |  | Other products and services that are generally applicable to customer devices |

[0001193125-16-576994:notes:79]
Traditional & Other Products generally includes a
 mix of prior generation technologies’ products and services,
 as well as other products and services that do not fit within the
 Access & Aggregation or Customer Devices categories.

[0001193125-16-576994:notes:80]
The Traditional & Other Products category includes
 products and services such as:

[0001193125-16-576994:notes:81]
|  | • |  | Time Division Multiplexed (TDM) and Asynchronous Transfer Mode (ATM) based aggregation systems and customer devices |

[0001193125-16-576994:notes:82]
|  | • |  | HDSL, ADSL and other mature technologies used to deliver business and residential services over the CSP access and customer networks |

[0001193125-16-576994:notes:83]
|  | • |  | Other products and services that do not fit within the Access & Aggregation and Customer Devices categories |

[0001193125-16-576994:notes:84]
The table below presents sales information by category for the
 three months ended March 31, 2016 and 2015:

[0001193125-16-576994:notes:85]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Access & Aggregation |  | $ | 93,855 |  |  | $ | 92,851 |  |
| Customer Devices |  |  | 32,353 |  |  |  | 31,704 |  |
| Traditional & Other Products |  |  | 15,996 |  |  |  | 18,280 |  |
| Total |  | $ | 142,204 |  |  | $ | 142,835 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-16-576994:notes:86]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the three months
 ended March 31, 2016 and 2015:

[0001193125-16-576994:notes:87]
|  |  | Three Months Ended March 31, 2016 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,932 |  |  | $ | (3,895 | ) |  | $ | (7,006 | ) |  | $ | (8,969 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 759 |  |  |  | — |  |  |  | 1,228 |  |  |  | 1,987 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,013 | ) |  |  | 44 |  |  |  | — |  |  |  | (969 | ) |
| Net current period other comprehensive income (loss) |  |  | (254 | ) |  |  | 44 |  |  |  | 1,228 |  |  |  | 1,018 |  |
| Ending balance |  | $ | 1,678 |  |  | $ | (3,851 | ) |  | $ | (5,778 | ) |  | $ | (7,951 | ) |

[0001193125-16-576994:notes:88]
|  |  | Three Months Ended March 31, 2015 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 8,964 |  |  | $ | (5,757 | ) |  | $ | (3,282 | ) |  | $ | (75 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,360 |  |  |  | — |  |  |  | (3,318 | ) |  |  | (1,958 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,863 | ) |  |  | 68 |  |  |  | — |  |  |  | (1,795 | ) |
| Net current period other comprehensive income (loss) |  |  | (503 | ) |  |  | 68 |  |  |  | (3,318 | ) |  |  | (3,753 | ) |
| Ending balance |  | $ | 8,461 |  |  | $ | (5,689 | ) |  | $ | (6,600 | ) |  | $ | (3,828 | ) |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-16-576994:notes:89]
[same as prior period, unchanged from 0001193125-15-366072:notes:100]

[0001193125-16-576994:notes:90]
The accompanying unaudited consolidated financial statements of
 ADTRAN®,
 Inc. and its subsidiaries (ADTRAN) have been prepared pursuant to
 the rules and regulations for reporting on Quarterly Reports on
 Form 10-Q. Accordingly, certain information and notes required by
 generally accepted accounting principles for complete financial
 statements are not included herein. The December 31, 2015
 Consolidated Balance Sheet is derived from audited financial
 statements, but does not include all disclosures required by
 accounting principles generally accepted in the United States.

[0001193125-16-576994:notes:91]
In the opinion of management, all adjustments necessary to fairly
 state these interim statements have been recorded and are of a
 normal and recurring nature. The results of operations for an
 interim period are not necessarily indicative of the results for
 the full year. The interim statements should be read in conjunction
 with the financial statements and notes thereto included in
 ADTRAN’s Annual Report on Form 10-K for the year ended
 December 31, 2015, filed on February 24, 2016 with the
 SEC.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-16-576994:notes:92]
A summary of the calculation of basic and diluted earnings per
 share for the three months ended March 31, 2016 and 2015 is as
 follows:

[0001193125-16-576994:notes:93]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2016 |  |  | 2015 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 5,014 |  |  | $ | 3,317 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 49,220 |  |  |  | 53,399 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| Stock options |  |  | 120 |  |  |  | 220 |  |
| Restricted stock and restricted stock units |  |  | 49 |  |  |  | 15 |  |
| Weighted average number of shares – diluted |  |  | 49,389 |  |  |  | 53,634 |  |
| Net income per share – basic |  | $ | 0.10 |  |  | $ | 0.06 |  |
| Net income per share – diluted |  | $ | 0.10 |  |  | $ | 0.06 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-16-576994:notes:94]
The following table summarizes the stock-based compensation expense
 related to stock options, restricted stock units (RSUs) and
 restricted stock for the three months ended March 31, 2016 and
 2015, which was recognized as follows:

[0001193125-16-576994:notes:95]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 99 |  |  | $ | 90 |  |
| Selling, general and administrative expense |  |  | 769 |  |  |  | 691 |  |
| Research and development expense |  |  | 690 |  |  |  | 858 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,459 |  |  |  | 1,549 |  |
| Total stock-based compensation expense |  |  | 1,558 |  |  |  | 1,639 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (212 | ) |  |  | (180 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,346 |  |  | $ | 1,459 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-16-576994:notes:96]
At March 31, 2016 and December 31, 2015, inventory
 consisted of the following:

[0001193125-16-576994:notes:97]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Raw materials |  | $ | 35,879 |  |  | $ | 34,223 |  |
| Work in process |  |  | 2,829 |  |  |  | 2,893 |  |
| Finished goods |  |  | 53,399 |  |  |  | 54,417 |  |
| Total |  | $ | 92,107 |  |  | $ | 91,533 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-16-576994:notes:98]
[same as prior period, unchanged from 0001193125-15-366072:notes:109]

[0001193125-16-576994:notes:99]
We establish reserves for estimated excess, obsolete, or
 unmarketable inventory equal to the difference between the cost of
 the inventory and the estimated fair value of the inventory based
 upon assumptions about future demand and market conditions. At
 March 31, 2016 and December 31, 2015, raw materials
 reserves totaled $18.5 million and $17.5 million, respectively, and
 finished goods inventory reserves totaled $9.0 million and $9.2
 million, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-576994:notes:100]
[same as prior period, unchanged from 0001193125-15-366072:notes:111]

[0001193125-16-576994:notes:101]
Our effective tax rate decreased from 39.8% in the three months
 ended March 31, 2015 to 37.9% in the three months ended
 March 31, 2016. The decrease in the effective tax rate between
 the two periods is primarily attributable to the research and
 development tax credit being made permanent.


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-16-576994:notes:102]
The following table is a summary of our stock options outstanding
 as of December 31, 2015 and March 31, 2016 and the
 changes that occurred during the three months ended March 31,
 2016:

[0001193125-16-576994:notes:103]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2015 |  |  | 7,108 |  |  | $ | 21.97 |  |  |  | 6.42 |  |  | $ | 3,284 |  |
| Options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (15 | ) |  | $ | 16.65 |  |  |  |  |  |  |  |  |  |
| Options forfeited |  |  | (23 | ) |  | $ | 17.84 |  |  |  |  |  |  |  |  |  |
| Options expired |  |  | (26 | ) |  | $ | 24.40 |  |  |  |  |  |  |  |  |  |
| Options outstanding, March 31, 2016 |  |  | 7,044 |  |  | $ | 22.00 |  |  |  | 6.18 |  |  | $ | 11,580 |  |
| Options vested and expected to vest, March 31, 2016 |  |  | 6,910 |  |  | $ | 22.10 |  |  |  | 6.12 |  |  | $ | 11,095 |  |
| Options exercisable, March 31, 2016 |  |  | 4,466 |  |  | $ | 24.33 |  |  |  | 4.69 |  |  | $ | 4,191 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-576994:notes:104]
13. COMMITMENTS AND CONTINGENCIES

[0001193125-16-576994:notes:105]
In the ordinary course of business, we may be subject to various
 legal proceedings and claims, including employment disputes, patent
 claims, disputes over contract agreements and other commercial
 disputes. In some cases, claimants seek damages or other relief,
 such as royalty payments related to patents, which, if granted,
 could require significant expenditures. Although the outcome of any
 claim or litigation can never be certain, it is our opinion that
 the outcome of all contingencies of which we are currently aware
 will not materially affect our business, operations, financial
 condition or cash flows.

[0001193125-16-576994:notes:106]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of March 31, 2016, of which $7.7 million has been applied to
 these commitments.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-16-576994:notes:107]
[same as prior period, unchanged from 0001193125-15-366072:notes:118]

[0001193125-16-576994:notes:108]
[same as prior period, unchanged from 0001193125-15-366072:notes:119]

[0001193125-16-576994:notes:109]
As of March 31, 2016, we had forward contracts outstanding
 with notional amounts totaling €1.8 million ($2.0
 million), which mature in the second quarter of 2016.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-16-576994:notes:110]
[same as prior period, unchanged from 0001193125-15-366072:notes:121]

[0001193125-16-576994:notes:111]
[same as prior period, unchanged from 0001193125-15-366072:notes:122]

[0001193125-16-576994:notes:112]
Since 1997, our Board of Directors has approved multiple share
 repurchase programs that have authorized open market repurchase
 transactions of up to 50.0 million shares of our common stock,
 which will be implemented through open market or private purchases
 from time to time as conditions warrant. During the three months
 ended March 31, 2016, we repurchased 0.6 million shares
 of our common stock at an average price of $18.38 per share. As of
 March 31, 2016, we have the authority to purchase an
 additional 5.2 million shares of our common stock under the
 current plans approved by the Board of Directors.

[0001193125-16-576994:notes:113]
[same as prior period, unchanged from 0001193125-15-366072:notes:124]

[0001193125-16-576994:notes:114]
We issued 15 thousand shares of treasury stock during the
 three months ended March 31, 2016 to accommodate employee
 stock option exercises. The stock options had exercise prices
 ranging from $15.29 to $18.97. We received proceeds totaling $0.2
 million from the exercise of these stock options during the three
 months ended March 31, 2016.

[0001193125-16-576994:notes:115]
[same as prior period, unchanged from 0001193125-15-366072:notes:126]

[0001193125-16-576994:notes:116]
[same as prior period, unchanged from 0001193125-15-366072:notes:127]

[0001193125-16-576994:notes:117]
[same as prior period, unchanged from 0001193125-15-366072:notes:128]

[0001193125-16-576994:notes:118]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the three months
 ended March 31, 2016 and 2015:

[0001193125-16-576994:notes:119]
| (In thousands) |  | Three Months Ended March 31, 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,761 |  |  | Net realized investment gain |
| Impairment expense |  |  | (100 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (64 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,597 |  |  |  |
| Tax (expense) benefit |  |  | (628 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 969 |  |  |  |

[0001193125-16-576994:notes:120]
[same as prior period, unchanged from 0001193125-15-366072:notes:131]

[0001193125-16-576994:notes:121]
| (In thousands) |  | Three Months Ended March 31, 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 3,076 |  |  | Net realized investment gain |
| Impairment expense |  |  | (22 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (98 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 2,956 |  |  |  |
| Tax (expense) benefit |  |  | (1,161 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,795 |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-576994:notes:122]
[same as prior period, unchanged from 0001193125-15-366072:notes:136]

[0001193125-16-576994:notes:123]
[same as prior period, unchanged from 0001193125-15-366072:notes:137]

[0001193125-16-576994:notes:124]
There were no options granted during the three months ended
 March 31, 2016. The weighted-average assumptions and value of
 options granted during the three months ended March 31, 2015
 were as follows:

[0001193125-16-576994:notes:125]
|  |  | Three Months |  |
|  |  | Ended |  |
|  |  | March 31, |  |
|  |  | 2015 |  |
| Expected volatility |  |  | 38.75 | % |
| Risk-free interest rate |  |  | 1.46 | % |
| Expected dividend yield |  |  | 1.60 | % |
| Expected life (in years) |  |  | 6.47 |  |
| Weighted-average estimated value |  | $ | 7.63 |  |

[0001193125-16-576994:notes:126]
The fair value of our RSUs is calculated using a Monte Carlo
 Simulation valuation method. No RSUs were granted or vested during
 the three months ended March 31, 2016 and 2015. Twelve
 thousand RSUs were forfeited during the three months ended
 March 31, 2015.

[0001193125-16-576994:notes:127]
The fair value of restricted stock is equal to the closing price of
 our stock on the date of grant. No restricted stock vested or was
 forfeited during the three months ended March 31, 2016 and
 2015. Two thousand shares of restricted stock were granted during
 the three months ended March 31, 2016.

[0001193125-16-576994:notes:128]
Stock-based compensation expense recognized in our Consolidated
 Statements of Income for the three months ended March 31, 2016
 and 2015 is based on options, RSUs and restricted stock ultimately
 expected to vest, and has been reduced for estimated forfeitures.
 Estimated forfeitures for stock options are based upon historical
 experience and approximate 3.7% annually. We estimated a 0%
 forfeiture rate for our RSUs and restricted stock due to the
 limited number of recipients and historical experience for these
 awards.

[0001193125-16-576994:notes:129]
As of March 31, 2016, total compensation expense related to
 non-vested stock options, RSUs and restricted stock not yet
 recognized was approximately $13.2 million, which is expected to be
 recognized over an average remaining recognition period of 2.53
 years.

[0001193125-16-576994:notes:130]
The aggregate intrinsic values in the table above represent the
 total pre-tax intrinsic value (the difference between the closing
 price of our stock on the last trading day of the quarter and the
 exercise price, multiplied by the number of in-the-money options)
 that would have been received by the option holders had all option
 holders exercised their options on March 31, 2016. The
 aggregate intrinsic value will change based on the fair market
 value of our stock.

[0001193125-16-576994:notes:131]
The total pre-tax intrinsic value of options exercised during the
 three months ended March 31, 2016 was $36 thousand.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-16-576994:notes:132]
Recent Accounting Pronouncements

[0001193125-16-576994:notes:133]
In May 2014, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update No. 2014-09, Revenue from
 Contracts with Customers (ASU 2014-09), which supersedes the
 revenue recognition requirements in Topic 605, Revenue
 Recognition, including most industry-specific revenue
 recognition guidance throughout the Industry Topics of the
 Codification. The core principle of ASU 2014-09 is to recognize
 revenues when promised goods or services are transferred to
 customers in an amount that reflects the consideration that is
 expected to be received for those goods or services. In August
 2015, the FASB issued ASU 2015-14, which deferred the effective
 date of ASU 2014-09 to fiscal years beginning after
 December 31, 2017, and interim periods within those fiscal
 years. ASU 2014-09 allows for either full retrospective or modified
 retrospective adoption. We are currently evaluating the transition
 method that will be elected and the impact that the adoption of ASU
 2014-09 will have on our financial position, results of operations
 and cash flows.

[0001193125-16-576994:notes:134]
In July 2015, the FASB issued Accounting Standards Update No.
 2015-11, Inventory (Topic 330): Simplifying the Measurement of
 Inventory (ASU 2015-11). Currently, Topic 330,
 Inventory, requires an entity to measure inventory at the
 lower of cost or market. Market could be replacement cost, net
 realizable value, or net realizable value less an approximately
 normal profit margin. ASU 2015-11 does not apply to inventory that
 is measured using last-in, first-out (LIFO) or the retail inventory
 method. The amendments apply to all other inventory, which includes
 inventory that is measured using first-in, first-out (FIFO) or
 average cost. ASU 2015-11 requires an entity to measure in scope
 inventory at the lower of cost and net realizable value. Net
 realizable value is the estimated selling prices in the ordinary
 course of business, less reasonably predictable costs of
 completion, disposal, and transportation. ASU 2015-11 is effective
 for annual reporting periods beginning after December 15,
 2016, including interim periods within that reporting period. The
 amendments should be applied prospectively with earlier application
 permitted as of the beginning of an interim or annual reporting
 period. We do not believe the adoption of ASU 2015-05 will have a
 material impact on our financial position, results of operations
 and cash flows.

[0001193125-16-576994:notes:135]
In November 2015, the FASB issued Accounting Standards Update
 No. 2015-17, Balance Sheet Classification of Deferred
 Taxes (ASU 2015-17). ASU 2015-17 amends the existing guidance
 on income taxes to require the classification of all deferred tax
 assets and liabilities as non-current on the balance sheet. ASU
 2015-17 is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 years. Early adoption is permitted. The guidance may be applied
 either prospectively, for all deferred tax assets and liabilities,
 or retrospectively to all periods presented. We have not selected a
 transition method or determined whether to early adopt ASU 2015-17
 in 2016. Other than the revised balance sheet presentation of
 current deferred tax assets and liabilities, we do not believe the
 adoption of ASU 2015-17 will have a material impact on our
 financial position, results of operations and cash flows.

[0001193125-16-576994:notes:136]
In February 2016, the FASB issued Accounting Standards Update
 No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU
 2016-02 requires an entity to recognize lease assets and lease
 liabilities on the balance sheet and to disclose key information
 about the entity’s leasing arrangements. ASU 2016-02 is
 effective for fiscal years beginning after December 15, 2018,
 and interim periods within those fiscal years, with early adoption
 permitted. A modified retrospective approach is required. We are
 currently evaluating the impact that the adoption of ASU 2016-02
 will have on our financial position, results of operations and cash
 flows.

[0001193125-16-576994:notes:137]
In March 2016, the FASB issued Accounting Standards Update
 No. 2016-09, Compensation – Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment Accounting
 (ASU 2016-09). ASU 2016-09 simplifies several aspects of accounting
 for share-based compensation arrangements, including income tax
 effects, the classification of tax-related cash flows on the
 statement of cash flows, and accounting for forfeitures. ASU
 2016-09 is effective for fiscal years beginning after
 December 15, 2016, including interim periods within those
 years. Early adoption is permitted. We are currently evaluating the
 impact that the adoption of ASU 2016-09 will have on our financial
 position, results of operations and cash flows.

[0001193125-16-576994:notes:138]
During the first quarter of 2016, we adopted the following
 accounting standards, which had no material effect on our financial
 position, results of operations or cash flows:

[0001193125-16-576994:notes:139]
In April 2015, the FASB issued Accounting Standards Update
 No. 2015-05, Intangibles – Goodwill and Other –
 Internal-Use Software (Subtopic 350-40): Customer’s
 Accounting for Fees Paid in a Cloud Computing Arrangement (ASU
 2015-05), which provides guidance on accounting for fees paid by a
 customer in a cloud computing arrangement. If a cloud computing
 arrangement includes a software license, then the customer should
 account for the software license element of the arrangement
 consistent with the acquisition of other software licenses. If a
 cloud computing arrangement does not include a software license,
 the customer should account for the arrangement as a service
 contract. ASU 2015-05 is effective for annual reporting periods
 beginning after December 15, 2015, including interim periods
 within that reporting period. The amendments may be applied either
 prospectively to all arrangements entered into or materially
 modified after the effective date or retrospectively. We adopted
 ASU 2015-05 during the first quarter of 2016 and will apply the new
 standard prospectively. The adoption of ASU 2015-05 did not have a
 material impact on our financial position, results of operations
 and cash flows.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-16-576994:notes:140]
[same as prior period, unchanged from 0001193125-15-366072:notes:149]

[0001193125-16-576994:notes:141]
The accompanying unaudited consolidated financial statements of
 ADTRAN®, Inc. and its
 subsidiaries (ADTRAN) have been prepared pursuant to the rules and
 regulations for reporting on Quarterly Reports on Form 10-Q.
 Accordingly, certain information and notes required by generally
 accepted accounting principles for complete financial statements
 are not included herein. The December 31, 2015 Consolidated
 Balance Sheet is derived from audited financial statements, but
 does not include all disclosures required by accounting principles
 generally accepted in the United States.

[0001193125-16-576994:notes:142]
[same as prior period, unchanged from 0001193125-15-366072:notes:153]

[0001193125-16-576994:notes:143]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter of 2015. The aggregate
 impact of the corrections was a $0.8 million reduction to pre-tax
 income for the three months ended March 31, 2015 and was not
 material to the prior year quarterly or annual results.

[0001193125-16-576994:notes:144]
[same as prior period, unchanged from 0001193125-15-366072:notes:155]

[0001193125-16-576994:notes:145]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated pension liability,
 fair value of investments, and the evaluation of
 other-than-temporary declines in the value of investments. Actual
 amounts could differ significantly from these estimates.


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-576994:notes:146]
[same as prior period, unchanged from 0001193125-15-366072:notes:158]

[0001193125-16-576994:notes:147]
Anti-dilutive options to purchase common stock outstanding were
 excluded from the above calculations. Anti-dilutive options totaled
 5.9 million and 5.6 million for the three months ended
 March 31, 2016 and 2015, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001193125-16-576994:notes:148]
14. SUBSEQUENT EVENTS

[0001193125-16-576994:notes:149]
On April 12, 2016, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 April 28, 2016. The payment date will be May 12, 2016.
 The quarterly dividend payment will be approximately $4.4 million.
 In July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.

[0001193125-16-576994:notes:150]
During the second quarter and as of May 4, 2016, we have
 repurchased 30 thousand shares of our common stock through
 open market purchases at an average cost of $18.64 per share. We
 currently have the authority to purchase an additional
 5.2 million shares of our common stock under the current plan
 approved by the Board of Directors.
