# ADTN MD&A — 0001193125-16-576994


## mdna

[0001193125-16-576994:mdna:1]
[same as prior period, unchanged from 0001193125-15-366072:mdna:1]

[0001193125-16-576994:mdna:2]
[same as prior period, unchanged from 0001193125-15-366072:mdna:2]

[0001193125-16-576994:mdna:3]
[same as prior period, unchanged from 0001193125-15-366072:mdna:3]

[0001193125-16-576994:mdna:4]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications
across a variety of network infrastructures. These solutions are deployed by many of the United States’ and the world’s largest service providers, distributed enterprises and small and medium-sized businesses, public and private
enterprises, and millions of individual users worldwide.

[0001193125-16-576994:mdna:5]
Our success depends upon our ability to increase unit volume and market share through the
introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy
is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek in most
instances to be a high-quality, low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased
functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to
new customers.

[0001193125-16-576994:mdna:6]
We report revenue for the following three categories – Access & Aggregation, Customer Devices, and
Traditional & Other Products.

[0001193125-16-576994:mdna:7]
Access & Aggregation generally includes software and hardware based products and services
that communication service providers (CSPs) use to aggregate and/or originate network access technologies. The portfolio of ADTRAN solutions within this category includes a wide array of modular or fixed physical form factors designed to deliver the
best technology and economic fit for our customers based on the target subscriber density and environmental conditions.

[0001193125-16-576994:mdna:8]
The Access & Aggregation
category includes product and service families such as:

[0001193125-16-576994:mdna:9]
|  | • |  | Total Access® 5000 Series Fiber to the Premises (FTTP) and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001193125-16-576994:mdna:10]
|  | • |  | hiX 5600 Series fiber aggregation and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001193125-16-576994:mdna:11]
|  | • |  | Fiber to the Distribution Point (FTTdp) Optical Network Units (ONU) |

[0001193125-16-576994:mdna:12]
|  | • |  | Optical Line Terminals (OLT) |

[0001193125-16-576994:mdna:13]
|  | • |  | Optical Networking Edge (ONE) aggregation |

[0001193125-16-576994:mdna:14]
|  | • |  | Distribution Point Units (DPUs) |

[0001193125-16-576994:mdna:15]
|  | • |  | IP Digital Subscriber Line Access Multiplexers (DSLAMs) |

[0001193125-16-576994:mdna:16]
|  | • |  | Cabinet and Outside-Plant (OSP) enclosures and services |

[0001193125-16-576994:mdna:17]
|  | • |  | Network Management and Cloud based software platforms and applications |

[0001193125-16-576994:mdna:18]
|  | • |  | Pluggable optical transceivers (i.e., SFP, SFP+, XFP, QSFP), cables and other miscellaneous materials |

[0001193125-16-576994:mdna:19]
|  | • |  | Other products and services that are generally applicable to Access & Aggregation |

[0001193125-16-576994:mdna:20]
Customer Devices generally includes the products and services that provide end users access to the CSP
network. The Customer Devices portfolio includes a comprehensive array of service provider and enterprise hardware and software products and services.

[0001193125-16-576994:mdna:21]
The Customer Devices category includes products and services such as:

[0001193125-16-576994:mdna:22]
|  | • |  | Broadband customer premise solutions, including Passive Optical Network (PON) and point-to-point Ethernet Optical Network Terminals (ONTs) |

[0001193125-16-576994:mdna:23]
|  | • |  | Residential and business gateways |

[0001193125-16-576994:mdna:24]
|  | • |  | Wi-Fi access points and associated powering and switching infrastructure |

[0001193125-16-576994:mdna:25]
|  | • |  | enterprise Session Border Controllers (eSBC) |

[0001193125-16-576994:mdna:26]
|  | • |  | Branch office and access routers |

[0001193125-16-576994:mdna:27]
|  | • |  | Carrier Ethernet services termination devices |

[0001193125-16-576994:mdna:28]
|  | • |  | VoIP media gateways |

[0001193125-16-576994:mdna:29]
|  | • |  | ProServices |

[0001193125-16-576994:mdna:30]
|  | • |  | Planning, engineering, program management, maintenance, installation and commissioning services to implement the customer devices solutions into consumer, small business and enterprise locations |

[0001193125-16-576994:mdna:31]
|  | • |  | Other products and services that are generally applicable to customer devices |

[0001193125-16-576994:mdna:32]
Traditional & Other
Products generally includes a mix of prior generation technologies’ products and services, as well as other products and services that do not fit within the Access & Aggregation or Customer Devices categories.

[0001193125-16-576994:mdna:33]
The Traditional & Other Products category includes products and services such as:

[0001193125-16-576994:mdna:34]
|  | • |  | Time Division Multiplexed (TDM) and Asynchronous Transfer Mode (ATM) based aggregation systems and customer devices |

[0001193125-16-576994:mdna:35]
|  | • |  | HDSL, ADSL and other mature technologies used to deliver business and residential services over the CSP access and customer networks |

[0001193125-16-576994:mdna:36]
|  | • |  | Other products and services that do not fit within the Access & Aggregation and Customer Devices categories |

[0001193125-16-576994:mdna:37]
See Note 11 of Notes to Consolidated Financial Statements in this report for further information regarding these product categories.

[0001193125-16-576994:mdna:38]
Sales were $142.2 million for the three months ended March 31, 2016, compared to $142.8 million for the three months ended March 31, 2015. Our gross
margin increased to 46.3% for the three months ended March 31, 2016 from 45.9% for the months ended March 31, 2015. Our operating income margin increased to 3.9% for the three months ended March 31, 2016 from 1.4% for the three months
ended March 31, 2015. Net income was $5.0 million for the three months ended March 31, 2016, compared to $3.3 million for the three months ended March 31, 2015. Our effective tax rate decreased to 37.9% for the three months ended
March 31, 2016 from 39.8% for the three months ended March 31, 2015. Earnings per share, assuming dilution, were $0.10 for the three months ended March 31, 2016 compared to $0.06 for the three months ended March 31, 2015.

[0001193125-16-576994:mdna:39]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future periods due to a number of factors, including
customer order activity and backlog. Backlog levels vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us
to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected.
Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001193125-16-576994:mdna:40]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general
economic and market conditions, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty
returns, expediting costs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and
increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting
costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter.

[0001193125-16-576994:mdna:41]
Accordingly, our historical financial
performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. A list of factors that could materially affect our business, financial condition
or operating results is included under “Factors That Could Affect Our Future Results” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
report. These factors have also been discussed in more detail in Item 1A of Part I in our most recent Annual Report on Form 10-K for the year ended December 31, 2015, filed on February 24, 2016 with the SEC.

[0001193125-16-576994:mdna:42]
[same as prior period, unchanged from 0001193125-15-366072:mdna:49]

[0001193125-16-576994:mdna:43]
Our critical
accounting policies and estimates have not changed significantly from those detailed in our most recent Annual Report on Form 10-K for the year ended December 31, 2015, filed on February 24, 2016 with the SEC.

[0001193125-16-576994:mdna:44]
[same as prior period, unchanged from 0001193125-15-366072:mdna:51]

[0001193125-16-576994:mdna:45]
[same as prior period, unchanged from 0001193125-15-366072:mdna:52]

[0001193125-16-576994:mdna:46]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2016 COMPARED TO THREE MONTHS ENDED
MARCH 31, 2015

[0001193125-16-576994:mdna:47]
[same as prior period, unchanged from 0001193125-15-366072:mdna:54]

[0001193125-16-576994:mdna:48]
Our sales
decreased 0.4% from $142.8 million in the three months ended March 31, 2015 to $142.2 million in the three months ended March 31, 2016. The decrease in sales for the three months ended March 31, 2016 is primarily attributable to a
$2.3 million decrease in sales of our Traditional & Other products, partially offset by a $1.0 million increase in sales of our Access & Aggregation products and a $0.6 million increase in sales of our Customer Devices products.

[0001193125-16-576994:mdna:49]
Network Solutions sales decreased 4.3% from $129.5 million in the three months ended March 31, 2015 to $123.9 million in the three months ended
March 31, 2016. The decrease in sales for the three months ended March 31, 2016 is primarily attributable to a decrease in sales of Access and Aggregation products and Traditional & Other products, partially offset by an increase
in Customer Devices products. The decrease in sales of our Access and Aggregation products is primarily attributable to a decrease in hiX product sales, partially offset by an increase in Total Access 5000 product sales. The decrease in sales of
Traditional and Other products has been expected as customers continue to upgrade their networks to deliver higher bandwidth services by migrating to newer technologies, including products from our Access and Aggregation and Customer Devices product
lines. While we expect that revenues from Traditional and Other products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies. The
increase in sales of our Customer Devices products is primarily attributable to increased sales of our FTTP ONT products.

[0001193125-16-576994:mdna:50]
Services & Support
sales increased 37.4% from $13.3 million in the three months ended March 31, 2015 to $18.3 million in the three months ended March 31, 2016. The increase in sales for the three months ended March 31, 2016 is primarily attributable to
an increase in network installation services for access and aggregation products.

[0001193125-16-576994:mdna:51]
International sales, which are included in the Network Solutions and Services & Support amounts
discussed above, decreased 56.4% from $59.4 million in the three months ended March 31, 2015 to $25.9 million in the three months ended March 31, 2016. International sales, as a percentage of total sales, decreased from 41.6% for the three
months ended March 31, 2015 to 18.2% for the three months ended March 31, 2016. The decrease in international sales for the three months ended March 31, 2016 is primarily attributable to the return to more seasonally normal buying
patterns in Europe and also, relating to the decrease in international sales as a percentage of revenue, growing momentum in the U.S. broadband market.

[0001193125-16-576994:mdna:52]
[same as prior period, unchanged from 0001193125-15-366072:mdna:63]

[0001193125-16-576994:mdna:53]
As a percentage of sales, cost of
sales decreased from 54.1% in the three months ended March 31, 2015 to 53.7% in the three months ended March 31, 2016. The decrease for the three months ended March 31, 2016 is primarily attributable to regional revenue and product
and services mix shifts.

[0001193125-16-576994:mdna:54]
Network Solutions cost of sales, as a percent of that segment’s sales, decreased from 55.3% in the three months ended
March 31, 2015 to 51.7% in the three months ended March 31, 2016. The decrease for the three months ended March 31, 2016 is primarily attributable to regional revenue shift and customer and product mix.

[0001193125-16-576994:mdna:55]
Services & Support cost of sales, as a percent of that segment’s sales, increased from 42.9% in the three months ended March 31, 2015 to
67.3% in the three months ended March 31, 2016. The increase for the three months ended March 31, 2016 is primarily attributable to a shift to more network installation services in the three months ended March 31, 2016, which have
higher costs, versus a greater mix of maintenance and support services in the prior year.

[0001193125-16-576994:mdna:56]
An important part of our strategy is to reduce the product cost
of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and
the lowering of product selling prices.

[0001193125-16-576994:mdna:57]
[same as prior period, unchanged from 0001193125-15-366072:mdna:68]

[0001193125-16-576994:mdna:58]
Selling, general and administrative expenses decreased 0.9% from $31.1 million in the three months ended March 31, 2015 to $30.8 million in the three
months ended March 31, 2016. The decrease in selling, general and administrative expenses for the three months ended March 31, 2016 is primarily attributable to a decrease in travel expense.

[0001193125-16-576994:mdna:59]
As a percentage of sales, selling, general and administrative expenses decreased from 21.7% in the three months ended March 31, 2015 to 21.6% in the
three months ended March 31, 2016. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-16-576994:mdna:60]
[same as prior period, unchanged from 0001193125-15-366072:mdna:71]

[0001193125-16-576994:mdna:61]
Research and
development expenses decreased 9.4% from $32.5 million in the three months ended March 31, 2015 to $29.5 million in the three months ended March 31, 2016. The decrease in research and development expenses for the three months ended
March 31, 2016 is primarily attributable to a decrease in compensation expense, partially offset by an increase in contract services. The decrease is compensation expense was primary attributable to the consolidation of engineering resources
that occurred in the second quarter of 2015.

[0001193125-16-576994:mdna:62]
As a percentage of sales, research and development expenses decreased from 22.8% in the three months ended
March 31, 2015 to 20.7% in the three months ended March 31, 2016. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in
revenues for the periods being compared.

[0001193125-16-576994:mdna:63]
We expect to continue to incur research and development expenses in connection with our new and existing
products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products
and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-16-576994:mdna:64]
[same as prior period, unchanged from 0001193125-15-366072:mdna:75]

[0001193125-16-576994:mdna:65]
Interest and dividend income decreased 8.4%, or $0.1 million from the three months ended March 31, 2015 to the three months ended March 31, 2016. The
decrease in interest and dividend income for the three months ended March 31, 2016 is primarily attributable to a reduction in investment principal, partially offset by a slight increase in interest rates.

[0001193125-16-576994:mdna:66]
[same as prior period, unchanged from 0001193125-15-366072:mdna:77]

[0001193125-16-576994:mdna:67]
Interest expense, which is
primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended March 31, 2015 and 2016, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources”
below for additional information on our revenue bond.

[0001193125-16-576994:mdna:68]
[same as prior period, unchanged from 0001193125-15-366072:mdna:79]

[0001193125-16-576994:mdna:69]
Net realized investment gains decreased 44.5% from $3.1 million in the three months ended March 31, 2015 to $1.7 million in the three months ended
March 31, 2016. The decrease in realized investment gains for the three months ended March 31, 2016 is primarily attributable to decreased gains from the sale of equity securities. See “Investing Activities” in “Liquidity
and Capital Resources” below for additional information.

[0001193125-16-576994:mdna:70]
[same as prior period, unchanged from 0001193125-15-366072:mdna:81]

[0001193125-16-576994:mdna:71]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management
fees, and scrap raw material sales, changed from $0.4 million of expense in the three months ended March 31, 2015 to $0.1 million of income in the three months ended March 31, 2016. The change for the three months ended March 31, 2016
is primarily attributable to reduced losses on foreign currency transactions during the first quarter of 2016.

[0001193125-16-576994:mdna:72]
[same as prior period, unchanged from 0001193125-15-366072:mdna:83]

[0001193125-16-576994:mdna:73]
Our effective tax rate decreased from 39.8% in the three months ended March 31, 2015 to 37.9% in the three months ended March 31, 2016. The decrease
in the effective tax rate between the two periods is primarily attributable to the research and development tax credit being made permanent.

[0001193125-16-576994:mdna:74]
NET
INCOME

[0001193125-16-576994:mdna:75]
As a result of the above factors, net income increased $1.7 million from $3.3 million in the three months ended March 31, 2015 to $5.0
million in the three months ended March 31, 2016.

[0001193125-16-576994:mdna:76]
As a percentage of sales, net income increased from 2.3% in the three months ended March 31,
2015 to 3.5% in the three months ended March 31, 2016.

[0001193125-16-576994:mdna:77]
[same as prior period, unchanged from 0001193125-15-366072:mdna:88]

[0001193125-16-576994:mdna:78]
[same as prior period, unchanged from 0001193125-15-366072:mdna:89]

[0001193125-16-576994:mdna:79]
We intend to finance our operations with cash
flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product
development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to
meet our operating and capital needs for at least the next 12 months.

[0001193125-16-576994:mdna:80]
At March 31, 2016, cash on hand was $91.6 million and short-term investments
were $29.3 million, which resulted in available short-term liquidity of $120.9 million. At December 31, 2015, our cash on hand of $84.6 million and short-term investments of $34.4 million resulted in available short-term liquidity of $118.9
million. The increase in short-term liquidity from December 31, 2015 to March 31, 2016 is primarily attributable to shifts among available investment option tenures to provide additional funds for our short-term cash needs.

[0001193125-16-576994:mdna:81]
[same as prior period, unchanged from 0001193125-15-366072:mdna:92]

[0001193125-16-576994:mdna:82]
Our working capital, which consists of current assets less current liabilities, decreased 2.5% from $238.1 million as of December 31, 2015 to $232.1
million as of March 31, 2016. The decrease in our working capital is primarily attributable to a decrease in other receivables, partially offset by a decrease in accounts payable. The quick ratio, defined as cash, cash equivalents, short-term
investments, and net accounts receivable, divided by current liabilities, increased from 2.06 as of December 31, 2015 to 2.13 as of March 31, 2016. The increase in the quick ratio is primarily attributable to a decrease in accounts
payable. The current ratio, defined as current assets divided by current liabilities, increased from 3.57 as of December 31, 2015 to 3.62 as of March 31, 2016. The increase in the current ratio is primarily attributable to a decrease in
accounts payable, partially offset by a decrease in other receivables.

[0001193125-16-576994:mdna:83]
Net accounts receivable decreased 6.2% from $71.9 million at December 31,
2015 to $67.5 million at March 31, 2016. Our allowance for doubtful accounts was $19 thousand at December 31, 2015 and March 31, 2016. Quarterly accounts receivable days sales outstanding (DSO) decreased from 48 days as of
December 31, 2015 to 43 days as of March 31, 2016. The change in net accounts receivable is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment
terms than U.S. customers. Other receivables decreased from $19.3 million at December 31, 2015 to $9.2 million at March 31, 2016. The decrease in other receivables is primarily attributable to the timing of filing returns and collections
of VAT receivables in our international subsidiaries. Other receivables will also fluctuate due to the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001193125-16-576994:mdna:84]
Quarterly inventory turnover decreased from 3.3 turns as of December 31, 2015 to 3.2 turns at March 31, 2016. Inventory increased 0.6% from
December 31, 2015 to March 31, 2016. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while
managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-16-576994:mdna:85]
Accounts payable decreased 12.4% from
$48.7 million at December 31, 2015 to $42.6 million at March 31, 2016. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-16-576994:mdna:86]
[same as prior period, unchanged from 0001193125-15-366072:mdna:97]

[0001193125-16-576994:mdna:87]
Capital expenditures totaled
approximately $3.2 million and $2.4 million for the three months ended March 31, 2016 and 2015, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building
improvements.

[0001193125-16-576994:mdna:88]
Our combined short-term and long-term investments decreased $7.4 million from $232.4 million at December 31, 2015 to $225.0 million at
March 31, 2016. This decrease reflects the impact of our cash needs for capital expenditures, purchases of treasury stock, and shareholder dividends, as well as net realized and unrealized losses and amortization of net premiums on our combined
investments, partially offset by additional funds available for investment provided by our operating activities and stock option exercises by our employees.

[0001193125-16-576994:mdna:89]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At March 31,
2016 these investments included corporate bonds of $60.9 million, municipal fixed-rate bonds of $15.7 million, asset-backed bonds of $20.6 million, mortgage/agency-backed bonds of $14.9 million, government bonds of $33.4 million, and variable rate
demand notes of $2.2 million. At December 31, 2015, these investments included corporate bonds of $57.6 million, municipal fixed-rate bonds of $26.4 million, asset-backed bonds of $19.2 million, mortgage/agency-backed bonds of $15.4 million,
and government bonds of $35.4 million. As of March 31, 2016, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, government bonds, and variable rate demand notes were classified as
available-for-sale and had a combined duration of 1.07 years with an average credit rating of A+. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds
derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-16-576994:mdna:90]
Our long-term investments decreased 1.2% from $198.0 million at December 31, 2015 to $195.7 million at
March 31, 2016. Long-term investments at March 31, 2016 and December 31, 2015 included an investment in a certificate of deposit of $30.0 million, which serves as collateral for our revenue bond. See “Debt” below for
additional information. We have various equity investments included in long-term investments at a cost of $31.8 million and $31.6 million, and with a fair value of $33.0 million and $34.3 million, at March 31, 2016 and December 31, 2015,
respectively.

[0001193125-16-576994:mdna:91]
Long-term investments at March 31, 2016 and December 31, 2015 also included $13.0 million and $12.8 million, respectively,
related to our deferred compensation plans, and $1.3 million of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001193125-16-576994:mdna:92]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements
made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive
months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three months ended March 31, 2016 and 2015, other-than-temporary impairment charges were not
significant.

[0001193125-16-576994:mdna:93]
[same as prior period, unchanged from 0001193125-15-366072:mdna:104]

[0001193125-16-576994:mdna:94]
[same as prior period, unchanged from 0001193125-15-366072:mdna:105]

[0001193125-16-576994:mdna:95]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and
adequate levels of Company liquidity. During the three months ended March 31, 2016, we paid dividends totaling $4.5 million.

[0001193125-16-576994:mdna:96]
[same as prior period, unchanged from 0001193125-15-366072:mdna:107]

[0001193125-16-576994:mdna:97]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled
$28.9 million at March 31, 2016 and December 31, 2015. At March 31, 2016, the estimated fair value of the Bond was approximately $29.1 million, based on a debt security with a comparable interest rate and maturity and a
Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $30.0 million at March 31, 2016 and December 31, 2015, which is a collateral deposit against the
principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of
2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions
that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.
In connection with this decision, $1.0 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at March 31, 2016.

[0001193125-16-576994:mdna:98]
[same as prior period, unchanged from 0001193125-15-366072:mdna:109]

[0001193125-16-576994:mdna:99]
Since 1997, our Board of
Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to
time as conditions warrant. During the three months ended March 31, 2016, we repurchased 0.6 million shares of our common stock at an average price of $18.38 per share. As of March 31, 2016, we have the authority to purchase an
additional 5.2 million shares of our common stock under the current plans approved by the Board of Directors.

[0001193125-16-576994:mdna:100]
[same as prior period, unchanged from 0001193125-15-366072:mdna:112]

[0001193125-16-576994:mdna:101]
We issued 15 thousand shares of treasury stock during the three months ended March 31, 2016 to accommodate employee stock option exercises. The stock
options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $0.2 million from the exercise of these stock options during the three months ended March 31, 2016.

[0001193125-16-576994:mdna:102]
[same as prior period, unchanged from 0001193125-15-366072:mdna:114]

[0001193125-16-576994:mdna:103]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or
other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the three months ended March 31, 2016, there have been no material changes in contractual obligations
and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2015 filed on February 24, 2016 with the SEC.

[0001193125-16-576994:mdna:104]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2016, of
which $7.7 million has been applied to these commitments.

[0001193125-16-576994:mdna:105]
[same as prior period, unchanged from 0001193125-15-366072:mdna:117]

[0001193125-16-576994:mdna:106]
[same as prior period, unchanged from 0001193125-15-366072:mdna:118]

[0001193125-16-576994:mdna:107]
[same as prior period, unchanged from 0001193125-15-366072:mdna:119]

[0001193125-16-576994:mdna:108]
[same as prior period, unchanged from 0001193125-15-366072:mdna:120]

[0001193125-16-576994:mdna:109]
[same as prior period, unchanged from 0001193125-15-366072:mdna:121]

[0001193125-16-576994:mdna:110]
|  | • |  | Our exposure to the credit risks of our customers and distributors may make it difficult to collect accounts receivable and could adversely affect our operating results, financial condition and cash flow. |

[0001193125-16-576994:mdna:111]
|  | • |  | We expect gross margins to vary over time, and our levels of product and services gross margins may not be sustainable. |

[0001193125-16-576994:mdna:112]
[same as prior period, unchanged from 0001193125-15-366072:mdna:124]

[0001193125-16-576994:mdna:113]
[same as prior period, unchanged from 0001193125-15-366072:mdna:125]

[0001193125-16-576994:mdna:114]
|  | • |  | Failure to comply with the U.S. Foreign Corrupt Practices Act and similar laws associated with our global activities could subject us to penalties or other adverse consequences. |

[0001193125-16-576994:mdna:115]
[same as prior period, unchanged from 0001193125-15-366072:mdna:126]

[0001193125-16-576994:mdna:116]
[same as prior period, unchanged from 0001193125-15-366072:mdna:127]

[0001193125-16-576994:mdna:117]
|  | • |  | The lengthy sales and approval process required by major and other SPs for new products could result in fluctuations in our revenue. |

[0001193125-16-576994:mdna:118]
[same as prior period, unchanged from 0001193125-15-366072:mdna:129]

[0001193125-16-576994:mdna:119]
[same as prior period, unchanged from 0001193125-15-366072:mdna:130]

[0001193125-16-576994:mdna:120]
|  | • |  | Our strategy of outsourcing a portion of our manufacturing requirements to subcontractors located in various international regions may result in us not meeting our cost, quality or performance standards |

[0001193125-16-576994:mdna:121]
[same as prior period, unchanged from 0001193125-15-366072:mdna:132]

[0001193125-16-576994:mdna:122]
[same as prior period, unchanged from 0001193125-15-366072:mdna:133]

[0001193125-16-576994:mdna:123]
|  | • |  | Our estimates regarding future warranty obligations may change due to product failure rates, installation and shipment volumes, field service repair obligations and other rework costs incurred in correcting product failures. If our estimates change, the liability for warranty obligations may be increased or decreased, impacting future cost of goods sold. |

[0001193125-16-576994:mdna:124]
[same as prior period, unchanged from 0001193125-15-366072:mdna:135]

[0001193125-16-576994:mdna:125]
|  | • |  | The continuing growth of our international operations could expose us to additional risks, increase our costs and adversely affect our operating results, financial condition and cash flow. |

[0001193125-16-576994:mdna:126]
[same as prior period, unchanged from 0001193125-15-366072:mdna:137]

[0001193125-16-576994:mdna:127]
[same as prior period, unchanged from 0001193125-15-366072:mdna:138]

[0001193125-16-576994:mdna:128]
[same as prior period, unchanged from 0001193125-15-366072:mdna:139]

[0001193125-16-576994:mdna:129]
[same as prior period, unchanged from 0001193125-15-366072:mdna:140]

[0001193125-16-576994:mdna:130]
[same as prior period, unchanged from 0001193125-15-366072:mdna:141]

[0001193125-16-576994:mdna:131]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-16-576994:mdna:132]
|  | • |  | Consolidation and deterioration in the competitive SP market could result in a significant decrease in our revenue. |

[0001193125-16-576994:mdna:133]
[same as prior period, unchanged from 0001193125-15-366072:mdna:144]

[0001193125-16-576994:mdna:134]
|  | • |  | If we are unable to successfully develop and maintain relationships with system integrators, SPs, and enterprise VARs, our sales may be negatively affected. |

[0001193125-16-576994:mdna:135]
[same as prior period, unchanged from 0001193125-15-366072:mdna:147]

[0001193125-16-576994:mdna:136]
[same as prior period, unchanged from 0001193125-15-366072:mdna:148]

[0001193125-16-576994:mdna:137]
[same as prior period, unchanged from 0001193125-15-366072:mdna:149]

[0001193125-16-576994:mdna:138]
|  | • |  | We may not fully realize the anticipated benefits of our restructuring plans. Our restructuring efforts may adversely affect our business and our operating results. |

[0001193125-16-576994:mdna:139]
[same as prior period, unchanged from 0001193125-15-366072:mdna:150]

[0001193125-16-576994:mdna:140]
[same as prior period, unchanged from 0001193125-15-366072:mdna:151]

[0001193125-16-576994:mdna:141]
[same as prior period, unchanged from 0001193125-15-366072:mdna:152]

[0001193125-16-576994:mdna:142]
[same as prior period, unchanged from 0001193125-15-366072:mdna:153]

[0001193125-16-576994:mdna:143]
The foregoing
list of risks is not exclusive. For a more detailed description of the risk factors associated with our business, see Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2015, filed on February 24, 2016 with the
SEC.

[0001193125-16-576994:mdna:144]
31
