# ADTN 8-K — 0000950170-25-028352 filed 2025-02-27

## item codes, every 8-K on or before 2025-03-03

- 2025-02-27 0000950170-25-028352 — 2.02, 7.01, 9.01
- 2024-11-07 0000950170-24-122762 — 2.02, 7.01, 9.01
- 2024-08-30 0000950170-24-102309 — 5.02, 9.01
- 2024-08-06 0000950170-24-091207 — 2.02, 7.01, 9.01
- 2024-08-02 0000950170-24-089974 — 5.02
- 2024-06-10 0001193125-24-158388 — 1.01, 2.03, 9.01
- 2024-05-09 0000950170-24-056830 — 5.02, 5.07, 9.01
- 2024-05-07 0000950170-24-053920 — 2.02, 7.01, 9.01
- 2024-05-03 0001193125-24-130896 — 2.02, 7.01, 9.01
- 2024-04-17 0000950170-24-045151 — 2.05, 9.01
- 2024-03-15 0000950170-24-031864 — 2.02, 9.01
- 2024-02-27 0000950170-24-020613 — 2.02, 7.01, 9.01
- 2024-02-20 0001193125-24-040068 — 4.02
- 2024-01-22 0001193125-24-011697 — 1.01, 2.03, 9.01
- 2023-12-06 0001193125-23-289895 — 5.02, 9.01
- 2023-12-05 0001193125-23-289150 — 5.02, 9.01
- 2023-11-07 0001193125-23-271842 — 2.02, 7.01, 9.01
- 2023-10-24 0001193125-23-261665 — 5.02, 5.03, 9.01
- 2023-10-17 0001193125-23-257289 — 2.02, 7.01, 9.01
- 2023-09-29 0001193125-23-246498 — 5.02
- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2025-03-03

- 2024-02-29 0000950170-24-023141 — NT 10-K, for the period ended 2023-12-31
- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-25-028352:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0000950170-25-028352:8k_2_02:2]
EX-99.1

[0000950170-25-028352:8k_2_02:3]
ADTRAN Holdings, Inc. reports preliminary fourth quarter and full-year 2024 financial results

[0000950170-25-028352:8k_2_02:4]
Huntsville, Alabama, USA. — February 26, 2025 — ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” or the “Company”) today announced its preliminary unaudited financial results for the fourth quarter and full-year ended December 31, 2024.

[0000950170-25-028352:8k_2_02:5]
•
Revenue: $242.9 million, up 7% sequentially and above the mid-point of outlook.

[0000950170-25-028352:8k_2_02:6]
•
Gross margin: GAAP gross margin: 37.6%; non-GAAP gross margin: 42.0%.

[0000950170-25-028352:8k_2_02:7]
•
Operating margin: improved sequentially on a GAAP and non-GAAP basis, above the mid-point of outlook.

[0000950170-25-028352:8k_2_02:8]
•
GAAP diluted loss per share of $0.58; non-GAAP diluted earning per share $0.00.

[0000950170-25-028352:8k_2_02:9]
Adtran Holdings’ Chairman and Chief Executive Officer Tom Stanton stated, “Market conditions continued to improve during the fourth quarter driven by higher service provider spending, lower customer inventories, a continuing shift away from high-risk vendors, and the secular trend of increased fiber access and optical transport. The progress we made during the fourth quarter, including higher sequential and year-over-year revenue and operating margin, was supported by growth across geographies, most product lines, and the continued expansion of our customer base.”

[0000950170-25-028352:8k_2_02:10]
Mr. Stanton added, “We finished 2024 with positive momentum in our business. Based on the current visibility and booking trends, we expect higher revenue in the first quarter of 2025, overcoming typical seasonality.”

[0000950170-25-028352:8k_2_02:11]
Business outlook1

[0000950170-25-028352:8k_2_02:12]
For the first quarter of 2025, the Company expects revenue to be within a range of $237.5 million to $252.5 million. Non-GAAP operating margin is expected to be within a range of 0% to 4%.

[0000950170-25-028352:8k_2_02:13]
1Non-GAAP operating margin (which is calculated as non-GAAP operating income (loss) divided by revenue) is a non-GAAP financial measure. The Company has provided first quarter 2025 guidance with regard to non-GAAP operating margin. This measure excludes from the corresponding GAAP financial measure the effect of adjustments as described below. The Company has not provided a reconciliation of such non-GAAP guidance to guidance presented on a GAAP basis because it cannot predict and quantify without unreasonable effort all of the adjustments that may occur during the period due to the difficulty of predicting the timing and amounts of various items within a reasonable range. In particular, non-GAAP operating margin excludes certain items, including continued restructuring expenses, that will continue to evolve as our business efficiency program is implemented that the Company is unable to quantitatively predict. Depending on the materiality of these items, they could have a significant impact on the Company's GAAP financial results.

[0000950170-25-028352:8k_2_02:14]
Conference call

[0000950170-25-028352:8k_2_02:15]
The Company will hold a conference call to discuss its preliminary fourth quarter 2024 results on Thursday, February 27, 2025, at 9:30 a.m. Central Time, or 4:30 p.m. Central European Time. The Company will webcast this conference call at the events and presentations section of ADTRAN Holdings, Inc. Investor Relations website at https://events.q4inc.com/attendee/811754399 approximately 10 minutes prior to the start of the call, or you may dial 1-888-330-2391 (Toll-Free US) or 1-240-789-2702, and use Conference ID 8936454.

[0000950170-25-028352:8k_2_02:16]
An online replay of the Company’s conference call, as well as the transcript of the call, will be available on the Investor Relations site  https://investors.adtran.com/ shortly following the call and will remain available for at least 12 months.

[0000950170-25-028352:8k_2_02:17]
For more information, visit investors.adtran.com or email investor.relations@adtran.com.

[0000950170-25-028352:8k_2_02:18]
Upcoming conference schedule

[0000950170-25-028352:8k_2_02:19]
March 11, 2025: Stifel 2025 NYC Technology One-on-One Conference

[0000950170-25-028352:8k_2_02:20]
March 17, 2025: 37th Annual ROTH Conference

[0000950170-25-028352:8k_2_02:21]
April 1, 2025: Optical Fiber Communication (OFC) Conference and Exhibition

[0000950170-25-028352:8k_2_02:22]
About Adtran

[0000950170-25-028352:8k_2_02:23]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises, government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the majority shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE. Find more at Adtran, LinkedIn and Twitter.

[0000950170-25-028352:8k_2_02:24]
Cautionary note regarding forward-looking statements

[0000950170-25-028352:8k_2_02:25]
Additionally, the financial measures presented herein are preliminary estimates, remain subject to our internal controls and procedures, and are subject to risks and uncertainties, including, among others, changes in connection with quarter-end adjustments. Any variation between the Company’s actual results and the preliminary financial information set forth herein may be material.

[0000950170-25-028352:8k_2_02:26]
Explanation of use of non-GAAP financial measures

[0000950170-25-028352:8k_2_02:27]
Set forth in the tables below are reconciliations of gross profit, gross margin, operating expenses, operating loss, other (expense) income, net loss inclusive of the non-controlling interest, net income attributable to the non-controlling interest, net loss attributable to the Company, and loss per share - basic and diluted, attributable to the Company, and net cash provided by (used in) operating activities, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income (loss), non-GAAP other expense, non-GAAP net income (loss) inclusive of the non-controlling interest, non-GAAP net income (loss) attributable to the Company, non-GAAP net earnings (loss) per share - basic and diluted, attributable to the Company, and free cash flow, respectively. Such non-GAAP measures exclude acquisition-related expenses, amortization and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments as well as legal and advisory fees related to a potential significant transaction), stock-based compensation expense, restructuring expenses, integration expenses, deferred compensation adjustments, goodwill impairments, amortization of pension actuarial losses, the tax effect of these adjustments to net loss and purchases of property, plant and equipment. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of these non-GAAP measures, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company. These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0000950170-25-028352:8k_2_02:28]
Published by

[0000950170-25-028352:8k_2_02:29]
ADTRAN Holdings, Inc.

[0000950170-25-028352:8k_2_02:30]
www.adtran.com

[0000950170-25-028352:8k_2_02:31]
For media

[0000950170-25-028352:8k_2_02:32]
Gareth Spence

[0000950170-25-028352:8k_2_02:33]
+44 1904 699 358

[0000950170-25-028352:8k_2_02:34]
public.relations@adtran.com

[0000950170-25-028352:8k_2_02:35]
For investors

[0000950170-25-028352:8k_2_02:36]
Peter Schuman, IRC

[0000950170-25-028352:8k_2_02:37]
+1 256 963 6305

[0000950170-25-028352:8k_2_02:38]
investor.relations@adtran.com

[0000950170-25-028352:8k_2_02:39]
Condensed Consolidated Balance Sheets

[0000950170-25-028352:8k_2_02:40]
(Preliminary, Unaudited)

[0000950170-25-028352:8k_2_02:41]
(In thousands)

[0000950170-25-028352:8k_2_02:42]
| ASSETS |  | December 31, 2024 |  |  | December 31, 2023 |  |  |
| Current Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 77,567 |  |  | $ | 87,167 |  |  |
| Accounts receivable, net |  |  | 178,030 |  |  |  | 216,445 |  |  |
| Other receivables |  |  | 9,775 |  |  |  | 17,450 |  |  |
| Income tax receivable |  |  | 4,355 |  |  |  | 7,933 |  |  |
| Inventory, net |  |  | 269,337 |  |  |  | 362,295 |  |  |
| Assets held for sale |  |  | 11,901 |  |  |  | — |  |  |
| Prepaid expenses and other current assets |  |  | 58,534 |  |  |  | 45,566 |  |  |
| Total Current Assets |  |  | 609,499 |  |  |  | 736,856 |  |  |
| Property, plant and equipment, net |  |  | 102,942 |  |  |  | 123,020 |  |  |
| Deferred tax assets, net |  |  | 17,826 |  |  |  | 25,787 |  |  |
| Goodwill |  |  | 52,918 |  |  |  | 353,415 |  |  |
| Intangibles, net |  |  | 284,893 |  |  |  | 327,985 |  |  |
| Other non-current assets |  |  | 78,128 |  |  |  | 87,706 |  |  |
| Long-term investments |  |  | 32,060 |  |  |  | 27,743 |  |  |
| Total Assets |  | $ | 1,178,266 |  |  | $ | 1,682,512 |  |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 170,451 |  |  | $ | 162,922 |  |  |
| Unearned revenue |  |  | 52,701 |  |  |  | 46,731 |  |  |
| Accrued expenses and other liabilities |  |  | 35,704 |  |  |  | 36,204 |  |  |
| Accrued wages and benefits |  |  | 32,853 |  |  |  | 27,030 |  |  |
| Income tax payable, net |  |  | 830 |  |  |  | 5,221 |  |  |
| Total Current Liabilities |  |  | 292,539 |  |  |  | 278,108 |  |  |
| Non-current revolving credit agreement outstanding |  |  | 189,576 |  |  |  | 195,000 |  |  |
| Deferred tax liabilities |  |  | 30,690 |  |  |  | 35,655 |  |  |
| Non-current unearned revenue |  |  | 22,065 |  |  |  | 25,109 |  |  |
| Non-current pension liability |  |  | 8,983 |  |  |  | 12,543 |  |  |
| Deferred compensation liability |  |  | 33,203 |  |  |  | 29,039 |  |  |
| Non-current lease obligations |  |  | 25,925 |  |  |  | 31,420 |  |  |
| Other non-current liabilities |  |  | 17,928 |  |  |  | 28,657 |  |  |
| Total Liabilities |  |  | 620,909 |  |  |  | 635,531 |  |  |
| Redeemable Non-Controlling Interest |  |  | 422,943 |  |  |  | 442,152 |  |  |
| Equity |  |  |  |  |  |  |  |
| Common stock |  |  | 795 |  |  |  | 790 |  |  |
| Additional paid-in capital |  |  | 808,913 |  |  |  | 795,304 |  |  |
| Accumulated other comprehensive income |  |  | 10,897 |  |  |  | 47,465 |  |  |
| Retained deficit |  |  | (680,993 | ) |  |  | (232,905 | ) |  |
| Treasury stock |  |  | (5,198 | ) |  |  | (5,825 | ) |  |
| Total Equity |  |  | 134,414 |  |  |  | 604,829 |  |  |
| Total Liabilities and Equity |  | $ | 1,178,266 |  |  | $ | 1,682,512 |  |  |

[0000950170-25-028352:8k_2_02:43]
Condensed Consolidated Statements of Loss

[0000950170-25-028352:8k_2_02:44]
(Preliminary, Unaudited)

[0000950170-25-028352:8k_2_02:45]
(In thousands, except per share amounts)

[0000950170-25-028352:8k_2_02:46]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 197,009 |  |  | $ | 180,405 |  |  | $ | 738,964 |  |  | $ | 974,389 |  |
| Services & Support |  |  | 45,843 |  |  |  | 45,074 |  |  |  | 183,756 |  |  |  | 174,711 |  |
| Total Revenue |  |  | 242,852 |  |  |  | 225,479 |  |  |  | 922,720 |  |  |  | 1,149,100 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 134,184 |  |  |  | 126,248 |  |  |  | 511,070 |  |  |  | 722,582 |  |
| Network Solutions - charges and inventory write-down |  |  | — |  |  |  | 3,270 |  |  |  | 8,597 |  |  |  | 24,313 |  |
| Services & Support |  |  | 17,435 |  |  |  | 17,496 |  |  |  | 72,739 |  |  |  | 69,142 |  |
| Total Cost of Revenue |  |  | 151,619 |  |  |  | 147,014 |  |  |  | 592,406 |  |  |  | 816,037 |  |
| Gross Profit |  |  | 91,233 |  |  |  | 78,465 |  |  |  | 330,314 |  |  |  | 333,063 |  |
| Selling, general and administrative expenses |  |  | 57,156 |  |  |  | 61,262 |  |  |  | 233,369 |  |  |  | 258,149 |  |
| Research and development expenses |  |  | 49,209 |  |  |  | 54,818 |  |  |  | 221,463 |  |  |  | 258,311 |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | 292,583 |  |  |  | 37,874 |  |
| Operating Loss |  |  | (15,132 | ) |  |  | (37,615 | ) |  |  | (417,101 | ) |  |  | (221,271 | ) |
| Interest and dividend income |  |  | 1,631 |  |  |  | 1,157 |  |  |  | 3,058 |  |  |  | 2,340 |  |
| Interest expense |  |  | (4,870 | ) |  |  | (4,441 | ) |  |  | (22,053 | ) |  |  | (16,299 | ) |
| Net investment (loss) gain |  |  | (920 | ) |  |  | 1,683 |  |  |  | 3,587 |  |  |  | 2,754 |  |
| Other income (expense), net |  |  | 687 |  |  |  | (3,448 | ) |  |  | 246 |  |  |  | 1,266 |  |
| Loss Before Income Taxes |  |  | (18,604 | ) |  |  | (42,664 | ) |  |  | (432,263 | ) |  |  | (231,210 | ) |
| Income tax expense |  |  | (24,906 | ) |  |  | (64,632 | ) |  |  | (8,785 | ) |  |  | (28,133 | ) |
| Net Loss |  | $ | (43,510 | ) |  | $ | (107,296 | ) |  | $ | (441,048 | ) |  | $ | (259,343 | ) |
| Net Income attributable to non-controlling interest |  |  | 2,406 |  |  |  | 2,566 |  |  |  | 9,824 |  |  |  | 6,946 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (45,916 | ) |  | $ | (109,862 | ) |  | $ | (450,872 | ) |  | $ | (266,289 | ) |
| Weighted average shares outstanding – basic |  |  | 79,091 |  |  |  | 78,530 |  |  |  | 78,928 |  |  |  | 78,416 |  |
| Weighted average shares outstanding – diluted |  |  | 79,091 |  |  |  | 78,530 |  |  |  | 78,928 |  |  |  | 78,416 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.58 | ) | (1) | $ | (1.40 | ) |  | $ | (5.67 | ) | (1) | $ | (3.39 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.58 | ) | (1) | $ | (1.40 | ) |  | $ | (5.67 | ) | (1) | $ | (3.39 | ) |

[0000950170-25-028352:8k_2_02:47]
(1) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $5 thousand effect of redemption for the three months ended December 31, 2024 and $3.0 million effect of redemption of RNCI for the year ended December 31, 2024.

[0000950170-25-028352:8k_2_02:48]
Condensed Consolidated Statements of Cash Flows

[0000950170-25-028352:8k_2_02:49]
(Preliminary, Unaudited)

[0000950170-25-028352:8k_2_02:50]
(In thousands)

[0000950170-25-028352:8k_2_02:51]
|  |  | Twelve Months Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net Loss |  | $ | (441,048 | ) |  | $ | (259,343 | ) |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 90,985 |  |  |  | 112,949 |  |
| Goodwill impairment |  |  | 292,583 |  |  |  | 37,874 |  |
| Amortization of debt issuance cost |  |  | 3,950 |  |  |  | 862 |  |
| Accretion on available-for-sale investments, net |  |  | — |  |  |  | (22 | ) |
| Gain on investments |  |  | (5,030 | ) |  |  | (2,900 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 1,371 |  |  |  | 458 |  |
| Stock-based compensation expense |  |  | 15,342 |  |  |  | 16,016 |  |
| Deferred income taxes |  |  | 2,247 |  |  |  | 15,558 |  |
| Inventory write down |  |  | 4,135 |  |  |  | 24,313 |  |
| Inventory reserves |  |  | 3,980 |  |  |  | 25,546 |  |
| Other, net |  |  | — |  |  |  | (2,942 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 46,108 |  |  |  | 65,612 |  |
| Other receivables |  |  | 10,713 |  |  |  | 10,315 |  |
| Income taxes receivable |  |  | 648 |  |  |  | (2,637 | ) |
| Inventory |  |  | 75,171 |  |  |  | 20,537 |  |
| Prepaid expenses other current assets and other assets |  |  | (10,718 | ) |  |  | (29,883 | ) |
| Accounts payable |  |  | 11,784 |  |  |  | (91,907 | ) |
| Accrued expenses and other liabilities |  |  | 5,519 |  |  |  | 17,929 |  |
| Income taxes payable, net |  |  | (4,670 | ) |  |  | (3,939 | ) |
| Net cash provided by (used in) operating activities |  |  | 103,070 |  |  |  | (45,604 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (32,454 | ) |  |  | (43,121 | ) |
| Purchases of intangibles - developed technology |  |  | (30,671 | ) |  |  | — |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 1,240 |  |  |  | 10,567 |  |
| Purchases of available-for-sale investments |  |  | (268 | ) |  |  | (868 | ) |
| (Payments) Proceeds from beneficial interests in securitized accounts receivable |  |  | (55 | ) |  |  | 1,218 |  |
| Net cash used in investing activities |  |  | (62,208 | ) |  |  | (32,204 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (1,143 | ) |  |  | (6,458 | ) |
| Proceeds from stock option exercises |  |  | 824 |  |  |  | 540 |  |
| Dividend payments |  |  | — |  |  |  | (21,237 | ) |
| Proceeds from receivables purchase agreement |  |  | 68,556 |  |  |  | 14,099 |  |
| Repayments on receivables purchase agreement |  |  | (83,772 | ) |  |  | — |  |
| Proceeds from draw on revolving credit agreements |  |  | 26,000 |  |  |  | 163,733 |  |
| Repayment of revolving credit agreements |  |  | (31,000 | ) |  |  | (64,987 | ) |
| Redemption of redeemable non-controlling interest |  |  | (17,398 | ) |  |  | (1,224 | ) |
| Payment of annual recurring compensation to non-controlling interest |  |  | (10,084 | ) |  |  | — |  |
| Payment of debt issuance cost |  |  | (1,994 | ) |  |  | (708 | ) |
| Repayment of notes payable |  |  | — |  |  |  | (24,891 | ) |
| Net cash (used in) provided by financing activities |  |  | (50,011 | ) |  |  | 58,867 |  |
| Net decrease in cash and cash equivalents |  |  | (9,149 | ) |  |  | (18,941 | ) |
| Effect of exchange rate changes |  |  | (451 | ) |  |  | (2,536 | ) |
| Cash and cash equivalents, beginning of year |  |  | 87,167 |  |  |  | 108,644 |  |
| Cash and cash equivalents, end of year |  | $ | 77,567 |  |  | $ | 87,167 |  |
| Supplemental disclosure of cash financing activities |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 20,884 |  |  | $ | 12,596 |  |
| Cash paid for income taxes |  | $ | 10,384 |  |  | $ | 18,552 |  |
| Cash used in operating activities related to operating leases |  | $ | 9,274 |  |  | $ | 9,682 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 5,317 |  |  | $ | 17,865 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 2,635 |  |  | $ | 1,298 |  |
| Redemption of redeemable non-controlling interest |  | $ | 2,986 |  |  | $ | 371 |  |

[0000950170-25-028352:8k_2_02:52]
Supplemental Information

[0000950170-25-028352:8k_2_02:53]
Reconciliation of Preliminary Gross Profit and Preliminary Gross Margin to

[0000950170-25-028352:8k_2_02:54]
Preliminary Non-GAAP Gross Profit and Preliminary Non-GAAP Gross Margin

[0000950170-25-028352:8k_2_02:55]
(Unaudited)

[0000950170-25-028352:8k_2_02:56]
(In thousands)

[0000950170-25-028352:8k_2_02:57]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |
|  |  | December 31, 2024 |  |  | September 30, 2024 |  |  | December 31, 2023 |  |  |  | December 31, 2024 |  |  | December 31, 2023 |  |
| Total Revenue |  | $ | 242,852 |  |  | $ | 227,704 |  |  | $ | 225,479 |  |  |  | $ | 922,720 |  |  | $ | 1,149,100 |  |
| Cost of Revenue |  | $ | 151,619 |  |  | $ | 142,453 |  |  | $ | 147,014 |  |  |  | $ | 592,406 |  |  | $ | 816,037 |  |
| Acquisition-related expenses, amortization and adjustments(1) |  |  | (9,980 | ) |  |  | (10,276 | ) |  |  | (10,048 | ) |  |  |  | (40,497 | ) |  |  | (89,602 | ) |
| Stock-based compensation expense |  |  | (317 | ) |  |  | (270 | ) |  |  | (440 | ) |  |  |  | (1,142 | ) |  |  | (1,294 | ) |
| Restructuring expenses(2) |  |  | (538 | ) |  |  | (7 | ) |  |  | (5,517 | ) |  |  |  | (14,580 | ) |  |  | (27,223 | ) |
| Integration expenses(3) |  |  | 123 |  |  |  | (34 | ) |  |  | 39 |  |  |  |  | 19 |  |  |  | (115 | ) |
| Non-GAAP Cost of Revenue |  | $ | 140,907 |  |  | $ | 131,866 |  |  | $ | 131,048 |  |  |  | $ | 536,206 |  |  | $ | 697,803 |  |
| Gross Profit |  | $ | 91,233 |  |  | $ | 85,251 |  |  | $ | 78,465 |  |  |  | $ | 330,314 |  |  | $ | 333,063 |  |
| Non-GAAP Gross Profit |  | $ | 101,945 |  |  | $ | 95,838 |  |  | $ | 94,431 |  |  |  | $ | 386,514 |  |  | $ | 451,297 |  |
| Gross Margin |  |  | 37.6 | % |  |  | 37.4 | % |  |  | 34.8 | % |  |  |  | 35.8 | % |  |  | 29.0 | % |
| Non-GAAP Gross Margin |  |  | 42.0 | % |  |  | 42.1 | % |  |  | 41.9 | % |  |  |  | 41.9 | % |  |  | 39.3 | % |

[0000950170-25-028352:8k_2_02:58]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-028352:8k_2_02:59]
(2) Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. These expenses include inventory write down and other charges of $8.6 million and other expenses of $0.6 million for the twelve months ended December 31, 2024, incurred as a result of a strategy shift which included discontinuance of certain product lines in connection with the Business Efficiency Program. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and was substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany which occurred in December 2024. These expenses include restructuring wage charges of $5.4 million for the twelve months ended December 31, 2024.

[0000950170-25-028352:8k_2_02:60]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE.

[0000950170-25-028352:8k_2_02:61]
Supplemental Information

[0000950170-25-028352:8k_2_02:62]
Reconciliation of Preliminary Operating Expenses to Preliminary Non-GAAP Operating Expenses

[0000950170-25-028352:8k_2_02:63]
(Unaudited)

[0000950170-25-028352:8k_2_02:64]
(In thousands)

[0000950170-25-028352:8k_2_02:65]
|  | Three Months Ended |  |  | Twelve Months Ended |  |  |
|  | December 31, 2024 |  |  | September 30, 2024 |  |  | December 31, 2023 |  |  | December 31, 2024 |  |  | December 31, 2023 |  |  |
| Operating Expenses | $ | 106,365 |  |  | $ | 109,235 |  |  | $ | 116,080 |  |  | $ | 747,415 |  |  | $ | 554,334 |  |  |
| Acquisition-related expenses, amortization and adjustments (1) |  | (5,294 | ) | (2) |  | (5,054 | ) | (7) |  | (4,150 | ) | (11) |  | (22,462 | ) | (15) |  | (17,666 | ) | (20) |
| Stock-based compensation expense |  | (3,351 | ) | (3) |  | (3,126 | ) | (8) |  | (3,181 | ) | (12) |  | (13,245 | ) | (16) |  | (13,864 | ) | (21) |
| Restructuring expenses |  | (3,567 | ) | (4) |  | (5,930 | ) | (9) |  | (7,859 | ) | (13) |  | (30,101 | ) | (17) |  | (19,331 | ) | (22) |
| Integration expenses |  | (586 | ) | (5) |  | (333 | ) | (10) |  | (1,928 | ) | (14) |  | (1,930 | ) | (18) |  | (4,825 | ) | (23) |
| Deferred compensation adjustments(6) |  | 451 |  |  |  | (1,471 | ) |  |  | (1,324 | ) |  |  | (3,808 | ) |  |  | 390 |  |  |
| Goodwill impairment |  | — |  |  |  | — |  |  |  | — |  |  |  | (292,583 | ) | (19) |  | (37,874 | ) | (24) |
| Non-GAAP Operating Expenses | $ | 94,018 |  |  | $ | 93,321 |  |  | $ | 97,638 |  |  | $ | 383,286 |  |  | $ | 461,164 |  |  |

[0000950170-25-028352:8k_2_02:66]
(1) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-028352:8k_2_02:67]
(2) Includes $4.3M of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations and $1.0 million of legal and advisory fees related to a potential strategic transaction which are included in selling, general and administrative expenses on the condensed consolidated statements of loss.

[0000950170-25-028352:8k_2_02:68]
(3) $2.4 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-028352:8k_2_02:69]
(4) $1.2 million is included in selling, general and administrative expenses and $2.4 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and was substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany which occurred in December 2024.

[0000950170-25-028352:8k_2_02:70]
(5) $0.6 million is included in selling, general and administrative expenses and less than $0.1 million is included in research and development expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE.

[0000950170-25-028352:8k_2_02:71]
(6) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-25-028352:8k_2_02:72]
(7)  Includes $4.0M of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations and $0.6 million of legal and advisory fees related to a potential strategic transaction which are both included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-028352:8k_2_02:73]
(8) $2.2 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-028352:8k_2_02:74]
(9) $2.7 million is included in selling, general and administrative expenses and $3.2 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses of $3.2 million of wage related and other charges due to the Greifswald facility closure of which $0.8 million is included in selling, general and administrative and $2.4 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and was substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany which occurred in December 2024.

[0000950170-25-028352:8k_2_02:75]
(10) $0.3 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE.

[0000950170-25-028352:8k_2_02:76]
(11) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $3.7 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-028352:8k_2_02:77]
(12) $2.3 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss

[0000950170-25-028352:8k_2_02:78]
(13) $4.6 million is included in selling, general and administrative expenses and $3.2 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and was substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany which occurred in December 2024.

[0000950170-25-028352:8k_2_02:79]
(14) $1.9 million is included in selling, general and administrative expenses and $0.02 million is included in research and development expenses on the condensed consolidated statements of loss. Includes legal and advisory fees totaling $1.2 million related to a contemplated capital raise transaction that are recorded in selling, general and administrative expenses. Includes expenses totaling $0.4 million related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE of which $0.4 million are included in selling, general and administrative expenses and $0.02 million are included in research and development expenses. The integration bonus expense of $0.4 million includes $0.2 million of stock compensation expense. Additionally, includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA.

[0000950170-25-028352:8k_2_02:80]
(15) Includes $17.6M of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations and $4.9 million of legal and advisory fees related to a potential strategic transaction which are included in selling, general and administrative expenses on the condensed consolidated statements of loss.

[0000950170-25-028352:8k_2_02:81]
(16) $9.4 million is included in selling, general and administrative expenses and $3.8 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-028352:8k_2_02:82]
(17) $9.1 million is included in selling, general and administrative expenses and $21.0 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and was substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany which occurred in December 2024.

[0000950170-25-028352:8k_2_02:83]
(18) $1.8 million is included in selling, general and administrative expenses and $0.1 million is included in research and development expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE.

[0000950170-25-028352:8k_2_02:84]
(19) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company's market capitalization, cautious service provider spending due to economic uncertainty and continued elevated customer inventory adjustments.

[0000950170-25-028352:8k_2_02:85]
(20) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $15.8 million is included in selling, general and administrative expenses and $1.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-028352:8k_2_02:86]
(21) $9.8 million is included in selling, general and administrative expenses and $4.0 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-028352:8k_2_02:87]
(22) $11.6 million is included in selling, general and administrative expenses and $7.7 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and was substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany which occurred in December 2024.

[0000950170-25-028352:8k_2_02:88]
(23) $4.8 million is included in selling, general and administrative expenses and $0.1 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses related to the integration bonus program and fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. Additionally, includes legal and advisory fees totaling $1.2 million related to a contemplated capital raise transaction that are recorded in selling, general and administrative expenses.

[0000950170-25-028352:8k_2_02:89]
(24) Includes non-cash goodwill impairment charge related to our Services and Support reporting unit. The impairment primarily resulted from a decrease in projected revenue growth rates and EBITDA margins.

[0000950170-25-028352:8k_2_02:90]
Supplemental Information

[0000950170-25-028352:8k_2_02:91]
Reconciliation of Preliminary Operating Loss to Preliminary Non-GAAP Operating Income (Loss)

[0000950170-25-028352:8k_2_02:92]
(Unaudited)

[0000950170-25-028352:8k_2_02:93]
(In thousands)

[0000950170-25-028352:8k_2_02:94]
|  | Three Months Ended |  |  | Twelve Months Ended |  |  |
|  | December 31, 2024 |  |  | September 30, 2024 |  |  | December 31, 2023 |  |  | December 31, 2024 |  |  | December 31, 2023 |  |  |
| Operating Loss | $ | (15,132 | ) |  | $ | (23,984 | ) |  | $ | (37,615 | ) |  | $ | (417,101 | ) |  | $ | (221,271 | ) |  |
| Acquisition related expenses, amortizations and adjustments(1) |  | 15,274 |  |  |  | 15,330 |  |  |  | 14,198 |  |  |  | 62,959 |  |  |  | 107,267 |  |  |
| Stock-based compensation expense |  | 3,668 |  |  |  | 3,396 |  |  |  | 3,621 |  |  |  | 14,387 |  |  |  | 15,158 |  |  |
| Restructuring expenses(2) |  | 4,105 |  |  |  | 5,936 |  |  |  | 13,376 |  |  |  | 44,681 |  |  |  | 46,554 |  |  |
| Integration expenses(3) |  | 464 |  |  |  | 367 |  |  |  | 1,890 |  |  |  | 1,911 |  |  |  | 4,941 |  |  |
| Deferred compensation adjustments(4) |  | (451 | ) |  |  | 1,471 |  |  |  | 1,324 |  |  |  | 3,808 |  |  |  | (390 | ) |  |
| Goodwill impairment |  | — |  |  |  | — |  |  |  | — |  |  |  | 292,583 |  | (5) |  | 37,874 |  | (6) |
| Non-GAAP Operating Income (Loss) | $ | 7,928 |  |  | $ | 2,516 |  |  | $ | (3,206 | ) |  | $ | 3,228 |  |  | $ | (9,867 | ) |  |

[0000950170-25-028352:8k_2_02:95]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-028352:8k_2_02:96]
(2) Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and was substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany which occurred in December 2024.

[0000950170-25-028352:8k_2_02:97]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks SE. Includes fees incurred for the expansion of internal controls at Adtran Networks SE and the implementation of the DPTLA.

[0000950170-25-028352:8k_2_02:98]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-25-028352:8k_2_02:99]
(5) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company's market capitalization, cautious service provider spending due to economic uncertainty and continued elevated customer inventory adjustments.

[0000950170-25-028352:8k_2_02:100]
(6) Non-cash goodwill impairment charge related to our Services and Support reporting unit. The impairment primarily resulted from a decrease in projected revenue growth rates and EBITDA margins.

[0000950170-25-028352:8k_2_02:101]
Supplemental Information

[0000950170-25-028352:8k_2_02:102]
Reconciliation of Preliminary Other Expense to Preliminary Non-GAAP Other Expense

[0000950170-25-028352:8k_2_02:103]
(Unaudited)

[0000950170-25-028352:8k_2_02:104]
(In thousands)

[0000950170-25-028352:8k_2_02:105]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |
|  |  | December 31, 2024 |  |  | September 30, 2024 |  |  | December 31, 2023 |  |  |  | December 31, 2024 |  |  | December 31, 2023 |  |
| Interest and dividend income |  | $ | 1,631 |  |  | $ | 664 |  |  | $ | 1,157 |  |  |  | $ | 3,058 |  |  | $ | 2,340 |  |
| Interest expense |  |  | (4,870 | ) |  |  | (5,679 | ) |  |  | (4,441 | ) |  |  |  | (22,053 | ) |  |  | (16,299 | ) |
| Net investment (loss) gain |  |  | (920 | ) |  |  | 1,382 |  |  |  | 1,683 |  |  |  |  | 3,587 |  |  |  | 2,754 |  |
| Other income (expense), net |  |  | 687 |  |  |  | (850 | ) |  |  | (3,448 | ) |  |  |  | 246 |  |  |  | 1,266 |  |
| Total Other Expense |  | $ | (3,472 | ) |  | $ | (4,483 | ) |  | $ | (5,049 | ) |  |  | $ | (15,162 | ) |  | $ | (9,939 | ) |
| Deferred compensation adjustments (1) |  |  | 1,090 |  |  |  | (1,294 | ) |  |  | (1,590 | ) |  |  |  | (3,539 | ) |  |  | (2,977 | ) |
| Pension expense (2) |  |  | 7 |  |  |  | 7 |  |  |  | 6 |  |  |  |  | 28 |  |  |  | 26 |  |
| Non-GAAP Other Expense |  | $ | (2,375 | ) |  | $ | (5,770 | ) |  | $ | (6,633 | ) |  |  | $ | (18,673 | ) |  | $ | (12,890 | ) |

[0000950170-25-028352:8k_2_02:106]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0000950170-25-028352:8k_2_02:107]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-25-028352:8k_2_02:108]
Supplemental Information

[0000950170-25-028352:8k_2_02:109]
Reconciliation of Preliminary Net Loss inclusive of Non-Controlling Interest to

[0000950170-25-028352:8k_2_02:110]
Preliminary Non-GAAP Net Income (Loss) inclusive of Non-Controlling Interest

[0000950170-25-028352:8k_2_02:111]
(Unaudited)

[0000950170-25-028352:8k_2_02:112]
and

[0000950170-25-028352:8k_2_02:113]
Reconciliation of Preliminary Net Income attributable to Non-Controlling Interest to

[0000950170-25-028352:8k_2_02:114]
Preliminary Non-GAAP Net Income attributable to Non-Controlling Interest

[0000950170-25-028352:8k_2_02:115]
(Unaudited)

[0000950170-25-028352:8k_2_02:116]
and

[0000950170-25-028352:8k_2_02:117]
Reconciliation of Preliminary Net Loss attributable to ADTRAN Holdings, Inc. and

[0000950170-25-028352:8k_2_02:118]
Preliminary Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0000950170-25-028352:8k_2_02:119]
Preliminary Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. and

[0000950170-25-028352:8k_2_02:120]
Preliminary Non-GAAP Earnings (Loss) per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0000950170-25-028352:8k_2_02:121]
(Unaudited)

[0000950170-25-028352:8k_2_02:122]
(In thousands, except per share amounts)

[0000950170-25-028352:8k_2_02:123]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |  |
|  |  | December 31, 2024 |  |  | September 30, 2024 |  |  | December 31, 2023 |  |  |  | December 31, 2024 |  |  | December 31, 2023 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | (45,911 | ) |  | $ | (28,263 | ) |  | $ | (109,592 | ) |  |  | $ | (447,886 | ) |  | $ | (266,289 | ) |  |
| Effect of redemption of RNCI(1) |  |  | (5 | ) |  |  | (2,976 | ) |  |  | — |  |  |  |  | (2,986 | ) |  |  | — |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (45,916 | ) |  | $ | (31,239 | ) |  | $ | (109,592 | ) |  |  | $ | (450,872 | ) |  | $ | (266,289 | ) |  |
| Net Income attributable to non-controlling interest(2) |  |  | 2,407 |  |  |  | 2,382 |  |  |  | 2,566 |  |  |  |  | 9,824 |  |  |  | 6,946 |  |  |
| Net Loss inclusive of non-controlling interest |  | $ | (43,509 | ) |  | $ | (28,857 | ) |  | $ | (107,026 | ) |  |  | $ | (441,048 | ) |  | $ | (259,343 | ) |  |
| Acquisition related expenses, amortization and adjustments (3) |  |  | 15,274 |  |  |  | 15,330 |  |  |  | 14,198 |  |  |  |  | 62,959 |  |  |  | 107,267 |  |  |
| Stock-based compensation expense |  |  | 3,668 |  |  |  | 3,396 |  |  |  | 3,621 |  |  |  |  | 14,387 |  |  |  | 15,158 |  |  |
| Deferred compensation adjustments(4) |  |  | 639 |  |  |  | 177 |  |  |  | (267 | ) |  |  |  | 269 |  |  |  | (3,368 | ) |  |
| Pension adjustments(5) |  |  | 7 |  |  |  | 7 |  |  |  | 6 |  |  |  |  | 28 |  |  |  | 26 |  |  |
| Restructuring expenses(6) |  |  | 4,105 |  |  |  | 5,936 |  |  |  | 13,376 |  |  |  |  | 44,681 |  |  |  | 46,554 |  |  |
| Integration expenses(7) |  |  | 464 |  |  |  | 367 |  |  |  | 1,890 |  |  |  |  | 1,911 |  |  |  | 4,941 |  |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | 292,583 |  |  |  | 37,874 |  |  |
| Tax effect of adjustments to net loss(8) |  |  | 21,804 |  |  |  | (712 | ) |  |  | 62,221 |  |  |  |  | 2,782 |  |  |  | 12,076 |  |  |
| Non-GAAP Net Income (Loss) inclusive of non-controlling interest |  | $ | 2,452 |  |  | $ | (4,356 | ) |  | $ | (11,981 | ) |  |  | $ | (21,448 | ) |  | $ | (38,815 | ) |  |
| Net Income attributable to non-controlling interest(2) |  |  | 2,407 |  |  |  | 2,382 |  |  |  | 2,566 |  |  |  |  | 9,824 |  |  |  | 8,475 |  |  |
| Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. |  | $ | 45 |  |  | $ | (6,738 | ) |  | $ | (14,547 | ) |  |  | $ | (31,272 | ) |  | $ | (47,290 | ) |  |
| Effect of redemption of RNCI (1) |  |  | 5 |  |  |  | 2,976 |  |  |  | — |  |  |  |  | 2,986 |  |  |  | — |  |  |
| Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | 50 |  |  | $ | (3,762 | ) |  | $ | (14,547 | ) |  |  | $ | (28,286 | ) |  | $ | (47,290 | ) |  |
| GAAP Net Income attributable to non-controlling interest (2) |  | $ | 2,407 |  |  | $ | 2,382 |  |  | $ | 2,566 |  |  |  | $ | 9,824 |  |  | $ | 6,946 |  |  |
| Acquisition related expenses, amortizations and adjustments(3) |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 1,457 |  |  |
| Restructuring expenses(6) |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 29 |  |  |
| Integration expenses(7) |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 6 |  |  |
| Stock-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 37 |  |  |
| Pension adjustments(5) |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | — |  |  |
| Non-GAAP Net Income attributable to non-controlling interest (2) |  | $ | 2,407 |  |  | $ | 2,382 |  |  | $ | 2,566 |  |  |  | $ | 9,824 |  |  | $ | 8,475 |  |  |
| Weighted average shares outstanding – basic |  |  | 79,091 |  |  |  | 78,952 |  |  |  | 78,530 |  |  |  |  | 78,928 |  |  |  | 78,416 |  |  |
| Weighted average shares outstanding – diluted |  |  | 79,091 |  |  |  | 78,952 |  |  |  | 78,530 |  |  |  |  | 78,928 |  |  |  | 78,416 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. - basic |  | $ | (0.58 | ) |  | $ | (0.36 | ) |  | $ | (1.40 | ) |  |  | $ | (5.67 | ) |  | $ | (3.39 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. - diluted |  | $ | (0.58 | ) |  | $ | (0.36 | ) |  | $ | (1.40 | ) |  |  | $ | (5.67 | ) |  | $ | (3.39 | ) |  |
| Non-GAAP Earnings (Loss) per common share attributable to ADTRAN Holdings, Inc. - basic |  | $ | 0.00 |  |  | $ | (0.05 | ) |  | $ | (0.19 | ) |  |  | $ | (0.36 | ) |  | $ | (0.60 | ) |  |
| Non-GAAP Earnings (Loss) per common share attributable to ADTRAN Holdings, Inc. - diluted |  | $ | 0.00 |  |  | $ | (0.05 | ) |  | $ | (0.19 | ) |  |  | $ | (0.36 | ) |  | $ | (0.60 | ) |  |

[0000950170-25-028352:8k_2_02:124]
(1) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $5 thousand and $3.0 million effect of redemption for the three months ended December 31, 2024 and September 30, 2024 respectively and $3.0 million effect of redemption of RNCI for the year ended December 31, 2024.

[0000950170-25-028352:8k_2_02:125]
(2) Represents the non-controlling interest portion of the Company's ownership of Adtran Networks pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0000950170-25-028352:8k_2_02:126]
(3) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-028352:8k_2_02:127]
(4) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-25-028352:8k_2_02:128]
(5) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-25-028352:8k_2_02:129]
(6) Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and was substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany which occurred in December 2024.

[0000950170-25-028352:8k_2_02:130]
(7) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE.

[0000950170-25-028352:8k_2_02:131]
(8) Represents the tax effect of non-GAAP adjustments. Beginning in the period ended September 30, 2024, the Company changed its method of calculating non-GAAP income taxes by applying blended statutory tax rates to non-GAAP losses before income taxes in order to include current and deferred income tax expenses that are commensurate with the non-GAAP measure of profitability. The blended statutory tax rate is calculated using 0%, resulting in no tax benefits net of impact of valuation allowance, for the loss jurisdiction’s non-GAAP losses before income taxes and 30% for all remaining jurisdictions’ non-GAAP income before income taxes. Prior periods have been adjusted to reflect the application of blended statutory tax rates, net of impact of valuation allowance, to non-GAAP losses before income taxes as opposed to the previous application of blended statutory and effective tax rates to separate non-GAAP adjustments. We previously reported the tax effect of the adjustment to non-GAAP net loss under the prior method of $8.7 million and $57.8 million for the three and twelve months ended December 31, 2023.

[0000950170-25-028352:8k_2_02:132]
Supplemental Information

[0000950170-25-028352:8k_2_02:133]
Reconciliation of Preliminary Net Cash Provided By (Used In) Operating Activities to Preliminary Free Cash Flow

[0000950170-25-028352:8k_2_02:134]
(Unaudited)

[0000950170-25-028352:8k_2_02:135]
(In thousands)

[0000950170-25-028352:8k_2_02:136]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | September 30, |  |  | December 31, |  |  |  | December 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2024 |  |  | 2023 |  |  |  | 2024 |  |  | 2023 |  |
| Net Cash provided by (used in) operating activities |  | $ | 4,544 |  |  | $ | 42,030 |  |  | $ | (16,290 | ) |  |  | $ | 103,070 |  |  | $ | (45,604 | ) |
| Purchases of property, plant and equipment and developed technologies(1) |  |  | (14,942 | ) |  |  | (18,814 | ) |  |  | (9,447 | ) |  |  |  | (63,125 | ) |  |  | (43,121 | ) |
| Free cash flow |  | $ | (10,398 | ) |  | $ | 23,216 |  |  | $ | (25,737 | ) |  |  | $ | 39,945 |  |  | $ | (88,725 | ) |

[0000950170-25-028352:8k_2_02:137]
(1) Purchases related to capital expenditures and developed technologies.
