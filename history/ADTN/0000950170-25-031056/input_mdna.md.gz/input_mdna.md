# ADTN MD&A — 0000950170-25-031056


## mdna

[0000950170-25-031056:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000950170-25-031056:mdna:2]
The following discussion should be read in conjunction with our audited consolidated financial statements and the related notes included in Part II, Item 8 of this report. We have omitted discussion of the earliest of the three years of financial condition and results of operations and this information can be found in Part I, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the fiscal year ended December 31, 2023, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, and Part I, Item 1A, Risk Factors, included in Amendment No. 1 to our Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on March 15, 2024 (the “2023 Form 10-K”), as well as Part I, Item 1, Business, included in our Annual Report on Form 10-K filed with the SEC on March 15, 2024, which is available free of charge on the SEC's website at http://www.sec.gov and on our website at www.adtran.com.

[0000950170-25-031056:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 2 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part I, Item 1A, Risk Factors, of this Form 10-K.

[0000950170-25-031056:mdna:4]
Unless the context otherwise indicates or requires, references in this Annual Report on Form 10-K to "Adtran", the “Company,” “we”, “us” and “our” refer to ADTRAN Holdings, Inc. and its consolidated subsidiaries for periods subsequent to the Merger and to ADTRAN, Inc. and its consolidated subsidiaries for periods prior to the Merger. The prior period results do not include the results of Adtran Networks prior to the Business Combination which occurred on July 15, 2022. Furthermore, unless the context otherwise indicates or requires, references in this Annual Report on Form 10-K to “Adtran Networks” refer to Adtran Networks SE (formerly ADVA Optical Networking SE).

[0000950170-25-031056:mdna:5]
Overview

[0000950170-25-031056:mdna:6]
The Company is a leading global provider of networking and communications platforms, software, systems and services focused on carrier networks, data center interconnect for private enterprise networks and mission critical infrastructure. It is serving a diverse domestic and international customer base in multiple countries that includes Large, Medium and Small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders; cable/MSOs; SMBs; distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies.

[0000950170-25-031056:mdna:7]
Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to have customers adopt our technology, increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-25-031056:mdna:8]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). Adtran is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer, especially upon the convergence of solutions at the network edge.

[0000950170-25-031056:mdna:9]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. In addition to operating under two reportable segments, the Company also reports revenue across three categories – Subscriber Solutions, Access & Aggregation Solutions and Optical Networking Solutions.

[0000950170-25-031056:mdna:10]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at customers' premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include our Mosaic One SaaS applications, fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers and cloud software solutions covering a mix of subscriber types.

[0000950170-25-031056:mdna:11]
Our Access & Aggregation Solutions are solutions that are used by communications Service Providers to connect residential subscribers, business subscribers and mobile radio networks to the Service Providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions and access orchestration solutions that ensure highly reliable and efficient network performance.

[0000950170-25-031056:mdna:12]
Our Optical Networking Solutions are used by communications Service Providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems and automation platforms that are used to build high-scale, secure and assured optical networks.

[0000950170-25-031056:mdna:13]
Adtran Networks Domination and Profit and Loss Transfer Agreement

[0000950170-25-031056:mdna:14]
The DPLTA between the Company, as the controlling company, and Adtran Networks, as the controlled company, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-25-031056:mdna:15]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is
entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applied for the first time to the net loss generated in 2023.

[0000950170-25-031056:mdna:16]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest (the "Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.52 per share for each full fiscal year of Adtran Networks (the “Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component that was 3.37% as of December 31, 2024. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks' ordinary general shareholders' meeting occurred on June 28, 2024, and therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for June 27, 2025, and therefore, the Annual Recurring Compensation will be due on July 2, 2025. The adequacy of both forms of compensation has been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation (including interest thereon) or Annual Recurring Compensation than agreed upon in the DPLTA.

[0000950170-25-031056:mdna:17]
The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a procedural decision during 2025 that will likely be appealed. The date of a decision by the court on the merits of the case is uncertain, but it is unlikely that such decision will be rendered in 2025. Thereafter, an expected appeal process will take a further 12-24 months to resolve. For the year ended December 31, 2024, approximately 831 thousand shares of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the year ended December 31, 2023, 67 thousand shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €1.2 million or approximately $1.3 million based on an exchange rate as of December 31, 2023, were paid to Adtran Networks' shareholders.

[0000950170-25-031056:mdna:18]
In addition to our cash and cash equivalents and the credit facility, we may fund a portion or all of the Exit Compensation through the sale of securities or additional alternative funding sources, if available. There can be no assurances that we would be successful in effecting these actions on commercially reasonable terms or at all. If we cannot raise additional funds as needed, it could have a material adverse impact on our financial results and financial condition.

[0000950170-25-031056:mdna:19]
We currently hold 34,856,232 no-par value bearer shares of Adtran Networks, representing 67.0% of Adtran Networks outstanding shares as of December 31, 2024.

[0000950170-25-031056:mdna:20]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which is incorporated by reference to Exhibit 10.7 included in our Annual Report on Form 10-K for the year ended December 31, 2023.

[0000950170-25-031056:mdna:21]
Business Efficiency Program

[0000950170-25-031056:mdna:22]
During the fourth quarter of 2023, the Company initiated a Business Efficiency Program designed to optimize the assets, business processes, and information technology systems of the Company in relation to the Business Combination with Adtran Networks. The Business Efficiency Program included expenses specifically associated with achieving run-rate synergies as well as Business Efficiency Program expenses described below. Other than the Company's aim of selling its headquarters, the Business Efficiency Program was substantially complete as of December 31, 2024. See Note 20 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:23]
During the years ended December 31, 2024 and 2023, we recognized $44.7 million and $25.1 million of costs relating to the Business Efficiency Program, respectively. Future cash payments include severance costs, outplacement fees and site consolidation that are anticipated to be approximately $10.3 million.

[0000950170-25-031056:mdna:24]
Business Combination Integration Costs

[0000950170-25-031056:mdna:25]
During the years ended December 31, 2024 and 2023, we recognized $1.9 million and $4.9 million, respectively, of integration costs related to the Business Combination were incurred. These transaction costs are included in selling, general and administrative expenses, research & development expenses and cost of revenue in the Consolidated Statement of Loss. The Company does not anticipate additional material expenses to be incurred in connection with this integration program.

[0000950170-25-031056:mdna:26]
Financial Performance and Trends

[0000950170-25-031056:mdna:27]
We ended 2024 with a year-over-year revenue decrease of 19.7%, driven by decreased volume of sales activity due to customers' focus on reducing inventory levels and continuing uncertain macroeconomic conditions related to elevated inflation, elevated interest rates and currency fluctuation which impacted the spending behavior of our customers. During 2024, we had one customer with revenues greater than 10.0% which was an international Service Provider customer and our next five largest customers comprised 21.7% of our revenue. Our year-over-year domestic revenue decreased by 13.6% and continued to be impacted by elevated customer inventory levels, continuing effects of uncertain macroeconomic conditions and decreased shipments to distributor customers. Internationally, our year-over-year revenue decreased by 23.8%, primarily driven by decreased shipments to network operators in Europe and the unfavorable impact of foreign exchange on revenue as a result of the strengthened U.S. dollar.

[0000950170-25-031056:mdna:28]
Access & Aggregation and Optical Networking revenue categories experienced a general slowdown in revenue as a result of reduced spending by our Service Provider customers as they continue to reduce excess inventory levels and monitor the uncertain macroeconomic conditions. Despite these challenges, we have maintained our emphasis on product development to enable us to respond to rapidly changing technology and evolving industry standards. For example, we expect public funding through projects such as IPCEI ME/CT to further our research and development for new communication technologies. Additionally, public funding through the Broadband Equity, Access and Deployment Program is expected to commence in 2025, which provides a positive outlook for the future. Nevertheless, these government-supported loan programs and grants generally include conditions such as deployment criteria, domestic preference provisions and other requirements that apply to the project and selected equipment as conditions for funding, which we expect will influence the extent to which such programs will have an impact on our revenue. In Europe, we continue to see increased activity from high-risk vendor replacement and broadband subsidy programs.

[0000950170-25-031056:mdna:29]
While our 2023 and 2024 revenues have fluctuated and may continue to fluctuate on a quarterly basis, during the fourth quarter of 2024, our operating results have improved due to slowly stabilizing revenues, improving margins and tight operational cost controls. Nevertheless, a significant percentage of orders require delivery within a few days, requiring us to maintain higher inventory levels. These factors may result in limited order flow visibility. We have taken decisive steps to transform our business into a leaner, more efficient and more profitable company, including the substantial completion of our Business Efficiency Program (other than the Company’s aim of selling its headquarters), which included a significant cost efficiency program targeting a reduction of ongoing operating expenses and a capital efficiency program inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the partial sale of owned real estate (including the potential sale of portions of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. Our operating expenses are relatively fixed in the short term, therefore, a shortfall in quarterly revenues has and may again in the future significantly impact our financial results in a given quarter.

[0000950170-25-031056:mdna:30]
Our operating results have significantly fluctuated and may do so in the future as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, inflation, increased competition, customer order patterns, changes in product and services mix, trade policies, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. In recent years, inflationary pressures on input costs, such as raw materials and labor, and distribution costs had a negative impact on our operating

[0000950170-25-031056:mdna:31]
results. However, inflationary pressures on our supply chain have eased somewhat, which has led to reductions in cost premiums on raw material costs and freight. We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors, and customers to address and to limit the disruption to our operations and order fulfillment. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an additional adverse effect on our business and operating results beyond the effects of the most recent inventory write-downs. Also, not maintaining sufficient inventory levels to ensure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results.

[0000950170-25-031056:mdna:32]
The U.S. government issued orders in February 2025 increasing tariffs on imports from certain countries, including Canada, China and Mexico, and it has discussed further tariffs, including plans to increase U.S. tariffs to match the rates that other countries charge on imports and tariffs on semiconductors, automobiles and pharmaceuticals imported into the U.S. While the implementation of tariffs on Canadian and Mexican imports was initially deferred, such tariffs are expected to go into effect in March 2025 and the U.S. has increased tariffs on goods imported into the U.S. from China by 10%. In response, China imposed a 15% tariff on U.S. coal and liquified natural gas products, along with a 10% tariff on crude oil. The U.S. government has indicated that an additional 10% duty on Chinese imports may be forthcoming, which may result in further tariffs on U.S. products being imported into China. The recent tariffs come on top of ongoing trade tensions and regulatory actions involving the governments of the U.S. and China. Moreover, on February 11, 2025, the U.S. government ordered tariffs of 25% on imports of steel and aluminum regardless of where they originate.

[0000950170-25-031056:mdna:33]
We are exposed to changes in foreign currencies relative to the U.S. dollar, which are references to the differences between the foreign-exchanges rates we use to convert the financial results of our international operations from local currencies into U.S. dollars for financial reporting purposes. This impact of foreign-exchange rate changes is calculated based on the difference between the current period’s currency exchange rates and that of the comparable prior period. Our primary exposures to foreign currency exchange rate movements are with the euro and the British pound. As a result of our global operations, our revenue, gross margins, operating expense and operating loss in some international markets have been and may continue to be affected by foreign currency fluctuations.

[0000950170-25-031056:mdna:34]
The Company’s policy is to assess the realizability of assets (long-lived assets, intangibles and goodwill) held within our reporting units and to evaluate such assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. During the third quarter of 2023, the Company identified a triggering event due to a decrease in its market capitalization and changes in projections (decrease in estimated cash flows). While the quantitative impairment analysis indicated that there was no impairment of Network Solutions goodwill, the Company determined a $37.9 million non-cash impairment charge for goodwill was warranted for the Services & Support reporting unit. During the fourth quarter of 2023, the Company completed its annual impairment test. There were no significant market changes or changes to cash flow projections, as such no triggering event was identified during the fourth quarter of 2023.

[0000950170-25-031056:mdna:35]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of the Network Solutions reporting unit using a combination of an income approach and a market approach. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit during the three months ended March 31, 2024. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the three months ended March 31, 2024. There have been no triggering events identified affecting the valuation of goodwill in our Services & Support reporting unit during the remainder of 2024.

[0000950170-25-031056:mdna:36]
Our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. For a discussion of risks associated with our operating results, see Part I, Item 1A, Risk Factors of this report.

[0000950170-25-031056:mdna:37]
49

[0000950170-25-031056:mdna:38]
Results of Operations

[0000950170-25-031056:mdna:39]
The following table presents selected financial information derived from our Consolidated Statements of Loss expressed as a percentage of revenue for the years indicated. Amounts may not foot due to rounding.

[0000950170-25-031056:mdna:40]
|  |  | Year Ended December 31, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Revenue |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 80.1 | % |  |  | 84.8 | % |  |  | 89.4 | % |
| Services & Support |  |  | 19.9 |  |  |  | 15.2 |  |  |  | 10.6 |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 55.4 |  |  |  | 62.9 |  |  |  | 63.1 |  |
| Network Solutions - other (credits), charges and inventory write-down |  |  | 0.9 |  |  |  | 2.1 |  |  |  | — |  |
| Services & Support |  |  | 7.9 |  |  |  | 6.0 |  |  |  | 5.0 |  |
| Total Cost of Revenue |  |  | 64.2 |  |  |  | 71.0 |  |  |  | 68.1 |  |
| Gross Profit |  |  | 35.8 |  |  |  | 29.0 |  |  |  | 31.9 |  |
| Selling, general and administrative expenses |  |  | 25.3 |  |  |  | 22.5 |  |  |  | 20.4 |  |
| Research and development expenses |  |  | 24.0 |  |  |  | 22.5 |  |  |  | 16.9 |  |
| Asset impairment |  |  | — |  |  |  | — |  |  |  | 1.7 |  |
| Goodwill impairments |  |  | 31.7 |  |  |  | 3.3 |  |  |  | — |  |
| Operating Loss |  |  | (45.2 | ) |  |  | (19.3 | ) |  |  | (7.1 | ) |
| Interest and dividend income |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Interest expense |  |  | (2.4 | ) |  |  | (1.4 | ) |  |  | (0.3 | ) |
| Net investment gain (loss) |  |  | 0.4 |  |  |  | 0.2 |  |  |  | (1.1 | ) |
| Other income, net |  |  | — |  |  |  | 0.1 |  |  |  | 1.4 |  |
| Loss Before Income Taxes |  |  | (46.8 | ) |  |  | (20.1 | ) |  |  | (6.9 | ) |
| Income tax (expense) benefit |  |  | (1.0 | ) |  |  | (2.4 | ) |  |  | 6.1 |  |
| Net Loss |  |  | (47.8 | )% |  |  | (22.6 | )% |  |  | (0.9 | )% |
| Net Income (loss) attributable to non-controlling interest |  |  | 1.1 |  |  |  | 0.6 |  |  |  | (0.7 | ) |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | (48.9 | )% |  |  | (23.2 | )% |  |  | (0.2 | )% |

[0000950170-25-031056:mdna:41]
The following discussion and financial information are presented to aid in an understanding of our current consolidated financial position, changes in financial position, results of operations and cash flows and should be read in conjunction with the audited consolidated financial statements and notes thereto included herein. The emphasis of the discussion is a comparison of the years ended December 31, 2024 and December 31, 2023. For a discussion of a comparison of the years ended December 31, 2023 and December 31, 2022, please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on March 15, 2024.

[0000950170-25-031056:mdna:42]
Comparison of Years Ended December 31, 2024 and December 31, 2023

[0000950170-25-031056:mdna:43]
Revenue

[0000950170-25-031056:mdna:44]
Our revenue decreased 19.7% from $1,149.1 million for the year ended December 31, 2023 to $922.7 million for the year ended December 31, 2024. The decrease in revenue for the year ended December 31, 2024 is primarily driven by a decrease in volume of sales activity due to customers’ focus on reducing inventory levels and the completion of significant customer projects. The decrease in revenue by category for the year ended December 31, 2024 was primarily attributable to $192.0 million decrease in Optical Networking Solutions products and a $67.4 million decrease in Access & Aggregation Solutions partially offset by a $33.1 million increase in Subscriber Solutions category. Continued customer concerns over inventory stocking levels have affected our revenue year-to-date in our Optical Networking Solutions category, Access & Aggregation category and our Subscriber Solutions category. This includes our two largest Optical Networking Solutions customers, which we believe are focused on reducing existing inventory.

[0000950170-25-031056:mdna:45]
Network Solutions segment revenue decreased 24.2% from $974.4 million in 2023 to $739.0 million in 2024, primarily attributable to $196.6 million decrease in Optical Networking Solutions products and a $71.1 million decrease in Access & Aggregation Solutions partially offset by a $32.3 million increase in Subscriber Solutions category. More specifically, for the year ended December 31, 2024, the decrease in revenue for our Subscriber Solutions products was primarily due to lower volume of sales of our residential solutions products as a result of customers focus on reducing inventory levels.

[0000950170-25-031056:mdna:46]
Services & Support revenue increased 5.2% from $174.7 million in 2023 to $183.8 million in 2024. The increase in revenue for 2024 was primarily attributable to $4.6 million increase in revenue for Optical Networking Solutions products, a $3.7 million increase in revenue for Access & Aggregation Solutions revenue and a $0.7 million increase in revenue for Subscriber Solutions services. More specifically, the increase in revenue for the year ended December 31, 2024 of our ADTRAN, Inc. operations was primarily due to higher volume of sales of our software services and business solutions services.

[0000950170-25-031056:mdna:47]
Domestic revenue decreased 13.6% from $461.0 million in 2023 to $398.2 million in 2024, driven by lower volume of sales of our residential solutions products as a result of customers' focus on reducing inventory levels in our Subscriber Solutions segment, partially offset by an increase in volume of sales activity during the first half of 2024 from the Business Combination with Adtran Networks.

[0000950170-25-031056:mdna:48]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., decreased 23.8% from $688.1 million for the year ended December 31, 2023 to $524.6 million for the year ended December 31, 2024. International revenue, as a percentage of total revenue, decreased from 59.8% for the year ended December 31, 2023 to 56.8% for the year ended December 31, 2024. The decrease in international revenue in 2024 was primarily due to the conclusion of specific customer projects and customer concerns over inventory levels.  For the year ended December 31, 2024 as compared to the year ended December 31, 2023, changes in foreign currencies relative to the U.S dollar increased our net revenue by approximately $5.4 million.

[0000950170-25-031056:mdna:49]
Our ADTRAN, Inc. international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income. Our Adtran Networks international revenue is largely focused on the manufacture and selling of networking solutions that are based on three core areas of expertise: fiber-optic transmission technology (cloud interconnect), cloud access technology for rapid creation of innovative services around the network edge and solutions for precise timing and synchronization of networks. In addition, Adtran Networks' international operations offers a comprehensive portfolio of network design, implementation and maintenance services to assist operators in the deployment of market-leading networks while reducing their cost to maintain these networks.

[0000950170-25-031056:mdna:50]
Cost of Revenue

[0000950170-25-031056:mdna:51]
As a percentage of revenue, cost of revenue decreased from 71.0% for the year ended December 31, 2023 to 64.2% for the year ended December 31, 2024. The decrease for the twelve months ended December 31, 2024 was attributable to (1) a 2.6% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, (2) a 2.7% decrease in expense as a percentage of revenue related to decreased acquisition costs, (3) a 1.4% decrease in expense as a percentage of revenue in connection with our Business Efficiency Program (primarily a decrease in inventory write-offs related to our strategy shift which included discontinuance of certain product lines, partially offset by increases in severance and employee related costs), (4) a 0.1% decrease in expense as a percentage of revenue attributable to changes in customer and product mix.  For the year ended December 31, 2024, changes in foreign currencies relative to the U.S. dollar increased our cost of revenue by approximately $0.7 million.

[0000950170-25-031056:mdna:52]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, decreased from 76.7% of revenue in 2023 to 70.3% of revenue in 2024. The decrease in cost of revenue as a percentage of revenue for the twelve months ended December 31, 2024 was attributable to (1) a 3.3% decrease in expense as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, (2) a 3.4% decrease in expense as a percentage of revenue related to decreased acquisition costs, and (3) a 1.9% decrease in expense as a percentage of revenue in connection with our Business Efficiency Program, which resulted in an inventory write down and other charges of $8.6 million incurred as a result of a strategy shift including discontinuance of certain product lines, partially offset by (4) a 2.2% increase in expense as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-25-031056:mdna:53]
Services & Support cost of revenue, as a percentage of that segment’s revenue, remained flat at 39.6% of revenue in 2023 and 2024.

[0000950170-25-031056:mdna:54]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0000950170-25-031056:mdna:55]
Gross Profit

[0000950170-25-031056:mdna:56]
As a percentage of revenue, gross profit increased from 29.0% for the year ended December 31, 2023 to 35.8% for the year ended December 31, 2024. The increase for the twelve months ended December 31, 2024 was attributable to (1) a 2.6% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, (2) a 2.7% increase in gross profit as a percentage of revenue related to decreased acquisition costs, (3) a 1.4% increase in gross profit as a percentage of revenue in connection with decreased expenses with our Business Efficiency Program (primarily a decrease in inventory write-offs related to our strategy shift which included discontinuance of certain product lines, partially offset by increases in severance and employee related costs), (4) a 0.1% increase in gross profit as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-25-031056:mdna:57]
As a percentage of that segment's revenue, Network Solutions gross profit increased from 23.3% for the year ended December 31, 2023 to 29.7% for the year ended December 31, 2024. The increase for the twelve months ended December 31, 2024 was attributable to (1) a 3.3% increase in gross profit as a percentage of revenue related to decreased amortization of intangible backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, (2) a 3.4% increase in gross profit as a percentage of revenue related to decreased acquisition costs, and (3) a 1.9% increase in gross profit as a percentage of revenue in connection with decreased expenses with our Business Efficiency Program, which resulted in an inventory write down and other charges of $8.6 million incurred as a result of a strategy shift including discontinuance of certain product lines, (4) partially offset by a 2.2% decrease in gross profit as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-25-031056:mdna:58]
As a percentage of that segment's revenue, Services & Support gross profit remained flat at 60.4% for the years ended December 31, 2023 and 2024.

[0000950170-25-031056:mdna:59]
Selling, General and Administrative Expenses

[0000950170-25-031056:mdna:60]
As a percentage of revenue, selling, general and administrative expenses increased from 22.5% for the year ended December 31, 2023, to 25.3% for the year ended December 31, 2024. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared. Other than our stated aim of selling our headquarters, we have substantially completed implementation of our Business Efficiency Program. We expect to continue to see lower selling, general and administrative expenses as a percentage of revenue over time.

[0000950170-25-031056:mdna:61]
Selling, general and administrative expenses decreased 9.6% from $258.1 million for the year ended December 31, 2023, to $233.4 million for the year ended December 31, 2024. Selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The decrease in selling, general and administrative expenses for the twelve months ended December 31, 2024, compared to the twelve months ended December 31, 2023, was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $20.4 million. For the year ended December 31, 2024, as compared to the year ended December 31, 2023, changes in foreign currencies relative to the U.S dollar increased our selling, general and administrative expenses by approximately $0.6 million.

[0000950170-25-031056:mdna:62]
Research and Development Expenses

[0000950170-25-031056:mdna:63]
As a percentage of revenue, research and development expenses increased from 22.5% for the year ended December 31, 2023, to 24.0% for the year ended December 31, 2024. Research and development expenses as a percentage of revenue will generally fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared. Other than our stated aim of selling our headquarters, we have substantially completed implementation of our Business Efficiency Program. We expect to continue to see lower research and development expense as a percentage of revenue over time.

[0000950170-25-031056:mdna:64]
Research and development expenses decreased 14.3% from $258.3 million for the year ended December 31, 2023, to $221.5 million for the year ended December 31, 2024. The decrease in research and development expenses for the twelve months ended December 31, 2024, was primarily attributable to the impact of the Company's Business Efficiency Program and integration programs. Specifically, the Company reduced its employee-related costs by $16.7 million and contract services by $7.9 million. For the year ended December 31, 2024 as compared to the year ended December 31, 2023, changes in foreign currencies relative to the U.S. dollar increased our research and development expenses by approximately $1.4 million.

[0000950170-25-031056:mdna:65]
Adtran Networks has arrangements with governmental entities for the purposes of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the years ended December 31, 2024 and 2023, the Company recognized $9.7 million and $5.2 million, respectively, as a reduction of research and development expense.

[0000950170-25-031056:mdna:66]
We expect to continue to incur research and development expenses in connection with our new and existing products. We continually evaluate new product opportunities and engage in significant research and product development efforts, which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0000950170-25-031056:mdna:67]
Asset Impairments

[0000950170-25-031056:mdna:68]
In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result, the Company recognized impairment charges of $17.4 million during the year ended December 31, 2022, primarily attributable to capitalized implementation costs for a cloud computing arrangement. There were no asset impairments recognized during the years ended December 31, 2024 and 2023. See Note 9 of the Notes to the Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:69]
Goodwill Impairment

[0000950170-25-031056:mdna:70]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer focus on inventory adjustments, triggered a quantitative impairment assessment for our reporting units for goodwill and long-lived assets. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit.

[0000950170-25-031056:mdna:71]
During the third quarter of 2023, qualitative factors, such as a decrease in the Company's market capitalization and long-term projections, triggered a quantitative impairment assessment for our reporting units. The Company determined upon its quantitative impairment assessment to recognize a $37.9 million non-cash goodwill impairment charge for the Services & Support reporting unit. There were no goodwill impairments recognized during the year ended December 31, 2022. See Note 8 of the Notes to the Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:72]
Interest and Dividend Income

[0000950170-25-031056:mdna:73]
Interest and dividend income increased by 30.7% from $2.3 million for the year ended December 31, 2023 to $3.1 million for the year ended December 31, 2024. The increase in interest and dividend income is primarily attributable to fluctuations in investment balances and an increase in the rate of return on those investments due to interest rate movements.

[0000950170-25-031056:mdna:74]
Interest Expense

[0000950170-25-031056:mdna:75]
Interest expense increased from $16.3 million for the year ended December 31, 2023 to $22.1 million for the year ended December 31, 2024. The increase in interest expense was primarily driven by higher amortization of debt issuance costs, as well as higher interest rates associated with the amendments of the Credit Agreement and higher average borrowings outstanding versus the twelve months ending December 31, 2023. See Note 11 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report and “Financing Activities” in “Liquidity and Capital Resources” below.

[0000950170-25-031056:mdna:76]
Net Investment Gain (Loss)

[0000950170-25-031056:mdna:77]
We recognized a net investment gain of $2.8 million and a gain of $3.6 million for the years ended December 31, 2023 and 2024, respectively. The fluctuations in our net investments were primarily attributable to market driven changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See “Investing Activities” in “Liquidity and Capital Resources” of this report and Note 1 and Note 4 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:78]
Other Income, net

[0000950170-25-031056:mdna:79]
Other income, net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, decreased from income of $1.3 million for the year ended December 31, 2023 to income of $0.2 million for the year ended December 31, 2024. See Note 10 of Notes to Consolidated Financial Statements included in Part II, Item 8 of the report for additional information on foreign exchange contracts.

[0000950170-25-031056:mdna:80]
Income Tax (Expense) Benefit

[0000950170-25-031056:mdna:81]
Our effective tax rate changed from an expense of 12.2%, for the year ended December 31, 2023 to an expense of 2.0% for the year ended December 31, 2024. The change in the effective tax rate for the year ended December 31, 2024, was driven primarily by non-deductible impairment charges and changes in our valuation allowance. See Note 12 of the Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:82]
Net Loss Attributable to ADTRAN Holdings, Inc.

[0000950170-25-031056:mdna:83]
As a result of the above factors, our net loss attributable to ADTRAN Holdings, Inc. increased from $266.3 million for the year ended December 31, 2023 to a net loss of $450.9 million for the year ended December 31, 2024. As a percentage of revenue, net loss was 23.2% for the year ended December 31, 2023 and net loss was 48.9% for the year ended December 31, 2024.

[0000950170-25-031056:mdna:84]
Liquidity and Capital Resources

[0000950170-25-031056:mdna:85]
Liquidity

[0000950170-25-031056:mdna:86]
We have historically financed our ongoing business with existing cash, investments and cash flow from operations; however, we have increasingly relied upon our credit arrangements to manage our working capital needs. We had a positive cash flow from operating activities of $103.1 million in the twelve months ended December 31, 2024.  We have used, and expect to continue to use, existing cash, credit arrangements and cash generated from operations for working capital and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures.

[0000950170-25-031056:mdna:87]
As of December 31, 2024, our cash on hand was $77.6 million of which $54.2 million was held by our foreign subsidiaries. The Company had access to $180.8 million on its Credit Facility for future borrowings; however, as of December 31, 2024, the Company was limited to additional borrowings of $56.1 million based on debt covenant compliance metrics. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax. As of December 31, 2023, our cash on hand was $87.2 million, of which $73.0 million was held by our foreign subsidiaries.

[0000950170-25-031056:mdna:88]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applied for the first time to the net loss generated in 2023.

[0000950170-25-031056:mdna:89]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.37% as of December 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €333.2 million or approximately $344.9 million, based on an exchange rate as of December 31, 2024 and reflecting interest accrued through December 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a procedural decision during 2025 that will likely be appealed. The date of a decision by the court on the merits of the case is uncertain, but it is unlikely that such decision will be rendered in 2025. Thereafter an expected appeal process will take a further 12-24 months to resolve.

[0000950170-25-031056:mdna:90]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million or $9.3 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024; therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for June 27, 2025, and therefore, the Annual Recurring Compensation will be due on July 2, 2025. During the twelve months ended December 31, 2024 and 2023, we accrued $9.8 million and $10.1 million, respectively, in Annual Recurring Compensation which is reflected as an increase to retained deficit.

[0000950170-25-031056:mdna:91]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”), which has since been amended four times. The Company had access to $180.8 million on its Credit Facility for future borrowings; however, as of December 31, 2024, the Company was limited to additional borrowings of $56.1 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x(or 4.0x to 3.5x during a Springing Covenant Period), and a Consolidated Fixed Charge Coverage Ratio of 1.25x.

[0000950170-25-031056:mdna:92]
As of December 31, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet the substantial majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the year ended December 31, 2024, approximately 831 thousand shares of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the year ended December 31, 2023, a total of 67 thousand shares of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €1.2 million or approximately $1.3 million based on an exchange rate as of December 31, 2023, were paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the publication of the final decision for at least another 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact that the Company expects to receive a procedural decision during 2025 that will likely be appealed and, while the date of a decision by the court on the merits of the case is uncertain, it is unlikely that such decision will be rendered in 2025 and an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

[0000950170-25-031056:mdna:93]
The Company experienced revenue declines in 2024. However, customers have started to replenish their inventories to meet increasing demand and we expect orders and billings to steadily increase in 2025. The Company is implementing plans to preserve cash liquidity to maintain compliance with the Company’s covenants in case of further we are impacted by customer inventory reduction initiatives and uncertain macroeconomic conditions. Additionally, the Company suspended dividend payments and effectuated a Business Efficiency Program. The Business Efficiency Program was substantially completed as of December 31, 2024, other than the Company's aim of selling its headquarters. The Company has determined that it is probable that the sale of our headquarters in Huntsville will occur within the next twelve months after December 31, 2024. We expect to use the proceeds of the sale to repay indebtedness. We may need to further reduce capital expenditure and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

[0000950170-25-031056:mdna:94]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo Credit Facility (described below), will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and ability to continue to comply with our debt covenants under the Credit Facility for at least the next twelve months, from the issuance of these Consolidated Financial Statements included in Part II, Item 8 of this Form 10-K. See Note 11 of Notes to Consolidated Financial Statements included in Part I, Item 8 of this report for additional information regarding the terms of the Wells Fargo Credit Agreement as amended.

[0000950170-25-031056:mdna:95]
Wells Fargo Credit Facility

[0000950170-25-031056:mdna:96]
On July 18, 2022, ADTRAN, Inc., as the borrower ("US Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (as amended from time to time, the “Credit Agreement”). Initially, the Credit Agreement allowed for revolving credit borrowings of up to $400.0 million in aggregate principal amount ($100.0 million of which is, subject to the restrictive covenants described below, available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below), as well as the $50.0 million delayed draw term loan facility described below. As of December 31, 2024, the aggregate principal amount was reduced to $374.0 million ($74.0 million of which is available to Adtran Networks as borrower pursuant to the Subline) due to a $26.0 million reduction on the Subline. The term of the delayed draw term loan facility expired on August 9, 2024.

[0000950170-25-031056:mdna:97]
On August 9, 2023, ("First Amendment Effective Date") the Company and ADTRAN, Inc. entered into a First Amendment to Credit Agreement (“First Amendment”).

[0000950170-25-031056:mdna:98]
The First Amendment, among other things, increased the available funding from $100.0 million to $400.0 million. In addition, a new $50.0 million delayed draw term loan facility (“DDTL”) was introduced, which (subject to certain conditions) was available for borrowing in the event that at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date was tendered (such event, a “Springing Covenant Event”). The First Amendment provided that, upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During the Springing Covenant Period, the Company’s leverage ratios are increased. Although the ability to borrow under the DDTL expired on August 9, 2024, the Springing Covenant Event and Springing Covenant Period remain in effect.

[0000950170-25-031056:mdna:99]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-25-031056:mdna:100]
On January 16, 2024 ("Second Amendment Effective Date"), the Company and ADTRAN, Inc. entered into a Second Amendment to Credit Agreement and First Amendment to Collateral Agreement ("Second Amendment"). The Second Amendment, among other things, introduced the Covenant Relief Period, which provided the Company with additional covenant headroom while imposing a minimum liquidity financial covenant from the end of the fourth quarter of 2023 to the end of the third quarter of 2024. The Covenant Relief Period ended on November 7, 2024.

[0000950170-25-031056:mdna:101]
On March 12, 2024, the Company and ADTRAN, Inc. entered into a Third Amendment to Credit Agreement ("Third Amendment"). The Third Amendment, among other things, amended the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024, and June 30, 2024.

[0000950170-25-031056:mdna:102]
On June 4, 2024, the Company, ADTRAN, Inc., and Adtran Networks entered into a Fourth Amendment to Credit Agreement ("Fourth Amendment"). The Fourth Amendment, among other things, created a new sublimit under the existing $400.0 million revolving commitments, in an aggregate amount of $100.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold is initially $75.0 million and may be lowered from time to time pursuant to the terms of the Fourth Amendment. The existing swing line sublimit and letter of credit sublimit under the Credit Agreement remained available to the US Borrower (and not to Adtran Networks) after giving effect to the Fourth Amendment. Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

[0000950170-25-031056:mdna:103]
As of December 31, 2024, Adtran’s borrowings under the revolving line of credit were $189.6 million, of which approximately $141.0 million were borrowed by ADTRAN, Inc. and $48.6 million were borrowed under the Subline by Adtran Networks. The credit facilities provided under the Credit Agreement mature in July 2027, but the US Borrower may request extensions subject to customary conditions. In addition, the US Borrower may utilize up to $50.0 million of the $374.0 million total revolving facility for the issuance of letters of credit. As of December 31, 2024, we had a total of $3.6 million in letters of credit under ADTRAN, Inc. outstanding under the Credit Agreement, leaving a net amount (after giving effect to the $189.6 million of outstanding borrowings described above) of $180.8 million available for future borrowings; however, as of December 31, 2024, the Company was limited to additional borrowings of $56.1 million based on debt covenant compliance metrics. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of December 31, 2024, the Company was in compliance with all covenants.

[0000950170-25-031056:mdna:104]
Revolving Line of Credit Interest Rate

[0000950170-25-031056:mdna:105]
All U.S. dollar borrowings under the revolving line of credit other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin), at the Company’s option, at a rate per annum equal to either (a) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period (as defined below), an applicable margin of 2.15% per annum), or (b) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.15% per annum).

[0000950170-25-031056:mdna:106]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.

[0000950170-25-031056:mdna:107]
“Adjusted Term SOFR” means Term SOFR for the applicable interest period plus 0.10% per annum. Adjusted Term SOFR is subject to a floor of 0.00% per annum.

[0000950170-25-031056:mdna:108]
All euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.25% per annum).

[0000950170-25-031056:mdna:109]
In addition, (x) if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-25-031056:mdna:110]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, is equal to 0.25%per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

[0000950170-25-031056:mdna:111]
The “Applicable Margin Interest Period” means the period commencing on the Second Amendment Effective Date and ending on the first date when each of the following conditions have been met: (a) the Covenant Relief Period has ended (b) since the Second Amendment Effective Date, the borrowers have repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million (c) the borrowers have reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million, and (d) the borrowers are in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-25-031056:mdna:112]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

[0000950170-25-031056:mdna:113]
Covenants Under the Credit Agreement

[0000950170-25-031056:mdna:114]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable):

[0000950170-25-031056:mdna:115]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Total Net Leverage Ratio may not exceed 5.00x.

[0000950170-25-031056:mdna:116]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

[0000950170-25-031056:mdna:117]
•
In the fiscal quarter in which a Springing Covenant Event occurs and the three consecutive quarterly test periods thereafter, (“Springing Covenant Period”), the following covenant levels:

[0000950170-25-031056:mdna:118]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

[0000950170-25-031056:mdna:119]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

[0000950170-25-031056:mdna:120]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

[0000950170-25-031056:mdna:121]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

[0000950170-25-031056:mdna:122]
•
If a Springing Covenant Period is not in effect, the Consolidated Senior Secured Net Leverage Ratio may not exceed 3.25x.

[0000950170-25-031056:mdna:123]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not exceed 1.25x.

[0000950170-25-031056:mdna:124]
•
During a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million.

[0000950170-25-031056:mdna:125]
All obligations under the Credit Agreement (including under the Subline) are guaranteed by ADTRAN, Inc., and certain subsidiaries of ADTRAN, Inc. (“Full Facility Guarantors”). To secure such guarantees, ADTRAN, Inc. and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and ADTRAN, Inc. has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries ("Subline Guarantors") have provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Adtran Networks has also granted security interests in favor of the Administrative Agent over substantially all of its tangible and intangible assets, to secure solely its obligations under the Subline. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

[0000950170-25-031056:mdna:126]
The Credit Agreement, as amended, contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.

[0000950170-25-031056:mdna:127]
Operating Activities

[0000950170-25-031056:mdna:128]
Net cash provided by operating activities of $103.1 million during the year ended December 31, 2024 increased by $148.7 million compared to $45.6 million of net cash used in during the year ended December 31, 2023. The increase was primarily due to the declining net loss for the twelve months ended December 31, 2024 and 2023, excluding the goodwill impairment charge of $292.6 million, as adjusted primarily for decreased depreciation and amortization, decreased deferred taxes and increased net cash inflows from working capital. Additional details related to our working capital and its drivers are discussed below.

[0000950170-25-031056:mdna:129]
Net accounts receivable decreased 17.8% from $216.4 million as of December 31, 2023 to $178.0 million as of December 31, 2024. There was an allowance for credit losses of $1.3 million and $0.4 million as of December 31, 2024 and December 31, 2023, respectively. The decrease in net accounts receivable was due primarily to a reduction in DSO.  Quarterly accounts receivable DSO decreased from 88 days as of December 31, 2023 to 67 days as of December 31, 2024. The decrease in DSO was primarily driven by customer and geographical mix of commercial terms.

[0000950170-25-031056:mdna:130]
Other receivables decreased 44.0% from $17.5 million as of December 31, 2023 to $9.8 million as of December 31, 2024. The decrease in other receivables was primarily attributable to a decrease in sales of raw materials.

[0000950170-25-031056:mdna:131]
Annual inventory turnover decreased from 2.07 turns as of December 31, 2023 to 1.88 turns as of December 31, 2024. Inventory decreased 25.7% from $362.3 million as of December 31, 2023 to $269.3 million as of December 31, 2024. The decrease in inventory was primarily due to steps taken in with our Business Efficiency Program to improve working capital, a reduction in component purchases due to improved lead time, utilization of buffer stock and a $4.1 million write down of inventory due to a restructuring discontinuation of certain product lines within our Network Solutions segment. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory for customer demand and improve working capital.

[0000950170-25-031056:mdna:132]
Accounts payable increased 4.6% from $162.9 million as of December 31, 2023 to $170.5 million as of December 31, 2024. The increase in accounts payable was primarily due to the timing of the receipt of inventory, supplies and services. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-25-031056:mdna:133]
Investing Activities

[0000950170-25-031056:mdna:134]
Capital expenditures, including intangibles totaled approximately $63.1 million and $43.1 million for the years ended December 31, 2024 and 2023, respectively. These expenditures were primarily used to purchase software, computer hardware, manufacturing and test equipment, building improvements and developed technologies. The increase in capital expenditures is primarily attributable to an increase in expenditures related to developed technology.

[0000950170-25-031056:mdna:135]
Our long-term investments increased 15.6% from $27.7 million as of December 31, 2023 to $32.1 million as of December 31, 2024.  Our investments include various marketable equity securities classified as long-term investments with a fair market value of $1.1 million and $0.9 million, as of December 31, 2024 and 2023, respectively. Long-term investments as of December 31, 2024 and 2023 also included $31.0 million and $26.8 million, respectively, related to our deferred compensation plan. See Note 4 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:136]
59

[0000950170-25-031056:mdna:137]
Financing Activities

[0000950170-25-031056:mdna:138]
Dividends

[0000950170-25-031056:mdna:139]
During 2023 we paid stockholder dividends totaling $21.2 million. On November 6, 2023, the Board of Directors suspended the Company’s quarterly cash dividend in order to reduce debt and interest expense and support the Company's capital efficiency program. We consequently did not pay any dividends during the twelve months ended December 31, 2024. The payment of any future dividends will be at the discretion of the Board of Directors and will depend on the Company’s financial condition, results of operations, capital requirements, and any other factors deemed relevant by the Board of Directors; however, the Wells Fargo Credit Agreement currently does not allow for the payment of dividends to stockholders. For addition information, see Note 18 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report and Liquidity & Capital Resources above. The following table shows dividends per common share paid to our stockholders in each quarter of 2024 and 2023:

[0000950170-25-031056:mdna:140]
| Dividends per Common Share |  |
|  |  | 2024 |  |  | 2023 |  |
| First Quarter |  | $ | - |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | - |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | - |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | - |  |  | $ | - |  |

[0000950170-25-031056:mdna:141]
Stock Repurchase Program

[0000950170-25-031056:mdna:142]
The Company did not repurchase any stock during the years ended December 31, 2024 and 2023, and there currently is no authorized stock repurchase plan.

[0000950170-25-031056:mdna:143]
Stock Option Exercises

[0000950170-25-031056:mdna:144]
To accommodate employee stock option exercises, the Company issued 0.1 million and 23 thousand shares of common stock which resulted in proceeds of $0.8 million and $0.2 million during the years ended December 31, 2024 and 2023, respectively. Additionally, to accommodate Adtran Networks stock option exercises, Adtran Networks issued 0.1 million of Adtran Networks common stock which resulted in proceeds of $0.4 million, during the year ended December 31, 2023. No Adtran Networks stock options were exercised during the year ended December 31, 2024.

[0000950170-25-031056:mdna:145]
Employee Pension Plan

[0000950170-25-031056:mdna:146]
We maintain defined benefit pension plans covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Details regarding the pension plans are set forth below.

[0000950170-25-031056:mdna:147]
•
In Germany, there are two defined benefit pension plans and two defined contribution plans. These plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service and salary. The defined benefit plans are financed by contributions paid by the Company and the defined contribution plans are financed by contributions paid by the participants.

[0000950170-25-031056:mdna:148]
•
In Switzerland, there are two defined benefit pension plans. Both plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service, salary and on a participant's old age account. The plans are financed by contributions paid by the participants and by the Company.

[0000950170-25-031056:mdna:149]
•
In Italy, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay-as-you-go basis. Employees receive their pension payments as a function of salary, inflation and a notional account.

[0000950170-25-031056:mdna:150]
•
In Israel, there is a defined benefit plan that provides benefits in the event of a participant being dismissed involuntarily, retirement or death. The plan's benefits are based on the higher of the severance benefit required by law or the cash surrender value of the severance benefit component of any qualifying insurance policy or long-term employee benefit fund that is registered in the participant's name. The plan is financed by contributions paid by the Company.

[0000950170-25-031056:mdna:151]
•
In India, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay-as-you-go basis.

[0000950170-25-031056:mdna:152]
Our defined benefit plan assets consist of a balanced portfolio of equity funds, bond funds, emerging market funds, real estate funds and balanced funds. Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner

[0000950170-25-031056:mdna:153]
necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. The objectives of our investment policy are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies. The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. At December 31, 2024, the estimated fair market value of our defined benefit pension plans' assets decreased to $54.5 million from $55.2 million at December 31, 2023.

[0000950170-25-031056:mdna:154]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in euro currency with durations close to the duration of our pension obligations. The projected benefit obligation for our defined benefit pension plans was $63.3 million and $67.9 million as of December 31, 2024 and 2023, respectively.

[0000950170-25-031056:mdna:155]
The components of net periodic pension cost, other than the service cost component, are included in other income, net in the Consolidated Statements of Loss. The components of net periodic pension cost and amounts recognized in other comprehensive income (loss) for the years ended December 31, 2024 and 2023 were $0.3 million and ($3.9) million, respectively.

[0000950170-25-031056:mdna:156]
Actuarial gains and losses are recorded in accumulated other comprehensive loss. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants. We estimate that less than $0.1 million will be amortized from accumulated other comprehensive income into net periodic pension cost in 2025 for the net actuarial loss. The net actuarial loss recognized in accumulated other comprehensive loss as of December 31, 2024 and 2023 was $1.0 million and $2.5 million, respectively. See Note 14 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:157]
Off-Balance Sheet Arrangements

[0000950170-25-031056:mdna:158]
We have exposure to credit losses from off-balance sheet exposures used to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of December 31, 2024. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 18 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:159]
Cash Requirements

[0000950170-25-031056:mdna:160]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of December 31, 2024, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA and currency hedging arrangements, which are discussed below). Other than operating lease obligations, the cash requirements table excludes interest payments.

[0000950170-25-031056:mdna:161]
| (In thousands) |  | Total |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | 2028 |  |  | 2029 |  |  | Thereafter |  |
| Wells Fargo credit agreement(1) |  | $ | 189,576 |  |  | $ | — |  |  | $ | — |  |  | $ | 189,576 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Purchase obligations(2) |  |  | 202,478 |  |  |  | 197,408 |  |  |  | 4,746 |  |  |  | 199 |  |  |  | 125 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations(3) |  |  | 41,063 |  |  |  | 8,829 |  |  |  | 7,550 |  |  |  | 6,498 |  |  |  | 4,980 |  |  |  | 2,925 |  |  |  | 10,281 |  |
| Totals |  | $ | 433,117 |  |  | $ | 206,237 |  |  | $ | 12,296 |  |  | $ | 196,273 |  |  | $ | 5,105 |  |  | $ | 2,925 |  |  | $ | 10,281 |  |

[0000950170-25-031056:mdna:162]
(1) See description below.

[0000950170-25-031056:mdna:163]
(2) We have purchase obligations related to open purchase orders to our contract manufacturers, ODMs, component suppliers, service partners and other vendors. The settlement of our purchase obligations will occur at various dates beginning in 2025 and going through 2028. See Note 18 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report for more information.

[0000950170-25-031056:mdna:164]
(3) We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Our operating leases had remaining lease terms ranging from 1 month to 167 months as of December 31, 2024.

[0000950170-25-031056:mdna:165]
Stock Repurchase Program

[0000950170-25-031056:mdna:166]
There were no stock repurchases during the years ended December 31, 2024 and 2023, and there currently is no authorized stock repurchase plan.

[0000950170-25-031056:mdna:167]
Wells Fargo Credit Agreement

[0000950170-25-031056:mdna:168]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into the Credit Agreement with the Administrative Agent and the other lenders named therein. The Credit Agreement was subsequently amended on August 9, 2023, January 16, 2024, March 12, 2024, and June 4, 2024. As of December 31, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $189.6 million. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. See Note 11 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report and “Liquidity and Capital Resources” in Part I, Item 2 of this report for additional information.

[0000950170-25-031056:mdna:169]
Nord/LB Revolving Line of Credit

[0000950170-25-031056:mdna:170]
On March 29, 2023, Adtran Networks entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bore interest of Euro Short Term Rate plus 1.94%. The line of credit had a perpetual term that could be terminated by the Company or Nord/LB at any time. As of December 31, 2023, Adtran Networks repaid the outstanding borrowings and terminated the Nord/LB Revolving Line of Credit.

[0000950170-25-031056:mdna:171]
Prior Nord/LB Revolving Line of Credit

[0000950170-25-031056:mdna:172]
On August 8, 2022, Adtran Networks entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bore interest of Euro Short Term Rate plus 1.4% and matured in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings and terminated the Nord/LB revolving line of credit.

[0000950170-25-031056:mdna:173]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-25-031056:mdna:174]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company repaid the outstanding borrowings and terminated the syndicated credit agreement working capital line of credit.

[0000950170-25-031056:mdna:175]
DZ Bank Revolving Line of Credit

[0000950170-25-031056:mdna:176]
In the fourth quarter of 2022, Adtran Networks entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings and terminated the DZ Bank revolving line of credit.

[0000950170-25-031056:mdna:177]
Syndicated Credit Agreement Note Payable

[0000950170-25-031056:mdna:178]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. On January 31, 2023, the Company repaid the outstanding borrowings and terminated the syndicated credit agreement note payable.

[0000950170-25-031056:mdna:179]
Currency Hedging Arrangements

[0000950170-25-031056:mdna:180]
On November 3, 2022, the Company entered into a euro/U.S. dollar forward contract arrangement (the "Initial Forward") with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which was governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enabling the Company to convert a portion of its euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million for U.S. dollars at a daily fixed forward rate ranging from EUR/USD 0.98286 to 1.03290. The aggregate amount of €160.0 million was divided into eight quarterly tranches of €20.0 million, which commenced in the fourth quarter of 2022. During the twelve months ended December 31, 2024, the Company settled four €20.0 million forward contract tranches.

[0000950170-25-031056:mdna:181]
On March 21, 2023, the Company entered into a euro/U.S. dollar forward contract arrangement (the “Forward”) with the Hedge Counterparty. Under the Forward, which was governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company exchanged an aggregate notional amount of €160.0 million for U.S. dollars at an average rate of EUR/USD 1.085. During the twelve months ended December 31, 2024, the Company settled four $20.0 million forward contract tranches. As of December 31, 2024, both the Initial Forward and Forward have fully matured and are no longer outstanding.

[0000950170-25-031056:mdna:182]
Receivables Purchase Arrangements

[0000950170-25-031056:mdna:183]
On July 1, 2024, the Company entered into receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of December 31, 2024, totaled $18.3 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets on the Consolidated Balance Sheets. The cost of the Factoring Agreement is included in interest expense in the Consolidated Statements of Loss and totaled $0.6 million for the year ended December 31, 2024. Costs of a previous receivables purchase agreement, which are included in interest expense in the Consolidated Statements of Loss totaled $0.9 million for the year ended December 31, 2023.

[0000950170-25-031056:mdna:184]
Domination and Profit and Loss Transfer Agreement

[0000950170-25-031056:mdna:185]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE, as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-25-031056:mdna:186]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applied for the first time to the net loss generated in 2023.

[0000950170-25-031056:mdna:187]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.37% as of December 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €333.2 million or approximately $344.9 million, based on an exchange rate as of December 31, 2024 and reflecting interest accrued through December 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a procedural decision during 2025 that will likely be appealed. The date of a decision by the court on the merits of the case is uncertain, but it is unlikely that such decision will be rendered in 2025. Thereafter an expected appeal process will take a further 12-24 months to resolve.

[0000950170-25-031056:mdna:188]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million or $9.3 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for June 27, 2025, and therefore, the Annual Recurring Compensation will be due on July 2, 2025. During the year ended December 31, 2024 and 2023, we accrued $9.8 million and $10.1 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Consolidated Balance Sheets.

[0000950170-25-031056:mdna:189]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the year ended December 31, 2024, approximately 831 thousand shares of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the year ended December 31, 2023, a total of 67 thousand shares of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €1.2 million or approximately $1.3 million based on an exchange rate as of December 31, 2023, were paid to Adtran Networks shareholders.

[0000950170-25-031056:mdna:190]
We currently hold 34,856,559 no-par value bearer shares of Adtran Networks, representing 67.0% of Adtran Networks outstanding shares as of February 27, 2025.

[0000950170-25-031056:mdna:191]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which incorporated by reference to Exhibit 10.5 of this Annual Report on Form 10-K.

[0000950170-25-031056:mdna:192]
Business Efficiency Program

[0000950170-25-031056:mdna:193]
During the fourth quarter of 2023, the Company initiated a Business Efficiency Program designed to optimize the assets, business processes, and information technology systems of the Company in relation to the Business Combination with Adtran Networks. The Business Efficiency Program included expenses specifically associated with achieving run-rate synergies as well as Business Efficiency Program expenses described below. Other than the Company's stated air of selling its headquarters, the Business Efficiency Program was substantially complete as of December 31, 2024. See Note 20 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:194]
During the years ended December 31, 2024 and 2023, we recognized $44.7 million and $25.1 million of costs relating to the Business Efficiency Program, respectively. Future cash payments include severance costs, outplacement fees and site consolidation that are anticipated to be approximately $10.3 million.

[0000950170-25-031056:mdna:195]
Business Combination Integration Costs

[0000950170-25-031056:mdna:196]
During the years ended December 31, 2024 and 2023, we recognized $1.9 million and $4.9 million of integration costs related to the Business Combination, respectively, that are included in selling, general and administrative expenses, research & development expenses and cost of revenue in the Condensed Consolidated Statement of Loss.

[0000950170-25-031056:mdna:197]
Other Cash Requirements

[0000950170-25-031056:mdna:198]
During the year ended December 31, 2024, other than the Exit Compensation payments, Annual Recurring Compensation under the DPLTA, restructuring costs and increased debt service costs, there have been no other material changes in cash requirements from those discussed in the 2023 Form 10-K and our cash requirements table shown in Liquidity and Capital Resources above.

[0000950170-25-031056:mdna:199]
Performance Bonds

[0000950170-25-031056:mdna:200]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2024 and 2023, we had commitments related to these bonds totaling $15.7 million and $10.8 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract; the probability of which we believe is remote.

[0000950170-25-031056:mdna:201]
Critical Accounting Policies and Estimates

[0000950170-25-031056:mdna:202]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of the Notes to Consolidated Financial Statements included in Part II, Item 8 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0000950170-25-031056:mdna:203]
Revenue

[0000950170-25-031056:mdna:204]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees collected are recorded as revenue and the related cost is included in cost of revenue. Revenue, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Incremental costs of obtaining a contract, that are recoverable, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to account for shipping fees paid as a cost of fulfilling the related contract. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0000950170-25-031056:mdna:205]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0000950170-25-031056:mdna:206]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in Service Provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware revenue.

[0000950170-25-031056:mdna:207]
Hardware and Software Revenue

[0000950170-25-031056:mdna:208]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenue from software license sales is recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time products are delivered.

[0000950170-25-031056:mdna:209]
Services & Support Segment - Includes a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services to complement our Network Solutions segment.

[0000950170-25-031056:mdna:210]
Maintenance Revenue

[0000950170-25-031056:mdna:211]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenue, when applicable, is recorded in unearned revenue and non-current unearned revenue. The total balance of our unearned revenue was $74.8 million and $71.8 million as of December 31, 2024 and 2023, respectively.

[0000950170-25-031056:mdna:212]
Network Implementation Revenue

[0000950170-25-031056:mdna:213]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheets. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0000950170-25-031056:mdna:214]
Receivables Purchase Agreement

[0000950170-25-031056:mdna:215]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. These transactions are accounted for in accordance with ASC Topic 860 and result in a reduction in accounts receivable because the Factoring Agreement transfers effective control over, and risk related to the receivables to the buyers. Trade accounts receivables balances sold are removed from the Consolidated Balance Sheets and cash received is reflected as cash flows provided by (used in) operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest expense on the Consolidated Statements of Loss. On each sale date, the Factor retains from the sale price a default reserve, up to a required balance, which is held by the Factor in a reserve account and pledged to the Company. The Factor is entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account is included in other assets on the Consolidated Balance Sheets.

[0000950170-25-031056:mdna:216]
Previous Receivables Purchase Agreement

[0000950170-25-031056:mdna:217]
On December 19, 2023, the Company entered into a factoring agreement with a third-party financial institution to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The factoring agreement qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company was considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retained a residual claim on reserves related to the factored receivables. The receivables factored were carried in accounts receivable, less allowance for credit losses on the Consolidated Balance Sheets, the secured borrowings were carried on the Company’s Consolidated Balance Sheets as a current liability, in accounts payable, proceeds and repayments of the secured borrowings are reflected as cash flows (used in) provided by financing activities in the Consolidated Statements of Cash Flows and program fees are recorded in interest expense in the Company’s Consolidated Statements of Loss. The short-term liability classification of the secured borrowings was based on the estimated timing of the collection of the accounts receivable which were expected to be received within 12 months. The receivables purchase agreement was terminated on July 1, 2024 and there were no secured borrowings under this agreement as of December 31, 2024. See Note 2 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:218]
Inventory

[0000950170-25-031056:mdna:219]
We carry our inventory at the lower of cost and net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor, and manufacturing overhead are used to value inventory and are updated at least quarterly. Most variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. If actual trends and market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs.

[0000950170-25-031056:mdna:220]
Stock-Based Compensation

[0000950170-25-031056:mdna:221]
For purposes of determining the estimated fair value of market-based PSU awards on the date of grant, the Monte Carlo Simulation valuation method is used. These PSUs are subject to a market condition based on the relative total stockholder return of Adtran against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of performance-based PSUs, RSUs and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. Compensation expense related to unvested performance-based PSUs is recognized over the requisite service period of two to three years as the achievement of the performance obligation becomes probable. For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable, single measure of the fair value of our stock option awards. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. As of December 31, 2024, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $10.7 million.

[0000950170-25-031056:mdna:222]
Pursuant to the Business Combination, which closed on July 15, 2022, Adtran Networks stock option holders were entitled to have their Adtran Networks stock options assumed by ADTRAN Holdings (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings. The maximum number of shares of ADTRAN Holdings stock potentially issuable upon such assumption was 2.3 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.1 million shares of ADTRAN Holdings stock were subject to assumed Adtran Networks options. The determination of the fair value of stock options assumed by ADTRAN Holdings was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors. As of December 31, 2024, total unrecognized compensation expense related to the non-vested portion of stock options was approximately $3.2 million.

[0000950170-25-031056:mdna:223]
Assets Held for Sale

[0000950170-25-031056:mdna:224]
An asset is considered to be held for sale when all the following criteria are met: (i) management commits to a plan to sell the asset; (ii) the asset is available for immediate sale in its present condition; (iii) actions required to complete the sale of the asset have been initiated; (iv) sale of the asset is probable and the completed sale is expected to occur within one year; (v) it is unlikely that the disposal plan will be significantly modified; and (vi) the asset is actively being marketed for sale at a price that is reasonable given its current market value.

[0000950170-25-031056:mdna:225]
The Company records assets held for sale at the lower of their carrying value or fair value. The total carrying value of assets held for sale was $11.9 million as of December 31, 2024 and is separately recorded on the balance sheet.

[0000950170-25-031056:mdna:226]
Goodwill

[0000950170-25-031056:mdna:227]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company’s annual impairment assessment is done at the reporting unit level, which we determined are generally the same as our operating segments, which are identified in Note 16 to the Consolidated Financial Statements. We review goodwill for impairment annually during the fourth quarter and also test for impairment between annual tests if an event occurs or circumstances change that would more likely than not reduce the fair value of our reporting units below their carrying amount. Such events and circumstances may include among others: a significant adverse change in legal factors or in the general business climate; significant decline in our stock price and market capitalization; unanticipated competition; the testing for recoverability of a significant asset within the reporting unit; and an adverse action or assessment by a regulator. Any adverse change in these factors could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000950170-25-031056:mdna:228]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of each reporting unit using a combination of an income approach and a market approach. The significant inputs and assumptions used in the determination of the fair value of our reporting units based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to cash flow projections, discount rate, peer group determination and market multiple selection. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the first quarter of 2024.

[0000950170-25-031056:mdna:229]
The Company’s annual impairment test date is October 1, 2024. Based on our analysis, management concluded that there was no impairment of goodwill as of that date. Between the annual impairment date of October 1, 2024 and year-end December 31, 2024, there were no additional triggering events.

[0000950170-25-031056:mdna:230]
During 2023, the Company experienced decreased market capitalization and long-term projections. Therefore, an interim impairment test over goodwill was performed as of September 30, 2023. The Company determined the fair value of each reporting unit using a combination of an income approach and a market approach. Management’s determination of the fair value of our reporting units, based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to cash flow projections, discount rate, peer group determination and market multiple selection. It was determined that the decreases in projected future cash flows, discount rates, overall macroeconomic conditions, as well as the decrease in our market capitalization applied in the valuation, were required to align with market-based assumptions and company-specific risk, which resulted in lower fair values of the Services & Support reporting unit. As a result of the interim assessment, the Company recorded a goodwill impairment charge of $37.9 million as its estimated fair value was less than its book value on that date. No other goodwill impairment charges were recorded during 2023.

[0000950170-25-031056:mdna:231]
No goodwill impairment charge was recorded in 2022 as a result of the Company’s internal assessment.

[0000950170-25-031056:mdna:232]
The balance of our goodwill was $52.9 million and $353.4 million as of December 31, 2024 and 2023, respectively.

[0000950170-25-031056:mdna:233]
Intangible Assets

[0000950170-25-031056:mdna:234]
Purchased intangible assets with finite lives are carried at cost less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets.

[0000950170-25-031056:mdna:235]
The balance of our intangible assets was $306.1 million and $337.4 million as of December 31, 2024 and 2023, respectively.

[0000950170-25-031056:mdna:236]
Impairment of Long-Lived Assets and Intangibles

[0000950170-25-031056:mdna:237]
Long-lived assets, such as property, plant and equipment, right of use lease assets and purchased intangibles subject to amortization, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of an asset to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset exceeds its estimated future cash flows, an impairment charge is recognized by the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group.

[0000950170-25-031056:mdna:238]
During the first quarter of 2024, factors triggered a quantitative impairment assessment for the Network Solutions asset group. The long-lived assets associated with the Network Solutions asset group was $358.6 million as of  December 31, 2024

[0000950170-25-031056:mdna:239]
There were no impairment losses for long-lived assets and intangible assets during the years ended December 31, 2024, 2023 and 2022.

[0000950170-25-031056:mdna:240]
Income Taxes

[0000950170-25-031056:mdna:241]
We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. We continually review the adequacy of our valuation allowance and recognize the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes. During the fourth quarter of 2023, after considering all quantitative and qualitative evidence, including our cumulative loss position, we have determined that the negative evidence outweighs the positive evidence and have concluded that it is not more likely than not that our U.S. federal and certain other state deferred tax assets were realizable for one of the consolidated filing groups. As a result, we recorded a valuation allowance against those assets and continue to maintain the valuation allowance through 2024. Additional valuation allowance was recorded against certain deferred tax assets on our foreign entities as not more likely than not realizable. However, the amount of deferred tax assets considered realizable could be adjusted and valuation allowance released in future periods in the event that sufficient positive evidence is present to support a conclusion that it is more likely than not that all or a portion of our domestic and foreign deferred tax assets will be realized.

[0000950170-25-031056:mdna:242]
In determining whether an uncertain tax position exists, the Company determines, based solely on its technical merits, whether the tax position is more likely than not to be sustained upon examination, and if so, a tax benefit is measured on a cumulative probability basis that is more likely than not to be realized upon the ultimate settlement. The Company recognizes interest and penalties related to unrecognized tax benefits through interest expense and income tax expense, respectively.

[0000950170-25-031056:mdna:243]
Pension Benefit Plan Obligations

[0000950170-25-031056:mdna:244]
Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $8.8 million and $12.7 million at December 31, 2024 and December 31, 2023, respectively. This liability is included in non-current pension liability, accrued wages and benefits and other non-current assets in the accompanying Consolidated Balance Sheets.

[0000950170-25-031056:mdna:245]
Lease Obligations

[0000950170-25-031056:mdna:246]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain potential embedded leases. These other contracts are specifically reviewed to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease. Some of our leases include options to renew. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. The exercise of lease renewal options is at our sole discretion. The depreciable life of leased assets and leasehold improvements are limited by the expected lease term. Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the

[0000950170-25-031056:mdna:247]
lease term. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. Our lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-25-031056:mdna:248]
Business Combinations

[0000950170-25-031056:mdna:249]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition subject to purchase accounting adjustments. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets and liabilities assumed or acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired and liabilities assumed exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying Consolidated Statements of Loss since their dates of acquisition. Costs incurred to complete the Business Combination, such as legal, accounting or other professional fees, are charged to selling, general and administrative expenses as incurred.

[0000950170-25-031056:mdna:250]
Recently Issued Accounting Pronouncements

[0000950170-25-031056:mdna:251]
For a discussion of recently issued accounting pronouncements, see Note 1 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:mdna:252]
69
