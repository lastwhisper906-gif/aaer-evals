# ADTN notes — 0000950170-25-031056


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-25-031056:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0000950170-25-031056:notes:2]
Portions of the Proxy Statement for the registrant's 2025 Annual Meeting of Stockholders are incorporated herein by reference into Part III of this report to the extent described in Part III.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000950170-25-031056:notes:3]
Risk Management and Strategy

[0000950170-25-031056:notes:4]
We recognize the importance of establishing governance and oversight over cybersecurity risks, and we have implemented mechanisms, controls, technologies, and processes designed to help us assess, identify, and manage these risks.

[0000950170-25-031056:notes:5]
The landscape of cyber threats is constantly evolving, making it increasingly challenging to effectively defend against them or implement sufficient preventative measures. We have observed a rise in the volume, frequency, and sophistication of cyber-attacks. There can be no assurance that our controls and procedures in place to monitor and mitigate the risks of cyber threats, including the remediation of critical information security and software vulnerabilities, will be sufficient and/or timely and that we will not suffer material losses or consequences in the future. Additionally, while we have in place insurance coverage designed to address certain aspects of cyber risks, such insurance coverage may be insufficient to cover all insured losses or all types of claims that may arise. For more information regarding the cybersecurity risks that we face, see “Risks Related to Our Control Environment – Breaches of our information systems and cyberattacks could compromise our intellectual property and cause significant damage to our business and reputation” included as part of our risk factor disclosures in Part I, Item 1A of this report.

[0000950170-25-031056:notes:6]
We have adopted and continue to maintain a cybersecurity risk management program that implements various controls, technology, and procedures for the evaluation, identification, and handling of significant cybersecurity risks that could impact the confidentiality, integrity, or availability of our information systems.

[0000950170-25-031056:notes:7]
Our practices include providing ongoing security awareness training for our global workforce, conducting ransomware and phishing simulations, deploying advanced tools for detecting and analyzing anomalous network activities, and implementing robust containment and incident response procedures. We leverage threat intelligence from our security vendors, as well as from trusted sources such as CISA and the FBI, to enhance our defenses and stay ahead of emerging threats. Additionally, we are committed to staying aligned with the latest industry standards and actively participating in industry forums to exchange insights and proactively address evolving cybersecurity challenges.

[0000950170-25-031056:notes:8]
A critical component of our cybersecurity strategy is the integration of a third-party Security Operations Center support, which monitors our global network environment on a 24/7/365 basis, and is designed to rapidly identify and respond to threats. This program monitors both internally detected and externally reported vulnerabilities that could impact our products, which are then evaluated for their cybersecurity implications according to Company protocols. We also utilize third-party service providers as part of our cybersecurity risk management program and maintain a framework for managing cybersecurity risks presented by our third-party Service Providers. This framework governs the third party’s security management system and mandates that the program (i) adhere to certain information handling and asset management protocols and (ii) promptly notify us of any cybersecurity incidents that impact its systems.

[0000950170-25-031056:notes:9]
Our enterprise risk management ("ERM") framework is designed to systematically integrate the assessment, identification, and handling of cybersecurity-related risks into our broader risk management strategy. This process involves an annual evaluation of the spectrum of risks facing the enterprise, including those related to cybersecurity. When elevated cybersecurity risks are detected, designated risk owners are tasked with formulating and overseeing the execution of targeted mitigation strategies.

[0000950170-25-031056:notes:10]
We did not experience any material losses relating to cybersecurity threats or incidents for the year ended December 31, 2024. We are not aware of any risks from cybersecurity threats, including as a result of any previous cybersecurity incidents, that have materially affected us or are reasonably likely to materially affect us, including our business strategy, results of operations, or financial condition.

[0000950170-25-031056:notes:11]
Governance

[0000950170-25-031056:notes:12]
Adtran maintains a cybersecurity governance structure led by its Information Security Management "ISM" team, which oversees the Company's cybersecurity risk management efforts. The ISM team ensures that appropriate controls are in place to protect Adtran’s corporate assets, ensuring their availability, confidentiality, and integrity. This risk management approach informs strategic decision-making, resource allocation, and oversight mechanisms. The governance of Adtran’s cybersecurity program is ultimately the responsibility of the Board of Directors, with the Audit Committee providing critical oversight through regular reviews and periodic updates at least quarterly, or more frequently as needed.

[0000950170-25-031056:notes:13]
The Company’s cybersecurity leadership includes the Chief Information Officer "CIO"/Chief Information Security Officer "CISO", who is responsible for governing and protecting Adtran’s information assets, leading the cybersecurity strategy, and reporting directly to the Chief Executive Officer. The CIO/CISO ensures compliance with ISO 27001, oversees annual external audits, and leads the monthly Information Technology Cybersecurity meetings and the Data Privacy Committee. Since joining Adtran in November 2018, the CIO/CISO has leveraged extensive leadership experience to enhance the company’s security posture. Additionally, the Chief Technology Officer ("CTO"), who joined the company in January 2023 following the Business Combination, plays a key role in product

[0000950170-25-031056:notes:14]
security oversight, drawing on prior experience as Adtran Networks' CTO leading their product management and advanced technology teams. Our CTO helps oversee our product security programs.

[0000950170-25-031056:notes:15]
Adtran employs a comprehensive cybersecurity program that integrates proactive risk management strategies to identify, assess, and mitigate cybersecurity threats. Key elements of this program include an Incident Response Plan to manage and resolve security incidents, regular vulnerability scanning to identify and address potential risks, and a structured patch management process to ensure timely remediation of security vulnerabilities. Additionally, the Company has established a dedicated Product Security Incident Response Team (PSIRT) to assess and respond to product security vulnerabilities. To strengthen its security culture, Adtran implements a Cybersecurity Testing and Awareness Program, requiring all employees to participate in quarterly cybersecurity assessments and complete mandatory annual training. This initiative ensures that employees remain well-informed about emerging cybersecurity threats and best practices, reinforcing a proactive security mindset across the organization.

[0000950170-25-031056:notes:16]
Cybersecurity risk management is integrated into Adtran’s Enterprise Risk Management "ERM" program, in order to provide for continuous oversight and executive engagement. The ERM program undergoes quarterly executive reviews and annual assessments by the Board of Directors, and the Board receives regular briefings on cybersecurity risks, regulatory compliance, and security program updates from management. Key policies include the Information Security Program, which establishes governance principles across facilities, employees, business partners, and customers; the Cybersecurity Framework, which ensures compliance with ISO 27001 and industry standards; employee handbooks outlining security best practices; and the Incident Response Plan, which includes a material impact assessment workflow to support timely regulatory disclosures.

[0000950170-25-031056:notes:17]
For additional discussion of risks associated with cybersecurity, see “Risk Factors – Breaches of our information systems and cyberattacks could compromise our intellectual property and cause significant damage to our business and reputation.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-25-031056:notes:18]
GENERAL

[0000950170-25-031056:notes:19]
ADTRAN Holdings, Inc. (“Adtran” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-25-031056:notes:20]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks SE (“Adtran Networks”). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer, especially upon the convergence of solutions at the network edge.

[0000950170-25-031056:notes:21]
Liquidity, Domination and Profit and Loss Transfer Agreement and Credit Facility

[0000950170-25-031056:notes:22]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE ("Adtran Networks"), as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-25-031056:notes:23]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applied for the first time to the net loss generated in 2023.

[0000950170-25-031056:notes:24]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.37% as of December 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €333.2 million or approximately $344.9 million, based on an exchange rate as of December 31, 2024 and reflecting interest accrued through December 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a procedural decision during 2025 that will likely be appealed. The date of a decision by the court on the merits of the case is uncertain, but it is unlikely that such decision will be rendered in 2025. Thereafter an expected appeal process will take a further 12-24 months to resolve.

[0000950170-25-031056:notes:25]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million (or $9.3 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders as of December 31, 2024 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran

[0000950170-25-031056:notes:26]
Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for June 27, 2025 and, therefore, the Annual Recurring Compensation will be due on July 2, 2025. During the year ended December 31, 2024 and 2023, we accrued $9.8 million and $10.1 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Consolidated Balance Sheets.

[0000950170-25-031056:notes:27]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the year ended December 31, 2024, approximately 831 thousand shares of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the year ended December 31, 2023, a total of 67 thousand shares of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €1.2 million or approximately $1.3 million based on an exchange rate as of December 31, 2023, were paid to Adtran Networks shareholders.

[0000950170-25-031056:notes:28]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. The Company had access to $180.8 million on its Credit Facility for future borrowings; however, as of December 31 2024, the Company was limited to additional borrowings of $56.1 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x.  See Note 11, Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

[0000950170-25-031056:notes:29]
As of December 31, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. While the Company did experience $17.4 million of redemptions during  2024, we believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the publication of the final decision for at least another 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact that the Company expects to receive a procedural decision during 2025 that will likely be appealed and, while the date of a decision by the court on the merits of the case is uncertain, it is unlikely that such decision will be rendered in 2025 and an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

[0000950170-25-031056:notes:30]
The Company experienced revenue declines in 2024. The Company is implementing plans to preserve cash liquidity to maintain compliance with the Company’s covenants in case of further impacts related to customer inventory reduction initiatives and uncertain macroeconomic conditions. Additionally, the Company suspended dividend payments and effectuated a Business Efficiency Program. The Business Efficiency Program was substantially completed as of December 31, 2024, other than the Company's aim of selling its headquarters. The Company has determined that it is probable that the sale of our headquarters in Huntsville will occur within the next twelve months after December 31, 2024. We may need to further reduce capital expenditure and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our debt covenants.

[0000950170-25-031056:notes:31]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and to support our ability to continue to comply with our debt covenants under the Credit Facility, for at least the next twelve months, from the issuance of these financial statements. See Note 11, Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo Credit agreement.

[0000950170-25-031056:notes:32]
Note 1 - Summary Of Significant Accounting Policies

[0000950170-25-031056:notes:33]
Basis of Presentation

[0000950170-25-031056:notes:34]
The accompanying Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the U.S. (“U.S. GAAP”) and include the financial position, results of operations, comprehensive (loss) income, changes in equity and cash flows of Adtran and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000950170-25-031056:notes:35]
Revision of Previously Issued Consolidated Financial Statements

[0000950170-25-031056:notes:36]
Following the third quarter of 2024, the Company identified errors primarily impacting the carrying values of the redeemable non-controlling interest, retained deficit, the net income attributable to the non-controlling interest and the net loss attributable to the Company and, as a consequence, of the loss per common share attributable to the Company. The Company has evaluated the errors and determined that the related impacts were not material to the previously issued consolidated financial statements for any prior period. A summary of the corrections to the Company's Consolidated Financial Statements for the periods ended March 31, 2023, June 30, 2023, September 30, 2023, December 31, 2023, March 31, 2024 and June 30, 2024, are as follows:

[0000950170-25-031056:notes:37]
(a)
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) is entitled to receive from us an Annual Recurring Compensation payment of €0.52 per share. The Company erroneously accrued this liability every quarter at €0.59 per share, overstating the associated accrual, the net income attributable to non-controlling interest and the net loss attributable to ADTRAN Holdings, Inc. for fiscal periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024.

[0000950170-25-031056:notes:38]
(b)
For the periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024 the Company remeasured the redeemable non-controlling interest each quarter-end at the current exchange rate of euros to U.S. Dollar. The Company treated the redeemable non-controlling interest as a monetary mezzanine equity instrument but should have treated it as a non-monetary mezzanine equity instrument not subject to remeasurement.

[0000950170-25-031056:notes:39]
The following tables reflect the impact of the revisions to the specific line items presented in the Company’s previously reported Consolidated Balance Sheet as of December 31, 2023, the Consolidated Statement of Loss and the Consolidated Statement of Comprehensive Loss for the year ended December 31, 2023.

[0000950170-25-031056:notes:40]
|  |  |  | December 31, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Accrued Expenses and Other Liabilities |  |  | $ | 37,607 |  |  | $ | (1,403 | ) | (a) | $ | 36,204 |  |
| Total Current Liabilities |  |  | $ | 279,511 |  |  | $ | (1,403 | ) |  | $ | 278,108 |  |
| Total Liabilities |  |  | $ | 636,934 |  |  | $ | (1,403 | ) |  | $ | 635,531 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 451,756 |  |  | $ | (9,604 | ) | (b) | $ | 442,152 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 47,461 |  |  | $ | 4 |  | (a) | $ | 47,465 |  |
| Retained Deficit |  |  | $ | (243,908 | ) |  | $ | 11,003 |  | (a)(b) | $ | (232,905 | ) |
| Total Equity |  |  | $ | 593,822 |  |  | $ | 11,007 |  |  | $ | 604,829 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,682,512 |  |  | $ | — |  |  | $ | 1,682,512 |  |

[0000950170-25-031056:notes:41]
|  |  |  | For the Year Ended December 31, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 8,345 |  |  | $ | (1,399 | ) | (a) | $ | 6,946 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (267,688 | ) |  | $ | 1,399 |  | (a) | $ | (266,289 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (3.41 | ) |  | $ | 0.02 |  | (a) | $ | (3.39 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (3.41 | ) |  | $ | 0.02 |  | (a) | $ | (3.39 | ) |
| Foreign currency translation gain |  |  | $ | 22,753 |  |  | $ | 4 |  | (a) | $ | 22,757 |  |
| Other Comprehensive Income, net of tax |  |  | $ | 21,717 |  |  | $ | 4 |  |  | $ | 21,721 |  |
| Comprehensive Loss, net of tax |  |  | $ | (237,626 | ) |  | $ | 4 |  |  | $ | (237,622 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 8,727 |  |  | $ | (1,399 | ) | (a) | $ | 7,328 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (246,353 | ) |  | $ | 1,403 |  | (a) | $ | (244,950 | ) |

[0000950170-25-031056:notes:42]
Use of Estimates

[0000950170-25-031056:notes:43]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates,

[0000950170-25-031056:notes:44]
determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenue and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

[0000950170-25-031056:notes:45]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions as of December 31, 2024, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.

[0000950170-25-031056:notes:46]
Summary of Significant Accounting Policies

[0000950170-25-031056:notes:47]
Cash and Cash Equivalents

[0000950170-25-031056:notes:48]
Cash and cash equivalents represent demand deposits, money market funds and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. As of December 31, 2024 $74.0 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions and determined the risk of material financial loss due to the exposure of such credit risk to be minimal.

[0000950170-25-031056:notes:49]
Fair Value of Financial Instruments

[0000950170-25-031056:notes:50]
Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models may be applied. Assets and liabilities recorded at fair value in our consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair values.

[0000950170-25-031056:notes:51]
The carrying amounts reported in the Consolidated Balance Sheets for cash and cash equivalents, accounts receivable and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments.

[0000950170-25-031056:notes:52]
The fair value measurements of our derivative instruments are determined using models that maximize the use of the observable market inputs including interest rate curves and both forward and spot prices for currencies, and are classified as Level II under the fair value hierarchy. The fair values of our derivatives are included in Note 10.

[0000950170-25-031056:notes:53]
Investments with contractual maturities beyond one year may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe we have the ability to quickly sell them to the remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. All income generated from these investments is recorded as interest income. We have not recorded any losses relating to variable rate demand notes.

[0000950170-25-031056:notes:54]
Long-term investments is comprised of our deferred compensation plan assets, marketable equity securities and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Any changes in fair value are recognized in net investment gain (loss). Realized gains and losses on sales of debt securities are computed under the specific identification method and are included in other income, net. See Note 4 for additional information.

[0000950170-25-031056:notes:55]
Accounts Receivable

[0000950170-25-031056:notes:56]
The Company records accounts receivable at amortized cost. Prior to establishing payment terms for a new customer, we evaluate the credit risk of the customer. Credit limits and payment terms established for new customers are re-evaluated periodically based on customer collection experience and other financial factors. As of December 31, 2024, no customer comprised more than 10% of our total accounts receivable balance. As of December 31, 2023, a single customer comprised more than 10% of our total accounts receivable balance, which accounted for 11.9% of our total accounts receivable.

[0000950170-25-031056:notes:57]
The Company regularly reviews the need for an allowance for credit losses related to our outstanding accounts receivable balances using the historical loss-rate method, as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition or credit rating by geographic location, as provided by a third party and/or by

[0000950170-25-031056:notes:58]
customer, if needed, and overall macro-economic conditions in which the customer operates. Based on this assessment, an allowance for credit losses would be recorded if the Company determined that, based on our historical write-offs, which have been immaterial, and such asset specific risks, there was risk in collectability of the full amount of any accounts receivable.

[0000950170-25-031056:notes:59]
Accounts Receivable Factoring

[0000950170-25-031056:notes:60]
Receivables Purchase Agreement

[0000950170-25-031056:notes:61]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. These transactions are accounted for in accordance with ASC Topic 860 and result in a reduction in accounts receivable because the Factoring Agreement transfers effective control over, and risk related to the receivables to the buyers. Trade accounts receivables balances sold are removed from the Consolidated Balance Sheets and cash received is reflected as cash flows provided by (used in) operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest expense on the Consolidated Statements of Loss. On each sale date, the Factor retains from the sale price a default reserve, up to a required balance, which is held by the Factor in a reserve account and pledged to the Company. The Factor is entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account is included in other assets on the Consolidated Balance Sheets.

[0000950170-25-031056:notes:62]
Previous Receivables Purchase Agreement

[0000950170-25-031056:notes:63]
On December 19, 2023, the Company entered into a factoring agreement with a third-party financial institution to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The factoring agreement qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company was considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retained a residual claim on reserves related to the factored receivables. The receivables factored were carried in accounts receivable, less allowance for credit losses on the Consolidated Balance Sheets, the secured borrowings were carried on the Company’s Consolidated Balance Sheets as a current liability, in accounts payable, proceeds and repayments of the secured borrowings are reflected as cash flows (used in) provided by financing activities in the Consolidated Statements of Cash Flows and program fees are recorded in interest expense in the Company’s Consolidated Statements of Loss. The short-term liability classification of the secured borrowings was based on the estimated timing of the collection of the accounts receivable which were expected to be received within 12 months. The receivables purchase agreement was terminated on July 1, 2024 and there were no secured borrowings under this agreement as of December 31, 2024. See Note 2 for additional information.

[0000950170-25-031056:notes:64]
Inventory

[0000950170-25-031056:notes:65]
Inventory is carried at the lower of cost and estimated net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory and are updated at least quarterly. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 5 for additional information.

[0000950170-25-031056:notes:66]
Property, Plant and Equipment

[0000950170-25-031056:notes:67]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. We depreciate building and land improvements from 5 to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years, and computer software from three to five years. Expenditures for repairs and maintenance are charged to expense as incurred. Major improvements that materially prolong the lives of the assets are capitalized. Gains and losses on the disposal of property, plant and equipment are recorded in operating loss. See Note 6 for additional information.

[0000950170-25-031056:notes:68]
Assets Held for Sale

[0000950170-25-031056:notes:69]
An asset is considered to be held for sale when all the following criteria are met: (i) management commits to a plan to sell the asset; (ii) the asset is available for immediate sale in its present condition; (iii) actions required to complete the sale of the asset have been initiated; (iv) sale of the asset is probable and the completed sale is expected to occur within one year; (v) it is unlikely that the disposal plan will be significantly modified; and (vi) the asset is actively being marketed for sale at a price that is reasonable given its current market value.

[0000950170-25-031056:notes:70]
The Company records assets held for sale at the lower of their carrying value or fair value. The total carrying value of assets held for sale was $11.9 million as of December 31, 2024 and is separately recorded on the balance sheet.

[0000950170-25-031056:notes:71]
Intangible Assets

[0000950170-25-031056:notes:72]
Purchased intangible assets with finite lives are carried at cost less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets. See Note 9 for additional information.

[0000950170-25-031056:notes:73]
Impairment of Long-Lived Assets and Intangibles

[0000950170-25-031056:notes:74]
Long-lived assets, such as property, plant and equipment, right of use lease assets and purchased intangibles subject to amortization, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of an asset to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset exceeds its estimated future cash flows, an impairment charge is recognized by the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group.

[0000950170-25-031056:notes:75]
During the first quarter of 2024, factors triggered a quantitative impairment assessment for the Network Solutions asset group. The long-lived assets associated with the Network Solutions asset group was approximately $358.6 million as of December 31, 2024

[0000950170-25-031056:notes:76]
There were no impairment losses for long-lived assets and intangible assets during the years ended December 31, 2024, 2023 and 2022. See Note 9 for additional information.

[0000950170-25-031056:notes:77]
Goodwill

[0000950170-25-031056:notes:78]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company’s annual impairment assessment is done at the reporting unit level, which we determined are generally the same as our operating segments, which are identified in Note 16 to the Consolidated Financial Statements. We review goodwill for impairment annually during the fourth quarter and also test for impairment between annual tests if an event occurs or circumstances change that would more likely than not reduce the fair value of our reporting units below their carrying amount. Such events and circumstances may include among others: a significant adverse change in legal factors or in the general business climate; significant decline in our stock price and market capitalization; unanticipated competition; the testing for recoverability of a significant asset within the reporting unit; and an adverse action or assessment by a regulator. Any adverse change in these factors could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements.

[0000950170-25-031056:notes:79]
The Company’s annual impairment test date is October 1, 2024. Based on our analysis, management concluded that there was no impairment of goodwill as of that date. Between the annual impairment date of October 1, 2024 and year-end December 31, 2024, there were no additional triggering events.

[0000950170-25-031056:notes:80]
The Company recognized impairments of $292.6 million and $37.9 million during the years ended December 31, 2024 and 2023, respectively. No goodwill impairment charge was recorded during the year ended December 31, 2022. See Note 8 for additional information.

[0000950170-25-031056:notes:81]
Other Non-Current Assets

[0000950170-25-031056:notes:82]
Implementation costs incurred for hosting arrangements that are related to service contracts are capitalized and amortized over the term of the arrangement. Capitalized implementation costs totaled $0.1 million and $0.3 million as of December 31, 2024 and 2023, respectively, and are included in other non-current assets on the Consolidated Balance Sheets. In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. The Company recognized impairment charges of $16.9 million during the year ended December 31, 2022 primarily related to capitalized implementation costs for a cloud computing arrangement. The impairment charges were determined based on actual costs incurred. During the year ended December 31, 2024 and 2023, no impairment charges were recognized. We depreciate capitalized implementation costs over various lives. Amortization expense was $0.1 million, $5.9 million and $3.9 million for the years ended December 31, 2024, 2023 and 2022, respectively, which is recorded almost entirely in selling, general and administrative expenses in the Consolidated Statements of Loss.

[0000950170-25-031056:notes:83]
Pension Benefit Plan Obligations

[0000950170-25-031056:notes:84]
The Company maintains a defined benefit pension plans covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. See Note 13 for additional information.

[0000950170-25-031056:notes:85]
Lease Obligations

[0000950170-25-031056:notes:86]
The Company  has operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain potential embedded leases. These other contracts are specifically reviewed to determine whether we have the right to substantially all of the

[0000950170-25-031056:notes:87]
economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease. Some of our leases include options to renew. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. The exercise of lease renewal options is at our sole discretion. The depreciable life of leased assets and leasehold improvements are limited by the expected lease term. Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. Our lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0000950170-25-031056:notes:88]
Stock-Based Compensation

[0000950170-25-031056:notes:89]
The Company has two stock incentive plans from which stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock are available for grant to employees and directors. Costs related to these awards are recognized over their vesting periods.

[0000950170-25-031056:notes:90]
Stock-based compensation expense recognized for the years ended December 31, 2024, 2023 and 2022 was approximately $15.3 million, $16.0 million and $28.3 million, respectively. See Note 3 for additional information.

[0000950170-25-031056:notes:91]
Research and Development Costs

[0000950170-25-031056:notes:92]
Research and development costs include compensation for engineers and support personnel, contracted services, depreciation and material costs associated with new product development, enhancement of current products and product cost reductions. We continually evaluate new product opportunities and engage in intensive research for product and software development efforts. Research and development costs totaled $221.5 million, $258.3 million and $173.8 million for the years ended December 31, 2024, 2023 and 2022, respectively.

[0000950170-25-031056:notes:93]
Adtran Networks has arrangements with governmental entities for the purposes of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the years ended December 31, 2024, 2023 and 2022, the Company recognized $9.2 million, $5.2 million and $1.1 million, respectively, as a reduction of research and development expense.

[0000950170-25-031056:notes:94]
Income Taxes

[0000950170-25-031056:notes:95]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax basis of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0000950170-25-031056:notes:96]
In determining whether an uncertain tax position exists, the Company determines, based solely on its technical merits, whether the tax position is more likely than not to be sustained upon examination, and if so, a tax benefit is measured on a cumulative probability basis that is more likely than not to be realized upon the ultimate settlement. The Company recognizes interest and penalties related to unrecognized tax benefits through interest expense and income tax expense, respectively.

[0000950170-25-031056:notes:97]
Foreign Currency

[0000950170-25-031056:notes:98]
Transactions with customers that are denominated in foreign currencies are recorded using the appropriate exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are remeasured at the balance sheet dates using the closing rates of exchange between those foreign currencies and the functional currency with any transaction gains or losses reported in other income, net. Our primary exposures to foreign currency exchange rate movements are with our German and United Kingdom subsidiaries, whose functional currencies are the euro and the British pound sterling.  Adjustments resulting from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive income.

[0000950170-25-031056:notes:99]
Revenue

[0000950170-25-031056:notes:100]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices

[0000950170-25-031056:notes:101]
primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees collected are recorded as revenue and the related cost is included in cost of revenue. Revenue, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Incremental costs of obtaining a contract, that are recoverable, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to account for shipping fees paid as a cost of fulfilling the related contract. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0000950170-25-031056:notes:102]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0000950170-25-031056:notes:103]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in Service Provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware revenue.

[0000950170-25-031056:notes:104]
Hardware and Software Revenue

[0000950170-25-031056:notes:105]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenue from software license sales is recognized at delivery and transfer of control to the customer. Revenue is recognized net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time products are delivered.

[0000950170-25-031056:notes:106]
Services & Support Segment - Includes a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services to complement our Network Solutions segment.

[0000950170-25-031056:notes:107]
Maintenance Revenue

[0000950170-25-031056:notes:108]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenue, when applicable, are recorded in current and non-current unearned revenue.

[0000950170-25-031056:notes:109]
Network Implementation Revenue

[0000950170-25-031056:notes:110]
The Company recognizes revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0000950170-25-031056:notes:111]
See Notes 2 and 16 for additional information on reportable segments.

[0000950170-25-031056:notes:112]
Unearned Revenue

[0000950170-25-031056:notes:113]
Unearned revenue primarily represents customer billings on maintenance service programs and unearned revenue related to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one month to five years. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. In addition, we provide software maintenance and a variety of hardware maintenance services to customers under contracts with terms up to ten years. When we defer revenue related to multiple performance obligations where we still have contractual obligations, we also defer the related costs. Current deferred costs are included in prepaid expenses and other current assets on the accompanying Consolidated Balance Sheets and totaled $2.2 million and $2.1 million as of December 31, 2024 and 2023, respectively. Non-current deferred costs included in other non-current assets on the accompanying Consolidated Balance Sheets were less than $0.1 million as of December 31, 2024 and December 31, 2023.

[0000950170-25-031056:notes:114]
Redeemable Non-Controlling Interest

[0000950170-25-031056:notes:115]
As of December 31, 2024 and 2023, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 33.0% and 34.7%, respectively.

[0000950170-25-031056:notes:116]
As a result of the effectiveness of the DPLTA on January 16, 2023, the Adtran Networks shares, representing the equity interest in Adtran Networks held by holders other than the Company, can be tendered at any time and are, therefore, redeemable and must be classified outside stockholders’ equity. Therefore, the permanent equity noncontrolling interest balance was reclassified to redeemable non-controlling interest (RNCI) on January 16, 2023 and was remeasured to fair value based on the trading market price of the Adtran Networks shares.

[0000950170-25-031056:notes:117]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Consolidated Balance Sheets. See Note 15 for additional information on RNCI.

[0000950170-25-031056:notes:118]
Loss per Share

[0000950170-25-031056:notes:119]
Loss per common share and loss per common share assuming dilution are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year. See Note 19 for additional information.

[0000950170-25-031056:notes:120]
Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $3.0 million effect of redemption of RNCI for the year ended December 31, 2024. See Note 19 for additional information.

[0000950170-25-031056:notes:121]
Recent Accounting Pronouncements Not Yet Adopted

[0000950170-25-031056:notes:122]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, as amended by ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which applies to all public business entities and is intended to enhance disclosures about specific types of expenses included in the expense captions presented on the face of the income statement as well as disclosures about selling expenses. The amendments are effective prospectively in the first annual period beginning after December 15, 2026 and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2024-03 will have on our disclosures.

[0000950170-25-031056:notes:123]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2023-09 will have on our disclosures.

[0000950170-25-031056:notes:124]
Recently Adopted Accounting Pronouncements

[0000950170-25-031056:notes:125]
In November 2023, the FASB issued ASU 2023-7, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures", which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses, allowing financial statement users to better understand the components of a segment's profit or loss to assess potential future cash flows for each reportable segment and the entity as a whole. The amendments expand a public entity's segment disclosures by requiring disclosure of significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), clarifying when an entity may report one or more additional measures to assess segment performance, requiring enhanced interim disclosures, providing new disclosure requirements for entities with a single reportable segment, and requiring other new disclosures. The amendments are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024.

[0000950170-25-031056:notes:126]
The Company adopted the new standard on January 1, 2024. The adoption of this standard resulted in additional footnote disclosures. The adoption of this standard did not have a material impact on our Consolidated Balance Sheet, Consolidated Statement of Income or Consolidated Statement of Cash Flows. See Note 16 for additional information.

[0000950170-25-031056:notes:127]
There have been no other recently adopted accounting pronouncements that are expected to have a material effect on the Consolidated Financial Statements.

[0000950170-25-031056:notes:128]
Reclassification of Prior Year Presentation

[0000950170-25-031056:notes:129]
Certain prior year amounts have been reclassified for consistency with current year presentation. These reclassifications had no effect on reported results of operations. An adjustment has been made to the Consolidated Balance Sheet and Consolidated Statement of Cash Flows for the fiscal year ended December 31, 2023, to reclassify between Property, Plant and Equipment and Intangible Assets.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-25-031056:notes:130]
Note 2 - Revenue

[0000950170-25-031056:notes:131]
The following is a description of the principal activities from which revenue is generated by reportable segment:

[0000950170-25-031056:notes:132]
Network Solutions Segment - Includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

[0000950170-25-031056:notes:133]
Services & Support Segment - Includes network design, implementation, maintenance and cloud-hosted services supporting the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

[0000950170-25-031056:notes:134]
Revenue by Category

[0000950170-25-031056:notes:135]
In addition to operating under two reportable segments, the Company also reports revenue across three categories – Subscriber Solutions, Access & Aggregation Solutions and Optical Networking Solutions.

[0000950170-25-031056:notes:136]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at the customer premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

[0000950170-25-031056:notes:137]
Our Access & Aggregation Solutions are solutions that are used by communications Service Providers to connect residential subscribers, business subscribers and mobile radio networks to the Service Providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions, and access orchestration solutions that ensure highly reliable and efficient network performance.

[0000950170-25-031056:notes:138]
Our Optical Networking Solutions are used by communications Service Providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems, and automation platforms that are used to build high-scale, secure and assured optical networks.

[0000950170-25-031056:notes:139]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2024:

[0000950170-25-031056:notes:140]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 295,541 |  |  | $ | 35,237 |  |  | $ | 330,778 |  |
| Access & Aggregation Solutions |  |  | 232,934 |  |  |  | 58,072 |  |  |  | 291,006 |  |
| Optical Networking Solutions |  |  | 210,489 |  |  |  | 90,447 |  |  |  | 300,936 |  |
| Total |  | $ | 738,964 |  |  | $ | 183,756 |  |  | $ | 922,720 |  |

[0000950170-25-031056:notes:141]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2023:

[0000950170-25-031056:notes:142]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 263,192 |  |  | $ | 34,516 |  |  | $ | 297,708 |  |
| Access & Aggregation Solutions |  |  | 304,074 |  |  |  | 54,344 |  |  |  | 358,418 |  |
| Optical Networking Solutions |  |  | 407,123 |  |  |  | 85,851 |  |  |  | 492,974 |  |
| Total |  | $ | 974,389 |  |  | $ | 174,711 |  |  | $ | 1,149,100 |  |

[0000950170-25-031056:notes:143]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2022:

[0000950170-25-031056:notes:144]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 364,238 |  |  | $ | 26,216 |  |  | $ | 390,454 |  |
| Access & Aggregation Solutions |  |  | 326,934 |  |  |  | 47,068 |  |  |  | 374,002 |  |
| Optical Networking Solutions |  |  | 225,621 |  |  |  | 35,459 |  |  |  | 261,080 |  |
| Total |  | $ | 916,793 |  |  | $ | 108,743 |  |  | $ | 1,025,536 |  |

[0000950170-25-031056:notes:145]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of December 31, 2024 and December 31, 2023 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $325.7 million and 314.8 million, respectively. As of December 31, 2024, approximately 73.0% is expected to be recognized over the next 12 months, and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of December 31, 2024, are related to contracts or orders that have an original expected duration of one year or less and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-25-031056:notes:146]
The following table provides information about accounts receivable, contract assets and unearned revenue from contracts with customers:

[0000950170-25-031056:notes:147]
| (In thousands) |  | December 31, 2024 |  |  | December 31, 2023 |  |
| Accounts receivable |  | $ | 178,030 |  |  | $ | 216,445 |  |
| Contract assets(1) |  | $ | 631 |  |  | $ | 691 |  |
| Unearned revenue |  | $ | 52,701 |  |  | $ | 46,731 |  |
| Non-current unearned revenue |  | $ | 22,065 |  |  | $ | 25,109 |  |

[0000950170-25-031056:notes:148]
(1) Included in other receivables on the Consolidated Balance Sheets.

[0000950170-25-031056:notes:149]
The allowance for credit losses were $1.3 million and, $0.4 million as of December 31, 2024, and December 31, 2023, respectively, related to accounts receivable.

[0000950170-25-031056:notes:150]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of December 31 2024, totaled $18.3 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets on the Consolidated Balance Sheets. The cost of the Factoring Agreement is included in interest expense in the Consolidated Statements of Loss and totaled $0.6 million for the year ended December 31, 2024. Costs of a previous receivables purchase agreement which are included in interest expense in the Consolidated Statements of Loss totaled $0.9 million for the year ended December 31, 2023.

[0000950170-25-031056:notes:151]
Previous Receivable Purchase Agreement

[0000950170-25-031056:notes:152]
On December 19, 2023, the Company entered into a receivables purchase agreement (the “Prior Factoring Agreement”) with a third-party financial institution (the "Prior Factoring Agreement") to replace a prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The prior factoring agreement provided for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The prior factoring agreement qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. The receivables purchase agreement was terminated on July 1, 2024 and there were no secured borrowings under this agreement as of December 31, 2024. Total secured borrowings under the agreement were $14.3 million as of December 31, 2023, which left $25.4 million available for future borrowings as of December 31, 2023. Accounts receivable pledged as collateral related to the secured borrowings were $16.8 million as of December 31, 2023. For the year ended December 31, 2024, the Company incurred program fee expenses of $0.6 million.

[0000950170-25-031056:notes:153]
Contract Assets

[0000950170-25-031056:notes:154]
No allowance for credit losses was recorded for the years ended December 31, 2024 and 2023, respectively, related to contract assets.

[0000950170-25-031056:notes:155]
Of the outstanding unearned revenue balances as of December 31, 2023, $50.5 million were recognized as revenue during the year ended December 31, 2024. Of the outstanding unearned revenue balances as of December 31, 2022, $36.2 million were recognized as revenue during the year ended December 31, 2023.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-25-031056:notes:156]
Note 3 – Stock-Based Compensation

[0000950170-25-031056:notes:157]
2024 Stock Incentive Plans

[0000950170-25-031056:notes:158]
At the annual meeting of stockholders held on May 8, 2024, the Company’s stockholders approved, upon recommendation of the Board of Directors, the adoption of the ADTRAN Holdings, Inc. 2024 Employee Stock Incentive Plan (“2024 Employee Plan”) and the ADTRAN Holdings, Inc. 2024 Directors Stock Plan (“2024 Directors Plan”). No additional awards will be granted under the Company’s previous stock incentive plans, including the 2020 Employee Stock Incentive Plan, the 2020 Directors Stock Plan, or the 2015 Employee Stock Incentive Plan. Outstanding awards granted under the Company's prior equity incentive plans will remain subject to the terms of such applicable plans, and shares under such plans that are cancelled or forfeited will be available for issuance under the 2024 Employee Plan or the 2024 Directors Plan, as applicable.

[0000950170-25-031056:notes:159]
Under the 2024 Employee Plan, the Company is authorized to issue 4.5 million shares of common stock to certain employees, key service providers and advisors through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock, any of which may be subject to performance-based conditions. RSUs and restricted stock granted under the 2024 Employee Plan will typically vest pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date. Stock options granted under the 2024 Employee Plan will typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Stock options, RSUs and restricted stock granted under the 2024 Employee Plan reduce the shares authorized for issuance under the 2024 Employee Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the prior employee stock incentive plans increase the shares authorized for issuance under the 2024 Employee Plan by one share of common stock for each share underlying the award.

[0000950170-25-031056:notes:160]
Under the 2024 Directors Plan, the Company is authorized to issue 0.6 million shares of common stock through stock options, restricted stock and RSUs to non-employee directors. Stock awards issued under the 2024 Directors Plan typically will become vested in full on the first anniversary of the grant date. Stock options issued under the 2024 Directors Plan will have a ten-year contractual term. Stock options, restricted stock and RSUs granted under the 2024 Directors Plan reduce the shares authorized for issuance under the 2024 Directors Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the prior directors stock plan increase the shares authorized for issuance under the 2024 Directors Plan by one share of common stock for each share underlying the award.

[0000950170-25-031056:notes:161]
As of December 31, 2024, 5.1 million shares were available for issuance pursuant to awards that may be made in the future under stockholder-approved equity plans.

[0000950170-25-031056:notes:162]
For the years ended December 31, 2024, 2023 and 2022, stock-based compensation expense was $15.3 million, $16.0 million and $28.3 million respectively.

[0000950170-25-031056:notes:163]
PSUs, RSUs and Restricted Stock - ADTRAN Holdings, Inc.

[0000950170-25-031056:notes:164]
The following table summarizes stock-based compensation expense related to stock options, PSUs, RSUs and restricted stock for the years ended December 31, 2024, 2023 and 2022:

[0000950170-25-031056:notes:165]
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Stock-based compensation expense included in cost of revenue |  | $ | 1,142 |  |  | $ | 1,293 |  |  | $ | 2,876 |  |
| Selling, general and administrative expenses |  |  | 10,412 |  |  |  | 10,701 |  |  |  | 20,844 |  |
| Research and development expenses |  |  | 3,788 |  |  |  | 4,022 |  |  |  | 4,602 |  |
| Stock-based compensation expense included in operating expenses |  |  | 14,200 |  |  |  | 14,723 |  |  |  | 25,446 |  |
| Total stock-based compensation expense |  |  | 15,342 |  |  |  | 16,016 |  |  |  | 28,322 |  |
| Tax benefit for expense associated with non-qualified stock options, PSUs, RSUs and restricted stock |  |  | (2,102 | ) |  |  | (3,837 | ) |  |  | (5,152 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 13,240 |  |  | $ | 12,179 |  |  | $ | 23,170 |  |

[0000950170-25-031056:notes:166]
PSUs, RSUs and restricted stock - ADTRAN Holdings, Inc.

[0000950170-25-031056:notes:167]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2023 and 2024 and the changes that occurred during 2024:

[0000950170-25-031056:notes:168]
|  |  | Number ofshares (In thousands) |  |  | WeightedAverage GrantDate Fair Value(Per Share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2023 |  |  | 1,942 |  |  | $ | 17.46 |  |
| PSUs, RSUs and restricted stock granted |  |  | 1,097 |  |  | $ | 7.85 |  |
| PSUs, RSUs and restricted stock vested |  |  | (575 | ) |  | $ | 18.76 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (129 | ) |  | $ | 14.20 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2024 |  |  | 2,335 |  |  | $ | 13.22 |  |

[0000950170-25-031056:notes:169]
The fair value of PSUs with performance conditions, RSUs and restricted stock is equal to the closing price of the Company's stock on the date of grant. The fair value of PSUs with market conditions is calculated using a Monte Carlo simulation valuation method.

[0000950170-25-031056:notes:170]
The following table details the significant assumptions that impact the fair value estimate of the market-based PSUs:

[0000950170-25-031056:notes:171]
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Estimated fair value per share |  | $ | 8.29 |  |  | $ | 19.26 |  |  | $ | 24.01 |  |
| Expected volatility |  |  | 51.34 | % |  |  | 51.52 | % |  |  | 45.77 | % |
| Risk-free interest rate |  |  | 4.12 | % |  |  | 3.93 | % |  |  | 4.28 | % |
| Expected dividend yield |  |  | — |  |  |  | 2.55 | % |  |  | 1.76 | % |

[0000950170-25-031056:notes:172]
For market-based PSUs, the number of shares of common stock earned by a recipient is subject to a market condition based on Adtran’s relative total stockholder return against all companies in the NASDAQ Telecommunications Index at the end of a three-year performance period. Depending on the relative total stockholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the PSUs, with the shares earned distributed upon the vesting. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted PSUs vests and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of Adtran, as defined by the 2020 Employee Plan. The recipients of the PSUs receive dividend credits based on the shares of common stock underlying the PSUs. The dividend credits vest and are earned in the same manner as the PSUs and are paid in cash upon the issuance of common stock for the PSUs.

[0000950170-25-031056:notes:173]
During the year ended December 31, 2024, and 2023, the Company granted 0.1 and 0.9 million performance-based PSUs to its executive officers and certain employees, respectively. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over either a two or three-year period, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to either 100% or 150% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense and liabilities with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0000950170-25-031056:notes:174]
During each of the years ended December 2023 and 2022, the Company granted 0.9 and 0.3 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vested over one-year and two-year periods, respectively, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements. Pursuant to the Business Combination, the unearned performance-based PSUs converted to time-based RSUs which were treated as an award modification during the third quarter of 2022. This resulted in incremental compensation expense totaling $17.8 million being recognized during the twelve months ended December 31, 2022. These awards were fully vested as of December 31, 2022.

[0000950170-25-031056:notes:175]
Pursuant to the Business Combination, 0.3 million shares of market-based PSU awards converted to time-based RSU awards which were treated as an award modification during the third quarter of 2022. Given that the fair value of these awards after the modification was less than the fair value of the awards immediately before the modification, no incremental compensation expense was recognized. The Company continued to recognize compensation expense based on the award's original grant date fair value.

[0000950170-25-031056:notes:176]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the grant date. RSUs and restricted stock vest ratably over four-year and one-year periods, respectively.

[0000950170-25-031056:notes:177]
We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0000950170-25-031056:notes:178]
As of December 31, 2024, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $10.7 million, which is expected to be recognized over an average remaining recognition period of 2.1 years. There was $10.9 million of unrecognized compensation expense related to unvested 2024 performance-based PSUs, which will be recognized over the remaining requisite service period of 1 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures as they occur.

[0000950170-25-031056:notes:179]
Stock Options - ADTRAN Holdings, Inc.

[0000950170-25-031056:notes:180]
The following table is a summary of stock options outstanding as of December 31, 2024 and 2023 and the changes that occurred during 2024:

[0000950170-25-031056:notes:181]
|  |  | Number ofOptions(In thousands) |  |  | WeightedAverageExercise Price(Per share) |  |  | Weighted AverageRemainingContractual Lifein Years |  |  | AggregateIntrinsic Value(In thousands) |  |
| Stock options outstanding, December 31, 2023 |  |  | 3,894 |  |  | $ | 10.32 |  |  |  | 5.25 |  |  | $ | 3,087 |  |
| Stock options exercised |  |  | (139 | ) |  | $ | 5.93 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (202 | ) |  | $ | 6.78 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (609 | ) |  | $ | 14.69 |  |  |  |  |  |  |  |
| Stock options outstanding, December 31, 2024 |  |  | 2,944 |  |  | $ | 9.86 |  |  |  | 4.98 |  |  | $ | 3,762 |  |
| Stock options exercisable, December 31, 2024 |  |  | 1,465 |  |  | $ | 8.73 |  |  |  | 4.18 |  |  | $ | 1,960 |  |

[0000950170-25-031056:notes:182]
As of December 31, 2024, there was $3.2 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 0.9 years. No stock options were granted during 2024.

[0000950170-25-031056:notes:183]
The determination of the fair value of stock options assumed or granted by Adtran was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors.

[0000950170-25-031056:notes:184]
All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0000950170-25-031056:notes:185]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between the Company's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December  31, 2024. The amount of aggregate intrinsic value was $3.8 million as of December 31, 2024, which will change based on the fair market value of the Company's stock. The total pre-tax intrinsic value of options exercised during the years ended December 31, 2024 and 2023 was $0.3 million and $0.1 million, respectively.

[0000950170-25-031056:notes:186]
The following table further describes our stock options outstanding as of December 31, 2024:

[0000950170-25-031056:notes:187]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range ofExercise Prices (Per Share) |  | OptionsOutstanding atDecember 31, 2024(In thousands) |  |  | Weighted AverageRemainingContractual Lifein Years |  |  | WeightedAverageExercise Price(Per Share) |  |  | OptionsExercisable atDecember 31, 2024(In thousands) |  |  | WeightedAverageExercisePrice |  |
| $5.23 – $5.23 |  |  | 1,131 |  |  |  | 8.87 |  |  | $ | 5.23 |  |  |  | 550 |  |  | $ | 5.23 |  |
| $5.24 – $8.58 |  |  | 431 |  |  |  | 1.85 |  |  | $ | 7.86 |  |  |  | 431 |  |  | $ | 7.86 |  |
| $8.59 – $12.17 |  |  | 696 |  |  |  | 2.81 |  |  | $ | 11.57 |  |  |  | 155 |  |  | $ | 9.49 |  |
| $12.18 – $15.33 |  |  | 378 |  |  |  | 1.23 |  |  | $ | 15.33 |  |  |  | 329 |  |  | $ | 15.33 |  |
| $15.34 – $19.08 |  |  | 308 |  |  |  | 4.37 |  |  | $ | 19.08 |  |  |  | — |  |  | $ | — |  |
|  |  |  | 2,944 |  |  |  |  |  |  |  |  |  | 1,465 |  |  |  |  |

[0000950170-25-031056:notes:188]
The Black-Scholes option pricing model (the “Black-Scholes Model”) is used to determine the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options. The stock

[0000950170-25-031056:notes:189]
option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0000950170-25-031056:notes:190]
The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0000950170-25-031056:notes:191]
The weighted-average estimated fair value of stock options granted to employees during the years ended December 31, 2023 was $2.99 per share with the following weighted-average assumptions:

[0000950170-25-031056:notes:192]
|  |  | 2023 |  |
| Expected volatility | $ |  | 51.78 | % |
| Risk-free interest rate |  |  | 4.13 | % |
| Expected dividend yield |  |  | — |  |
| Expected life (in years) |  |  | 5.8 | % |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-25-031056:notes:193]
Note 4 – Investments

[0000950170-25-031056:notes:194]
Debt Securities and Other Investments

[0000950170-25-031056:notes:195]
The Company did not have any debt securities and other investments as of December 31, 2024.

[0000950170-25-031056:notes:196]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities for the years ended December 31, 2024, 2023 and 2022:

[0000950170-25-031056:notes:197]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Gross realized gains on debt securities |  | $ | — |  |  | $ | 9 |  |  | $ | 17 |  |
| Gross realized losses on debt securities |  |  | — |  |  |  | (355 | ) |  |  | (1,211 | ) |
| Total (loss) gain recognized, net |  | $ | — |  |  | $ | (346 | ) |  | $ | (1,194 | ) |

[0000950170-25-031056:notes:198]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt with credit deterioration during the years ended December 31, 2024, 2023 and 2022.

[0000950170-25-031056:notes:199]
Marketable Equity Securities

[0000950170-25-031056:notes:200]
Marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost, where appropriate.

[0000950170-25-031056:notes:201]
Realized and unrealized gains and losses for our marketable equity securities for the year ended December 31, 2024, 2023 and 2022 were as follows:

[0000950170-25-031056:notes:202]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Realized gains (losses) on equity securities sold |  | $ | 277 |  |  | $ | 17 |  |  | $ | (1,675 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 3,310 |  |  |  | 3,083 |  |  |  | (8,470 | ) |
| Total gain (loss) recognized, net |  | $ | 3,587 |  |  | $ | 3,100 |  |  | $ | (10,145 | ) |

[0000950170-25-031056:notes:203]
As of December 31, 2024, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.

[0000950170-25-031056:notes:204]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-25-031056:notes:205]
•
Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-25-031056:notes:206]
•
Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-25-031056:notes:207]
•
Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement; inputs could include information supplied by investees.

[0000950170-25-031056:notes:208]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-25-031056:notes:209]
|  |  | Fair Value Measurements as of December 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,538 |  |  | $ | 5,538 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities - various industries |  |  | 1,068 |  |  |  | 1,068 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 30,991 |  |  |  | 30,991 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 37,597 |  |  | $ | 37,597 |  |  | $ | — |  |  | $ | — |  |

[0000950170-25-031056:notes:210]
|  |  | Fair Value Measurements as of December 31, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,302 |  |  | $ | 5,302 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities - various industries |  |  | 905 |  |  |  | 905 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,838 |  |  |  | 26,838 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,045 |  |  | $ | 33,045 |  |  | $ | — |  |  | $ | — |  |

[0000950170-25-031056:notes:211]
Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-25-031056:notes:212]
Note 5 – Inventory

[0000950170-25-031056:notes:213]
As of December 31, 2024 and 2023, inventory, net was comprised of the following:

[0000950170-25-031056:notes:214]
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Raw materials |  | $ | 107,369 |  |  | $ | 152,140 |  |
| Work in process |  |  | 9,724 |  |  |  | 17,239 |  |
| Finished goods |  |  | 152,244 |  |  |  | 192,916 |  |
| Total Inventory, net |  | $ | 269,337 |  |  | $ | 362,295 |  |

[0000950170-25-031056:notes:215]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions.

[0000950170-25-031056:notes:216]
During the twelve months ended December 31, 2024, the Company recorded an inventory write-down of $8.6 million, as a result of a strategy shift which included discontinuance of certain product lines in connection with the Business Efficiency Program of which $4.1 million relates to inventory write-downs and $4.5 million relates to other charges all of which are included in cost of revenue in the Consolidated Statements of Loss. In connection with the Company’s restructuring efforts, during the twelve months ended December 31, 2023, management determined that there would be a discontinuation of product lines in the Network solutions segment and, as a result, wrote-down related inventories of $24.3 million, which is included in cost of revenue in the Consolidated Statements of Loss.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-25-031056:notes:217]
Note 6 – Property, Plant and Equipment

[0000950170-25-031056:notes:218]
As of December 31, 2024 and 2023, property, plant and equipment, net was comprised of the following:

[0000950170-25-031056:notes:219]
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Engineering and other equipment |  | $ | 184,694 |  |  | $ | 183,336 |  |
| Building |  |  | 50,871 |  |  |  | 79,215 |  |
| Computer hardware and software |  |  | 109,729 |  |  |  | 91,752 |  |
| Building and land improvements |  |  | 39,979 |  |  |  | 58,238 |  |
| Furniture and fixtures |  |  | 20,994 |  |  |  | 21,368 |  |
| Land |  |  | 2,989 |  |  |  | 5,242 |  |
| Total Property, Plant and Equipment |  |  | 409,256 |  |  |  | 439,151 |  |
| Less: accumulated depreciation |  |  | (306,314 | ) |  |  | (325,569 | ) |
| Total Property, Plant and Equipment, net |  | $ | 102,942 |  |  | $ | 113,582 |  |

[0000950170-25-031056:notes:220]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs or strategic plan. As a result, the Company recognized impairment charges of $0.5 million during the year ended December 31, 2022 related to software and web site development. The impairment charges were determined based on actual costs incurred. During the years ended December 31, 2024 and 2023, no impairment charges were recognized.

[0000950170-25-031056:notes:221]
Depreciation expense was $27.7 million, $30.2 million and $20.9 million for the years ended December 31, 2024, 2023 and 2022, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Loss.

[0000950170-25-031056:notes:222]
Assets Held For Sale

[0000950170-25-031056:notes:223]
On December 31, 2024, the Company determined it met the held for sale criteria pursuant to ASC 360, "Impairment and Disposal of Long-Live Assets" on the Company's property located at the North and South Towers in its Huntsville, Alabama campus and ceased recording depreciation on the assets. The Company expects to dispose of the property within the next twelve months.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000950170-25-031056:notes:224]
Note 7 – Leases

[0000950170-25-031056:notes:225]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. As of December 31, 2024, our operating leases had remaining lease terms of 1 month to 167 months, some of which included options to extend the leases for up to one year, and some of which included options to terminate the leases within three months. Supplemental balance sheet information related to operating leases is as follows:

[0000950170-25-031056:notes:226]
|  |  |  |  | December 31, |  |  | December 31, |  |
| (In thousands) |  | Classification |  | 2024 |  |  | 2023 |  |
| Assets |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Other non-current assets |  | $ | 30,342 |  |  | $ | 37,474 |  |
| Total lease asset |  |  |  | $ | 30,342 |  |  | $ | 37,474 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses and other liabilities |  | $ | 7,154 |  |  | $ | 7,720 |  |
| Non-current lease obligations |  | Non-current lease obligations |  |  | 25,925 |  |  |  | 31,420 |  |
| Total lease liability |  |  |  | $ | 33,079 |  |  | $ | 39,140 |  |

[0000950170-25-031056:notes:227]
Lease expense related to short-term leases was less than $0.2 million for the twelve months ended December 31, 2024 and $0.1 million for the twelve months ended December 31, 2023 and 2022, and is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Loss. Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.3 million, $0.7 million and $0.6 million for the twelve months ended December 31, 2024, 2023 and 2022, respectively.

[0000950170-25-031056:notes:228]
The components of lease expense included in the Consolidated Statements of Loss were as follows:

[0000950170-25-031056:notes:229]
|  |  | For the Year Ended December 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Cost of revenue |  | $ | 150 |  |  | $ | 163 |  |  | $ | 110 |  |
| Research and development expenses |  |  | 412 |  |  |  | 990 |  |  |  | 942 |  |
| Selling, general and administrative expenses |  |  | 9,213 |  |  |  | 9,708 |  |  |  | 3,961 |  |
| Total operating lease expense |  | $ | 9,775 |  |  | $ | 10,861 |  |  | $ | 5,013 |  |

[0000950170-25-031056:notes:230]
As of December 31, 2024, operating lease liabilities included on the Consolidated Balance Sheet by future maturity were as follows:

[0000950170-25-031056:notes:231]
| (In thousands) |  | Amount |  |
| 2025 |  |  | 8,829 |  |
| 2026 |  |  | 7,550 |  |
| 2027 |  |  | 6,498 |  |
| 2028 |  |  | 4,980 |  |
| 2029 |  |  | 2,925 |  |
| Thereafter |  |  | 10,281 |  |
| Total lease payments |  |  | 41,063 |  |
| Less: Interest |  |  | (7,984 | ) |
| Present value of lease liabilities |  | $ | 33,079 |  |

[0000950170-25-031056:notes:232]
Future operating lease payments include $5.3 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0000950170-25-031056:notes:233]
An incremental borrowing rate is used based on information available at the commencement date in determining the present value of lease payments. The incremental borrowing rate is determined on a portfolio basis by grouping leases with similar terms, as well as grouping leases based on a U.S. dollar or euro functional currency. The following table provides information about our weighted average lease terms and weighted average discount rates:

[0000950170-25-031056:notes:234]
|  |  | As of December 31, |  |
| Weighted average remaining lease term (years) |  | 2024 |  |  | 2023 |  |
| Operating leases with USD functional currency |  |  | 7.3 |  |  |  | 8.1 |  |
| Operating leases with EUR functional currency |  |  | 5.9 |  |  |  | 5.8 |  |
| Weighted average discount rate |  |  |  |  |  |  |
| Operating leases with USD functional currency |  |  | 3.64 | % |  |  | 3.70 | % |
| Operating leases with EUR functional currency |  |  | 4.50 | % |  |  | 3.92 | % |


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-25-031056:notes:235]
Note 8 – Goodwill

[0000950170-25-031056:notes:236]
The changes in the carrying amount of goodwill for the year ended December 31, 2024 are as follows:

[0000950170-25-031056:notes:237]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2023 |  | $ | 297,031 |  |  | $ | 56,384 |  |  | $ | 353,415 |  |
| Goodwill impairment |  |  | (290,528 | ) |  |  | — |  |  |  | (290,528 | ) |
| Foreign currency translation adjustments |  |  | (6,503 | ) |  |  | (3,466 | ) |  |  | (9,969 | ) |
| As of December 31, 2024 |  | $ | — |  |  | $ | 52,918 |  |  | $ | 52,918 |  |

[0000950170-25-031056:notes:238]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of each reporting unit using a combination of an income approach and a market approach. The significant inputs and assumptions used in the determination of the fair value of our reporting units, based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to revenue growth rates, earnings before interest, taxes, depreciation and amortization ("EBITDA") margins, discount rate, peer group determination, revenue and EBITDA market multiple. The Company determined upon its quantitative impairment assessment to recognize a $292.6 million non-cash goodwill impairment charge for the Network Solutions reporting unit. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the first quarter of 2024.

[0000950170-25-031056:notes:239]
During 2023, the Company experienced decreased market capitalization and long-term projections. Therefore, an interim impairment test over goodwill was performed as of September 30, 2023. The Company determined the fair value of each reporting unit using a combination of an income approach and a market approach. Management’s determination of the fair value of our reporting units, based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to cash flow projections, discount rate, peer group determination and market multiple selection. It was determined that the decreases in projected future cash flows, discount rates, overall macroeconomic conditions, as well as the decrease in our market capitalization applied in the valuation, were required to align with market-based assumptions and company-specific risk, which resulted in lower fair values of the Services & Support reporting unit. As a result of the interim assessment, the Company recorded a goodwill impairment charge of $37.9 million as its estimated fair value was less than its book value on that date. No other goodwill impairment charges were recorded during 2023.

[0000950170-25-031056:notes:240]
As of December 31, 2024, accumulated goodwill impairment losses in total were $330.5 million.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-25-031056:notes:241]
Note 9 – Intangible Assets

[0000950170-25-031056:notes:242]
Intangible assets as of December 31, 2024 and 2023, consisted of the following:

[0000950170-25-031056:notes:243]
|  |  |  |  | 2024 |  |  | 2023 |  |
| (In thousands) | Weighted Average Useful Life(in years) |  |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |
| Customer relationships |  | 11.0 |  |  | $ | 51,165 |  |  | $ | (18,778 | ) |  | $ | 32,387 |  |  | $ | 54,856 |  |  | $ | (15,943 | ) |  | $ | 38,913 |  |
| Backlog |  | 1.7 |  |  |  | 53,839 |  |  |  | (52,258 | ) |  |  | 1,581 |  |  |  | 57,391 |  |  |  | (52,022 | ) |  |  | 5,369 |  |
| Developed technology |  | 7.9 |  |  |  | 346,923 |  |  |  | (99,588 | ) |  |  | 247,335 |  |  |  | 339,189 |  |  |  | (61,653 | ) |  |  | 277,536 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (4,452 | ) |  |  | 1,448 |  |  |  | 5,900 |  |  |  | (3,797 | ) |  |  | 2,103 |  |
| Licensing agreements |  | 8.5 |  |  |  | 560 |  |  |  | (407 | ) |  |  | 153 |  |  |  | 560 |  |  |  | (368 | ) |  |  | 192 |  |
| Patents |  | 7.3 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 500 |  |  |  | (500 | ) |  |  | — |  |
| Trade names |  | 3.0 |  |  |  | 27,851 |  |  |  | (25,862 | ) |  |  | 1,989 |  |  |  | 29,689 |  |  |  | (16,379 | ) |  |  | 13,310 |  |
| Total |  |  |  | $ | 486,238 |  |  | $ | (201,345 | ) |  | $ | 284,893 |  |  | $ | 488,085 |  |  | $ | (150,662 | ) |  | $ | 337,423 |  |

[0000950170-25-031056:notes:244]
Intangible assets are reviewed for impairment whenever events and circumstances indicate impairment may have occurred. During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer inventory adjustments triggered a quantitative reassessment of our estimated future undiscounted cash flows for the Network Solutions asset group. The significant inputs and assumptions used in the determination of the cash flows expected to be generated by the asset group, requires significant judgment and the use of estimates and assumptions related to revenue growth rates, EBITDA margins, peer group determination, and disposition exit multiple. The Company determined that our estimated future undiscounted cash flows exceeded the carrying value of our asset groups. No impairment losses of intangible assets were recorded during the years ended December 31, 2024, 2023 and 2022.

[0000950170-25-031056:notes:245]
Amortization expense was $63.0 million, $82.8 million and $47.3 million for the years ended December 31, 2024, 2023 and 2022, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Loss.

[0000950170-25-031056:notes:246]
As of December 31, 2024, estimated future amortization expense of intangible assets was as follows:

[0000950170-25-031056:notes:247]
|  |  | As of |  |
| (In thousands) |  | December 31, 2024 |  |
| 2025 |  | $ | 56,268 |  |
| 2026 |  |  | 53,231 |  |
| 2027 |  |  | 47,585 |  |
| 2028 |  |  | 40,374 |  |
| 2029 |  |  | 40,028 |  |
| Thereafter |  |  | 47,407 |  |
| Total |  | $ | 284,893 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-25-031056:notes:248]
Note 10 - Hedging

[0000950170-25-031056:notes:249]
The Company has certain forward rate agreements to hedge foreign currency exposure of expected future cash flows in foreign currency. The Company does not hold or issue derivative instruments for trading or other speculative purposes. Derivatives are initially recognized at fair value on the date a derivative contract is entered into and are subsequently re-measured to their fair value at the end of each reporting period. All changes in the fair value of derivative instruments are recognized as other income, net in the Consolidated Statements of Loss. The derivative instruments are not subject to master netting agreements and are not offset in the Consolidated Balance Sheets. We are exposed to risk from credit-related losses resulting from nonperformance by counterparties to our financial instruments. We perform credit evaluations of our counterparties under forward exchange contracts and expect all counterparties to meet their obligations. We have not experienced credit losses from our counterparties.
 As of December 31, 2024, the Company had 39 forward rate contracts outstanding.

[0000950170-25-031056:notes:250]
Foreign Currency Hedging Agreement

[0000950170-25-031056:notes:251]
On November 3, 2022, the Company entered into a euro/U.S. dollar forward contract arrangement (the "Initial Forward") with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which was governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enabling the Company to convert a portion of its euro denominated payment obligations under the proposed DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million for U.S. dollars at a daily fixed forward rate ranging from EUR/USD 0.98286 to 1.03290. The aggregate amount of €160.0 million was divided into eight quarterly tranches of €20.0 million, which commenced in the fourth quarter of 2022. During the twelve months ended December 31, 2024, the Company settled four €20.0 million forward contract tranches.

[0000950170-25-031056:notes:252]
On March 21, 2023, the Company entered into a euro/U.S. dollar forward contract arrangement (the “Forward”) with the Hedge Counterparty. Under the Forward, which was governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company exchanged an aggregate notional amount of €160.0 million for U.S. dollars at an average rate of EUR/USD 1.085. During the twelve months ended December 31, 2024, the Company settled four $20.0 million forward contract tranches. As of December 31, 2024, both the Initial Forward and Forward have fully matured and are no longer outstanding.

[0000950170-25-031056:notes:253]
The fair values of the Company's derivative instruments recorded in the Consolidated Balance Sheet as of December 31, 2024 were as follows:

[0000950170-25-031056:notes:254]
| (In thousands) |  | Balance Sheet Location |  | December 31, 2024 |  |  | December 31, 2023 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  | $ | 565 |  |  | $ | 7,125 |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  | $ | — |  |  | $ | (2,277 | ) |
| Total derivatives |  |  |  | $ | 565 |  |  | $ | 4,848 |  |

[0000950170-25-031056:notes:255]
The change in the fair values of the Company's derivative instruments recorded in the Consolidated Statements of Loss during the years ended December 31, 2024, 2023 and 2022 were as follows:

[0000950170-25-031056:notes:256]
| (In thousands) |  | Income StatementLocation |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income, net |  | $ | 2,197 |  |  | $ | 758 |  |  | $ | 10,793 |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-25-031056:notes:257]
Note 11 – Credit Agreements

[0000950170-25-031056:notes:258]
The carrying amounts of the Company's revolving credit agreements in its Consolidated Balance Sheets were as follows:

[0000950170-25-031056:notes:259]
|  |  | As of December 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Wells Fargo credit agreement |  | $ | 189,576 |  |  | $ | 195,000 |  |
| Total non-current revolving credit facility |  | $ | 189,576 |  |  | $ | 195,000 |  |

[0000950170-25-031056:notes:260]
As of December 31, 2024 and 2023, the estimated fair value of our revolving credit agreements, approximates the carrying value. As of December 31, 2024 and 2023, the weighted average interest rate on our revolving credit agreements was 8.64% and 7.45%, respectively.

[0000950170-25-031056:notes:261]
Wells Fargo Credit Agreement

[0000950170-25-031056:notes:262]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (as amended from time to time, the “Credit Agreement”). Initially, the Credit Agreement allowed for revolving credit borrowings of up to $400.0 million in aggregate principal amount ($100.0 million of which is, subject to the covenants described below, available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below). As of December 31, 2024, the aggregate principal amount was reduced to $374.0 million ($74.0 million of which is available to Adtran Networks as borrower pursuant to the Subline) due to a $26.0 million reduction on the Subline.

[0000950170-25-031056:notes:263]
On August 9, 2023, ("First Amendment Effective Date") the Company and ADTRAN, Inc. entered into a First Amendment to Credit Agreement (“First Amendment”).

[0000950170-25-031056:notes:264]
The First Amendment, among other things, increased the available funding from $100.0 million to $400.0 million. In addition, a new $50.0 million delayed draw term loan facility (“DDTL”) was introduced, which (subject to certain conditions) was available for borrowing in the event that at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date was tendered (such event, a “Springing Covenant Event”). Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During the Springing Covenant Period, the Company’s leverage ratios are increased. Although the ability to borrow under the DDTL expired on August 9, 2024, the Springing Covenant Event and Springing Covenant Period remain in effect.

[0000950170-25-031056:notes:265]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-25-031056:notes:266]
On January 16, 2024 ("Second Amendment Effective Date"), the Company and ADTRAN, Inc. entered into a Second Amendment to Credit Agreement and First Amendment to Collateral Agreement ("Second Amendment"). The Second Amendment, among other things, introduced the Covenant Relief Period, which provided the Company with additional covenant headroom while imposing a minimum liquidity financial covenant from the end of the fourth quarter of 2023 to the end of the third quarter of 2024. The Covenant Relief Period ended on November 7, 2024.

[0000950170-25-031056:notes:267]
On March 12, 2024, the Company and ADTRAN, Inc. entered into a Third Amendment to Credit Agreement ("Third Amendment"). The Third Amendment, among other things, amended the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024, and June 30, 2024.

[0000950170-25-031056:notes:268]
On June 4, 2024, the Company, ADTRAN, Inc., and Adtran Networks entered into a Fourth Amendment to Credit Agreement ("Fourth Amendment"). The Fourth Amendment, among other things, created a new sublimit under the existing $400.0 million revolving commitments, in an aggregate amount of $100.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold is initially $75.0 million and may be lowered from time to time pursuant to the terms of the Fourth Amendment. The existing swing line sublimit and letter of credit sublimit under the Credit Agreement remained available to the US Borrower (and not to Adtran Networks) after giving effect to the Fourth Amendment. Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

[0000950170-25-031056:notes:269]
As of December 31, 2024, Adtran's borrowings under the revolving line of credit were $189.6 million, of which approximately $141.0 million were borrowed by ADTRAN, Inc. and $48.6 million were borrowed under the Subline by Adtran Networks. The credit facilities provided under the Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $374.0 million total revolving facility for the issuance of letters of credit. As of December 31, 2024, we had a total of 3.6 million in letters of credit under ADTRAN, Inc. outstanding under the Credit Agreement, leaving a net amount (after giving effect to the $189.6 million of outstanding borrowings described above) of $180.8 million available for future borrowings; however, as of December 31, 2024, the Company was limited to additional borrowings of $56.1 million based on debt covenant compliance metrics. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of December 31, 2024, the Company was in compliance with all covenants.

[0000950170-25-031056:notes:270]
Revolving Line of Credit Interest Rate

[0000950170-25-031056:notes:271]
All U.S. dollar borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin) bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, an applicable margin of 3.15% per annum).

[0000950170-25-031056:notes:272]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.

[0000950170-25-031056:notes:273]
“Adjusted Term SOFR” means Term SOFR for the applicable interest period plus 0.10% per annum. Adjusted Term SOFR is subject to a floor of 0.00% per annum.

[0000950170-25-031056:notes:274]
All euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.25% per annum).

[0000950170-25-031056:notes:275]
In addition, if on or prior to December 31, 2024 we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

[0000950170-25-031056:notes:276]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Covenant Relief Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

[0000950170-25-031056:notes:277]
The “Applicable Margin Increase Period” means the period commencing on the Second Amendment Effective Date and ending on the first date when each of the following conditions have been met: (a) the Covenant Relief Period has ended, (b) since the Second Amendment Effective Date, the borrowers have repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the borrowers have reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million, and (d) the borrowers are in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

[0000950170-25-031056:notes:278]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

[0000950170-25-031056:notes:279]
Covenants Under the Credit Agreement

[0000950170-25-031056:notes:280]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable):

[0000950170-25-031056:notes:281]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Total Net Leverage Ratio may not exceed 5.00x.

[0000950170-25-031056:notes:282]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

[0000950170-25-031056:notes:283]
•
In the fiscal quarter in which a Springing Covenant Event occurs and the three consecutive quarterly test periods thereafter, (“Springing Covenant Period”), the following covenant levels:

[0000950170-25-031056:notes:284]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

[0000950170-25-031056:notes:285]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

[0000950170-25-031056:notes:286]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

[0000950170-25-031056:notes:287]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

[0000950170-25-031056:notes:288]
•
If a Springing Covenant Period is not in effect, the Consolidated Senior Secured Net Leverage Ratio may not exceed 3.25x.

[0000950170-25-031056:notes:289]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not be less than 1.25x.

[0000950170-25-031056:notes:290]
•
During a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million.

[0000950170-25-031056:notes:291]
All obligations under the Credit Agreement (including under the Subline) are guaranteed by ADTRAN, Inc., and certain subsidiaries of ADTRAN, Inc. (“Full Facility Guarantors”). To secure such guarantees, ADTRAN, Inc. and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and ADTRAN, Inc. has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries ("Subline Guarantors") have provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Adtran Networks has also granted security interests in favor of the Administrative Agent over substantially all of its tangible and intangible assets, to secure solely its obligations under the Subline. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

[0000950170-25-031056:notes:292]
The Credit Agreement, as amended, contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-25-031056:notes:293]
Note 12 – Income Taxes

[0000950170-25-031056:notes:294]
The components of income tax expense (benefit) for the years ended December 31, 2024, 2023 and 2022 are as follows:

[0000950170-25-031056:notes:295]
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Current |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (1,456 | ) |  | $ | 2,545 |  |  | $ | 4,572 |  |
| State |  |  | 575 |  |  |  | 26 |  |  |  | 88 |  |
| International |  |  | 7,419 |  |  |  | 10,004 |  |  |  | (4,347 | ) |
| Total Current |  |  | 6,538 |  |  |  | 12,575 |  |  |  | 313 |  |
| Deferred |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 332 |  |  |  | 46,252 |  |  |  | (47,429 | ) |
| State |  |  | (405 | ) |  |  | 6,607 |  |  |  | (6,776 | ) |
| International |  |  | 2,320 |  |  |  | (37,301 | ) |  |  | (8,183 | ) |
| Total Deferred |  |  | 2,247 |  |  |  | 15,558 |  |  |  | (62,388 | ) |
| Total Income Tax Expense (Benefit) |  | $ | 8,785 |  |  | $ | 28,133 |  |  | $ | (62,075 | ) |

[0000950170-25-031056:notes:296]
The effective income tax rate differs from the federal statutory rate due to the following:

[0000950170-25-031056:notes:297]
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Tax provision computed at the federal statutory rate |  |  | 21.00 | % |  |  | 21.00 | % |  |  | 21.00 | % |
| State income tax provision, net of federal benefit |  |  | 0.06 |  |  |  | 1.34 |  |  |  | 2.60 |  |
| Federal research credits |  |  | 0.68 |  |  |  | 3.26 |  |  |  | 6.74 |  |
| Foreign taxes |  |  | 0.50 |  |  |  | 3.52 |  |  |  | 6.29 |  |
| Tax-exempt income |  |  | 0.04 |  |  |  | 0.06 |  |  |  | 0.21 |  |
| Change in valuation allowance |  |  | (5.88 | ) |  |  | (35.19 | ) |  |  | 63.92 |  |
| Non-deductible transaction costs |  |  | — |  |  |  | — |  |  |  | (2.74 | ) |
| Foreign tax credits |  |  | 0.86 |  |  |  | 2.45 |  |  |  | (0.40 | ) |
| Stock-based compensation |  |  | (0.40 | ) |  |  | (0.57 | ) |  |  | (2.09 | ) |
| Withholding taxes |  |  | (0.08 | ) |  |  | 0.01 |  |  |  | 0.03 |  |
| Adtran Networks tax exempt income |  |  | — |  |  |  | 1.42 |  |  |  | — |  |
| Return to accrual |  |  | (0.50 | ) |  |  | 0.62 |  |  |  | 0.24 |  |
| Global intangible low-taxed income ("GILTI") |  |  | (3.14 | ) |  |  | (5.87 | ) |  |  | (8.08 | ) |
| Adtran Networks Goodwill Impairment |  |  | (14.17 | ) |  |  | (4.62 | ) |  |  | — |  |
| Other, net |  |  | (1.00 | ) |  |  | 0.40 |  |  |  | (0.24 | ) |
| Effective Tax Rate |  |  | (2.03 | )% |  |  | (12.17 | )% |  |  | 87.48 | % |

[0000950170-25-031056:notes:298]
Loss before expense (benefit) for income taxes for the years ended December 31, 2024, 2023 and 2022 is as follows:

[0000950170-25-031056:notes:299]
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| U.S. entities |  | $ | (71,684 | ) |  | $ | (113,951 | ) |  | $ | (33,720 | ) |
| International entities |  |  | (360,579 | ) |  |  | (117,259 | ) |  |  | (37,243 | ) |
| Total |  | $ | (432,263 | ) |  | $ | (231,210 | ) |  | $ | (70,963 | ) |

[0000950170-25-031056:notes:300]
Loss before expense (benefit) for income taxes for international entities reflects loss based on statutory transfer pricing agreements. This amount does not correlate to consolidated international revenue, which occurs from our U.S. entity.

[0000950170-25-031056:notes:301]
Deferred income taxes on the Consolidated Balance Sheets result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The significant components of current and non-current deferred taxes as of December 31, 2024 and 2023 consist of the following:

[0000950170-25-031056:notes:302]
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Inventory |  | $ | 14,121 |  |  | $ | 19,623 |  |
| Accrued expenses |  |  | 845 |  |  |  | 3,533 |  |
| Deferred compensation |  |  | 7,093 |  |  |  | 6,284 |  |
| Stock-based compensation |  |  | 1,770 |  |  |  | 2,023 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 105 |  |  |  | 105 |  |
| Pensions |  |  | 5,121 |  |  |  | 8,607 |  |
| Foreign losses |  |  | 70,666 |  |  |  | 2,705 |  |
| State losses and credit carry-forwards |  |  | 4,901 |  |  |  | 4,259 |  |
| Federal loss and research carry-forwards |  |  | 20,874 |  |  |  | 78,450 |  |
| Lease liabilities |  |  | 6,153 |  |  |  | 7,701 |  |
| Capitalized research and development expenditures |  |  | 43,574 |  |  |  | 48,192 |  |
| Interest expense limitation |  |  | 6,815 |  |  |  | — |  |
| Valuation allowance |  |  | (110,960 | ) |  |  | (86,567 | ) |
| Total Deferred Tax Assets |  |  | 71,078 |  |  |  | 94,915 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Property, plant and equipment |  |  | (8,368 | ) |  |  | (9,093 | ) |
| Intellectual property |  |  | (67,923 | ) |  |  | (86,572 | ) |
| Right of use lease assets |  |  | (6,175 | ) |  |  | (8,424 | ) |
| Investments |  |  | (1,476 | ) |  |  | (694 | ) |
| Total Deferred Tax Liabilities |  |  | (83,942 | ) |  |  | (104,783 | ) |
| Net Deferred Tax Liabilities |  | $ | (12,864 | ) |  | $ | (9,868 | ) |

[0000950170-25-031056:notes:303]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was signed into law. Subsequently, the Internal Revenue Service (“IRS”) released its final GILTI regulations on July 9, 2020. The passage of the CARES Act and subsequent issuance of the GILTI final regulations together resulted in the Company’s recognition of a tax benefit in the amount of $10.8 million during 2020, $7.9 million of which related to the utilization of deferred tax assets which had previously been offset with a valuation allowance and $2.9 million primarily related to the tax rate differential on carrying back losses from 2018 and 2019 tax years to prior years in which the U.S. Corporate tax rate was 35% versus the current 21% federal tax rate.

[0000950170-25-031056:notes:304]
On December 20, 2021, the Organization for Economic Co-operation and Development (“OECD”) published Pillar Two Model Rules defining the global minimum tax, which calls for the taxation of large corporations at a minimum rate of 15%. The OECD has since issued administrative guidance providing transition and safe harbor rules around the implementation of the Pillar Two global minimum tax. Many non-U.S. tax jurisdictions have either recently enacted legislation to adopt certain components of the Pillar Two Model Rules beginning in 2024 (including the European Union Member States) with the adoption of additional components in later years or announced their plans to enact legislation in future years. The Pillar Two Model Rules did not have a material impact on the Company’s financial statements for the 2024 tax year. We are still closely monitoring developments and evaluating the potential impact on future periods.

[0000950170-25-031056:notes:305]
On August 16, 2022, the Inflation Reduction Act of 2022 (“Inflation Reduction Act”) was signed into law, with tax provisions primarily focused on implementing a 15% minimum tax on global adjusted financial statement income (“AFSI”) for corporations with average AFSI exceeding $1 billion over a three-year period, a 1% excise tax on share repurchases and various climate and clean energy tax incentives. The Inflation Reduction Act did not have a material impact on the Company’s financial statements for the 2024 tax year.

[0000950170-25-031056:notes:306]
As of December 31, 2024 and 2023, non-current deferred taxes reflected deferred taxes on net unrealized gains and losses on available-for-sale investments and deferred taxes on unrealized losses in our pension plan. The net change in non-current deferred taxes associated with these items, which resulted in a deferred tax benefit of $0.2 million and $0.3 million in 2024 and 2023, respectively, was recorded as an adjustment to other comprehensive (loss) income, presented in the Consolidated Statements of Comprehensive (Loss) Income.

[0000950170-25-031056:notes:307]
The Company continually reviews the adequacy of our valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes. Due to the decrease in revenue and profitability for 2023 and 2024 and all other positive and negative objective evidence considered as part of our analysis, our ability to consider other subjective evidence such as projections for future growth continues to be limited when evaluating whether our deferred tax assets will be realized. As such, the Company maintains its conclusion from 2023 that it is not more likely than not that our domestic deferred tax assets will be realized and a valuation allowance against certain domestic deferred tax assets remains through  2024. Additional valuation allowance was recorded against certain deferred tax assets on our foreign entities as not more likely than not realizable in the fourth quarter of 2024. The amount of the deferred tax assets considered realizable, however, could be adjusted in future periods in the event sufficient evidence is present to support a conclusion that it is more likely than not that all or a portion of our deferred tax assets will be realized.

[0000950170-25-031056:notes:308]
As of December 31, 2024 and 2023, the Company had gross deferred tax assets totaling $98.1 million offset by a valuation allowance totaling $111.0 million and gross deferred tax assets totaling $76.7 million offset by a valuation allowance of $86.6 million, respectively. Of the current valuation allowance, $87.0 million was established against our domestic deferred tax assets and the remaining $24.0 million is related to foreign tax assets where we lacked sufficient future source of taxable income to realize those deferred tax assets. The change in our valuation allowance for the year ending December 31, 2024 was an increase of $24.4 million. The change in the valuation allowance was primarily related to the decrease in deferred tax liabilities remaining from the step up in book basis from purchase accounting and the increase in deferred tax assets associated with net operating losses and interest expense limitation during the year.

[0000950170-25-031056:notes:309]
Supplemental balance sheet information related to deferred tax assets (liabilities) as of December 31, 2024 and 2023 were as follows:

[0000950170-25-031056:notes:310]
|  |  | December 31, 2024 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Assets (Liabilities), net |  |
| Domestic |  | $ | 102,447 |  |  | $ | (87,030 | ) |  | $ | 15,417 |  |
| International |  |  | (4,351 | ) |  |  | (23,930 | ) |  |  | (28,281 | ) |
| Total |  | $ | 98,096 |  |  | $ | (110,960 | ) |  | $ | (12,864 | ) |

[0000950170-25-031056:notes:311]
|  |  | December 31, 2023 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Assets (Liabilities), net |  |
| Domestic |  | $ | 101,120 |  |  | $ | (84,767 | ) |  | $ | 16,353 |  |
| International |  |  | (24,421 | ) |  |  | (1,800 | ) |  |  | (26,221 | ) |
| Total |  | $ | 76,699 |  |  | $ | (86,567 | ) |  | $ | (9,868 | ) |

[0000950170-25-031056:notes:312]
As of December 31, 2024 and 2023, the deferred tax assets for foreign and domestic loss carry-forwards, research and development tax credits, unamortized research and development costs and state credit carry-forwards totaled $140.0 million and $135.1 million, respectively. As of December 31, 2024, $27.7 million of these deferred tax assets will expire at various times between 2025 and 2045. The remaining deferred tax assets will either amortize through 2040 or carryforward indefinitely.

[0000950170-25-031056:notes:313]
As of December 31, 2024 and 2023, respectively, our cash and cash equivalents were $77.6 million and $87.2 million. Of these amounts, our foreign subsidiaries held cash of $54.2 million and $73.0 million, respectively, representing approximately 78% and 88% of available short-term liquidity, which is used to fund ongoing liquidity needs of these subsidiaries. As part of our restructuring plan, the Company’s assertion on being indefinitely reinvested changed in a particular jurisdiction in a previous year. The Company has a withholding tax liability of $0.4 million as of December 31, 2024 and 2023. The Company maintains its assertion in all other jurisdictions that it is indefinitely reinvesting its funds held in foreign jurisdictions outside of the U.S., except to the extent any of these funds can be repatriated without withholding tax. However, if all of these funds were repatriated to the U.S., or used for U.S. operations, certain amounts could be subject to tax. Due to the timing and circumstances of repatriation of such earnings, if any, it is not practicable to determine the amount of funds subject to unrecognized deferred tax liability.

[0000950170-25-031056:notes:314]
During 2024, 2023 and 2022, no income tax benefit or expense was recorded for stock options exercised as an adjustment to equity.

[0000950170-25-031056:notes:315]
The change in the unrecognized income tax benefits for the years ended December 31, 2024, 2023 and 2022 were as follows:

[0000950170-25-031056:notes:316]
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 989 |  |  | $ | 17,885 |  |  | $ | 17,836 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | — |  |  |  | — |  |
| Current year |  |  | — |  |  |  | 129 |  |  |  | 123 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | (121 | ) |  |  | (17,025 | ) |  |  | (13 | ) |
| Expiration of applicable statute of limitations |  |  | (616 | ) |  |  | — |  |  |  | (61 | ) |
| Balance at end of period |  | $ | 252 |  |  | $ | 989 |  |  | $ | 17,885 |  |

[0000950170-25-031056:notes:317]
As of December 31, 2024, 2023 and 2022, our total liability for unrecognized tax benefits was $0.3 million, $1.0 million and $17.9 million, respectively, of which $0.3 million, $1.0 million and $17.9 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of December 31, 2023 and 2022, the balances of accrued interest and penalties $0.1 million and $0.1 million, respectively. There was no accrued interest and penalties as of December 31, 2024.

[0000950170-25-031056:notes:318]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date. We file income tax returns in the U.S. for federal and various state jurisdictions and several foreign jurisdictions. We are not currently under audit by the Internal Revenue Service. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2019.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-25-031056:notes:319]
Note 13 – Employee Benefit Plans

[0000950170-25-031056:notes:320]
Pension Benefit Plan

[0000950170-25-031056:notes:321]
We maintain a defined benefit pension plans covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Details regarding the pension plans are set forth below.

[0000950170-25-031056:notes:322]
•
In Germany, there are two defined benefit pension plans and two defined contribution plans. These plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service and salary. The defined benefit plans are financed by contributions paid by the Company and the defined contribution plans are financed by contributions paid by the participants.

[0000950170-25-031056:notes:323]
•
In Switzerland, there are two defined benefit pension plans. Both plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service, salary and on a participant's old age account. The plans are financed by contributions paid by the participants and by the Company.

[0000950170-25-031056:notes:324]
•
In Italy, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis. Employees receive their pension payments as a function of salary, inflation and a notional account.

[0000950170-25-031056:notes:325]
•
In Israel, there is a defined benefit pension plan that provides benefits in the event of a participant being dismissed involuntarily, retirement or death. The plan's benefits are based on the higher of the severance benefit required by law or the cash surrender value of the severance benefit component of any qualifying insurance policy or long-term employee benefit fund that is registered in the participants name. The plan is financed by contributions paid by the Company.

[0000950170-25-031056:notes:326]
•
In India, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis.

[0000950170-25-031056:notes:327]
The pension benefit plan obligations and funded status as of December 31, 2024 and 2023, were as follows:

[0000950170-25-031056:notes:328]
| (In thousands) |  | 2024 |  |  | 2023 |  |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 67,897 |  |  | $ | 59,344 |  |  |
| Service cost |  |  | 1,664 |  |  |  | 1,579 |  |  |
| Interest cost |  |  | 1,902 |  |  |  | 1,851 |  |  |
| Actuarial (gain) loss - experience |  |  | (238 | ) |  |  | 1,181 |  |  |
| Actuarial loss - assumptions |  |  | 860 |  |  |  | 1,791 |  |  |
| Benefit payments |  |  | (4,108 | ) |  |  | (1,966 | ) |  |
| Plan amendments |  |  | (874 | ) |  |  | 966 |  |  |
| Participant contributions |  |  | 429 |  |  |  | — |  |  |
| Effects of foreign currency exchange rate changes |  |  | (4,273 | ) |  |  | 3,151 |  |  |
| Projected benefit obligation at end of period |  |  | 63,259 |  |  |  | 67,897 |  |  |
| Change in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  |  | 55,218 |  |  |  | 48,720 |  |  |
| Actual gain on plan assets |  |  | 3,966 |  |  |  | 3,125 |  |  |
| Contributions |  |  | 1,288 |  |  |  | 1,215 |  |  |
| Benefit payments |  |  | (2,244 | ) |  |  | (231 | ) |  |
| Effects of foreign currency exchange rate changes |  |  | (3,738 | ) |  |  | 2,389 |  |  |
| Fair value of plan assets at end of period |  |  | 54,490 |  |  |  | 55,218 |  |  |
| Unfunded status at end of period |  | $ | (8,769 | ) |  | $ | (12,679 | ) |  |

[0000950170-25-031056:notes:329]
The accumulated benefit obligation was $62.8 million and $67.1 million as of December 31, 2024 and 2023, respectively. The decrease in the accumulated benefit obligation, projected benefit obligation and the actuarial loss was primarily attributable to benefit payments to retirees and the effect of exchange rates during the year.

[0000950170-25-031056:notes:330]
The net amounts recognized in the Consolidated Balance Sheets for the unfunded pension liability as of December 31, 2024 and 2023 were as follows:

[0000950170-25-031056:notes:331]
| (In thousands) |  | Balance Sheet Location |  | 2024 |  |  | 2023 |  |
| Non-current pension asset |  | Other non-current assets |  | $ | 517 |  |  | $ | — |  |
| Current pension liability |  | Accrued wages and benefits |  |  | (303 | ) |  |  | (136 | ) |
| Non-current pension liability |  | Non-current pension liability |  |  | (8,983 | ) |  |  | (12,543 | ) |
| Total |  |  |  | $ | (8,769 | ) |  | $ | (12,679 | ) |

[0000950170-25-031056:notes:332]
The components of net periodic pension cost, other than the service cost component, are included in other income, net in the Consolidated Statements of Loss. The components of net periodic pension cost and amounts recognized in other comprehensive (loss) income for the years ended December 31, 2024, 2023 and 2022 were as follows:

[0000950170-25-031056:notes:333]
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,664 |  |  | $ | 1,579 |  |  | $ | 1,426 |  |
| Interest cost |  |  | 1,902 |  |  |  | 1,851 |  |  |  | 1,168 |  |
| Expected return on plan assets |  |  | (2,529 | ) |  |  | (1,750 | ) |  |  | (2,129 | ) |
| Amortization of actuarial losses |  |  | 28 |  |  |  | 26 |  |  |  | 355 |  |
| Net periodic benefit cost |  |  | 1,065 |  |  |  | 1,706 |  |  |  | 820 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | (1,640 | ) |  |  | 2,304 |  |  |  | (6,549 | ) |
| Amortization of actuarial gains (losses) |  |  | 233 |  |  |  | (145 | ) |  |  | (113 | ) |
| Amount recognized in other comprehensive (income) loss |  |  | (1,407 | ) |  |  | 2,159 |  |  |  | (6,662 | ) |
| Total recognized in net periodic benefit cost and other comprehensive (income) loss |  | $ | (342 | ) |  | $ | 3,865 |  |  | $ | (5,842 | ) |

[0000950170-25-031056:notes:334]
The amounts recognized in accumulated other comprehensive loss as of December 31, 2024 and 2023 were as follows:

[0000950170-25-031056:notes:335]
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Net actuarial loss |  | $ | (1,824 | ) |  | $ | (3,231 | ) |

[0000950170-25-031056:notes:336]
The defined benefit pension plans are accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our plan's assets is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in euro currency with durations close to the duration of our pension obligations.

[0000950170-25-031056:notes:337]
The weighted-average assumptions that were used to determine the net periodic benefit cost for the years ended December 31, 2024, 2023 and 2022 were as follows:

[0000950170-25-031056:notes:338]
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Discount rate |  |  | 2.84 | % |  |  | 3.17 | % |  |  | 3.24 | % |
| Rate of compensation increase |  |  | 1.54 | % |  |  | 2.22 | % |  |  | 2.17 | % |
| Expected long-term rates of return |  |  | 4.85 | % |  |  | 4.83 | % |  |  | 4.65 | % |

[0000950170-25-031056:notes:339]
The weighted-average assumptions that were used to determine the benefit obligation as of December 31, 2024 and 2023:

[0000950170-25-031056:notes:340]
|  |  | 2024 |  |  | 2023 |  |  |
| Discount rate |  |  | 2.73 | % |  |  | 2.84 | % |  |
| Rate of compensation increase |  |  | 1.54 | % |  |  | 2.22 | % |  |

[0000950170-25-031056:notes:341]
Actuarial gains and losses are recorded in accumulated other comprehensive income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants.

[0000950170-25-031056:notes:342]
The Company anticipates making approximately $2.0 million in contributions to the pension plans in 2025.

[0000950170-25-031056:notes:343]
The following pension benefit payments, which reflect expected future service, as appropriate, are expected to be paid to participants:

[0000950170-25-031056:notes:344]
| (In thousands) |  |  |  |
| 2025 |  | $ | 3,032 |  |
| 2026 |  |  | 3,214 |  |
| 2027 |  |  | 3,906 |  |
| 2028 |  |  | 3,346 |  |
| 2029 |  |  | 4,352 |  |
| 2030 - 2034 |  |  | 18,834 |  |
| Total |  | $ | 36,684 |  |

[0000950170-25-031056:notes:345]
•
Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-25-031056:notes:346]
We have categorized our cash equivalents and our investments held at fair value into this hierarchy as follows:

[0000950170-25-031056:notes:347]
|  |  | Fair Value Measurements at December 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash and cash equivalents |  | $ | 753 |  |  | $ | 753 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds |  |  | 18,058 |  |  |  | 16,867 |  |  |  | 1,191 |  |  |  | — |  |
| Equity funds |  |  | 21,376 |  |  |  | 21,183 |  |  |  | 193 |  |  |  | — |  |
| Other funds |  |  | 7,406 |  |  |  | 6,089 |  |  |  | 1,317 |  |  |  | — |  |
| Real estate funds |  |  | 6,897 |  |  |  | 1,737 |  |  |  | 2,106 |  |  |  | 3,054 |  |
| Available-for-sale securities |  |  | 53,737 |  |  |  | 45,876 |  |  |  | 4,807 |  |  |  | 3,054 |  |
| Total |  | $ | 54,490 |  |  | $ | 46,629 |  |  | $ | 4,807 |  |  | $ | 3,054 |  |

[0000950170-25-031056:notes:348]
|  |  | Fair Value Measurements at December 31, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash and cash equivalents |  | $ | 987 |  |  | $ | 987 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds |  |  | 20,155 |  |  |  | 18,840 |  |  |  | 1,315 |  |  |  | - |  |
| Equity funds |  |  | 21,525 |  |  |  | 21,288 |  |  |  | 237 |  |  |  | — |  |
| Other funds |  |  | 6,054 |  |  |  | 5,343 |  |  |  | 711 |  |  |  | — |  |
| Insurance contracts |  |  | 353 |  |  |  | — |  |  |  | 353 |  |  |  | — |  |
| Real estate funds |  |  | 6,144 |  |  |  | 546 |  |  |  | 2,326 |  |  |  | 3,272 |  |
| Available-for-sale securities |  |  | 54,231 |  |  |  | 46,017 |  |  |  | 4,942 |  |  |  | 3,272 |  |
| Total |  | $ | 55,218 |  |  | $ | 47,004 |  |  | $ | 4,942 |  |  | $ | 3,272 |  |

[0000950170-25-031056:notes:349]
Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies.

[0000950170-25-031056:notes:350]
The investment policy is periodically reviewed by the Company and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations.

[0000950170-25-031056:notes:351]
401(k) Savings Plans

[0000950170-25-031056:notes:352]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan and the Adtran Networks SE 401(k) Retirement Plan (the “Savings Plans”) for the benefit of eligible employees. The Savings Plans are intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (the “Code”), and is intended to be a “safe harbor” 401(k) plan under Code Section 401(k)(12). The Savings Plans allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plans also requires us to contribute a “safe harbor” amount each year. In our legacy ADTRAN, Inc. plan, we match up to 4% of employee contributions (100% of an employee’s first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s one-year anniversary date. All matching contributions under the legacy ADTRAN, Inc. Savings Plan vest immediately. In our legacy Adtran Networks, plan, we match up to 1.5% of employee contributions (25% of an employee's first 6% of contributions). All matching contributions under the legacy Adtran Networks Savings Plan vest ratably over five years beginning on the employee's one-year anniversary date. In addition, under the legacy Adtran Networks plan, an annual matching employer contribution is made which is based on the Company's achievement against a yearly relative Pro-forma EBIT target which can range from no additional match up to an additional 50% match. In calculating our matching contributions, compensation up to the statutory maximum under the Code is used ($345,000 for 2024). Employer contribution expense and plan administration costs for both Savings Plan amounted to approximately $3.5 million, $4.2 million and $4.1 million in 2024, 2023 and 2022, respectively.

[0000950170-25-031056:notes:353]
Deferred Compensation Plans

[0000950170-25-031056:notes:354]
We maintain two deferred compensation programs for certain executive management employees.

[0000950170-25-031056:notes:355]
The ADTRAN, Inc. Deferred Compensation Program for Employees is offered as a supplement to our tax-qualified 401(k) plan and is available to certain executive management employees who have been designated by our Board of Directors. This deferred compensation plan allows participants to defer all or a portion of certain specified bonuses and up to 25% of remaining cash compensation and permits us to make matching contributions on a discretionary basis without the limitations that apply to the 401(k) plan. To date, we have not made any matching contributions under this plan. We also maintain the ADTRAN, Inc. Equity Deferral Program for Employees. Under this plan, participants may elect to defer all or a portion of their vested PSUs and RSUs to the plan. Such deferrals shall continue to be held and deemed to be invested in shares of Adtran stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the participant.

[0000950170-25-031056:notes:356]
We have set aside the plan assets for all plans in a rabbi trust (the “Trust”) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant and the participant’s bookkeeping account is credited with the earnings and losses attributable to those investments. Benefits are scheduled to be distributed six months after termination of employment in a single lump sum payment or annual installments paid over a three or ten-year term based on the participant’s election. Distributions will be made on a pro-rata basis from each of the hypothetical investments of the participant’s account in cash. Any whole shares of ADTRAN, Inc. common stock that are distributed will be distributed in-kind.

[0000950170-25-031056:notes:357]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging from equities to money market instruments. These mutual funds are publicly quoted and reported at fair value. The fair value of the assets held by the Trust and the amounts payable to the plan participants as of December 31, 2024 and 2023 were as follows:

[0000950170-25-031056:notes:358]
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |
| Long-term investments |  | $ | 30,991 |  |  | $ | 26,838 |  |
| Total Fair Value of Plan Assets |  | $ | 30,991 |  |  | $ | 26,838 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |
| Deferred compensation liability |  | $ | 33,203 |  |  | $ | 29,039 |  |
| Total Amounts Payable to Plan Participants |  | $ | 33,203 |  |  | $ | 29,039 |  |

[0000950170-25-031056:notes:359]
The Trust held $2.2 million of common stock in the Company as of December 31, 2024 and 2023. Shares of the Company held by the Trust are recorded at cost and classified as treasury stock on the Consolidated Balance Sheet.

[0000950170-25-031056:notes:360]
Interest and dividend income of the Trust are included in interest and dividend income in the accompanying 2024, 2023 and 2022 Consolidated Statements of Loss. Changes in the fair value of the plan assets held by the Trust have been included in other income, net  in the accompanying 2024, 2023 and 2022 Consolidated Statements of Loss. Changes in the fair value of the deferred compensation liability are included as selling, general and administrative expense in the accompanying 2024, 2023 and 2022 Consolidated Statements of Loss. Based on the changes in the total fair value of the Trust’s assets, the Company recorded deferred compensation income in 2024, 2023 and 2022 of $3.4 million, $3.0 million and $6.3 million, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-25-031056:notes:361]
Note 14 – Equity

[0000950170-25-031056:notes:362]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by components of accumulated other comprehensive income (loss) for the years ended December 31, 2024, 2023 and 2022:

[0000950170-25-031056:notes:363]
| (In thousands) |  | UnrealizedGains (Losses)on Available-for-SaleSecurities |  |  | DefinedBenefit PlanAdjustments |  |  | ForeignCurrencyAdjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| Balance as of December 31, 2022 |  |  | (836 | ) |  |  | (1,016 | ) |  |  | 27,593 |  |  |  | 385 |  |  |  | 26,126 |  |
| Other comprehensive (loss) income before reclassifications |  |  | 734 |  |  |  | (1,590 | ) |  |  | 22,757 |  |  |  | — |  |  |  | 21,901 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (280 | ) |  |  | 100 |  |  |  | — |  |  |  | — |  |  |  | (180 | ) |
| Net current period other comprehensive income (loss) |  |  | 454 |  |  |  | (1,490 | ) |  |  | 22,757 |  |  |  | — |  |  |  | 21,721 |  |
| Less: Other comprehensive income attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | 382 |  |  |  | — |  |  |  | 382 |  |
| Balance as of December 31, 2023 |  |  | (382 | ) |  |  | (2,506 | ) |  |  | 49,968 |  |  |  | 385 |  |  |  | 47,465 |  |
| Other comprehensive (loss) income before reclassifications |  |  | (160 | ) |  |  | 1,640 |  |  |  | (38,047 | ) |  |  | — |  |  |  | (36,567 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 160 |  |  |  | (161 | ) |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Net current period other comprehensive income (loss) |  |  | — |  |  |  | 1,479 |  |  |  | (38,047 | ) |  |  | — |  |  |  | (36,568 | ) |
| Balance as of December 31, 2024 |  | $ | (382 | ) |  | $ | (1,027 | ) |  | $ | 11,921 |  |  | $ | 385 |  |  | $ | 10,897 |  |

[0000950170-25-031056:notes:364]
(1)
With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings.

[0000950170-25-031056:notes:365]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the years ended December 31, 2024, 2023 and 2022:

[0000950170-25-031056:notes:366]
| (In thousands) |  | For the year ended December 31, |  |  |  |
| Details about Accumulated Other Comprehensive (Loss)Income Components |  | 2024 |  |  | 2023 |  |  | 2022 |  |  | Affected Line Item in theStatement Where Net Loss Is Presented |
| Unrealized gains (loss) on available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | 216 |  |  | $ | (378 | ) |  | $ | (328 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial (loss) gain |  |  | (233 | ) |  |  | 145 |  |  |  | 113 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (17 | ) |  |  | (233 | ) |  |  | (215 | ) |  |  |
| Tax expense |  |  | 16 |  |  |  | 53 |  |  |  | 50 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (1 | ) |  | $ | (180 | ) |  | $ | (165 | ) |  |  |

[0000950170-25-031056:notes:367]
(1)
Included in the computation of net periodic pension cost. See Note 13 for additional information.

[0000950170-25-031056:notes:368]
The following tables present the tax effects related to the change in each component of other comprehensive income (loss) for the years ended December 31, 2024, 2023 and 2022:

[0000950170-25-031056:notes:369]
|  |  | 2024 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized (losses) gains on available-for-sale securities |  | $ | (216 | ) |  | $ | 56 |  |  | $ | (160 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 216 |  |  |  | (56 | ) |  |  | 160 |  |
| Defined benefit plan adjustments |  |  | 1,640 |  |  |  | — |  |  |  | 1,640 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) income |  |  | (233 | ) |  |  | 72 |  |  |  | (161 | ) |
| Foreign currency translation adjustment |  |  | (38,047 | ) |  |  | — |  |  |  | (38,047 | ) |
| Total Other Comprehensive Loss |  | $ | (36,640 | ) |  | $ | 72 |  |  | $ | (36,568 | ) |

[0000950170-25-031056:notes:370]
|  |  | 2023 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 992 |  |  | $ | (258 | ) |  | $ | 734 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) income |  |  | (378 | ) |  |  | 98 |  |  |  | (280 | ) |
| Defined benefit plan adjustments |  |  | (2,304 | ) |  |  | 714 |  |  |  | (1,590 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 145 |  |  |  | (45 | ) |  |  | 100 |  |
| Foreign currency translation adjustment |  |  | 22,757 |  |  |  | — |  |  |  | 22,757 |  |
| Total Other Comprehensive Income |  | $ | 21,212 |  |  | $ | 509 |  |  | $ | 21,721 |  |

[0000950170-25-031056:notes:371]
|  |  | 2022 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized (losses) gains on available-for-sale securities |  | $ | (55 | ) |  | $ | 14 |  |  | $ | (41 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) income |  |  | (328 | ) |  |  | 85 |  |  |  | (243 | ) |
| Defined benefit plan adjustments |  |  | 6,549 |  |  |  | (2,030 | ) |  |  | 4,519 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 113 |  |  |  | (35 | ) |  |  | 78 |  |
| Foreign currency translation adjustment |  |  | 53,396 |  |  |  | — |  |  |  | 53,396 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 59,675 |  |  | $ | (1,966 | ) |  | $ | 57,709 |  |


## us-gaap:RedeemableNoncontrollingInterestTableTextBlock

[0000950170-25-031056:notes:372]
The following table summarizes the redeemable non-controlling interest activity for the year ended December 31, 2024 and 2023:

[0000950170-25-031056:notes:373]
|  |  | For the year ended December 31, |  |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  |
| Balance at beginning of period |  | $ | 442,152 |  |  | $ | — |  |  |
| Reclassification of non-controlling interests |  |  | 1,175 |  |  |  | 443,757 |  |  |
| Redemption of redeemable non-controlling interests |  |  | (20,384 | ) |  |  | (1,657 | ) |  |
| Net income attributable to redeemable non-controlling interests |  |  | 9,824 |  |  |  | 10,092 |  | (1) |
| Annual recurring compensation earned |  |  | (9,824 | ) |  |  | (10,092 | ) | (1) |
| Adtran Networks stock option exercises |  |  | — |  |  |  | 52 |  |  |
| Balance at end of period |  | $ | 422,943 |  |  | $ | 442,152 |  | (1) |

[0000950170-25-031056:notes:374]
(1) During the the third quarter of 2024, the Company identified errors primarily impacting the carrying values of the redeemable non-controlling interest, retained deficit, the net income attributable to the non-controlling interest and the net loss attributable to the Company and, as a consequence, of the loss per common share attributable to the Company. We have revised our previously issued Consolidated Financial Statements for the year ended December 31, 2023. See Note 1 for additional information.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-25-031056:notes:375]
Note 16 – Segment Information and Major Customers

[0000950170-25-031056:notes:376]
The chief operating decision maker is the Company's Chief Executive Officer who regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support.

[0000950170-25-031056:notes:377]
The Network Solutions segment includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions. The Company's cloud-managed Wi-Fi gateways, virtualization software, and switches provide a mix of wired and wireless connectivity at the customer premises. In addition, its Carrier Ethernet products support a variety of applications at the network edge ranging from mobile backhaul to connecting enterprise customers (“Subscriber Solutions"). The Company's portfolio includes products for multi-gigabit service delivery over fiber or alternative media to homes and businesses.

[0000950170-25-031056:notes:378]
The Services & Support segment offers a comprehensive portfolio of network design, implementation, maintenance and cloud-hosted services supporting its Subscriber, Access and Aggregation, and Optical Networking Solutions. These services assist operators in the deployment of multi-vendor networks while reducing their cost to maintain these networks. The cloud-hosted services include a suite of SaaS applications under the Company's Mosaic One platform that manages end-to-end network and service optimization for both fiber access infrastructure and mesh Wi-Fi connectivity. The Company backs these services with a global support organization that offers on-site and off-site support services with varying SLAs.

[0000950170-25-031056:notes:379]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income, net and income tax (expense) benefit are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-25-031056:notes:380]
Revenue and Gross Profit

[0000950170-25-031056:notes:381]
The following table presents information about revenue and gross profit of our reportable segments for each of the years ended December 31, 2024, 2023 and 2022:

[0000950170-25-031056:notes:382]
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| (In thousands) |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 738,964 |  |  | $ | 519,667 |  |  | $ | 219,297 |  |  | $ | 974,389 |  |  | $ | 746,895 |  |  | $ | 227,494 |  |  | $ | 916,793 |  |  | $ | 647,105 |  |  | $ | 269,688 |  |
| Services & Support |  |  | 183,756 |  |  |  | 72,739 |  |  |  | 111,017 |  |  |  | 174,711 |  |  |  | 69,142 |  |  |  | 105,569 |  |  |  | 108,743 |  |  |  | 51,179 |  |  |  | 57,564 |  |
| Total |  | $ | 922,720 |  |  | $ | 592,406 |  |  | $ | 330,314 |  |  | $ | 1,149,100 |  |  | $ | 816,037 |  |  | $ | 333,063 |  |  | $ | 1,025,536 |  |  | $ | 698,284 |  |  | $ | 327,252 |  |

[0000950170-25-031056:notes:383]
For the years ended December 31, 2024, 2023 and 2022, $6.1 million, $6.5 million and $3.2 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the years ended December 31, 2024, 2023 and 2022, $0.1 million, $20 thousand and $10 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0000950170-25-031056:notes:384]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN, Inc. reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, the Company has recast these revenues such that ADTRAN, Inc’s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks solutions to create Access & Aggregation Solutions, Adtran’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions was added as a new revenue category to represent a meaningful portion of Adtran Networks' portfolio.

[0000950170-25-031056:notes:385]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at customers' premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

[0000950170-25-031056:notes:386]
The following tables disaggregate our revenue by category for the years ended December 31, 2024, 2023 and 2022:

[0000950170-25-031056:notes:387]
|  |  | 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 295,541 |  |  | $ | 35,237 |  |  | $ | 330,778 |  |
| Access & Aggregation Solutions |  |  | 232,934 |  |  |  | 58,072 |  |  |  | 291,006 |  |
| Optical Networking Solutions |  |  | 210,489 |  |  |  | 90,447 |  |  |  | 300,936 |  |
| Total |  | $ | 738,964 |  |  | $ | 183,756 |  |  | $ | 922,720 |  |

[0000950170-25-031056:notes:388]
|  |  | 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 263,192 |  |  | $ | 34,516 |  |  | $ | 297,708 |  |
| Access & Aggregation Solutions |  |  | 304,074 |  |  |  | 54,344 |  |  |  | 358,418 |  |
| Optical Networking Solutions |  |  | 407,123 |  |  |  | 85,851 |  |  |  | 492,974 |  |
| Total |  | $ | 974,389 |  |  | $ | 174,711 |  |  | $ | 1,149,100 |  |

[0000950170-25-031056:notes:389]
|  |  | 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 364,238 |  |  | $ | 26,216 |  |  | $ | 390,454 |  |
| Access & Aggregation Solutions |  |  | 326,934 |  |  |  | 47,068 |  |  |  | 374,002 |  |
| Optical Networking Solutions |  |  | 225,621 |  |  |  | 35,459 |  |  |  | 261,080 |  |
| Total |  | $ | 916,793 |  |  | $ | 108,743 |  |  | $ | 1,025,536 |  |

[0000950170-25-031056:notes:390]
Additional Information

[0000950170-25-031056:notes:391]
The following table presents revenue information by geographic area for the years ended December 31, 2024, 2023 and 2022:

[0000950170-25-031056:notes:392]
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| United States |  | $ | 398,170 |  |  | $ | 460,985 |  |  | $ | 517,433 |  |
| United Kingdom |  |  | 196,064 |  |  |  | 214,655 |  |  |  | 189,685 |  |
| Germany |  |  | 119,976 |  |  |  | 230,922 |  |  |  | 146,797 |  |
| Other international |  |  | 208,510 |  |  |  | 242,538 |  |  |  | 171,621 |  |
| Total |  | $ | 922,720 |  |  | $ | 1,149,100 |  |  | $ | 1,025,536 |  |

[0000950170-25-031056:notes:393]
Customers comprising more than 10% of revenue can change from year to year. The Company had one customer comprising more than 10% of revenue in 2024 at 12.1% and was included in both our Network Solutions and Services & Support segments. This customer accounted for $111.8 million, $126.0 million and $106.3 million in revenues for the years ended December 31, 2024, 2023 and 2022, respectively. Single customers comprising more than 10% of revenue in 2023 included one customer at 10.4% and was included in both our Network Solutions and Services & Support segments. Single customers comprising more than 10% of revenue in 2022 included one customer at 18% and was included in both our Network Solutions and Services & Support segments. Other than those with more than 10% of revenue disclosed above, our next five largest customers can change, and have historically changed, from year-to-year. The next five largest customers combined represented 22%, 28% and 33% of total revenue in 2024, 2023 and 2022, respectively.

[0000950170-25-031056:notes:394]
As of December 31, 2024, property, plant and equipment, net totaled $102.9 million, which included $46.3 million held in the U.S. and $56.6 million held outside the U.S. As of December 31, 2023, property, plant and equipment, net totaled $113.6 million, which included

[0000950170-25-031056:notes:395]
$55.1 million held in the U.S. and $58.5 million held outside the U.S. Property, plant and equipment, net is reported on a Company-wide, functional basis only.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-25-031056:notes:396]
Note 17 – Liability for Warranty Returns

[0000950170-25-031056:notes:397]
The liability for warranty obligations totaled $4.5 million and $6.4 million as of December 31, 2024 and 2023, respectively. These liabilities are included in accrued expenses and other liabilities and other non-current liabilities in the accompanying Consolidated Balance Sheets.

[0000950170-25-031056:notes:398]
A summary of warranty expense and write-off activity for the years ended December 31, 2024, 2023 and 2022 is as follows:

[0000950170-25-031056:notes:399]
|  |  | Year Ended December 31, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 6,445 |  |  | $ | 7,196 |  |  | $ | 5,403 |  |
| Plus: Adtran Networks acquisition |  |  | — |  |  |  | — |  |  |  | 3,756 |  |
| Plus: Amounts charged to cost and expenses |  |  | 1,772 |  |  |  | 2,952 |  |  |  | 3,104 |  |
| Plus: Foreign currency translation adjustments |  |  | (119 | ) |  |  | 82 |  |  |  | 334 |  |
| Less: Deductions |  |  | (3,586 | ) |  |  | (3,784 | ) |  |  | (5,401 | ) |
| Balance at end of period |  | $ | 4,512 |  |  | $ | 6,445 |  |  | $ | 7,196 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-25-031056:notes:400]
Note 18 – Commitments and Contingencies

[0000950170-25-031056:notes:401]
Legal Matters

[0000950170-25-031056:notes:402]
From time to time, the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. The Company records an accrual for any Legal Matters that arise whenever it considers that it is probable that it is exposed to a loss contingency and the amount of the loss contingency can be reasonably estimated. Although the ultimate disposition of asserted claims cannot be predicted with certainty, it is our belief that the outcome of any such claims, either individually or on a combined basis, will not have a material adverse effect on our consolidated financial position.

[0000950170-25-031056:notes:403]
DPLTA Appraisal Proceedings

[0000950170-25-031056:notes:404]
In addition to such Legal Matters, the Company is a party to appraisal proceedings relating to the DPLTA. The DPLTA provides that Adtran Networks shareholders (other than the Company) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest or (ii) to remain Adtran Networks shareholders and receive recurring cash compensation of €0.52 per share for each full fiscal year of Adtran Networks. The appraisal proceedings, which were initiated by certain minority shareholders of Adtran Networks, challenge the adequacy of both forms of compensation. While the Company believes that the compensation offered in connection with the DPLTA is fair, it notes that German courts often adjudicate increases of the cash compensation to plaintiffs in varying amounts in connection with German appraisal proceedings. Therefore, the Company cannot rule out that the first instance court or an appellate court may increase the cash compensation owed to the minority Adtran Networks shareholders. Given the stage of the appraisal proceedings, the Company is currently unable to predict the likely outcome or estimate the potential financial impact, if any, of the appraisal proceedings. If a ruling were to occur and be upheld upon appeal that required the Company to pay significant additional cash compensation to the Adtran Networks minority shareholders, there exists the possibility of a material adverse effect on our financial position and results of operations for the period in which the ruling occurs or future periods.

[0000950170-25-031056:notes:405]
DPLTA Exit and Recurring Compensation Costs and the Absorption of Adtran Network's Annual Net Loss

[0000950170-25-031056:notes:406]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.37% as of December 31, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €333.2 million or approximately $344.9 million, based on an exchange rate as of December 31, 2024 and reflecting interest accrued through December 31, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second

[0000950170-25-031056:notes:407]
option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-25-031056:notes:408]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million (or $9.3 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024.With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholders meeting is scheduled for June 27, 2025 and, therefore, the Annual Recurring Compensation will be due on July 2, 2025. During the year ended December 31, 2024 and 2023, we accrued $9.8 million and $10.1 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

[0000950170-25-031056:notes:409]
For the year ended December 31, 2024, approximately 831 thousand shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the year ended December 31, 2023, 67 thousand shares, respectively, of Adtran Networks shares were tendered to the Company. This resulted in Exit Compensation payments of approximately €1.2 million, respectively, or approximately $1.3 million, based on an exchange rate as of December 31, 2023, being paid to Adtran Networks shareholders.

[0000950170-25-031056:notes:410]
In addition, under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applied for the first time to the net loss generated in 2023.

[0000950170-25-031056:notes:411]
Performance Bonds

[0000950170-25-031056:notes:412]
Certain contracts, customers and jurisdictions in which the Company do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2024 and December 31, 2023, the Company had commitments related to these bonds totaling $15.7 million and $10.8 million, respectively, which expire at various dates through April 2029. In general the Company would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which the Company believes is remote.

[0000950170-25-031056:notes:413]
Purchase Obligations

[0000950170-25-031056:notes:414]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for short-term product manufacturing requirements, as well as for obligations to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of December 31, 2024, purchase obligations totaled $202.5 million.


## us-gaap:EarningsPerShareTextBlock

[0000950170-25-031056:notes:415]
Note 19 – Loss per Share

[0000950170-25-031056:notes:416]
The calculations of basic and diluted loss per share for the years ended December 31, 2024, 2023 and 2022 are as follows:

[0000950170-25-031056:notes:417]
| (In thousands, except for per share amounts) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Numerator |  |  |  |  |  |  |  |  |  |
| Net loss attributable to ADTRAN Holdings, Inc. |  | $ | (450,872 | ) |  | $ | (266,289 | ) |  | $ | (2,037 | ) |
| Effect of redemption of RNCI |  |  | 2,981 |  |  |  | — |  |  |  | — |  |
| Net loss attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | (447,891 | ) |  | $ | (266,289 | ) |  | $ | (2,037 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 78,928 |  |  |  | 78,416 |  |  |  | 62,346 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 78,928 |  |  |  | 78,416 |  |  |  | 62,346 |  |
| Loss per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (5.67 | ) |  | $ | (3.39 | ) |  | $ | (0.03 | ) |
| Loss per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (5.67 | ) |  | $ | (3.39 | ) |  | $ | (0.03 | ) |

[0000950170-25-031056:notes:418]
For each of the years ended December 31, 2024, 2023 and 2022, less than 0.8 million, 0.5 million and 0.1 million shares of unvested or unearned, as applicable, PSUs, RSUs and restricted stock were excluded from the calculation of diluted loss per share due to their anti-dilutive effect.

[0000950170-25-031056:notes:419]
For the years ended December 31, 2024, 2023 and 2022, 3.4 million, 1.8 million and 0.2 million stock options, respectively, were outstanding but were not included in the computation of diluted loss per share due to their exercise prices being greater than the average market price of the common shares during the quarter, making them anti-dilutive under the treasury stock method.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-25-031056:notes:420]
Note 20 – Restructuring

[0000950170-25-031056:notes:421]
During the fourth quarter of 2022, the Company initiated a restructuring program designed to optimize the assets, business processes, and information technology systems of the Company in relation to the Business Combination with Adtran Networks. The restructuring program included expenses specifically associated with achieving run-rate synergies as well as Business Efficiency Program expenses described below.

[0000950170-25-031056:notes:422]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a business efficiency program (“Business Efficiency Program”) targeting the reduction of ongoing operating expenses and focusing on capital efficiency inclusive of certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the sale of owned real estate (including the sale of our headquarters), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program expanded upon other recently implemented restructuring efforts and synergy costs following the Business Combination. For instance, on August 17, 2023, the Company’s management determined to discontinue its copper-based Digital Subscriber Line broadband access technology products and its fixed wireless access products in its Network Solutions segment. Furthermore, on September 29, 2023, the Company’s management decided to exit the "IoT" gateway market (indoor and outdoor), a subset of the broader IoT market (together with the other product discontinuations, the “Discontinuations”). On October 25, 2023, all employees were informed of certain personnel measures, which included the reduction of salary for select management, a reduction of approximately 5% of the workforce, an early retirement program and a hiring freeze. Additionally, on April 11, 2024, Management determined to close a facility in Greifswald, Germany which occurred in November 2024. As of December 31, 2024, the Company classified the Company's property, specifically the North and South Towers located on our Huntsville, Alabama campus, as assets held for sale, see Note 1 and Note 6 of this report for additional information. The Business Efficiency Program was substantially complete as of December 31, 2024.

[0000950170-25-031056:notes:423]
During the years ended December 31, 2024 and 2023, we recognized $44.7 million and $25.1 of costs related to the Business Efficiency Program. The costs recognized during the year ended December 31, 2024, included total other renegotiated charges and inventory write-down of $8.6 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business

[0000950170-25-031056:notes:424]
Efficiency Program, of which, $4.1 million relates to inventory write-downs and $4.5 million relates to other charges, and are included in cost of revenue in the Consolidated Statements of Loss.

[0000950170-25-031056:notes:425]
For the years ended December 31, 2023 and 2022, we recognized $21.5 million and $1.6 million of restructuring costs relating to the Business Combination under the multi-year integration program and synergy realization, respectively, that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statement of Loss.

[0000950170-25-031056:notes:426]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits and accrued expenses and other liabilities in the Consolidated Balance Sheets as of December 31, 2024 and 2023, is as follows:

[0000950170-25-031056:notes:427]
| (In thousands) |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 8,309 |  |  | $ | 159 |  |
| Plus: Amounts charged to cost and expense |  |  | 40,545 |  |  |  | 22,241 |  |
| Less: Amounts paid |  |  | (38,518 | ) |  |  | (14,091 | ) |
| Balance at end of period |  | $ | 10,336 |  |  | $ | 8,309 |  |

[0000950170-25-031056:notes:428]
Restructuring expenses included in the Consolidated Statements of Loss are for the years ended December 31, 2024, 2023 and 2022:

[0000950170-25-031056:notes:429]
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Network solutions - cost of revenue |  | $ | 3,693 |  |  | $ | 2,910 |  |  | $ | 8 |  |
| Network solutions - inventory write-down |  |  | 8,597 |  |  |  | 24,313 |  |  |  | — |  |
| Services & support - cost of revenue |  |  | 2,289 |  |  |  | — |  |  |  | — |  |
| Cost of revenue |  | $ | 14,579 |  |  | $ | 27,223 |  |  | $ | 8 |  |
| Selling, general and administrative expenses |  |  | 9,128 |  |  |  | 11,603 |  |  |  | 117 |  |
| Research and development expenses |  |  | 20,973 |  |  |  | 7,728 |  |  |  | 1,504 |  |
| Total restructuring expenses |  | $ | 44,680 |  |  | $ | 46,554 |  |  | $ | 1,629 |  |

[0000950170-25-031056:notes:430]
The following table represents the components of restructuring expense by geographic area for the years ended December 31, 2024, 2023 and 2022:

[0000950170-25-031056:notes:431]
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| United States |  | $ | 18,422 |  |  | $ | 34,629 |  |  | $ | 2 |  |
| International |  |  | 26,258 |  |  |  | 11,925 |  |  |  | 1,627 |  |
| Total restructuring expenses |  | $ | 44,680 |  |  | $ | 46,554 |  |  | $ | 1,629 |  |


## us-gaap:CreditLossFinancialInstrumentTextBlock

[0000950170-25-031056:notes:432]
Note 21 – Current Expected Credit Losses

[0000950170-25-031056:notes:433]
Under ASC 326 – Financial Instruments – Credit Losses, the Company estimates credit losses for the contractual life of assets that are measured at amortized cost and are within the scope of this guidance, which includes accounts receivable, net investment in sales-type leases, contract assets under the revenue recognition model and outstanding notes receivable. Where appropriate, the Company pools assets if similar risk characteristics exist. Additionally, the Company analyzes its available-for-sale debt securities for impairment and records a credit loss allowance as needed.

[0000950170-25-031056:notes:434]
Assets Measured at Amortized Cost

[0000950170-25-031056:notes:435]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. Accounts receivable balances are considered past due when payment has not been received by the date indicated on the relevant invoice or based on agreed upon terms between the customer and the Company. As of December 31, 2024 and 2023, the Company’s net outstanding accounts receivable balance was $178.0 million and $216.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The Company’s historical losses related to accounts receivable have been immaterial as evidenced by its historical allowance and write-offs due to collectability. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer

[0000950170-25-031056:notes:436]
specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0000950170-25-031056:notes:437]
Credit losses totaling $1.3 million and $0.4 million were recorded for the years ended December 31, 2024 and 2023, respectively, related to accounts receivable.

[0000950170-25-031056:notes:438]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of December 31, 2024 and 2023, the Company’s outstanding contract asset balance was $0.6 million and $0.7 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0000950170-25-031056:notes:439]
No allowance for credit losses was recorded for the years ended December 31, 2024 and 2023 related to contract assets.

[0000950170-25-031056:notes:440]
Off-Balance Sheet Arrangements

[0000950170-25-031056:notes:441]
We have exposure to credit losses from off-balance sheet exposures, to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of December 31, 2024 and 2023, respectively. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 18 of the Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report for additional information.

[0000950170-25-031056:notes:442]
Available-for-Sale Debt Securities

[0000950170-25-031056:notes:443]
As of December 31, 2024 and 2023 the Company had sold all available-for-sale debt securities.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000950170-25-031056:notes:444]
SCHEDULE II

[0000950170-25-031056:notes:445]
VALUATION AND QUALIFYING ACCOUNTS

[0000950170-25-031056:notes:446]
| (In thousands) |  | Balance atBeginningof Period |  |  | Charged toCosts &Expenses |  |  | Deductions |  |  | Balance atEnd ofPeriod |  |
| Year ended December 31, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 400 |  |  |  | 900 |  |  |  | — |  |  | $ | 1,300 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 86,567 |  |  |  | 24,483 |  |  |  | 90 |  |  | $ | 110,960 |  |
| Year ended December 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 49 |  |  |  | 351 |  |  |  | — |  |  | $ | 400 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 5,201 |  |  |  | 81,590 |  |  |  | 224 |  |  | $ | 86,567 |  |
| Year ended December 31, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | — |  |  |  | 49 |  |  |  | — |  |  | $ | 49 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 50,564 |  |  |  | — |  |  |  | 45,363 |  |  | $ | 5,201 |  |
