# ADTN 10-K controls and the auditor's report


## auditors_report

[0000950170-25-031056:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000950170-25-031056:auditors_report:2]
To the Board of Directors and Stockholders of ADTRAN Holdings, Inc.

[0000950170-25-031056:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000950170-25-031056:auditors_report:4]
We have audited the accompanying consolidated balance sheets of ADTRAN Holdings, Inc. and its subsidiaries (the "Company") as of December 31, 2024 and 2023, and the related consolidated statements of loss, of comprehensive (loss) income, of changes in equity and of cash flows for each of the three years in the period ended December 31, 2024, including the related notes and financial statement schedule listed in the accompanying index (collectively referred to as the "consolidated financial statements"). We also have audited the Company's internal control over financial reporting as of December 31, 2024, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000950170-25-031056:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2024 and 2023, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2024 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company did not maintain, in all material respects, effective internal control over financial reporting as of December 31, 2024, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO because material weaknesses in internal control over financial reporting existed as of that date related to the Company not (i) designing and maintaining effective controls in response to the risks of material misstatement; (ii) designing and maintaining effective controls over financial statement preparation, presentation and disclosure commensurate with its financial reporting requirements; and (iii) designing and maintaining effective controls to address the initial application of complex accounting standards and accounting of non-routine, unusual or complex events and transactions.

[0000950170-25-031056:auditors_report:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weaknesses referred to above are described in Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. We considered these material weaknesses in determining the nature, timing, and extent of audit tests applied in our audit of the 2024 consolidated financial statements, and our opinion regarding the effectiveness of the Company’s internal control over financial reporting does not affect our opinion on those consolidated financial statements.

[0000950170-25-031056:auditors_report:7]
Basis for Opinions

[0000950170-25-031056:auditors_report:8]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in management's report referred to above. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000950170-25-031056:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000950170-25-031056:auditors_report:10]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000950170-25-031056:auditors_report:11]
Definition and Limitations of Internal Control over Financial Reporting

[0000950170-25-031056:auditors_report:12]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in

[0000950170-25-031056:auditors_report:13]
accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000950170-25-031056:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000950170-25-031056:auditors_report:15]
Critical Audit Matters

[0000950170-25-031056:auditors_report:16]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0000950170-25-031056:auditors_report:17]
Valuation of Inventory – Estimate of Certain Excess and Obsolete Reserves

[0000950170-25-031056:auditors_report:18]
As described in Notes 1 and 5 to the consolidated financial statements, the Company’s consolidated net inventory as of December 31, 2024 was $269.3 million, of which certain inventory is subject to certain excess and obsolete reserves. Management establishes reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age, and market conditions.

[0000950170-25-031056:auditors_report:19]
The principal considerations for our determination that performing procedures relating to the valuation of inventory – estimate of certain excess and obsolete reserves is a critical audit matter are (i) the significant judgment by management when developing the estimate of certain excess and obsolete inventory reserves and (ii) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s significant assumption related to the estimated reserve percentages.

[0000950170-25-031056:auditors_report:20]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to certain excess and obsolete inventory reserves, including controls over the significant assumption related to estimated reserve percentages. These procedures also included, among others (i) testing management’s process for developing the estimate of certain excess and obsolete inventory reserves; (ii) evaluating the appropriateness of management’s estimation methodology; (iii) testing the completeness and accuracy of the underlying data used in developing the estimate of certain excess and obsolete inventory reserves, including historical usage, known trends, and inventory age; and (iv) evaluating the reasonableness of the significant assumption used by management related to the estimated reserve percentages. Evaluating management’s assumption related to the estimated reserve percentages involved considering (i) the current and past results of the Company; (ii) a comparison of the prior year estimate to actual activity in the current year; and (iii) whether the assumption was consistent with evidence obtained in other areas of the audit.

[0000950170-25-031056:auditors_report:21]
Accounts Receivable Factoring

[0000950170-25-031056:auditors_report:22]
As described in Notes 1 and 2 to the consolidated financial statements, on July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection. Total accounts receivables factored as of December 31, 2024 totaled $18.3 million, of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account.  These transactions result in a reduction in accounts receivable because the Factoring Agreement transfers effective control and risk related to the receivables to the buyers. On each sale date, the Factor retains from the sale price a default reserve, up to a required balance, which is held by the Factor in a reserve account and pledged to the Company. The Factor is entitled to withdraw from the reserve account the sale price of a defaulted receivable.

[0000950170-25-031056:auditors_report:23]
The principal considerations for our determination that performing procedures relating to the accounts receivable factoring is a critical audit matter are a high degree of auditor effort in performing procedures and evaluating audit evidence related to evaluating the Factoring Agreement. As described in the “Opinions on the Financial Statements and Internal Control over Financial Reporting” section, a material weakness was identified related to this matter.

[0000950170-25-031056:auditors_report:24]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included, among others (i) reading the Factoring Agreement; (ii) evaluating management’s assessment that the transactions under the Factoring Agreement were appropriately accounted for; (iii) confirming the accounts receivables factored as of December 31, 2024 with the Factor; (iv) testing the classification of accounts receivable factored, including whether balances have been properly excluded from the accounts receivable balance as of December 31, 2024; and (v) evaluating the sufficiency of the disclosures in the consolidated financial statements.

[0000950170-25-031056:auditors_report:25]
Interim Goodwill and Asset Group Impairment Assessments – Network Solutions Reporting Unit and Asset Group

[0000950170-25-031056:auditors_report:26]
As described in Notes 1, 8, and 9 to the consolidated financial statements, the Company’s goodwill balance was $52.9 million as of December 31, 2024, and the goodwill associated with the Network Solutions reporting unit was $0 million. The Company’s long-lived assets, such as property, plant and equipment, right of use lease assets, and purchased intangibles subject to amortization were $418.2 million as of December 31, 2024, and the long-lived assets associated with the Network Solutions asset group were $358.6 million. Goodwill is tested by management for impairment annually during the fourth quarter and reviewed for impairment if an event occurs or circumstances change that would more likely than not reduce the fair value of the reporting units below their carrying amount. Long lived assets are reviewed by management for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. During the first quarter of 2024, management identified factors triggering a quantitative impairment assessment for the Company’s reporting units and Network Solutions asset group, resulting in a $292.6 million goodwill impairment charge for the Network Solutions reporting unit. Management determined the fair value of the Network Solutions reporting unit using a combination of an income approach and a market approach. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of an asset to estimated undiscounted future cash flows expected to be generated by the asset group. The significant inputs and assumptions used in the determination of the fair value of the reporting unit requires significant judgment and the use of estimates and assumptions related to revenue growth rates, earnings before interest, taxes, depreciation and amortization (“EBITDA”) margins, discount rate, peer group determination, and revenue and EBITDA market multiples. The significant inputs and assumptions used in the determination of the cash flows expected to be generated by the asset group requires significant judgment and the use of estimates and assumptions related to revenue growth rates, EBITDA margins, peer group determination, and disposition exit multiple.

[0000950170-25-031056:auditors_report:27]
The principal considerations for our determination that performing procedures relating to the interim goodwill and asset group impairment assessments of the Network Solution reporting unit and asset group is a critical audit matter are (i) the significant judgment by management when developing the fair value estimate of the Network Solutions reporting unit and when developing the cash flows expected to be generated by the Network Solutions asset group; (ii) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s significant assumptions related to (a) revenue growth rates and EBITDA margins for the Network Solutions reporting unit and asset group, (b) revenue and EBITDA market multiples for the Network Solutions reporting unit, and (c) disposition exit multiple for the Network Solutions asset group (collectively, the “aforementioned assumptions”); and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0000950170-25-031056:auditors_report:28]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to management’s goodwill and asset group impairment assessments, including controls over the valuation of the Network Solutions reporting unit and asset group. These procedures also included, among others (i) testing management’s process for developing the fair value estimate of the Network Solutions reporting unit and for developing the cash flows expected to be generated by the Network Solutions asset group; (ii) evaluating the appropriateness of the income approach, market approach, and undiscounted future cash flows approach used by management; (iii) testing the completeness and accuracy of underlying data used by management in the income approach, market approach, and undiscounted future cash flows approach; and (iv) evaluating the reasonableness of the significant assumptions used by management related to the aforementioned assumptions. Evaluating management’s assumptions related to revenue growth rates and EBITDA margins for the Network Solutions reporting unit and asset group involved evaluating whether the assumptions used by management were reasonable considering (i) the current and past performance of the Network Solutions reporting unit and asset group; (ii) the consistency with external market and industry data; and (iii) whether the assumptions were consistent with evidence obtained in other areas of the audit. Professionals with specialized skill and knowledge were used to assist in evaluating (i) the appropriateness of the income approach, market approach, and undiscounted future cash flows approach and (ii) the reasonableness of the revenue and EBITDA market multiples assumptions for the Network Solutions reporting unit and disposition exit multiple assumption for the Network Solutions asset group.

[0000950170-25-031056:auditors_report:29]
/s/ PricewaterhouseCoopers LLP

[0000950170-25-031056:auditors_report:30]
Birmingham, Alabama

[0000950170-25-031056:auditors_report:31]
March 3, 2025

[0000950170-25-031056:auditors_report:32]
We have served as the Company’s auditor since 1986.

[0000950170-25-031056:auditors_report:33]
Financial Statements

[0000950170-25-031056:auditors_report:34]
ADTRAN Holdings, Inc.


## item_9a

[0000950170-25-031056:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0000950170-25-031056:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000950170-25-031056:item_9a:3]
We maintain disclosure controls and procedures that are designed to ensure that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000950170-25-031056:item_9a:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e)) under the Exchange Act. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that due to the material weaknesses in our internal control over financial reporting described below, our disclosure controls and procedures were not effective as of December 31, 2024.

[0000950170-25-031056:item_9a:5]
Management's Report on Internal Control over Financial Reporting

[0000950170-25-031056:item_9a:6]
Management of ADTRAN Holdings, Inc. (“Adtran”) is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act. Adtran’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Adtran’s internal control over financial reporting includes those policies and procedures that:

[0000950170-25-031056:item_9a:7]
•
pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of Adtran;

[0000950170-25-031056:item_9a:8]
•
provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of Adtran are being made only in accordance with authorizations of management and directors of Adtran; and

[0000950170-25-031056:item_9a:9]
•
provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of Adtran’s assets that could have a material effect on the financial statements.

[0000950170-25-031056:item_9a:10]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000950170-25-031056:item_9a:11]
Management assessed the effectiveness of Adtran’s internal control over financial reporting as of December 31, 2024. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO") in Internal Control-Integrated Framework (2013).

[0000950170-25-031056:item_9a:12]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. In its assessment of the effectiveness of internal control over financial reporting as of December 31, 2024, management determined that there were deficiencies in Adtran’s internal control over financial reporting that constituted material weaknesses that existed as of December 31, 2024. Such material weaknesses were as follows:

[0000950170-25-031056:item_9a:13]
•
Adtran did not design and maintain effective controls in response to the risks of material misstatement. Specifically, changes to existing controls or the implementation of new controls have not been sufficient to respond to changes to the risks of material misstatement to financial reporting. This material weakness contributed to the following additional material weaknesses:

[0000950170-25-031056:item_9a:14]
•
Adtran did not design and maintain effective controls over financial statement preparation, presentation and disclosure commensurate with its financial reporting requirements. Specifically, Adtran did not design and maintain effective controls over the presentation and disclosure of transactions, including non-controlling interest.

[0000950170-25-031056:item_9a:15]
•
Adtran did not design and maintain effective controls to address the initial application of complex accounting standards and accounting of non-routine, unusual or complex events and transactions. Specifically, Adtran did not design and maintain

[0000950170-25-031056:item_9a:16]
123

[0000950170-25-031056:item_9a:17]
effective controls to timely analyze and account for (i) non-controlling interest and (ii) the receivable purchase and servicing agreement.

[0000950170-25-031056:item_9a:18]
The material weaknesses resulted in the restatements and revisions of immaterial adjustments to our consolidated financial statements for the years ended December 31, 2022, and December 31, 2023, as well as the condensed consolidated financial statements for the quarterly and year-to-date periods ended September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024, and June 30, 2024. The material weaknesses also resulted in material adjustments to our consolidated financial statements for the year ended December 31, 2023. The material weaknesses also resulted in immaterial adjustments to our consolidated financial statements for the years ended December 31, 2023 and December 31, 2024, as well as the condensed consolidated financial statements for the quarterly and year-to-date periods ended March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024, June 30, 2024, and September 30, 2024. Additionally, these material weaknesses could result in misstatements of Adtran’s accounts or disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0000950170-25-031056:item_9a:19]
Because of these material weaknesses, management has concluded that Adtran did not maintain effective internal control over financial reporting as of December 31, 2024.

[0000950170-25-031056:item_9a:20]
The effectiveness of Adtran's internal control over financial reporting as of December 31, 2024 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which appears in Item 8.

[0000950170-25-031056:item_9a:21]
Management’s Remediation Efforts

[0000950170-25-031056:item_9a:22]
To remediate the material weaknesses in Adtran’s internal control over financial reporting related to the risks of material misstatement, including financial statement preparation, presentation and disclosure of transactions and the non-controlling interest, Adtran has implemented a remediation plan that involves introducing new or enhanced controls over the review of Adtran's consolidated financial statements, global identification and reassessment of all key process and controls, increased training and awareness of control activities, and increased scrutiny on control performance and documentation standards. Adtran believes that the foregoing actions will support the improvement of the Company’s internal control over financial reporting, and, through our efforts to identify, design, and implement the necessary control activities, will be effective in remediating such material weaknesses.

[0000950170-25-031056:item_9a:23]
To remediate the material weaknesses in Adtran’s internal control over financial reporting relating to accounting of non-routine, unusual or complex events and transactions for non-controlling interest and the receivable purchase and servicing agreement, Adtran has prepared a remediation plan that included designing and implementing new controls over the identification and review of contracts, transactions or arrangements that may result in a financial obligation including the use of an accounting third-party consultant as needed to ensure proper presentation of these items within our financial statements. These controls have been in place since the third quarter of 2024.

[0000950170-25-031056:item_9a:24]
We have implemented the above-referenced controls and are in the process of testing their effectiveness. We will continue to devote significant time and attention to these remediation efforts. Adtran continues to evaluate and work to improve our internal control over financial reporting, management may decide to take additional measures to address the material weaknesses or determine to modify the remediation plans described above. Until the remediation steps set forth above, including the implementation of all necessary control activities that we identify, are fully completed, and there has been time for us to conclude through testing that the control activities are operating effectively, the material weaknesses described above will not be considered remediated.

[0000950170-25-031056:item_9a:25]
Changes in Internal Control over Financial Reporting.

[0000950170-25-031056:item_9a:26]
There were no changes in Adtran’s internal control over financial reporting that occurred during the most recent fiscal quarter covered by this report that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.
