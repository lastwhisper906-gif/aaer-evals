# ADTN 10-K controls and the auditor's report


## auditors_report

[0001564590-21-009423:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001564590-21-009423:auditors_report:2]
To the Board of Directors and Stockholders of ADTRAN, Inc.

[0001564590-21-009423:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001564590-21-009423:auditors_report:4]
We have audited the accompanying consolidated balance sheets of ADTRAN, Inc.  and its subsidiaries (the “Company”) as of December 31, 2020 and 2019, and the related consolidated statements of income (loss), of comprehensive income (loss), of changes in stockholders’ equity and of cash flows for each of the three years in the period ended December 31, 2020, including the related notes and financial statement schedule listed in the accompanying index (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of December 31, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001564590-21-009423:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2020 and 2019, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2020 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001564590-21-009423:auditors_report:6]
Basis for Opinions

[0001564590-21-009423:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-21-009423:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001564590-21-009423:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001564590-21-009423:auditors_report:10]
Definition and Limitations of Internal Control over Financial Reporting

[0001564590-21-009423:auditors_report:11]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001564590-21-009423:auditors_report:12]
51

[0001564590-21-009423:auditors_report:13]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001564590-21-009423:auditors_report:14]
Critical Audit Matters

[0001564590-21-009423:auditors_report:15]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001564590-21-009423:auditors_report:16]
Excess and Obsolete Inventory Reserve

[0001564590-21-009423:auditors_report:17]
As described in Note 7 to the consolidated financial statements, the Company’s consolidated net inventory and inventory reserve as of December 31, 2020 were $125.5 million and $39.6 million, respectively. Management establishes reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age, and market conditions.

[0001564590-21-009423:auditors_report:18]
The principal considerations for our determination that performing procedures relating to the excess and obsolete inventory reserve is a critical audit matter are (i) the significant judgment by management in estimating the excess and obsolete inventory reserve, which in turn led to (ii) a high degree of auditor judgment, subjectivity and effort in performing procedures and evaluating management’s significant assumptions related to the estimated reserve percentages.

[0001564590-21-009423:auditors_report:19]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the excess and obsolete inventory reserve. These procedures also included, among others, testing management’s process for developing the excess and obsolete inventory reserve; evaluating the appropriateness of the approach; testing the completeness and accuracy of underlying data used in the approach, including historical usage and inventory age; and evaluating the reasonableness of the estimated reserve percentages used by management to determine the excess and obsolete inventory reserve. Evaluating the reasonableness of the estimated reserve percentages involved assessing whether they were consistent with the historical data and evidence obtained in other areas of the audit.

[0001564590-21-009423:auditors_report:20]
/s/ PricewaterhouseCoopers LLP

[0001564590-21-009423:auditors_report:21]
Birmingham, Alabama

[0001564590-21-009423:auditors_report:22]
February 26, 2021

[0001564590-21-009423:auditors_report:23]
We have served as the Company’s auditor since 1986.

[0001564590-21-009423:auditors_report:24]
52

[0001564590-21-009423:auditors_report:25]
Financial Statements

[0001564590-21-009423:auditors_report:26]
ADTRAN, INC.


## item_9a

[0001564590-21-009423:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES |

[0001564590-21-009423:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-21-009423:item_9a:3]
We maintain disclosure controls and procedures that are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure. Because of the inherent limitations to the effectiveness of any system of disclosure controls and procedures, no evaluation of disclosure controls and procedures can provide absolute assurance that all control issues, if any, with a company have been prevented or detected on a timely basis. Even disclosure controls and procedures determined to be effective can only provide reasonable assurance that their objectives are achieved.

[0001564590-21-009423:item_9a:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and our Chief Financial Officer, of the effectiveness of our disclosure controls and procedures, as such term is defined under Rule 13a-15(e) promulgated under the Exchange Act. Based on that evaluation, our Chief Executive Officer and our Chief Financial Officer concluded that our disclosure controls and procedures were effective at the reasonable assurance level.

[0001564590-21-009423:item_9a:5]
Internal Control over Financial Reporting.

[0001564590-21-009423:item_9a:6]
Section 404 of the Sarbanes-Oxley Act of 2002 requires management to include in our Annual Report on Form 10-K a report on management’s assessment of the effectiveness of our internal control over financial reporting, as well as a report from our independent registered public accounting firm on the effectiveness of our internal control over financial reporting. Management’s report on internal control over financial reporting is included below, and the related report from our independent registered public accounting firm is located in Part II, Item 8, “Financial Statements and Supplementary Data,” of this Annual Report on Form 10-K.

[0001564590-21-009423:item_9a:7]
Changes in Internal Control over Financial Reporting.

[0001564590-21-009423:item_9a:8]
During the fourth quarter of 2020, ADTRAN, Inc. began implementing a new enterprise resource planning (“ERP”) software solution. As of December 31, 2020, the Company was still reliant on its existing procedures and controls. The Company continues to work toward implementation of the new ERP system and expects to complete that process during 2021. There were no other changes in the Company’s internal control over financial reporting that occurred during the most recent fiscal quarter covered by this report that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.

[0001564590-21-009423:item_9a:9]
Management’s Report on Internal Control over Financial Reporting

[0001564590-21-009423:item_9a:10]
Management of ADTRAN, Inc. is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934, as amended. ADTRAN’s internal control over financial reporting is designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. ADTRAN’s internal control over financial reporting includes those policies and procedures that:

[0001564590-21-009423:item_9a:11]
|  | • | pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of ADTRAN; |

[0001564590-21-009423:item_9a:12]
|  | • | provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of ADTRAN are being made only in accordance with authorizations of management and directors of ADTRAN; and |

[0001564590-21-009423:item_9a:13]
|  | • | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of ADTRAN’s assets that could have a material effect on the financial statements. |

[0001564590-21-009423:item_9a:14]
98

[0001564590-21-009423:item_9a:15]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001564590-21-009423:item_9a:16]
Management assessed the effectiveness of ADTRAN’s internal control over financial reporting as of December 31, 2020. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in Internal Control-Integrated Framework (2013).

[0001564590-21-009423:item_9a:17]
Based on our assessment and those criteria, management has concluded that ADTRAN maintained effective internal control over financial reporting as of December 31, 2020.

[0001564590-21-009423:item_9a:18]
The effectiveness of the Company’s internal control over financial reporting as of December 31, 2020 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which appears in Item 8.
