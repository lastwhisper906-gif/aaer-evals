# ADTN notes — 0001564590-21-009423


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001564590-21-009423:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001564590-21-009423:notes:2]
Portions of the Proxy Statement for the Annual Meeting of Stockholders to be held on May 12, 2021 are incorporated herein by reference in Part III.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-21-009423:notes:3]
Note 1 – Nature of Business

[0001564590-21-009423:notes:4]
ADTRAN, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms and services focused on the broadband access market. Our vision is to enable a fully connected world where the power to communicate is available to everyone, everywhere. Our unique approach, unmatched industry expertise and innovative solutions enable us to address almost any customer need. Our products and services are utilized by a diverse global customer base of network operators that range from those having regional or national reach and operating as telephone or cable television network operators to alternative network providers such as municipalities or utilities, as well as, managed service providers who serve small- and medium-sized businesses and distributed enterprises.

[0001564590-21-009423:notes:5]
Principles of Consolidation

[0001564590-21-009423:notes:6]
The accompanying Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the U.S. (“U.S. GAAP”) and include the financial position, results of operations, comprehensive income (loss), changes in equity and cash flows of ADTRAN and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001564590-21-009423:notes:7]
Use of Estimates

[0001564590-21-009423:notes:8]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expenses during the reporting period. Our more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability, fair value of investments, evaluation of other-than-temporary declines in the value of investments and our allowance for current expected credit losses. Actual amounts could differ significantly from these estimates.

[0001564590-21-009423:notes:9]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of December 31, 2020 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, current estimated credit losses, stock-based compensation, excess and obsolete inventory reserves, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the year ended December 31, 2020 resulting from these assessments, future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

[0001564590-21-009423:notes:10]
Correction of Immaterial Misstatement

[0001564590-21-009423:notes:11]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of goods sold for the period. For the six and twelve months ended June 30, 2019 and December 31, 2019, respectively, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of goods sold. Management determined that the correction of this misstatement was not material to any of its previously issued financial statements on both a quantitative and qualitative basis.

[0001564590-21-009423:notes:12]
During the first quarter of 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out-of-period adjustment in the three months ended March 31, 2020 and the twelve months ended December 31, 2020, by remeasuring the investment assets to their historical cost basis through the recording of a net investment gain of $1.5 million in the Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the long-term investment balance at its remeasured cost basis of $2.8 million to treasury stock in the Consolidated 2020 Balance Sheet. Management has determined that this misstatement was not material to any of its previously issued financial statements and that correction of the misstatement was not material to the 2020 annual financial results on either a quantitative or qualitative basis.

[0001564590-21-009423:notes:13]
Summary of Significant Accounting Policies

[0001564590-21-009423:notes:14]
Cash and Cash Equivalents

[0001564590-21-009423:notes:15]
Cash and cash equivalents represent demand deposits, money market funds and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. As of December 31, 2020, $56.3 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions and determined the risk of material financial loss due to the exposure of such credit risk to be minimal.

[0001564590-21-009423:notes:16]
Restricted Cash

[0001564590-21-009423:notes:17]
Restricted cash consists of certain collateral which secures the Company’s performance obligation under a contract with a certain customer.

[0001564590-21-009423:notes:18]
Financial Instruments

[0001564590-21-009423:notes:19]
The carrying amounts reported in the Consolidated Balance Sheets for cash and cash equivalents, accounts receivable, and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments. The carrying amount reported for bonds payable was $24.6 million, which was its fair value as of December 31, 2019.

[0001564590-21-009423:notes:20]
Investments with contractual maturities beyond one year may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe we have the ability to quickly sell them to the remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. All income generated from these investments is recorded as interest income. We have not recorded any losses relating to variable rate demand notes.

[0001564590-21-009423:notes:21]
Long-term investments is comprised of deferred compensation plan assets, corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. and foreign government bonds, marketable equity securities and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Any changes in fair value are recognized in net investment gain (loss). Realized gains and losses on sales of debt securities are computed under the specific identification method and are included in other income (expense). See Note 6 for additional information.

[0001564590-21-009423:notes:22]
Accounts Receivable

[0001564590-21-009423:notes:23]
We record accounts receivable at net realizable value. Prior to establishing payment terms for a new customer, we evaluate the credit risk of the customer. Credit limits and payment terms established for new customers are re-evaluated periodically based on customer collection experience and other financial factors. As of December 31, 2020, single customers comprising more than 10% of our total accounts receivable balance included three customers, which accounted for 41.5% of our total accounts receivable. As of December 31, 2019, single customers comprising more than 10% of our total accounts receivable balance included four customers, which accounted for 53.2% of our total accounts receivable.

[0001564590-21-009423:notes:24]
On January 1, 2020, we adopted ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.

[0001564590-21-009423:notes:25]
Accounting Policy Under Topic 326

[0001564590-21-009423:notes:26]
We regularly review the need for an allowance for credit losses related to our outstanding accounts receivable balances using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition or credit rating by geographic location, as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. Based on this assessment, an allowance for credit loss would be recorded if the Company determined that, based on our historical write-offs, which have been immaterial, and such asset specific risks, there was risk in collectability of the full amount of any accounts receivable.

[0001564590-21-009423:notes:27]
Accounting Policy Prior to Adoption of Topic 326

[0001564590-21-009423:notes:28]
Prior to adoption of Topic 326 on January 1, 2020, we regularly reviewed the need to maintain an allowance for doubtful accounts and considered factors such as the age of accounts receivable balances, the current economic conditions that may affect a customer’s ability to pay, significant one-time events impacting these customers and our historical experience. If the financial condition of a customer deteriorated, resulting in an impairment of their ability to make payments, we may have been required to record an allowance for doubtful accounts.

[0001564590-21-009423:notes:29]
Inventory

[0001564590-21-009423:notes:30]
Inventory is carried at the lower of cost and estimated net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory and are updated at least quarterly. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 7 for additional information.

[0001564590-21-009423:notes:31]
Property, Plant and Equipment

[0001564590-21-009423:notes:32]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. We depreciate building and land improvements from five to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years, and computer software from three to five years. Expenditures for repairs and maintenance are charged to expense as incurred. Major improvements that materially prolong the lives of the assets are capitalized. Gains and losses on the disposal of property, plant and equipment are recorded in operating income (loss). See Note 8 for additional information.

[0001564590-21-009423:notes:33]
Intangible Assets

[0001564590-21-009423:notes:34]
Purchased intangible assets with finite lives are carried at cost less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets, which is two to 14 years. See Note 11 for additional information.

[0001564590-21-009423:notes:35]
Impairment of Long-Lived Assets and Intangibles

[0001564590-21-009423:notes:36]
Long-lived assets used in operations and intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. An impairment loss would be recognized in the amount by which the recorded value of the asset exceeds the fair value of the asset, measured by the quoted market price of an asset or an estimate based on the best information available in the circumstances. During the years ended December 31, 2020 and December 31, 2019, we recognized an impairment loss of less than $0.1 million and $3.9 million, respectively, related to the abandonment of certain information technology implementation projects for which we had previously capitalized expenses. There were no impairment losses for long-lived assets during the year ended December 31, 2018, or for intangible assets recognized during the years ended December 31, 2020, 2019 or 2018.

[0001564590-21-009423:notes:37]
Goodwill

[0001564590-21-009423:notes:38]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to by-pass a qualitative assessment to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount and, in turn, performed a step-1 analysis of goodwill. No impairment charges related to goodwill were recognized during the years ended December 31, 2020, 2019 and 2018.

[0001564590-21-009423:notes:39]
Liability for Warranty

[0001564590-21-009423:notes:40]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $7.1 million and $8.4 million as of December 31, 2020 and 2019, respectively. These liabilities are included in accrued expenses and other liabilities in the accompanying Consolidated Balance Sheets.

[0001564590-21-009423:notes:41]
A summary of warranty expense and write-off activity for the years ended December 31, 2020, 2019 and 2018 is as follows:

[0001564590-21-009423:notes:42]
|  |  | Year Ended December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 8,394 |  |  | $ | 8,623 |  |  | $ | 9,724 |  |
| Plus: Amounts charged to cost and expenses |  |  | 1,538 |  |  |  | 4,569 |  |  |  | 7,392 |  |
| Less: Deductions |  |  | (2,786 | ) |  |  | (4,798 | ) |  |  | (8,493 | ) |
| Balance at end of period |  | $ | 7,146 |  |  | $ | 8,394 |  |  | $ | 8,623 |  |

[0001564590-21-009423:notes:43]
Pension Benefit Plan Obligations

[0001564590-21-009423:notes:44]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $18.7 million and $15.9 million as of December 31, 2020 and 2019, respectively.

[0001564590-21-009423:notes:45]
Stock-Based Compensation

[0001564590-21-009423:notes:46]
We have two stock incentive plans from which stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock are available for grant to employees and directors. Costs related to these awards are recognized over their vesting periods. All employee and director stock options granted under our stock option plans have an exercise price equal to the fair market value of the award, as defined in the plan, of the underlying common stock on the grant date. All of our outstanding stock option awards are classified as equity awards and therefore are measured at fair value on their grant date.

[0001564590-21-009423:notes:47]
Stock-based compensation expense recognized for the years ended December 31, 2020, 2019 and 2018 was approximately $6.8 million, $7.0 million and $7.2 million, respectively. As of December 31, 2020, total unrecognized compensation cost related to non-vested stock options, PSUs, RSUs and restricted stock was approximately $16.7 million, which is expected to be recognized over an average remaining recognition period of 2.9 years. See Note 5 for additional information.

[0001564590-21-009423:notes:48]
Research and Development Costs

[0001564590-21-009423:notes:49]
Research and development costs include compensation for engineers and support personnel, contracted services, depreciation and material costs associated with new product development, enhancement of current products and product cost reductions. We continually evaluate new product opportunities and engage in intensive research and product development efforts. Research and development costs totaled $113.3 million, $126.2 million and $124.5 million for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001564590-21-009423:notes:50]
Other Comprehensive Income (Loss)

[0001564590-21-009423:notes:51]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by components of accumulated other comprehensive income (loss) for the years ended December 31, 2020 2019 and 2018:

[0001564590-21-009423:notes:52]
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (2) |  |  | Total |  |
| Balance as of December 31, 2017 |  | $ | 2,567 |  |  | $ | (4,286 | ) |  | $ | (1,576 | ) |  | $ | — |  |  | $ | (3,295 | ) |
| Other comprehensive loss before reclassifications |  |  | 685 |  |  |  | (3,890 | ) |  |  | (4,236 | ) |  |  | — |  |  |  | (7,441 | ) |
| Amounts reclassified to retained earnings (1) |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | (595 | ) |  |  | 135 |  |  |  | — |  |  |  | — |  |  |  | (460 | ) |
| Balance as of December 31, 2018 |  |  | (563 | ) |  |  | (8,041 | ) |  |  | (5,812 | ) |  |  | — |  |  |  | (14,416 | ) |
| Other comprehensive loss before reclassifications |  |  | 573 |  |  |  | (1,717 | ) |  |  | (1,480 | ) |  |  | — |  |  |  | (2,624 | ) |
| Amounts reclassified to retained earnings (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |  |  | 385 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | (294 | ) |  |  | 532 |  |  |  | — |  |  |  | — |  |  |  | 238 |  |
| Balance as of December 31, 2019 |  |  | (284 | ) |  |  | (9,226 | ) |  |  | (7,292 | ) |  |  | 385 |  |  |  | (16,417 | ) |
| Other comprehensive loss before reclassifications |  |  | 749 |  |  |  | (1,231 | ) |  |  | 4,857 |  |  |  | — |  |  |  | 4,375 |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | (433 | ) |  |  | 836 |  |  |  | — |  |  |  | — |  |  |  | 403 |  |
| Balance as of December 31, 2020 |  | $ | 32 |  |  | $ | (9,621 | ) |  | $ | (2,435 | ) |  | $ | 385 |  |  | $ | (11,639 | ) |

[0001564590-21-009423:notes:53]
|  | (1) | With the adoption of ASU 2016-01, the unrealized gains on our equity investments were reclassified to retained earnings. |

[0001564590-21-009423:notes:54]
|  | (2) | With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings. See Note 14 for additional information. |

[0001564590-21-009423:notes:55]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the years ended December 31, 2020, 2019 and 2018:

[0001564590-21-009423:notes:56]
| (In thousands) |  | For the year ended December 31, |  |  |  |
| Details about Accumulated Other Comprehensive Income Components |  | 2020 |  |  | 2019 |  |  | 2018 |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains on available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 585 |  |  | $ | 397 |  |  | $ | 804 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (1,212 | ) |  |  | (771 | ) |  |  | (196 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (627 | ) |  |  | (374 | ) |  |  | 608 |  |  |  |
| Tax benefit |  |  | 224 |  |  |  | 136 |  |  |  | (148 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | (403 | ) |  | $ | (238 | ) |  | $ | 460 |  |  |  |

[0001564590-21-009423:notes:57]
|  | (1) | Included in the computation of net periodic pension cost. See Note 15 for additional information. |

[0001564590-21-009423:notes:58]
The following tables present the tax effects related to the change in each component of other comprehensive income (loss) for the years ended December 31, 2020, 2019 and 2018:

[0001564590-21-009423:notes:59]
|  |  | 2020 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 1,012 |  |  | $ | (263 | ) |  | $ | 749 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (585 | ) |  |  | 152 |  |  |  | (433 | ) |
| Defined benefit plan adjustments |  |  | (1,784 | ) |  |  | 553 |  |  |  | (1,231 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 1,212 |  |  |  | (376 | ) |  |  | 836 |  |
| Foreign currency translation adjustment |  |  | 4,857 |  |  |  | — |  |  |  | 4,857 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 4,712 |  |  | $ | 66 |  |  | $ | 4,778 |  |

[0001564590-21-009423:notes:60]
|  |  | 2019 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 774 |  |  | $ | (201 | ) |  | $ | 573 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net loss |  |  | (397 | ) |  |  | 103 |  |  |  | (294 | ) |
| Defined benefit plan adjustments |  |  | (2,488 | ) |  |  | 771 |  |  |  | (1,717 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net loss |  |  | 771 |  |  |  | (239 | ) |  |  | 532 |  |
| Foreign currency translation adjustment |  |  | (1,480 | ) |  |  | — |  |  |  | (1,480 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (2,820 | ) |  | $ | 434 |  |  | $ | (2,386 | ) |

[0001564590-21-009423:notes:61]
|  |  | 2018 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 926 |  |  | $ | (241 | ) |  | $ | 685 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net loss |  |  | (804 | ) |  |  | 209 |  |  |  | (595 | ) |
| Reclassification adjustment for amounts reclassed to retained earnings related to the adoption of ASU 2016-01 |  |  | (4,351 | ) |  |  | 1,131 |  |  |  | (3,220 | ) |
| Defined benefit plan adjustments |  |  | (5,638 | ) |  |  | 1,748 |  |  |  | (3,890 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net loss |  |  | 196 |  |  |  | (61 | ) |  |  | 135 |  |
| Foreign currency translation adjustment |  |  | (4,236 | ) |  |  | — |  |  |  | (4,236 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (13,907 | ) |  | $ | 2,786 |  |  | $ | (11,121 | ) |

[0001564590-21-009423:notes:62]
Income Taxes

[0001564590-21-009423:notes:63]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax bases of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0001564590-21-009423:notes:64]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001564590-21-009423:notes:65]
Foreign Currency

[0001564590-21-009423:notes:66]
Transactions with customers that are denominated in foreign currencies are recorded using the appropriate exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are remeasured at the balance sheet dates using the closing rates of exchange between those foreign currencies and the functional currency with any transaction gains or losses reported in other income (expense). Our primary exposures to foreign currency exchange rate movements are with our German subsidiary, whose functional currency is the Euro, our Australian subsidiary, whose functional currency is the Australian dollar and our British subsidiary, whose functional currency is the Great British pound. Adjustments resulting from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive income (loss).

[0001564590-21-009423:notes:67]
Revenue

[0001564590-21-009423:notes:68]
On January 1, 2018, we adopted ASU 2014-09, Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition.

[0001564590-21-009423:notes:69]
Accounting Policy under Topic 606

[0001564590-21-009423:notes:70]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. Review of contracts with customers, for both direct customers and distributors, are performed and assessment made regarding principal versus agent considerations to determine primary responsibility for delivery of performance obligation, presumed inventory risk, and discretion in establishing pricing, when applicable. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract, if material, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to account for shipping fees as a cost of fulfilling the related contract. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0001564590-21-009423:notes:71]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0001564590-21-009423:notes:72]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware revenue.

[0001564590-21-009423:notes:73]
Hardware and Software Revenue

[0001564590-21-009423:notes:74]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenue from software license sales are recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time products are delivered.

[0001564590-21-009423:notes:75]
Services & Support Segment - A complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services to complement our Network Solutions segment.

[0001564590-21-009423:notes:76]
Maintenance Revenue

[0001564590-21-009423:notes:77]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenues, when applicable, are recorded in current and non-current unearned revenue.

[0001564590-21-009423:notes:78]
Network Implementation Revenue

[0001564590-21-009423:notes:79]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0001564590-21-009423:notes:80]
See Notes 4 and 16 for additional information on reportable segments.

[0001564590-21-009423:notes:81]
Unearned Revenue

[0001564590-21-009423:notes:82]
Unearned revenue primarily represents customer billings on maintenance service programs and unearned revenues related to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one month to five years. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. In addition, we provide software maintenance and a variety of hardware maintenance services to customers under contracts with terms up to ten years. When we defer revenue related to multiple performance obligations where we still have contractual obligations, we also defer the related costs. Current deferred costs are included in prepaid expenses and other current assets on the accompanying Consolidated Balance Sheets and totaled $1.1 million and $1.6 million as of December 31, 2020 and 2019, respectively. Non-current deferred costs are included in other non-current assets on the accompanying Consolidated Balance Sheets and totaled less than $0.1 million and $0.1 million as of December 31, 2020 and 2019, respectively.

[0001564590-21-009423:notes:83]
Earnings (Loss) per Share

[0001564590-21-009423:notes:84]
Earnings (loss) per common share and earnings (loss) per common share assuming dilution, are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year. See Note 19 for additional information.

[0001564590-21-009423:notes:85]
Business Combinations

[0001564590-21-009423:notes:86]
The Company records assets acquired, liabilities assumed, contractual contingencies, when applicable, and intangible assets recognized as part of business combinations based on their fair values on the date of acquisition. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets and liabilities assumed or acquired is recorded as goodwill. If the estimated fair values of net tangible and intangible assets acquired and liabilities assumed exceed the purchase price, a bargain purchase gain is recorded. The Company’s estimates of fair value are based on historical experience, industry knowledge, certain information obtained from the management of the acquired company and, in some cases, valuations performed by independent third-party firms. The results of operations of acquired companies are included in the accompanying Consolidated Statements of Income (Loss) since their dates of acquisition. Costs incurred to complete the business combination, such as legal, accounting or other professional fees are charged to selling, general and administrative expenses as incurred.

[0001564590-21-009423:notes:87]
Recently Adopted Accounting Pronouncements

[0001564590-21-009423:notes:88]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 was effective for public business entities for fiscal years ending after December 15, 2020. The adoption of this standard did not have a material effect on the disclosures in the consolidation financial statements. See Note 15 for additional information.

[0001564590-21-009423:notes:89]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. The Company adopted ASU 2018-13 on January 1, 2020, and the adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-21-009423:notes:90]
In August 2018, the FASB issued ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. The Company adopted ASU 2018-15 on January 1, 2020, retrospectively. The adoption of this standard resulted in a reclassification of $5.6 million from property, plant and equipment to other non-current assets for certain previously capitalized costs related to information technology implementation projects that had not yet been placed in service on the Consolidated Balance Sheets as of December 31, 2020 and December 31, 2019. There was no impact to previously reported net cash provided by (used in) operations on the statement of cash flows and no impact to the statements of income (loss) as no portion of the capitalized asset was depreciated in prior periods.

[0001564590-21-009423:notes:91]
The following table illustrates the impact of adoption of ASU 2018-15 on the Consolidated Balance Sheet as of December 31, 2019:

[0001564590-21-009423:notes:92]
|  |  | As of December 31, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Consolidated Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | $ | 73,708 |  |  | $ | (5,622 | ) |  | $ | 68,086 |  |
| Other non-current assets |  | $ | 14,261 |  |  | $ | 5,622 |  |  | $ | 19,883 |  |

[0001564590-21-009423:notes:93]
There was no impact upon adoption of ASU 2018-15 on the Consolidated Statement of Income (Loss) for the year ended December 31, 2019 and the Consolidated Statement of Cash Flows for the year ended December 31, 2019 as outlined in the following tables:

[0001564590-21-009423:notes:94]
|  |  | For the year ended December 31, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Consolidated Statement of Income (Loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (52,982 | ) |  | $ | — |  |  | $ | (52,982 | ) |
| Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities |  | $ | (2,472 | ) |  | $ | — |  |  | $ | (2,472 | ) |

[0001564590-21-009423:notes:95]
The following table presents the capitalized implementation costs incurred with hosting arrangements, included in other non-current assets on the Consolidated Balance Sheet, as of December 31, 2020:

[0001564590-21-009423:notes:96]
| (In thousands) |  | December 31, 2020 |  |
| Implementation costs - hosting arrangements |  | $ | 13,515 |  |
| Less: accumulated amortization |  |  | — |  |
| Implementation costs - hosting arrangements, net |  | $ | 13,515 |  |

[0001564590-21-009423:notes:97]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss), that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Consolidated Balance Sheets, Consolidated Statements of Income (Loss) or Consolidated Statements of Cash Flows.

[0001564590-21-009423:notes:98]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, which clarifies that receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the standard for leases. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification Improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as providing disclosure relief for accrued interest receivables. In March 2020, the FASB issued ASU 2020-03, Codification Improvements to financial instruments, which clarifies various issues related to the new credit losses standard, such as the contractual term used to measure expected credit losses for leases and when to record an allowance for credit losses for financial assets that fall under the scope of ASC 860-20, Transfers and Servicing – Sales of Financial Assets. All of these ASUs were codified as part of Accounting Standards Codifications (“ASC”) Topic 326 and were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard on January 1, 2020, using a modified-retrospective approach and, therefore, elected to carry forward legacy disclosures for comparative periods and did not adjust the comparative period financial information. Additionally, the Company made an accounting policy election, at the class of financing receivable, not to measure the allowance for credit losses for accrued interest receivables, as the Company writes off the uncollectable accrued interest receivable by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable). The adoption of this standard did not have a material effect on our consolidated financial statements. See Note 18 for additional information.

[0001564590-21-009423:notes:99]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities are required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 was effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019.

[0001564590-21-009423:notes:100]
The Company adopted ASU 2017-04 on January 1, 2020, and the amendments were applied prospectively. The adoption of this standard did not have a material effect on our consolidated financial statements.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001564590-21-009423:notes:101]
Note 2 – Cash, Cash Equivalents and Restricted Cash

[0001564590-21-009423:notes:102]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the Consolidated Balance Sheet that sum to the total of the same such amounts shown in the Consolidated Statement of Cash Flows:

[0001564590-21-009423:notes:103]
| (In thousands) |  | December 31, 2020 |  |
| Cash and cash equivalents |  | $ | 60,161 |  |
| Restricted cash |  |  | 18 |  |
| Cash, cash equivalents and restricted cash |  | $ | 60,179 |  |

[0001564590-21-009423:notes:104]
The Company did not have any restricted cash as of December 31, 2019 and 2018. See Note 17 for additional information regarding restricted cash.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-21-009423:notes:105]
Note 3 – Business Combinations

[0001564590-21-009423:notes:106]
In November 2018, we acquired SmartRG, Inc., for cash consideration. This transaction was accounted for as a business combination. We recorded goodwill of $3.5 million as a result of this acquisition, which represents the excess of the purchase price over the fair value of net assets acquired and liabilities assumed. The financial results of this acquisition are included in the consolidated financial statements since the date of acquisition. The revenues are included in the Subscriber Solutions & Experience category within the Network Solutions and Services & Support reportable segments.

[0001564590-21-009423:notes:107]
Contingent liabilities with a fair value totaling $1.2 million were recognized at the acquisition date. The required milestones were not achieved and therefore, a gain of $1.2 million was recognized upon the reversal of these liabilities during the second quarter of 2019.

[0001564590-21-009423:notes:108]
An escrow in the amount of $2.8 million was set up at the acquisition date to fund post-closing working capital settlements and to satisfy indemnity obligations to the Company arising from any inaccuracy or breach of representations, warranties, covenants, agreements or obligations of the sellers. The escrow was subject to arbitration. In December 2019, $1.3 million of the $2.8 million was released from the escrow account pursuant to the agreement and the remaining balance was released in December 2020.

[0001564590-21-009423:notes:109]
In March 2018, we acquired Sumitomo Electric Lightwave Corp.’s (SEL) North American EPON business and entered into a technology license and OEM supply agreement with Sumitomo Electric Industries, Ltd. (SEI). We recorded a bargain purchase gain of $11.3 million during the first quarter of 2018, net of income taxes, which was subject to customary working capital adjustments between the parties. This transaction was accounted for as a business combination. The financial results of this acquisition are included in the consolidated financial statements since the date of acquisition. The revenues are included in the Access & Aggregation and Subscriber Solutions & Experience categories within the Network Solutions and Services & Support reportable segments.

[0001564590-21-009423:notes:110]
The Consolidated Statement of Income for the year ended December 31, 2018 includes the following revenue and net loss attributable to SmartRG and Sumitomo since the date of acquisition:

[0001564590-21-009423:notes:111]
| (In thousands) |  | March 19, 2018 to December 31, 2018 |  |
| Revenue |  | $ | 9,186 |  |
| Net loss |  | $ | (1,297 | ) |

[0001564590-21-009423:notes:112]
The following unaudited supplemental pro forma information presents the financial results as if the acquisition of SmartRG and Sumitomo had occurred on January 1, 2017. This unaudited supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2018, nor is it indicative of any future results. There were no material, non-recurring adjustments to this unaudited pro forma information.

[0001564590-21-009423:notes:113]
| (In thousands) |  | 2018 |  |
| Pro forma revenue |  | $ | 559,050 |  |
| Pro forma net loss |  | $ | (33,862 | ) |

[0001564590-21-009423:notes:114]
For the years ended December 31, 2020, 2019 and 2018, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $3.8 million, $5.0 million and $2.9 million, respectively, related to the SmartRG and Sumitomo acquisitions.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-009423:notes:115]
Note 4 - Revenue

[0001564590-21-009423:notes:116]
The following is a description of the principal activities from which revenue is generated by reportable segment:

[0001564590-21-009423:notes:117]
Network Solutions - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

[0001564590-21-009423:notes:118]
Services & Support - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-21-009423:notes:119]
Revenue by Category

[0001564590-21-009423:notes:120]
In addition to reportable segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

[0001564590-21-009423:notes:121]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2020:

[0001564590-21-009423:notes:122]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 262,578 |  |  | $ | 50,560 |  |  | $ | 313,138 |  |
| Subscriber Solutions & Experience |  |  | 161,824 |  |  |  | 9,263 |  |  |  | 171,087 |  |
| Traditional & Other Products |  |  | 13,613 |  |  |  | 8,672 |  |  |  | 22,285 |  |
| Total |  | $ | 438,015 |  |  | $ | 68,495 |  |  | $ | 506,510 |  |

[0001564590-21-009423:notes:123]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2019:

[0001564590-21-009423:notes:124]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 289,980 |  |  | $ | 58,894 |  |  | $ | 348,874 |  |
| Subscriber Solutions & Experience |  |  | 144,651 |  |  |  | 8,269 |  |  |  | 152,920 |  |
| Traditional & Other Products |  |  | 20,595 |  |  |  | 7,672 |  |  |  | 28,267 |  |
| Total |  | $ | 455,226 |  |  | $ | 74,835 |  |  | $ | 530,061 |  |

[0001564590-21-009423:notes:125]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2018:

[0001564590-21-009423:notes:126]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 301,801 |  |  | $ | 57,069 |  |  | $ | 358,870 |  |
| Subscriber Solutions & Experience |  |  | 129,067 |  |  |  | 5,393 |  |  |  | 134,460 |  |
| Traditional & Other Products |  |  | 27,364 |  |  |  | 8,583 |  |  |  | 35,947 |  |
| Total |  | $ | 458,232 |  |  | $ | 71,045 |  |  | $ | 529,277 |  |

[0001564590-21-009423:notes:127]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration greater than one year. As of December 31, 2020, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $17.7 million and $13.6 million as of December 31, 2020 and December 31, 2019, respectively. The Company expects to recognize 61% of the $17.7 million as of December 31, 2020 over the next 12 months, with the remainder to be recognized thereafter.

[0001564590-21-009423:notes:128]
The following table provides information about accounts receivable, contract assets and unearned revenue from contracts with customers:

[0001564590-21-009423:notes:129]
| (In thousands) |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Accounts receivable |  | $ | 98,827 |  |  | $ | 90,531 |  |
| Contract assets(1) |  | $ | 63 |  |  | $ | 2,812 |  |
| Unearned revenue |  | $ | 14,092 |  |  | $ | 11,963 |  |
| Non-current unearned revenue |  | $ | 6,888 |  |  | $ | 6,012 |  |

[0001564590-21-009423:notes:130]
(1) Included in other receivables on the Consolidated Balance Sheets.

[0001564590-21-009423:notes:131]
Of the outstanding unearned revenue balance as of December 31, 2019 and December 31, 2018, $11.0 million and $12.7 million were recognized as revenue during the years ended December 31, 2020 and 2019, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-21-009423:notes:132]
The following tables disaggregate our revenue by category for the years ended December 31, 2020, 2019 and 2018:

[0001564590-21-009423:notes:133]
|  |  | 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 262,578 |  |  | $ | 50,560 |  |  | $ | 313,138 |  |
| Subscriber Solutions & Experience |  |  | 161,824 |  |  |  | 9,263 |  |  |  | 171,087 |  |
| Traditional & Other Products |  |  | 13,613 |  |  |  | 8,672 |  |  |  | 22,285 |  |
| Total |  | $ | 438,015 |  |  | $ | 68,495 |  |  | $ | 506,510 |  |

[0001564590-21-009423:notes:134]
|  |  | 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 289,980 |  |  | $ | 58,894 |  |  | $ | 348,874 |  |
| Subscriber Solutions & Experience |  |  | 144,651 |  |  |  | 8,269 |  |  |  | 152,920 |  |
| Traditional & Other Products |  |  | 20,595 |  |  |  | 7,672 |  |  |  | 28,267 |  |
| Total |  | $ | 455,226 |  |  | $ | 74,835 |  |  | $ | 530,061 |  |

[0001564590-21-009423:notes:135]
|  |  | 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 301,801 |  |  | $ | 57,069 |  |  | $ | 358,870 |  |
| Subscriber Solutions & Experience |  |  | 129,067 |  |  |  | 5,393 |  |  |  | 134,460 |  |
| Traditional & Other Products |  |  | 27,364 |  |  |  | 8,583 |  |  |  | 35,947 |  |
| Total |  | $ | 458,232 |  |  | $ | 71,045 |  |  | $ | 529,277 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-009423:notes:136]
Note 5 – Stock-Based Compensation

[0001564590-21-009423:notes:137]
The following table summarizes stock-based compensation expense related to stock options, PSUs, RSUs and restricted stock for the years ended December 31, 2020, 2019 and 2018:

[0001564590-21-009423:notes:138]
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 426 |  |  | $ | 369 |  |  | $ | 418 |  |
| Selling, general and administrative expenses |  |  | 4,036 |  |  |  | 3,889 |  |  |  | 3,989 |  |
| Research and development expenses |  |  | 2,372 |  |  |  | 2,704 |  |  |  | 2,748 |  |
| Stock-based compensation expense included in operating expenses |  |  | 6,408 |  |  |  | 6,593 |  |  |  | 6,737 |  |
| Total stock-based compensation expense |  |  | 6,834 |  |  |  | 6,962 |  |  |  | 7,155 |  |
| Tax benefit for expense associated with non-qualified stock options, PSUs, RSUs and restricted stock |  |  | (1,629 | ) |  |  | (1,659 | ) |  |  | (1,432 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 5,205 |  |  | $ | 5,303 |  |  | $ | 5,723 |  |

[0001564590-21-009423:notes:139]
Stock Incentive Program Descriptions

[0001564590-21-009423:notes:140]
2020 Stock Incentive Plans

[0001564590-21-009423:notes:141]
At the annual meeting of stockholders held on May 13, 2020, the Company’s stockholders approved, upon recommendation of the Board of Directors, the adoption of the ADTRAN, Inc. 2020 Employee Stock Incentive Plan (the “2020 Employee Plan”) as well as the ADTRAN, Inc. 2020 Directors Stock Plan (the “2020 Directors Plan”). No additional awards will be granted under the Company’s previous stock incentive plans, the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (the “2015 Employee Plan”) or the 2010 Directors Stock Plan (the “2010 Directors Plan”) subsequent to the stockholders’ approval of these new stock plans. Outstanding awards granted under the 2015 Employee Plan and the 2010 Directors Plan will remain subject to the terms of such plans, and shares underlying awards granted under such plans that are cancelled or forfeited will be available for issuance under the 2020 Employee Plan or the 2020 Directors Plan, as applicable.

[0001564590-21-009423:notes:142]
Under the 2020 Employee Plan, the Company is authorized to issue 2.8 million shares of common stock to certain employees, key service providers and advisors through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock, any of which may be subject to performance-based conditions. RSUs and restricted stock granted under the 2020 Employee Plan will typically vest pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date. Stock options granted under the 2020 Employee Plan will typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Stock options, RSUs and restricted stock granted under the 2020 Employee Plan reduce the shares authorized for issuance under the 2020 Employee Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations or expirations of awards granted under the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan, with forfeitures, cancellations or expirations of RSUs and restricted stock increasing the shares authorized for issuance by 2.5 shares of common stock for each share underlying the award. Forfeitures, cancellations or expirations of stock options from the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan by one share of common stock for each share underlying the award.

[0001564590-21-009423:notes:143]
Under the 2020 Directors Plan, the Company is authorized to issue 0.4 million shares of common stock through stock options, restricted stock and RSUs to non-employee directors. Stock awards issued under the 2020 Directors Plan typically will become vested in full on the first anniversary of the grant date. Stock options issued under the 2020 Directors Plan will have a ten-year contractual term. Stock options, restricted stock and RSUs granted under the 2020 Directors Plan reduce the shares authorized for issuance under the 2020 Directors Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the 2010 Directors Stock Plan increase the shares authorized for issuance under the 2020 Directors Plan by one share of common stock for each share underlying the award.

[0001564590-21-009423:notes:144]
Previous Stock Incentive Plans

[0001564590-21-009423:notes:145]
In January 2015, the Board of Directors adopted the 2015 Employee Plan, which authorized 7.7 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, PSUs, RSUs and restricted stock. The 2015 Employee Plan was adopted by stockholder approval at our annual meeting of stockholders held in May 2015. PSUs, RSUs and restricted stock granted under the 2015 Plan reduce the shares authorized for issuance under the 2015 Employee Plan by 2.5 shares of common stock for each share underlying the award. Options granted under the 2015 Employee Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Expiration dates of options outstanding as of December 31, 2020 under the 2015 Employee Plan range from 2025 to 2026.

[0001564590-21-009423:notes:146]
In January 2006, the Board of Directors adopted the ADTRAN, Inc. 2006 Employee Stock Incentive Plan (the “2006 Plan”), which authorized 13.0 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock. Options granted under the 2006 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and had a ten-year contractual term. The 2006 Plan was replaced in May 2015 by the 2015 Employee Plan. Expiration dates of options outstanding as of December 31, 2020 under the 2006 Plan range from 2021 to 2024.

[0001564590-21-009423:notes:147]
In May 2010, the Company’s stockholders approved the 2010 Directors Plan, under which 0.5 million shares of common stock have been reserved for issuance. This plan replaced the 2005 Directors Stock Option Plan. Under the 2010 Directors Plan, the Company may issue stock options, restricted stock and RSUs to our non-employee directors. Stock awards issued under the 2010 Directors Plan become vested in full on the first anniversary of the grant date. Options issued under the 2010 Directors Plan had a ten-year contractual term. All remaining options under the 2010 Directors Plan expired in 2019.

[0001564590-21-009423:notes:148]
PSUs, RSUs and restricted stock

[0001564590-21-009423:notes:149]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2019 and 2020 and the changes that occurred during 2020:

[0001564590-21-009423:notes:150]
|  |  | Number of shares (In thousands) |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2019 |  |  | 1,891 |  |  | $ | 14.58 |  |
| PSUs, RSUs and restricted stock granted |  |  | 1,029 |  |  | $ | 11.02 |  |
| PSUs, RSUs and restricted stock vested |  |  | (453 | ) |  | $ | 14.26 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (621 | ) |  | $ | 18.14 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2020 |  |  | 1,846 |  |  | $ | 11.49 |  |

[0001564590-21-009423:notes:151]
The following table details the significant assumptions that impact the fair value estimate of the market-based PSUs:

[0001564590-21-009423:notes:152]
|  |  | 2020 |  |  | 2019 |  | 2018 |  |
| Estimated fair value per share |  |  | $14.43 |  |  | $9.53 to $18.05 |  |  | $16.59 |  |
| Expected volatility |  |  | 51.88% |  |  | 32.7% to 38.9% |  | 27.98% to 31.58% |  |
| Risk-free interest rate |  |  | 0.24% |  |  | 1.6% to 2.46% |  | 2.11% to 2.99% |  |
| Expected dividend yield |  |  | 2.85% |  |  | 2.3% to 4.09% |  | 1.83% to 2.49% |  |

[0001564590-21-009423:notes:153]
For market-based PSUs, the number of shares of common stock earned by a recipient is subject to a market condition based on ADTRAN’s relative total shareholder return against all companies in the NASDAQ Telecommunications Index at the end of a three-year performance period. Depending on the relative total shareholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the PSUs, with the shares earned distributed upon the vesting. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted PSUs vests and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of ADTRAN, as defined by the 2020 Employee Plan. The recipients of the PSUs receive dividend credits based on the shares of common stock underlying the PSUs. The dividend credits vest and are earned in the same manner as the PSUs and are paid in cash upon the issuance of common stock for the PSUs.

[0001564590-21-009423:notes:154]
During the first quarter of 2020, the Company issued 0.3 million performance-based PSUs under the 2015 Employee Plan to its executive officers. The grant-date fair value of these performance-based awards is based on the closing price of the Company’s stock on the date of grant. Subject to the grantee’s continued employment, the grantee has the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of a defined performance target at the end of a three-year period. If the Company achieves the performance target at the end of the first or second year during the vesting period, the grantee will be entitled to the target number of performance shares, which will be issued at the end of the three-year period. Equity-based compensation expense with respect to these awards will be adjusted over the vesting period to reflect the probability of achievement of the performance target defined in the award agreements.

[0001564590-21-009423:notes:155]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the grant date. RSUs and restricted stock vest ratably over four-year and one-year periods, respectively.

[0001564590-21-009423:notes:156]
We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0001564590-21-009423:notes:157]
As of December 31, 2020, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $16.7 million, which is expected to be recognized over an average remaining recognition period of 2.9 years and will be adjusted for actual forfeitures as they occur.

[0001564590-21-009423:notes:158]
As of December 31, 2020, 3.6 million shares were available for issuance under shareholder-approved equity plans in connection with the grant and exercise of stock options, PSU’s, RSU’s or restricted stock.

[0001564590-21-009423:notes:159]
Stock Options

[0001564590-21-009423:notes:160]
The following table is a summary of stock options outstanding as of December 31, 2020 and 2019 and the changes that occurred during 2020:

[0001564590-21-009423:notes:161]
|  |  | Number of Options (In thousands) |  |  | Weighted Average Exercise Price (Per share) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Aggregate Intrinsic Value (In thousands) |  |
| Stock options outstanding, December 31, 2019 |  |  | 3,572 |  |  | $ | 22.88 |  |  |  | 3.40 |  |  | $ | — |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options exercised |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (854 | ) |  | $ | 28.00 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, December 31, 2020 |  |  | 2,718 |  |  | $ | 21.17 |  |  |  | 2.86 |  |  | $ | — |  |
| Stock options exercisable, December 31, 2020 |  |  | 2,718 |  |  | $ | 21.17 |  |  |  | 2.86 |  |  | $ | — |  |

[0001564590-21-009423:notes:162]
All of these stock options were issued at exercise prices that approximated fair market value at the date of grant. As of December 31, 2020, there was no unrecognized compensation expense related to non-vested stock options.

[0001564590-21-009423:notes:163]
The aggregate intrinsic values represent the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of 2020 and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2020. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock and was $0 as of December 31, 2020.

[0001564590-21-009423:notes:164]
The total pre-tax intrinsic value of options exercised during 2020, 2019 and 2018 was $0, $0.1 million and $0.2 million, respectively. The fair value of options fully vesting during 2020, 2019 and 2018 was less than $0.1 million, $0.9 million and $2.5 million, respectively.

[0001564590-21-009423:notes:165]
The following table further describes our stock options outstanding as of December 31, 2020:

[0001564590-21-009423:notes:166]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range of Exercise Prices |  | Options Outstanding at December 31, 2020 (In thousands) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Weighted Average Exercise Price |  |  | Options Exercisable at December 31, 2020 (In thousands) |  |  | Weighted Average Exercise Price |  |
| $15.33 – $18.96 |  |  | 1,007 |  |  |  | 3.69 |  |  | $ | 15.91 |  |  |  | 1,007 |  |  | $ | 15.91 |  |
| $18.97 – $23.45 |  |  | 588 |  |  |  | 3.68 |  |  | $ | 18.97 |  |  |  | 588 |  |  | $ | 18.97 |  |
| $23.46 – $30.35 |  |  | 603 |  |  |  | 2.55 |  |  | $ | 24.11 |  |  |  | 603 |  |  | $ | 24.11 |  |
| $30.36 – $41.92 |  |  | 520 |  |  |  | 0.64 |  |  | $ | 30.40 |  |  |  | 520 |  |  | $ | 30.40 |  |
|  |  |  | 2,718 |  |  |  |  |  |  |  |  |  |  |  | 2,718 |  |  |  |  |  |

[0001564590-21-009423:notes:167]
The Black-Scholes option pricing model (the “Black-Scholes Model”) is used to determine the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0001564590-21-009423:notes:168]
There were no stock options granted in during the years ended December 31, 2020, 2019 or 2018.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-21-009423:notes:169]
Note 6 – Investments

[0001564590-21-009423:notes:170]
Debt Securities and Other Investments

[0001564590-21-009423:notes:171]
As of December 31, 2020, the following debt securities and other investments were included in short-term investments and long-term investments on the Consolidated Balance Sheet and recorded at fair value:

[0001564590-21-009423:notes:172]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 11,762 |  |  | $ | 123 |  |  | $ | — |  |  | $ | 11,885 |  |
| Municipal fixed-rate bonds |  |  | 2,854 |  |  |  | 30 |  |  |  | — |  |  |  | 2,884 |  |
| Asset-backed bonds |  |  | 6,634 |  |  |  | 74 |  |  |  | — |  |  |  | 6,708 |  |
| Mortgage/Agency-backed bonds |  |  | 11,536 |  |  |  | 114 |  |  |  | (6 | ) |  |  | 11,644 |  |
| U.S. government bonds |  |  | 9,763 |  |  |  | 112 |  |  |  | — |  |  |  | 9,875 |  |
| Foreign government bonds |  |  | 1,334 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 1,337 |  |
| Commercial Paper |  |  | 250 |  |  |  | — |  |  |  | — |  |  |  | 250 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,666 |  |  | $ | 457 |  |  | $ | (7 | ) |  | $ | 45,116 |  |

[0001564590-21-009423:notes:173]
As of December 31, 2019, the following debt securities and other investments were included in short-term investments and long-term investments on the Consolidated Balance Sheet and recorded at fair value:

[0001564590-21-009423:notes:174]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,304 |  |  | $ | 80 |  |  | $ | — |  |  | $ | 9,384 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | 930 |  |
| Asset-backed bonds |  |  | 6,867 |  |  |  | 26 |  |  |  | (3 | ) |  |  | 6,890 |  |
| Mortgage/Agency-backed bonds |  |  | 6,944 |  |  |  | 26 |  |  |  | (8 | ) |  |  | 6,962 |  |
| U.S. government bonds |  |  | 12,311 |  |  |  | 21 |  |  |  | (9 | ) |  |  | 12,323 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (1 | ) |  |  | 371 |  |
| Variable rate demand notes |  |  | 800 |  |  |  | — |  |  |  | — |  |  |  | 800 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,528 |  |  | $ | 153 |  |  | $ | (21 | ) |  | $ | 37,660 |  |

[0001564590-21-009423:notes:175]
As of December 31, 2020, our debt securities had the following contractual maturities:

[0001564590-21-009423:notes:176]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage / Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Commercial paper |  |  | Other |  |
| Less than one year |  | $ | 1,477 |  |  | $ | 96 |  |  | $ | 144 |  |  | $ | 63 |  |  | $ | — |  |  | $ | 75 |  |  | $ | 250 |  |  | $ | 533 |  |
| One to two years |  |  | 2,007 |  |  |  | 1,245 |  |  |  | 300 |  |  |  | 2,129 |  |  |  | 5,122 |  |  |  | 462 |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 7,013 |  |  |  | 1,246 |  |  |  | 622 |  |  |  | 2,940 |  |  |  | 4,526 |  |  |  | 498 |  |  |  | — |  |  |  | — |  |
| Three to five years |  |  | 1,388 |  |  |  | 297 |  |  |  | 3,658 |  |  |  | 183 |  |  |  | 227 |  |  |  | 302 |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,241 |  |  |  | 2,095 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 743 |  |  |  | 4,234 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 11,885 |  |  | $ | 2,884 |  |  | $ | 6,708 |  |  | $ | 11,644 |  |  | $ | 9,875 |  |  | $ | 1,337 |  |  | $ | 250 |  |  | $ | 533 |  |

[0001564590-21-009423:notes:177]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-21-009423:notes:178]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities for the years ended December 31, 2020, 2019 and 2018:

[0001564590-21-009423:notes:179]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Gross realized gains on debt securities |  | $ | 459 |  |  | $ | 108 |  |  | $ | 57 |  |
| Gross realized losses on debt securities |  |  | (58 | ) |  |  | (50 | ) |  |  | (592 | ) |
| Total gain (loss) recognized, net |  | $ | 401 |  |  | $ | 58 |  |  | $ | (535 | ) |

[0001564590-21-009423:notes:180]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt with credit deterioration during the years ended December 31, 2020, 2019 and 2018.

[0001564590-21-009423:notes:181]
The following table presents the breakdown of debt securities and other investments with unrealized losses as of December 31, 2020:

[0001564590-21-009423:notes:182]
|  |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  | $ | 336 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 336 |  |  | $ | — |  |
| Municipal fixed-rate bonds |  |  | 310 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 310 |  |  |  | — |  |
| Asset-backed bonds |  |  | 2 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 2,078 |  |  |  | (6 | ) |  |  | — |  |  |  | — |  |  |  | 2,078 |  |  |  | (6 | ) |
| U.S. government bonds |  |  | 350 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 350 |  |  |  | — |  |
| Foreign government bonds |  |  | 302 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 302 |  |  |  | (1 | ) |
| Total |  | $ | 3,378 |  |  | $ | (7 | ) |  | $ | — |  |  | $ | — |  |  | $ | 3,378 |  |  | $ | (7 | ) |

[0001564590-21-009423:notes:183]
The following table presents the breakdown of debt securities and other investments with unrealized losses as of December 31, 2019:

[0001564590-21-009423:notes:184]
|  |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  | $ | 203 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 203 |  |  | $ | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 797 |  |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | 797 |  |  |  | (3 | ) |
| Mortgage/Agency-backed bonds |  |  | 2,594 |  |  |  | (6 | ) |  |  | 136 |  |  |  | (2 | ) |  |  | 2,730 |  |  |  | (8 | ) |
| U.S. government bonds |  |  | 4,070 |  |  |  | (9 | ) |  |  | — |  |  |  | — |  |  |  | 4,070 |  |  |  | (9 | ) |
| Foreign government bonds |  |  | 371 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 371 |  |  |  | (1 | ) |
| Total |  | $ | 8,965 |  |  | $ | (19 | ) |  | $ | 136 |  |  | $ | (2 | ) |  | $ | 9,101 |  |  | $ | (21 | ) |

[0001564590-21-009423:notes:185]
The decrease in unrealized losses during 2020 resulted from changes in market positions associated with our fixed income portfolio.

[0001564590-21-009423:notes:186]
Marketable Equity Securities

[0001564590-21-009423:notes:187]
Marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost, where appropriate.

[0001564590-21-009423:notes:188]
During the three months ended March 31, 2019, an outstanding note receivable of $4.3 million was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment, which represented a non-cash investing activity. This equity investment, which does not have a readily determinable fair value, was recorded using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. During the year ended December 31, 2020, impairment charges totaling $2.6 million were recorded related to this equity investment and are included in net investment gain (loss) on the Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $0.8 million as of December 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Consolidated Balance Sheets as of December 31, 2020 and December 31, 2019, and represented a non-cash investing activity during the year ended December 31, 2019. No impairment charge was recognized related to the note receivable as it is a secured loan.

[0001564590-21-009423:notes:189]
Realized and unrealized gains and losses for our marketable equity securities for the year ended December 31, 2020, 2019 and 2018 were as follows:

[0001564590-21-009423:notes:190]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Realized losses on equity securities sold |  | $ | (2,382 | ) |  | $ | (96 | ) |  | $ | 1,306 |  |
| Unrealized gains on equity securities held |  |  | 6,831 |  |  |  | 11,472 |  |  |  | (4,821 | ) |
| Total gain (loss) recognized, net |  | $ | 4,449 |  |  | $ | 11,376 |  |  | $ | (3,515 | ) |

[0001564590-21-009423:notes:191]
As of December 31, 2020 and 2019, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.

[0001564590-21-009423:notes:192]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0001564590-21-009423:notes:193]
• Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0001564590-21-009423:notes:194]
• Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0001564590-21-009423:notes:195]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement; inputs could include information supplied by investees.

[0001564590-21-009423:notes:196]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0001564590-21-009423:notes:197]
|  |  | Fair Value Measurements as of December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 497 |  |  | $ | 497 |  |  | $ | — |  |  | $ | — |  |
| U.S. government bonds |  |  | 350 |  |  |  | 350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,885 |  |  |  | — |  |  |  | 11,885 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,884 |  |  |  | — |  |  |  | 2,884 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,708 |  |  |  | — |  |  |  | 6,708 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,644 |  |  |  | — |  |  |  | 11,644 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,875 |  |  |  | 9,875 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,337 |  |  |  | — |  |  |  | 1,337 |  |  |  | — |  |
| Commercial paper |  |  | 250 |  |  |  | — |  |  |  | 250 |  |  |  | — |  |
| Other investments |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 10,963 |  |  |  | 10,963 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 23,891 |  |  |  | 23,891 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,217 |  |  | $ | 46,976 |  |  | $ | 34,708 |  |  | $ | 533 |  |

[0001564590-21-009423:notes:198]
|  |  | Fair Value Measurements as of December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,309 |  |  | $ | 1,309 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,384 |  |  |  | — |  |  |  | 9,384 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,890 |  |  |  | — |  |  |  | 6,890 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 6,962 |  |  |  | — |  |  |  | 6,962 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,323 |  |  |  | 12,323 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 371 |  |  |  | — |  |  |  | 371 |  |  |  | — |  |
| Variable rate demand notes |  |  | 800 |  |  |  | — |  |  |  | 800 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,501 |  |  |  | 35,501 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 298 |  |  |  | 298 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,698 |  |  |  | 21,698 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,442 |  |  |  | 2,442 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 98,908 |  |  | $ | 73,571 |  |  | $ | 25,337 |  |  | $ | — |  |

[0001564590-21-009423:notes:199]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-21-009423:notes:200]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consisted of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.

[0001564590-21-009423:notes:201]
Our variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:InventoryDisclosureTextBlock

[0001564590-21-009423:notes:202]
Note 7 – Inventory

[0001564590-21-009423:notes:203]
As of December 31, 2020 and 2019, inventory, net was comprised of the following:

[0001564590-21-009423:notes:204]
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Raw materials |  | $ | 47,026 |  |  | $ | 36,987 |  |
| Work in process |  |  | 776 |  |  |  | 1,085 |  |
| Finished goods |  |  | 77,655 |  |  |  | 60,233 |  |
| Total Inventory, net |  | $ | 125,457 |  |  | $ | 98,305 |  |

[0001564590-21-009423:notes:205]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. As of December 31, 2020 and 2019, our inventory reserve was $39.6 million and $34.1 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-21-009423:notes:206]
Note 8 – Property, Plant and Equipment

[0001564590-21-009423:notes:207]
As of December 31, 2020 and 2019, property, plant and equipment, net was comprised of the following:

[0001564590-21-009423:notes:208]
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 35,142 |  |  |  | 34,797 |  |
| Building |  |  | 68,169 |  |  |  | 68,157 |  |
| Furniture and fixtures |  |  | 19,965 |  |  |  | 19,959 |  |
| Computer hardware and software |  |  | 70,942 |  |  |  | 68,777 |  |
| Engineering and other equipment |  |  | 132,920 |  |  |  | 130,430 |  |
| Total Property, Plant and Equipment |  |  | 331,713 |  |  |  | 326,695 |  |
| Less: accumulated depreciation |  |  | (269,314 | ) |  |  | (258,609 | ) |
| Total Property, Plant and Equipment, net |  | $ | 62,399 |  |  | $ | 68,086 |  |

[0001564590-21-009423:notes:209]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. During the years ended December 31, 2020 and December 31, 2019, the Company recognized impairment charges of $0.1 million and $3.9 million, respectively, related to the abandonment of certain information technology projects in which we had previously capitalized expenses related to these projects. The impairment charges were determined based on actual costs incurred as part of the projects. No impairment charges were recognized during the year ended December 31, 2018.

[0001564590-21-009423:notes:210]
Depreciation expense was $12.2 million, $12.5 million and $12.7 million for the years ended December 31, 2020, 2019 and 2018, respectively, which is recorded in cost of sales, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Income (Loss).


## adtn:LeasesDisclosureTextBlock

[0001564590-21-009423:notes:211]
Note 9 – Leases

[0001564590-21-009423:notes:212]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain potential embedded leases. These other contracts are specifically reviewed to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease.

[0001564590-21-009423:notes:213]
As of December 31, 2020, our operating leases had remaining lease terms of two months to 55 months, some of which included options to extend the leases for up to two years, and some of which included options to terminate the leases within three months. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. Supplemental balance sheet information related to operating leases is as follows:

[0001564590-21-009423:notes:214]
|  |  |  |  | December 31, |  |  | December 31, |  |
| (In thousands) |  | Classification |  | 2020 |  |  | 2019 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Other non-current assets |  | $ | 5,309 |  |  | $ | 8,452 |  |
| Total lease asset |  |  |  | $ | 5,309 |  |  | $ | 8,452 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses and other liabilities |  | $ | 1,806 |  |  | $ | 2,676 |  |
| Non-current operating lease liability |  | Other non-current liabilities |  |  | 3,574 |  |  |  | 5,818 |  |
| Total lease liability |  |  |  | $ | 5,380 |  |  | $ | 8,494 |  |

[0001564590-21-009423:notes:215]
Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. Lease expense related to these short-term leases was less than $0.1 million and $0.4 million for the year ended December 31, 2020 and 2019, respectively, and is included in cost of sales, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Income (Loss). Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.7 million and $0.9 million for the year ended December 31, 2020 and 2019, respectively. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. Our lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001564590-21-009423:notes:216]
The components of lease expense included in the Consolidated Statements of Income (Loss) were as follows:

[0001564590-21-009423:notes:217]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Cost of sales |  | $ | 113 |  |  | $ | 64 |  |
| Selling, general and administrative expenses |  |  | 1,311 |  |  |  | 1,400 |  |
| Research and development expenses |  |  | 1,121 |  |  |  | 2,417 |  |
| Total operating lease expense |  | $ | 2,545 |  |  | $ | 3,881 |  |

[0001564590-21-009423:notes:218]
As of December 31, 2020, operating lease liabilities included on the Consolidated Balance Sheet by future maturity were as follows:

[0001564590-21-009423:notes:219]
| (In thousands) |  | Amount |  |
| 2021 |  | $ | 1,895 |  |
| 2022 |  |  | 1,600 |  |
| 2023 |  |  | 1,251 |  |
| 2024 |  |  | 521 |  |
| 2025 |  |  | 287 |  |
| Thereafter |  |  | — |  |
| Total lease payments |  |  | 5,554 |  |
| Less: Interest |  |  | (174 | ) |
| Present value of lease liabilities |  | $ | 5,380 |  |

[0001564590-21-009423:notes:220]
Future operating lease payments include $0.3 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0001564590-21-009423:notes:221]
An incremental borrowing rate is used based on information available at the commencement date in determining the present value of lease payments. The incremental borrowing rate is determined on a portfolio basis by grouping leases with similar terms as well as grouping leases based on a U.S. dollar or Euro functional currency. The actual rate is then determined based on a credit spread over LIBOR as well as the Bloomberg Curve Matrix for the U.S. Communications section. The following table provides information about our weighted average lease terms and weighted average discount rates:

[0001564590-21-009423:notes:222]
|  |  | As of December 31, |  |
| Weighted average remaining lease term (years) |  | 2020 |  |  | 2019 |  |
| Operating leases with USD functional currency |  |  | 2.4 |  |  |  | 2.6 |  |
| Operating leases with Euro functional currency |  |  | 3.6 |  |  |  | 4.4 |  |
| Weighted average discount rate |  |  |  |  |  |  |  |  |
| Operating leases with USD functional currency |  |  | 4.47 | % |  |  | 4.02 | % |
| Operating leases with Euro functional currency |  |  | 1.37 | % |  |  | 1.84 | % |

[0001564590-21-009423:notes:223]
Supplemental cash flow information related to operating leases is as follows:

[0001564590-21-009423:notes:224]
|  |  | As of December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Cash paid for amounts included in the measurement of operating lease assets/liabilities |  |  |  |  |  |  |  |  |
| Cash used in operating activities related to operating leases |  | $ | 2,632 |  |  | $ | 3,439 |  |
| Right-of-use assets obtained in exchange for operating lease obligations |  | $ | 324 |  |  | $ | 11,615 |  |

[0001564590-21-009423:notes:225]
Sales-Type Leases

[0001564590-21-009423:notes:226]
We are the lessor in sales-type lease arrangements for network equipment, which have initial terms of up to five years. Our sales-type lease arrangements contain either a provision whereby the network equipment reverts back to us upon the expiration of the lease or a provision that allows the lessee to purchase the network equipment at a bargain purchase amount at the end of the lease. In addition, our sales-type lease arrangements do not contain any residual value guarantees or material restrictive covenants. The allocation of the consideration between lease and non-lease components is determined by stand-alone selling price by component. The net investment in sales-type leases consists of lease receivables less unearned income. Collectability of sales-type leases is evaluated periodically at an individual customer level. The Company has elected to exclude taxes related to sales-type leases from revenue and the associated expense of such taxes. As of December 31, 2020 and 2019, we did not have an allowance for credit losses for our net investment in sales-type leases. As of December 31, 2020 and 2019, the components of the net investment in sales-type leases were as follows:

[0001564590-21-009423:notes:227]
|  |  | As of December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Current minimum lease payments receivable(1) |  | $ | 702 |  |  | $ | 1,201 |  |
| Non-current minimum lease payments receivable(2) |  |  | 347 |  |  |  | 889 |  |
| Total minimum lease payments receivable |  |  | 1,049 |  |  |  | 2,090 |  |
| Less: Current unearned revenue(1) |  |  | 218 |  |  |  | 365 |  |
| Less: Non-current unearned revenue(2) |  |  | 50 |  |  |  | 163 |  |
| Net investment in sales-type leases |  | $ | 781 |  |  | $ | 1,562 |  |

[0001564590-21-009423:notes:228]
|  | (1) | Included in other receivables on the Consolidated Balance Sheets. |

[0001564590-21-009423:notes:229]
|  | (2) | Included in other non-current assets on the Consolidated Balance Sheets. |

[0001564590-21-009423:notes:230]
Components of gross profit related to sales-type lease recognized at the lease commencement date and interest and dividend income, included in the Consolidated Statements of Income (Loss) for the year ended December 31, 2020 and 2019 were as follows:

[0001564590-21-009423:notes:231]
|  |  | For the year ended December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Revenue - Network Solutions |  | $ | 78 |  |  | $ | 1,723 |  |
| Cost of sales - Network Solutions |  |  | 32 |  |  |  | 675 |  |
| Gross profit |  | $ | 46 |  |  | $ | 1,048 |  |
| Interest and dividend income |  | $ | 42 |  |  | $ | 357 |  |

[0001564590-21-009423:notes:232]
As of December 31, 2020 future minimum lease payments to be received from sales-type leases were as follows:

[0001564590-21-009423:notes:233]
| (In thousands) |  | Amount |  |
| 2021 |  | $ | 703 |  |
| 2022 |  |  | 250 |  |
| 2023 |  |  | 88 |  |
| 2024 |  |  | 7 |  |
| 2025 |  |  | 1 |  |
| Total |  | $ | 1,049 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-21-009423:notes:234]
Note 10 – Goodwill

[0001564590-21-009423:notes:235]
Goodwill, all of which relates to our acquisitions of Bluesocket, Inc. in 2011 and SmartRG in 2018, was $7.0 million as of December 31, 2020 and December 31, 2019 of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-21-009423:notes:236]
The Company evaluates the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that could more likely than not reduce the fair value of the reporting unit below its carrying amount.  We have elected to by-pass a qualitative assessment to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount. No impairment charges related to goodwill were recognized during the years ended December 31, 2020, 2019 and 2018.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-21-009423:notes:237]
Note 11 – Intangible Assets

[0001564590-21-009423:notes:238]
Intangible assets as of December 31, 2020 and 2019, consisted of the following:

[0001564590-21-009423:notes:239]
|  |  | 2020 |  |  | 2019 |  |
| (In thousands) |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 21,123 |  |  | $ | (8,055 | ) |  | $ | 13,068 |  |  | $ | 22,356 |  |  | $ | (7,233 | ) |  | $ | 15,123 |  |
| Developed technology |  |  | 8,200 |  |  |  | (2,546 | ) |  |  | 5,654 |  |  |  | 10,170 |  |  |  | (3,379 | ) |  |  | 6,791 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (1,830 | ) |  |  | 4,070 |  |  |  | 5,900 |  |  |  | (1,174 | ) |  |  | 4,726 |  |
| Supplier relationships |  |  | 2,800 |  |  |  | (2,800 | ) |  |  | — |  |  |  | 2,800 |  |  |  | (2,508 | ) |  |  | 292 |  |
| Licensing agreements |  |  | 560 |  |  |  | (152 | ) |  |  | 408 |  |  |  | 560 |  |  |  | (79 | ) |  |  | 481 |  |
| Patents |  |  | 500 |  |  |  | (294 | ) |  |  | 206 |  |  |  | 500 |  |  |  | (226 | ) |  |  | 274 |  |
| Trade names |  |  | 210 |  |  |  | (146 | ) |  |  | 64 |  |  |  | 310 |  |  |  | (176 | ) |  |  | 134 |  |
| Total |  | $ | 39,293 |  |  | $ | (15,823 | ) |  | $ | 23,470 |  |  | $ | 42,596 |  |  | $ | (14,775 | ) |  | $ | 27,821 |  |

[0001564590-21-009423:notes:240]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. No impairment losses of intangible assets were recorded during the year ended December 31, 2020, 2019 or 2018.

[0001564590-21-009423:notes:241]
Amortization expense was $4.4 million, $5.3 million and $2.3 million for the years ended December 31, 2020, 2019 and 2018, respectively, and was included in cost of sales, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Income (Loss).

[0001564590-21-009423:notes:242]
As of December 31, 2020, estimated future amortization expense of intangible assets was as follows:

[0001564590-21-009423:notes:243]
| (In thousands) |  | Amount |  |
| 2021 |  | $ | 4,119 |  |
| 2022 |  |  | 3,494 |  |
| 2023 |  |  | 3,340 |  |
| 2024 |  |  | 3,245 |  |
| 2025 |  |  | 3,031 |  |
| Thereafter |  |  | 6,241 |  |
| Total |  | $ | 23,470 |  |


## us-gaap:DebtDisclosureTextBlock

[0001564590-21-009423:notes:244]
Note 12 – Revolving Credit Agreement

[0001564590-21-009423:notes:245]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company had not made any draws under the Revolving Credit Agreement as of December 31, 2020.


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001564590-21-009423:notes:246]
Note 13 – Alabama State Industrial Development Authority Financing and Economic Incentives

[0001564590-21-009423:notes:247]
In conjunction with the 1995 expansion of our Huntsville, Alabama facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, in January 1995, the Authority issued $20.0 million of its taxable revenue bonds (the “Taxable Revenue Bonds”) and loaned the proceeds from the sale of the Taxable Revenue Bonds to the Company. Further advances on the Taxable Revenue Bonds were made by the Authority, bringing the total amount outstanding to $50.0 million. The Taxable Revenue Bonds bore interest, payable monthly with an interest rate of 2% per annum. The Taxable Revenue Bonds’ aggregate principal amount outstanding of $24.6 million matured on January 1, 2020 and was repaid in full on January 2, 2020, using the funds held in a certificate of deposit by the Company. This certificate of deposit, which totaled $25.6 million, was included in short-term investments on the Consolidated Balance Sheet as of December 31, 2019. We made a principal payment of $1.0 million for the year ended December 31, 2019.

[0001564590-21-009423:notes:248]
In conjunction with this program, we were eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we were required to remit to the state for those employment positions that qualify under the program. Economic incentives realized related to payroll withholdings totaled $0, $1.2 million and $1.4 million for the years ended December 31, 2020, 2019 and 2018, respectively. This program concluded on January 2, 2020 following the maturity of the Taxable Revenue Bonds.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-009423:notes:249]
Note 14 – Income Taxes

[0001564590-21-009423:notes:250]
The components of income tax expense (benefit) for the years ended December 31, 2020, 2019 and 2018 are as follows:

[0001564590-21-009423:notes:251]
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (10,574 | ) |  | $ | (518 | ) |  | $ | (8,001 | ) |
| State |  |  | (329 | ) |  |  | (1,065 | ) |  |  | (476 | ) |
| International |  |  | 3,635 |  |  |  | (282 | ) |  |  | 11,705 |  |
| Total Current |  |  | (7,268 | ) |  |  | (1,865 | ) |  |  | 3,228 |  |
| Deferred |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | — |  |  |  | 24,801 |  |  |  | (14,448 | ) |
| State |  |  | — |  |  |  | 5,815 |  |  |  | (3,390 | ) |
| International |  |  | (1,356 | ) |  |  | (546 | ) |  |  | 581 |  |
| Total Deferred |  |  | (1,356 | ) |  |  | 30,070 |  |  |  | (17,257 | ) |
| Total Income Tax Expense (Benefit) |  | $ | (8,624 | ) |  | $ | 28,205 |  |  | $ | (14,029 | ) |

[0001564590-21-009423:notes:252]
The effective income tax rate differs from the federal statutory rate due to the following:

[0001564590-21-009423:notes:253]
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Tax provision computed at the federal statutory rate |  |  | 21.00 | % |  |  | 21.00 | % |  |  | 21.00 | % |
| State income tax provision, net of federal benefit |  |  | 11.10 |  |  |  | 6.97 |  |  |  | 14.53 |  |
| Federal research credits |  |  | 57.63 |  |  |  | 15.53 |  |  |  | 14.23 |  |
| Foreign taxes |  |  | (17.83 | ) |  |  | 2.83 |  |  |  | (11.45 | ) |
| Tax-exempt income |  |  | 1.93 |  |  |  | 0.49 |  |  |  | 0.45 |  |
| State tax incentives |  |  | — |  |  |  | 3.85 |  |  |  | 3.15 |  |
| Change in valuation allowance |  |  | 44.79 |  |  |  | (172.82 | ) |  |  | — |  |
| Foreign tax credits |  |  | 17.90 |  |  |  | 16.69 |  |  |  | — |  |
| Stock-based compensation |  |  | (23.36 | ) |  |  | (6.01 | ) |  |  | (2.87 | ) |
| Withholding taxes |  |  | (20.83 | ) |  |  | — |  |  |  | — |  |
| Bargain purchase |  |  | — |  |  |  | — |  |  |  | 8.82 |  |
| Impact of CARES Act |  |  | 45.65 |  |  |  | — |  |  |  | — |  |
| Impact of U.S. tax reform |  |  | — |  |  |  | — |  |  |  | 12.00 |  |
| Global intangible low-taxed income ("GILTI") |  |  | (0.49 | ) |  |  | (1.87 | ) |  |  | (17.48 | ) |
| Other, net |  |  | 0.56 |  |  |  | (0.49 | ) |  |  | (0.34 | ) |
| Effective Tax Rate |  |  | 138.05 | % |  |  | (113.83 | )% |  |  | 42.04 | % |

[0001564590-21-009423:notes:254]
Income (loss) before expense (benefit) for income taxes for the years ended December 31, 2020, 2019 and 2018 is as follows:

[0001564590-21-009423:notes:255]
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| U.S. entities |  | $ | (12,833 | ) |  | $ | (29,829 | ) |  | $ | (74,131 | ) |
| International entities |  |  | 6,587 |  |  |  | 5,052 |  |  |  | 40,760 |  |
| Total |  | $ | (6,246 | ) |  | $ | (24,777 | ) |  | $ | (33,371 | ) |

[0001564590-21-009423:notes:256]
Income (loss) before expense (benefit) for income taxes for international entities reflects income (loss) based on statutory transfer pricing agreements. This amount does not correlate to consolidated international revenue, which occurs from our U.S. entity.

[0001564590-21-009423:notes:257]
Deferred income taxes on the Consolidated Balance Sheets result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The significant components of current and non-current deferred taxes as of December 31, 2020 and 2019 consist of the following:

[0001564590-21-009423:notes:258]
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Inventory |  | $ | 8,882 |  |  | $ | 7,144 |  |
| Accrued expenses |  |  | 2,331 |  |  |  | 2,330 |  |
| Deferred compensation |  |  | 6,714 |  |  |  | 5,660 |  |
| Stock-based compensation |  |  | 1,971 |  |  |  | 2,451 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 149 |  |  |  | 241 |  |
| Pensions |  |  | 8,554 |  |  |  | 7,074 |  |
| Foreign losses |  |  | 2,590 |  |  |  | 2,925 |  |
| State losses and credit carry-forwards |  |  | 5,509 |  |  |  | 3,995 |  |
| Federal loss and research carry-forwards |  |  | 17,323 |  |  |  | 12,171 |  |
| Lease liabilities |  |  | 1,588 |  |  |  | 2,496 |  |
| Capitalized research and development expenditures |  |  | 11,832 |  |  |  | 22,230 |  |
| Valuation allowance |  |  | (45,818 | ) |  |  | (48,616 | ) |
| Total Deferred Tax Assets |  |  | 21,625 |  |  |  | 20,101 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Property, plant and equipment |  |  | (4,546 | ) |  |  | (2,815 | ) |
| Intellectual property |  |  | (4,375 | ) |  |  | (5,337 | ) |
| Right of use lease assets |  |  | (1,585 | ) |  |  | (2,496 | ) |
| Investments |  |  | (1,250 | ) |  |  | (1,892 | ) |
| Total Deferred Tax Liabilities |  |  | (11,756 | ) |  |  | (12,540 | ) |
| Net Deferred Tax Assets |  | $ | 9,869 |  |  | $ | 7,561 |  |

[0001564590-21-009423:notes:259]
On March 27, 2020, the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) was signed into law. Subsequently, the Internal Revenue Service (“IRS”) released its final Global Intangible Low Tax Income (“GILTI”) regulations on July 9, 2020. The passage of the CARES Act and subsequent issuance of the GILTI final regulations together resulted in the Company’s recognition of a tax benefit in the amount of $10.8 million during 2020, $7.9 million of which related to the utilization of deferred tax assets which had previously been offset with a valuation allowance and $2.9 million primarily related to the tax rate differential on carrying back losses from 2018 and 2019 tax years to prior years in which the U.S. Corporate tax rate was 35% versus the current 21% federal tax rate.

[0001564590-21-009423:notes:260]
As of December 31, 2020 and 2019, non-current deferred taxes reflect deferred taxes on net unrealized gains and losses on available-for-sale investments and deferred taxes on unrealized losses in our pension plan. The net change in non-current deferred taxes associated with these items, which resulted in a deferred tax benefit of $0.1 million and $0.4 million in 2020 and 2019, respectively, was recorded as an adjustment to other comprehensive income (loss), presented in the Consolidated Statements of Comprehensive Income (Loss).

[0001564590-21-009423:notes:261]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. Our assessment of the realizability of our deferred tax assets includes the evaluation of evidence, some of which requires significant judgement, including historical operating results, the evaluation of a three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and additional valuation allowance or a partial or full release of the valuation allowance is necessary, it could have a material effect on our consolidated financial statements.

[0001564590-21-009423:notes:262]
As of December 31, 2020 and 2019, the Company had gross deferred tax assets totaling $55.7 million offset by a valuation allowance totaling $45.8 million and gross deferred tax assets totaling $56.2 million offset by a valuation allowance of $48.6 million, respectively. Of the current valuation allowance, $43.8 million has been established against our domestic deferred tax assets and the remaining $2.0 million is related to foreign net operating loss and research and development credit carryforwards where we lack sufficient activity to realize those deferred tax assets. The change in our valuation allowance for the year ending December 31, 2020 was a decrease of $2.8 million. The change in the valuation allowance was primarily related to increases in our deferred tax assets during the year, offset with the impact of monetizing deferred tax assets through net operating loss carryback claims related to the CARES Act of $7.9 million. As of December 31, 2020, the remaining $9.9 million in deferred tax assets that were not offset by a valuation allowance are located in various foreign jurisdictions where the Company believes it is more likely than not we will realize these deferred tax assets.

[0001564590-21-009423:notes:263]
Supplemental balance sheet information related to deferred tax assets as of December 31, 2020 and 2019 is as follows:

[0001564590-21-009423:notes:264]
|  |  | December 31, 2020 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 43,791 |  |  | $ | (43,791 | ) |  | $ | — |  |
| International |  |  | 11,896 |  |  |  | (2,027 | ) |  |  | 9,869 |  |
| Total |  | $ | 55,687 |  |  | $ | (45,818 | ) |  | $ | 9,869 |  |

[0001564590-21-009423:notes:265]
|  |  | December 31, 2019 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 46,266 |  |  | $ | (46,266 | ) |  | $ | — |  |
| International |  |  | 9,911 |  |  |  | (2,350 | ) |  |  | 7,561 |  |
| Total |  | $ | 56,177 |  |  | $ | (48,616 | ) |  | $ | 7,561 |  |

[0001564590-21-009423:notes:266]
As of December 31, 2020 and 2019, the deferred tax assets for foreign and domestic loss carry-forwards, research and development tax credits, unamortized research and development costs and state credit carry-forwards totaled $37.3 million and $41.3 million, respectively. As of December 31, 2020, $25.1 million of these deferred tax assets will expire at various times between 2021 and 2040. The remaining deferred tax assets will either amortize through 2029 or carryforward indefinitely.

[0001564590-21-009423:notes:267]
As of December 31, 2020 and 2019, respectively, our cash and cash equivalents were $60.2 million and $73.8 million and short-term investments were $3.1 million and $33.2 million, which provided available short-term liquidity of $63.3 million and $107.0 million. Of these amounts, our foreign subsidiaries held cash of $49.7 million and $52.3 million, respectively, representing approximately 78.5% and 48.9% of available short-term liquidity, which is used to fund ongoing liquidity needs of these subsidiaries. As part of our restructuring plan, the Company’s assertion on being indefinitely reinvested changed in a particular jurisdiction during the current year resulting in the accrual of $0.7 million in withholding tax liabilities. The Company maintains its assertion in all other jurisdictions that it is indefinitely reinvesting its funds held in foreign jurisdictions outside of the U.S., except to the extent any of these funds can be repatriated without withholding tax. However, if all of these funds were repatriated to the U.S., or used for U.S. operations, certain amounts could be subject to tax. Due to the timing and circumstances of repatriation of such earnings, if any, it is not practicable to determine the amount of funds subject to unrecognized deferred tax liability.

[0001564590-21-009423:notes:268]
During 2020, 2019 and 2018, no income tax benefit or expense was recorded for stock options exercised as an adjustment to equity.

[0001564590-21-009423:notes:269]
The change in the unrecognized income tax benefits for the years ended December 31, 2020, 2019 and 2018 is reconciled below:

[0001564590-21-009423:notes:270]
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 1,487 |  |  | $ | 1,868 |  |  | $ | 2,366 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | 4 |  |  |  | — |  |  |  | 3 |  |
| Current year |  |  | 165 |  |  |  | 161 |  |  |  | 254 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | (71 | ) |  |  | — |  |
| Expiration of applicable statute of limitations |  |  | (578 | ) |  |  | (471 | ) |  |  | (755 | ) |
| Balance at end of period |  | $ | 1,078 |  |  | $ | 1,487 |  |  | $ | 1,868 |  |

[0001564590-21-009423:notes:271]
As of December 31, 2020, 2019 and 2018, our total liability for unrecognized tax benefits was $1.1 million, $1.5 million and $1.9 million, respectively, of which $1.0 million, $1.4 million and $1.7 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of December 31, 2020, 2019 and 2018, the balances of accrued interest and penalties were $0.3 million, $0.5 million and $0.7 million, respectively.

[0001564590-21-009423:notes:272]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date. We file income tax returns in the U.S. for federal and various state jurisdictions and several foreign jurisdictions. We are not currently under audit by the Internal Revenue Service. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2017.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-21-009423:notes:273]
Note 15 – Employee Benefit Plans

[0001564590-21-009423:notes:274]
Pension Benefit Plan

[0001564590-21-009423:notes:275]
We maintain a defined benefit pension plan covering employees in certain foreign countries.

[0001564590-21-009423:notes:276]
The pension benefit plan obligations and funded status as of December 31, 2020 and 2019, were as follows:

[0001564590-21-009423:notes:277]
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 43,902 |  |  | $ | 37,245 |  |
| Service cost |  |  | 1,270 |  |  |  | 1,471 |  |
| Interest cost |  |  | 444 |  |  |  | 634 |  |
| Actuarial (gain) loss - experience |  |  | (744 | ) |  |  | 453 |  |
| Actuarial loss - assumptions |  |  | 2,458 |  |  |  | 5,091 |  |
| Benefit payments |  |  | (509 | ) |  |  | (166 | ) |
| Effects of foreign currency exchange rate changes |  |  | 4,106 |  |  |  | (826 | ) |
| Projected benefit obligation at end of period |  |  | 50,927 |  |  |  | 43,902 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  |  | 28,016 |  |  |  | 24,159 |  |
| Actual gain on plan assets |  |  | 1,744 |  |  |  | 4,392 |  |
| Contributions |  |  | 24 |  |  |  | — |  |
| Effects of foreign currency exchange rate changes |  |  | 2,479 |  |  |  | (535 | ) |
| Fair value of plan assets at end of period |  |  | 32,263 |  |  |  | 28,016 |  |
| Unfunded status at end of period |  | $ | (18,664 | ) |  | $ | (15,886 | ) |

[0001564590-21-009423:notes:278]
The accumulated benefit obligation was $50.9 million and $43.9 million as of December 31, 2020 and 2019, respectively. The increase in the accumulated benefit obligation, projected benefit obligation and the actuarial loss was primarily attributable to a decrease in the discount rate during 2020.

[0001564590-21-009423:notes:279]
The net amounts recognized in the Consolidated Balance Sheets for the unfunded pension liability as of December 31, 2020 and 2019 were as follows:

[0001564590-21-009423:notes:280]
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Current liability |  | $ | — |  |  | $ | — |  |
| Pension liability |  |  | 18,664 |  |  |  | 15,886 |  |
| Total |  | $ | 18,664 |  |  | $ | 15,886 |  |

[0001564590-21-009423:notes:281]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Consolidated Statements of Income (Loss). The components of net periodic pension cost and amounts recognized in other comprehensive income (loss) for the years ended December 31, 2020, 2019 and 2018 were as follows:

[0001564590-21-009423:notes:282]
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,270 |  |  | $ | 1,471 |  |  | $ | 1,193 |  |
| Interest cost |  |  | 444 |  |  |  | 634 |  |  |  | 727 |  |
| Expected return on plan assets |  |  | (1,679 | ) |  |  | (1,392 | ) |  |  | (1,548 | ) |
| Amortization of actuarial losses |  |  | 970 |  |  |  | 795 |  |  |  | 247 |  |
| Net periodic benefit cost |  |  | 1,005 |  |  |  | 1,508 |  |  |  | 619 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | 1,784 |  |  |  | 2,488 |  |  |  | 5,638 |  |
| Amortization of actuarial losses |  |  | (1,212 | ) |  |  | (771 | ) |  |  | (196 | ) |
| Amount recognized in other comprehensive income (loss) |  |  | 572 |  |  |  | 1,717 |  |  |  | 5,442 |  |
| Total recognized in net periodic benefit cost and other comprehensive income (loss) |  | $ | 1,577 |  |  | $ | 3,225 |  |  | $ | 6,061 |  |

[0001564590-21-009423:notes:283]
The amounts recognized in accumulated other comprehensive income (loss) as of December 31, 2020 and 2019 were as follows:

[0001564590-21-009423:notes:284]
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Net actuarial loss |  | $ | (13,545 | ) |  | $ | (12,973 | ) |

[0001564590-21-009423:notes:285]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations.

[0001564590-21-009423:notes:286]
The weighted-average assumptions that were used to determine the net periodic benefit cost for the years ended December 31, 2020, 2019 and 2018 were as follows:

[0001564590-21-009423:notes:287]
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Discount rate |  |  | 1.00 | % |  |  | 1.75 | % |  |  | 2.13 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.00 | % |  |  | 2.00 | % |
| Expected long-term rates of return |  |  | 5.90 | % |  |  | 5.90 | % |  |  | 5.90 | % |

[0001564590-21-009423:notes:288]
The weighted-average assumptions that were used to determine the benefit obligation as of December 31, 2020 and 2019:

[0001564590-21-009423:notes:289]
|  |  | 2020 |  |  | 2019 |  |
| Discount rate |  |  | 0.69 | % |  |  | 1.00 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.00 | % |

[0001564590-21-009423:notes:290]
Actuarial gains and losses are recorded in accumulated other comprehensive income (loss). To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants.

[0001564590-21-009423:notes:291]
We do not anticipate making any contributions to the pension plan in 2021.

[0001564590-21-009423:notes:292]
The following pension benefit payments, which reflect expected future service, as appropriate, are expected to be paid to participants:

[0001564590-21-009423:notes:293]
| (In thousands) |  |  |  |  |
| 2021 |  | $ | 714 |  |
| 2022 |  |  | 1,048 |  |
| 2023 |  |  | 1,348 |  |
| 2024 |  |  | 1,657 |  |
| 2025 |  |  | 1,621 |  |
| 2026 - 2030 |  |  | 7,615 |  |
| Total |  | $ | 14,003 |  |

[0001564590-21-009423:notes:294]
|  | • | Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market; |

[0001564590-21-009423:notes:295]
|  | • | Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; |

[0001564590-21-009423:notes:296]
|  | • | Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees. |

[0001564590-21-009423:notes:297]
We have categorized our cash equivalents and our investments held at fair value into this hierarchy as follows:

[0001564590-21-009423:notes:298]
|  |  | Fair Value Measurements at December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash and cash equivalents |  | $ | 1,935 |  |  | $ | 1,935 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 6,746 |  |  |  | 6,746 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 5,971 |  |  |  | 5,971 |  |  |  | — |  |  |  | — |  |
| Emerging markets bonds |  |  | 307 |  |  |  | 307 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global equity |  |  | 11,638 |  |  |  | 11,638 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 2,515 |  |  |  | 2,515 |  |  |  | — |  |  |  | — |  |
| Emerging markets |  |  | 1,848 |  |  |  | 1,848 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 198 |  |  |  | 198 |  |  |  | — |  |  |  | — |  |
| Global real estate fund |  |  | 799 |  |  |  | 799 |  |  |  | — |  |  |  | — |  |
| Managed futures fund |  |  | 306 |  |  |  | 306 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 30,328 |  |  |  | 30,328 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 32,263 |  |  | $ | 32,263 |  |  | $ | — |  |  | $ | — |  |

[0001564590-21-009423:notes:299]
|  |  | Fair Value Measurements at December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash and cash equivalents |  | $ | 691 |  |  | $ | 691 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Government bonds |  |  | 6,645 |  |  |  | 6,645 |  |  |  | — |  |  |  | — |  |
| Corporate bonds |  |  | 5,514 |  |  |  | 5,514 |  |  |  | — |  |  |  | — |  |
| Emerging markets bonds |  |  | 531 |  |  |  | 531 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Global equity |  |  | 11,071 |  |  |  | 11,071 |  |  |  | — |  |  |  | — |  |
| Emerging markets |  |  | 956 |  |  |  | 956 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 863 |  |  |  | 863 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 312 |  |  |  | 312 |  |  |  | — |  |  |  | — |  |
| Global real estate fund |  |  | 902 |  |  |  | 902 |  |  |  | — |  |  |  | — |  |
| Managed futures fund |  |  | 531 |  |  |  | 531 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 27,325 |  |  |  | 27,325 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 28,016 |  |  | $ | 28,016 |  |  | $ | — |  |  | $ | — |  |

[0001564590-21-009423:notes:300]
Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. Central to the policy are target allocation ranges by asset class, which is currently 50% for bond funds, 40% for equity funds and 10% for cash, real estate and managed futures. The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies.

[0001564590-21-009423:notes:301]
The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations.

[0001564590-21-009423:notes:302]
401(k) Savings Plan

[0001564590-21-009423:notes:303]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (the “Savings Plan”) for the benefit of eligible employees. The Savings Plan is intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (the “Code”), and is intended to be a “safe harbor” 401(k) plan under Code Section 401(k)(12). The Savings Plan allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plan also requires us to contribute a “safe harbor” amount each year. We match up to 4% of employee contributions (100% of an employee’s first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s one-year anniversary date. In calculating our matching contribution, compensation up to the statutory maximum under the Code is used ($285,000 for 2020). All matching contributions under the Savings Plan vest immediately. Employer contribution expense and plan administration costs for the Savings Plan amounted to approximately $4.0 million, $4.4 million and $4.4 million in 2020, 2019 and 2018, respectively.

[0001564590-21-009423:notes:304]
Deferred Compensation Plans

[0001564590-21-009423:notes:305]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors.

[0001564590-21-009423:notes:306]
The ADTRAN, Inc. Deferred Compensation Program for Employees is offered as a supplement to our tax-qualified 401(k) plan and is available to certain executive management employees who have been designated by our Board of Directors. This deferred compensation plan allows participants to defer all or a portion of certain specified bonuses and up to 25% of remaining cash compensation and permits us to make matching contributions on a discretionary basis without the limitations that apply to the 401(k) plan. To date, we have not made any matching contributions under this plan. We also maintain the ADTRAN, Inc. Equity Deferral Program for Employees. Under this plan, participants may elect to defer all or a portion of their vested PSUs and RSUs to the plan. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the participant.

[0001564590-21-009423:notes:307]
For our Board of Directors, we maintain the ADTRAN, Inc. Deferred Compensation Program for Directors. This program allows our Board of Directors to defer all or a portion of monetary remuneration paid to the Director, including, but not limited to, meeting fees and annual retainers. We also maintain the ADTRAN, Inc. Equity Deferral Program for Directors. Under this plan, participants may elect to defer all or a portion of their vested restricted stock awards. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the director.

[0001564590-21-009423:notes:308]
We have set aside the plan assets for all plans in a rabbi trust (the “Trust”) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant and the participant’s bookkeeping account is credited with the earnings and losses attributable to those investments. Benefits are scheduled to be distributed six months after termination of employment in a single lump sum payment or annual installments paid over a three or ten-year term based on the participant’s election. Distributions will be made on a pro-rata basis from each of the hypothetical investments of the participant’s account in cash. Any whole shares of ADTRAN, Inc. common stock that are distributed will be distributed in-kind.

[0001564590-21-009423:notes:309]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging from equities to money market instruments. These mutual funds are publicly quoted and reported at fair value. The fair value of the assets held by the Trust and the amounts payable to the plan participants as of December 31, 2020 and 2019 were as follows:

[0001564590-21-009423:notes:310]
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |  |  |
| Long-term investments |  | $ | 23,891 |  |  | $ | 21,698 |  |
| Total Fair Value of Plan Assets |  | $ | 23,891 |  |  | $ | 21,698 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |  |  |
| Deferred compensation liability |  | $ | 25,866 |  |  | $ | 21,698 |  |
| Total Amounts Payable to Plan Participants |  | $ | 25,866 |  |  | $ | 21,698 |  |

[0001564590-21-009423:notes:311]
The Trust held $2.8 million of common stock in the Company as of December 31, 2020. Shares of the Company held by the Trust are recorded at cost and classified as treasury stock on the Consolidated Balance Sheet.

[0001564590-21-009423:notes:312]
Interest and dividend income of the Trust are included in interest and dividend income in the accompanying 2020, 2019 and 2018 Consolidated Statements of Income (Loss). Changes in the fair value of the plan assets held by the Trust have been included in other income (expense) in the accompanying 2020, 2019 and 2018 Consolidated Statements of Income (Loss). Changes in the fair value of the deferred compensation liability are included as selling, general and administrative expense in the accompanying 2020, 2019 and 2018 Consolidated Statements of Income (Loss). Based on the changes in the total fair value of the Trust’s assets, we recorded deferred compensation income (expense) in 2020, 2019 and 2018 of $4.3 million, $3.6 million and $(2.1) million, respectively.

[0001564590-21-009423:notes:313]
Retiree Medical Coverage

[0001564590-21-009423:notes:314]
Medical, dental and prescription drug coverage is provided to certain spouses and former spouses of current and former officers on the same terms as provided to our active officers for up to 30 years. As of December 31, 2020 and 2019, this liability totaled $0.2 million and $0.1 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-009423:notes:315]
Note 16 – Segment Information and Major Customers

[0001564590-21-009423:notes:316]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. Network Solutions includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes a portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-21-009423:notes:317]
The performance of each segment is evaluated based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense) and income tax (expense) benefit are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0001564590-21-009423:notes:318]
The following table presents information about revenue and gross profit of our reportable segments for each of the years ended December 31, 2020, 2019 and 2018:

[0001564590-21-009423:notes:319]
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 438,015 |  |  | $ | 193,789 |  |  | $ | 455,226 |  |  | $ | 191,549 |  |  | $ | 458,232 |  |  | $ | 179,303 |  |
| Services & Support |  |  | 68,495 |  |  |  | 23,762 |  |  |  | 74,835 |  |  |  | 27,618 |  |  |  | 71,045 |  |  |  | 24,262 |  |
| Total |  | $ | 506,510 |  |  | $ | 217,551 |  |  | $ | 530,061 |  |  | $ | 219,167 |  |  | $ | 529,277 |  |  | $ | 203,565 |  |

[0001564590-21-009423:notes:320]
In addition to our reportable segments, revenue is also reported for the following three categories – (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products.

[0001564590-21-009423:notes:321]
Additional Information

[0001564590-21-009423:notes:322]
The following table presents revenue information by geographic area for the years ended December 31, 2020, 2019 and 2018:

[0001564590-21-009423:notes:323]
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| United States |  | $ | 352,079 |  |  | $ | 300,853 |  |  | $ | 288,843 |  |
| Germany |  |  | 74,882 |  |  |  | 78,062 |  |  |  | 167,251 |  |
| Mexico |  |  | 4,087 |  |  |  | 90,795 |  |  |  | 12,186 |  |
| Other international |  |  | 75,462 |  |  |  | 60,351 |  |  |  | 60,997 |  |
| Total |  | $ | 506,510 |  |  | $ | 530,061 |  |  | $ | 529,277 |  |

[0001564590-21-009423:notes:324]
Customers comprising more than 10% of revenue can change from year to year. Single customers comprising more than 10% of revenue in 2020 included three customers, at 15%, 12% and 10%, of which one was a distributor. Single customers comprising more than 10% of revenue in 2019 included three customers at 19%, 17% and 13%. Single customers comprising more than 10% of revenue in 2018 included two customers at 27% and 17%. Other than those with more than 10% of revenues disclosed above, and excluding distributors, our next five largest customers can change, and have historically changed, from year-to-year. The next five largest customers combined represented 19%, 15% and 18% of total revenue in 2020, 2019 and 2018, respectively.

[0001564590-21-009423:notes:325]
As of December 31, 2020, property, plant and equipment, net totaled $62.4 million, which included $58.4 million held in the U.S. and $4.0 million held outside the U.S. As of December 31, 2019, property, plant and equipment, net totaled $68.1 million, which included $64.2 million held in the U.S. and $3.9 million held outside the U.S. Property, plant and equipment, net is reported on a Company-wide, functional basis only.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-009423:notes:326]
Note 17 – Commitments and Contingencies

[0001564590-21-009423:notes:327]
Securities Class Action Lawsuit

[0001564590-21-009423:notes:328]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The lawsuit was transferred to the U.S. District Court for the Northern District of Alabama on January 7, 2020, and co-lead plaintiffs have been appointed to represent the putative class. The plaintiffs filed an amended complaint on April 30, 2020. The defendants filed a motion to dismiss the amended complaint on June 17, 2020. The plaintiffs filed an opposition brief to the defendants’ motion to dismiss on July 17, 2020. The defendants filed a reply to the plaintiffs’ brief on August 17, 2020. The motion to dismiss remains under review by the Court. We deny the allegations in the complaint, as amended, and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-21-009423:notes:329]
Shareholder Derivative Lawsuit

[0001564590-21-009423:notes:330]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, makes similar allegations as the stockholder class action lawsuit and accuses the directors and officers of breaches of fiduciary duty in connection with those allegations. On June 7, 2020, the Court entered an order staying the derivative litigation pending resolution of the motion to dismiss in the securities class action. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-21-009423:notes:331]
Other Legal Matters

[0001564590-21-009423:notes:332]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001564590-21-009423:notes:333]
Performance Bonds

[0001564590-21-009423:notes:334]
Certain contracts, customers and/or jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2020, we had commitments related to these bonds totaling $15.2 million which expire at various dates through August 2024. As of December 31, 2019, we had commitments related to these bonds totaling $9.3 million. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001564590-21-009423:notes:335]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. As of December 31, 2020, the Company was required to maintain a minimum collateral value of $9.0 million. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $11.2 million as of December 31, 2020, of which less than $0.1 million is included in restricted cash and $11.2 million is included in long-term investments on the Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. We expect to reach the maximum value of our minimum collateral requirement of $15.0 million in the first quarter of 2021 as the Company reaches certain milestones through the first quarter of 2021 as outlined in the customer contract. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of December 31, 2020, the Company was in compliance with all contractual requirements under the letter of credit.

[0001564590-21-009423:notes:336]
Investment Commitment

[0001564590-21-009423:notes:337]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been applied to these commitments as of December 31, 2020.


## us-gaap:CreditLossFinancialInstrumentTextBlock

[0001564590-21-009423:notes:338]
Note 18 – Current Expected Credit Losses

[0001564590-21-009423:notes:339]
Under ASC 326 – Financial Instruments – Credit Losses, the Company estimates credit losses for the contractual life of assets that are measured at amortized cost and are within the scope of this guidance, which includes accounts receivable, net investment in sales-type leases, contract assets under the revenue recognition model and outstanding notes receivable. Where appropriate, the Company pools assets if similar risk characteristics exist. Additionally, the Company analyzes its available-for-sale debt securities for impairment and records a credit loss allowance as needed.

[0001564590-21-009423:notes:340]
Assets Measured at Amortized Cost

[0001564590-21-009423:notes:341]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. Accounts receivable balances are considered past due when payment has not been received by the date indicated on the relevant invoice or based on agreed upon terms between the customer and the Company.

[0001564590-21-009423:notes:342]
As of December 31, 2020 and January 1, 2020 (the “implementation date”), the Company’s net outstanding accounts receivable balance was $98.8 million and $90.5 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable as of December 31, 2020 and January 1, 2020 using the historical loss-rate method as well as assessing asset-specific risks. The Company’s historical losses related to accounts receivable have been immaterial as evidenced by its historical allowance and write-offs due to uncollectability. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0001564590-21-009423:notes:343]
No allowance for credit loss was recorded for the year ended December 31, 2020 or on January 1, 2020 related to accounts receivable. The Company’s allowance for credit losses related to accounts receivable was less than $0.1 million as of December 31, 2020 and December 31, 2019, all of which was expensed prior to January 1, 2020.

[0001564590-21-009423:notes:344]
Contract Assets

[0001564590-21-009423:notes:345]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of December 31, 2020 and January 1, 2020, the Company’s outstanding contract asset balance was $0.1 million and $2.8 million, respectively, which is included in other receivables on the Consolidated Balance Sheets as of December 31, 2020 and December 31, 2019. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets as of December 31, 2020 and January 1, 2020 using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to uncollectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0001564590-21-009423:notes:346]
No allowance for credit loss was recorded for the year ended December 31, 2020 or on the implementation date related to contract assets.

[0001564590-21-009423:notes:347]
Net Investment in Sales-Type Leases

[0001564590-21-009423:notes:348]
The Company is the lessor in sales-type lease arrangements for network equipment. As of December 31, 2020 and January 1, 2020, the Company’s outstanding net investment in sales-type leases was $0.8 million and $1.6 million, respectively, which is included in other receivables and other non-current assets on the Consolidated Balance Sheets as of December 31, 2020 and 2019. The Company assessed the need for an allowance for credit losses related to future receivables under its outstanding sales-type leases as of December 31, 2020 and January 1, 2020 using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to uncollectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates.

[0001564590-21-009423:notes:349]
The following table presents amortized cost basis in sales-type leases based on payment activity:

[0001564590-21-009423:notes:350]
|  |  | Sales-Type Leases Amortized Cost Basis by Origination Year |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |  | 2017 |  |  | 2016 |  |  | Prior |  |  | Total |  |
| Payment performance |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Performing |  | $ | 55 |  |  | $ | 192 |  |  | $ | 354 |  |  | $ | 128 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 781 |  |
| Non-performing |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 55 |  |  | $ | 192 |  |  | $ | 354 |  |  | $ | 128 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 781 |  |

[0001564590-21-009423:notes:351]
Sales-type lease receivables are considered past due when payment has not been received based on agreed upon terms between the customer and the Company. No allowance for credit loss was recorded for the year ended December 31, 2020 or on the implementation date related to sales-type leases.

[0001564590-21-009423:notes:352]
Secured Loan Receivable

[0001564590-21-009423:notes:353]
The Company has a secured loan receivable totaling $0.9 million as of December 31, 2020 and January 1, 2020, which originated in February 2019, and is included in long-term investments on the Consolidated Balance Sheets as of December 31, 2020 and 2019. The Company assessed the need for an allowance for credit loss related to its secured loan receivable as of December 31, 2020 and January 1, 2020 using the historical loss-rate method as well as asset-specific risks. There have been no historical losses related to this receivable. Asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect the customer’s ability to repay the loan upon maturity, such as the customer’s current financial condition, credit rating specific to the customer as determined by a third party and current overall economic conditions, as well as a Company valuation prepared by a third party which was based on reasonable and supportable forecasts as provided by management. Accrued interest receivable on the secured loan receivable, which is included in other receivables on the Consolidated Balance Sheets totaled less than $0.1 million as of December 31, 2020 and January 1, 2020, and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election.

[0001564590-21-009423:notes:354]
No allowance for credit loss was recorded for the year ended December 31, 2020 or on the implementation date related to the secured loan receivable.

[0001564590-21-009423:notes:355]
Off-Balance Sheet Arrangements

[0001564590-21-009423:notes:356]
The Company did not have any off-balance sheet arrangements as of December 31, 2020 or January 1, 2020.

[0001564590-21-009423:notes:357]
Available-for-Sale Debt Securities

[0001564590-21-009423:notes:358]
As of December 31, 2020 and January 1, 2020, the Company’s available-for-sale debt securities totaled $45.1 million and $37.7 million, respectively. These securities were analyzed at the individual investment level, by Committee on Uniform Securities Identification Procedures (“CUSIP”), to limit credit losses, if applicable, to reflect only the amount by which the fair value of the security was less than its amortized cost. The Company noted that, as of December 31, 2020 and January 1, 2020, there was no intent to sell any of its available-for-sale debt securities before maturity, and, therefore, the Company assessed the need for an allowance for each of its available-for-sale debt securities in which the fair value was less than its amortized cost as of December 31, 2020 and January 1, 2020. Accrued interest receivable on available-for-sale debt securities, which is included in other receivables on the Consolidated Balance Sheets as of December 31, 2020 and 2019, totaled $0.1 million as of December 31, 2020 and January 1, 2020, and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election. Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Consolidated Statements of Income (Loss).

[0001564590-21-009423:notes:359]
The Company had 42 positions in available-for-sale debt securities that were in an unrealized loss position as of December 31, 2020. See Note 6 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-21-009423:notes:360]
For those available-for-sale debt securities whose fair value was less than its amortized cost basis, the Company analyzed additional criteria such as adverse conditions specifically related to the security, an industry or geographic area, failure of the issuer of the security to make scheduled interest or principal payments, if applicable, and any changes to the rating of the security by a rating agency to determine if a credit loss existed. The Company used information provided by its investment manager to determine if any scheduled interest or principal payments had not been received and used a third party to determine if any changes to credit ratings had occurred. The Company noted that all principal and interest payments had been received as scheduled and that there had been no changes in credit ratings year-over-year or period-over-period that warranted further review.

[0001564590-21-009423:notes:361]
No allowance for credit loss was recorded for the year ended December 31, 2020 or on the implementation date related to the Company’s available-for-sale debt securities.


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-009423:notes:362]
Note 19 – Earnings (Loss) per Share

[0001564590-21-009423:notes:363]
The calculations of basic and diluted earnings (loss) per share for the years ended December 31, 2020, 2019 and 2018 are as follows:

[0001564590-21-009423:notes:364]
| (In thousands, except for per share amounts) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income (Loss) |  | $ | 2,378 |  |  | $ | (52,982 | ) |  | $ | (19,342 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,996 |  |  |  | 47,836 |  |  |  | 47,880 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | 292 |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 48,288 |  |  |  | 47,836 |  |  |  | 47,880 |  |
| Earnings (loss) per share – basic |  | $ | 0.05 |  |  | $ | (1.11 | ) |  | $ | (0.40 | ) |
| Earnings (loss) per share – diluted |  | $ | 0.05 |  |  | $ | (1.11 | ) |  | $ | (0.40 | ) |

[0001564590-21-009423:notes:365]
For the years ended December 31, 2020 and 2019, 0.1 million and 0.5 million shares, respectively, of unvested or unearned, as applicable, PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0001564590-21-009423:notes:366]
For the year ended December 31, 2020 and 2019, 3.6 million and 5.2 million stock options were outstanding but were not included in the computation of diluted earnings per share due to the fact that their exercise prices were greater than the average market price of the common shares during the quarter, making them anti-dilutive under the treasury stock method.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-009423:notes:367]
Note 20 – Restructuring

[0001564590-21-009423:notes:368]
During the second half of 2019, the Company initiated a restructuring plan to realign its expense structure with the reduction in revenue experienced in recent years and overall Company objectives. As part of this restructuring plan, the Company announced plans to reduce its overall operating expenses, both in the U.S. and internationally. Management continued to assess the efficiency of operations during 2020 and, in turn, consolidated locations and personnel, among other things, where possible.

[0001564590-21-009423:notes:369]
In February 2019, the Company announced the restructuring of a certain portion of its workforce predominantly in Germany, which included the closure of the Company’s office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. Voluntary early retirement was offered to certain other employees and was announced in March 2019 and again in August 2020.

[0001564590-21-009423:notes:370]
The cumulative amount of restructuring expenses incurred as of December 31, 2020 for the restructuring plans announced in the second half of 2019 and continuing in 2020 was $12.2 million.

[0001564590-21-009423:notes:371]
In January 2018, the Company announced an early retirement incentive program for employees that met certain defined requirements. The cumulative amount incurred during the year ended December 31, 2018 related to this restructuring program was $7.3 million. We did not incur any additional expenses related to this restructuring program during the year ended December 31, 2019 or 2020.

[0001564590-21-009423:notes:372]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Consolidated Balance Sheets as of December 31, 2020 and 2019, is as follows:

[0001564590-21-009423:notes:373]
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 1,568 |  |  | $ | 185 |  |
| Plus: Amounts charged to cost and expense |  |  | 6,229 |  |  |  | 6,014 |  |
| Less: Amounts paid |  |  | (3,611 | ) |  |  | (4,631 | ) |
| Balance at end of period |  | $ | 4,186 |  |  | $ | 1,568 |  |

[0001564590-21-009423:notes:374]
Restructuring expenses included in the Consolidated Statements of Income (Loss) are for the years ended December 31, 2020, 2019 and 2018:

[0001564590-21-009423:notes:375]
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Cost of sales |  | $ | 455 |  |  | $ | 785 |  |  | $ | 2,775 |  |
| Selling, general and administrative expenses |  |  | 1,832 |  |  |  | 2,360 |  |  |  | 2,655 |  |
| Research and development expenses |  |  | 3,942 |  |  |  | 2,869 |  |  |  | 1,831 |  |
| Total restructuring expenses |  | $ | 6,229 |  |  | $ | 6,014 |  |  | $ | 7,261 |  |

[0001564590-21-009423:notes:376]
The following table represents the components of restructuring expense by geographic area for the years ended December 31, 2020, 2019 and 2018:

[0001564590-21-009423:notes:377]
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| United States |  | $ | 2,234 |  |  | $ | 3,336 |  |  | $ | 7,120 |  |
| International |  |  | 3,995 |  |  |  | 2,678 |  |  |  | 141 |  |
| Total restructuring expenses |  | $ | 6,229 |  |  | $ | 6,014 |  |  | $ | 7,261 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001564590-21-009423:notes:378]
Note 21 – Summarized Quarterly Financial Data (Unaudited)

[0001564590-21-009423:notes:379]
The following table presents unaudited quarterly operating results for each of the last eight fiscal quarters. This information has been prepared on a basis consistent with the audited financial statements and includes all adjustments, consisting only of normal recurring adjustments, considered necessary for a fair presentation of the data.

[0001564590-21-009423:notes:380]
Unaudited Quarterly Operating Results

[0001564590-21-009423:notes:381]
|  |  | Three Months Ended |  |  |
| (In thousands, except for per share amounts) |  | March 31, 2020(2) |  |  | June 30, 2020 |  |  | September 30, 2020 |  |  | December 31, 2020 |  |  |
| Total Sales |  | $ | 114,523 |  |  | $ | 128,715 |  |  | $ | 133,143 |  |  | $ | 130,129 |  |  |
| Gross Profit |  | $ | 51,600 |  |  | $ | 53,472 |  |  | $ | 58,962 |  |  | $ | 53,517 |  |  |
| Operating Income (Loss) |  | $ | (4,944 | ) |  | $ | (6,039 | ) |  | $ | 4,534 |  |  | $ | (3,324 | ) |  |
| Net Income (Loss) |  | $ | (9,969 | ) |  | $ | 752 |  |  | $ | 5,481 |  |  | $ | 6,114 |  |  |
| Earnings (loss) per common share - basic |  | $ | (0.21 | ) |  | $ | 0.02 |  |  | $ | 0.11 |  |  | $ | 0.13 |  |  |
| Earnings (loss) per common share - diluted |  | $ | (0.21 | ) |  | $ | 0.02 |  | (1) | $ | 0.11 |  | (1) | $ | 0.13 |  | (1) |

[0001564590-21-009423:notes:382]
|  |  | Three Months Ended |  |  |
| (In thousands, except for per share amounts) |  | March 31, 2019 |  |  | June 30, 2019(2) |  |  | September 30, 2019 |  |  | December 31, 2019 |  |  |
| Total Sales |  | $ | 143,791 |  |  | $ | 156,391 |  |  | $ | 114,092 |  |  | $ | 115,787 |  |  |
| Gross Profit |  | $ | 60,612 |  |  | $ | 65,015 |  |  | $ | 46,331 |  |  | $ | 47,209 |  |  |
| Operating Income (Loss) |  | $ | (6,167 | ) |  | $ | 562 |  |  | $ | (20,288 | ) |  | $ | (14,070 | ) |  |
| Net Income (Loss) |  | $ | 770 |  |  | $ | 3,995 |  |  | $ | (46,123 | ) |  | $ | (11,624 | ) |  |
| Earnings (loss) per common share - basic |  | $ | 0.02 |  |  | $ | 0.08 |  |  | $ | (0.96 | ) |  | $ | (0.25 | ) |  |
| Earnings (loss) per common share - diluted |  | $ | 0.02 |  | (1) | $ | 0.08 |  | (1) | $ | (0.96 | ) |  | $ | (0.25 | ) |  |

[0001564590-21-009423:notes:383]
|  | (1) | Assumes exercise of dilutive securities calculated under the treasury stock method. |

[0001564590-21-009423:notes:384]
|  | (2) | See footnote 1 for discussion on out of period disclosures impacting these quarterly operating results. |


## us-gaap:SubsequentEventsTextBlock

[0001564590-21-009423:notes:385]
Note 22 – Subsequent Events

[0001564590-21-009423:notes:386]
On February 3, 2021, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record at the close of business on February 18, 2021. The payment date will be March 4, 2021 in the aggregate amount of approximately $4.4 million.

[0001564590-21-009423:notes:387]
As part of our required pledged collateral related to a letter for credit agreement entered into with a bank to guarantee performance obligations under a contract with a certain customer, the Company increased its pledged collateral to $15.0 million as of February 2021. We do not anticipate any additional increases in the collateral value at this time as we have reached the maximum amount of the letter of credit required under our contract with the customer. The collateral under the letter of credit will be released when all obligations under the customer contract have been met.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001564590-21-009423:notes:388]
SCHEDULE II

[0001564590-21-009423:notes:389]
VALUATION AND QUALIFYING ACCOUNTS

[0001564590-21-009423:notes:390]
| (In thousands) |  | Balance at Beginning of Period |  |  | Charged to Costs & Expenses |  |  | Deductions |  |  | Balance at End of Period |  |
| Year ended December 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 38 |  |  |  | — |  |  |  | — |  |  | $ | 38 |  |
| Inventory Reserve |  | $ | 34,162 |  |  |  | 11,404 |  |  |  | 6,005 |  |  | $ | 39,561 |  |
| Warranty Liability |  | $ | 8,394 |  |  |  | 1,538 |  |  |  | 2,786 |  |  | $ | 7,146 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 48,616 |  |  |  | 5,120 |  |  |  | 7,918 |  |  | $ | 45,818 |  |
| Year ended December 31, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 128 |  |  |  | 38 |  |  |  | 128 |  |  | $ | 38 |  |
| Inventory Reserve |  | $ | 30,009 |  |  |  | 5,893 |  |  |  | 1,740 |  |  | $ | 34,162 |  |
| Warranty Liability |  | $ | 8,623 |  |  |  | 4,569 |  |  |  | 4,798 |  |  | $ | 8,394 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 5,816 |  |  |  | 43,560 |  |  |  | 760 |  |  | $ | 48,616 |  |
| Year ended December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | — |  |  |  | 128 |  |  |  | — |  |  | $ | 128 |  |
| Inventory Reserve |  | $ | 23,355 |  |  |  | 7,006 |  |  |  | 352 |  |  | $ | 30,009 |  |
| Warranty Liability |  | $ | 9,724 |  |  |  | 7,392 |  |  |  | 8,493 |  |  | $ | 8,623 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 6,006 |  |  |  | — |  |  |  | 190 |  |  | $ | 5,816 |  |
