# ADTN note change history — 0001564590-20-038237 → 0001564590-20-052017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001564590-20-052017:note_history:1]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The lawsuit was transferred to the U.S. District Court for the Northern District of Alabama on January 7, 2020, and co-lead plaintiffs have been appointed to represent the putative class. The plaintiffs filed an amended complaint on April 30, 2020. The defendants filed a motion to dismiss the amended complaint on June 17, 2020. The plaintiffs filed an opposition brief to the defendants’ motion to dismiss on July 17, 2020. The defendants filed a reply to the plaintiffs’ brief on August 17, 2020. The motion to dismiss remains under review by the Court. We deny the allegations in the complaint, as amended, and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.
  (was, 2020-08-07, similarity 0.9767):
[0001564590-20-038237:note_history:1]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The lawsuit was transferred to the U.S. District Court for the Northern District of Alabama on January 7, 2020, and co-lead plaintiffs have been appointed to represent the putative class. The plaintiffs filed an amended complaint on April 30, 2020. The defendants filed a motion to dismiss the amended complaint on June 17, 2020. The plaintiffs filed an opposition brief to the defendants’ motion to dismiss on July 17, 2020. The defendants intend to file a reply to the plaintiffs’ brief on August 17, 2020. We deny the allegations in the complaint, as amended, and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

- changed (2020-11-06):
[0001564590-20-052017:note_history:2]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2020 and December 31, 2019, we had commitments related to these bonds totaling $12.0 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2020-08-07, similarity 0.9888):
[0001564590-20-038237:note_history:2]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2020 and December 31, 2019, we had commitments related to these bonds totaling $11.3 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- added (2020-11-06):
[0001564590-20-052017:note_history:3]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under the customer contract will be performed over multiple years. As of September 30, 2020, the Company was required to maintain a minimum collateral value of $4.5 million. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $5.9 million as of September 30, 2020, of which $0.3 million is included in restricted cash and $5.6 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments, with an expected maximum value between $13.0 million and $15.0 million. On October 8, 2020, the Company entered into an amendment to the letter of credit, which increased the minimum collateral value to $9.0 million. The minimum collateral value is expected to continue to increase as the Company reaches certain milestones through the first quarter of 2021 as outlined in the customer contract. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of September 30, 2020, the Company was in compliance with all contractual requirements under the letter of credit.

- changed (2020-11-06):
[0001564590-20-052017:note_history:4]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been contributed as of September 30, 2020.
  (was, 2020-08-07, similarity 0.9619):
[0001564590-20-038237:note_history:4]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been contributed as of June 30, 2020.

- removed (2020-11-06):
[0001564590-20-038237:note_history:5]
In June of 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a customer. The letter of credit is secured by a pledge of collateral in the amount of $5.0 million, of which $1.2 million is included in restricted cash and $3.8 million is included in long-term investments on the Condensed Consolidated Balance Sheet as of June 30, 2020. Currently, the Company is required to maintain a minimum collateral value of approximately $5.0 million. The minimum collateral value will increase over time as the Company reaches certain milestones in the contract. The maximum collateral value required under the contract will be approximately $12.0 million, and this is expected to occur in February 2021. This minimum collateral value will increase further if the Company changes the mix of investments away from restricted cash and into other investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments or long-term investments. The obligations under the customer contract will be performed over multiple years. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of June 30, 2020, the Company was in compliance with all contractual requirements under the letter of credit.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001564590-20-052017:note_history:6]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The Condensed Consolidated Balance Sheet as of December 31, 2019 is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.
  (was, 2020-08-07, similarity 0.9303):
[0001564590-20-038237:note_history:6]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2019 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

- changed (2020-11-06):
[0001564590-20-052017:note_history:7]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of September 30, 2020 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, current estimated credit losses, stock-based compensation, excess and obsolete inventory reserves, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our condensed consolidated financial statements as of and for the three and nine month periods ended September 30, 2020 resulting from these assessments, future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.
  (was, 2020-08-07, similarity 0.735):
[0001564590-20-038237:note_history:7]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of June 30, 2020 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, current estimated credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the quarter ended June 30, 2020 resulting from these assessments, future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

- changed (2020-11-06):
[0001564590-20-052017:note_history:8]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company corrected this misstatement in the Unaudited Condensed Consolidated Statement of Cash Flows for the nine months ended September 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management determined that these misstatements were not material to any of its previously issued financial statements on both a quantitative and qualitative basis.
  (was, 2020-08-07, similarity 0.9819):
[0001564590-20-038237:note_history:8]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company corrected this misstatement in the Unaudited Condensed Consolidated Statement of Cash Flows for the six months ended June 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management determined that these misstatements were not material to any of its previously issued financial statements on both a quantitative and qualitative basis.

- changed (2020-11-06):
[0001564590-20-052017:note_history:9]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, which clarifies that receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the standard for leases. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification Improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as providing disclosure relief for accrued interest receivables. All of these ASUs were codified as part of Accounting Standards Codifications (“ASC”) Topic 326 and were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard on January 1, 2020, using a modified-retrospective approach and, therefore, elected to carry forward legacy disclosures for comparative periods and did not adjust the comparative period financial information. Additionally, the Company made an accounting policy election, at the class of financing receivable, not to measure the allowance for credit losses for accrued interest receivables, as the Company writes off the uncollectable accrued interest receivable by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable). The adoption of this standard did not have a material effect on our consolidated financial statements. See Note 19 for additional information.
  (was, 2020-08-07, similarity 0.9921):
[0001564590-20-038237:note_history:9]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, which clarifies that receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the standard for leases. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification Improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as providing disclosure relief for accrued interest receivables. All of these ASUs were codified as part of ASC Topic 326 and were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard on January 1, 2020, using a modified-retrospective approach and, therefore, elected to carry forward legacy disclosures for comparative periods and did not adjust the comparative period financial information. Additionally, the Company made an accounting policy election, at the class of financing receivable, not to measure the allowance for credit losses for accrued interest receivables, as the Company writes off the uncollectable accrued interest receivable by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable). The adoption of this standard did not have a material effect on our consolidated financial statements. See Note 19 for additional information.

- changed (2020-11-06):
[0001564590-20-052017:note_history:10]
In August 2018, the FASB issued ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. The Company adopted ASU 2018-15 on January 1, 2020, retrospectively. The adoption of this standard resulted in a reclassification of $5.6 million from property, plant and equipment to other assets for certain previously capitalized costs related to information technology implementation projects that had not yet been placed in service on the Condensed Consolidated Balance Sheets as of September 30, 2020 and December 31, 2019. There was no impact to previously reported net cash provided by (used in) operations on the statement of cash flows and no impact to the statements of income (loss) as no portion of the capitalized asset was depreciated in prior periods.
  (was, 2020-08-07, similarity 0.9948):
[0001564590-20-038237:note_history:10]
In August 2018, the FASB issued ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. The Company adopted ASU 2018-15 on January 1, 2020, retrospectively. The adoption of this standard resulted in a reclassification of $5.6 million from property, plant and equipment to other assets for certain previously capitalized costs related to information technology implementation projects that had not yet been placed in service on the Condensed Consolidated Balance Sheets as of June 30, 2020 and December 31, 2019. There was no impact to previously reported net cash provided by (used in) operations on the statement of cash flows and no impact to the statements of income (loss) as no portion of the capitalized asset was depreciated in prior periods.

- added (2020-11-06):
[0001564590-20-052017:note_history:11]
There was no impact upon adoption of ASU 2018-15 on the Condensed Consolidated Statement of Loss for the three and nine months ended September 30, 2019 and the Condensed Consolidated Statement of Cash Flows for nine months ended September 30, 2019 as outlined in the following tables:

- added (2020-11-06):
[0001564590-20-052017:note_history:12]
|  |  | Three months ended September 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Loss |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (46,123 | ) |  | $ | — |  |  | $ | (46,123 | ) |

- added (2020-11-06):
[0001564590-20-052017:note_history:13]
|  |  | Nine months ended September 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Loss |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (41,358 | ) |  | $ | — |  |  | $ | (41,358 | ) |
| Condensed Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 10,082 |  |  | $ | — |  |  | $ | 10,082 |  |

- added (2020-11-06):
[0001564590-20-052017:note_history:14]
The following table presents the capitalized implementation costs incurred with hosting arrangements, included in other assets on the Condensed Consolidated Balance Sheet, as of September 30, 2020:

- added (2020-11-06):
[0001564590-20-052017:note_history:15]
| (In thousands) |  | September 30, 2020 |  |
| Implementation costs - hosting arrangements |  | $ | 10,455 |  |
| Less: accumulated amortization |  |  | — |  |
| Implementation costs - hosting arrangements, net |  | $ | 10,455 |  |

- changed (2020-11-06):
[0001564590-20-052017:note_history:16]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss), that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.
  (was, 2020-08-07, similarity 0.9971):
[0001564590-20-038237:note_history:16]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which will be applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss), that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.

- removed (2020-11-06):
[0001564590-20-038237:note_history:17]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Statement of Income for the three and six months ended June 30, 2019 and the Condensed Consolidated Statement of Cash Flows for six months ended June 30, 2019:

- removed (2020-11-06):
[0001564590-20-038237:note_history:18]
|  |  | Three months ended June 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Income (Loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,995 |  |  | $ | — |  |  | $ | 3,995 |  |

- removed (2020-11-06):
[0001564590-20-038237:note_history:19]
|  |  | Six months ended June 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Income (Loss) |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 4,765 |  |  | $ | — |  |  | $ | 4,765 |  |
| Condensed Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 11,007 |  |  | $ | — |  |  | $ | 11,007 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001564590-20-052017:note_history:20]
As of September 30, 2020, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:
  (was, 2020-08-07, similarity 0.9644):
[0001564590-20-038237:note_history:20]
As of June 30, 2020, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

- changed (2020-11-06):
[0001564590-20-052017:note_history:21]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 12,861 |  |  | $ | 149 |  |  | $ | — |  |  | $ | 13,010 |  |
| Municipal fixed-rate bonds |  |  | 3,093 |  |  |  | 32 |  |  |  | (1 | ) |  |  | 3,124 |  |
| Asset-backed bonds |  |  | 8,472 |  |  |  | 115 |  |  |  | — |  |  |  | 8,587 |  |
| Mortgage/Agency-backed bonds |  |  | 10,964 |  |  |  | 127 |  |  |  | (11 | ) |  |  | 11,080 |  |
| U.S. government bonds |  |  | 7,096 |  |  |  | 174 |  |  |  | — |  |  |  | 7,270 |  |
| Foreign government bonds |  |  | 1,032 |  |  |  | 3 |  |  |  | — |  |  |  | 1,035 |  |
| Commercial paper |  |  | 324 |  |  |  | 1 |  |  |  | — |  |  |  | 325 |  |
| Variable-rate demand notes |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,284 |  |  | $ | 601 |  |  | $ | (12 | ) |  | $ | 44,873 |  |
  (was, 2020-08-07, similarity 0.9692):
[0001564590-20-038237:note_history:21]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 13,747 |  |  | $ | 168 |  |  | $ | (1 | ) |  | $ | 13,914 |  |
| Municipal fixed-rate bonds |  |  | 2,379 |  |  |  | 21 |  |  |  | — |  |  |  | 2,400 |  |
| Asset-backed bonds |  |  | 7,600 |  |  |  | 86 |  |  |  | (4 | ) |  |  | 7,682 |  |
| Mortgage/Agency-backed bonds |  |  | 7,944 |  |  |  | 152 |  |  |  | (12 | ) |  |  | 8,084 |  |
| U.S. government bonds |  |  | 7,935 |  |  |  | 211 |  |  |  | — |  |  |  | 8,146 |  |
| Foreign government bonds |  |  | 540 |  |  |  | — |  |  |  | — |  |  |  | 540 |  |
| Commercial paper |  |  | 1,120 |  |  |  | 4 |  |  |  | — |  |  |  | 1,124 |  |
| Variable-rate demand notes |  |  | 300 |  |  |  | — |  |  |  | — |  |  |  | 300 |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Available-for-sale debt securities held at fair value |  | $ | 42,007 |  |  | $ | 642 |  |  | $ | (17 | ) |  | $ | 42,632 |  |

- changed (2020-11-06):
[0001564590-20-052017:note_history:22]
As of September 30, 2020, contractual maturities related to debt securities and other investments were as follows:
  (was, 2020-08-07, similarity 0.9479):
[0001564590-20-038237:note_history:22]
As of June 30, 2020, contractual maturities related to debt securities and other investments were as follows:

- changed (2020-11-06):
[0001564590-20-052017:note_history:23]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage/ Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Commercial paper |  |  | Other |  |
| Less than one year |  | $ | 2,900 |  |  | $ | 737 |  |  | $ | 696 |  |  | $ | 208 |  |  | $ | 500 |  |  | $ | 75 |  |  | $ | 325 |  |  | $ | 442 |  |
| One to two years |  |  | 3,752 |  |  |  | 1,183 |  |  |  | 956 |  |  |  | 1,256 |  |  |  | 826 |  |  |  | 463 |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 6,122 |  |  |  | 908 |  |  |  | 615 |  |  |  | 2,775 |  |  |  | 5,492 |  |  |  | 497 |  |  |  | — |  |  |  | — |  |
| Three to five years |  |  | 236 |  |  |  | 296 |  |  |  | 4,817 |  |  |  | 1,079 |  |  |  | 452 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 946 |  |  |  | 1,507 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 557 |  |  |  | 4,255 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 13,010 |  |  | $ | 3,124 |  |  | $ | 8,587 |  |  | $ | 11,080 |  |  | $ | 7,270 |  |  | $ | 1,035 |  |  | $ | 325 |  |  | $ | 442 |  |
  (was, 2020-08-07, similarity 0.8831):
[0001564590-20-038237:note_history:23]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage/ Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Commercial paper |  |  | Variable-rate demand notes |  |  | Other |  |
| Less than one year |  | $ | 5,441 |  |  | $ | 738 |  |  | $ | 465 |  |  | $ | 146 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,124 |  |  | $ | — |  |  | $ | 442 |  |
| One to two years |  |  | 2,926 |  |  |  | 528 |  |  |  | 465 |  |  |  | 603 |  |  |  | 1,638 |  |  |  | 75 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 5,547 |  |  |  | 757 |  |  |  | 1,141 |  |  |  | 1,528 |  |  |  | 6,065 |  |  |  | 465 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Three to five years |  |  | — |  |  |  | 377 |  |  |  | 3,932 |  |  |  | — |  |  |  | 443 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 982 |  |  |  | 1,890 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 697 |  |  |  | 3,917 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 300 |  |  |  | — |  |
| Total |  | $ | 13,914 |  |  | $ | 2,400 |  |  | $ | 7,682 |  |  | $ | 8,084 |  |  | $ | 8,146 |  |  | $ | 540 |  |  | $ | 1,124 |  |  | $ | 300 |  |  | $ | 442 |  |

- changed (2020-11-06):
[0001564590-20-052017:note_history:24]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Gross realized gains on debt securities |  | $ | 70 |  |  | $ | 36 |  |  | $ | 303 |  |  | $ | 85 |  |
| Gross realized losses on debt securities |  |  | (6 | ) |  |  | (7 | ) |  |  | (45 | ) |  |  | (40 | ) |
| Total gain recognized, net |  | $ | 64 |  |  | $ | 29 |  |  | $ | 258 |  |  | $ | 45 |  |
  (was, 2020-08-07, similarity 0.8624):
[0001564590-20-038237:note_history:24]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Gross realized gains on debt securities |  | $ | 190 |  |  | $ | 8 |  |  | $ | 233 |  |  | $ | 49 |  |
| Gross realized losses on debt securities |  |  | (19 | ) |  |  | (14 | ) |  |  | (39 | ) |  |  | (33 | ) |
| Total gain recognized, net |  | $ | 171 |  |  | $ | (6 | ) |  | $ | 194 |  |  | $ | 16 |  |

- changed (2020-11-06):
[0001564590-20-052017:note_history:25]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three and nine months ended September 30, 2020.
  (was, 2020-08-07, similarity 0.9233):
[0001564590-20-038237:note_history:25]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended June 30, 2020.

- changed (2020-11-06):
[0001564590-20-052017:note_history:26]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost, where appropriate.
  (was, 2020-08-07, similarity 0.9902):
[0001564590-20-038237:note_history:26]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost (where appropriate).

- changed (2020-11-06):
[0001564590-20-052017:note_history:27]
During the three months ended March 31, 2019, an outstanding note receivable of $4.3 million was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment, which represented a non-cash investing activity. We elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. During the nine months ended September 30, 2020, an impairment charge of $1.6 million was recorded related to this equity investment, which is included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $1.8 million as of September 30, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of September 30, 2020 and December 31, 2019, and represented a non-cash investing activity during the nine months ended September 30, 2019. No impairment charge was recognized related to the note receivable as it is a secured loan.
  (was, 2020-08-07, similarity 0.7128):
[0001564590-20-038237:note_history:27]
During the three months ended March 31, 2019, an outstanding note receivable of $4.3 million was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment, which represented a non-cash investing activity. We elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. During the six months ended June 30, 2020, an impairment charge of $1.6 million was recorded related to this equity investment, which is included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $1.8 million as of June 30, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of June 30, 2020 and December 31, 2019, and represented a non-cash investing activity during the six months ended June 30, 2019. No impairment charge was recognized related to the note receivable as it is a secured loan.

- changed (2020-11-06):
[0001564590-20-052017:note_history:28]
Realized and unrealized gains and losses related to marketable equity securities for the three and nine months ended September 30, 2020 and 2019 were as follows:
  (was, 2020-08-07, similarity 0.9467):
[0001564590-20-038237:note_history:28]
Realized and unrealized gains and losses related to marketable equity securities for the three and six months ended June 30, 2020 and 2019 were as follows:

- changed (2020-11-06):
[0001564590-20-052017:note_history:29]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Realized gains (losses) on equity securities sold |  | $ | 623 |  |  | $ | (20 | ) |  | $ | (1,485 | ) |  | $ | (83 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 2,157 |  |  |  | (225 | ) |  |  | 3,046 |  |  |  | 8,233 |  |
| Total gain (loss) recognized, net |  | $ | 2,780 |  |  | $ | (245 | ) |  | $ | 1,561 |  |  | $ | 8,150 |  |
  (was, 2020-08-07, similarity 0.8575):
[0001564590-20-038237:note_history:29]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Realized gains (losses) on equity securities sold |  | $ | 328 |  |  | $ | (49 | ) |  | $ | (2,108 | ) |  | $ | (63 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 9,353 |  |  |  | 2,540 |  |  |  | 889 |  |  |  | 8,458 |  |
| Total gain (loss) recognized, net |  | $ | 9,681 |  |  | $ | 2,491 |  |  | $ | (1,219 | ) |  | $ | 8,395 |  |

- changed (2020-11-06):
[0001564590-20-052017:note_history:30]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement; inputs could include information supplied by investees.
  (was, 2020-08-07, similarity 0.9841):
[0001564590-20-038237:note_history:30]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

- changed (2020-11-06):
[0001564590-20-052017:note_history:31]
|  |  |  |  |  |  | Fair Value Measurements as of September 30, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 636 |  |  | $ | 636 |  |  | $ | — |  |  | $ | — |  |
| U.S. government securities |  |  | 300 |  |  |  | 300 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,010 |  |  | — |  |  |  | 13,010 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 3,124 |  |  | — |  |  |  | 3,124 |  |  |  | — |  |
| Asset-backed bonds |  |  | 8,587 |  |  | — |  |  |  | 8,587 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,080 |  |  | — |  |  |  | 11,080 |  |  |  | — |  |
| U.S. government bonds |  |  | 7,270 |  |  |  | 7,270 |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 1,035 |  |  | — |  |  |  | 1,035 |  |  |  | — |  |
| Commercial paper |  |  | 325 |  |  | — |  |  |  | 325 |  |  |  | — |  |
| Variable-rate demand notes |  |  | — |  |  | — |  |  |  |  |  |  |  | — |  |
| Other |  |  | 442 |  |  | — |  |  | — |  |  |  | 442 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 13,590 |  |  |  | 13,590 |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,595 |  |  |  | 21,595 |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,276 |  |  |  | 1,276 |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,270 |  |  | $ | 44,667 |  |  | $ | 37,161 |  |  | $ | 442 |  |
  (was, 2020-08-07, similarity 0.6954):
[0001564590-20-038237:note_history:31]
|  |  |  |  |  |  | Fair Value Measurements as of June 30, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,697 |  |  | $ | 1,697 |  |  | $ | — |  |  | $ | — |  |
| U.S. government securities |  |  | 1,250 |  |  |  | 1,250 |  |  |  | — |  |  |  | — |  |
| Commercial paper |  |  | 100 |  |  |  | — |  |  |  | 100 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,914 |  |  |  | — |  |  |  | 13,914 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,400 |  |  |  | — |  |  |  | 2,400 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,682 |  |  |  | — |  |  |  | 7,682 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,084 |  |  |  | — |  |  |  | 8,084 |  |  |  | — |  |
| U.S. government bonds |  |  | 8,146 |  |  |  | 8,146 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 540 |  |  |  | — |  |  |  | 540 |  |  |  | — |  |
| Commercial paper |  |  | 1,124 |  |  |  | — |  |  |  | 1,124 |  |  |  | — |  |
| Variable-rate demand notes |  |  | 300 |  |  |  | — |  |  |  | 300 |  |  |  | — |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,116 |  |  |  | 26,116 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,468 |  |  |  | 20,468 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,223 |  |  |  | 1,223 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 93,486 |  |  | $ | 58,900 |  |  | $ | 34,144 |  |  | $ | 442 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001564590-20-052017:note_history:32]
The following tables disaggregate revenue by reportable segment and revenue category for the three and nine months ended September 30, 2020 and 2019:
  (was, 2020-08-07, similarity 0.942):
[0001564590-20-038237:note_history:32]
The following tables disaggregate revenue by reportable segment and revenue category for the three and six months ended June 30, 2020 and 2019:

- changed (2020-11-06):
[0001564590-20-052017:note_history:33]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 71,919 |  |  | $ | 13,504 |  |  | $ | 85,423 |  |  | $ | 48,902 |  |  | $ | 16,212 |  |  | $ | 65,114 |  |
| Subscriber Solutions & Experience |  |  | 40,843 |  |  |  | 2,282 |  |  |  | 43,125 |  |  |  | 40,382 |  |  |  | 2,094 |  |  |  | 42,476 |  |
| Traditional & Other Products |  |  | 2,467 |  |  |  | 2,128 |  |  |  | 4,595 |  |  |  | 4,734 |  |  |  | 1,768 |  |  |  | 6,502 |  |
| Total |  | $ | 115,229 |  |  | $ | 17,914 |  |  | $ | 133,143 |  |  | $ | 94,018 |  |  | $ | 20,074 |  |  | $ | 114,092 |  |
  (was, 2020-08-07, similarity 0.9585):
[0001564590-20-038237:note_history:33]
|  |  | Three Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,721 |  |  | $ | 13,055 |  |  | $ | 82,776 |  |  | $ | 96,262 |  |  | $ | 13,159 |  |  | $ | 109,421 |  |
| Subscriber Solutions & Experience |  |  | 38,081 |  |  |  | 2,312 |  |  |  | 40,393 |  |  |  | 38,444 |  |  |  | 2,058 |  |  |  | 40,502 |  |
| Traditional & Other Products |  |  | 3,521 |  |  |  | 2,025 |  |  |  | 5,546 |  |  |  | 4,461 |  |  |  | 2,007 |  |  |  | 6,468 |  |
| Total |  | $ | 111,323 |  |  | $ | 17,392 |  |  | $ | 128,715 |  |  | $ | 139,167 |  |  | $ | 17,224 |  |  | $ | 156,391 |  |

- changed (2020-11-06):
[0001564590-20-052017:note_history:34]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 194,695 |  |  | $ | 39,470 |  |  | $ | 234,165 |  |  | $ | 230,837 |  |  | $ | 43,476 |  |  | $ | 274,313 |  |
| Subscriber Solutions & Experience |  |  | 118,907 |  |  |  | 6,790 |  |  |  | 125,697 |  |  |  | 113,545 |  |  |  | 6,186 |  |  |  | 119,731 |  |
| Traditional & Other Products |  |  | 10,322 |  |  |  | 6,197 |  |  |  | 16,519 |  |  |  | 14,625 |  |  |  | 5,605 |  |  |  | 20,230 |  |
| Total |  | $ | 323,924 |  |  | $ | 52,457 |  |  | $ | 376,381 |  |  | $ | 359,007 |  |  | $ | 55,267 |  |  | $ | 414,274 |  |
  (was, 2020-08-07, similarity 0.9523):
[0001564590-20-038237:note_history:34]
|  |  | Six Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 122,776 |  |  | $ | 25,966 |  |  | $ | 148,742 |  |  | $ | 181,935 |  |  | $ | 27,264 |  |  | $ | 209,199 |  |
| Subscriber Solutions & Experience |  |  | 78,064 |  |  |  | 4,508 |  |  |  | 82,572 |  |  |  | 73,163 |  |  |  | 4,092 |  |  |  | 77,255 |  |
| Traditional & Other Products |  |  | 7,855 |  |  |  | 4,069 |  |  |  | 11,924 |  |  |  | 9,891 |  |  |  | 3,837 |  |  |  | 13,728 |  |
| Total |  | $ | 208,695 |  |  | $ | 34,543 |  |  | $ | 243,238 |  |  | $ | 264,989 |  |  | $ | 35,193 |  |  | $ | 300,182 |  |

- changed (2020-11-06):
[0001564590-20-052017:note_history:35]
The table below presents sales information by category for the three and nine months ended September 30, 2020 and 2019:
  (was, 2020-08-07, similarity 0.9259):
[0001564590-20-038237:note_history:35]
The table below presents sales information by category for the three and six months ended June 30, 2020 and 2019:

- changed (2020-11-06):
[0001564590-20-052017:note_history:36]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Access & Aggregation |  | $ | 85,423 |  |  | $ | 65,114 |  |  | $ | 234,165 |  |  | $ | 274,313 |  |
| Subscriber Solutions & Experience |  |  | 43,125 |  |  |  | 42,476 |  |  |  | 125,697 |  |  |  | 119,731 |  |
| Traditional & Other Products |  |  | 4,595 |  |  |  | 6,502 |  |  |  | 16,519 |  |  |  | 20,230 |  |
| Total |  | $ | 133,143 |  |  | $ | 114,092 |  |  | $ | 376,381 |  |  | $ | 414,274 |  |
  (was, 2020-08-07, similarity 0.9392):
[0001564590-20-038237:note_history:36]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Access & Aggregation |  | $ | 82,776 |  |  | $ | 109,421 |  |  | $ | 148,742 |  |  | $ | 209,199 |  |
| Subscriber Solutions & Experience |  |  | 40,393 |  |  |  | 40,502 |  |  |  | 82,572 |  |  |  | 77,255 |  |
| Traditional & Other Products |  |  | 5,546 |  |  |  | 6,468 |  |  |  | 11,924 |  |  |  | 13,728 |  |
| Total |  | $ | 128,715 |  |  | $ | 156,391 |  |  | $ | 243,238 |  |  | $ | 300,182 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001564590-20-052017:note_history:37]
Network Solutions - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.
  (was, 2020-08-07, similarity 0.9794):
[0001564590-20-038237:note_history:37]
Network Solutions Segment - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

- changed (2020-11-06):
[0001564590-20-052017:note_history:38]
Services & Support - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.
  (was, 2020-08-07, similarity 0.9774):
[0001564590-20-038237:note_history:38]
Services & Support Segment - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

- changed (2020-11-06):
[0001564590-20-052017:note_history:39]
The following tables disaggregate revenue by reportable segment and revenue category for the three and nine months ended September 30, 2020 and 2019:
  (was, 2020-08-07, similarity 0.942):
[0001564590-20-038237:note_history:39]
The following tables disaggregate revenue by reportable segment and revenue category for the three and six months ended June 30, 2020 and 2019:

- changed (2020-11-06):
[0001564590-20-052017:note_history:40]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 71,919 |  |  | $ | 13,504 |  |  | $ | 85,423 |  |  | $ | 48,902 |  |  | $ | 16,212 |  |  | $ | 65,114 |  |
| Subscriber Solutions & Experience |  |  | 40,843 |  |  |  | 2,282 |  |  |  | 43,125 |  |  |  | 40,382 |  |  |  | 2,094 |  |  |  | 42,476 |  |
| Traditional & Other Products |  |  | 2,467 |  |  |  | 2,128 |  |  |  | 4,595 |  |  |  | 4,734 |  |  |  | 1,768 |  |  |  | 6,502 |  |
| Total |  | $ | 115,229 |  |  | $ | 17,914 |  |  | $ | 133,143 |  |  | $ | 94,018 |  |  | $ | 20,074 |  |  | $ | 114,092 |  |
  (was, 2020-08-07, similarity 0.9585):
[0001564590-20-038237:note_history:40]
|  |  | Three Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,721 |  |  | $ | 13,055 |  |  | $ | 82,776 |  |  | $ | 96,262 |  |  | $ | 13,159 |  |  | $ | 109,421 |  |
| Subscriber Solutions & Experience |  |  | 38,081 |  |  |  | 2,312 |  |  |  | 40,393 |  |  |  | 38,444 |  |  |  | 2,058 |  |  |  | 40,502 |  |
| Traditional & Other Products |  |  | 3,521 |  |  |  | 2,025 |  |  |  | 5,546 |  |  |  | 4,461 |  |  |  | 2,007 |  |  |  | 6,468 |  |
| Total |  | $ | 111,323 |  |  | $ | 17,392 |  |  | $ | 128,715 |  |  | $ | 139,167 |  |  | $ | 17,224 |  |  | $ | 156,391 |  |

- changed (2020-11-06):
[0001564590-20-052017:note_history:41]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 194,695 |  |  | $ | 39,470 |  |  | $ | 234,165 |  |  | $ | 230,837 |  |  | $ | 43,476 |  |  | $ | 274,313 |  |
| Subscriber Solutions & Experience |  |  | 118,907 |  |  |  | 6,790 |  |  |  | 125,697 |  |  |  | 113,545 |  |  |  | 6,186 |  |  |  | 119,731 |  |
| Traditional & Other Products |  |  | 10,322 |  |  |  | 6,197 |  |  |  | 16,519 |  |  |  | 14,625 |  |  |  | 5,605 |  |  |  | 20,230 |  |
| Total |  | $ | 323,924 |  |  | $ | 52,457 |  |  | $ | 376,381 |  |  | $ | 359,007 |  |  | $ | 55,267 |  |  | $ | 414,274 |  |
  (was, 2020-08-07, similarity 0.9523):
[0001564590-20-038237:note_history:41]
|  |  | Six Months Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 122,776 |  |  | $ | 25,966 |  |  | $ | 148,742 |  |  | $ | 181,935 |  |  | $ | 27,264 |  |  | $ | 209,199 |  |
| Subscriber Solutions & Experience |  |  | 78,064 |  |  |  | 4,508 |  |  |  | 82,572 |  |  |  | 73,163 |  |  |  | 4,092 |  |  |  | 77,255 |  |
| Traditional & Other Products |  |  | 7,855 |  |  |  | 4,069 |  |  |  | 11,924 |  |  |  | 9,891 |  |  |  | 3,837 |  |  |  | 13,728 |  |
| Total |  | $ | 208,695 |  |  | $ | 34,543 |  |  | $ | 243,238 |  |  | $ | 264,989 |  |  | $ | 35,193 |  |  | $ | 300,182 |  |

- added (2020-11-06):
[0001564590-20-052017:note_history:42]
Revenue allocated to remaining performance obligations represents contract revenue that have not yet been recognized for contracts with a duration of greater than one year. As of September 30, 2020, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $16.5 million and $13.6 million as of September 30, 2020 and December 31, 2019, respectively. The Company expects to recognize 59% of the $16.5 million as of September 30, 2020 over the next 12 months, with the remainder to be recognized thereafter.

- changed (2020-11-06):
[0001564590-20-052017:note_history:43]
| (In thousands) |  | September 30, 2020 |  |  | December 31, 2019 |  |
| Accounts receivable, net |  | $ | 100,223 |  |  | $ | 90,531 |  |
| Contract assets(1) |  | $ | 1,015 |  |  | $ | 2,812 |  |
| Unearned revenue |  | $ | 13,379 |  |  | $ | 11,963 |  |
| Non-current unearned revenue |  | $ | 6,694 |  |  | $ | 6,012 |  |
  (was, 2020-08-07, similarity 0.9201):
[0001564590-20-038237:note_history:43]
| (In thousands) |  | June 30, 2020 |  |  | December 31, 2019 |  |
| Accounts receivable, net |  | $ | 95,335 |  |  | $ | 90,531 |  |
| Contract assets(1) |  | $ | 1,028 |  |  | $ | 2,812 |  |
| Unearned revenue |  | $ | 12,090 |  |  | $ | 11,963 |  |
| Non-current unearned revenue |  | $ | 6,166 |  |  | $ | 6,012 |  |

- changed (2020-11-06):
[0001564590-20-052017:note_history:44]
Of the outstanding unearned revenue balances as of December 31, 2019 and December 31, 2018, $1.5 million and $1.2 million were recognized as revenue during the three months ended September 30, 2020 and 2019 and $9.6 million and $11.7 million were recognized as revenue during the nine months ended September 30, 2020 and 2019, respectively.
  (was, 2020-08-07, similarity 0.8473):
[0001564590-20-038237:note_history:44]
Of the outstanding unearned revenue balances as of December 31, 2019 and December 31, 2018, $2.4 million and $3.6 million were recognized as revenue during the three months ended June 30, 2020 and 2019, respectively, and $8.1 million and $10.5 million were recognized as revenue during the six months ended June 30, 2020 and 2019, respectively.

- removed (2020-11-06):
[0001564590-20-038237:note_history:45]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration of greater than one year. As of June 30, 2020, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $16.0 million and $13.6 million as of June 30, 2020 and December 31, 2019, respectively. The Company expects to recognize 62% of the $16.0 million as of June 30, 2020 over the next 12 months, with the remainder to be recognized thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-11-06):
[0001564590-20-052017:note_history:46]
On November 2, 2020, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 17, 2020. The payment date will be December 1, 2020 in the aggregate amount of approximately $4.3 million.
  (was, 2020-08-07, similarity 0.6832):
[0001564590-20-038237:note_history:46]
On August 5, 2020, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 20, 2020. The payment date will be September 3, 2020 in the aggregate amount of approximately $4.3 million.

- added (2020-11-06):
[0001564590-20-052017:note_history:47]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company has not made any draws under the Revolving Credit Agreement to date.
