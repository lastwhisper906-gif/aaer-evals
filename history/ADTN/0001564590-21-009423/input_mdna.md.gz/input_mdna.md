# ADTN MD&A — 0001564590-21-009423


## mdna

[0001564590-21-009423:mdna:1]
| ITEM 7. | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001564590-21-009423:mdna:2]
The following discussion should be read in conjunction with our audited consolidated financial statements and the related notes included in Part II, Item 8 of this Annual Report on Form 10-K. We have omitted discussion of the earliest of the three years of financial condition and results of operations and this information can be found in Part I, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the fiscal year ended December 31, 2019, filed with the SEC on February 25, 2020, which is available free of charge on the SEC's website at sec.gov and on our website at www.adtran.com.

[0001564590-21-009423:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 2 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part I, Item 1A, Risk Factors, of this Form 10-K.

[0001564590-21-009423:mdna:4]
Overview

[0001564590-21-009423:mdna:5]
ADTRAN is a leading global provider of networking and communications platforms and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, alternative service providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. In order to service our customers and grow revenue, we are continually conducting research and development of new products addressing customer needs and testing those products for the specific requirements of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have research and development facilities in strategic global locations.

[0001564590-21-009423:mdna:6]
An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek to be a high-quality and low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001564590-21-009423:mdna:7]
We ended 2020 with a year-over-year revenue decline of 4.4%, driven by the decrease in shipments to an international Tier-1 operator partially offset by an increase in shipments to regional service providers in the U.S., alternative network operators in Europe and initial sales to a European Tier-1 operator. During 2020, we had three 10% revenue customers. Our year-over-year domestic revenue growth of 17.0% was driven by growth in both Tier-2 and Tier-3 carrier categories due to additional fiber access deployments in both access equipment and CPE. Internationally, our revenue decreased by 32.6% compared to the prior year, primarily driven by a slowdown in shipments to an international Tier-1 operator. In the Asia Pacific region, we experienced growth driven by the acceleration of access network builds. Additionally, fiber access continued to experience revenue growth, and, during 2020, we announced multiple long-term Tier-1 next-generation fiber access deals in Europe and the U.S., positioning us well for the next access network upgrade investment cycle.

[0001564590-21-009423:mdna:8]
In March 2020, the World Health Organization declared the outbreak of COVID-19 a pandemic. During the twelve months ended December 31, 2020, there was a downturn in the global financial markets followed by a gradual rebound and a slowdown in the global economy due to the COVID-19 pandemic. COVID-19 continues to spread throughout the U.S. and the world and has resulted in authorities implementing numerous measures to contain the virus, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns. While we are unable to accurately predict the full impact that COVID-19 will have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time. We have experienced some impact to our supply chain, including a slowdown in supply chain deliveries, extended lead times on some key components and some raw material cost increases. We have also had to increase our volume of inventory to ensure supply continuity during the pandemic. In addition, we have experienced significant increases in freight-related costs. While throughout the pandemic, we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments, as well as COVID-19 related reductions in travel and infrastructure expenses, it is possible that we could experience some slowdown in demand and further supply chain issues as the pandemic continues. Even after the COVID-19 pandemic has subsided, we may continue to experience adverse impacts to our business as a result of any economic recession that has occurred or may occur in the future.

[0001564590-21-009423:mdna:9]
Among our customers, we made progress with our fiber and fiber-extension solutions, including PON and Gfast, while also continuing to engage various Services & Support opportunities that we expect will contribute to sales in 2021 and beyond. In addition, we believe that we are at the beginning of a significant investment cycle for fiber deployment driven by technology advancements and regulatory influences. The transition to next-generation network architectures is beginning, and we are seeing demand for our next-generation SD-Access solutions. In 2021, we anticipate that payments to service providers under government funding programs such as the FCC RDOF will begin.

[0001564590-21-009423:mdna:10]
In addition to classifying our operations into two reportable segments, we report revenue across three categories of products and services – (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products.

[0001564590-21-009423:mdna:11]
Our Access & Aggregation platforms are used by CSPs to connect their network infrastructure to subscribers. This revenue category includes hardware- and software-based products and services that aggregate and/or originate access technologies. ADTRAN solutions within this category include a wide array of modular or fixed platforms designed to deliver the best technology and economy based on subscriber density and environmental conditions.

[0001564590-21-009423:mdna:12]
Our Subscriber Solutions & Experience portfolio is used by service providers to terminate their infrastructure at the customer’s premises while providing an immersive and interactive experience for the subscriber. These solutions include copper and fiber WAN termination, LAN switching, Wi-Fi access, and cloud software services, for both residential and business markets.

[0001564590-21-009423:mdna:13]
Our Traditional & Other Products category generally includes a mix of prior-generation technologies’ products and services, as well as other products and services that do not fit within the other revenue categories.

[0001564590-21-009423:mdna:14]
Our operating results have fluctuated, and may continue to fluctuate, on a quarterly basis due to a number of factors, including customer order activity and backlog. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days. These factors normally result in a varying order backlog and limited order flow visibility. Additionally, backlog levels may vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Because many of our customers require prompt delivery of products, we are required to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001564590-21-009423:mdna:15]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that has resulted from the COVID-19 pandemic, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter. During 2019 and continuing into 2020, the Company initiated restructuring plans to realign its expense structure with the reduction in revenue experienced in recent years and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and implemented certain cost savings initiatives, where possible. We expect to continue to see a reduction in our operating expenses and cost of sales, both in the U.S. and internationally, as a result of our implementation of these restructuring plans.

[0001564590-21-009423:mdna:16]
Our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. See Note 21 of Notes to Consolidated Financial Statements, included in Part II, Item 8 of this report, for additional information on quarterly results for 2020 and 2019. For a discussion of risks associated with our operating results, see Part I, Item 1A, Risk Factors of this Annual Report on Form 10-K.

[0001564590-21-009423:mdna:17]
Results of Operations

[0001564590-21-009423:mdna:18]
The following table presents selected financial information derived from our Consolidated Statements of Income (Loss) expressed as a percentage of revenue for the years indicated. Amounts may not foot due to rounding.

[0001564590-21-009423:mdna:19]
|  |  | Year Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 86.5 | % |  |  | 85.9 | % |  |  | 86.6 | % |
| Services & Support |  |  | 13.5 |  |  |  | 14.1 |  |  |  | 13.4 |  |
| Total Sales |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 48.2 |  |  |  | 49.7 |  |  |  | 52.7 |  |
| Services & Support |  |  | 8.8 |  |  |  | 8.9 |  |  |  | 8.8 |  |
| Total Cost of Sales |  |  | 57.0 |  |  |  | 58.7 |  |  |  | 61.5 |  |
| Gross Profit |  |  | 43.0 |  |  |  | 41.3 |  |  |  | 38.5 |  |
| Selling, general and administrative expenses |  |  | 22.5 |  |  |  | 24.6 |  |  |  | 23.5 |  |
| Research and development expenses |  |  | 22.4 |  |  |  | 23.8 |  |  |  | 23.5 |  |
| Asset impairments |  |  | — |  |  |  | 0.7 |  |  |  | — |  |
| Gain on contingency |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |
| Operating Loss |  |  | (1.9 | ) |  |  | (7.5 | ) |  |  | (8.6 | ) |
| Interest and dividend income |  |  | 0.4 |  |  |  | 0.5 |  |  |  | 0.8 |  |
| Interest expense |  |  | — |  |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Net investment gain (loss) |  |  | 1.0 |  |  |  | 2.2 |  |  |  | (0.8 | ) |
| Other income (expense), net |  |  | (0.6 | ) |  |  | 0.3 |  |  |  | 0.2 |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  | 2.1 |  |
| Loss Before Income Taxes |  |  | (1.2 | ) |  |  | (4.7 | ) |  |  | (6.3 | ) |
| Income tax (expense) benefit |  |  | 1.7 |  |  |  | (5.3 | ) |  |  | 2.7 |  |
| Net Income (Loss) |  |  | 0.5 | % |  |  | (10.0 | )% |  |  | (3.7 | )% |

[0001564590-21-009423:mdna:20]
The following discussion and financial information are presented to aid in an understanding of our current consolidated financial position, changes in financial position, results of operations and cash flows and should be read in conjunction with the audited consolidated financial statements and notes thereto included herein. The emphasis of the discussion is a comparison of the years ended December 31, 2020 and December 31, 2019.  For a discussion of a comparison of the years ended December 31, 2019 and December 31, 2018, please refer to Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the year ended December 31, 2019, filed with the SEC on February 25, 2020.

[0001564590-21-009423:mdna:21]
37

[0001564590-21-009423:mdna:22]
Comparison of Years Ended December 31, 2020 and December 31, 2019

[0001564590-21-009423:mdna:23]
Revenue

[0001564590-21-009423:mdna:24]
Our revenue decreased 4.4% from $530.1 million for the year ended December 31, 2019 to $506.5 million for the year ended December 31, 2020. Our Services & Support revenue decreased $6.3 million compared to 2019 and our Network Solutions revenue decreased $17.2 million versus the prior year. The decrease in our 2020 revenue was primarily attributable to a decrease in Access & Aggregation revenue of $35.7 million and Traditional & Other Products revenue of $6.0 million, partially offset by increases in Subscriber Solutions & Experience revenue of $18.2 million.

[0001564590-21-009423:mdna:25]
Network Solutions revenue decreased by 3.8% from $455.2 million in 2019 to $438.0 million in 2020, due primarily to a decrease in sales of our Access & Aggregation products and Traditional & Other Products, partially offset by increases in Subscriber Solutions & Experience revenue. The decrease in revenue of 9.4% of our Access & Aggregation products for 2020 was primarily attributable to decreased volume in sales of FTTN products. The increase of 11.9% in 2020 for sales of our Subscriber Solutions & Experience products was primarily attributable to an increased volume of network termination and Fiber CPE. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate, and continue to fluctuate, for years because of the time required for our customers to transition to newer technologies.

[0001564590-21-009423:mdna:26]
Services & Support revenue decreased by 8.5% from $74.8 million in 2019 to $68.5 million in 2020. The decrease in revenue for 2020 was primarily attributable to decreased sales volume of FTTN products for Access & Aggregation.

[0001564590-21-009423:mdna:27]
Domestic revenue increased 17.0% from $300.9 million in 2019 to $352.1 million in 2020. Our domestic growth was driven by an increase in revenue to the RSP market segment and additional fiber deployments across all customers. In addition, such growth was driven by an increase in sales to Tier-2 and Tier-3 customers with diversified business among our fiber access and CPE, service provider CPE and services.

[0001564590-21-009423:mdna:28]
International revenue, which is included in the amounts for the Network Solutions and Services & Support segments amounts discussed above, decreased 32.6% from $229.2 million for the year ended December 31, 2019 to $154.4 for the year ended December 31, 2020. International revenue, as a percentage of total revenue, decreased from 43.2% for the year ended December 31, 2019 to 30.5% for the year ended December 31, 2020. The decrease in international revenue for 2020 was primarily attributable to the slowdown in shipments to an international Tier-1 customer.

[0001564590-21-009423:mdna:29]
Our international revenue is largely focused on broadband infrastructure and is affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. The competitive landscape in certain international markets is also affected by the increased presence of Asian manufacturers that seek to compete aggressively on price. Our revenue and operating income in some international markets can be negatively impacted by a strengthening U.S. dollar. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in negative pressure on revenue and operating income.

[0001564590-21-009423:mdna:30]
Cost of Sales

[0001564590-21-009423:mdna:31]
As a percentage of revenue, cost of sales decreased from 58.7% for the year ended December 31, 2019 to 57.0% for the year ended December 31, 2020. The decrease was primarily attributable to regional revenue shifts, changes in customer and product mix and a decrease in fixed personnel costs as a result of our restructuring program initiated in 2019.

[0001564590-21-009423:mdna:32]
Network Solutions cost of sales, as a percentage of that segment’s revenue, decreased from 57.9% of revenue in 2019 to 55.8% of revenue in 2020. The decrease in Network Solutions cost of sales as a percentage of that segment’s revenue was primarily attributable to changes in customer and product mix, a regional revenue shift and a decrease in fixed personnel costs as a result of our restructuring program initiated in 2019.

[0001564590-21-009423:mdna:33]
An important part of our strategy is to reduce the cost of each succeeding generation of product and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-21-009423:mdna:34]
Services & Support cost of sales, as a percentage of that segment’s revenue, increased from 63.1% of revenue in 2019 to 65.3% of revenue in 2020. The increase in Services & Support cost of sales as a percentage of that segment’s revenue in 2020 was primarily attributable to changes in services and support mix and volume.

[0001564590-21-009423:mdna:35]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services.

[0001564590-21-009423:mdna:36]
As our network planning and implementation revenue grew to become the largest component of our Services & Support segment business, our Services & Support segment gross margins decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support segment revenue comprising a larger percentage of our overall revenue, and because our Services & Support segment gross margins are generally below those of the Network Solutions segment, our overall corporate gross margins may decline as that business continues to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-21-009423:mdna:37]
Selling, General and Administrative Expenses

[0001564590-21-009423:mdna:38]
Selling, general and administrative expenses as a percentage of revenue decreased from 24.6% for the year ended December 31, 2019 to 22.5% for the year ended December 31, 2020. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared as these costs are relatively fixed in the short term.

[0001564590-21-009423:mdna:39]
Selling, general and administrative expenses decreased by 12.5% from $130.3 million for the year ended December 31, 2019 to $114.0 million for the year ended December 31, 2020. Selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as accounting, tax and other professional fees, contract services and legal and litigation related costs. The decrease in selling, general and administrative expenses was primarily attributable to lower travel related expenses, personnel costs due to our restructuring program initiated in 2019 and the capitalization of certain costs related to our ongoing enterprise resource planning implementation project as well as marketing related costs, such as trade show expenses, offset by increased contract and professional services mainly related to our enterprise resource planning implementation project.

[0001564590-21-009423:mdna:40]
Research and Development Expenses

[0001564590-21-009423:mdna:41]
Research and development expenses as a percentage of revenue decreased from 23.8% for the year ended December 31, 2019 to 22.4% for the year ended December 31, 2020. Research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared as these costs are relatively fixed in the short term.

[0001564590-21-009423:mdna:42]
Research and development expenses decreased by 10.2% from $126.2 million for the year ended December 31, 2019 to $113.3 million for the year ended December 31, 2020. The decrease in research and development expenses was primarily attributable to lower personnel costs and other expenses, such as operating expenses, which were mainly the result of our restructuring program initiated in 2019 as well as lower travel related costs, partially offset by increased contract services and restructuring related costs.

[0001564590-21-009423:mdna:43]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product and market opportunities and engage in significant research and development efforts which provide for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0001564590-21-009423:mdna:44]
Asset Impairments

[0001564590-21-009423:mdna:45]
Asset impairments, which were $3.9 million and less than $0.1 million for the years ended December 31, 2019 and 2020, respectively, relate to the abandonment of certain information technology implementation projects in which we had previously capitalized costs. See Note 1 and Note 8 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-21-009423:mdna:46]
Gain on Contingency

[0001564590-21-009423:mdna:47]
Gain on contingency, which was $1.2 million for the year ended December 31, 2019, relates to the reversal of unearned contingent liabilities which were initially recognized upon the acquisition of SmartRG in the fourth quarter of 2018. There was no gain on contingency recognized during the year ended December 31, 2020. See Note 3 of the Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-21-009423:mdna:48]
Interest and Dividend Income

[0001564590-21-009423:mdna:49]
Interest and dividend income decreased by 30.0% from $2.8 million for the year ended December 31, 2019 to $1.9 million for the year ended December 31, 2020. The decrease in interest and dividend income was primarily attributable to a decrease in interest income as a result of a decline in our investment balances. Our investment balances decreased due to the maturity of our certificate of deposit which served as collateral for our taxable revenue bonds and the sale of certain equity investments for working capital and other purposes. Our investments decreased from $127.7 million as of December 31, 2019 to $83.3 million as of December 31, 2020.

[0001564590-21-009423:mdna:50]
Interest Expense

[0001564590-21-009423:mdna:51]
Interest expense, which is related to our taxable revenue bonds, decreased by $0.5 million for the year ended December 31, 2020 compared to the year ended December 31, 2019. The decrease was due to the outstanding principal balance of the taxable revenue bonds being paid off upon maturity in January 2020. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001564590-21-009423:mdna:52]
Net Investment Gain

[0001564590-21-009423:mdna:53]
We recognized a net investment gain of $11.4 million and $4.9 million for the years ended December 31, 2019 and 2020, respectively. The decrease in our net investment gain was primarily attributable to changes in fair value of equity securities recognized during the period and impairment charges related to an equity investment. During the year ended December 31, 2020, our investments were impacted by varying market conditions, including the COVID-19 pandemic, which resulted in a sharp downturn in the markets during the first quarter of 2020 followed by market improvements and more positive results from a favorable portfolio mix during the remainder of 2020. We expect that any future equity market volatility, whether from COVID-19 or other factors, will result in continued volatility in our investment portfolios. See “Investing Activities” in “Liquidity and Capital Resources” and Note 1 and Note 6 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-21-009423:mdna:54]
Other Income (Expense), net

[0001564590-21-009423:mdna:55]
Other income (expense), net, decreased from income of $1.5 million for the year ended December 31, 2019 to expense of $3.3 million for the year ended December 31, 2020. For the year ended December 31, 2020, other income (expense), net, is comprised primarily of gains and losses on foreign currency transactions. For the year ended December 31, 2019, other income (expense), net, consisted mainly of the receipt of a one-time insurance proceeds from a life insurance policy.

[0001564590-21-009423:mdna:56]
Income Tax (Expense) Benefit

[0001564590-21-009423:mdna:57]
Our effective tax rate decreased from an expense of 113.8%, for the year ended December 31, 2019 to a benefit of 138.1% for the year ended December 31, 2020. The change in the effective tax rate between the two periods was primarily driven by the establishment of a valuation allowance against our domestic deferred tax assets in the amount of $42.8 million during the year ended December 31, 2019, and tax benefits generated from loss carrybacks as a result of the passage of the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) partially offset by tax expense in foreign jurisdictions during the year ended December 31, 2020. See Note 14 of the Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-21-009423:mdna:58]
Net Income (Loss)

[0001564590-21-009423:mdna:59]
As a result of the above factors, our net income increased from a net loss of $53.0 million for the year ended December 31, 2019 to net income of $2.4 million for the year ended December 31, 2020. As a percentage of revenue, net loss was 10.0% for the year ended December 31, 2019. As a percentage of revenue, net income was 0.5% for the year ended December 31, 2020.

[0001564590-21-009423:mdna:60]
Liquidity and Capital Resources

[0001564590-21-009423:mdna:61]
Liquidity

[0001564590-21-009423:mdna:62]
We have historically financed, and currently expect to continue to finance, our ongoing business with existing cash, investments and cash flow from operations. We have used, and expect to continue to use, existing cash, investments and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures. We believe that our cash and cash equivalents, investments and cash generated from operations will be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-21-009423:mdna:63]
As of December 31, 2020, cash on hand was $60.2 million and short-term investments were $3.1 million, which resulted in available short-term liquidity of $63.3 million, of which $49.7 million was held by our foreign subsidiaries. As of December 31, 2019, cash on hand was $73.8 million and short-term investments were $33.2 million, which resulted in available short-term liquidity of $107.0 million, of which $52.3 million was held by our foreign subsidiaries. The decrease in short-term liquidity from December 31, 2019 to December 31, 2020 was primarily attributable to the maturity of a certificate of deposit of $25.6 million that served as collateral for our revenue bond, which matured in January 2020, and the sale of certain equity investments for working capital and other purposes.

[0001564590-21-009423:mdna:64]
On November 4, 2020, the Company entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company entered into the Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. To date, the Company has not made any draws under the Revolving Credit Agreement. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company, which negative covenants are subject to certain exceptions. The Company must be in compliance with all covenants to be able to draw on the line of credit. As of December 31, 2020, the Company was in compliance with all covenants.

[0001564590-21-009423:mdna:65]
Operating Activities

[0001564590-21-009423:mdna:66]
Our working capital, which consists of current assets less current liabilities, increased 7.5% from $207.6 million as of December 31, 2019 to $223.2 million as of December 31, 2020. The current ratio, defined as current assets divided by current liabilities, increased from 2.84 as of December 31, 2019 to 3.37 as of December 31, 2020. The increase in our working capital and current ratio was primarily attributable to an increase in inventory, accounts receivable and other receivables, partially offset by a decrease in cash and short-term investments, which consisted of a certificate of deposit related to our taxable revenue bond as of December 31, 2019 and the related bonds payable. The quick ratio, defined as cash and cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 1.75 as of December 31, 2019 to 1.72 as of December 31, 2020. The decrease in the quick ratio was primarily attributable to the decrease in cash and cash equivalents as well as a decrease in short-term investments, offset by a decrease in current liabilities due to the repayment of our revenue bond payable.

[0001564590-21-009423:mdna:67]
Net accounts receivable increased 9.2% from $90.5 million as of December 31, 2019 to $98.8 million as of December 31, 2020. Our allowance for doubtful accounts was less than $0.1 million as of December 31, 2020 and 2019. Quarterly accounts receivable DSO decreased from 72 days as of December 31, 2019 to 70 days as of December 31, 2020. The decrease in DSO was due to the timing of product shipments and customer mix.

[0001564590-21-009423:mdna:68]
Other receivables increased 30.0% from $16.6 million as of December 31, 2019 to $21.5 million as of December 31, 2020. The increase in other receivables was primarily attributable to increases in income tax receivables related to the CARES Act partially offset by a decrease in contract assets and purchasing shipments.

[0001564590-21-009423:mdna:69]
Annual inventory turnover decreased from 3.14 turns as of December 31, 2019 to 2.58 turns as of December 31, 2020. Inventory increased 27.6% from $98.3 million as of December 31, 2019 to $125.5 million as of December 31, 2020. The increase in inventory was due to increased purchases in preparation for new product ramp ups as well as strategic inventory buffer purchases to ensure supply continuity during the COVID-19 pandemic. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to COVID-19 uncertainties related to supply chain and supply, seasonal cycles of our business and ensuring competitive lead times while managing the risk of inventory.

[0001564590-21-009423:mdna:70]
Accounts payable increased 11.3% from $44.9 million as of December 31, 2019 to $49.9 million as of December 31, 2020. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-21-009423:mdna:71]
Investing Activities

[0001564590-21-009423:mdna:72]
Capital expenditures totaled approximately $6.4 million, $9.5 million and $8.1 million for the years ended December 31, 2020, 2019 and 2018, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements.

[0001564590-21-009423:mdna:73]
Our combined short-term and long-term investments decreased $44.5 million from $127.7 million as of December 31, 2019 to $83.3 million as of December 31, 2020. This decrease reflects the maturity of a certificate of deposit which served as collateral for our revenue bond and the sale of certain equity investments for working capital and other purposes.

[0001564590-21-009423:mdna:74]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 6 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information. As of December 31, 2020, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds were classified as available-for-sale and had a combined duration of 1.74 years with an average Standard & Poor’s credit rating of AA-. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-21-009423:mdna:75]
Our long-term investments decreased 15.2% from $94.5 million as of December 31, 2019 to $80.1 million as of December 31, 2020. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $11.0 million and $35.8 million, as of December 31, 2020 and December 31, 2019, respectively. Long-term investments as of December 31, 2020 and 2019 also included $23.9 million and $21.7 million, respectively, related to our deferred compensation plan, and $0.2 million and $0.3 million, respectively, of other investments, consisting of interests in a private equity fund.

[0001564590-21-009423:mdna:76]
Financing Activities

[0001564590-21-009423:mdna:77]
In conjunction with the 1995 expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (“the Authority”). Pursuant to the program, in January 1995, the Authority issued $20.0 million of its taxable revenue bonds (the “Taxable Revenue Bonds”) and loaned the proceeds from the sale of the Taxable Revenue Bonds to ADTRAN. Further advances on the Taxable Revenue Bonds were made by the Authority, bringing the total amount outstanding to $50.0 million. The bonds matured on January 1, 2020, and the current outstanding balance of $24.6 million was repaid in full on January 2, 2020. We were required to make payments to the Authority in amounts necessary to pay the interest on the Taxable Revenue Bonds which totaled $1.0 million and $1.1 million for the years ended December 31, 2019 and 2018, respectively. The Company had no outstanding debt as of December 31, 2020. See Note 13 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-21-009423:mdna:78]
Dividends

[0001564590-21-009423:mdna:79]
During 2020, 2019 and 2018, we paid shareholder dividends totaling $17.3 million, $17.2 million and $17.3 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained. The following table shows dividends per common share paid to our shareholders in each quarter of 2020, 2019 and 2018:

[0001564590-21-009423:mdna:80]
| Dividends per Common Share |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001564590-21-009423:mdna:81]
Stock Repurchase Program

[0001564590-21-009423:mdna:82]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. There were no stock repurchases during the year ended December 31, 2020. For the years ended December 31, 2019 and 2018, we repurchased less than 0.1 million shares and 1.0 million shares, respectively, for $0.2 million and $15.5 million, respectively, at an average price of $14.06 and $15.52 per share, respectively. We currently have authorization to repurchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-21-009423:mdna:83]
Stock Option Exercises

[0001564590-21-009423:mdna:84]
To accommodate employee stock option exercises, we issued less than 0.1 million shares of treasury stock for $0.5 million during the year ended December 31, 2019 and 0.1 million shares of treasury stock for $1.5 million during the year ended December 31, 2018. There were no stock option exercises during the year ended December 31, 2020.

[0001564590-21-009423:mdna:85]
Employee Pension Plan

[0001564590-21-009423:mdna:86]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations.

[0001564590-21-009423:mdna:87]
Our defined benefit plan assets consist of a balanced portfolio of equity funds, bond funds, real estate funds and managed futures. Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. Central to the policy are target allocation ranges by asset class, which is currently 50% for bond funds, 40% for equity funds and 10% cash, real estate and managed futures. The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies. The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations. At December 31, 2020, the estimated fair market value of our defined benefit pension plans assets increased to $32.3 million from $28.0 million at December 31, 2019.

[0001564590-21-009423:mdna:88]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations. The projected benefit obligation for our defined benefit pension plans was $50.9 million and $43.9 million as of December 31, 2020 and 2019, respectively.

[0001564590-21-009423:mdna:89]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Consolidated Statements of Income (Loss). The components of net periodic pension cost and amounts recognized in other comprehensive income (loss) for the years ended December 31, 2020, 2019 and 2018 were $1.6 million, $3.2 million and $6.1 million, respectively.

[0001564590-21-009423:mdna:90]
Actuarial gains and losses are recorded in accumulated other comprehensive income (loss). To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants. We estimate that $0.9 million will be amortized from accumulated other comprehensive income (loss) into net periodic pension cost in 2021 for the net actuarial loss. The net actuarial loss recognized in accumulated other comprehensive income (loss) as of December 31, 2020 and 2019 was $13.5 million and $13.0 million, respectively.

[0001564590-21-009423:mdna:91]
See Note 15 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-21-009423:mdna:92]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001564590-21-009423:mdna:93]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect our financial condition, revenue or expenses, results of operations, liquidity, capital expenditures, or the availability of, or requirements for, capital resources.

[0001564590-21-009423:mdna:94]
Contractual Obligations

[0001564590-21-009423:mdna:95]
We have various contractual obligations and commercial commitments. The following table sets forth the annual payments we are required to make under contractual cash obligations and other commercial commitments as of December 31, 2020:

[0001564590-21-009423:mdna:96]
| (In thousands) |  | Total |  |  | 2021 |  |  | 2022 |  |  | 2023 |  |  | 2024 |  |  | 2025 |  |  | After 2025 |  |
| Pledged collateral(1) |  | $ | 6,000 |  |  | $ | 6,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Purchase obligations(2) |  |  | 143,944 |  |  |  | 136,924 |  |  |  | 2,839 |  |  |  | 2,123 |  |  |  | 2,056 |  |  |  | 2 |  |  |  | — |  |
| Operating lease obligations(3) |  |  | 5,554 |  |  |  | 1,895 |  |  |  | 1,600 |  |  |  | 1,251 |  |  |  | 521 |  |  |  | 287 |  |  |  | — |  |
| Totals |  | $ | 155,498 |  |  | $ | 144,819 |  |  | $ | 4,439 |  |  | $ | 3,374 |  |  | $ | 2,577 |  |  | $ | 289 |  |  | $ | — |  |

[0001564590-21-009423:mdna:97]
(1) We are required to maintain a pledged collateral amount related to a letter of credit agreement entered into with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. As of December 31, 2020, the Company was required to maintain a minimum collateral value of $9.0 million. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $11.2 million as of December 31, 2020. The Company increased its pledged collateral to the maximum value of our minimum collateral requirement of $15.0 million in February 2021 as the Company reached certain milestones as outlined in the customer contract. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met.

[0001564590-21-009423:mdna:98]
(2) Primarily relates to open purchase orders to our contract manufacturers, component suppliers, service partners and other vendors, including those assisting with the implementation of our new ERP system.

[0001564590-21-009423:mdna:99]
(3) Primarily relates to future minimum rental payments under non-cancelable operating leases, including renewals determined to be reasonably assured, with original maturities of greater than 12 months.

[0001564590-21-009423:mdna:100]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been applied to these commitments. The additional $0.1 million commitment has been excluded from the table above due to the uncertainty of when it will be applied.

[0001564590-21-009423:mdna:101]
Certain contracts, customers and/or jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2020, we had commitments related to these bonds totaling $15.2 million, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default in our performance under each contract, the probability of which we believe is remote.

[0001564590-21-009423:mdna:102]
We also have obligations related to uncertain income tax positions that have been excluded from the table above due to the uncertainty of when the related expense will be recognized. See Note 14 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-21-009423:mdna:103]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). See Liquidity and Capital Resources – Liquidity for further information.

[0001564590-21-009423:mdna:104]
Critical Accounting Policies and Estimates

[0001564590-21-009423:mdna:105]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part II, Item 8 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our Consolidated Financial Statements:

[0001564590-21-009423:mdna:106]
Revenue

[0001564590-21-009423:mdna:107]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. Review of contracts with customers, for both direct customers and distributors, are performed and assessed for principal versus agent considerations to determine primary responsibility for delivery of performance obligation, presumed inventory risk, and discretion in establishing pricing, when applicable. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract, if material, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to account for shipping fees as a cost of fulfilling the related contract. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0001564590-21-009423:mdna:108]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0001564590-21-009423:mdna:109]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales.

[0001564590-21-009423:mdna:110]
Hardware and Software Revenue

[0001564590-21-009423:mdna:111]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenues from software license sales are recognized at delivery and transfer of control to the customer. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects.

[0001564590-21-009423:mdna:112]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services.

[0001564590-21-009423:mdna:113]
Services & Support Segment – A complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services to complement our Network Solutions segment.

[0001564590-21-009423:mdna:114]
Maintenance Revenue

[0001564590-21-009423:mdna:115]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenues, when applicable, are recorded in unearned revenue and non-current unearned revenue.

[0001564590-21-009423:mdna:116]
Network Implementation Revenue

[0001564590-21-009423:mdna:117]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0001564590-21-009423:mdna:118]
Inventory

[0001564590-21-009423:mdna:119]
We carry our inventory at the lower of cost and net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor, and manufacturing overhead are used to value inventory and are updated at least quarterly. Most variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and marketing conditions. If actual trends and market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $39.6 million and $34.1 million at December 31, 2020 and 2019, respectively. Inventory disposals charged against the reserve were $6.0 million and $1.8 million for the years ended December 31, 2020 and 2019, respectively.

[0001564590-21-009423:mdna:120]
Stock-Based Compensation

[0001564590-21-009423:mdna:121]
For purposes of determining the estimated fair value of market-based performance stock unit (PSU) awards on the date of grant, the Monte Carlo Simulation valuation method is used. These PSUs are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of performance-based PSUs, restricted stock units (RSUs) and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. Compensation expense related to unvested performance-based PSUs is recognized over the requisite service period of three years as the achievement of the performance obligation becomes probable. For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable, single measure of the fair value of our stock option awards. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period.

[0001564590-21-009423:mdna:122]
Goodwill

[0001564590-21-009423:mdna:123]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to by-pass a qualitative assessment to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount and, in turn, performed a step-1 analysis of goodwill. No impairment charges on goodwill were recognized during the years ended December 31, 2020, 2019 and 2018.

[0001564590-21-009423:mdna:124]
Income Taxes

[0001564590-21-009423:mdna:125]
We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. We continually review the adequacy of our valuation allowance and recognize the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes. Due to a decrease in revenue and profitability for 2019, and all other positive and negative objective evidence considered as part of our analysis, our ability to consider other subjective evidence such as projections for future growth is limited when evaluating whether our deferred tax assets will be realized. As such, the Company is no longer able to conclude that it is more likely than not that our domestic deferred tax assets will be realized and a valuation allowance against our domestic deferred tax assets was established in the third quarter of 2019. The amount of the deferred tax assets considered realizable, however, could be adjusted in future periods in the event sufficient evidence is present to support a conclusion that it is more likely than not that all or a portion of our domestic deferred tax assets will be realized.

[0001564590-21-009423:mdna:126]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain.  We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001564590-21-009423:mdna:127]
Liability for Warranty

[0001564590-21-009423:mdna:128]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and an estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $7.1 million and $8.4 million at December 31, 2020 and 2019, respectively. These liabilities are included in accrued expenses and other liabilities in the accompanying Consolidated Balance Sheets.

[0001564590-21-009423:mdna:129]
Pension Benefit Plan Obligations

[0001564590-21-009423:mdna:130]
Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $18.7 million and $15.9 million at December 31, 2020 and 2019, respectively. This liability is included in pension liability in the accompanying Consolidated Balance Sheets.

[0001564590-21-009423:mdna:131]
Recently Issued Accounting Pronouncements

[0001564590-21-009423:mdna:132]
For a discussion of recently issued accounting pronouncements, see Note 1 of Notes to Consolidated Financial Statements included in Part II, Item 8 of this report for additional information.

[0001564590-21-009423:mdna:133]
Subsequent Events

[0001564590-21-009423:mdna:134]
On February 3, 2021, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record at the close of business on February 18, 2021. The dividends will be paid on March 4, 2021 in the aggregate amount of approximately $4.4 million.

[0001564590-21-009423:mdna:135]
As part of our required pledged collateral related to a letter for credit agreement entered into with a bank to guarantee performance obligations under a contract with a certain customer, the Company increased its pledged collateral to $15.0 million as of February 2021. We do not anticipate any additional increases in the collateral value at this time as we have reached the maximum amount of the letter of credit required under our contract with the customer. The collateral under the letter of credit will be released when all obligations under the customer contract have been met.

[0001564590-21-009423:mdna:136]
48
