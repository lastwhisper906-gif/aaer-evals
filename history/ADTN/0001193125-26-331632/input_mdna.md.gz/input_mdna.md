# ADTN MD&A — 0001193125-26-331632


## mdna

[0001193125-26-331632:mdna:1]
ITEM 2. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF                    OPERATIONS

[0001193125-26-331632:mdna:2]
[same as prior period, unchanged from 0001193125-26-205276:mdna:2]

[0001193125-26-331632:mdna:3]
[same as prior period, unchanged from 0001193125-26-205276:mdna:3]

[0001193125-26-331632:mdna:4]
[same as prior period, unchanged from 0001193125-26-205276:mdna:4]

[0001193125-26-331632:mdna:5]
[same as prior period, unchanged from 0001193125-26-205276:mdna:5]

[0001193125-26-331632:mdna:6]
[same as prior period, unchanged from 0001193125-26-205276:mdna:6]

[0001193125-26-331632:mdna:7]
[same as prior period, unchanged from 0001193125-26-205276:mdna:7]

[0001193125-26-331632:mdna:8]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks. Adtran is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end customer, especially upon the convergence of solutions at the network edge.

[0001193125-26-331632:mdna:9]
[same as prior period, unchanged from 0001193125-26-205276:mdna:9]

[0001193125-26-331632:mdna:10]
[same as prior period, unchanged from 0001193125-26-205276:mdna:10]

[0001193125-26-331632:mdna:11]
[same as prior period, unchanged from 0001193125-26-205276:mdna:11]

[0001193125-26-331632:mdna:12]
[same as prior period, unchanged from 0001193125-26-205276:mdna:12]

[0001193125-26-331632:mdna:13]
[same as prior period, unchanged from 0001193125-26-205276:mdna:13]

[0001193125-26-331632:mdna:14]
[same as prior period, unchanged from 0001193125-26-205276:mdna:14]

[0001193125-26-331632:mdna:15]
[same as prior period, unchanged from 0001193125-26-205276:mdna:15]

[0001193125-26-331632:mdna:16]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest ("Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.52 per share for each full fiscal year of Adtran Networks (“Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component that was 1.27% as of June 30, 2026. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2025 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 15, 2026 and, therefore, the Annual Recurring Compensation was paid after the general shareholders’ meeting in the amount of $8.9 million. The adequacy of both forms of compensation has been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (including interest thereon) than agreed upon in the DPLTA.

[0001193125-26-331632:mdna:17]
The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the trial on the merits of the DPLTA has recommenced. Following the effective date of the DPLTA on January 16, 2023, certain Adtran Networks shareholders filed lawsuits against the Company in the Regional Court Meiningen, Germany challenging the Exit Compensation offered under the DPLTA. The Regional Court Meiningen has not yet ruled on the shareholders' claims. After the Regional Court Meiningen issues an opinion, an appeal is likely to follow, and thus the Company does not anticipate a final decision on the shareholders' claims until late 2027 or 2028.

[0001193125-26-331632:mdna:18]
For the three and six months ended June 30, 2026, approximately 0.4 million shares and 0.6 million shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €11.7 million, or $13.8 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the three and six months ended June 30, 2025, approximately 0.9 million shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million, or $19.4 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders.

[0001193125-26-331632:mdna:19]
In summary, the Company believes that its cash and cash equivalents, working capital management and availability to access cash under its credit facility or other future sources of capital will be adequate to meet its business operating requirements, its capital expenditures and its expected obligations under both the Notes and the DPLTA, including the anticipated levels of Exit Compensation, as well as to support the Company's ability to continue to comply with its debt covenants under its credit facility for at least the next twelve months, from the issuance of the consolidated financial statements included in Part I, Item 1 of this 10-Q. See Note 10, Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo credit agreement.

[0001193125-26-331632:mdna:20]
As of June 30, 2026 we hold 37,447,983 no-par value bearer shares of Adtran Networks, representing 71.9% of Adtran Networks outstanding shares as of June 30, 2026.

[0001193125-26-331632:mdna:21]
[same as prior period, unchanged from 0001193125-26-205276:mdna:21]

[0001193125-26-331632:mdna:22]
[same as prior period, unchanged from 0001193125-26-205276:mdna:22]

[0001193125-26-331632:mdna:23]
We ended the second quarter of 2026 with a year-over-year revenue increase of 6.1% as compared to the three months ended June 30, 2025, driven by increased volume of sales activity and continued strength of our core markets, due to broadband expansion brought about by higher service provider spending and a continued vendor consolidation due to a shift away from high-risk vendors. During the second quarter of 2026, we had no customers with revenues greater than 10.0% and our five largest customers comprised 28.8% of our revenue. Our year-over-year U.S. revenue increased by 11.7% due to continued customer spending and broadband expansion. Internationally, our year-over-year revenue increased by 1.4%, primarily due to broad-based strength across Europe, partially offset by a decrease in revenues due to a project delay from a single customer.

[0001193125-26-331632:mdna:24]
[same as prior period, unchanged from 0001193125-26-205276:mdna:24]

[0001193125-26-331632:mdna:25]
[same as prior period, unchanged from 0001193125-26-205276:mdna:25]

[0001193125-26-331632:mdna:26]
During 2025, the U.S. introduced various trade policy orders that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. On February 20, 2026, the U.S. Supreme Court issued a ruling striking down certain tariffs previously imposed under the International Emergency Economic Powers Act ("IEEPA"). The ultimate availability, timing, and amount of any potential refunds of such tariffs remain highly uncertain and are subject to further legal, regulatory, and administrative developments. See ‘Tariff Refund” below for further discussion of this topic. Following the Supreme Court’s decision, the U.S. presidential administration invoked Section 122 of the Trade Act of 1974 to impose new tariffs of 10% on imports from all countries, in addition to any existing non-IEEPA tariffs (including tariffs on semiconductors, which are expected to increase in June 2027), and also amended tariffs on imports of copper, steel and aluminum previously imposed under Section 232 of the Trade Expansion Act of 1962, effective April 6, 2026, to apply differentiated tariff rates based on metal content and the use of U.S.-origin metal inputs. By its terms, the Section 122 tariff expired on July 24, 2026. On July 23, 2026, the Office of the U.S. Trade Representative ("USTR") announced a final action under Section 301 of the Trade Act of 1974 imposing additional ad valorem tariffs of 10% or 12.5% on most goods imported from approximately 60 foreign trading partners, which together account for nearly all U.S. import trade.  Under the final action, trading partners that have adopted, or have committed to adopt and effectively enforce, a qualifying forced labor import prohibition are subject to the lower 10% tariff rate, while trading partners that have not adopted such a prohibition are subject to the 12.5% rate.  Certain categories of goods are excluded from the new tariffs, including articles already subject to duties under Section 232 of the Trade Expansion Act of 1962, and certain other products identified by USTR as warranting exemption.

[0001193125-26-331632:mdna:27]
Furthermore, recent U.S. trade actions have triggered retaliatory actions by certain affected countries, and other foreign governments may impose further trade measures, including reciprocal tariffs, on certain U.S. goods in the future. There remains substantial uncertainty regarding the duration of existing and newly announced tariffs, potential changes or pauses to such tariffs, tariff levels, and whether further additional tariffs or other retaliatory actions may be imposed, modified, or suspended, and the impacts of such actions on our business. These changes in U.S. trade policy and subsequent retaliatory actions have the potential to materially alter various input costs for the Company. Moreover, related costs and the uncertainty arising from such changes in trade policy may result in shifts in customer behavior, such as decreased demand. These impacts could have a negative effect on our financial results, including our revenue and profitability. To help mitigate this, the Company has taken steps to diversify its supply chain, manufacturing locations and relationships with suppliers to provide added flexibility. See “Changes in trade policy in the U.S. and other countries, including the imposition of additional tariffs and the resulting consequences, may adversely impact our gross profits, gross margins, results of operations and financial condition,” in Part II, Item 1A “Risk Factors” of this report for further discussion of the risks associated with the changes to U.S. and foreign trade policies.

[0001193125-26-331632:mdna:28]
[same as prior period, unchanged from 0001193125-26-205276:mdna:27]

[0001193125-26-331632:mdna:29]
[same as prior period, unchanged from 0001193125-26-205276:mdna:28]

[0001193125-26-331632:mdna:30]
[same as prior period, unchanged from 0001193125-26-205276:mdna:29]

[0001193125-26-331632:mdna:31]
Given the lack of clarity surrounding refund execution to determine expected recovery amount, the Company has concluded that recovery of the IEEPA tariffs is not probable as of the reporting date. Accordingly, no refund receivable has been recognized. Management will continue to monitor developments, including CBP implementation milestones, formal guidance on claim  submission, and claim acceptance processes.

[0001193125-26-331632:mdna:32]
[same as prior period, unchanged from 0001193125-26-205276:mdna:32]

[0001193125-26-331632:mdna:33]
[same as prior period, unchanged from 0001193125-26-205276:mdna:33]

[0001193125-26-331632:mdna:34]
[same as prior period, unchanged from 0001193125-26-205276:mdna:34]

[0001193125-26-331632:mdna:35]
[same as prior period, unchanged from 0001193125-26-205276:mdna:35]

[0001193125-26-331632:mdna:36]
[same as prior period, unchanged from 0001193125-26-205276:mdna:36]

[0001193125-26-331632:mdna:37]
36

[0001193125-26-331632:mdna:38]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2026, COMPARED TO THE THREE AND SIX MONTHS ENDED JUNE 30, 2025

[0001193125-26-331632:mdna:39]
[same as prior period, unchanged from 0001193125-26-205276:mdna:39]

[0001193125-26-331632:mdna:40]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2026 |  |  | 2025 |  |  | 2026 |  |  | 2025 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 82.8 |  | % |  | 82.8 |  | % |  | 83.0 |  | % |  | 82.2 |  | % |
| Services & Support |  |  | 17.2 |  |  |  | 17.2 |  |  |  | 17.0 |  |  |  | 17.8 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 56.1 |  |  |  | 55.6 |  |  |  | 55.0 |  |  |  | 54.9 |  |  |
| Services & Support |  |  | 7.0 |  |  |  | 7.1 |  |  |  | 6.7 |  |  |  | 7.2 |  |  |
| Total Cost of Revenue |  |  | 63.0 |  |  |  | 62.7 |  |  |  | 61.8 |  |  |  | 62.1 |  |  |
| Gross Profit |  |  | 37.0 |  |  |  | 37.3 |  |  |  | 38.2 |  |  |  | 37.9 |  |  |
| Selling, general and administrative expenses |  |  | 21.4 |  |  |  | 22.8 |  |  |  | 20.5 |  |  |  | 21.6 |  |  |
| Research and development expenses |  |  | 19.1 |  |  |  | 19.6 |  |  |  | 18.4 |  |  |  | 19.6 |  |  |
| Operating Loss |  |  | (3.6 | ) |  |  | (5.0 | ) |  |  | (0.7 | ) |  |  | (3.4 | ) |  |
| Interest and dividend income |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |
| Interest expense |  |  | (1.5 | ) |  |  | (1.7 | ) |  |  | (1.5 | ) |  |  | (1.8 | ) |  |
| Net investment gain |  |  | 1.9 |  |  |  | 1.2 |  |  |  | 0.8 |  |  |  | 0.3 |  |  |
| Other income (expense), net |  |  | 0.3 |  |  |  | (1.0 | ) |  |  | 0.3 |  |  |  | (0.3 | ) |  |
| Loss Before Income Taxes |  |  | (2.8 | ) |  |  | (6.5 | ) |  |  | (0.9 | ) |  |  | (5.2 | ) |  |
| Income tax expense |  |  | (0.3 | ) |  |  | (0.4 | ) |  |  | (0.5 | ) |  |  | (0.1 | ) |  |
| Net Loss |  |  | (3.1 | ) | % |  | (6.9 | ) | % |  | (1.4 | ) | % |  | (5.3 | ) | % |
| Less: Net Income attributable to non-controlling interest |  |  | 0.8 |  |  |  | 0.9 |  |  |  | 0.8 |  |  |  | 0.9 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | (3.9 | ) | % |  | (7.7 | ) | % |  | (2.2 | ) | % |  | (6.2 | ) | % |

[0001193125-26-331632:mdna:41]
[same as prior period, unchanged from 0001193125-26-205276:mdna:41]

[0001193125-26-331632:mdna:42]
Our revenue increased 6.1% from $265.1 million for the three months ended June 30, 2025, to $281.1 million for the three months ended June 30, 2026, and increased 10.6% from $512.8 million for the six months ended June 30, 2025, to $567.2 million for the six months ended June 30, 2026. The increase in revenue for the three and six months ended June 30, 2026, was driven by increased volume of sales activity and continued strength of our core markets, due to broadband expansion brought about by higher service provider spending and continued vendor consolidation due to a shift away from high-risk vendors.

[0001193125-26-331632:mdna:43]
The increase in revenue by category for the three months ended June 30, 2026, was primarily attributable to a $19.6 million increase in Optical Networking Solutions products, a $0.8 million increase in Subscriber Solutions products, partially offset by a $4.3 million decrease in Access & Aggregation revenue. The increase in revenue by category for the six months ended June 30, 2026, was primarily attributable to a $38.7 million increase in Optical Networking Solutions products, a $18.6 million increase in Subscriber Solutions products, partially offset by a $2.9 million decrease in Access & Aggregation revenue. The increase in Optical Networking Solutions products was primarily driven by high-risk vendor displacement across Europe and was helped by increased sales to enterprise, government and internet content provider customers. The increase in Subscriber Solutions products was primarily driven by continued investment in fiber-to-the-home, multi-Gig Wi-Fi 7, and Carrier Ethernet applications. The decrease in Access & Aggregation revenue was primarily driven by a project delay from a single customer, and was partially offset by increases in revenue driven by broad-based strength across the U.S. and Europe.

[0001193125-26-331632:mdna:44]
Network Solutions Segment Revenue

[0001193125-26-331632:mdna:45]
Network Solutions segment revenue increased 6.1% from $219.5 million for the three months ended June 30, 2025, to $232.9 million for the three months ended June 30, 2026, and increased 11.6% from $421.7 million for the six months ended June 30, 2025, to $470.8 million for the six months ended June 30, 2026. The increase in Network Solutions revenue by category for the three months ended June 30, 2026, was due to an increase in volume of sales activity of $20.6 million in Optical Networking products, partially offset by a $5.2 million decrease in Access & Aggregation products and a $2.0 million decrease in Subscriber Solutions products. The increase in Network Solutions revenue by category for the six months ended June 30, 2026, was due to an increase in volume of sales activity of $36.9 million in Optical Networking products and $16.5 million in Subscriber Solutions products, partially offset by a $4.3 million decrease in Access & Aggregation products.

[0001193125-26-331632:mdna:46]
Services & Support Segment Revenue

[0001193125-26-331632:mdna:47]
Services & Support segment revenue increased 5.9% from $45.6 million for the three months ended June 30, 2025, to $48.2 million for the three months ended June 30, 2026, and increased 5.8% from $91.1 million for the six months ended June 30, 2025, to $96.4 million for the six months ended June 30, 2026. The increase in Services & Support revenue by category for the three months ended June 30, 2026, was primarily attributable to a $2.8 million increase in Subscriber Solutions and $0.9 million in Access & Aggregation, partially offset by a $1.0 million decrease in Optical Networking services. The increase in Services & Support revenue by category for the six months ended June 30, 2026, was primarily attributable to increases of $2.1 million increase in Subscriber Solutions, $1.8 million in Optical Networking services and $1.4 million increase in Access & Aggregation.

[0001193125-26-331632:mdna:48]
Domestic Revenue

[0001193125-26-331632:mdna:49]
U.S. revenue increased by 11.7% from $120.3 million for the three months ended June 30, 2025, to $134.4 million for the three months ended June 30, 2026, and increased by 25.5% from $223.5 million for the six months ended June 30, 2025, to $280.6 million for the six months ended June 30, 2026. The increase in U.S. revenue for the three and six months ended June 30, 2026, was primarily due to continued customer spending and broadband expansion.

[0001193125-26-331632:mdna:50]
International Revenue

[0001193125-26-331632:mdna:51]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., increased by 1.4% from $144.7 million for the three months ended June 30, 2025 to $146.7 million for the three months ended June 30, 2026 and decreased by 0.9% from $289.3 million for the six months ended June 30, 2025 to $286.7 million for the six months ended June 30, 2026. International revenue, as a percentage of total revenue, decreased from 54.6% for the three months ended June 30, 2025, to 52.2% for the three months ended June 30, 2026, and decreased from 56.4% for the six months ended June 30, 2025, to 50.5% for the six months ended June 30, 2026. The change in international revenue for the three and six months ended June 30, 2026 compared to the three and six months June 30, 2025, remained relatively flat, with minor fluctuations driven by changes in customer and product mix. For the three and six months ended June 30, 2026, as compared to the three and six months ended June 30, 2025, changes in foreign currencies relative to the U.S. dollar increased our net revenue by approximately $1.9 million and $3.8 million, respectively.

[0001193125-26-331632:mdna:52]
Our ADTRAN, Inc. international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and, in some instances, regionally – whether of a multi-country region or a more local region within a country. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income. Our Adtran Networks international revenue is largely focused on the manufacture and selling of networking solutions that are based on three core areas of expertise: fiber-optic transmission technology (cloud interconnect), cloud access technology for rapid creation of innovative services around the network edge and solutions for precise timing and synchronization of networks. In addition, Adtran Networks international operations offers a comprehensive portfolio of network design, implementation and maintenance services to assist operators in the deployment of market-leading networks while reducing costs to maintain these networks.

[0001193125-26-331632:mdna:53]
[same as prior period, unchanged from 0001193125-26-205276:mdna:49]

[0001193125-26-331632:mdna:54]
As a percentage of revenue, cost of revenue increased from 62.7% for the three months ended June 30, 2025, to 63.0% for the three months ended June 30, 2026, and decreased from 62.1% for the six months ended June 30, 2025, to 61.8% for the six months ended June 30, 2026. Cost of revenue as a percentage of revenue for the three and six months ended June 30, 2026, remained relatively flat, with minor fluctuations driven by changes in customer and product mix.

[0001193125-26-331632:mdna:55]
For the three and six months ended June 30, 2026, as compared to the three and six months ended June 30, 2025, changes in foreign currencies relative to the U.S. dollar increased our cost of revenue by approximately $1.3 million and $2.5 million, respectively.

[0001193125-26-331632:mdna:56]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 67.1% for the three months ended June 30, 2025, to 67.7% for the three months ended June 30, 2026, and decreased from 66.8% for the six months ended June 30, 2025, to 66.3% for the six months ended June 30, 2026. Network Solutions cost of revenue as a percentage of revenue for the three and six months ended June 30, 2026, remained relatively flat, with minor fluctuations driven by changes in customer and product mix.

[0001193125-26-331632:mdna:57]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 41.3% for the three months ended June 30, 2025, to 40.6% for the three months ended June 30, 2026, and decreased from 40.8% for the six months ended June 30, 2025 to 39.5% for the six months ended June 30, 2026. Services & Support cost of revenue as a percentage of revenue for the three and six months ended June 30, 2026, remained relatively flat, with minor fluctuations driven by cyclical changes in customer buying habits.

[0001193125-26-331632:mdna:58]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work

[0001193125-26-331632:mdna:59]
for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001193125-26-331632:mdna:60]
[same as prior period, unchanged from 0001193125-26-205276:mdna:54]

[0001193125-26-331632:mdna:61]
As a percentage of revenue, gross profit decreased from 37.3% for the three months ended June 30, 2025, to 37.0% for the three months ended June 30, 2026, and increased from 37.9% for the six months ended June 30, 2025, to 38.2% for the six months ended June 30, 2026. The gross profit as a percentage of revenue for the three and six months ended June 30, 2026, remained relatively flat, with minor fluctuations driven by changes in customer and product mix. For the three and six months ended June 30, 2026, as compared to the three and six months ended June 30, 2025, changes in foreign currencies relative to the U.S. dollar increased our gross profit by approximately $0.7 million and $1.3 million, respectively.

[0001193125-26-331632:mdna:62]
As a percentage of that segment's revenue, Network Solutions gross profit decreased from 32.9% for the three months ended June 30, 2025, to 32.3% for the three months ended June 30, 2026, and increased from 33.2% for the six months ended June 30, 2025 to 33.7% for the six months ended June 30, 2026. The decrease in gross profit for the three and six months ended June 30, 2026, remained relatively flat, with minor fluctuations driven by changes in customer and product mix.

[0001193125-26-331632:mdna:63]
As a percentage of that segment's revenue, Services & Support gross profit increased from 58.7% for the three months ended June 30, 2025, to 59.4% for the three months ended June 30, 2026, and increased from 59.2% for the six months ended June 30, 2025, to 60.5% for the six months ended June 30, 2026. The increase in gross profit for the three and six months ended June 30, 2026 remained relatively flat, with minor fluctuations driven by cyclical changes in customer buying habits.

[0001193125-26-331632:mdna:64]
[same as prior period, unchanged from 0001193125-26-205276:mdna:59]

[0001193125-26-331632:mdna:65]
As a percentage of revenue, selling, general and administrative expenses decreased from 22.8% for the three months ended June 30, 2025, to 21.4% for the three months ended June 30, 2026, and decreased from 21.6% for the six months ended June 30, 2025, to 20.5% for the six months ended June 30, 2026. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0001193125-26-331632:mdna:66]
Selling, general and administrative expenses decreased 0.2% from $60.3 million for the three months ended June 30, 2025, to $60.2 million for the three months ended June 30, 2026, and increased 4.9% from $110.6 million for the six months ended June 30, 2025, to $116.1 million for the six months ended June 30, 2026. Selling, general and administrative expenses include personnel costs for management and back office departments, as well as auditor, tax and other professional fees. The increase for the six months ended June 30, 2026, compared to the six months ended June 30, 2025, was primarily attributable to increased employee-related costs and increased travel related expenses. For the three and six months ended June 30, 2026, as compared to the three and six months ended June 30, 2025, changes in foreign currencies relative to the U.S. dollar increased our selling, general and administrative expenses by approximately $0.6 million and $1.3 million, respectively.

[0001193125-26-331632:mdna:67]
[same as prior period, unchanged from 0001193125-26-205276:mdna:62]

[0001193125-26-331632:mdna:68]
As a percentage of revenue, research and development expenses decreased from 19.6% for the three months ended June 30, 2025, to 19.1% for the three months ended June 30, 2026, and decreased from 19.6% for the six months ended June 30, 2025, to 18.4% for the six months ended June 30, 2026. Research and development expenses as a percentage of revenue will generally fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0001193125-26-331632:mdna:69]
Research and development expenses increased 3.6% from $51.9 million for the three months ended June 30, 2025, to $53.8 million for the three months ended June 30, 2026, and increased 3.8% from $100.8 million for the six months ended June 30, 2025, to $104.6 million for the six months ended June 30, 2026. The increase in research and development expenses for the three months ended June 30, 2026 compared to the three months ended June 30, 2025, was primarily attributable to increased employee-related costs. The increase in research and development expenses for the six months ended June 30, 2026 compared to the six months ended June 30, 2025, was primarily attributable to increased employee-related costs partially offset by increased governmental research and development subsidies. For the three and six months ended June 30, 2026 as compared to the three and six months ended June 30, 2025, changes in foreign currencies relative to the U.S. dollar increased our research and development expenses by approximately $1.3 million and $2.5 million, respectively.

[0001193125-26-331632:mdna:70]
Adtran Networks has arrangements with governmental entities for the purpose of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expenses incurred. For the three months ended June 30, 2026 and 2025, the Company recognized $3.4 million and $3.1 million as a reduction of research and development expense, respectively. For the six months ended June 30, 2026 and 2025, the Company recognized $6.4 million and $5.3 million as a reduction of research and development expense, respectively.

[0001193125-26-331632:mdna:71]
We expect to continue to incur research and development expenses in connection with our new and existing products. We continually evaluate new product opportunities and engage in significant research and product development efforts, which provides for new product

[0001193125-26-331632:mdna:72]
development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0001193125-26-331632:mdna:73]
[same as prior period, unchanged from 0001193125-26-205276:mdna:67]

[0001193125-26-331632:mdna:74]
Interest and dividend income increased from $0.2 million for the three months ended June 30, 2025, to $0.4 million for the three months ended June 30, 2026 and increased from $0.3 million for the six months ended June 30, 2025, to $0.7 million for the six months ended June 30, 2026. The increase in interest and dividend income is primarily attributable to fluctuations in investment balances and an increase in the rate of return on those investments due to interest rate movements.

[0001193125-26-331632:mdna:75]
[same as prior period, unchanged from 0001193125-26-205276:mdna:69]

[0001193125-26-331632:mdna:76]
Interest expense decreased from $4.6 million for the three months ended June 30, 2025, to $4.2 million for the three months ended June 30, 2026, and decreased from $9.3 million for the six months ended June 30, 2025, to $8.5 million for the six months ended June 30, 2026. The decrease in interest expense during the three and six months ended June 30, 2026, was primarily driven by the issuance of the 2030 Notes, which accrues interest at 4.7%, and the repayment of the majority of the principal under the credit agreement with Wells Fargo which accrued interest at 8.6% for the three and six months ended June 30, 2025. See Note 10 and Note 11 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0001193125-26-331632:mdna:77]
Net Investment Gain

[0001193125-26-331632:mdna:78]
We recognized a net investment gain of $3.1 million and $5.3 million for the three months ended June 30, 2025 and 2026, respectively and recognized a net investment gain of $1.4 million and $4.4 million for the six months ended June 30, 2025, and 2026, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See Note 5 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-26-331632:mdna:79]
Other Income (Expense), net

[0001193125-26-331632:mdna:80]
Other income (expense), net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, increased from expense of $2.6 million for the three months ended June 30, 2025 to income of $0.7 million for the three months ended June 30, 2026 and increased from expense of $1.7 million for the six months ended June 30, 2025 to income of $2.0 million for the six months ended June 30, 2026.

[0001193125-26-331632:mdna:81]
Income Tax Expense

[0001193125-26-331632:mdna:82]
The Company's effective tax rate changed from an expense of 5.9% of pre-tax loss for the three months ended June 30, 2025, to an expense of 10.0% of pre-tax loss for the three months ended June 30, 2026 and changed from an expense of 2.3% of pre-tax loss for the six months ended June 30, 2025, to an expense of 53.4% of pre-tax loss for the six months ended June 30, 2026. The changes in the effective tax rate for the three and six months ended June 30, 2026, was driven primarily by loss jurisdictions for which the recognition of tax benefits on pre-tax losses incurred were limited due to a valuation allowance during the three and six months ended June 30, 2026.

[0001193125-26-331632:mdna:83]
[same as prior period, unchanged from 0001193125-26-205276:mdna:77]

[0001193125-26-331632:mdna:84]
As a result of the above factors, net loss attributable to ADTRAN Holdings, Inc. decreased from net loss of $20.5 million for the three months ended June 30, 2025, to a net loss of $10.9 million for the three months ended June 30, 2026, and decreased from net loss of $31.8 million for the six months ended June 30, 2025, to a net loss of $12.2 million for the six months ended June 30, 2026.

[0001193125-26-331632:mdna:85]
[same as prior period, unchanged from 0001193125-26-205276:mdna:79]

[0001193125-26-331632:mdna:86]
[same as prior period, unchanged from 0001193125-26-205276:mdna:80]

[0001193125-26-331632:mdna:87]
We generally finance our ongoing business with existing cash, investments, credit arrangements and cash flow from operations to manage our working capital needs. We had a positive cash flow from operating activities of $38.6 million in the six months ended June 30, 2026. We have used, and expect to continue to use, existing cash, credit arrangements and cash generated from operations for working capital and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures.

[0001193125-26-331632:mdna:88]
As of June 30, 2026, our cash on hand was $79.2 million of which $58.2 million was held by our foreign subsidiaries. As of June 30, 2026 the Company had access to $318.2 million on its Credit Facility for future borrowings based on debt covenant compliance metrics. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax. As of December 31, 2025, our cash on hand was $95.7 million, of which $87.5 million was held by our foreign subsidiaries.

[0001193125-26-331632:mdna:89]
[same as prior period, unchanged from 0001193125-26-205276:mdna:83]

[0001193125-26-331632:mdna:90]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of June 30, 2026. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €292.6 million or $334.2 million, based on an exchange rate as of June 30, 2026, and reflecting interest accrued through June 30, 2026 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). Following the effective date of the DPLTA on January 16, 2023, certain Adtran Networks shareholders filed lawsuits against the Company in the Regional Court Meiningen, Germany challenging the Exit Compensation offered under the DPLTA. The Regional Court Meiningen has not yet ruled on the shareholders' claims. After the Regional Court Meiningen issues an opinion, an appeal is likely to follow, and thus the Company does not anticipate a final decision on the shareholders' claims until late 2027 or 2028.

[0001193125-26-331632:mdna:91]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €7.6 million or $8.7 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2025 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 15, 2026 and, therefore, the Annual Recurring Compensation was paid after the ordinary general shareholders’ meeting in the amount of $8.9 million. During the three months ended June 30, 2026 and 2025, we accrued $2.1 million and $2.4 million, respectively, in Annual Recurring Compensation. During the six months ended June 30, 2026 and 2025, we accrued $4.3 million and $4.8 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.

[0001193125-26-331632:mdna:92]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Former Credit Agreement”), which was subsequently amended six times. As of June 30, 2026 the Company had access to $318.2 million on its Credit Facility for future borrowings based on debt covenant compliance metrics.

[0001193125-26-331632:mdna:93]
On July 21, 2026, ADTRAN Holdings, Inc. (the “Company”) as guarantor, ADTRAN, Inc., a Delaware corporation (the “US Borrower”), and Adtran Networks SE, a European stock corporation (the “German Borrower” and together with the US Borrower, collectively, the “Borrowers”), entered into a credit agreement (the “New Credit Agreement”) with J.P. Morgan Chase Bank, N.A., as administrative agent for the US Borrower and J.P. Morgan SE, as administrative agent for the German Borrower, and the financial institutions party thereto, as lenders. The New Credit Agreement allows for borrowings of up to $350.0 million in aggregate principal amount, with borrowings by the German Borrower limited to $50.0 million. The New Credit Agreement replaces the Former Credit Agreement. The proceeds of any loans are expected to be used for general corporate purposes not prohibited under the New Credit Agreement.

[0001193125-26-331632:mdna:94]
As of June 30, 2026, and as of the date of issuance of the condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q, the Company has sufficient liquidity through its operating cash flow and the borrowings available under the Credit Facility to meet a majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three and six months ended June 30, 2026, approximately 0.4 million shares and 0.6 million shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €11.7 million, or $13.8 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the three and six months ended June 30, 2025, approximately 0.9 million shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million, or $19.4 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal

[0001193125-26-331632:mdna:95]
41

[0001193125-26-331632:mdna:96]
proceedings and the Company does not anticipate a final decision on shareholder's challenges to Exit Compensation until late 2027 or 2028; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the current guaranteed Annual Recurring Compensation payment; and (iv) the current trading value of Adtran Networks shares.

[0001193125-26-331632:mdna:97]
In summary, the Company believes that its cash and cash equivalents, working capital management and availability to access cash under its credit facility or other future sources of capital, will be adequate to meet its business operating requirements, its capital expenditures and its expected obligations under both the Notes and the DPLTA, including the anticipated levels of Exit Compensation as well to support the Company's ability to continue to comply with its debt covenants under its credit facility for at least the next twelve months, from the issuance of the condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q. See Note 10, Credit Agreements, and Note 18, Subsequent Events in the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 for additional information regarding the terms of the Former Credit Agreement and the New Credit Agreement, respectively.

[0001193125-26-331632:mdna:98]
[same as prior period, unchanged from 0001193125-26-205276:mdna:89]

[0001193125-26-331632:mdna:99]
[same as prior period, unchanged from 0001193125-26-205276:mdna:101]

[0001193125-26-331632:mdna:100]
On September 19, 2025, the Company issued $201.3 million principal amount of 2030 Notes. The 2030 Notes were issued pursuant to, and are governed by, an indenture, dated as of September 19, 2025, between the Company and U.S. Bank Trust Company, National Association, as trustee. In connection with the 2030 Notes, the Company has entered into privately negotiated Capped Calls.

[0001193125-26-331632:mdna:101]
Interest expense related to the 2030 Notes was $2.3 million and $4.5 million for the three and six months ended June 30, 2026, respectively. In conjunction with the issuance of the 2030 Notes, the Company recognized debt issuance costs of $8.7 million, which were capitalized as components of the carrying amount and included in convertible senior notes, net within the Consolidated Balance Sheets. See Note 11 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for more information.

[0001193125-26-331632:mdna:102]
J.P. Morgan Credit Agreement

[0001193125-26-331632:mdna:103]
On July 21, 2026, the Company entered into the New Credit Agreement with J.P. Morgan Chase Bank, N.A. The New Credit Agreement allows for borrowings of up to $350.0 million in aggregate principal amount, with borrowings by the German Borrower limited to $50.0 million. The New Credit Agreement matures in July 2031 and provides for borrowings bearing interest, at the Company’s election, at either the Term Benchmark Rate or the Base Rate, in each case subject to a 0.00% floor, plus an applicable margin based on the consolidated total net leverage ratio. The applicable margin ranges from 2.25% to 3.25% for Term Benchmark Rate loans and from 1.25% to 2.25% for Base Rate loans. The Borrowers are also required to pay a commitment fee of 0.25% on unused revolving commitments. The New Credit Agreement replaces the Former Credit Agreement. The proceeds of any loans are expected to be used for general corporate purposes not prohibited under the New Credit Agreement. Under the New Credit Agreement, the Company agreed to maintain certain leverage ratios and certain fixed charge coverage ratios commencing with the fiscal quarter ending December 31, 2026.

[0001193125-26-331632:mdna:104]
In connection with entering into the New Credit Agreement, on July 21, 2026, the Company terminated the Former Credit Agreement, the collateral agreement dated July 18, 2022, the ADVA domestic collateral agreement dated June 4, 2024, the guaranty agreement dated July 18, 2022 and the ADVA guaranty agreement dated June 4, 2024. See Note 10, Credit Agreements and Note 18, Subsequent Events of the Notes to Condensed Consolidated Financial Statements in Part 1, Item 1 of this report for additional information regarding the terms of the Former Credit Agreement and the new J.P. Morgan Chase Bank Credit Agreement.

[0001193125-26-331632:mdna:105]
[same as prior period, unchanged from 0001193125-26-205276:mdna:104]

[0001193125-26-331632:mdna:106]
Net cash provided by operating activities of $38.6 million during the six months ended June 30, 2026, decreased by $36.7 million compared to net cash provided by operating activities of $75.3 million during the six months ended June 30, 2025.

[0001193125-26-331632:mdna:107]
[same as prior period, unchanged from 0001193125-26-205276:mdna:106]

[0001193125-26-331632:mdna:108]
| (In thousands) |  | Six Months EndedJune 30, 2026 |  |
| Net loss |  | $ | (7,774 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization |  |  | 50,478 |  |
| Amortization of debt issuance cost |  |  | 746 |  |
| Amortization of convertible notes issuance costs |  |  | 784 |  |
| Gain on investments, net |  |  | (4,530 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 82 |  |
| Stock-based compensation expense |  |  | 4,670 |  |
| Deferred income taxes |  |  | (413 | ) |
| Inventory reserves |  |  | 277 |  |
| Changes in operating assets and liabilities |  |  |  |
| Accounts receivable, net |  |  | 1,758 |  |
| Other receivables |  |  | (2,872 | ) |
| Income taxes receivable, net |  |  | 2,733 |  |
| Inventory |  |  | 3,422 |  |
| Prepaid expenses, other current assets and other assets |  |  | 426 |  |
| Accounts payable |  |  | 10,941 |  |
| Accrued expenses and other liabilities |  |  | (20,468 | ) |
| Income taxes payable |  |  | (1,675 | ) |
| Net cash provided by operating activities |  | $ | 38,585 |  |

[0001193125-26-331632:mdna:109]
Quarterly accounts receivable DSO increased from 66 days as of December 31, 2025, to 67 days as of June 30, 2026 and was primarily driven by customer and geographical mix of commercial terms.

[0001193125-26-331632:mdna:110]
[same as prior period, unchanged from 0001193125-26-205276:mdna:109]

[0001193125-26-331632:mdna:111]
Quarterly inventory turnover increased from 2.8 turns as of December 31, 2025, to 3.4 turns as of June 30, 2026. The increase in inventory turnover was primarily attributable to increased volume of sales activity due to continue strength of spending within our core markets and utilization of buffer stock. The decrease in inventory was primarily attributable to increased volume of sales activity due to continue strength of spending within our core markets and utilization of buffer stock. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory for customer demand and improve working capital.

[0001193125-26-331632:mdna:112]
[same as prior period, unchanged from 0001193125-26-205276:mdna:111]

[0001193125-26-331632:mdna:113]
[same as prior period, unchanged from 0001193125-26-205276:mdna:112]

[0001193125-26-331632:mdna:114]
[same as prior period, unchanged from 0001193125-26-205276:mdna:113]

[0001193125-26-331632:mdna:115]
Capital expenditures totaled approximately $33.2 million and $32.5 million for the six months ended June 30, 2026 and 2025, respectively. The increase in capital expenditures for the six months ended June 30, 2026, was primarily attributable to increases in expenditures related to developed technology, equipment and building improvements.

[0001193125-26-331632:mdna:116]
Our deferred compensation plan assets increased 11.1% from $35.2 million as of December 31, 2025, to $39.1 million as of June 30, 2026. Our investments include various marketable equity securities with a fair market value of $1.0 million and $1.0 million as of June 30, 2026, and December 31, 2025. See Note 5 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001193125-26-331632:mdna:117]
[same as prior period, unchanged from 0001193125-26-205276:mdna:116]

[0001193125-26-331632:mdna:118]
For the six months ended June 30, 2026, net cash used in financing activities was $19.0 million, which was primarily due to $13.8 million of payments for redemption of redeemable non-controlling interest, $8.9 million payment of annual recurring compensation to non-controlling interests, $1.6 million of payments of tax withholdings related to stock-based compensation settlements, $1.4 million

[0001193125-26-331632:mdna:119]
of payments on a financing agreement partially offset by $6.6 million proceeds from stock option exercises.

[0001193125-26-331632:mdna:120]
[same as prior period, unchanged from 0001193125-26-205276:mdna:118]

[0001193125-26-331632:mdna:121]
There were no stock repurchases during the periods ended June 30, 2026, and 2025, and there currently is no authorized stock repurchase program for the repurchase of ADTRAN Holdings, Inc. shares.

[0001193125-26-331632:mdna:122]
[same as prior period, unchanged from 0001193125-26-205276:mdna:120]

[0001193125-26-331632:mdna:123]
To accommodate employee stock option exercises, the Company issued 0.9 million and 0.2 million shares of common stock which resulted in proceeds of $6.6 million and $1.2 million during the six months ended June 30, 2026 and 2025, respectively.

[0001193125-26-331632:mdna:124]
[same as prior period, unchanged from 0001193125-26-205276:mdna:122]

[0001193125-26-331632:mdna:125]
[same as prior period, unchanged from 0001193125-26-205276:mdna:123]

[0001193125-26-331632:mdna:126]
[same as prior period, unchanged from 0001193125-26-205276:mdna:124]

[0001193125-26-331632:mdna:127]
[same as prior period, unchanged from 0001193125-26-205276:mdna:125]

[0001193125-26-331632:mdna:128]
The fair value of the assets held by the deferred compensation programs totaled $39.1 million and $35.2 million as of June 30, 2026, and December 31, 2025, respectively, and is included in short-term investments on the Condensed Consolidated Balance Sheets. The amounts payable to the deferred compensation program participants totaled $42.7 million and $37.4 million as of June 30, 2026, and December 31, 2025, respectively. For additional information, see Note 5 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0001193125-26-331632:mdna:129]
[same as prior period, unchanged from 0001193125-26-205276:mdna:127]

[0001193125-26-331632:mdna:130]
We have exposure to credit losses from off-balance sheet exposures, to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of June 30, 2026. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 17 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0001193125-26-331632:mdna:131]
[same as prior period, unchanged from 0001193125-26-205276:mdna:129]

[0001193125-26-331632:mdna:132]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of the date of this filing, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA, which is discussed below). Other than operating lease obligations, the cash requirements table excludes interest payments.

[0001193125-26-331632:mdna:133]
| (In thousands) |  | Total |  |  | 2026 |  |  | 2027 |  |  | 2028 |  |  | 2029 |  |  | 2030 |  |  | Thereafter |  |
| J.P. Morgan credit agreement(1) |  | $ | 47,961 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 47,961 |  |
| Convertible Senior Notes (2) |  |  | 201,250 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 201,250 |  |  |  | — |  |
| Purchase obligations(3) |  |  | 232,001 |  |  |  | 174,748 |  |  |  | 48,448 |  |  |  | 8,505 |  |  |  | 300 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations(4) |  |  | 39,412 |  |  |  | 4,609 |  |  |  | 8,553 |  |  |  | 7,937 |  |  |  | 4,622 |  |  |  | 3,228 |  |  |  | 10,463 |  |
| Totals |  | $ | 520,624 |  |  | $ | 179,357 |  |  | $ | 57,001 |  |  | $ | 16,442 |  |  | $ | 4,922 |  |  | $ | 204,478 |  |  | $ | 58,424 |  |

[0001193125-26-331632:mdna:134]
(1) On July 21, 2026, the Company, entered into the New Credit Agreement with J.P. Morgan Chase Bank, N.A. The New Credit Agreement allows

[0001193125-26-331632:mdna:135]
for borrowings of up to $350.0 million in aggregate principal amount. The borrowings outstanding as of the date of the filing include funds for

[0001193125-26-331632:mdna:136]
closing and legal fees and other general corporate purposes. See Note 18, Subsequent Events of the Notes to Condensed Consolidated Financial

[0001193125-26-331632:mdna:137]
Statements in Part 1, Item 1 of this report and “Liquidity and Capital Resources - J.P. Morgan Credit Agreement” for additional information

[0001193125-26-331632:mdna:138]
regarding the terms of the new J.P. Morgan Chase Bank Credit Agreement.

[0001193125-26-331632:mdna:139]
(2) See description below.

[0001193125-26-331632:mdna:140]
(3) We have purchase obligations related to open purchase orders to our contract manufacturers, ODMs, component suppliers, service partners and

[0001193125-26-331632:mdna:141]
other vendors. The settlement of our purchase obligations will occur at various dates beginning in 2026 and going

[0001193125-26-331632:mdna:142]
through 2029. See Note 17 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of the report for more

[0001193125-26-331632:mdna:143]
information.

[0001193125-26-331632:mdna:144]
(4) We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations.

[0001193125-26-331632:mdna:145]
Our operating leases have remaining lease terms ranging from 1 month to 149 months as of June 30, 2026.

[0001193125-26-331632:mdna:146]
[same as prior period, unchanged from 0001193125-26-205276:mdna:137]

[0001193125-26-331632:mdna:147]
[same as prior period, unchanged from 0001193125-26-205276:mdna:138]

[0001193125-26-331632:mdna:148]
[same as prior period, unchanged from 0001193125-26-205276:mdna:139]

[0001193125-26-331632:mdna:149]
On July 1, 2024, the Company entered into a Factoring Agreement with a third-party financial institution (the "Factor"), which accelerates receivable collection and helps to better manage cash flow. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. Total accounts receivables factored as of the end of June 30, 2026, totaled $18.3 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. During the six months ended June 30, 2026 and 2025, the Company received $94.8 million and $73.8 million in cash proceeds from the Factoring Agreement, respectively, which are recorded in operating cash flows on the Condensed Consolidated Statement of Cash Flows. See Note 2 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0001193125-26-331632:mdna:150]
[same as prior period, unchanged from 0001193125-26-205276:mdna:141]

[0001193125-26-331632:mdna:151]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE ("Adtran Networks"), as the controlled company, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0001193125-26-331632:mdna:152]
[same as prior period, unchanged from 0001193125-26-205276:mdna:143]

[0001193125-26-331632:mdna:153]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of June 30, 2026. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €292.6 million or $334.2 million, based on an exchange rate

[0001193125-26-331632:mdna:154]
as of June 30, 2026, and reflecting interest accrued through June 30, 2026, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). Following the effective date of the DPLTA on January 16, 2023, certain Adtran Networks shareholders filed lawsuits against the Company in the Regional Court Meiningen, Germany challenging the Exit Compensation offered under the DPLTA. The Regional Court Meiningen has not yet ruled on the shareholders' claims. After the Regional Court Meiningen issues an opinion, an appeal is likely to follow, and thus the Company does not anticipate a final decision on the shareholders' claims until late 2027 or 2028.

[0001193125-26-331632:mdna:155]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €7.6 million or $8.7 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2025 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 15, 2026 and, therefore, the Annual Recurring Compensation was paid after the ordinary general shareholders’ meeting in the amount of $8.9 million. During the three months ended June 30, 2026 and 2025, we accrued $2.1 million and $2.4 million, respectively, in Annual Recurring Compensation. During the six months ended June 30, 2026 and 2025, we accrued $4.3 million and $4.8 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.

[0001193125-26-331632:mdna:156]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares.

[0001193125-26-331632:mdna:157]
For the three and six months ended June 30, 2026, approximately 0.4 million shares and 0.6 million shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €11.7 million, or $13.8 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the three and six months ended June 30, 2025, approximately 0.9 million shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million, or $19.4 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders.

[0001193125-26-331632:mdna:158]
As of June 30, 2026 we held 37,447,983 no-par value bearer shares of Adtran Networks, representing 71.9% of Adtran Networks outstanding shares as of June 30, 2026.

[0001193125-26-331632:mdna:159]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which incorporated by reference to Exhibit 10.14 of the 2025 Form 10-K.

[0001193125-26-331632:mdna:160]
[same as prior period, unchanged from 0001193125-26-205276:mdna:149]

[0001193125-26-331632:mdna:161]
During the six months ended June 30, 2026, other than the Exit Compensation payments, Annual Recurring Compensation under the DPLTA, and receivables purchase arrangements there have been no other material changes in cash requirements from those discussed in the 2025 Form 10-K and our cash requirements table shown in Liquidity and Capital Resources above.

[0001193125-26-331632:mdna:162]
[same as prior period, unchanged from 0001193125-26-205276:mdna:151]

[0001193125-26-331632:mdna:163]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2026, and December 31, 2025, we had commitments related to these bonds totaling $23.3 million and $22.4 million, respectively, which expire at various dates through October 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001193125-26-331632:mdna:164]
[same as prior period, unchanged from 0001193125-26-205276:mdna:153]

[0001193125-26-331632:mdna:165]
[same as prior period, unchanged from 0001193125-26-205276:mdna:154]

[0001193125-26-331632:mdna:166]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Condensed Consolidated Financial Statements included in Part I, Item 1 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the critical accounting policies affect our more significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements. During the six months ended June 30, 2026, there were no significant changes to our critical accounting policies and estimates as described in the financial statements contained in the 2025 Form 10-K.

[0001193125-26-331632:mdna:167]
47
